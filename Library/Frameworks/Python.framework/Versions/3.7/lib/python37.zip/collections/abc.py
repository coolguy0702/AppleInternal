from _collections_abc import *
from _collections_abc import __all__
from _collections_abc import __name_for_get_source__, __loader__

