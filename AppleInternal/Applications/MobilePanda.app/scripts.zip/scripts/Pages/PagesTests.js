load("UIATesting.js");
load("SpringBoard.js");
load("Pages.js");

if (typeof PagesTestUtilities !== 'undefined') throw new UIAError("PagesTestUtilities has already been loaded!", {identifier:"UIA module already loaded"});
if (typeof PagesTest !== 'undefined') throw new UIAError("PagesTest has already been loaded!", {identifier:"UIA module already loaded"});

var PagesTestUtilities = {
    _cleanedBool: function _cleanedBool(boolString) {
        return (typeof boolString == 'string') ? boolString.match(/^true$/i) :
               (typeof boolString == 'number' ) ? (boolString != 0) :
               (typeof boolString == 'boolean' ) ? boolString : undefined;
    },

    _cleanedString: function _cleanedString(string) {
        return string ? String(string) : undefined;
    },

    _cleanedStringArray: function _cleanedStringArray(thunk) {
        var arr = [];
        if (typeof thunk == 'undefined') return arr;
        else if (thunk === null) return arr;
        else if (thunk instanceof Array) {
            for (var i in thunk) {
                arr.push( this._cleanedString(thunk[i]) );
            }

        } else {
            arr.push( this._cleanedString(thunk) );
        }

        return arr;
    },

    defaultTestArgs: function defaultTestArgs(args, customDefaults) {
        // First override with custom defaults if available
        if (typeof customDefaults == 'object') args = UIAUtilities.defaults(args, customDefaults);

        return UIAUtilities.defaults(args, {
            FolderName:                 "",
            DocumentName:               "",
            NewDocumentName:            "",
            TemplateType:               "",
            DocumentContents:           [],
            DocumentNames:              [],
        });
    },

    // Parses args dictionary into calendar test arguments
    parseOptions: function parseOptions(args) {
        // First do type-checking
        var options = {
            FolderName:                 this._cleanedString(args.FolderName),
            DocumentName:               this._cleanedString(args.DocumentName),
            NewDocumentName:            this._cleanedString(args.NewDocumentName),
            TemplateType:               this._cleanedString(args.TemplateType),
            DocumentContents:           args.DocumentContents.map( function(dc) {return pages._cleanedDocumentContent(dc);} ),
            DocumentNames:              this._cleanedStringArray(args.DocumentNames),
        };

        UIALogger.logMessage("Pages options passed in: %0".format(JSON.stringify(options)));
        return options;
    },
};


/**
 * @namespace PagesTests
 */
var PagesTests = {

/*******************************************************************************/
/*                                                                             */
/*   Mark: PagesTests Public API - Navigation                                  */
/*                                                                             */
/*      This is where test interfaces for handling Pages navigation            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Launches Pages, and walks through the splashscreen if necessary
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    launchApp: function launchApp(args) {
        pages.launchApp();
    },


/*******************************************************************************/
/*                                                                             */
/*   Mark: PagesTests Public API - Documents                                   */
/*                                                                             */
/*      This is where test interfaces for handling events                      */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Creates a new document
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.TemplateType="Blank"]                                                                         - Document template to start with
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SAMPLE TEXT","Overwrite":false}]]         - Contents to add to document
     */
    createDocument: function createDocument(args) {
        args = PagesTestUtilities.defaultTestArgs(args);
        var options = PagesTestUtilities.parseOptions(args);

        pages.createDocument(options.DocumentName, options);
    },
    
    /**
     * Verifies existing document(s) in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args - Test arguments.
     * @param {string} [args.DocumentName="SAMPLE NAME"]      - (Required) Name of document.
     * @param {string} [args.FolderName=""]                   - (Optional) Folder name where document exists.
     */
    verifyDocumentExists: function verifyDocumentExists(args) {
        args = PagesTestUtilities.defaultTestArgs(args);
        var options = PagesTestUtilities.parseOptions(args);

        pages._findDocument(options.DocumentName, options);
    },
    
    /**
     * Verifies document(s) don't exist in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args - Test arguments.
     * @param {string} [args.DocumentName="SAMPLE NAME"]      - (Required) Name of document.
     * @param {string} [args.FolderName=""]                   - (Optional) Folder name where document exists.
     */
    verifyDocumentDoesNotExists: function verifyDocumentDoesNotExists(args) {
        args = PagesTestUtilities.defaultTestArgs(args);
        var options = PagesTestUtilities.parseOptions(args);
        options.suppressError = true;
        var foundDocument = pages._findDocument(options.DocumentName, options);
        if (foundDocument) {
            throw new UIAError('The document named "%0" was found.'.format(options.DocumentName));
        }
    },

    /**
     * Edits an existing document in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.NewDocumentName=""]                                                                           - New Name of document
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"MODIFIED TEXT","Overwrite":true}]]        - Contents to add to document
     */
    editDocument: function editDocument(args) {
        args = PagesTestUtilities.defaultTestArgs(args);
        var options = PagesTestUtilities.parseOptions(args);

        pages.editDocument(options.DocumentName, options);
    },

    /**
     * Delete existing document(s) in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string[]}      [args.DocumentNames=["SAMPLE NAME"]]      - (Required) Name of document
     */
    deleteDocuments: function deleteDocuments(args) {
        args = PagesTestUtilities.defaultTestArgs(args);
        var options = PagesTestUtilities.parseOptions(args);

        pages.deleteDocuments(options.DocumentNames);
    },

    /**
     * Delete ALL existing document(s) in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    deleteAllDocuments: function deleteAllDocuments(args) {
        pages.deleteAllDocuments();
    },

    /**
     * Resolves conflict on the existing document(s) in Pages
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}    [args.documentName="SAMPLE NAME"]  - (Required) Name of document
     * @param {bool}      [args.local=false] - true if local conflicts are to be resolved
     * @param {bool}      [args.nonLocal=false] - true if non-local conflicts are to be resolved
     */
    resolveConflict: function resolveConflict(args) {
        args = UIAUtilities.defaults(args, {
        documentName: "SAMPLE",
        local: false,
        nonLocal: false,
        });

        pages.resolveConflict(args.documentName, args);
    },

     /**
     * Verifies the conflict appeared/disappeared on the screen
     * This test is an interface test to the Pages library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}    [args.documentName="SAMPLE NAME"]  - (Required) Name of document
     * @param {bool}      [args.expectConflict=true] - true if the test has to check for the conflict sheet
     */
    verifyConflict: function verifyConflict(args) {
        args = UIAUtilities.defaults(args, {
        documentName: "SAMPLE",
        expectConflict: true,
        });

        pages.verifyConflict(args.documentName, args);
    },

};
