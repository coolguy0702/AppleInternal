load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');

if (typeof pages !== 'undefined') throw new UIAError("Pages has already been loaded!", {identifier:"UIA module already loaded"});

/*******************************************************************************/
/*                                                                             */
/*   Mark: Pages Query Constants                                               */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIAQuery.Pages = {
    // FIRST_LAUNCH_SPLASHSCREEN: UIAQuery.query("TIAFirstLaunchDocumentStackContainerView"),

    CONTINUE_BUTTON: UIAQuery.buttons("Continue"),

    USE_ICLOUD_BUTTON: UIAQuery.buttons("Use iCloud"),

    START_USING_BUTTON: UIAQuery.buttons("View My Documents").orElse(UIAQuery.buttons("Use Pages")).orElse(UIAQuery.buttons("Documents")),

    MY_DOCUMENTS_BUTTON: UIAQuery.buttons("My Documents"),

    BROWSE_BUTTON: UIAQuery.buttons("Browse"),

    // NAVIGATION BAR BUTTONS
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Back")),

    DOCUMENTS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Documents")),

    ADD_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Add")),

    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Done")),

    EDIT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Edit")),

    DELETE_BUTTON: UIAQuery.buttons("Delete"),

    CANCEL_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Cancel")),

    EDIT_DOCUMENT_PAGE: UIAQuery.staticTexts().withPredicate('name contains[c] "TIADocumentTitleView"'),

    RENAME_DOCUMENT_TEXTFIELD: UIAQuery.textFields(),

    get EXIT_DOCUMENT_EDIT_BUTTON () { return this.BACK_BUTTON.isVisible().orElse(this.DONE_BUTTON.isVisible()).orElse(this.DOCUMENTS_BUTTON.isVisible()); },

    DELETE_DOCUMENT_SELECT_BUTTON: UIAQuery.buttons("Select"),

    DOCUMENT_MANAGER_VIEW: UIAQuery.query("DOCTabbedBrowserView").orElse(UIAQuery.query('TSADocumentManagerView')),

    EMPTY_DOCUMENT_MANAGER_VIEW: UIAQuery.query("TSADocumentManagerNoDocView"),

    DOCUMENT_EDIT_VIEW: UIAQuery.query("TSKScrollView"),

    DOCUMENT_PAGE_SETUP_VIEW: UIAQuery.query("TPDocSetupScrollView"),

    FIRST_LAUNCH_VIEW: UIAQuery.query("screenContentContainer"),

    CREATE_DOCUMENT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Add")),

    SELECT_CREATE_DOCUMENT_BUTTON:  UIAQuery.staticTexts().withPredicate('name contains[c] "Create Document"').parent(),
};



/*******************************************************************************/
/*                                                                             */
/*   Mark: Pages UI State Constants                                            */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIStateDescription.Pages = {
    FIRST_LAUNCH_VIEW:          'FIRST LAUNCH',
    DOCUMENT_MANAGER_VIEW:      'DOCUMENT MANAGER',
    EDIT_DOCUMENT_VIEW:         'EDIT DOCUMENT',
    CHOOSE_TEMPLATE_VIEW:       'CHOOSE TEMPLATE',
    DOCUMENT_EDIT_SELECTION:    'DOCUMENT EDIT SELECTION',
    DOCUMENT_COLLAB_SELECTION:  'DOCUMENT COLLAB SELECTION',
    DOCUMENT_PAGE_SETUP_VIEW:   'DOCUMENT PAGE SETUP',
}

/**
    @namespace
    @augments UIAApp
*/
var pages = target.appWithBundleID("com.apple.Pages");



/*******************************************************************************/
/*                                                                             */
/*   Mark: Pages Constants and Enums                                           */
/*                                                                             */
/*      Enums used by the Pages library, for internal and external API use     */
/*                                                                             */
/*******************************************************************************/



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Private UIAApp Extension Methods                 */
/*                                                                             */
/*      UIAApp extension methods that are specifically useful for Pages        */
/*                                                                             */
/*******************************************************************************/

pages._enterTextAndDismiss = function _enterTextAndDismiss(query, text, overwrite) {
    if (overwrite === undefined) overwrite = true;
    this.enterText(query, String(text), {clearTextBeforeTyping: Boolean(overwrite)});

    var keyboard = UIAQuery.keyboard();
    if (this.exists(keyboard)) {
        UIALogger.logMessage("Dismissing keyboard");
        this.dismissKeyboard()
        this.tapIfExists(keyboard.andThen(UIAQuery.buttons('Done').orElse(UIAQuery.buttons('Search'))));
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Pages Navigation & Navigation Setup              */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

function isHorizontalCompactUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.COMPACT;
}

function isHorizontalRegularUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
}

pages._navigationBarValueIs = function _navigationBarValueIs(navigationBarValue) {
    var navigationBarInfo = this.inspect(UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.TOP_NAVBAR.isVisible())) || this.inspect(UIAQuery.TOP_NAVBAR.isVisible());
    var navigationBarName = navigationBarInfo ? navigationBarInfo.name : null;
    return navigationBarName === navigationBarValue;
}

pages.NAVIGATION_VIEW_TRANSITIONS = [
    { from: UIStateDescription.Pages.EDIT_DOCUMENT_VIEW, to: UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW, transition:{action: function() { pages.tap(UIAQuery.Pages.EXIT_DOCUMENT_EDIT_BUTTON); pages.waitUntilPresent(UIAQuery.Pages.BACK_BUTTON.isVisible()); pages.tapIfExists(UIAQuery.Pages.BACK_BUTTON.isVisible()); }} },
    { from: UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Pages.DOCUMENT_EDIT_SELECTION, transition:{action:pages.tap, options:UIAQuery.Pages.EDIT_BUTTON} },
    { from: UIStateDescription.Pages.DOCUMENT_EDIT_SELECTION, to: UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW, transition:{action:pages.tap, options:UIAQuery.Pages.DONE_BUTTON} },
    { from: UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Pages.CHOOSE_TEMPLATE_VIEW, transition:{action: function() { pages.tap(UIAQuery.Pages.CREATE_DOCUMENT_BUTTON); pages.tapIfExists(UIAQuery.Pages.SELECT_CREATE_DOCUMENT_BUTTON); }} },
    { from: UIStateDescription.Pages.DOCUMENT_PAGE_SETUP_VIEW, to: UIStateDescription.Pages.EDIT_DOCUMENT_VIEW, transition:{action: function() { pages.tap(UIAQuery.query("Done")); pages.tapIfExists(UIAQuery.query("Done")); }} },
    { from: UIStateDescription.Pages.FIRST_LAUNCH_VIEW, to: UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW, transition:{action: function () { pages._walkThroughFirstLaunch(); }} },

];

// Define functions for determining current app's view state
pages.NAVIGATION_VIEWS = {};
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW]          = {action:pages.exists, options:UIAQuery.Pages.DOCUMENT_MANAGER_VIEW};
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.EDIT_DOCUMENT_VIEW]             = {action:pages.exists, options:UIAQuery.Pages.DOCUMENT_EDIT_VIEW};
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.DOCUMENT_EDIT_SELECTION]        = {action: function() { return pages._navigationBarValueIs('Select a Document') || (pages.exists(UIAQuery.Pages.DOCUMENT_MANAGER_VIEW) && pages.exists(UIAQuery.Pages.DONE_BUTTON)); } };
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.CHOOSE_TEMPLATE_VIEW]           = {action: function() { return pages._navigationBarValueIs('Choose a Template') || pages._navigationBarValueIs('Templates'); } };
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.DOCUMENT_PAGE_SETUP_VIEW]       = {action:pages.exists, options:UIAQuery.Pages.DOCUMENT_PAGE_SETUP_VIEW};
pages.NAVIGATION_VIEWS[UIStateDescription.Pages.FIRST_LAUNCH_VIEW]              = {action:pages.exists, options:UIAQuery.Pages.FIRST_LAUNCH_VIEW};

// Defines Pages Navigation
pages.navigation = new UIANavigation(pages, pages.NAVIGATION_VIEW_TRANSITIONS, pages.NAVIGATION_VIEWS);



/*******************************************************************************/
/*                                                                             */
/*   Mark: Pages Library Public API - Navigation                               */
/*                                                                             */
/*      This is where all public API methods for Pages Navigation              */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Safari for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
pages.currentUIState = function currentUIState() {
    var currentUIState = this.navigation.getCurrentState() || 'UNKNOWN STATE';
    UIALogger.logMessage("UI is currently on '%0'".format(currentUIState));
    return currentUIState;
}

/**
 * Launches Pages.  This differs from pages.launch() in that it will walk through the first-time splashscreen
 *
 * @throws If unable to launch Pages or walk through the splashscreen to the Document Manager View
*/
pages.launchApp = function launchApp() {
    this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Pages Library Public API - Document Management                      */
/*                                                                             */
/*      This is where all public API methods for Pages Navigation              */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Create new document
 *
 * @param {string}   DocumentName           - Name of the document
 * @param {object}   DocumentOptions        - Name of the pages
 *
 * @throws If unable to create a new document
 */
pages.createDocument = function createDocument(DocumentName, DocumentOptions) {
    DocumentOptions = pages._defaultDocumentOptions(DocumentOptions);

    this.navigation.goTo(UIStateDescription.Pages.CHOOSE_TEMPLATE_VIEW);
    this.tap( UIAQuery.tableCells(DocumentOptions.TemplateType) );

    this.waitUntilPresent(UIAQuery.Pages.DOCUMENT_EDIT_VIEW, 10);
    this._renameDocument(DocumentOptions.TemplateType, DocumentName);
    this.waitUntilPresent(UIAQuery.Pages.DOCUMENT_EDIT_VIEW, 10);
    this.editDocument(DocumentName, DocumentOptions);
}

/**
 * Edit existing document
 *
 * @param {string}   DocumentName           - Name of the document to be edited
 * @param {object}   DocumentOptions        - Name of the pages
 *
 * @throws If unable to find or edit document
 */
pages.editDocument = function editDocument(DocumentName, DocumentOptions) {
    if (DocumentOptions.NewDocumentName) {
        this._renameDocument(DocumentName, DocumentOptions.NewDocumentName);
        DocumentName = DocumentOptions.NewDocumentName;
    }

    this._getToDocument(DocumentName);
    this._applyDocumentContents(DocumentOptions.DocumentContents);

    UIALogger.logMessage("Finished applying changes to document; exiting document");
    this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
}

pages.deleteDocumentAlertHandler = function deleteDocumentAlertHandler() {
    var app = pages;
    if (app.exists(UIAQuery.withPredicate("name CONTAINS[c] 'Deleting '"))) {
        app.tap(UIAQuery.alerts().andThen('Delete'));
        return true;
    } return false;
};

/**
 * Deletes a list of existing documents.  Assumes all documents are uniquely named
 *
 * @param {string|string[]}    DocumentName         - Name(s) of the documents to be deleted
 *
 * @throws If unable to find or delete the listed documents
 */
pages.deleteDocuments = function deleteDocuments(DocumentNames) {
    DocumentNames = this._toStringList(DocumentNames);
    var documents = DocumentNames.map( (function (dn) { return this._findDocument(dn); }).bind(this) );

    this.tap(UIAQuery.Pages.BROWSE_BUTTON)
    this._tapDeleteDocument(documents);

    var remainingFiles = DocumentNames.filter( (function (dn) { return this._findDocument(dn, {suppressError: true}); }).bind(this) );
    if (remainingFiles.length > 0) throw new UIAError("The following files did not appear to be deleted: %0".format(JSON.stringify(remainingFiles)), {identifier:"Document(s) could not be deleted"});
    else UIALogger.logMessage("Successfully deleted the following files: %0".format(JSON.stringify(DocumentNames)));
}

pages.deleteAllDocuments = function deleteAllDocuments() {
    this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_EDIT_SELECTION);
    var allDocuments = UIAQuery.Pages.DOCUMENT_MANAGER_VIEW.andThen( UIAQuery.buttons().withPredicate("parent.name != 'UISegmentedControl' AND parent.name != 'TIADocumentManagerSearchBar'") );

    var buttonNames = this.inspectAll(allDocuments).map( function (n) {return n.name;} );
    for (var i in buttonNames) {
        this.tap( UIAQuery.buttons(buttonNames[i]).parent() );
    }

    this._tapDeleteDocument();

    if (this.exists( UIAQuery.Pages.EMPTY_DOCUMENT_MANAGER_VIEW )) {
        UIALogger.logMessage("All documents appear to have been successfully deleted");
    } else {
        var remainingDocs = this.inspectAll(allDocuments).map( function (n) {return n.name;} )
        .map( (function (n) {return this.inspect( UIAQuery.buttons(n).parent() ).name;}).bind(this) );
        throw new UIAError("The following files were not deleted:  %0".format(JSON.stringify(remainingDocs)), {identifier:"Some files were not deleted"});
    }
}

pages.sendDocument = function sendDocument() {
    /* DocumentName, Format/Pages, Word, ePub, PDF/, SendMethod/tons of options/ */
}

pages.shareDocument = function shareDocument() {
    // DocumentName, ShareOptions/Allow editing, View only/, Password, PasswordHint
    // should return Share Link
}

pages.stopSharingDocument = function stopSharingDocument() {
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Variable/Argument Sanitizers                     */
/*                            and Struct Defaults                              */
/*                                                                             */
/*      Sanitizes variables against types and Pages-specific enums/structs     */
/*                                                                             */
/*******************************************************************************/

pages._defaultDocumentOptions = function _defaultDocumentOptions(DocumentOptions) {
    DocumentOptions = UIAUtilities.defaults((typeof DocumentOptions !== "object") ? {} : DocumentOptions, {
        TemplateType:                       'Blank',
        NewDocumentName:                    undefined,
        DocumentContents:                   [],
    });

    DocumentOptions.TemplateType        = String(DocumentOptions.TemplateType);
    DocumentOptions.NewDocumentName     = (DocumentOptions.NewDocumentName == undefined) ? undefined : String(DocumentOptions.NewDocumentName);
    DocumentOptions.DocumentContents    = DocumentOptions.DocumentContents.map( (function (dc) {return this._cleanedDocumentContent(dc);}).bind(this) );

    return DocumentOptions;
}

pages._cleanedDocumentContent = function _cleanedDocumentContent(DocumentContent) {
    DocumentContent = UIAUtilities.defaults((typeof DocumentContent !== "object") ? {} : DocumentContent, {
        DocumentSection:                    '',
        Contents:                           '',
        Overwrite:                          false,
    });
    DocumentContent.DocumentSection = String(DocumentContent.DocumentSection);
    DocumentContent.Contents        = String(DocumentContent.Contents);
    DocumentContent.Overwrite       = Boolean(DocumentContent.Overwrite);
    return DocumentContent;
}


pages._toStringList = function _toStringList(x) {
    if (x === undefined || x === null) throw new UIAError("List is null or empty!", {identifier:"Invalid list"});
    else if (x instanceof Array) return x.map( function (i) {return String(i);} );
    else return [ String(x) ];
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Navigation                                       */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigation in Pages                                                */
/*                                                                             */
/*******************************************************************************/

/**
 * Asserts device is in a specified view in Pages
 *
 * @param {enum} ExpectedView            - The expected view (enum UIStateDescription.Pages)
 *
 * @throws If current view !== ExpectedView
 */
pages._ensureCurrentViewIs = function _ensureCurrentViewIs(ExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView !== ExpectedView) throw new UIAError("UIA expected to be in the '%0' view but is currently in the '%1' view instead!".format(ExpectedView, ActualView), {identifier:"Device in unexpected view"});
    return true;
}

/**
 * Asserts device is NOT in a specified view in Pages
 *
 * @param {enum} NotExpectedView            - The unexpected view (enum UIStateDescription.Pages)
 *
 * @throws If current view === NotExpectedView
 */
pages._ensureCurrentViewIsNot = function _ensureCurrentViewIsNot(NotExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView === NotExpectedView) throw new UIAError("UIA expected to not be in the '%0' view but currently is!".format(NotExpectedView), {identifier:"Device in unexpected view"});
    return true;
}

pages._walkThroughFirstLaunch = function _walkThroughFirstLaunch() {
    var validQueries = [ UIAQuery.Pages.CONTINUE_BUTTON, UIAQuery.Pages.USE_ICLOUD_BUTTON, UIAQuery.Pages.MY_DOCUMENTS_BUTTON, ];
    var button = validQueries.reduce(function (qA, qB, idx, arr) { return qA.orElse(qB.isVisible()); }, UIAQuery.withPredicate('FALSEPREDICATE'));
    while (this.exists(UIAQuery.Pages.FIRST_LAUNCH_VIEW)) {
        this.waitUntilPresent(button, 60);
        this.tap(button);
        this.delay(2); // This is necessary b/c the taps enter a race condition otherwise
    }
}

/**
 * Walks to Manage Document View, and returns the UIAQuery to the document, if found.  Useful for building other Pages library functions
 *
 * @param {string} documentName             - Name of the document to be verified.
 * @param {object} options                  - (Optional) Options dictionary.
 * @param {string} options.FolderName       - (Optional) Folder name where document exists.
 * @param {boolean} options.suppressError   - (Optional) If set to true, will return undefined upon failure to find document (instead of throwing UIAError)
 *
 * @throws If unable to find the document, and if suppressError is set to false.
 *
 * @returns {object|undefined} UIAQuery object to the document if the document is found; undefined otherwise
 */
pages._findDocument = function _findDocument(documentName, options) {
    options = UIAUtilities.defaults((typeof options !== "object") ? {} : options, {
        suppressError: false,
    });
    documentName = String(documentName);
    var folderName = options.FolderName && String(options.FolderName);

    this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);

    var folderQuery;
    if (folderName) {
        UIALogger.logMessage('Navigating to folder %0'.format(folderName));
        folderQuery = UIAQuery.beginsWith(folderName);
        this.tap(folderQuery);
    }

    var documentQuery = UIAQuery.collectionViews().bottommost().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "%0"'.format(documentName)));
    var numMatchingDocuments = this.count(documentQuery);

    var returnQuery = undefined;
    var msg = '';
    var errorID = '';

    if (numMatchingDocuments < 1) {
        msg = 'Did not find a document named "%0"'.format(documentName);
        errorID = "Didn't find the target document matching name";

    } else if (numMatchingDocuments > 1) {
        msg = 'Found %0 documents with name matches the given name (beginsWith): "%1"'.format(numMatchingDocuments, documentName);
        errorID = 'Found multiple documents matching name';

    } else {
        msg = 'Found exactly one document named "%0".'.format(documentName);
        returnQuery = documentQuery;
    }

    UIALogger.logMessage(msg);
    if (folderQuery) {
        this.tap(folderQuery);
    }

    if (!returnQuery && !options.suppressError) {
        throw new UIAError(msg, {identifier: errorID});
    }
    return returnQuery;
}

/**
 * Opens the document
 *
 * @param {string}      DocumentName         - Name of the document to be renamed
 *
 * @throws If unable to find or open the document
 */
pages._getToDocument = function _getToDocument(DocumentName) {
    var documentQuery = pages._findDocument(DocumentName);
    this.tap(documentQuery);
    this.waitUntilPresent(UIAQuery.Pages.DOCUMENT_EDIT_VIEW, 10);
}

/**
 * Tap the Delete Document while in Select Document view, and handles the Verify iCloud Document Delete alert that appears once
 *
 * @throws If unable to delete document
 */
pages._tapDeleteDocument = function _tapDeleteDocument(documents) {
    var _deleteDocumentAlertHandler = function() {
        var app = pages;
        if (app.exists(UIAQuery.withPredicate("name CONTAINS[c] 'Deleting '"))) {
            app.tap(UIAQuery.alerts().andThen('Delete'));
            return true;
        } return false;
    };

    this.withAlertHandler(_deleteDocumentAlertHandler, function () {
        this.tap( UIAQuery.Pages.DELETE_DOCUMENT_SELECT_BUTTON );
        for (var i in documents) {
            this.tap(documents[i]);
            UIALogger.logDebug(documents[i])
        };
        this.tap( UIAQuery.Pages.DELETE_BUTTON );

        this.navigation.goTo(UIStateDescription.Pages.CHOOSE_TEMPLATE_VIEW);
        this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
    });
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Editing Documents                                */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigating to specific documents in Pages                          */
/*                                                                             */
/*******************************************************************************/

/**
 * Rename an existing document.  Assumes all documents are uniquely named
 *
 * @param {string}   DocumentName           - Name of the document to be renamed
 * @param {object}   NewDocumentName        - New name for the document
 *
 * @throws If unable to find or rename document
 */
pages._renameDocument = function _renameDocument(DocumentName, NewDocumentName) {
    NewDocumentName = String(NewDocumentName);
    var documentQuery = this._findDocument(DocumentName);

    var newDocumentQuery = this._findDocument(NewDocumentName, {suppressError: true});
    if (newDocumentQuery !== undefined) {
        throw new UIAError("Cannot rename document to '%0' because another such document already exists!".format(NewDocumentName), {identifier:"Document rename conflict"});
    }

    this.tap(documentQuery);
    this.waitUntilPresent(UIAQuery.Pages.EDIT_DOCUMENT_PAGE, 10);
    this.tap(DocumentName);
    this.waitUntilPresent(UIAQuery.Pages.RENAME_DOCUMENT_TEXTFIELD, 10);
    this._enterTextAndDismiss(UIAQuery.Pages.RENAME_DOCUMENT_TEXTFIELD, NewDocumentName);

    if (pages._findDocument(NewDocumentName) !== undefined) UIALogger.logMessage("Successfully renamed document to '%0'".format(NewDocumentName));
}

/**
 * Apply a list of changes to a document.  Assumes device is currently in Edit Document View
 *
 * @param {DocumentContent[]}   DocumentContents           - List of changes to apply to a document.  Schema for DocumentContent is defined in the documentation for pages._cleanedDocumentContent()
 *
 * @throws If unable to apply the specified changed to a document
 */
pages._applyDocumentContents = function _applyDocumentContents(DocumentContents) {
    this.waitUntilPresent(UIAQuery.Pages.DOCUMENT_EDIT_VIEW, 10);
    for (var i in DocumentContents) {
        var content = DocumentContents[i];
        UIALogger.logMessage("Attempting to write to document %0 [%1]:    %2".format(content.DocumentSection, content.Overwrite ? "OVERWRITE" : "APPEND", content.Contents));
        this._enterTextToDocumentSection(content.DocumentSection, content.Contents, content.Overwrite);
    }
}

/**
 * Enters text to page section.  Assumes device is currently in Edit Document View
 *
 * @param {string}      DocumentSection     - Name of the page section (i.e. 'Body', 'Center Header')
 * @param {string}      Contents            - Content to add to document
 * @param {bool}        Overwrite           - If true; clear all text inside field prior to typing in Contents
 *
 * @throws If unable to add the specified contents into the specified document section
 */
pages._enterTextToDocumentSection = function _enterTextToDocumentSection(DocumentSection, Contents, Overwrite) {
    DocumentSection  = String(DocumentSection);
    this._enterTextAndDismiss(UIAQuery.textViews(DocumentSection), Contents, Overwrite);

    // For iPads editing Body, there is no 'Done' to tap
    // For page sections, one 'Done' tap is required
    // For iPhones, 2 'Done' taps are required for non-Body page sections
    this.tapIfExists(UIAQuery.query("Done").isVisible());
    this.tapIfExists(UIAQuery.query("Done").isVisible());
}

pages._getDocumentContents = function _getDocumentContents(DocumentName) {
    this._getToDocument(DocumentName);
    this.waitUntilPresent(UIAQuery.Pages.DOCUMENT_EDIT_VIEW, 10);
    return this.inspect(UIAQuery.textViews('Body')).value;
}

/**
 * Resolves the conflict on the documents
 * @param {string} documentName - Name of the Document
 * @param {object} options
 * @param {bool} options.local - true if local conflicts are to be resolved
 * @param {bool} options.nonLocal - true if non-local conflicts are to be resolved
 */
pages.resolveConflict = function resolveConflict(documentName, options) {
    options = UIAUtilities.defaults(options, {
        local: false,
        nonLocal: false,
    });
    var documentQuery = pages._findDocument(documentName);
    this.tap(documentQuery);
    this.waitUntilAbsent(UIAQuery.Pages.DOCUMENT_MANAGER_VIEW, 10);
    if (!this.exists(UIAQuery.tableViews("UITableView").andThen(UIAQuery.tableCells()))) {
        throw new UIAError('The conflict window never showed up');
    }
    if (options.local && options.nonLocal) {
        this.tapIfExists(UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().atIndex(0)));
        this.tap(UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().atIndex(1)));
        this.tap(UIAQuery.buttons('Keep Both'));
    } else if (options.local) {
        this.tapIfExists(UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().atIndex(0)));
        this.tap(UIAQuery.buttons('Keep 1'));
    } else if (options.nonLocal) {
        this.tapIfExists(UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().atIndex(1)));
        this.tap(UIAQuery.buttons('Keep 1'));
    } else {
        throw new UIAError('The conflict window appeared but none of the options were selected');
    }
}

/**
 * Verifies the conflict appeared/disappeared on the screen
 * @param {string} documentName - Name of the Document
 * @param {object} options
 * @param {bool} options.expectConflict - true if you want to check if the conflict sheet appeared
 *
 **/
pages.verifyConflict = function verifyConflict(documentName, options) {
    options = UIAUtilities.defaults(options, {
        expectConflict: true,
    });
    this.launchApp();
    var documentQuery = pages._findDocument(documentName);
    this.tap(documentQuery);
    this.waitUntilAbsent(UIAQuery.Pages.DOCUMENT_MANAGER_VIEW, 10);
    if (options.expectConflict) {
        if (this.exists(UIAQuery.tableViews("UITableView").andThen(UIAQuery.tableCells()))) {
            UIALogger.logMessage("The conflict sheet appeared on the screen");
        } else {
            throw new UIAError("The conflict sheet did not appear on the screen");
        }
    } else if (this.exists(UIAQuery.Pages.DOCUMENT_EDIT_VIEW)) {
        UIALogger.logMessage("The conflict sheet does not appear on the screen");
    } else {
        throw new UIAError("The Conflict sheet which is not supposed to appear, appears on the screen");
    }
}

