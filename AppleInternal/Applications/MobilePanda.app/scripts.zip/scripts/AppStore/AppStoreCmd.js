#! /usr/local/bin/scripter2 -verboseerror YES -f

load('../SpringBoard/SpringBoard.js');
load('/usr/local/etc/scripter/libs/UIATestingEnvironment.js');
load('AppStore.js');


function usage() {
    system.println("usage: AppStoreCmd.js -h ");
    system.println("       AppStoreCmd.js --help");
    system.println("    --launchVerify          Launch the App and verify content in each tab")
    system.println("    --searchForApp          Launch the App and Search for an App")
    system.println("    --searchString          String to search the store for")
    system.println("    --appName               Name of the App to verify after searching/selecting")
    
    system.println("    Example     ./AppStoreCmd.js --launchVerify");
}

function main() {
    var options = new Options();
    if (options.help || options.h) {
        usage();
        system.exit(0);
    }
    var testID;
    var testDescription;
    var args = [];
    var testFunction = undefined;
    var theTest = undefined;
    if (options.launchVerify) {
        args = [];
        testFunction = launchVerify;
        testID = 'Launch/Verify: ';
        testDescription = ' Open AppStore and verify elements exist';
    }
    else if (options.searchAndSubscribe) {
        args = [];
        testFunction = searchForApp;
        testID = 'searchForApp: ';
        testDescription = 'Launch and Search for an App';
    }
    else {
        system.println("ERROR: Failed to Run Any Test");
        usage();
        system.exit(1);
    }
    
    theTest = new UIATesting.Test(testID, args, testFunction, testDescription);
    
    system.println("Starting Test: " + testDescription);
    theTest.run();
    
    if (theTest.testResult == 0) {
        system.println("Test Failed");
        system.exit(1);
    }
    else {
        system.println("Finish Successfully");
        system.exit(0);
    }
}

main();
