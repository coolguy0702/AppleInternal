load('UIAApp.js');
load('SpringBoard.js');
load('Safari.js')

UIAUtilities.assert(
    typeof AppStore === 'undefined',
    'AppStore has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/
/**
    @namespace
    @augments UIAApp
*/
var appstore = target.appWithBundleID('com.apple.AppStore');
/** Constants for tabs - we should only need to change these in one place if UI Changes */
TABS = {
    /** 'Today' button within a TabBar */
    TODAY:                  'Today',
    /** 'Games' button within a TabBar */ 
    GAMES:                  'Games',
    /** 'Apps' button within a TabBar */ 
    APPS:                   'Apps',
    /** 'Featured' button within a TabBar */
    FEATURED:               'Featured',
      /** 'Top Charts' button within a TabBar */
    TOP_CHARTS:             'Top Charts',
        /** 'Explore' button within a TabBar */
    EXPLORE:                'Explore',
        /** 'Search' button within a TabBar */
    SEARCH:                 'Search',
        /** 'Purchased' button within a TabBar */
    PURCHASED:              'Purchased',
        /** 'Updates' button within a TabBar */
    UPDATES:                'Updates',
},

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/
UIAQuery.AppStore = {
    /** 'Featured' button within a TabBar */
    TABS: {
        /** 'Today' button within a TabBar */
        TODAY:                     UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.TODAY)),
        /** 'Games' button within a TabBar */
        GAMES:                     UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.GAMES)),
        /** 'Apps' button within a TabBar */
        APPS:                     UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.APPS)),
        /** 'Featured' button within a TabBar */
        FEATURED:                  UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.FEATURED)),
          /** 'Top Charts' button within a TabBar */
        TOP_CHARTS:                UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.TOP_CHARTS)),
            /** 'Explore' button within a TabBar */
        EXPLORE:                   UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.EXPLORE)),
            /** 'Search' button within a TabBar */
        SEARCH:                    UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.SEARCH)),
            /** 'Purchased' button within a TabBar */
        PURCHASED:                 UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.PURCHASED)),
            /** 'Updates' button within a TabBar */
        UPDATES:                   UIAQuery.tabBars().andThen(UIAQuery.buttons(TABS.UPDATES)),
    },

    /** 'Edit' button within a NavigationBar */
    EDIT_NAVBAR_BUTTON:            UIAQuery.navigationBars().andThen(UIAQuery.buttons('Edit')),
    /** 'Done' button within a NavigationBar */
    DONE_NAVBAR_BUTTON:            UIAQuery.navigationBars().andThen(UIAQuery.buttons('Done')),
    /** 'Search' key on keyboard */
    SEARCH_KEY:                    UIAQuery.query('UIKeyboardLayoutStar').andThen(UIAQuery.buttons().contains('Search')),
    /** 'SearchBar' */
    SEARCH_BAR:                    UIAQuery.searchBars('App Store'),
    /** 'Cancel' button */
    CANCEL:                        UIAQuery.buttons('Cancel'),
    /** 'Content Unavailable' View */
    UNAVAILABLE_CONTENT_VIEW:      UIAQuery.query('_UIContentUnavailableView'),
    /** 'Search Results' View */
    SEARCH_RESULTS_CONTAINER:      UIAQuery.collectionViews('SKUICollectionView'),
    /** 'Get Alert' */
    GET_ALERT: 					   UIAQuery.alerts('GET'),
    /** 'Sign in' */
    FIRST_SIGN_IN_ALERT:           UIAQuery.alerts('Sign In'),
    /** 'Sign in to iTunes Alert */
    SIGN_IN_ALERT:                 UIAQuery.alerts('Sign In to iTunes Store'),
    /** Install Alert that that pops up while trying to install an app that's not present in iCloud" */
    INSTALL_ALERT:                 UIAQuery.alerts("SBAlertViewAdapter"),
    /** 'iTunes Terms Conditions Changed Alert */
    TERMS_CHANGED_ALERT:           UIAQuery.alerts('iTunes Terms & Conditions Have Changed'),
    /** 'You have already purchased' alert */
    ALREADY_PURCHASED_ALERT:       UIAQuery.alerts('You have already purchased this item. To download it again for free, select OK.'),
    /** 'Categories Button on Featured tab screen */
    CATEGORIES_BUTTON:             UIAQuery.buttons('Categories'),
    /** 'Back button on Categories Popup view */
    BACK_BUTTON:                   UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.buttons('Back')),
    /** 'Purchase button on Categories Popup view */
    PURCHASE_BUTTON:               UIAQuery.query('OverlayCaptureView').andThen(
                                       UIAQuery.buttons('PurchaseButton')).orElse(UIAQuery.buttons('PurchaseButton')).orElse(UIAQuery.buttons('AppStore.OfferButton')),
    /** 'Purchase button when downloading */
    PURCHASE_BUTTON_DOWNLOADING:   UIAQuery.buttons('PurchaseButton').withPredicate('identifiers contains "Cancel download"'),
    /** Terms and conditions changed window*/
    TERMS_WINDOW:                  UIAQuery.staticTexts().withPredicate('name contains[c] "Terms and Conditions have changed"'),
    /** 'Install' button*/
    INSTALL_BUTTON:                UIAQuery.buttons('Install'),
    /** 'GET' Button*/
    GET_BUTTON: 				   UIAQuery.buttons('GET'),
    /** 'Enter Password' button*/
    ENTER_PASSWORD_BUTTON:         UIAQuery.buttons('Enter Password'),
    /** 'Agree' button in Terms and Conditions window */
    AGREE_BUTTON:                  UIAQuery.buttons('Agree'),
    /** 'Agree' button in Terms and Conditions Alert */
    AGREE_TO_TERMS_ALERT_BUTTON:   UIAQuery.alerts().andThen(UIAQuery.buttons('Agree')),
    /** Downloading Button/progress circle */
    DOWNLOADING_BUTTON:            UIAQuery.buttons('Downloading'),
    /** Use Existing Apple ID button */
    USE_EXISTING_APPLE_ID_BUTTON:  UIAQuery.buttons('Use Existing Apple ID'),
    /** Password field */
    PASSWORD_FIELD:                UIAQuery.secureTextFields('Password').last(),
    /** 'Account Not In This Store' Alert */
    ACCOUNT_NOT_IN_STORE_ALERT:    UIAQuery.alerts('Account Not In This Store'), 
    /** 'Change Store' button */
    CHANGE_STORE_BUTTON:           UIAQuery.buttons().contains('Change Store'),
    /** 'Welcome to the App Store' Alert */
    WELCOME_ALERT:                 UIAQuery.staticTexts('Welcome to the App Store'), 
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/
/** Constants for possible UI state names specific to AppStore */
UIStateDescription.AppStore = {

    /** Today Tab */
    TODAY:                      'today',
    /** Splash Screen */
    SPLASH_SCREEN:              'Splash Screen',
    /** Now Playing */
    NOW_PLAYING:                'now playing',
    /** Cannot Connect to App Store */
    CANNOT_CONNECT:             'Cannot Connect to App Store',
    /** Featured Tab on bottom tab bar */
    FEATURED:                    TABS.FEATURED,
    /** Top Charts Tab*/
    TOP_CHARTS:                  TABS.TOP_CHARTS,
    /** Explore Tab*/
    EXPLORE:                     TABS.EXPLORE,
    /** Purchased Tab - iPad only */
    PURCHASED:                   TABS.PURCHASED,
    /** Search Tab - iphone-ish only */
    SEARCH:                      TABS.SEARCH,
    /** Updates Tab*/
    UPDATES:                     TABS.UPDATES,
    /** UI name for each top level category in FEATURED Tab */
    /** KIDS Category Page */
    KIDS:                     'Kids',
    /** Games Tab*/
    GAMES:                       TABS.GAMES,
    /** Apps Tab*/
    APPS:                       TABS.APPS,
    /** NEWSSTAND Category Page */
    NEWSSTAND:                'Newsstand',
    /** BOOKS Category Page */
    BOOKS:                    'Books',
    /** BUSINESS Category Page */
    BUSINESS:                 'Business',
    /** CATALOGS Category Page */
    CATALOGS:                 'Catalogs',
    /** EDUCATION Category Page */
    EDUCATION:                'Education',
    /** ENTERTAINMENT Category Page */
    ENTERTAINMENT:            'Entertainment',
    /** FINANCE Category Page */
    FINANCE:                  'Finance',
    /** FOOD_AND_DRINK Category Page */
    FOOD_AND_DRINK:           'Food & Drink',
    /** HEALTH_AND_FITNESS Category Page */
    HEALTH_AND_FITNESS:       'Health & Fitness',
    /** LIFESTYLE Category Page */
    LIFESTYLE:                'Lifestyle',
    /** MEDICAL Category Page */
    MEDICAL:                  'Medical',
    /** MUSIC Category Page */
    MUSIC:                    'Music',
    /** NAVIGATION Category Page */
    NAVIGATION:               'Navigation',
    /** NEWS Category Page */
    NEWS:                     'News',
    /** PHOTO_AND_VIDEO Category Page */
    PHOTO_AND_VIDEO:          'Photo & Video',
    /** PRODUCTIVITY Category Page */
    PRODUCTIVITY:             'Productivity',
    /** REFERENCE Category Page */
    REFERENCE:                'Reference',
    /** SOCIAL_NETWORKING Category Page */
    SOCIAL_NETWORKING:        'Social Networking',
    /** SPORTS Category Page */
    SPORTS:                   'Sports',
    /** TRAVEL Category Page */
    TRAVEL:                   'Travel',
    /** UTILITIES Category Page */
    UTILITIES:                'Utilities',
    /** WEATHER Category Page */
    WEATHER:                  'Weather',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/
/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and AppStore for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
appstore.currentUIState = function currentUIState() {
    var navBarName = null;
    if (appstore.exists(UIAQuery.staticTexts("Explore"))) {
        return UIStateDescription.AppStore.EXPLORE;
    }

    if (!appstore.exists(UIAQuery.navigationBars()) &&
        (appstore.exists(UIAQuery.buttons().contains('OF THE DAY')) ||
         appstore.exists(UIAQuery.buttons().contains('OF THE\nDAY')))) {
            return UIStateDescription.AppStore.TODAY;
    }

    if (this.exists(UIAQuery.navigationBars())) {
        navBarName = this.nameOf(UIAQuery.navigationBars());
        switch (navBarName) {
            case 'Today':
                return UIStateDescription.AppStore.TODAY;
            case 'Featured':
                return UIStateDescription.AppStore.FEATURED;
            case 'Top Charts':
                return UIStateDescription.AppStore.TOP_CHARTS;
            case 'Explore':
                return UIStateDescription.AppStore.EXPLORE;
            case 'Search':
                return UIStateDescription.AppStore.SEARCH;
            case 'Purchased':
                return UIStateDescription.AppStore.EXPLORE;
            case 'Updates':
                return UIStateDescription.AppStore.UPDATES;
            case 'Games':
                return UIStateDescription.AppStore.GAMES;
            case 'Apps':
                return UIStateDescription.AppStore.APPS;
            case 'Kids':
                return UIStateDescription.AppStore.KIDS;
            case 'Newsstand':
                return UIStateDescription.AppStore.NEWSSTAND;
            case 'Books':
                return UIStateDescription.AppStore.BOOKS;
            case 'Business':
                return UIStateDescription.AppStore.BUSINESS;
            case 'Catalogs':
                return UIStateDescription.AppStore.CATALOGS;
            case 'Education':
                return UIStateDescription.AppStore.EDUCATION;
            case 'Entertainment':
                return UIStateDescription.AppStore.ENTERTAINMENT;
            case 'Finance':
                return UIStateDescription.AppStore.FINANCE;
            case 'Food & Drink':
                return UIStateDescription.AppStore.FOOD_AND_DRINK;
            case 'Health & Fitness':
                return UIStateDescription.AppStore.HEALTH_AND_FITNESS;
            case 'Lifestyle':
                return UIStateDescription.AppStore.LIFESTYLE;
            case 'Medical':
                return UIStateDescription.AppStore.MEDICAL;
            case 'Music':
                return UIStateDescription.AppStore.MUSIC;
            case 'Navigation':
                return UIStateDescription.AppStore.NAVIGATION;
            case 'News':
                return UIStateDescription.AppStore.NEWS;
            case 'Photo & Video':
                return UIStateDescription.AppStore.PHOTO_AND_VIDEO;
            case 'Productivity':
                return UIStateDescription.AppStore.PRODUCTIVITY;
            case 'Reference':
                return UIStateDescription.AppStore.REFERENCE;
            case 'Social Networking':
                return UIStateDescription.AppStore.SOCIAL_NETWORKING;
            case 'Sports':
                return UIStateDescription.AppStore.SPORTS;
            case 'Travel':
                return UIStateDescription.AppStore.TRAVEL;
            case 'Utilities':
                return UIStateDescription.AppStore.UTILITIES;
            case 'Weather':
                return UIStateDescription.AppStore.WEATHER;
            default:
                UIALogger.logWarning('Existing navbar did not match any known states');
        }
    } else if (appstore.exists(UIAQuery.staticTexts('Welcome to the App Store'))) {
        return UIStateDescription.AppStore.SPLASH_SCREEN;
    }

    throw new UIAError('Could not determine current UI state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/
/**
* Launch the app if we have not yet, and get to the Tab we
*/
appstore.getToTab = function getToTab(tab, options) {
    options = UIAUtilities.defaults(options, {
        noLaunch: false,
    });

    if (!options.noLaunch){
        this.launch();
    }

    appstore.exitVisiblePopovers();
    var currentState = this.currentUIState();
    switch (currentState) {
        case UIStateDescription.AppStore.FEATURED:
        case UIStateDescription.AppStore.TOP_CHARTS:
        case UIStateDescription.AppStore.EXPLORE:
        case UIStateDescription.AppStore.SEARCH:
        case UIStateDescription.AppStore.PURCHASED:
        case UIStateDescription.AppStore.UPDATES:
        case UIStateDescription.AppStore.GAMES:
        case UIStateDescription.AppStore.APPS:
        case UIStateDescription.AppStore.TODAY:
        /* The below UI states are part of the FEATURED tab and are ok if we want to navigate to a tab. */
        case UIStateDescription.AppStore.KIDS:
        case UIStateDescription.AppStore.NEWSSTAND:
        case UIStateDescription.AppStore.BOOKS:
        case UIStateDescription.AppStore.BUSINESS:
        case UIStateDescription.AppStore.CATALOGS:
        case UIStateDescription.AppStore.EDUCATION:
        case UIStateDescription.AppStore.ENTERTAINMENT:
        case UIStateDescription.AppStore.FINANCE:
        case UIStateDescription.AppStore.FOOD_AND_DRINK:
        case UIStateDescription.AppStore.HEALTH_AND_FITNESS:
        case UIStateDescription.AppStore.LIFESTYLE:
        case UIStateDescription.AppStore.MEDICAL:
        case UIStateDescription.AppStore.MUSIC:
        case UIStateDescription.AppStore.NAVIGATION:
        case UIStateDescription.AppStore.NEWS:
        case UIStateDescription.AppStore.PHOTO_AND_VIDEO:
        case UIStateDescription.AppStore.PRODUCTIVITY:
        case UIStateDescription.AppStore.REFERENCE:
        case UIStateDescription.AppStore.SOCIAL_NETWORKING:
        case UIStateDescription.AppStore.SPORTS:
        case UIStateDescription.AppStore.TRAVEL:
        case UIStateDescription.AppStore.UTILITIES:
        case UIStateDescription.AppStore.WEATHER:
            break;
        default:
            // if we got here, we don't have no clue where we are...
            throw new UIAError('Could not determine state.');
    }

    // Should be at the top level of a tab now.
    // Can now tap ����a tab button
    switch (tab) {
        case TABS.TODAY:
            this.tap(UIAQuery.AppStore.TABS.TODAY);
            break;
        case TABS.FEATURED:
            this.tap(UIAQuery.AppStore.TABS.FEATURED);
            break;
        case TABS.TOP_CHARTS:
            this.tap(UIAQuery.AppStore.TABS.TOP_CHARTS);
            break;
        case TABS.EXPLORE:
            this.tap(UIAQuery.AppStore.TABS.EXPLORE);
            break;
        case TABS.SEARCH:
            this.tap(UIAQuery.AppStore.TABS.SEARCH);
            break;
        case TABS.PURCHASED:
            this.tap(UIAQuery.AppStore.TABS.PURCHASED);
            break;
        case TABS.UPDATES:
            this.tap(UIAQuery.AppStore.TABS.UPDATES);
            break;
        case TABS.GAMES:
            this.tap(UIAQuery.AppStore.TABS.GAMES);
            break;
        case TABS.APPS:
            this.tap(UIAQuery.AppStore.TABS.APPS);
            break;
        default:
            // should never get here
            throw new UIAError('Could not get to unknown tab: \'%0\'.'.format(tab));
    }
}


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Purchase the app through URL                                            */
/*                                                                                 */
/*          Actual code to purchase the app from url provided                      */
/*                                                                                 */
/***********************************************************************************/
/**
* Purchase an App In the Store, using a URL
*
* @param {object} args - Test arguments
* @param {string} [args.url="https://itunes.apple.com/us/app/pandora-radio/id284035177?mt=8"] - Exact url of the
* desired application
* @param {string} [args.username="PERSISTEDAPPLEID"] - App Store ID
* @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - AppStore password.
* @param {string} [args.appLoadingTime=60] - Time (in seconds) used as timeout when loading the app
*/
appstore.purchaseAppThroughURL = function purchaseAppThroughURL(options) {
    safari.launch();
    safari.handlingAlertsInline(UIAQuery.alerts().withPredicate('name contains[c] "Open this page in"') , function() {
        try {
            safari.loadURL(options.url);
            if (this.waitUntilPresent(UIAQuery.buttons('Open'), 5)) {
               safari.tapIfExists('Open');
            }
        } catch(e) {
            //Since Safari will no longer be the frontmost app, ignore the error thrown out for that
            UIALogger.logError('Got an error when try to load url in Safari to open AppStore. ' + e.message);
            UIALogger.logDebug('Ignoring the error that Safari is no longer the frontmost app');
        }

    });
    if (appstore.currentUIState() === UIStateDescription.AppStore.SPLASH_SCREEN) {
        appstore.handleSplashScreen();
    }
    appstore.downloadSelectedApp(options);

}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
* Search for an Application in the Store
*
* @param {object} options
* @param {string} options.appSearchTitle - the name of the App to search for
* @param {string} options.appName - Name of the App to verify after search
*
* @returns {UIAQuery} - query evaluating to 'GET' button associated with App, null otherwise
*/
appstore.searchForApp = function searchForApp(options) {
    if (target.activeApp().name() != 'AppStore' && !springboard.isInSideAppView()) {
        appstore.launch();
    }

    appstore.handleSplashScreen();
    appstore.getToTab(TABS.SEARCH);
    //search here for options.podcastSearchTitle;
    UIALogger.logMessage('Searching for: ' + options.appSearchTitle);
    // bring keyboard up
    if (!this.exists(UIAQuery.keyboard().isVisible())) {
        //click the search field
        this.tap(UIAQuery.AppStore.SEARCH_BAR);
    }
    this.typeString(options.appSearchTitle);
    this.tapIfExists(UIAQuery.AppStore.SEARCH_KEY);

    UIALogger.logMessage('Check the view now for the searched content: ' + options.appName);

    var resultsLoaded = UIAWaiter.withPredicate(
                            'ViewDidAppear', 
                            'controllerClass = "AppStore.SearchResultsViewController"');
    resultsLoaded.wait(10);

    if (this.count(UIAQuery.tableCells().contains(options.appSearchTitle)) > 0) {
        return (UIAQuery.tableCells().contains(options.appSearchTitle).andThen(UIAQuery.buttons()));
    }
    return null;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
* Check the the store is Unavailable, reutrn true if it is or false if not
*/
appstore.storeUnavailable = function storeUnavailable() {
    return this.exists(UIAQuery.AppStore.UNAVAILABLE_CONTENT_VIEW);
}

/**
* This function handles Splash Screens
*/
appstore.handleSplashScreen = function handleSplashScreen(){
    UIALogger.logMessage('Handling Splash Screen');
    if (appstore.waitUntilPresent(UIAQuery.AppStore.WELCOME_ALERT,20)) {
        appstore.tapIfExists(UIAQuery.CONTINUE_BUTTON);
    }   
}

/**
* Tap on features tab, and get to the top view of categories pop up
*
*/
appstore.waitForDownload = function waitForDownload(getButton) {
    UIALogger.logMessage('Wait for the app to finish downloading.');
    var appSheet = UIAQuery.query('OverlayCaptureView');
    // Appsheet purchase button, needed for this test only. // TODO - make this better with waiters
    var purchaseButton = getButton; 
    var counter = 0;
    var limit = 12 * 10;
    while (this.inspect(purchaseButton).label != 'OPEN') {
        if (counter > limit) {
            throw new UIAError('App did not load after %0 minutes.').format(limit/12);
        }

        if ((!this.inspect(purchaseButton).value ||
             !this.inspect(purchaseButton).value.contains('%')) &&
            this.inspect(purchaseButton).label != 'OPEN') {
            // If app is no longer downloading for whatever reason.
            throw new UIAError('App is not downloading.');
        } else {
            // If app has not finished downloading.
            UIALogger.logDebug(this.inspect(purchaseButton).value);
        }
        counter +=1;
        // <rdar://problem/22503104> Remove Delay from 22448780
        target.delay(5);
    }
    UIALogger.logDebug('App has been installed.');
}

/**
* Change the Orientation of the app.  For iPad only.
*
*/
function rotateAndCheck(rotation) {
    // TODO - the corrisponding test will be implemented and this funciton will be better defined.
    UIATarget.localTarget().setDeviceOrientation(rotation);
    if (UIATarget.localTarget().activeApp().name() !== 'App Store') {
        throw new UIAError('Target was not valid after switching orientation');
    }
    UIALogger.logDebug('Change orientation was completed with popover view');
}

/**
* Handle app purchase, including any sign-in alerts.
*
* @param {object} options - Test arguments
* @param {string} [options.appName='Pandora Radio'] - Exact name of the
* desired application, as shown in the App store.
* @param {string} [options.username='PERSISTEDAPPLEID'] - App Store ID
* @param {string} [options.password='PERSISTEDAPPLEIDPASSWORD'] - AppStore password.
* @param {string} [options.appLoadingTime=60] - Time (in seconds) used as timeout when loading the app
*/
appstore.downloadSelectedApp = function downloadSelectedApp(options) {
    UIALogger.logMessage('We are in the downloadSelectedApp function for: %0'.format(options.appName));

    var purchaseButton = null;
    if (options.getButton) {
        purchaseButton = options.getButton;
    } else {
        purchaseButton = UIAQuery.AppStore.PURCHASE_BUTTON;
    }

    appstore.waitUntilPresent(purchaseButton, options.appLoadingTime);
    if (this.inspect(purchaseButton).identifiers.contains('OPEN')) {
        UIALogger.logWarning('Application %0 has already been downloaded.'.format(options.appName));
        return;
    }

    var paymentAuthorizationWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass = "PKPaymentAuthorizationServiceViewController"'
    );

    var handler = function() {
        UIALogger.logMessage('Inside the Handler. Trying to find the Alert')
        if (springboard.exists(UIAQuery.AppStore.FIRST_SIGN_IN_ALERT)) {
            UIALogger.logMessage('Detected Sign In Alert');
            springboard.tap(UIAQuery.AppStore.USE_EXISTING_APPLE_ID_BUTTON);
            UIALogger.logMessage('Successfully Handled Sign In Alert');
            return true;
        } else if (springboard.exists(UIAQuery.AppStore.SIGN_IN_ALERT)) {
            UIALogger.logMessage('Detected Sign In to iTunes Store Alert');
            springboard.typeString(options.username);
            springboard.tap(UIAQuery.AppStore.PASSWORD_FIELD);
            springboard.typeString(options.password);
            springboard.tap(UIAQuery.buttons('OK'));
            UIALogger.logMessage('Successfuly Handled Sign In to iTunes Store Alert');
            return true;
        } else if (springboard.exists(UIAQuery.AppStore.ACCOUNT_NOT_IN_STORE_ALERT)) {
            UIALogger.logMessage('Detected Acccount not in store Alert');
            springboard.tap(UIAQuery.AppStore.CHANGE_STORE_BUTTON);
            return true;
        } else if (appstore.exists(UIAQuery.AppStore.WELCOME_ALERT)) {
            appstore.tapIfExists(UIAQuery.CONTINUE_BUTTON);
            return true;
        } else if (springboard.exists(UIAQuery.AppStore.INSTALL_ALERT)) {
            if (springboard.exists(UIAQuery.AppStore.INSTALL_BUTTON)) {
                UIALogger.logMessage('Detected Install Button Alert');

                if (!paymentAuthorizationWaiter.wait(5)) {
                    throw new UIAError('Install button did not appear');
                }
                springboard.tap(UIAQuery.AppStore.INSTALL_BUTTON);
                UIALogger.logMessage('Handled Install Button Alert');

                if (springboard.exists(UIAQuery.staticTexts('Sign In with Apple ID'))) {
                    UIALogger.logMessage('Detected Password field Alert');
                    springboard.typeString(options.password);
                    springboard.tap(UIAQuery.buttons('Sign In'));
                    UIALogger.logMessage('Handled Password field Alert');

                }
                return true
            }
        }
        else if (appstore.exists(UIAQuery.AppStore.GET_ALERT)){
        	UIALogger.logMessage('Detected GET Alert');
        	appstore.tap(UIAQuery.alerts().andThen(UIAQuery.AppStore.GET_BUTTON));
        	UIALogger.logMessage('Handled GET Alert');
        	return true
        }
        return false;
    }

    appstore.withAlertHandler(handler, function() {
        if (!appstore.inspect(purchaseButton).identifiers.contains('Download')){
                UIALogger.logMessage('Have to tap the purchase button for the first time');
                appstore.tap(purchaseButton);
            }
        UIALogger.logMessage('waiting for Download button');
        if (!appstore.waitUntilPresent(UIAQuery.AppStore.DOWNLOADING_BUTTON, 30)) {
            // the possibility exists that we got here because the download happened extremely quickly
            if (appstore.inspect(UIAQuery.AppStore.PURCHASE_BUTTON).label != 'OPEN') {
                // oh, nevermind, go ahead and explode
                throw new UIAError('Failed to start downloading.');
            }
        }
    });

    appstore.waitForDownload(purchaseButton);
}

/**
* Select the desired application from the Search results view.
*
* @param {object} args - Test arguments
* @param {string} [args.appName='Pandora Radio'] - Exact name of the
* desired application, as shown in the App store.
* @param {string} [args.username='PERSISTEDAPPLEID'] - App Store ID
* @param {string} [args.password='PERSISTEDAPPLEIDPASSWORD'] - App Store password.
*/
appstore.selectSearchResult = function selectSearchResult(options) {
    var appIcon = UIAQuery.tableCells().beginsWith(options.appName);
    if (appstore.waitUntilPresent(appIcon, 10)) {
        UIALogger.logMessage('Found the app icon for ' + options.appName);
            appstore.tap(appIcon);
    } else {
        throw new UIAError('App icon for %0 was not found'.format(options.appName));
    }

    // this only appears once, so wait for it just in case
    this.waitUntilPresent(UIAQuery.buttons('Privacy Policy'), 30);
}

/**
* Open Categories on Featured Tab and get to the top Category Screen.
*
*/
appstore.getToCategoriesHomeInFeaturedTab = function getToCategoriesHomeInFeaturedTab() {
    appstore.exitVisiblePopovers();
    // IF we do not see the categories button, try to tap the categories button
    appstore.waitUntilPresent((UIAQuery.AppStore.CATEGORIES_BUTTON), 3);
    if (appstore.exists(UIAQuery.AppStore.CATEGORIES_BUTTON.isVisible())) {
        appstore.tap(UIAQuery.AppStore.CATEGORIES_BUTTON);
    }
    appstore.waitUntilPresent(UIAQuery.AppStore.BACK_BUTTON.isVisible(), 2);
    if (appstore.exists(UIAQuery.AppStore.BACK_BUTTON.isVisible())) {
        appstore.tap(UIAQuery.AppStore.BACK_BUTTON.isVisible());
    //iPhone
    }
    appstore.waitUntilPresent(UIAQuery.buttons('Back').isVisible(), 2);
    if (appstore.exists(UIAQuery.buttons('Back').isVisible())) {
        appstore.tap(UIAQuery.buttons('Back'));
    }
}

/**
* If popups are present, we will exit to the top screen
*
*/
appstore.exitVisiblePopovers = function exitVisiblePopovers() {
    appstore.waitUntilPresent(UIAQuery.AppStore.BACK_BUTTON.isVisible(), 2);
    if (appstore.exists(UIAQuery.AppStore.BACK_BUTTON.isVisible())) {
        appstore.tap(UIAQuery.AppStore.BACK_BUTTON.isVisible());
    //iPhone
    }

    appstore.waitUntilPresent(UIAQuery.buttons('Back').isVisible(), 2);
    if (appstore.exists(UIAQuery.buttons('Back').isVisible())) {
        appstore.tap(UIAQuery.buttons('Back'));
    }

    appstore.waitUntilPresent(UIAQuery.AppStore.CANCEL.isVisible(), 2);
    if (appstore.exists(UIAQuery.AppStore.CANCEL.isVisible())) {
        appstore.tap(UIAQuery.AppStore.CANCEL.isVisible());
    }
    return true;
}

/**
* Tap on selected category in categories popup on 'Featured' tab.
*
* @param {string} category - exact name of the category you want to tap on
*
*/
appstore.checkCategoryPageLoads = function checkCategoryPageLoads(category) {
    var currentUIMatchesCategory = false;
    if (category === appstore.currentUIState) {
        currentUIMatchesCategory = true;
    }
    // Get to top screen in Features tab
    appstore.getToCategoriesHomeInFeaturedTab();
    //Scroll to bottom - need to do twice because tap wants to
    // scroll up to seach for things out of view: rdar://problem/21794549
    if (UIATarget.localTarget().model()  === 'iPad') {
        appstore.swipeUp(UIAQuery.VISIBLE_POPOVERS);
        appstore.swipeUp(UIAQuery.VISIBLE_POPOVERS) ;
    } else {
        appstore.swipeUp('UILayoutContainerView');
        appstore.swipeUp('UILayoutContainerView');
    }
    // there is no title for the document loading
    var documentLoaded = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "SKUIStackDocumentViewController"');
    // tap on category
    appstore.tap(category);
    UIALogger.logMessage('Check if we are in a nested category.  Currently looking at category: ' + appstore.currentUIState());
    switch (category) {
        case UIStateDescription.AppStore.GAMES:
            appstore.tap('All Games');
            break;
        case UIStateDescription.AppStore.KIDS:
            appstore.tap('All Kids');
            break;
        case UIStateDescription.AppStore.NEWSSTAND:
            appstore.tap('All Newsstand');
            break;
        default:
            UIALogger.logMessage('We are not in a nested category ');
    }
    // If waiter does not return true within 10 seconds, the page did not load.
    if (!documentLoaded.wait(10)) {
        if (currentUIMatchesCategory) {
            UIALogger.logMessage('The UI did not change by selecting this category - we were already on this screen: ' + category);
        } else if (appstore.exists('In progress')) {
            throw new UIAError('App page never loaded - Loading screen was still up.');
        } else {
            UIALogger.logMessage('UI did not change. We probably loaded the screen super quick');
        }
    }
    if (!category === appstore.CurrentUIState) {
        UIALogger.logMessage('Current UI State =  ' + appstore.CurrentUIState);
        UIALogger.logMessage('Curretn Category = ' + category);
        throw new UIAError('Categories do not match for the current UI State');
    }
}

/**
* Launches the AppStore, makes sure UI popoups are out of the way, and navigates to the 'Featured' tab.
*/
appstore.cleanLaunch = function cleanLaunch() {
    appstore.launch();
    appstore.exitVisiblePopovers();
    appstore.getToTab(TABS.FEATURED);
}

/**
* Loads page associated with given tab and perform scroll up/down on page.
*/
appstore.verifyTabLoads = function verifyTabLoads(tab, options){
    var currentUIMatchesCategory = false;
    if (tab === appstore.currentUIState()) {
        currentUIMatchesCategory = true;
    }
    var documentLoaded = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "SKUIStackDocumentViewController"');
    UIALogger.logMessage('Navigate to %0 Tab '.format(tab));
    appstore.getToTab(tab, options);

    if (!documentLoaded.wait(10)) {
        if (currentUIMatchesCategory) {
            UIALogger.logMessage('The UI did not change by selecting this tab - we were already on this screen: ' + tab);
        } else if (appstore.exists('In progress')) {
            throw new UIAError('App page never loaded - Loading screen was still up.');
        } else {
            UIALogger.logMessage('UI did not change. We probably loaded the screen super quick');
        }
    }

    this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.1}, toOffset:{x:0.5, y:0.9}});
    this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.9}, toOffset:{x:0.5, y:0.1}});

    return true;
}

/**
* Goes Through each tab on the bottom, and fails if we get stuck on a 'loading...' screen
* Defaults goToTab to [noLaunch:true]
*/
appstore.verifyTabs = function verifyTabs() {
    options = {noLaunch: true}
    UIALogger.logMessage('Launch AppStore');
    this.launch();
    this.handleSplashScreen();
    if (appstore.storeUnavailable() && !appstore.exists('Sign In')) {
        throw new Error('Store is Not available at this time');
    }
    this.verifyTabLoads(TABS.GAMES, options);
    this.verifyTabLoads(TABS.APPS, options);
    this.verifyTabLoads(TABS.TODAY, options);
    this.verifyTabLoads(TABS.UPDATES, options);
    this.verifyTabLoads(TABS.SEARCH, options);
}
