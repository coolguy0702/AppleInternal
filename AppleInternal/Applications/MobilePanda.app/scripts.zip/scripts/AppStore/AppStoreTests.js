load('UIATesting.js');
load('AppStore.js');
load('SpringBoardTests.js')
UIAUtilities.assert(
    typeof AppStoreTests === 'undefined',
    'AppStore has already been defined.'
);

/**
* @namespace AppStoreTests
*/
var AppStoreTests = {
    /**
     * Launch App Store and Verify Tabs are present
     *
     * @targetApps Music
     * @param {object} args - Test arguments
     *
     * @alertHandlers appstore.allowAccessToLocationAlertHandler
     */
    verifyTabs: function verifyTabs(args) {
        appstore.verifyTabs();
    },

    /**
     * Search for an App In the Store
     *
     * @param {object} args - Test arguments
     * @param {string} [args.appSearchTitle="Pandora"] - Required Title of the App to search for (can be partial name)
     * @param {string} [args.appName="Pandora"] - Required name of the App to verify we found
     */
    searchForApp: function searchForApp(args) {
        args = UIAUtilities.defaults(args, {'appSearchTitle': 'Serial', 'appName': 'Serial'});
        appstore.launch();

        var getButton = appstore.searchForApp(args);
        if (getButton === null) {
            throw new UIAError('%0 app was not found'.format(args.appName));
        }

        return(getButton);
    },

    /**
     * Purchase an App In the Store, using Parsec as our entrypoint
     *
     * @param {object} args - Test arguments
     * @param {string} [args.appName="Yahoo Sports"] - Exact name of the app
     * @param {string} [args.searchString="Yahoo Sports"] - the search string to enter
     * @param {string} [args.resultQuery="Search App Store"] - query on something displayed as a result of the search
     * @param {string} [args.appToExpect="com.apple.AppStore"] - the app to expect after tapping on the result
     * @param {string} [args.username="PERSISTEDAPPLEID"] - App Store ID
     * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - App
     * Store password.
     */
    purchaseApp: function purchaseApp(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Yahoo Sports',
            username: 'PERSISTEDAPPLEID',
            password: 'PERSISTEDAPPLEIDPASSWORD',
            searchString:'Yahoo Sports',
            resultQuery:'Search App Store',
            appToExpect:'com.apple.AppStore'}
        );
        if (args.username === 'PERSISTEDAPPLEID') {
            args.username = springboard.appleID;
        }
        if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
            args.password = springboard.appleIDPassword;
        }
        SpringBoardTests.search(args);
        UIALogger.logMessage('Attempting to download app');
        appstore.selectSearchResult(args);
        appstore.downloadSelectedApp(args);
    },

    /**
     * Purchase an App In the Store, using a URL
     *
     * @param {object} args - Test arguments
     * @param {string} [args.url="https://itunes.apple.com/us/app/pandora-radio/id284035177?mt=8"] - Exact url of the
     * desired application
     * @param {string} [args.username="PERSISTEDAPPLEID"] - App Store ID
     * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - AppStore password.
     * @param {string} [args.appLoadingTime=60] - Time (in seconds) used as timeout when loading the app
     */
    purchaseAppThroughURL: function purchaseAppThroughURL(args) {
        args = UIAUtilities.defaults(args, {
            url: 'https://itunes.apple.com/us/app/pandora-radio/id284035177?mt=8', username: 'PERSISTEDAPPLEID',
            password: 'PERSISTEDAPPLEIDPASSWORD', appLoadingTime: 60}
        );
        if (args.username === 'PERSISTEDAPPLEID') {
            args.username = springboard.appleID;
        }
        if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
            args.password = springboard.appleIDPassword;
        }
        if (args.url === '') {
            throw new UIAError('Need a URL to download the app.')
        }
        appstore.purchaseAppThroughURL(args)
    },

    /**
     * Go through all the top level categories in Featured Tab.
     * @param {object} args -  Test arguments
     * @param {array} [args.category_array="DEFAULT_CATEGORIES"] - list of all current categories or "DEFAULT_CATEGORIES"
     */
    selectAllCategoriesInFeaturedTab: function selectAllCategoriesInFeaturedTab(args) {
        args = UIAUtilities.defaults(args, {
            category_array : 'DEFAULT_CATEGORIES',
        });

        if (!args.category_array instanceof Array) {
            args.category_array =  'DEFAULT_CATEGORIES';
        };

        if  (args.category_array ===  'DEFAULT_CATEGORIES') {
             args.category_array = [
            'Games',
            'All Categories',
            'Kids',
            'Newsstand',
            'Books',
            'Business',
            'Catalogs',
            'Education',
            'Entertainment',
            'Finance',
            'Food & Drink',
            'Health & Fitness',
            'Lifestyle',
            'Medical',
            'Music',
            'Navigation',
            'News',
            'Photo & Video',
            'Productivity',
            'Reference',
            'Social Networking',
            'Sports',
            'Travel',
            'Utilities',
            'Weather',
             ];
        }

        appstore.cleanLaunch();
        //loop through each category, and verify category loads
        for (i = 0; i < args.category_array.length; i++) {
            appstore.checkCategoryPageLoads(args.category_array[i]);
        }
     },

    /**
     * Search and download an App In the Store
     *
     * @param {object} args - Test arguments
     * @param {string} [args.appName="Yahoo Sport"] - Exact name of the app
     * @param {string} [args.resultQuery="Search App Store"] - query on something displayed as a result of the search
     * @param {string} [args.appToExpect="com.apple.AppStore"] - the app to expect after tapping on the result
     * @param {string} [args.username="osbq.dev8@icloud.com"] - App Store ID
     * @param {string} [args.password="Apple-1984"] - App Store password.
     *
     * @alertHandlers appstore.allowAccessToLocationAlertHandler
     */
    searchAndDownloadApp: function searchAndDownloadApp(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Yahoo Sport',
            username: 'osbq.dev8@icloud.com',
            password: 'Apple-1984',
            appToExpect:'com.apple.AppStore'}
        );

        appstore.launch();
        args.appSearchTitle = args.appName;        
        args.getButton = appstore.searchForApp(args);
        appstore.downloadSelectedApp(args);
    },
}
