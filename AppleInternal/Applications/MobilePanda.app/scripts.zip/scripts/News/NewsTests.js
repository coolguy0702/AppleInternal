load('UIATesting.js');
load('UIAApp.js');
load('News.js');

UIAUtilities.assert(
    typeof NewsTests === 'undefined',
    'NewsTests undefined'
);

var NewsTests = {
    /**
     * Verify can launch app and get to default news feed view
     *
     * @targetApps News
     *
     * @alertHandlers news.allowAccessToLocationAlertHandler
     */
    verifyLaunch: function verifyLaunch() {
        news.getToDefaultState();
    },

    /**
     * Verify some of the basic views in News app
     *
     * @targetApps News
     *
     * @alertHandlers news.allowAccessToLocationAlertHandler
     */
    verifyTabBarButtons: function verifyTabBarButtons() {
        news.getToSaved();
        news.getToHistory();
        news.getToDefaultState();
    },
}
