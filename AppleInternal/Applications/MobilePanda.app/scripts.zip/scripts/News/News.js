load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof news === 'undefined',
    'news undefined'
);

/**
*   @namespace {UIAApp} news
*/
var news = target.appWithBundleID('com.apple.news');

/** Constants for tabs - we should only need to change these in one place if UI Changes */
news.TabBarTitles = {
    /** 'Today' button within a TabBar */
    TODAY:                                       'Today',

    /** 'News_Plus' button within a TabBar */
    NEWS_PLUS:                                   'News+',

    /** 'Following' button within a TabBar */
    FOLLOWING:                                    'Following',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common News queries */
UIAQuery.News = {

    TabBarButtons: {
        /** 'Today' button within a TabBar */
        TODAY:                                    UIAQuery.tabBars().andThen(UIAQuery.buttons().contains(news.TabBarTitles.TODAY)),

        /** 'News_Plus' button within a TabBar */
        NEWS_PLUS:                                  UIAQuery.tabBars().andThen(UIAQuery.buttons().contains(news.TabBarTitles.NEWS_PLUS)),

        /** 'Following' button within a TabBar */
        FOLLOWING:                                  UIAQuery.tabBars().andThen(UIAQuery.buttons().contains(news.TabBarTitles.FOLLOWING)),
    },

    /**Today view */
    TODAY:                                      UIAQuery.navigationBars('TODAY').orElse(UIAQuery.query('Top Stories')),

    /** Welcome */
    WELCOME:                                    UIAQuery.contains('Welcome to').andThen(UIAQuery.contains('Apple News')),

    /** Sign up page */
    SIGNUP:                                     UIAQuery.contains('Get News').andThen(UIAQuery.contains('in Your Inbox')),

    /** Saved Stories */
    SAVED_STORIES:                              UIAQuery.navigationBars('Saved Stories'),

    /** History segmented control on the Saved page */
    HISTORY:                                    UIAQuery.staticTexts('HISTORY'),

    /** Clear History Button */
    CLEAR_HISTORY:                              UIAQuery.buttons('Clear History'),

    /** Following view */
    FOLLOWING:                                   UIAQuery.navigationBars('Following'),
    
    /** Add to favorites button */
    ADD_TO_FAVORITES:                           UIAQuery.buttons('Add to favorites'),

    /** Like Button */
    LIKE:                                       UIAQuery.buttons('Like').orElse(UIAQuery.buttons('Liked')),

    /** Save Button */
    SAVE:                                       UIAQuery.buttons('Unsaved').orElse(UIAQuery.buttons('Saved')),

    /** Title of an article */
    ARTICLE_TITLE:                              UIAQuery.query('Title').andThen(UIAQuery.staticTexts()),

    /** Article Source */
    ARTICLE_SOURCE:                             UIAQuery.navigationBars(),

    /** Article Intro */
    ARTICLE_INTRO:                              UIAQuery.query('Intro').andThen(UIAQuery.staticTexts()),

    /** All the Captions in the article */
    ARTICLE_CAPTIONS:                           UIAQuery.query('Caption').andThen(UIAQuery.staticTexts()),

    /** All the Quotes in the article */
    ARTICLE_QUOTES:                             UIAQuery.query('Quote').andThen(UIAQuery.staticTexts()),

    /** All the normal text in the article */
    ARTICLE_TEXT:                               UIAQuery.query('SXTextView').andThen(UIAQuery.staticTexts()),

    /** Button to open the Navigation Bar */
    NAVIGATION_BUTTON:                          UIAQuery.buttons('Table of Contents'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to News */
UIStateDescription.News = {
    /** Welcome page */
    WELCOME:                                    'welcome page',

    /** Today view */
    TODAY:                                      'today',

    /** Signup */
    SIGNUP:                                     'signup',

    /** Following */
    FOLLOWING:                                   'following',

    /** Search */
    SEARCH:                                     'search',

    /** Saved */
    SAVED_STORIES:                              'saved stories',

    /** Saved History */
    HISTORY:                                    'history',

    /** Introducing Notifications page */
    INTRO_NOTIFICATIONS:                        'introducing notifications',

    /** Whats New pages */
    WHATS_NEW:                                  "whats new",

    /** Unknown state */
    UNKNOWN:                                    "unknown state",
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
*  Constants for News
*/
news.Constants = {
    News:       	                         	'News',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.
* See News UIStateDescription constants for possible values.
* Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw
* if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in News UIStateDescription.
*
* UIStateDescription.News.UNKNOWN is returned for undefined state.
*
*/
news.getCurrentUIState = function getCurrentUIState() {
    this.launch();

    if (this.exists(UIAQuery.News.WELCOME)) {
        return UIStateDescription.News.WELCOME;
    }

    if (this.exists(UIAQuery.News.SIGNUP)) {
        return UIStateDescription.News.SIGNUP;
    }

    if (this.exists(UIAQuery.staticTexts('Introducing Notifications').isVisible())) {
        return UIStateDescription.News.INTRO_NOTIFICATIONS;
    }

    if (this.exists(UIAQuery.staticTexts().contains("What").isVisible())) {
        return UIStateDescription.News.WHATS_NEW;
    }

    if (this.exists(UIAQuery.News.TODAY)) {
        return UIStateDescription.News.TODAY;
    }

    if (this.exists(UIAQuery.News.HISTORY)) {
        return UIStateDescription.News.HISTORY;
    }

    if (this.exists(UIAQuery.News.SAVED_STORIES)) {
        return UIStateDescription.News.SAVED_STORIES;
    }

    if (this.exists(UIAQuery.News.FOLLOWING)) {
        return UIStateDescription.News.FOLLOWING;
    }


    return UIStateDescription.News.UNKNOWN;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigate to For You
*
* @throws throws if we don't make it
*/
news.getToDefaultState = function getToDefaultState() {
    this.launch();

    var maxDepth = 10;
    UIALogger.logMessage('Navigating to "%0" UI'.format(UIStateDescription.News.TODAY));

    this.returnToTopLevel();

    for (var i = 0; i < maxDepth; i++) {
        var currentState = this.getCurrentUIState();
        UIALogger.logMessage('Current state: "%0"'.format(currentState));

        if (currentState === UIStateDescription.News.TODAY) {
            return;
        }

        var waiter = UIAWaiter.waiter('ViewDidAppear');
        switch (currentState) {

            case UIStateDescription.News.HISTORY:
            case UIStateDescription.News.SAVED_STORIES:
                this.returnFromChannel(currentState);
                break;
            case UIStateDescription.News.FOLLOWING:
                if (this.tapIfExists(UIAQuery.News.TabBarButtons.TODAY)) {
                    break;
                } else {
                    if (this.tapIfExists(UIAQuery.News.NAVIGATION_BUTTON)) {
                        this.tapIfExists(UIAQuery.News.TabBarButtons.TODAY)
                        break;
                    }
                }
            case UIStateDescription.News.WELCOME:
                this.tapIfExists('Continue');
                break;
            case UIStateDescription.News.SIGNUP:
                this.tapIfExists('Not Now');
                break;
            case UIStateDescription.News.INTRO_NOTIFICATIONS:
                this.tapIfExists('Not Now');
                break;
            case UIStateDescription.News.WHATS_NEW:
                this.tapIfExists(UIAQuery.buttons('Next'));
                break;

            default:
                UIALogger.logMessage('Undefined state found: "%0"'.format(currentState)); 
        }
        waiter.wait(5);
    }

    currentState = this.getCurrentUIState();

    if (currentState !== UIStateDescription.News.FOR_YOU) {
        throw new UIAError('Could not get to "%0" UI from "%1" UI'.format(UIStateDescription.News.TODAY, currentState));
    }

}

news.returnFromChannel = function returnFromChannel(currentState) {
    switch (currentState) {
        case UIStateDescription.News.HISTORY:
        case UIStateDescription.News.SAVED_STORIES:
            if (this.exists(UIAQuery.buttons('Back'))) {
                this.tap(UIAQuery.buttons('Back'));
            } else {
                this.tap(UIAQuery.query('_UIButtonBarButton'));
                this.tap(UIAQuery.query('Today'));
            }
            break;
    }
}

news.tapSideBarButton = function tapSideBarButton() {
    this.drag(UIAQuery.application(),
        {fromOffset:{x:0.5, y:0.1}, toOffset:{x:0.5, y:0.999}, duration: 0.1});
    this.tap(UIAQuery.query('_UIButtonBarButton'));    
}

/**
 * Gets to the Saved UI State
 */
news.getToSaved = function getToSaved() {
	
    this.getToDefaultState();
    if (this.exists(UIAQuery.News.TabBarButtons.FOLLOWING)) { 
        this.tap(UIAQuery.News.TabBarButtons.FOLLOWING);
    } else {
        this.tapSideBarButton();
    }
    this.tap(UIAQuery.query('Saved Stories'));
    
}

/**
 * Gets to the History UI State
 */
news.getToHistory = function getToHistory() {
    this.getToDefaultState();
    if (this.exists(UIAQuery.News.TabBarButtons.FOLLOWING)) { 
        this.tap(UIAQuery.News.TabBarButtons.FOLLOWING);
    } else {
        this.tapSideBarButton();
    }
    this.tap(UIAQuery.query('History'));
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Choose you favorites when setting up news!
 *
 * @param  {object} options
 * @param  {int} [options.number=3] How many articles to select.
 * @param  {string[]} [options.sources=null] Array of Source titles to select: ['CNN', 'ESPN', 'NPR']
 *                                           (if this is specified then the numbers parameter is ignored)
 */
news.pickFavorites = function pickFavorites(options) {
	options = UIAUtilities.defaults(options, {
        number: 3,
        sources: null,
    });
    var orig = UIAQuery.scrollViews().children();
    if (Array.isArray(options.sources)) {
    	if (options.sources.length < 3) {
    		throw new UIAError('You must supply at least 3 sources');
    	}
    	for (var i = 1; i <= options.sources.length; i++) {
    		//var query = UIAQuery.scrollViews().children().andThen(UIAQuery.buttons().beginsWith(sources[i]));
    		var query = orig.andThen(UIAQuery.buttons().withPredicate('isSelected == false AND label BEGINSWITH "%0"'.format(options.sources[i-1])));
    		this.tapIfExists(query);
    	};
    } else {
    	var query = orig.andThen(UIAQuery.buttons().withPredicate('isSelected == false'));
    	for (var i = 1; i <= options.number; i++) {
    		this.tap(query);
    	};
    }
    this.tap('Continue');
}

/**
 * Clear your browsing history. Because everyone does that...
 */
news.clearHistory = function clearHistory() {
	this.getToHistory();
	if (this.exists(UIAQuery.tableViews('No History'))) {
		return;
	}
	var waiter = UIAWaiter.waiter('Alert');
	this.tap(UIAQuery.News.CLEAR_HISTORY);
	if (!waiter.wait(2)) {
		throw new UIAError('Clear History sheet did not open in time!');
	}
	this.tap(UIAQuery.News.CLEAR_HISTORY.isVisible());
}

/**
 * Tap on an article in a news feed
 *
 * @param  {object} options
 * @param  {bool} [options.unread=null] if null then we find any article, if true, only unread if false, only read
 * @param  {string} [options.article=null] Option article name/description (partial)
 */
news.tapArticle = function tapArticle(options) {
	options = UIAUtilities.defaults(options, {
        unread: null,
        article: null,
    });

    var query = this._getArticleQuery(options);
    this.tap(query);
}

/**
 * Save an article
 *
 * @param  {bool} save (Optional) if `false` unsave article, if `null` or `true` save the article
 *
 * @throws If we can't find the save button or if the label of the save button is something we don't expect
 */
news.saveArticle = function saveArticle(save) {
	var button = UIAQuery.News.SAVE;
	var status = this.inspect(button);
    if (!status) {
        throw new UIAError('Unable to find Save button!');
    }
	if (status.isVisible === false) {
		UIALogger.logMessage('Save button not visible, scrolling up');
		this.dragDownInside('SXScrollView', {flick: true, duration: 1});
	}
	if (status.label === 'Unsaved' && save !== false) {
		this.tap(button);
	} else if (status.label === 'Saved' && save === false) {
		this.tap(button);
	} else {
        throw new UIAError('Unknown label on save button: %0'.format(status.label));
    }
}

/**
 * Whether or not an article is saved or not.
 *
 * @return {Boolean}
 *
 * @throws If we can't find the save button
 */
news.isSaved = function isSaved() {
	var button = UIAQuery.News.SAVE;
	var status = this.inspectElementKey(button, 'label');
	if (status === 'Unsaved') {
		return false;
	}
	return true;
}

/**
 * Like an article
 *
 * @param  {bool} save (Optional) if `false` unlike article, if `null` or `true` like the article
 *
 * @throws If we can't find the like button or it has a label we don't expect
 */
news.likeArticle = function likeArticle(like) {
	var button = UIAQuery.News.LIKE;
	var status = this.inspect(button);
    if (!status) {
        throw new UIAError('Unable to find Like button!');
    }
	if (status.isVisible === false) {
		UIALogger.logMessage('Like button not visible, scrolling up');
		this.dragDownInside('SXScrollView', {flick: true, duration: 1});
	}
	if (status.label === 'Like' && like !== false) {
		this.tap(button);
	} else if (status.label === 'Liked' && like === false) {
		this.tap(button);
	} else {
        throw new UIAError('Unknown lavel on save button: %0'.format(status.label));
    }
}

/**
 * Whether an article is liked or not.
 *
 * @return {Boolean}
 *
 * @throws If we can't find the Like button
 */
news.isLiked = function isLiked() {
	var button = UIAQuery.News.LIKE;
	var status = this.inspectElementKey(button, 'label');
	if (status === 'Like') {
		return false;
	}
	return true;
}

/**
 * Get the source for the article
 *
 * @return {string}
 *
 * @throws If we can't find the element we get the source from
 */
news.getArticleSource = function getArticleSource() {
	return this.inspectElementKey(UIAQuery.News.ARTICLE_SOURCE, 'label');
}

/**
 * While in an article, swipe to the next article
 */
news.swipeToNextArticle = function swipeToNextArticle() {
    var query = UIAQuery.scrollViews().isVisible();
    this.drag(query, {toOffset: {x: 0.85, y: 0.10}, fromOffset: {x: 0.15, y: 0.11}, duration: 0.50, flick: 1});
}

/**
 * While in an article, swipe to the previous article
 */
news.swipeToPreviousArticle = function swipeToPreviousArticle() {
    var query = UIAQuery.scrollViews().isVisible();
    this.drag(query, {fromOffset: {x: 0.85, y: 0.10}, toOffset: {x: 0.15, y: 0.11}, duration: 0.50, flick: 1});
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Verify tab bar button and associated destination view exists from main news feed view 
 *
 * @param  {string} buttonQuery - UIAQuery expression to locate tab bar button
 * @param  {string} buttonName - button text
 * @param  {string} viewQuery - UIAQuery expression to validate associated view 
 */
news.verifyTabBarButton = function verifyTabBarButton(buttonQuery,buttonName,viewQuery) {
    if (!news.exists(buttonQuery)) {
        throw new UIAError('Missing "%0" button in default news feed view'.format(buttonName));
    } else {
        news.tap(buttonQuery);
        if (!news.exists(viewQuery)) {
            throw new UIAError('Missing "%0" view?'.format(buttonName));
        }
    }
}

/**
 * Swipe to delete an article from the history or saved
 *
 * @param  {UIAQuery} query Query from {@link news#_getArticleQuery}
 * @param  {bool} tap   whether or not we should tap to delete or just swipe
 *
 * @throws If the item is not deleted.
 */
news._swipeToDelete = function _swipeToDelete(query, tap) {
    if (!this.exists(query)) {
        throw new UIAError('Query returned no valid results!');
    }
    this.scrollToVisible(query);
    var label = this.inspect(query).label;

    // this doesn't actually work due to:
    // <rdar://problem/22405132> UIA2: Running UIAApp.count() has a side effect on the UI in News
    var tap = false;
    if (tap) {
        // this doesn't actually work due to:
        // <rdar://problem/22405132> UIA2: Running UIAApp.count() has a side effect on the UI in News
        this.drag(query, {fromOffset: {x: 0.85, y: 0.50}, toOffset: {x: 0.45, y: 0.50}, flick: 1, duration: 1.00});
        this.tap(UIAQuery.buttons('Delete').isVisible());
    } else {
        this.dragLeftInside(query);
    }
    if (this.exists(label)) {
        throw new UIAError('Item "%0" was not deleted!'.format(label));
    }
}

/**
 * Get a {@link UIAQuery} for an article
 *
 * @param  {object} options
 * @param  {bool} [options.unread=null] if null then we find any article, if true, only unread if false, only read
 * @param  {string} [options.article=null] Option article name/description (partial)
 *
 * @return {UIAQuery}
 *
 * @throws If we are in a UI State that isn't supported
 */
news._getArticleQuery = function _getArticleQuery(options) {
        options = UIAUtilities.defaults(options, {
        unread: null,
        article: null,
    });
    var state = this.getCurrentUIState();
    
    switch (state) {
        case UIStateDescription.News.FOR_YOU:
            var pred = 'label != UICollectionViewCellAccessibilityElement';
            if (options.unread !== null) {
                if (options.unread && options.unread != 'false') {
                    pred += ' AND label BEGINSWITH "Unread,"';
                } else {
                    pred += ' AND NOT (label BEGINSWITH "Unread,")';
                }
            }

            if (options.article !== null) {
                pred += ' AND label CONTAINS "%0"'.format(options.article);
            }
            var q = UIAQuery.collectionViews('FRFeedCollectionView');
            q = q.andThen(UIAQuery.tableCells().withPredicate(pred));
            return q;

        case UIStateDescription.News.HISTORY:
        case UIStateDescription.News.SAVED_STORIES:
           var pred = '';
           if (options.article !== null) {
               pred += 'ANY children.label CONTAINS "%0"'.format(options.article);
           }
           var q = UIAQuery.tableViews('FRFeedTableView');
           var q2 = UIAQuery.tableCells();
           if (pred.length) {
               q2 = q2.withPredicate(pred);
           }
           q = q.andThen(q2);
           return q;

        default:
            throw new UIAError('Unable to tap article in the current state');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Assertions                                                          */
/*                                                                             */
/*      Functions that perform validations and throw UIAErrors                 */
/*      These are App specific assertions only                                 */
/*                                                                             */
/*******************************************************************************/

/**
* Asserts that an item from a query is selected
*
* @param  {UIAQuery} query - Query to inspect
* @param  {string} message - message to throw if the assertion fails
*
* @throws Throws if the item is not selected
*/
news.assertSelected = function assertSelected(query, message) {
    UIAUtilities.assertEqual(
        this.inspect(query).isSelected,
        true,
        message
    );
}

/**
 * Gets to the FOLLOWING UI State
 */
news.getToFollowing = function getToFollowing() {
	this.getToDefaultState();
    if (this.exists(UIAQuery.News.TabBarButtons.FOLLOWING)) {
        this.tap(UIAQuery.News.TabBarButtons.FOLLOWING);
    }
}