load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof stocks === 'undefined',
    'stocks undefined'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common stocks queries */
UIAQuery.Stocks = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Stocks */
UIStateDescription.Stocks = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

//Need list of constants to map from x or * to MULTIPLY

/**
    @namespace
    @augments UIAApp
*/
var stocks = target.appWithBundleID('com.apple.stocks');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Stocks for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
stocks.currentUIState = function currentUIState() {
    throw new UIAError('Not yet implemented.');
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/



/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation.                                         */
/*      Other helper functions.                                                */
/*                                                                             */
/*******************************************************************************/


/**
 * Navigation control. Gets to top level of app.
 */
stocks.getToAppTopLevel = function getToAppTopLevel() {
    this.launch();
}

