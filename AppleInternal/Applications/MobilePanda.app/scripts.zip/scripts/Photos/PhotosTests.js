
load("UIATesting.js");
load("SpringBoard.js");
load("Camera.js");
load("Photos.js");
load("Settings.js");

if (typeof PhotosTests !== 'undefined') {
    throw new UIAError("Namespace 'PhotosTests' has already been defined.");
}

/**
 * @namespace PhotosTests
 */
var PhotosTests = {

    /**
     * Deletes all in Recently Deleted
     *
     * @targetApps MobileSlideShow
     * 
     */
    deleteAllRecentlyDeleted: function deleteAllRecentlyDeleted() {
        photos.launch();
        photos.getToCollectionInView("Recently Deleted", "Albums");
        photos.deleteAllRecentlyDeleted();
    },

    /**
     * Scrolls through an album. Does not select any pictures, just
     * scrolls up and down.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName=null] - The name of the photo collection to scroll through.
     */
    scrollThroughAlbum: function scrollThroughAlbum(args) {
        args = UIAUtilities.defaults(args, {
            viewName: "Albums",
            collectionName: null,
        });

        var id = {predicate: 'TRUEPREDICATE'};

        if (!args.collectionName || args.collectionName.length < 1) {
            UIALogger.logDebug("No collection name was specified. Choosing one at random.");
            photos.launch();
            args.collectionName = photos.randomCollectionNameFromView(args.viewName);
        }

        photos.getToCollectionInView(args.collectionName, args.viewName);
        photos.scrollPhotoCollection();
    },


    /**
     * Swipes through images in an album in 1UP view. Can go left and right
     * based on the starting and ending index.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName=null] - The name of the photo collection to scroll through.
     * @param {boolean} [args.liveSwipe=false] - Do we play dynamic assets when we see them?
     * @param {int} [args.secondsToLiveInteract=4] - Seconds that we spend 'playing' an asset.
     * @param {int} [args.startIndex=0] - Index of the first image we will view. (Stays within photo count range)
     * @param {int} [args.endIndex=20] - Index of the last image we will view. (Stays within photo count range)
     */
    swipeThroughPhotosInAlbum: function swipeThroughPhotosInAlbum(args) {
        args = UIAUtilities.defaults(args, {
            viewName: "Albums",
            collectionName: null,
            liveSwipe: false,
            secondsToLiveInteract: 4,
            startIndex: 0,
            endIndex: 20, 
        });

        if (!args.collectionName || args.collectionName.length < 1) {
            UIALogger.logDebug("No collection name was specified. Choosing to go to Camera Roll.");
            photos.launch();
            args.collectionName = photos.getCollectionNameFromView(args.viewName,0);
        }

        photos.getToCollectionInView(args.collectionName, args.viewName);

        // Count the number of assets to swipe through
        var thumbnailCount = photos.numberOfThumbnails();
        var assets = photos.inspect(UIAQuery.collectionViews("PUCollectionView")).children;
        UIALogger.logDebug("Number of thumbnails before swiping through the assets is [" + thumbnailCount + "]");

        // Change the swipe based on if we're going right-to-left or left-to-right
        if (thumbnailCount === 0) {
            throw new UIAError("Collection does not contain photos");
        }

        var imageQuery = UIAQuery.PHOTOS_THUMBNAILS;
        var collectionView = UIAQuery.navigationBars(args.collectionName);
        var loadedImageView = UIAQuery.Photos.ONE_UP_VIEW;

        // Verify we are in the collection detail view
        photos.waitUntilPresent(collectionView);
        UIAUtilities.assert(photos.exists(collectionView), "Cannot select album photo because collection view doesn't exist");

        // Select the starting and end indices
        var start = args.startIndex;
        var end = args.endIndex;
        var goingRight = true;
        if (start < 0) {
            start = 0;
        } else if (start > thumbnailCount-1) {
            start = thumbnailCount-1;
        }
        if (end < 0) {
            end = 0;
        } else if (end > thumbnailCount-1) {
            end = thumbnailCount-1;
        }
        if (start > end) {
            goingRight = false;
        }
        var count = Math.abs(end - start) + 1;
        var index = start;

        // Load the starting image
        UIALogger.logMessage("Loading image at index: " + index);
        photos.scrollToVisible(imageQuery.atIndex(index));
        photos.tap(imageQuery.atIndex(index));

        photos.waitUntilPresent(loadedImageView, 10);
        UIAUtilities.assert(photos.exists(loadedImageView), "Did not successfully load image");

        // Do the actions for at least one item before quitting
        for (var i = 0; i < count; i++) {
            photos.tapIfExists(UIAQuery.buttons('Got It'));
            
            UIALogger.logMessage("[" + index + "]: According to the thumbnails, this asset is of media type: " + assets[index].label);
            if (args.liveSwipe) {
                // Interact depending on the type of media
                if (assets[index].label.contains("ideo")) { // Video
                    UIAUtilities.assert(photos.exists(UIAQuery.buttons('Play video')), "This asset should be a video, but lacks a play button!");
                    photos.tap(UIAQuery.buttons('Play video'));
                    target.delay(args.secondsToLiveInteract);
                } else if (assets[index].label.contains("Live")) { // Iris Photo
                    // This query just pulls out a label and checks if it has 'Live' in it.
                    UIAUtilities.assert(photos.inspect(UIAQuery.scrollViews('PUTilingView').andThen(UIAQuery.images().withPredicate('label != NULL')))
                        .label.contains("Live"), "This asset should be an Iris photo, but isn't labeled as such!");
                    // Change to "photos.tap(UIAQuery.application(), {duration: 4});" for non-Orb devices
                    photos.touchForPopGesture(UIAQuery.application());
                }
            }
            if (index !== end) {
                if (goingRight) {
                    photos.swipeLeft(UIAQuery.application());
                    index++;
                } else {
                    photos.swipeRight(UIAQuery.application());
                    index--;
                }
            }
        }

        // Get back to detail view
        if (!photos.exists(UIAQuery.BACK_NAV_BUTTON)) {
            photos.tap(UIAQuery.application(), {offset: {x: 0.5, y: 0.25}});
        }
        photos.exitPhotoView();
    },


    /**
     * Edits a photo.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.editType="filter"] - Name edit type to apply to the picture(s).
     * @param {string} [args.editTypeDetail="Mono"] - Sub-selection of the edit type to apply.
     * @param {int} [args.count=1] - Number of pictures to edit.
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName=null] - The name of the photo collection to edit a photo in. Random if null.
     * @param {boolean} [args.requireMinimumPhotoCount=false] - require a selected album to have at least MIN_PHOTO_COUNT number of photos

     */
    editPhoto: function editPhoto(args) {
        args = UIAUtilities.defaults(args, {
            editType: "filter",
            editTypeDetail: "Mono",
            count: 1,
            viewName: "Albums",
            collectionName: null,
            requireMinimumPhotoCount: false,
        });

        var id = {predicate: 'TRUEPREDICATE'};

        if (!args.collectionName || args.collectionName.length < 1) {
            UIALogger.logDebug("No collection name was specified. Choosing one at random.");
            photos.launch();
            args.collectionName = photos.randomCollectionNameFromView(args.viewName);
        }

        photos.getToCollectionInView(args.collectionName, args.viewName);
        photos.tap(UIAQuery.PHOTOS_PHOTO_THUMBNAILS.any());
        photos.editPhoto();
    },


    /**
     * Views pictures in an album.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName="All Photos"] - The name of the photo collection to scroll through.
     * @param {int} [args.numberOfPhotosToView=5] - Number of photos to view.
     */
    viewPicturesInAlbum: function viewPicturesInAlbum(args) {
        args = UIAUtilities.defaults(args, {
            viewName: "Albums",
            collectionName: "All Photos",
            numberOfPhotosToView: 5,
        });

        var id = {predicate: 'TRUEPREDICATE'};

        if (!args.collectionName || args.collectionName.length < 1) {
            UIALogger.logDebug("No collection name was specified. Choosing first in view");
            photos.launch();
            args.collectionName = photos.getCollectionNameFromView(args.viewName,0);
        }

        photos.getToCollectionInView(args.collectionName, args.viewName);

        var imageQuery = UIAQuery.PHOTOS_PHOTO_THUMBNAILS;
        var collectionImagerCount = photos.count(imageQuery);
        if (collectionImagerCount === 0) {
            throw new UIAError("Collection does not contain photos");
        }

        var collectionView = UIAQuery.navigationBars(args.collectionName);
        var loadedImageView = UIAQuery.Photos.ONE_UP_VIEW;

        for (var i = 0; i < args.numberOfPhotosToView; i++) {
            // Verify we are in the collection detail view
            photos.waitUntilPresent(collectionView);
            UIAUtilities.assert(photos.exists(collectionView), "Cannot select album photo because collection view doesn't exist");

            // Select any image
            var numberOfImages = photos.count(imageQuery);
            var index = UIAUtilities.randomInt(0, numberOfImages-1);

            UIALogger.logMessage("Loading image at index: " + index);
            photos.scrollToVisible(imageQuery.atIndex(index));
            photos.tap(imageQuery.atIndex(index));

            photos.waitUntilPresent(loadedImageView, 10);
            UIAUtilities.assert(photos.exists(loadedImageView), "Did not successfully load image");

            // Get back to detail view
            photos.exitPhotoView();
        }
    },

    /**
     * Emails a photo.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.recipient="weliketesting@me.com"] - The email address to send the photo to.
     * @param {string} [args.subject="Where's Chuck?"] - The subject line for the email.
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName=null] - The name of the photo collection to send a photo from.
     */
    emailPhoto: function emailPhoto(args) {
        args = UIAUtilities.defaults(args, {
            recipient: "weliketesting@me.com",
            subject: "Where's Chuck?",
            viewName: "Albums",
            collectionName: null,
        });

        var id = {predicate: 'TRUEPREDICATE'};

        if (!args.collectionName || args.collectionName.length < 1) {
            UIALogger.logDebug("No collection name was specified. Choosing one at random.");
            photos.launch();
            args.collectionName = photos.randomCollectionNameFromView(args.viewName);
        }

        photos.getToCollectionInView(args.collectionName, args.viewName);

        UIALogger.logDebug("Selecting a random photo.");
        photos.tap(UIAQuery.PHOTOS_PHOTO_THUMBNAILS.any());

        // TODO: put these into a method called "performShareActionWithName"
        photos.waitUntilReady();
        photos.tap(UIAQuery.buttons("Share"));
        photos.tap(UIAQuery.SHARE_SHEET.andThen("Mail"));

        photos.composeEmail(args.recipient, args);
    },

};
