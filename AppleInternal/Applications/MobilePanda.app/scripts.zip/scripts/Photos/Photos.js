load('UIAApp.js');
load('UIAApp+Photos.js');
load("UIAApp+Mail.js");
load('SpringBoard.js');

if (typeof photos === 'undefined') {
    /**
        @namespace
        @augments UIAApp
    */
    var photos = target.appWithBundleID('com.apple.mobileslideshow');

    // Minumum # of photos required to scroll the photo table view
    if (UIATarget.localTarget().model() != 'iPad') {
        photos.MIN_PHOTO_COUNT = 25;
    } else {
        photos.MIN_PHOTO_COUNT = 40;
    }
}

/**
 * @namespace
 */
UIAQuery.Photos = {
        SELECT_BUTTON: UIAQuery.buttons('Select'),
        DELETE_ALL_BUTTON: UIAQuery.buttons('Delete All'),
        DELETE_ALL_CONFIRMATION_BUTTON: UIAQuery.contains('Delete').isVisible(),
        EXPLORE_MODAL: UIAQuery.contains('Explore'),
        GOT_IT_BUTTON: UIAQuery.buttons('Got It'),
        PHOTOS_SPLASH_SCREEN: UIAQuery.staticTexts().andThen(UIAQuery.contains('What’s New')),
        ONE_UP_VIEW: UIAQuery.scrollViews('OneUpMainPagingView'),
};

/**
 * Deletes all in Recently Deleted
 * 
 *
 **/
photos.deleteAllRecentlyDeleted = function deleteAllRecentlyDeleted() {
    this.tap(UIAQuery.Photos.SELECT_BUTTON);
    this.tap(UIAQuery.Photos.DELETE_ALL_BUTTON);
    this.tap(UIAQuery.Photos.DELETE_ALL_CONFIRMATION_BUTTON);
}


/**
 * Returns to the top-most view in the Photos view hierarchy and selects a tab in
 * the tab bar with the specified name.  By default, this will navigate to the
 * Albums tab on iPhone and Photos tab on iPad
 *
 *  @param {string} viewName - name of the view to select (if available)
 *                       Photos
 *                       Albums
 *                       Shared
 *
 **/
photos.getToViewNamed = function getToViewNamed(viewName) {

    if (!viewName) {
        if (target.model() == "iPad") {
            viewName = "Photos";
        } else {
            viewName = "Albums";
        }
    }

    if (this.exists("PUCloudPhotoWelcomeView")) {
        UIALogger.logMessage("New window asking to use iCloud Photos.");
        this.tap(UIAQuery.buttons("Not Now"));
    }

    if (this.exists(UIAQuery.Photos.EXPLORE_MODAL)) {
        UIALogger.logMessage('"Explore" modal dialog is appearing over Photos.');
        this.tap(UIAQuery.Photos.GOT_IT_BUTTON);
    }

    this.returnToTopLevel({leftButtonsToAvoid:["Add","Share"]});

    var viewButton = UIAQuery.tabBars().isVisible().andThen(viewName);
    if (!this.waitUntilPresent(viewButton, 1)) {
        throw new UIAError("View '%0' does not exist in tabbar".format(viewName));
    }
    this.tap(viewButton);

    this.returnToTopLevel({leftButtonsToAvoid:["Add","Share"]});
}


/**
 * Selects an album/event/Faces with the name specified from a specified view.
 *
 *  @param {string} collectionName - name of the collection to select
 *  @param {string} viewName - name of the tab the collection should be in
 **/
photos.getToCollectionInView = function getToCollectionInView(collectionName, viewName) {
    this.launch();

    // the splash screen may take several seconds to appear, so we should try to anticipate it
    var splashScreenTimeout = 5;
    UIALogger.logMessage('Waiting %0 seconds to see if the splash screen appears'.format(splashScreenTimeout));
    this.waitUntilPresent(UIAQuery.Photos.PHOTOS_SPLASH_SCREEN, splashScreenTimeout);
    if (this.exists(UIAQuery.Photos.PHOTOS_SPLASH_SCREEN)) {
        this.tap(UIAQuery.CONTINUE_BUTTON);
    }

    UIALogger.logMessage("Searching for collection: '" + collectionName + "' in '" + viewName + "' view.");

    var collection = UIAQuery.navigationBars(collectionName).isVisible();
    if (this.exists(collection)) {
        UIALogger.logMessage("Already in the '" + collectionName + "' album");
        return;
    }
    UIALogger.logDebug("Going to the view named " + viewName);
    this.getToViewNamed(viewName);

    UIALogger.logDebug("Tapping on the collection named " + collectionName);
    this.tap(UIAQuery.beginsWith(collectionName));
}
/**
 * Launches Photos and handles the splash page if present
 **/
photos.launch = function launch() {
     this.__proto__.launch.apply(this);
     this.tapIfExists(UIAQuery.PHOTOS_WHATS_NEW_CONTINUE_BUTTON)
}

/**
 * Selects an album/event/Faces with the name specified from a specified view.
 *
 * @param {string} viewName - name of the tab the collection should be in
 * @param {object} options Optional arguments
 * @param {boolean} [options.requireMinimumPhotoCount=false] - require a selected album to have at least MIN_PHOTO_COUNT number of photos
 **/
photos.randomCollectionNameFromView = function randomCollectionNameFromView(viewName, options) {
    options = UIAUtilities.defaults(options, {
        requireMinimumPhotoCount: false,
    });

    if (options.requireMinimumPhotoCount) {
        throw new UIAError("Minimum photo count feature not yet implemented.");
    }

    UIALogger.logMessage("Getting the name for a random collection in the '" + viewName + "' view.");

    UIALogger.logDebug("Going to the view named " + viewName);
    this.getToViewNamed(viewName);

    // TODO: Replace this with better syntax once the following is resolved:
    //       <rdar://problem/18448522> UIA2 ER: get a random element that matches a query

    var info = this.inspect(UIAQuery.tableCells().withPredicate("name != 'Recently Deleted' AND name != 'Videos'").any());
    return info ? info.name : null;
}

/**
 * Selects a collection name from a specified view and index
 *
 * @param {string} viewName - name of the tab the collection should be in
 * @param {number} index    - TableCell index to use
 *
 * @returns {string} - name of collection otherwise null if none found
 *
 **/
photos.getCollectionNameFromView = function getCollectionNameFromView(viewName, index) {

    UIALogger.logMessage('Getting the name for a collection in the %0 view at index: %1'.format(viewName, index));

    this.getToViewNamed(viewName);
    var info = this.inspect(UIAQuery.tableCells().atIndex(index).children());
    return info ? info.name : null;
}

/**
 *       Function: chooseLastPhotoOrVideoInCurrentAlbum
 *           This method assumes the device is now in an album and ready to pick the last photo/video in that album
 *
 *  @param None
 *
 *  @returns none
 **/
photos.chooseLastPhotoOrVideoInCurrentAlbum = function chooseLastPhotoOrVideoInCurrentAlbum(){

    var thumnailCount = this.numberOfThumbnails();

    if (thumnailCount < 1) {
        throw new UIAError("Cannot choose a photo. Current album is empty.");
    }

    this.tap(this.thumbnails().last());

    if (!this.exists(UIAQuery.PHOTO_BROWSER_TITLE.isVisible())) {
        throw new UIAError("We should be on the photo detail view but we aren't.");
    }
}
