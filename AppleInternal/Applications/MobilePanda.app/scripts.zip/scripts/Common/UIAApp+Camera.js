
load('UIAApp.js');

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Localization Strings                                                           */
/*                                                                                        */
/*      A dictionary of localization look up strings                                      */
/*                                                                                        */
/******************************************************************************************/

/** Use Photo Button */
LocStrings.USE_PHOTO =  target.localizedString('USE_PHOTO', {
                        tableName:'CameraUI',
                        bundlePath:'/MobileSlideShow-2941/Projects/CameraUI/Resources',
                        });

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Query Constants                                                                */
/*                                                                                        */
/*      App specific queries that will be used frequently                                 */
/*                                                                                        */
/******************************************************************************************/

UIAQuery.CAMERA_VIEWFINDER = UIAQuery.buttons('Viewfinder');

UIAQuery.CAMERA_NOT_READY = UIAQuery.query('CAMSnapshotView');

/** Button for changing camera modes */
UIAQuery.CAMERA_MODE = UIAQuery.query("CameraMode");

/** Capture button */
/** The orElse is here because of <rdar://problem/25120374> Label of camera button changes after opening camera app. */
UIAQuery.CAMERA_CAPTURE_BUTTON = UIAQuery.buttons().endsWith('Capture').orElse(UIAQuery.buttons('CUShutterButton').orElse(UIAQuery.buttons('PhotoCapture')));

/** Video capture button */
UIAQuery.CAMERA_VIDEO_CAPTURE_BUTTON = UIAQuery.buttons('VideoCapture');

/** Slomo capture button */
UIAQuery.CAMERA_SLOMO_CAPTURE_BUTTON = UIAQuery.buttons('SlomoCapture');

/** Video capture elapsed time */
UIAQuery.CAMERA_VIDEO_ELAPSED_TIME = UIAQuery.query("CAMModeDialItem");

/** Retake button */
UIAQuery.CAMERA_RETAKE_BUTTON = UIAQuery.buttons('Retake');

/** Button that begins with 'Use' in camera */
UIAQuery.CAMERA_USE_BUTTON = UIAQuery.buttons().beginsWith('Use');

/** Button that begins with 'Choose' in camera */
UIAQuery.CAMERA_CHOOSE_BUTTON = UIAQuery.buttons().beginsWith('Choose');

/** Camera play button */
UIAQuery.CAMERA_PLAY_BUTTON = UIAQuery.buttons('Play');

/** Camera pause button */
UIAQuery.CAMERA_PAUSE_BUTTON = UIAQuery.buttons('Pause');

/** Button for switching between front and back facing camera */
UIAQuery.CAMERA_FRONT_BACK_FACING_BUTTON = UIAQuery.buttons('FrontBackFacingCameraChooser');

/** Camera flash mode button */
UIAQuery.CAMERA_FLASH = UIAQuery.query('Flash');

/** Camera flash 'on' selection  */
UIAQuery.CAMERA_FLASH_ON = UIAQuery.CAMERA_FLASH.andThen('On');

/** Camera flash 'off' selection  */
UIAQuery.CAMERA_FLASH_OFF = UIAQuery.CAMERA_FLASH.andThen('Off');

/** Camera flash 'auto' selection  */
UIAQuery.CAMERA_FLASH_AUTO = UIAQuery.CAMERA_FLASH.andThen('Auto');

/** Camera HDR mode button */
UIAQuery.CAMERA_HDR = UIAQuery.query('HDR');

/** Camera HDR 'on' selection  */
UIAQuery.CAMERA_FLASH_ON = UIAQuery.CAMERA_HDR.andThen('On');

/** Camera HDR 'off' selection  */
UIAQuery.CAMERA_FLASH_OFF = UIAQuery.CAMERA_HDR.andThen('Off');

/** Camera Iris mode button */
UIAQuery.CAMERA_IRIS = UIAQuery.query('Iris');

/** Camera filters button */
UIAQuery.CAMERA_FILTERS = UIAQuery.query('Filters');

/** Camera lighting indicator */
UIAQuery.CAMERA_LIGHTING = UIAQuery.query('Lighting');

/** All Photos button in Camera Roll */
UIAQuery.ALL_PHOTOS = UIAQuery.buttons('All Photos');

/** Button that opens the camera to take a picture to send in a message */
UIAQuery.OPEN_CAMERA_BUTTON = UIAQuery.query('AXExplorerViewControllerScrollView').andThen(UIAQuery.buttons('Camera'));

/** Button that opens the photo library to add a picture to send in a message */
UIAQuery.PHOTO_LIRBARY_BUTTON = UIAQuery.buttons('Photo Library');

/** Element containing the camera filters shown to user */
UIAQuery.CAMERA_FILTER_SCRUBBER = UIAQuery.query("CAMFilterScrubberView");

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Other Constants                                                                */
/*                                                                                        */
/*      Any other app specific constants                                                  */
/*                                                                                        */
/******************************************************************************************/

// this list needs to be maintained to match the order in the UI
CameraMode = {
    TIMELAPSE:'time-lapse',
    SLOMO:'slo-mo',
    VIDEO:'video',
    PHOTO:'photo',
    PORTRAIT:'portrait',
    SQUARE:'square',
    PANO:'pano',
}

CameraFacingMode = {
    FRONT: "Front facing",
    BACK: "Back facing",
}

CameraHDRMode = {
    AUTO: "Auto",
    OFF: "Off",
    ON: "On",
}

CameraFlashMode = {
    AUTO: "Auto",
    OFF: "Off",
    ON: "On",
}

VideoButtonLabel = {
    STOP: 'Stop Recording Video',
}

CameraCapability = {
    supportsVideo: target.hasCapability('video-camera'),
    supportsSloMo: target.hasCapability('RearFacingCameraHFRCapability'),
    supportsPano:  target.hasCapability('PanoramaCameraCapability'),
    hasFrontFacingCamera: target.hasCapability('front-facing-camera'),
    /* HDR Modes Front Camera */
    supportsRFCHDR: target.hasCapability('RearFacingCameraHDRCapability'),
    supportsRFCHDRAuto: target.hasCapability('RearFacingCameraAutoHDRCapability'),
    supportsRFCHDROn: target.hasCapability('RearFacingCameraHDROnCapability'),
    /* HDR Modes Rear Camera */
    supportsFFCHDR: target.hasCapability('FrontFacingCameraHDRCapability'),
    supportsFFCHDRAuto: target.hasCapability('FrontFacingCameraAutoHDRCapability'),
    supportsFFCHDROn: target.hasCapability('FrontFacingCameraHDROnCapability'),
    /* Iris */
    supportsIris: target.hasCapability('SupportsIrisCapture'),
    /* Portrait modes */
    supportsRFCPortrait: target.hasCapability('DeviceHasAggregateCamera'),
    /* Flash caps */
    supportsRFCFlash: target.hasCapability('camera-flash'),
    supportsFFCFlash: target.hasCapability('camera-front-flash'),
}

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/

/**
 *  Safe switch-over when tapping All Photos in the camera roll.
 *  Assumes we are currently examining an image in the Camera-specific roll.
 *
 **/
UIAApp.prototype.switchoverToAllPhotos = function switchoverToAllPhotos() {
    try {
        var photosWaiter = UIAWaiter.withPredicate("ViewDidAppear", "controllerClass == 'UIInputWindowController'");
        this.tap(UIAQuery.ALL_PHOTOS);
        photosWaiter.wait();
    } catch (e) {
        throw new UIAError("Could not switchover to Photos app via All Photos button due to: " + e);
    }
}

/**
 *  Checks if device supports video.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsVideo = function supportsVideo() {
    return CameraCapability.supportsVideo;
}

/**
 *  Checks if device supports HFR (high frame rate, aka slow motion, aka slo-mo) video.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsSloMo = function supportsSloMo() {
    return CameraCapability.supportsSloMo;
}

UIAApp.prototype.supportsHFR = function supportsHFR() {
    return CameraCapability.supportsSloMo;
}

/**
 *  Checks if device supports panorama photos.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsPanorama = function supportsPanorama() {
    return CameraCapability.supportsPano;
}

/**
*  Check if device supports Portrait photos.
*
* @returns {boolean} true if it does, otherwise false
**/
UIAApp.prototype.supportsPortrait = function supportsPortrait() {
    return CameraCapability.supportsRFCPortrait;
}

/**
 *  Checks if device supports panorama photos.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsPanorama = function supportsPanorama() {
    return CameraCapability.supportsPano;
}

/**
 *  Checks if device has front facing camera.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.hasFrontFacingCamera = function hasFrontFacingCamera() {
    return CameraCapability.hasFrontFacingCamera;
}

/**
 *  Checks if device has flash/torch.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.hasFlash = function hasFlash() {
    return CameraCapability.hasRFCFlash;
}

/**
 *  Checks if device has FFC flash/torch.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.hasFFCFlash = function hasFFCFlash() {
    return CameraCapability.hasRFCFlash;
}

/**
 *  Checks if device supports HDR image capture.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsHDR = function supportsHDR() {
    return CameraCapability.supportsRFCHDR;
}

/**
 *  Checks if device supports Front HDR image capture.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
 UIAApp.prototype.supportsFFCHDR = function supportsFFCHDR() {
    return CameraCapability.supportsFFCHDR;
}

/**
 *  Checks if device has Iris support.
 *
 *  @returns {boolean} true if it does, otherwise false
 **/
UIAApp.prototype.supportsIris = function supportsIris() {
    return CameraCapability.supportsIris;
}

/**
 *  Gets the current camera mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @returns {string} the current camera mode: 'photo', 'video' or 'pano'
 **/
UIAApp.prototype.getCameraMode = function getCameraMode() {
    var info = this.inspect(UIAQuery.CAMERA_MODE.orElse(UIAQuery.CAMERA_VIDEO_CAPTURE_BUTTON))
    // camera mode not found but video capture button exists
    if (info && !info.exists(UIAQuery.CAMERA_MODE)) {
        return CameraMode.VIDEO
    }
    // button we use to check for camera mode value
    return this.valueOf(UIAQuery.CAMERA_MODE).replace(' ','').replace('\n','');
}

/**
 *  Gets the current camera facing mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @returns {string} the current camera facing mode: 'Front facing' or 'Back facing'
 **/
UIAApp.prototype.getCameraFacingMode = function getCameraFacingMode() {
    if (this.exists(UIAQuery.CAMERA_FRONT_BACK_FACING_BUTTON)) {
        return this.valueOf(UIAQuery.CAMERA_FRONT_BACK_FACING_BUTTON);
    } else {
        return CameraFacingMode.BACK
    }
}

/**
 *  Gets the current camera HDR mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @returns {string} the current camera HDR mode: 'On', 'Off', or 'Auto'
 **/
UIAApp.prototype.getCameraHDRMode = function getCameraHDRMode() {
    var mode = this.valueOf(UIAQuery.CAMERA_HDR);
    if ('Automatic' == mode) {
        mode = 'Auto';
    }
    return mode;
}


/**
 *  Gets the current camera flash mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @returns {string} the current camera flash mode: "On", "Off", or "Auto"
 **/
UIAApp.prototype.getCameraFlashMode = function getCameraFlashMode() {
    var mode = this.valueOf(UIAQuery.CAMERA_FLASH);
    if ('Automatic' == mode) {
        mode = 'Auto';
    }
    return mode;
}


/**
 *  Gets the current camera Iris mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @returns {boolean} the current camera Iris mode
 **/
UIAApp.prototype.getCameraIrisMode = function getCameraIrisMode() {
    if (!this.exists(UIAQuery.CAMERA_IRIS)) {
        throw new UIAError("Camera Iris button doesn't exist");
    }
    if (this.valueOf(UIAQuery.CAMERA_IRIS) === "On") {
        return true;
    } else if (this.valueOf(UIAQuery.CAMERA_IRIS) === "Off") {
        return false;
    } else {
        throw new UIAError("Camera Iris button returned a value other than 'On' or 'Off': " + this.valueOf(UIAQuery.CAMERA_IRIS));
    }
}


UIAApp.prototype._changeCameraMode = function _changeCameraMode(mode) {
    var cameraModeBar = UIAQuery.CAMERA_MODE;

	// determine the index of the target mode so we know which direction to swipe
    var targetModeIndex = 0;
    for (var key in CameraMode) {
        if (mode === CameraMode[key]) break;
        targetModeIndex++;
    }
    // error if we can't find current or target mode index
    if (targetModeIndex >= Object.keys(CameraMode).length) {
        throw new UIAError('Requested camera mode "' + mode + '" is not a valid option', {identifier : 'Camera mode does not exist'});
    }

    UIALogger.logMessage('Configuring for ' + mode + ' mode');

	 // swipe to get to desired mode
    var numSwipes = Object.keys(CameraMode).length;
    var currentMode = null;
    while (((currentMode = this.getCameraMode()) !== mode) && (numSwipes-- > 0)) {
        // find which index the current camera mode is so we know how many times to swipe
        var currentModeIndex = 0;
        for (var key in CameraMode) {
            if (currentMode === CameraMode[key]) break;
            currentModeIndex++;
        }

        // error if we can't find index of current mode
        if (currentModeIndex >= Object.keys(CameraMode).length) {
            throw new UIAError('Current camera mode "' + currentMode + '" unknown', {identifier : 'Camera mode does not exist'});
        }

        UIALogger.logDebug('Switching from ' + currentMode + ' mode');

        // swipe a different direction depending on current mode, device type, and orientation
        if (currentModeIndex > targetModeIndex) {
            if (UIATarget.localTarget().model() !== 'iPad') {
                switch (this.interfaceOrientation()) {
                    case UIAInterfaceOrientation.PORTRAIT:
                        this.dragRightInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.UPSIDE_DOWN:
                        this.dragLeftInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.LANDSCAPE_RIGHT:
                        this.dragUpInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.LANDSCAPE_LEFT:
                        this.dragDownInside(cameraModeBar);
                        break;
                }
            } else {
                this.dragDownInside(
                    cameraModeBar,
                    {fromOffset: {x: 0.50, y: 0.55}, toOffset: {x: 0.50, y: 0.05}}
                );
            }
        } else {
            if (UIATarget.localTarget().model() !== 'iPad') {
                switch (this.interfaceOrientation()) {
                    case UIAInterfaceOrientation.PORTRAIT:
                        this.dragLeftInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.UPSIDE_DOWN:
                        this.dragRightInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.LANDSCAPE_RIGHT:
                        this.dragDownInside(cameraModeBar);
                        break;
                    case UIAInterfaceOrientation.LANDSCAPE_LEFT:
                        this.dragUpInside(cameraModeBar);
                        break;
                }
            } else {
                this.dragUpInside(
                    cameraModeBar,
                    {fromOffset: {x: 0.50, y: 0.45}, toOffset: {x: 0.50, y: 0.95}}
                );
            }
        }
    }

    UIALogger.logMessage('Currently in ' + currentMode + ' mode');

    return (currentMode === mode);
}

/**
 *  Sets the desired camera mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {string} mode - the desired mode: 'photo', 'video', 'pano', 'slo-mo', 'time-lapse', 'square', or 'portrait'
 *
 *  @returns {boolean} true if mode changed, else false
 **/
UIAApp.prototype.setCameraMode = function setCameraMode(mode) {
    // default mode is 'photo'
    if (typeof mode !== 'string') {
        mode = CameraMode.PHOTO;
    }

    // allow users to pass mode with any variation of case
    mode = mode.toLowerCase();
    var selectedCameraPortraitSupport = CameraFacingMode.FRONT == this.getCameraFacingMode() ? false : CameraCapability.supportsRFCPortrait;

    // sanity checks
    if (!CameraCapability.supportsVideo && (mode === CameraMode.VIDEO)) {
        UIALogger.logWarning('Device does not support Video -- will not set the mode');
        return false;
    } else if (!CameraCapability.supportsPano && (mode === CameraMode.PANO)) {
        UIALogger.logWarning('Device does not support Panorama -- will not set the mode');
        return false;
    } else if (!CameraCapability.supportsSloMo && (mode === CameraMode.SLOMO)) {
        UIALogger.logWarning('Device does not support HFR (aka Slo-Mo video) -- will not set the mode');
        return false;
    } else if (!selectedCameraPortraitSupport && (mode == CameraMode.PORTRAIT)) {
        throw new UIAError('Device does not support Portrait on current sensor');
    }

    // make sure we are in camera and iris is open/viewfinder is up
    // <rdar://problem/42626536> - isCameraIrisOpen() returns false if Camera is open from Messages
    if (!this.isCameraIrisOpen() && target.activeApp().name() !== 'Messages') {
        throw new UIAError('Camera Iris not open. Cannot switch camera to "' + mode + '" without viewfinder up.',
                        {identifier : 'Camera iris not open'});
    }

    // save some logic if we are already in the right mode
    var initialMode = this.getCameraMode();
    if (initialMode === mode) {
        UIALogger.logMessage('Camera already in mode "' + mode + '"');
        return false;
    }
    // turn off video capture if camera is actively capturing video
    // so that camera mode slider will appear
    if (initialMode === CameraMode.VIDEO) {
        this.stopVideoCapture()
    }

    // Slow devices sometimes fail because preview doesn't start fast enough, UIAWaiter should help
    var irisWaiter = UIAWaiter.waiter("CameraIrisOpened");
    UIALogger.logMessage('Switching camera to "' + mode + '" mode');
    this._changeCameraMode(mode);

    // we should be in the right mode now
    if (this.getCameraMode() !== mode){
        throw new UIAError('Could not switch camera to "' + mode + '" mode');
    } else if (!this.isCameraIrisOpen() && !irisWaiter.wait()) {
        throw new UIAError('Camera iris never opened after switching to "' + mode + '" mode');
    } else {
        UIALogger.logMessage('Successfully switched camera to "' + mode + '" mode');
    }

    return true;
}


/**
 *  Sets the desired camera facing mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {string} mode - the desired mode: "Front facing" or "Back facing"
 *
 *  @returns {boolean} true if mode changed, else false
 **/
UIAApp.prototype.setCameraFacingMode = function setCameraFacingMode(mode) {

    UIALogger.logMessage("Setting camera facing mode to '" + mode + "'");
    // default mode is 'Back facing'
    if (mode !== CameraFacingMode.FRONT) {
        mode = CameraFacingMode.BACK;
    }

    // sanity checks
    if (!this.hasFrontFacingCamera() && (mode === CameraFacingMode.FRONT && !CameraCapability.hasFFCFlash)) {
        UIALogger.logWarning('Device does not support front-facing camera -- will not set the mode');
        return false;
    }

    // make sure we are in camera and iris is open/viewfinder is up
    if (!this.isCameraIrisOpen()) {
        throw new UIAError('Camera Iris not open. Cannot switch camera to "' + mode + '" mode without viewfinder up.',
                        {identifier : 'Camera iris not open'});
    }

    // save some logic if we are already in the right mode
    if (this.getCameraFacingMode() === mode) {
        UIALogger.logMessage('Camera already in mode "' + mode + '"');
        return false;
    } else {
        UIALogger.logMessage('Camera currently in mode "' + this.getCameraFacingMode() + '"');
    }

    UIALogger.logMessage('Switching camera to "' + mode + '" mode');

    // Test would always fail if CameraFacingMode was set to FRONT, removing this chunk of code fixes the issue
    this.tap(UIAQuery.CAMERA_FRONT_BACK_FACING_BUTTON);

    UIAUtilities.assert(
        this.isCameraIrisOpen(),
        'Camera iris never opened after switching to "' + mode + '" mode'
    )

    UIALogger.logMessage('Successfully switched camera to "' + mode + '" mode');
    return true;
}


/**
 *  Sets the desired HDR mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {string} mode - the desired HDR mode: "On", "Off" or "Auto"
 *
 *  @returns {boolean} true if mode changed, else false
 **/
UIAApp.prototype.setCameraHDRMode = function setCameraHDRMode(mode) {

    UIALogger.logMessage("Setting camera HDR mode to '%0'".format(mode));
    var cameraFacingMode = this.getCameraFacingMode();
    var selectedCameraSupportsHDR = CameraFacingMode.FRONT == cameraFacingMode ? CameraCapability.supportsFFCHDR : CameraCapability.supportsRFCHDR;
    var selectedCameraSupportsHDRAuto = CameraFacingMode.FRONT == cameraFacingMode ? CameraCapability.supportsFFCHDRAuto : CameraCapability.supportsRFCHDRAuto;
    var selectedCameraSupportsHDROn = CameraFacingMode.FRONT == cameraFacingMode ? CameraCapability.supportsFFCHDROn : CameraCapability.supportsRFCHDROn;

    // HDR may not be supported at all
    if (!selectedCameraSupportsHDR) {
        UIALogger.logMessage("HDR mode is not supported on this device for the selected camera");
        return false;
    }

    if ("Auto" == mode) {
        if (!selectedCameraSupportsHDRAuto) {
             UIALogger.logError("Auto HDR mode is not supported on this device for the selected camera");
             return false;
        }
    }

    if ("On" == mode) {
        if (!selectedCameraSupportsHDROn) {
             UIALogger.logError("ON HDR mode is not supported on this device for the selected camera");
             return false;
        }
    }

    // make sure we are in camera and iris is open/viewfinder is up
    if (!this.isCameraIrisOpen()) {
        throw new UIAError(
            'Camera Iris not open. Cannot switch HDR to "%0" mode without viewfinder up.'
            .format(mode),
            {identifier : 'Camera iris not open'}
        );
    }

    // save some logic if we are already in the right mode
    if (this.getCameraHDRMode() === mode) {
        UIALogger.logMessage('Camera already in HDR mode "%0"'.format(mode));
        return false;
    }

    // Change the HDR mode state
    UIALogger.logMessage('Switching HDR to "' + mode + '" mode');
    this.tap(UIAQuery.CAMERA_HDR);
    // if the current camera supports three modes for HDR then two step to activate
    if (selectedCameraSupportsHDRAuto) {
        this.tap(mode);
    }

    // Wait for HDR to update its value ('Automation' contains 'Auto')
    this.waitUntilPresent(UIAQuery.CAMERA_HDR.withPredicate('value CONTAINS "%0"'.format(mode)), 2);

    // we should be in the right mode now
    UIAUtilities.assert(
        this.getCameraHDRMode() === mode,
        'Could not switch camera to HDR mode "%0". Current mode is "%1"'.format(mode, this.getCameraHDRMode())
    )
    UIAUtilities.assert(
        this.isCameraIrisOpen(),
        'Camera iris never opened after switching to "%0" mode'.format(mode)
    )

    UIALogger.logMessage('Successfully switched camera to HDR mode "%0"'.format(mode));
    return true;
}


/**
 *  Sets the desired flash mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {string} mode - the desired flash mode: "On", "Off", or "Auto"
 *
 *  @returns {boolean} true if mode changed, else false
 **/
UIAApp.prototype.setCameraFlashMode = function setCameraFlashMode(mode) {

    UIALogger.logMessage("Setting camera flash mode to '%0'".format(mode));

    // default mode is 'off'
    if (typeof mode !== 'string') {
        mode = CameraFlashMode.OFF;
    }

    // make sure we are in camera and iris is open/viewfinder is up
    if (!this.isCameraIrisOpen()) {
        throw new UIAError(
            'Camera Iris not open. Cannot switch flash to "%0" mode without viewfinder up.'
            .format(mode),
            {identifier : 'Camera iris not open'}
        );
    }

    // check flash is supported on current camera
    var selectedCameraFlashSupport = CameraFacingMode.FRONT == this.getCameraFacingMode() ? CameraCapability.supportsFFCFlash : CameraCapability.supportsRFCFlash;
    if (!selectedCameraFlashSupport) {
        UIALogger.logMessage("Device does not support front facing camera flash.");
        return false;
    }

    // save some logic if we are already in the right mode
    if (this.getCameraFlashMode().indexOf(mode) >= 0) {
        UIALogger.logMessage('Camera already in flash mode "%0"'.format(mode));
        return false;
    }

    UIALogger.logMessage('Switching flash to "%0" mode'.format(mode));

    this.tap(UIAQuery.CAMERA_FLASH);
    this.tap(mode);

    // Wait for Flash to update its value ('Automation' contains 'Auto')
    this.waitUntilPresent(UIAQuery.CAMERA_FLASH.withPredicate('value CONTAINS "%0"'.format(mode)), 2);

    // we should be in the right mode now
    UIAUtilities.assert(
        this.getCameraFlashMode() === mode,
        'Could not switch flash to "%0" mode, current mode "%1"'.format(mode, this.getCameraFlashMode())
    )
    UIAUtilities.assert(
        this.isCameraIrisOpen(),
        'Camera iris never opened after switching to "%0" mode'.format(mode)
    )

    UIALogger.logMessage('Successfully switched camera to "%0" mode'.format(mode));
    return true;
}


/**
 *  Sets the desired Iris mode.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {boolean} mode - the desired Iris mode
 *
 *  @returns {boolean} true if mode changed, else false
 **/
UIAApp.prototype.setCameraIrisMode = function setCameraIrisMode(mode) {
    // default mode is 'off'
    if (mode !== true && mode !== false) {
        mode = false;
    }

    // Store the string version of the mode we're looking for
    mode ? value = 'On' : value = 'Off';

    UIALogger.logMessage("Setting camera Iris mode to '%0'".format(value));

    // make sure we are in camera and iris is open/viewfinder is up
    if (!this.isCameraIrisOpen()) {
        throw new UIAError(
            'Camera Iris not open. Cannot switch Iris to "%0" mode without viewfinder up.'
            .format(value),
            {identifier : 'Camera iris not open'}
        );
    }

    // save some logic if we are already in the right mode
    if (this.getCameraIrisMode() === mode) {
        UIALogger.logMessage('Camera already in Iris mode "%0"'.format(value));
        return false;
    }

    UIALogger.logMessage('Switching Iris to "%0" mode'.format(value));
    this.tap(UIAQuery.CAMERA_IRIS);

    // Wait for the Iris button to update
    this.waitUntilPresent(UIAQuery.CAMERA_IRIS.withPredicate('value == "%0"'.format(value)), 2);

    // we should be in the right mode now
    UIAUtilities.assert(
        this.getCameraIrisMode() === mode,
        'Could not switch Iris to "%0" mode'.format(value)
    )
    UIAUtilities.assert(
        this.isCameraIrisOpen(),
        'Camera iris never opened after switching to "%0" mode'.format(value)
    )

    UIALogger.logMessage('Successfully switched Iris to "%0" mode'.format(value));
    return true;
}


/**
 *  Sets the desired filter and verifies it.
 *  Assumes user already has viewfinder UI up.
 *
 *  @param {string} mode - the desired filter name
 *
 **/
UIAApp.prototype.setCameraFilter = function setCameraFilter(filter) {
    var filters = {
        'Original': 0,
        'Vivid': 1,
        'Vivid Warm': 2,
        'Vivid Cool': 3,
        'Dramatic': 4,
        'Dramatic Warm': 5,
        'Dramatic Cool': 6,
        'Mono': 7,
        'Silvertone': 8,
        'Noir': 9,
    };

    if (target.mobileGestaltQuery('DeviceName') == "iPad") {
        UIALogger.logMessage("Filter mode is not supported on iPad");
        return;
    }

    // default mode is 'Original'
    if (typeof filter !== 'string') {
        filter = "Original";
    }

    // make sure we are in camera and iris is open/viewfinder is up
    if (!this.isCameraIrisOpen()) {
        throw new UIAError(
            'Camera Iris not open. Cannot switch filter to "%0" without viewfinder up.'
            .format(filter),
            {identifier : 'Camera iris not open'}
        );
    }

    // make sure the desired filter is in the list
    if (!(filter in filters)) {
        throw new UIAError(
            "Camera cannot switch filter to '%0' because it doesn't exist"
            .format(filter)
        );
    }

    // If we are already on the desired filter, bail
    if (this.inspect(UIAQuery.CAMERA_FILTERS).value == filter) {
        UIALogger.logMessage('Already on filter "%0"'.format(filter));
        return;
    }

    if (!this.exists(UIAQuery.CAMERA_FILTER_SCRUBBER)) {
        this.tap(UIAQuery.CAMERA_FILTERS);
    }
    UIAUtilities.assert(this.waitUntilPresent(UIAQuery.CAMERA_FILTER_SCRUBBER),
                        "Attempted to open filter page, list is not shown on UI");

    // Get current filter value
    var current_filter = this.inspect(UIAQuery.CAMERA_FILTER_SCRUBBER).value;

    UIALogger.logMessage('Currently on filter "%0" at index "%1"'.format(current_filter, filters[current_filter]));
    UIALogger.logMessage('Swiping to filter to "%0" at index "%1"'.format(filter, filters[filter]));

    // Positive diff means the element is X filters to the right (so swipe left)
    // and negative means we need to swipe right to go left X filters.
    var index_diff = filters[filter] - filters[current_filter];

    var left_offset = {fromOffset: {x: 0.58, y: 0.50}, toOffset: {x: 0.42, y: 0.50}};
    var right_offset = {fromOffset: {x: 0.42, y: 0.50}, toOffset: {x: 0.58, y: 0.50}};

    if (index_diff > 0) {
        UIALogger.logMessage('The target filter is to the right, so we will be dragging from right to left.');
        var offset = left_offset;
    } else {
        UIALogger.logMessage('The target filter is to the left, so we will be dragging from left to right.');
        var offset = right_offset;
    }

    var swipes = 0;
    while (swipes < Math.abs(index_diff) && current_filter != filter) {
        swipes++;
        this.drag(UIAQuery.CAMERA_FILTER_SCRUBBER, offset);
        var current_filter = this.inspect(UIAQuery.CAMERA_FILTER_SCRUBBER).value;
        UIALogger.logMessage('Swipe #%0: Got to filter "%1" at index "%2"'.format(swipes, current_filter, filters[current_filter]));
    }

    UIAUtilities.assert(current_filter == filter,
                        "Didn't get to the desired filter filter after %0 swipes!".format(swipes));

    // Tap and Wait to close the filter page, if camera filter element is in the tree then filter has been closed
    this.tap(UIAQuery.CAMERA_FILTERS);
    UIAUtilities.assert(this.waitUntilPresent(UIAQuery.CAMERA_MODE),
                        "Closing filter page however filter list is still shown on UI");

    UIALogger.logMessage('Successfully switched camera to "%0" filter'.format(filter));
}

/**
 *  Sets the desired lighting and verifies it.
 *  Assumes user already has viewfinder UI up and is already in Portrait mode
 *
 *  @param {string} targetLighting - the desired lighting mode
 *
 **/
UIAApp.prototype.setPortraitLighting = function setPortraitLighting(targetLighting) {

    // if we're not already in portrait mode, bail
    UIAUtilities.assert(this.getCameraMode() === CameraMode.PORTRAIT,
                        'Cannot set portrait lighting when portrait mode is not active');

    // if arguments aren't valid, bail
    UIAUtilities.assert(typeof targetLighting === 'string', 'Invalid type for argument "targetLighting"');

    // if the viewfinder isn't up, bail
    UIAUtilities.assert(this.isCameraIrisOpen(), 'Camera iris not open. Cannot switch lighting without viewfinder up.');

    var targetLighting = targetLighting.toUpperCase();
    var lightings = {
		'NATURAL LIGHT': 0,
		'STUDIO LIGHT': 1,
		'CONTOUR LIGHT': 2,
        'STAGE LIGHT': 3,
        'STAGE LIGHT MONO': 4,
    };
    // if the desired lighting isn't in the list, bail
    UIAUtilities.assert(targetLighting in lightings,
                        "Camera cannot switch lighting to '%0' because it doesn't exist".format(targetLighting));

    // Get current filter value
    UIAUtilities.assert(this.waitUntilPresent(UIAQuery.CAMERA_LIGHTING),
                        'Attempted to open lighting options, list is not shown on UI');
    var currentLighting = this.inspect(UIAQuery.CAMERA_LIGHTING).value;

    // If we are already on the desired filter, bail
    if (currentLighting == targetLighting) {
        UIALogger.logMessage('Already on lighting "%0"'.format(currentLighting));
        return;
    }

    UIALogger.logMessage('Currently on lighting "%0" at index "%1"'.format(currentLighting, lightings[currentLighting]));
    UIALogger.logMessage('Swiping to lighting "%0" at index "%1"'.format(targetLighting, lightings[targetLighting]));

    // Positive diff means the element is X filters to the right (so swipe left)
    // and negative means we need to swipe right to go left X filters.
    var indexDiff = lightings[targetLighting] - lightings[currentLighting];

    var leftOffset = {fromOffset: {x: 0.58, y: 0.50}, toOffset: {x: 0.42, y: 0.50}};
    var rightOffset = {fromOffset: {x: 0.42, y: 0.50}, toOffset: {x: 0.58, y: 0.50}};

    if (indexDiff > 0) {
        UIALogger.logMessage('The target filter is to the right, so we will be dragging from right to left.');
        var offset = leftOffset;
    } else {
        UIALogger.logMessage('The target filter is to the left, so we will be dragging from left to right.');
        var offset = rightOffset;
    }

    var swipes = 0;
    while (swipes < Math.abs(indexDiff) && currentLighting != targetLighting) {
        swipes++;
        this.drag(UIAQuery.CAMERA_LIGHTING, offset);
        var currentLighting = this.inspect(UIAQuery.CAMERA_LIGHTING).value;
        UIALogger.logMessage('Swipe #%0: Got to filter "%1" at index "%2"'.format(swipes, currentLighting, lightings[currentLighting]));
    }

    UIAUtilities.assert(currentLighting === targetLighting,
                        "Didn't get to the desired filter filter after %0 swipes!".format(swipes));

    UIALogger.logMessage('Successfully switched camera to "%0" mode'.format(targetLighting));
}

/**
 * Sets Camera options from the viewfinder display
 *
 * @param {object} options Test arguments
 * @param {string} [options.flashMode=null] - Which flash mode to use: "On", "Off", or "Automatic"
 * @param {string} [options.cameraFacingMode=null] - Choose the front- or back-facing camear: "Front facing" or "Back facing"
 * @param {string} [options.hdrMode=null] - Which HDR mode to use: "On" or "Off"
 * @param {boolean} [options.irisMode=null] - Should we make an Iris asset?
 * @param {string} [options.cameraFilter=null] - Use a specific filter. String should equal the filter's name.
 * @param {string} [options.captureMode='photo'] - Which capture mode to use: 'photo', 'video', 'pano', 'slo-mo', 'time-lapse', 'square', or 'portrait'
 *
 */
UIAApp.prototype.setCameraOptions = function setCameraOptions(options) {
    options = UIAUtilities.defaults(options, {
        flashMode: null,
        cameraFacingMode: null,
        hdrMode: null,
        irisOn: false,
        cameraFilter: null,
        captureMode: 'photo',
    });

    // TO DO: Replace all of these delays with waiters
    // Sensor must be set first since some capabilities are sensor specific
    if (this.hasFrontFacingCamera() && options.cameraFacingMode) {
        target.delay(1);
        this.setCameraFacingMode(options.cameraFacingMode);
        target.delay(1);
    }

    this.setCameraMode(options.captureMode);
    // Nothing else can be done since Portrait doesn't have other controls
    if (options.captureMode == CameraMode.PORTRAIT) {
        // Dismiss splash screen on the first launch of Portrait mode
        if (this.waitUntilPresent(UIAQuery.staticTexts().contains('Portrait Camera'), 2.0)) {
            UIALogger.logMessage('Trying to dismiss Portrait Camera splash screen');
            this.tapIfExists(UIAQuery.buttons('Continue'));
        }
        return;
    }

    var cameraFacingMode = this.getCameraFacingMode();
    var selectedCameraHDRSupport =  CameraFacingMode.FRONT == cameraFacingMode ? CameraCapability.supportsFFCHDR : CameraCapability.supportsRFCHDR;
    var selectedCameraFlashSupport =  CameraFacingMode.FRONT == cameraFacingMode ? CameraCapability.supportsFFCFlash : CameraCapability.supportsRFCFlash;
    if (selectedCameraHDRSupport && options.hdrMode && options.hdrMode == 'On') {
        target.delay(1);
        this.setCameraHDRMode(options.hdrMode);
    }

    if (selectedCameraFlashSupport) {
        target.delay(1);
        this.setCameraFlashMode(options.flashMode);
    }

    if (CameraCapability.supportsIris && (options.captureMode === CameraMode.PHOTO)) {
        target.delay(1);
        this.setCameraIrisMode(options.irisOn);
    }

    if (options.cameraFilter) {
        target.delay(1);
        this.setCameraFilter(options.cameraFilter);
    }
}

/**
 *  Takes a picture.
 *
 * @param {object} options Test arguments
 * @param {boolean} [options.burstMode=false] - Are we takng a burst photo?"
 * @param {int} [options.burstDuration=10] - The time duration in seconds for taking a burst photo"
 */
UIAApp.prototype.takePicture = function takePicture(options) {
    UIALogger.logDebug("Waiting for photo capture");

    //A dummy waiter for functionality until we get a notification for Photo Capture
    var captureWaiter = UIAWaiter.waiter("PhotoCaptured");

    if (options.burstMode) {
        UIALogger.logDebug("Burst duration: %0".format(options.burstDuration));
        this.touchAndHold(UIAQuery.CAMERA_CAPTURE_BUTTON, options.burstDuration);
    } else if (options.captureMode == CameraMode.PORTRAIT) {
        var portraitWaiter = UIAWaiter.withPredicate('Announcement', 'announcement CONTAINS "Depth Effect Enabled"');
        if(!portraitWaiter.wait(10)) {
            UIALogger.logWarning("'Depth Effect Enabled' event did not fire");
        }
        this.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);
    } else {
        this.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);
    }
    captureWaiter.wait();
}

/**
 *  Starts video capture.
 */
UIAApp.prototype.startVideoCapture = function startVideoCapture() {
	if (this.exists(UIAQuery.query('00:00:00'))) {
		this.tap(UIAQuery.CAMERA_VIDEO_CAPTURE_BUTTON);
	}
	else if (this.exists(UIAQuery.CAMERA_VIDEO_ELAPSED_TIME)) {
		// figuring out the time from the four CAMModeDialItem elements is a PITA
        throw new UIAError("Video capture already started.");
    }
	else {
        throw new UIAError("Can't find timer. Are you on the video capture UI?");
    }
}


/**
 *  Stops video capture, if video is being started.
 *
 * @param {object} options Test arguments
 * @param {boolean} [options.throwIfNotRecording=false] - Throw an error if camera is not recording
 */
UIAApp.prototype.stopVideoCapture = function stopVideoCapture(options) {
    options = UIAUtilities.defaults(options, {
        throwIfNotRecording: false,
    });
    var videoButton = camera.inspect(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON)
    if (videoButton && videoButton.label === VideoButtonLabel.STOP) {
        this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);
    } else if (options.throwIfNotRecording) {
        throw new UIAError("Camera is not capturing video.")
    }
}
