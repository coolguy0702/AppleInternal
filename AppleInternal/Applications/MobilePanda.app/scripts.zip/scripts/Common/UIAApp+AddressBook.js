load("UIAApp.js");

/*******************************************************************************/
/*                                                                             */
/*   Mark: Localization Strings                                                */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/

/** AddressBookUI.framework and AddressBookUI.axbundle Strings: */

/** All Contacts */
LocStrings.ALL_CONTACTS =   target.localizedString(
                                'ALL_CONTACTS',
                                {tableName:"AB", bundlePath:"/System/Library/Frameworks/AddressBookUI.framework"}
                            );

/** Edit */
LocStrings.EDIT =           target.localizedString(
                                'EDIT',
                                {tableName:"AB", bundlePath:"/System/Library/Frameworks/AddressBookUI.framework"}
                            );

/** Groups */
LocStrings.GROUPS =         target.localizedString(
                                'GROUPS',
                                {tableName:"AB", bundlePath:"/System/Library/Frameworks/AddressBookUI.framework"}
                            );

/** Remove Pin */
LocStrings.REMOVE_PIN =     target.localizedString(
                                'MAPS_CARD_REMOVE_PIN',
                                {tableName:"AB", bundlePath:"/System/Library/Frameworks/AddressBookUI.framework"}
                            );

/** All contacts */
LocStrings.ALL_CONTACTS =   target.localizedString(
                                'ALL_CONTACTS',
                                { tableName:"AB", bundlePath:"/System/Library/Frameworks/AddressBookUI.framework"}
                            );

/** Contacts */
LocStrings.CONTACTS =       target.localizedString(
                                'ALL_CONTACTS',
                                { tableName:'Localized', bundlePath: '/System/Library/Frameworks/ContactsUI.framework'}
                            );

/** New Contact */
LocStrings.NEW_CONTACT =   target.localizedString(
                                'CREATE_NEW_CONTACT_TITLE',
                                { tableName:'Localized', bundlePath: '/System/Library/Frameworks/ContactsUI.framework'}
                            );

/** First name */
LocStrings.FIRST_NAME =     target.localizedString(
                               'givenName',
                               { tableName:"CNContact", bundlePath:"/System/Library/Frameworks/Contacts.framework"}
                            );

/** Last name */
LocStrings.LAST_NAME =      target.localizedString(
                               'familyName',
                               { tableName:"CNContact", bundlePath:"/System/Library/Frameworks/Contacts.framework"}
                            );

/** Company */
LocStrings.COMPANY =        target.localizedString(
                                'Organization',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** Add url */
LocStrings.ADD_URL =        target.localizedString(
                                'ADD_NEW_ITEM urlAddresses',
                                { tableName:"Localized", bundlePath:"/System/Library/Frameworks/ContactsUI.framework"}
                            );

/** Add address */
LocStrings.ADD_ADDRESS =    target.localizedString(
                               'ADD_NEW_ITEM postalAddresses',
                               { tableName:"Localized", bundlePath:"/System/Library/Frameworks/ContactsUI.framework"}
                            ),

/** home */
LocStrings.HOME_ADDRESS =   target.localizedString(
                                '_$!<Home>!$_',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** work */
LocStrings.WORK_ADDRESS =   target.localizedString(
                                '_$!<Work>!$_',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** Street */
LocStrings.STREET =         target.localizedString(
                                'Street',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** City */
LocStrings.CITY =           target.localizedString(
                                'City',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** State */
LocStrings.STATE =          target.localizedString(
                                'State',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** Postal Code */
LocStrings.POSTAL_CODE =    target.localizedString(
                                'ZIP',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/** Postal Code In Contacts */
LocStrings.POSTAL_CODE_IN_CONTACTS =    target.localizedString(
                                            'postalCode',
                                            { tableName:'CNPostalAddress', bundlePath:'/System/Library/Frameworks/Contacts.framework' }
                                        );

/** Country */
LocStrings.COUNTRY =        target.localizedString(
                                'Country',
                                { tableName:'Localized', bundlePath:"/System/Library/Frameworks/AddressBook.framework" }
                            );

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAQuery.HOME_ADDRESS_BUTTON =  UIAQuery.query('UITableViewCellAccessibilityElement').andThen(UIAQuery.withPredicate("ANY descendants.name contains 'CNPostalAddressEditorTableView'")).andThen(UIAQuery.buttons(LocStrings.HOME_ADDRESS));

UIAQuery.WORK_ADDRESS_BUTTON =  UIAQuery.query('UITableViewCellAccessibilityElement').andThen(UIAQuery.withPredicate("ANY descendants.name contains 'CNPostalAddressEditorTableView'")).andThen(UIAQuery.buttons(LocStrings.WORK_ADDRESS));

UIAQuery.HOME_ADDRESS_ELEMENT = UIAQuery.query('UITableViewCellAccessibilityElement').
                                andThen(UIAQuery.withPredicate("ANY descendants.name contains 'CNPostalAddressEditorTableView'")).
                                andThen(UIAQuery.withPredicate("ANY children.name =='%0'".format(LocStrings.HOME_ADDRESS)));

UIAQuery.WORK_ADDRESS_ELEMENT = UIAQuery.query('UITableViewCellAccessibilityElement').
                                andThen(UIAQuery.withPredicate("ANY descendants.name contains 'CNPostalAddressEditorTableView'")).
                                andThen(UIAQuery.withPredicate("ANY children.name =='%0'".format(LocStrings.WORK_ADDRESS)));

UIAQuery.STREET = UIAQuery.query(LocStrings.STREET);

UIAQuery.CITY = UIAQuery.query(LocStrings.CITY);

UIAQuery.STATE = UIAQuery.query(LocStrings.STATE);

UIAQuery.POSTAL_CODE = UIAQuery.query(LocStrings.POSTAL_CODE);

UIAQuery.COUNTRY = UIAQuery.query(LocStrings.COUNTRY);

UIAQuery.CONTACTS_NAV_BAR = UIAQuery.navigationBars(LocStrings.CONTACTS);
UIAQuery.NEW_CONTACT_NAV_BAR = UIAQuery.navigationBars(LocStrings.NEW_CONTACT);

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/

/**
 *  Chooses which groups are displayed
 *
 *  @param {array} groups - an array of the groups to be displayed
 *  @returns {boolean} true if the desired groups are chosen, else false
 **/
UIAApp.prototype.chooseContactGroup = function chooseContactGroup(groups) {
    return false
}

/**
 *  Select the specified contact
 *
 *  @param {string} contactName - name of the contact to select
 *  @returns {boolean} true if the desired contact is selected, else false
 **/
UIAApp.prototype.selectContact = function selectContact(contactName) {
    return false
}

/**
 *  Search for the specified contact
 *
 *  @param {string} contactName - name of the contact to search for
 *  @returns {boolean} true if the desired contact is found, else false
 **/
UIAApp.prototype.searchForContact = function searchForContact(contactName) {
    return false
}

/**
 *  Add new multi content cell
 *
 *  @param {string} type - which type of multi content cell are we adding
 *  @param {string} label - label associated with this content cell
 *  @param {string} value - content to be added
 *  @returns {boolean} true if the cell is added correctly, else false
 **/
UIAApp.prototype.addNewMultiContentCell = function addNewMultiContentCell(type,label,value) {
	var abContactView = UIAQuery.query("ABContactView");
	this.tap(abContactView.andThen("add " + type));
	// var textfield = UIAQuery.tableCells().withPredicate('ANY children.value == "Phone"');
	// set label
	// enter value
    return false
}

/**
 * Verifies the number of contacts
 *
 * @param {integer} [numContacts=15] - Number of contacts to verify
 */
UIAApp.prototype.verifyNumberOfContacts = function verifyNumberOfContacts(numContacts) {

    var numContactsUI = this.count(UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells()));
    UIALogger.logMessage("Num Contacts: %0".format(numContactsUI));
    if (numContactsUI !== numContacts) {
        throw new UIAError("Number of contacts does not match expected value. Actual: %0, Expected: %1".format(numContactsUI, numContacts));
    }
    UIALogger.logMessage("Number of Contacts: %0 matches the number of contacts expected: %1".format(numContactsUI, numContacts));

}

/**
 *  Delete the specified multi content cell
 *
 *  @param {string} type - which type of multi content cell are we deleting
 *  @param {string} label - label associated with this content cell
 *  @returns {boolean} true if the cell is successfully deleted, else false
 **/
UIAApp.prototype.deleteMultiContentCell = function deleteMultiContentCell(type,label) {
    return false
}

/**
 *  Select the contact at the desired index of the addressbook
 *
 *  @param {int} index - the index of the desired contact
 *  @returns {boolean} true if the contact at the desired index is selected, else false
 **/
UIAApp.prototype.selectContactAtIndex = function selectContactAtIndex(index) {
    return false
}
