

load("Help.js");

/**
 * @class UIATesting
 */
UIATesting = {};

/**
 * @namespace
 */
UIATestResult = {
    /**
     * @type {int}
     */
    PASS: 1,
    /**
     * @type {int}
     */
    FAIL: 0
}

/**
 * Use this to add a function that needs to be executed before each test
 *
 * @memberof UIATesting
 * @param {function} handler Funciton to execute before each test
 */
UIATesting.registerPreTaskHandler = function registerPreTaskHandler(handler) {
	if (typeof UIATesting._preTaskHandlers == 'undefined') UIATesting._preTaskHandlers = new Array();
	UIATesting._preTaskHandlers.push(handler);
}

/**
 * Use this to add a function that needs to be executed after each test completes
 *
 * @memberof UIATesting
 * @param {function} handler Funciton to execute after each test
 */
UIATesting.registerPostTaskHandler = function registerPostTaskHandler(handler) {
	if (typeof UIATesting._postTaskHandlers == 'undefined') UIATesting._postTaskHandlers = new Array();
	UIATesting._postTaskHandlers.push(handler);
}

/**
 * Logs the test names and descriptions for an array or hash of tests
 *
 * @memberof UIATesting
 * @param object test - the container object of tests to list
 **/
UIATesting.list = function list(object) {
	if (object instanceof UIATest) println(object.name + ": " + object._main.name + " (" + object.desc + ")");
	else if (test instanceof Object) {
		for (index in object) {
			this.list(object[index]);
		}
	}
}

/**
 * The constructor for a task object.
 *
 * UIATask is the base class for most of the classes defined in UIATesting.
 * The class represents any executable task. The task can be executed by calling
 * run() or execute().
 *
 * @class UIATask
 *
 * @param {function|object} main - the function that performs the intended task,
 *              or a dictionary object containing the main function (as the value of the
 *              "main" key) and the object on which the function should be applied (as the
 *              value of the "callingObject"). The dictionary value is useful when the
 *              function should be applied to a different object (by default, the function
 *              is applied to the task object). For e.g to use the maps.search function as
 *              the main function, the following expression should be used:
 * @example
 *   var mapsSearchTask = new UIATask({callingObject:maps, main:maps.search}, ["Boston"])
 * @param {array} args - the arguments to the main function
 **/
UIATask = function(config) {
	if (!config.main  || typeof config.main == 'undefined') {
		throw new UIAError("No main function specified for this task.");
	}

    this._parseConfig(config);
	this._main = config.main; // implements a single iteration of a test/task
	this._callingObject = config.callingObject; //the calling object

	this.setup = new Array(); // tasks that are used to setup for the iterations of a test
	this.teardown = new Array(); // tasks that is used to do post processing or cleanup after all test iterations
}

UIATask.prototype = {
    _parseConfig: function _parseConfig(config) {
        var config = (config) ? config : {};
        var restore = {};

        for (var key in config) {
            // supported config properties
            var property = {
                name:"name",
                desc:"desc",
                args:"args",
                alertHandlers:"alertHandlers",
            }[key];

            if (typeof property != 'undefined') {
                restore[property] = this[property];
                this[property] = config[key];
            }
        }

        return restore;
    },

    _restore: function _restore(restore) {
        var restore = (restore) ? restore : {};

        for (var key in restore) {
            if (this.hasOwnProperty(key)) {
                this[key] = restore[key];
            }
        }
    },

	_performTasks: function _performTasks(tasks) {
		if (!(tasks instanceof Array)) return;

		for (var i = 0; i < tasks.length; ++i) {
			var task = tasks[i];
			if (task instanceof UIATask) task.execute();
			else if (typeof task == 'function') task.apply(this);
		}
	},

    /**
     * Run each task without running pre or post handlers
     */
	execute: function execute() {
		this._performTasks(this.setup);
        if (this.args instanceof Array) {
            // called as array
            this.testResult = this._main.apply(this._callingObject, this.args);
        } else {
            // called as associative array (allows for keyed implementation)
            this.testResult = this._main.call(this._callingObject, this.args);
        }
		this._performTasks(this.teardown);
	},

    /**
     * Run each task running pre or post handlers beforehand
     */
	run: function run(config) {
        var task = this;

        function usingAlertHandlers(handlers, block) {
            if (!handlers || handlers.length == 0) {
                return block.call(task);
            } else {
                var handler = handlers[0];
                UIALogger.logDebug('Using alert handler "%0"'.format(handler.name));
                return UIAAlertManager.usingAlertHandler(handler, function () {
                    return usingAlertHandlers(handlers.slice(1), block);
                });
            }
        };

        var restore = this._parseConfig(config);
        try {
            // if not otherwise specified, use the system apps standard alert handler
            var handlers = this.alertHandlers;
            if (!handlers && target.systemApp().standardAlertHandler) {
                handlers = [target.systemApp().standardAlertHandler];
            }

            usingAlertHandlers.call(this, handlers, function () {
                this._runTaskHandlers(UIATesting._preTaskHandlers, 'pre');
                task.execute();
                this._runTaskHandlers(UIATesting._postTaskHandlers, 'post');
            });
        } finally {
            this._restore(restore);
        }
	},

    _runTaskHandlers: function (handlers, handlers_type) {
        var task = this;

        if (handlers instanceof Array) {
            for (index in handlers) {
                var type = typeof(handlers[index])

                if (type === 'function') {
                    // call handler function as a method of the task object
                    handlers[index].call(task);
                } else {
                    UIALogger.logError('Incompatible %0 handler type: "%1"'.format(handlers_type, type));
                }
            }
        }
    }
}

/**
 * A convenience function for creating subclass of UIATask (and
 * its subclasses)
 *
 * @memberof UIATesting
 *
 * @param {object} properties - an dictionary object containing the key/value pairs that
 *               will be associated with all the instances of the class
 * @param {array} parent - the parent class. If no value is specified, UIATask
 *               is used.
 * @example
 *           UIATesting.createTaskSubtype({main:settings.setWiFi}, UIATask)
 *           will create a subclass with the main function set to settings.setWiFi.
 * @returns {function} A constructor function for a subclass of the specified parent type
 **/
UIATesting.createTaskSubtype = function createTaskSubtype(properties, parent) {
	if (!parent) parent = UIATask;
	var _tempClass = function() {
		for (var key in properties)
			this[key] = properties[key];
	}
	_tempClass.prototype.__proto__ = new parent(properties);

	return _tempClass;
}

/**
 * The constructor for a test object.
 *
 * UIATest is a subclass of a UITesting.Task class. The class represents
 * an executable test. The test can be run by calling run() or execute() on the
 * object. The test result is stored in the testResult property of the object.
 *
 * @class UIATest
 * @extends UIATask
 *
 * @param {string} name - an identifier for the test
 * @param {array} args - the arguments to the main function
 * @param {function} main - the function that performs the intended test
 * @param {string} desc - a description of the test
 * @returns {object} UIATest
 **/
UIATest = function(config) {
	UIATask.apply(this, [config]);
    this._parseConfig(config);

    if (null == this.name) this.name = (this._main.name) ? this._main.name : "Test";
    if (null == this.desc) this.desc = "";

	this.cleanup = new Array(); // tasks that are used to cleanup between iterations of the test
}

UIATest.prototype = {
	_executeIteration: function _executeIteration() {
		try {
            if (this.args instanceof Array) {
                // called as array
                this.testResult = this._main.apply(this, this.args);
            } else {
                // called as associative array (allows for keyed implementation)
                this.testResult = this._main.call(this, this.args);
            }
			if (typeof this._cleanup != 'undefined' && this._cleanup instanceof UIATest)
			{
				UIATesting._performTasks(this._cleanup);
			}
		}
		catch (e) {
			this._onException(e);
		}
	},

    /**
     * Run each task without running pre or post handlers
     */
	execute: function execute() {
		if (typeof this.currentRun == 'undefined') this.currentRun = 0;
		if (typeof this.numberOfRuns == 'undefined') this.numberOfRuns = 1;

		this.testError = "";

		this.startTime = new Date();
        this._installLogging();
        try {
            try {
                this._performTasks(this.setup);
            } catch(e) {
                this._onException(e, {prefixString:"Failed test setup"});
                this._report();
                return ;
            }

            for (; this.currentRun < this.numberOfRuns; this.currentRun++)
            {
                var startInfo = {
                    Description: this.desc,
                    TestID: this.name,
                    Arguments: this.args,
                    Iteration: this.currentRun,
                    StartTime: this.startTime.toISOString(),
                };
                if (this._main) startInfo.MainFunctionName = this._main.name;
                var message = this.name + ((this.desc) ? (": " + this.desc) : "");
                UIALogger.logStart(message, startInfo);
                this._executeIteration();
                if (this.currentRun == (this.numberOfRuns-1)) {
                    try {
                        this._performTasks(this.teardown);
                    } catch(e) {
                        this._onException(e, {prefixString:"Failed test teardown"});
                    }
                }
                this._report();
            }
        } finally {
            this._uninstallLogging();
        }
	},

	_onException: function onException(e, options) {
		var prefixString = "Uncaught exception in " + this.name;
		if (options && options.prefixString) prefixString = options.prefixString;

		var errorString = prefixString + ": '" + ((typeof e.message != 'undefined') ? e.message : String(e)) + "'";
		e.message = errorString;
		if (this.testError == 'undefined' || this.testError == "") this.testError = e;
		this.testResult = UIATestResult.FAIL;
	},

    _report: function report() {
        var message = this.name + (this.desc ? ": " + this.desc : "");
        var resultInfo = {
            Description: this.desc,
            TestID: this.name,
            Iteration: this.currentRun,
            StartTime: this.startTime.toISOString(),
        };
        if (this._main) {
            resultInfo.MainFunctionName = this._main.name;
        }
        if (this.testResult == UIATestResult.FAIL) {
            if (this.testError) {
                if (typeof this.testError == "string") {
                    this.testError = new UIAError(this.testError);
                }
                if (this.testError instanceof Error) {
                    UIALogger.logError(this.testError);
                }
                message = typeof this.testError.message != 'undefined' ? this.testError.message : this.testError.toString();
                resultInfo.errorID = typeof this.testError.identifier != 'undefined' ? this.testError.identifier : message;
            }
            UIALogger.logFail(message, resultInfo);
        } else {
            UIALogger.logPass(message, resultInfo);
        }
    },

    _installLogging: function installLogging() {
        var filepath = '/tmp/UIATestResults.json';
        if (target.mobileGestaltQuery('InternalBuild') === false) {
            filepath = '/private/var/mobile/Media/uiautomation/UIATestResults.json';
        }
        if (typeof this.testLog === 'undefined') {
            if (typeof UIADataLogReceiver === 'undefined') {
                UIALogger.logDebug('Installing JavaScript test data log receiver');
                this.testLog = new UIATestLog(filepath);
            } else {
                UIALogger.logDebug('Installing native test data log receiver');
                this.testLog = new UIADataLogReceiver(filepath, UIALogLevel.DEBUG);
            }
            UIALogger.registerReceiver(this.testLog);
        }
    },

    _uninstallLogging: function uninstallLogging() {
        if (typeof this.testLog !== 'undefined') {
            UIALogger.unregisterReceiver(this.testLog);
        }
    },
}

UIATest.prototype.__proto__ = UIATask.prototype;

/**
 * DEPRECATED: JavaScript test data log receiver
 *
 * UIATest._installLogging() will install this only if the native
 * UIADataLogReceiver is undefined, that is, on older scripter2 versions.
 */
UIATestLog = function(resultsPath) {
    this.resultsFile = new UIAFile(resultsPath);
    this.logType = UIALoggingType.WARNING;
    this._logData = [];

    return this;
}
UIATestLog.prototype = {
    currentTest: function currentTest() {
        var tests = this._logData;
        if (!tests.length) {
            tests.push({
                Errors: [],
                Warnings: [],
                PassMessage: null,
                FailMessage: null,
                Result: "INCOMPLETE",
                StartTime: null,
                EndTime: null,
                Data: {},
                ErrorID: null,
            });
        }
        return tests[tests.length-1];
    },

    logInfo: function logInfo(info) {
        info = UIATestingUtilities.convertDatesToString(info);
        var test = this.currentTest();
        var timestamp = test.EndTime = info[UIALoggingKey.TIMESTAMP];
        var message = info[UIALoggingKey.MESSAGE];
        switch (info[UIALoggingKey.TYPE]) {
            case UIALoggingType.START:
                test.Result = "INCOMPLETE";
                test.StartTime = timestamp;
                break;
            case UIALoggingType.PASS:
                test.Result = "PASS";
                test.PassMessage = message;
                break;
            case UIALoggingType.FAIL:
                test.Result = "FAIL";
                test.FailMessage = message;
                test.ErrorID = info.errorID ? info.errorID : message;
                break;
            case UIALoggingType.WARNING:
                test.Warnings.push(message);
                break;
            case UIALoggingType.ERROR:
                var errorInfo = {"message":message};
                if (info.identifier) errorInfo.identifier = info.identifier;
                test.Errors.push(errorInfo);
                break;
            default:
                return;
        }
        this.resultsFile.open('w', 'unicode');
        this.resultsFile.writeln(JSON.stringify(this._logData));
        this.resultsFile.close();
    }
}

/**
 * The constructor for a multi-test object.
 *
 * UIAMultiTest is a subclass of a UITesting.Test class. A multi-test
 * object represents a collection of tests that are run as one test i.e.
 * executing the multi-test runs the tests in the collection one-by-one, and the
 * multi-test passes if all the tests pass, and it fails if any of the tests
 * fail.
 *
 * @class UIAMultiTest
 * @extends UIATest
 *
 * @param {string} name - an identifier for the multi test
 * @param {array} tests - the collection of tests  (array of UIATest objects)
 * @param {string} desc - a description of the multi test
 **/
UIAMultiTest = function(config) {
    this._parseConfig(config);

	if (!config.tests || !(config.tests instanceof Array)) {
		throw new UIAError("No tests specified for multi test.");
	}

	if (!config.name || typeof config.name == 'undefined') {
		throw new UIAError("No name specified for this test.");
	}
	this.name = config.name;
	this.tests = tests;
	this.desc = (config.desc) ? config.desc : "";
	this.setup = new Array();
	this.teardown = new Array();
}

UIAMultiTest.prototype = {
	_executeIteration: function _executeIteration() {
		UIALogger.logStart(this.name);
		try {
            for (var i = 0; i < this.tests.length; ++i) {
				var test = this.tests[i];
				test.execute();
				this.testResult = test.testResult;
				if (this.testResult == UIATestResult.FAIL) {
					this.testError = test.testError;
					break;
				}
			}
		}

		catch (e) {
			this._onException(e);
		}
	}
}

UIAMultiTest.prototype.__proto__ = UIATest.prototype;

/**
 * The constructor for a test dependency object.
 *
 * UIATesting.TestDependency is a subclass of a UITesting.Task class. A test
 * dependency object can be used to check if dependencies are satisfied during
 * setup process of a test/task. Calling execute() on the test dependency object
 * will return true or false based on whether the dependency condition was
 * satisfied or not.
 *
 * @class UIATestDependency
 * @extends UIATask
 *
 * @param {function} main - a function that returns true or false based on whether the
 *              dependency condition was satisfied or not.
 * @param {object} options - a dictionary object of optional arguments
 * @param {string} options.failureMessage - a failure message that will be used to create the
 *     error object if the dependency condition was not satisfied
 * @returns UIATesting.TestDependency object
 **/
UIATestDependency = function (main, options) {

	if (arguments.length == 1 && arguments[0] instanceof Object) {
		var properties = arguments[0];
		main = properties.main;
		options = properties.options;
	}

	this._main = main;
	if (options == undefined) options = new Object();

	if (options.failureMessage) {
		this.failureMessage = options.failureMessage;
	}
}
UIATestDependency.prototype = {
    /**
     * Run each task without running pre or post handlers
     */
	execute: function execute() {
		var result = this._main();
		var errorMessage = this.failureMessage;
		if (errorMessage == undefined) errorMessage = "Failed Dependency Condition";
		if (result == false) throw new UIAError(errorMessage);
	}
}

UIATestDependency.prototype.__proto__ = UIATask.prototype;

/**
 * The constructor for a test collection object.
 *
 * UIATestCollection is a subclass of a UITesting.Task class. A test
 * collection object represents a collection of tests. Calling execute() on the
 * test collection object runs the tests in the collection one at a time.
 *
 * @class UIATestCollection
 * @extends UIATask
 *
 * @param string name - an identifier for the collection
 * @returns object - UIATestCollection object
 **/
UIATestCollection = function(config) {
    this._parseConfig(config);

	this.name = config.name;

	this.setup = new Array();
	this.teardown = new Array();
}
UIATestCollection.prototype = {
	_performTasks: function _performTasks(tasks) {
		if (!(tasks instanceof Array)) return;

        for (var i = 0; i < tasks.length; ++i) {
			var task = tasks[i];
			try {
				if (task instanceof UIATask) task.execute();
				else if (typeof task == 'function') task();
			} catch (e) {
				UIALogger.logError(e);
			}
		}
	},
    /**
     * Run each task without running pre or post handlers
     */
	execute: function execute() {
		this._performTasks(this.setup);

		for (var key in this) {
			if (this[key] instanceof UIATask)
				this[key].run();
		}

		this._performTasks(this.teardown);
	}
}
UIATestCollection.prototype.__proto__ = UIATask.prototype;

/**
 * @class UIAFileManagement
 */
var UIAFileManagement = {
}

/**
 * Escape space characters in path names
 *
 * @param {string} path - a path name to be used to create files or directories
 *
 * @returns {string} UNIX safe path
 **/
UIAFileManagement.escapePath = function escapePath(path) {
	var finalPath = path.replace(' ', '/ ');
	return finalPath;
}

/**
 * Escape space characters in path names
 *
 * @param {string} path - a path name to be used to create files or directories
 * @returns {string} UNIX safe path
 **/

UIAFileManagement.makeSafePath = function makeSafePath(path) {
	var finalPath = path.replace(' ', '/ ');
	return finalPath;
}


/**
 * Creates the given directory on the system.
 *
 * @param string directory - full path to the directory that needs to be created.
 **/
UIAFileManagement.makeDirectory = function makeDirectory(directory) {
	directory = UIAFileManagement.makeSafePath(directory);
	performTask('/sbin/mount', ['-uw', '/'], 5);
    performTask('/bin/mkdir', [directory], 5);
}

/**
 * Removes a file.
 *
 * @param {string} filepath - full path to the file that is to be removed.
 **/
UIAFileManagement.removeFile = function removeFile(filepath) {
    performTask('/bin/rm', ['-rf', UIAFileManagement.makeSafePath(filepath)], 5);
}

/**
 * Removed the given directory on the system.
 *
 * @param {string} directory - full path to the directory that needs to be created.
 **/
UIAFileManagement.removeDirectory = function removeDirectory(directory) {
    performTask('/sbin/mount', ['-uw', '/'], 5);
    performTask('/bin/rm', ['-Rf', UIAFileManagement.makeSafePath(directory)], 5);
}

/**
 * @class UIATestingUtilities
 */
var UIATestingUtilities = {
}

/**
 * Performs a query for crash logs on syslog
 *
 * @param {number} elapsedTimeToCheck - how many millisec of the syslog output to check
 * @returns {array} paths to any crashlogs that have been reported.  If path
 *      cannot be identified, it will send the crash message.
 **/
UIATestingUtilities.crashLogPathsFromSysLog = function crashLogPathsFromSysLog(elapsedTimeToCheck) {
	var crashLogList = new Array();

	// Add crashes (found by ReportCrash) to the array
	var logOutput;
	logOutput = UIAUtility.logToolOutput("/usr/bin/syslog -k Sender ReportCrash -k Level Nle 3 -k Time ge -" + Math.floor(elapsedTimeToCheck/1000), 60);
	if (logOutput != "") {
		var crashLogPrefix = "Saved crashreport to ";
		var newCrashList = logOutput.split("\n");
		if (newCrashList.length > 40) {
			// We had a whole, whole bunch of "crashes" which probably means we're actually putting the
			// 	whole crash log inline.  (This can happen if we max out the number of crashes we can have--i.e. 100)
			//  In this case, we'll just print the first line and then exit.
			crashLogList.push("Too much output to report.  Probably have max number of crashes -- first line is: " + newCrashList[0]);
		}
		else {
			for (var i = 0; i < newCrashList.length; i++) {
				if (newCrashList[i] == "") continue;  // skip empty lines
				if (newCrashList[i].indexOf("--- last message repeated") > -1) {
					// Do not report these, because they seem to be wrong...
					continue;
				}
				var startIndex = newCrashList[i].indexOf(crashLogPrefix);
				if (startIndex == -1) {
					// non-standard crash report -- put it in the array
					crashLogList.push(newCrashList[i]);
				}
				else if (newCrashList[i].indexOf("LowMemory-") > -1) {
					// Low memory warning--don't do anything with these "crashes"
				}
				else {
					// standard crash report -- put just the path in the array
					newCrashList[i] = newCrashList[i].substring(startIndex + crashLogPrefix.length);
					var endIndex = newCrashList[i].indexOf(" ");
					newCrashList[i] = newCrashList[i].substring(0, endIndex);
					crashLogList.push(newCrashList[i]);  // push the modified crash on the list.
				}
			}
		}
	}

	return crashLogList;
}

/**
 * Convert each Date object in obj parameter to an ISO string representing that
 * Date.
 *
 * @param {object} obj Object that may contain or be a Date object
 * @returns {object}
 */
UIATestingUtilities.convertDatesToString = function convertDatesToString(obj) {
    if (obj instanceof Date) {
        return obj.toISOString();
    } else if (obj instanceof Array) {
        return obj.map(this.convertDatesToString.bind(this));
    } else if (typeof obj === 'object') {
        var out = {};
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                out[key] = this.convertDatesToString(obj[key]);
            }
        }
        return out;
    } else {
        return obj;
    }
}

