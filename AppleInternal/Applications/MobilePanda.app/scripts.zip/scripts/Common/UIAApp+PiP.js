load('UIAApp.js');
load('SpringBoard.js')

/**
* Close the Picture in Picture window
* @param {float} timeout - how long to wait for the Cancel button to appear
*
*/
UIAApp.prototype.closePip = function(timeout) {
	if (springboard.waitUntilPresent(UIAQuery.SpringBoard.CLOSE_PIP.isVisible(), timeout)) {
		springboard.tap(UIAQuery.SpringBoard.CLOSE_PIP);
		UIALogger.logMessage('Tapping the close PiP button');
	}
};

/**
* Take the Picture in Picture window back to the originating app and full screen
* @param {float} timeout - how long to wait for the fullscreen button to appear
*
*/
UIAApp.prototype.fullScreenPip = function(timeout) {
	if (springboard.waitUntilPresent(UIAQuery.SpringBoard.FULLSCREEN_PIP.isVisible(), timeout)) {
		UIALogger.logMessage('Taking PiP window Full Screen.');
		springboard.tap(UIAQuery.SpringBoard.FULLSCREEN_PIP);
	}
};

/**
* Pause the Picture in Picture player
* @param {float} timeout - how long to wait for the pause button to appear
*
*/
UIAApp.prototype.pausePip = function(timeout) {
	if (springboard.waitUntilPresent(UIAQuery.SpringBoard.PAUSE_PIP.isVisible(), timeout)) {
		UIALogger.logMessage('Pausing the video from the PiP Window.');
		springboard.tap(UIAQuery.SpringBoard.PAUSE_PIP);
	}
	springboard.delay(1);
	if (springboard.exists(UIAQuery.SpringBoard.PAUSE_PIP.isVisible()) && !springboard.exists(UIAQuery.SpringBoard.PLAY_PIP.isVisible())) {
		throw new UIAError('The Pause button should have changed to the Play button.')
	}
};

/**
* Play the Picture in Picture player
* @param {float} timeout - how long to wait for the play button to appear
*
*/
UIAApp.prototype.playPip = function(timeout) {
	if (springboard.waitUntilPresent(UIAQuery.SpringBoard.PLAY_PIP.isVisible(), timeout)) {
		UIALogger.logMessage('Playing the video from the PiP Window.');
		springboard.tap(UIAQuery.SpringBoard.PLAY_PIP);
	}
	springboard.delay(1);
	if (springboard.exists(UIAQuery.SpringBoard.PLAY_PIP.isVisible()) && !springboard.exists(UIAQuery.SpringBoard.PAUSE_PIP.isVisible())) {
		throw new UIAError('The Play button should have changed to the Pause button.')
	}
};

/**
* Evaluate if the Picture in Picture window was entered
*
* @returns {None} - throws an error if the cancel, fullscreen, and play or pause buttons do not exist
*/
UIAApp.prototype.successfullyEnteredPip = function() {
	if ( !(springboard.exists(UIAQuery.SpringBoard.CLOSE_PIP) && springboard.exists(UIAQuery.SpringBoard.FULLSCREEN_PIP) && (springboard.exists(UIAQuery.Videos.PAUSE) || springboard.exists(UIAQuery.Videos.PLAY)))) {
		throw new UIAError('We failed to enter the PiP window. This is a problem.')
    }
};

/**
* Evaluate if the Picture in Picture window has been closed
*
* @returns {None} - throws an error if the cancel, fullscreen, and play or pause buttons doexist
*/
UIAApp.prototype.successfullyClosedPip = function() {
	if ( springboard.exists(UIAQuery.SpringBoard.CLOSE_PIP) || springboard.exists(UIAQuery.SpringBoard.FULLSCREEN_PIP) || (springboard.exists(UIAQuery.Videos.PAUSE) || springboard.exists(UIAQuery.Videos.PLAY))) {
		throw new UIAError('We failed to close the PiP window. This is a problem.')
	}
}