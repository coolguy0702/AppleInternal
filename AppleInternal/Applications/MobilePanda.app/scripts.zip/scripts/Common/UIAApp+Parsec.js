load('UIAApp.js');
load('Stocks.js');
load('Settings.js');



/******************************************************************************************/
/*                                                                                        */
/*   Mark: Query Constants                                                                */
/*                                                                                        */
/*      App specific queries that will be used frequently                                 */
/*                                                                                        */
/******************************************************************************************/

/** @namespace */

UIAQuery.Parsec = {

    /** Spotlight search results */
    SEARCH_RESULTS_TABLEVIEW    :   UIAQuery.query('SearchUITableView'),
    SEARCH_RESULTS_SECTION      :   UIAQuery.withPredicate("any identifiers contains 'SectionHeader'"),

    get SEARCH_RESULTS_SECTION_NAMES () { return target.activeApp().inspectAll(UIAQuery.Parsec.SEARCH_RESULTS_SECTION.children()).map(function(n) {return n.name;}); },

    Alerts : {
        OPEN_ITUNES     :       UIAQuery.alerts().contains('Open this page in'),

    },

};

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Other Constants                                                                */
/*                                                                                        */
/*      Any other app specific constants                                                  */
/*                                                                                        */
/******************************************************************************************/
Parsec = new Object();
Parsec.Domain = {
    ITUNES_TV       :   "TV EPISODE ON ITUNES",
    ITUNES_SHOW     :   "TV SHOW ON ITUNES",
    ITUNES_SONG     :   "SONG ON ITUNES",
    ITUNES_ARTIST   :   "ARTIST ON ITUNES",
    ITUNES_ALBUM    :   "ALBUM ON ITUNES",
    ITUNES_MOVIE    :   "MOVIE ON ITUNES",
    ITUNES_AUDIOBOOK:   "AUDIOBOOK ON ITUNES",
    ITUNES_VIDEO    :   "MUSIC VIDEO ON ITUNES",
    ITUNES_PODCAST  :   "PODCAST ON ITUNES",
    ITUNES_STORE    :   "ITUNES STORE",
    APPS            :   "APP STORE",
    WIKI            :   "WIKIPEDIA",
    NEWS            :   "NEWS",
    SHOWTIMES       :   "NOW PLAYING IN THEATERS",
    MOVIE           :   "MOVIES",
    WEBSITE         :   "SUGGESTED WEBSITE",
    MAPS            :   "MAPS",
    WEB             :   "FROM THE WEB",
    BING            :   "BING SEARCH",
    IBOOKS          :   "IBOOKS STORE",
    TWITTER         :   "TWITTER",
    TV_SHOW         :   "TV SHOW",
    TV_SEASON       :   "TV SEASON",
    TV_EPISODE      :   "TV EPISODE",
    ON_DEMAND_MOVIE :   "MOVIES",
    STOCKS          :   "STOCKS",
    SPORTS          :   "SPORTS",
    WEATHER         :   "WEATHER",
    WEB_VIDEOS      :   "WEB VIDEOS",
    APP_HIST_CLOCK  :   "CLOCK",
    PODCASTS        :   "PODCASTS",
    APPLE_MUSIC     :   "APPLE MUSIC",
    MUSIC           :   "MUSIC",
    TOP_HITS        :   "TOP HITS",
    LYRA            :   "LYRA",
    APPLICATIONS    :   "APPLICATIONS",
    CONTACTS        :   "CONTACTS",
    NOTES           :   "NOTES",
    CALENDAR        :   "CALENDAR",
    MAIL            :   "MAIL",
    REMINDERS       :   "REMINDERS",
    MESSAGES        :   "MESSAGES",
    PASSBOOK        :   "WALLET",
    SIRI_SUGGEST    :   "SIRI SUGGESTIONS",
    NEARBY          :   "NEARBY",
    CONVERSION      :   "CONVERSION",
    CALCULATOR      :   "CALCULATOR",

};

Parsec.DOMAIN_LIST = Object.keys(Parsec.Domain).map(function(n) {return Parsec.Domain[n]});
Parsec.DOMAIN_GROUP_LIST = Parsec.DOMAIN_LIST.map(function(n) {return n.split(" ").pop()});

Parsec.PAGELOAD_TIMEOUT = 60;
Parsec.RESULTS_TIMEOUT = 1;
Parsec.EXIT_CARD_BUTTONNAMES = ['Back', 'Cancel', 'Done'];

// Parsec screenshot settings
Parsec.SCREENSHOTS = new Object();
Parsec.SCREENSHOTS.Enabled = true;
Parsec.SCREENSHOTS.Directory = "/tmp/parsec_screenshots/";

Parsec.APPSATE = {};
Parsec.APPSATE.Deactivate = 'deactivate';
Parsec.APPSATE.Reactivate = 'reactivate';
Parsec.APPSATE.Quit = 'quit';

Parsec.USERACTION = {};
Parsec.USERACTION.Tap = 'tap';
Parsec.USERACTION.Peek = 'peek';
Parsec.USERACTION.Pop = 'pop';
Parsec.USERACTION.HomeButton = 'home_button';
Parsec.USERACTION.KeyboardGo = 'keyboard_go';
Parsec.USERACTION.Wait = 'wait';
Parsec.USERACTION.Delay = 'delay';
Parsec.USERACTION.ScrollUp = 'scroll_up';
Parsec.USERACTION.ScrollDown = 'scroll_down';
Parsec.USERACTION.SwipeLeft = 'swipe_left';
Parsec.USERACTION.Search = 'search';
Parsec.USERACTION.EvalAction = 'eval_action';
Parsec.USERACTION.ScrollToVisible = 'scroll_to_visible';
Parsec.USERACTION.PerformTask = 'perform_task';

Parsec.TEXT_SIRI_SUGGESTIONS = 'SIRI_SUGGESTIONS';


/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/


/**
 * Performs a search for the specified string
 *
 * @param {string} [searchString] - the string to search for
 * @param {int} [options.delay=0.3] - the interkey delay to use when typing in a search string
 * @param {object}  [options.enterTextOptions={}] - options to be passed onto the enterText action
 * @param {boolean}  [options.dismissSplashScreen=true] - flag to indicate whether or not dismiss Spotlight First Time Experience (FTE) splash
 * @param {string} [widget=""] - widget name if targeting a widget
 * @param {string} [deviceRegion=""] - desired device Region
 * @param {boolean}  [options.requiresEnterKey=false] - Spotlight requires enter to continue search with typed text.
 *                                                     - set to false if want to manually trigger the search via Search btn, of suggestion
 *                                                     - set to true to automatically press enter
 *
 * @returns {None}
 */
UIAApp.prototype.parsecSearch = function parsecSearch(searchString, options)
{
    options = UIAUtilities.defaults(options, {
        delay:0.3,
        enterTextOptions:{},
        dismissSplashScreen: true,
        widget: '',
        deviceRegion: '',
        requiresEnterKey: false
    });

    this.interKeyDelay = options.delay;

    if (this.name() === 'Safari') {
        this.enterURLSearchStr(searchString, {enterTextOptions:options.enterTextOptions});
    } else if (this.name() == 'Notes') {
        this.parsecLookup(searchString, options);
    } else if (this.name() == 'Mail') {
        this.parsecLookupHint(searchString, options);
    } else if (this.name() == 'Messages') {
        this.launchParsecImages(searchString, options);
    } else if (this.name() == 'News') {
        this.getToFollowing();
        this.search(searchString, options);
    } else if (options.widget) {
        if (options.deviceRegion) {
            settings.setDeviceRegion(options.deviceRegion);
        }
        this.enableWidgets([options.widget.toUpperCase()]);
        this.scrollToWidget(options.widget.toUpperCase());
    } else {
        this.search(searchString, {requiresEnterKey: options.requiresEnterKey, enterTextOptions:options.enterTextOptions});
    }
}

/**
 * Verifies the expected parsec domain appears and links to a valid page.
 * (Replaces verifyParsecResult and findParsecResult)
 *
 * @param {string} searchString - the string that was searched for
 * @param {array} expectedDomains - the expected parsec domains (one or more of Parsec.Domain.*).
 *                  The first domain result in the list is selected and verified.
 * @param {array} options.expectedDomainText - the expected domain name if different from the Parsec.Domain
 *                  category (e.g. Lyra)
 * @param {string} options.expectedString - string to validate after tapping parsec result
 * @param {bool} options.validatePunchout - whether to tap the first result in the domain and validate
 *                  app or card that appears
 * @param {array} options.expectedSubDomain - the expected sub domain behavior for a given result; e.g. the
 *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
 *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
 *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
 * @param {array} options.expectedDomainResults - array of array of results to check for under each expected domain
 * @param {array} options.topHit - indicates whether to check for the Top Hit domain if the expected domain
 *                  is not found
 * @param {string} options.parsecApiHost - the parsec server to query
 *
 * @returns {None} - throws an error if the view doesn't appear with the expected info or
 *                  if the script can't return to the original search results
 */
UIAApp.prototype.verifyParsecResult = function verifyParsecResult(searchString, expectedDomains, options)
{
    var options = UIAUtilities.defaults(options, {
        expectedDomainText:[],
        expectedString:null,
        validatePunchout:true,
        expectedSubDomain:[],
        expectedDomainResults:[],
        topHit:false,
        parsecApiHost:'api.smoot.apple.com',
    });

    var activeApp = this;

    var punchoutAlertHandler = function() {
        var app = target.activeApp();
        alertQuery = UIAQuery.Parsec.Alerts.OPEN_ITUNES; // "Open this page in "iTunes Store""? Cancel/Open
        if (alertQuery && app.exists(alertQuery)) {
            app.tap("Open");
            return true;
        }
        alertQuery = UIAQuery.alerts().withPredicate("name like[c] 'Add *" + options.expectedString + "* to *\?'");
        if (alertQuery && app.exists(alertQuery)) {
            app.tap("View");
            return true;
        }
        UIALogger.logWarning("Received unhandled alert: " + app.inspect(UIAQuery.alerts().isVisible()).name);
        return false
    }


    // Helper function to validate the parsec card appears, contains the correct navbar name,
    // and contains the expected string
    function expectParsecCard(navBarNames, expectedStr, buttonNames, body) {

        // Tap parsec result and wait for parsec card to appear
        if (body) {
            target.activeApp().waitForViewToAppear("controllerClass == 'SKUIStorePageSectionsViewController' || \
                controllerClass == 'SearchUICardViewController' || controllerClass == 'SUStorePageViewController' || \
                controllerClass == 'SPUISearchMoviesViewController'",
                Parsec.PAGELOAD_TIMEOUT, body);
        }

        try {
            if (navBarNames) {
                var predicate = [];
                for (var i = 0; i < navBarNames.length; i++) {
                    predicate.push("name contains[c] '" + navBarNames[i] + "' ");
                }
                predicate = predicate.join(' OR ');

                // Verify navbar exists
                var navBar = UIAQuery.navigationBars().withPredicate(predicate);
                target.activeApp().assertExists(navBar, 'Matching navigation bar not found');
            }

            // Verify string exists
            if (expectedStr) {
                var str = UIAQuery.withPredicate("name contains[c] '" + expectedStr + "'");
                target.activeApp().assertExists(str, "Could not find '" + expectedStr + "' in parsec card");
            }
        } finally {
            target.activeApp().captureParsecScreenshot(searchString + '_PunchOut');
            var predicate = [];
            for (var i = 0; i < buttonNames.length; i++) {
                predicate.push("name contains[c] '" + buttonNames[i] + "'");
            }
            predicate = predicate.join(' OR ');
            target.activeApp().tapIfExists(UIAQuery.buttons().withPredicate(predicate).isVisible().first());
        }

    }


    // Helper function to validate safari is opened and contains the expected string
    function expectSafari(expectedStr, body) {

        // Wait for the selected page to load
        target.activeApp().waitForWebPageLoaded(Parsec.PAGELOAD_TIMEOUT, body);

        // Verify Safari app is active
        UIAUtilities.assertEqual(target.activeApp().name(), 'Safari', 'Safari is not the active app');

        // Verify expected string appears on page
        if (expectedStr) {
            var str = UIAQuery.withPredicate("name contains[c] '" + expectedStr + "' OR value contains[c] '" + expectedStr + "'");
            target.activeApp().assertExists(str, "Could not find '" + expectedStr + "' on loaded webpage");
        }
    }


    // Helper function to validate maps is opened and contains the expected string (may be maps parsec card)
    function expectMaps(expectedStr, body) {

        // Wait for maps or maps card to load
        body();
        var query = UIAQuery.beginsWith('Map containing').orElse(UIAQuery.links('Open in Maps'));
        UIAUtilities.assert(target.activeApp().waitUntilPresent(query, Parsec.PAGELOAD_TIMEOUT), 'Maps placecard not found');

        // If parsec card, check and dismiss
        UIALogger.logMessage("active app = " + target.activeApp().name());
        if (target.activeApp().name() != 'Maps') {
            expectParsecCard(null, expectedStr, Parsec.EXIT_CARD_BUTTONNAMES);
        } else if (expectedStr) {
            // Verify expected string appears on page
            var str = UIAQuery.withPredicate("any identifiers contains[c] '%0' || value contains[c] '%0'".format(expectedStr));
            target.activeApp().assertExists(str, "Could not find '%0' on map or placecard".format(expectedStr));
        }
    }

    // Helper function to validate stocks is opened and contains the expected string
    function expectStocks(expectedStr, body) {

        // Wait for stocks app to become active
        stocks.waitToBecomeActive(Parsec.PAGELOAD_TIMEOUT, body);
        UIALogger.logMessage("active app = " + target.activeApp().name());

        if (expectedStr) {
            // Verify expected string appears on page
            var str = UIAQuery.withPredicate("name contains[c] '" + expectedStr + "'");
            target.activeApp().assertExists(str, "Could not find '" + expectedStr + "' in stocks app");
        }
    }


    function expectApp(bundleID, expectedStr, body) {
        var app = target.appWithBundleID(bundleID);
        target.activeApp().withAlertHandler(punchoutAlertHandler, function() {
            UIALogger.logDebug("expected app = " + app.name());
            app.waitToBecomeActive(Parsec.PAGELOAD_TIMEOUT, body);
            // app.waitForViewToDisappear("controllerClass == 'SBIconController'", Parsec.PAGELOAD_TIMEOUT, body);
        });

        UIAUtilities.assert(app === target.activeApp(), "Expected app " + app.name() + ", but current app is " + target.activeApp().name());
        UIALogger.logMessage("active app = " + target.activeApp().name());

        // Check for and dismiss 'What's New' or 'Welcome to' screen before validating expected data
        var dismissWelcomeScreenQuery = UIAQuery.buttons().withPredicate("name contains[c] 'Continue' || name contains[c] 'Not Now'");
        if (target.activeApp().exists(dismissWelcomeScreenQuery)) {
            target.activeApp().tap(dismissWelcomeScreenQuery);
        }

        if (expectedStr) {
            var str = UIAQuery.withPredicate("any identifiers contains[c] '%0'".format(expectedStr)).isVisible();
            target.activeApp().withMaximumSnapshotBreadth(999, function () {
                target.activeApp().assertExists(str, "Could not find '%0' in %1 app".format(expectedStr, target.activeApp().name()));
            });
        }
    }


    // get displayed parsec results
    var parsecResults = this.parsecResultsQuery(expectedDomains, {additionalDomains: options.expectedDomainText});
    this.captureParsecScreenshot(searchString + '_SearchResult');
    var topHit = options.topHit && Parsec.Domain.TOP_HITS in parsecResults;

    UIALogger.logMessage("Expected Domains: " + expectedDomains);

    for (var i = 0; i < expectedDomains.length; i++) {

        // Lyra domains are the name of the app the results are linked to, so will need to
        // validate against the expectedDomainText instead of the expected domain
        if (expectedDomains[i].toUpperCase() === Parsec.Domain.LYRA) {
            UIAUtilities.assert(options.expectedDomainText[i].toUpperCase() in parsecResults,
                "Query did not yield expected Lyra domain '" + options.expectedDomainText[i] + "'");

            // Set the domain to the expected domain or TOP HITS if expected domain is not in the results
            var domainSnapshot = parsecResults[options.expectedDomainText[i].toUpperCase()];

        } else {
            // fail if there isn't a match for our expected domain
            UIAUtilities.assert(expectedDomains[i].toUpperCase() in parsecResults || topHit,
                "Query did not yield expected domain '" + expectedDomains[i] + "'");

            // Set the domain to the expected domain or TOP HITS if expected domain is not in the results
            var domainSnapshot = parsecResults[expectedDomains[i].toUpperCase()] || parsecResults[Parsec.Domain.TOP_HITS];
        }

        var elemToTap = domainSnapshot.first();

        // verify each of the expected domain results, if specified
        if (options.expectedDomainResults && options.expectedDomainResults[i] && options.expectedDomainResults[i].length > 0) {
            for (var idx = 0; idx < options.expectedDomainResults[i].length; idx++) {
                this.assertExists(domainSnapshot.children().withPredicate("any identifiers contains[c] '%0'".format(options.expectedDomainResults[i][idx])));
                elemToTap = domainSnapshot.children().withPredicate("any identifiers contains[c] '%0'".format(options.expectedDomainResults[i][idx])).first();
            }
        }

        if (options.validatePunchout) {
            // if a sub domain is specified for this domain, then that's what should determine punchout behavior below
            if (options.expectedSubDomain[i]) {
                expectedDomains[i] = options.expectedSubDomain[i];
            }

            // get the snapshot for the expected domain
            var curApp = this;
            var tapParsecFunc = function() {
                curApp.withAlertHandler(punchoutAlertHandler, function () {
                    curApp.tap(elemToTap);
                });
            }

            // select the first parsec result and verify card/page is loaded
            switch (expectedDomains[i].toUpperCase()) {
                // Parsec card, no nav bar name
                case Parsec.Domain.TV_EPISODE:
                case Parsec.Domain.TV_SHOW:
                case Parsec.Domain.TV_SEASON:
                case Parsec.Domain.ON_DEMAND_MOVIE:
                case Parsec.Domain.ITUNES_ARTIST:
                case Parsec.Domain.ITUNES_SONG:
                case Parsec.Domain.ITUNES_ALBUM:
                case Parsec.Domain.APPLE_MUSIC:
                    try {
                        expectParsecCard(null, options.expectedString, Parsec.EXIT_CARD_BUTTONNAMES, tapParsecFunc);
                    } finally {
                        this.getToParsecSearchResults();
                    }
                    break;
                // Parsec card if Spotlight with navbar name matching last part of domain or expectedString, otherwise iTunes Store
                case Parsec.Domain.ITUNES_TV:
                case Parsec.Domain.ITUNES_MOVIE:
                case Parsec.Domain.ITUNES_AUDIOBOOK:
                case Parsec.Domain.ITUNES_VIDEO:
                case Parsec.Domain.ITUNES_PODCAST:
                case Parsec.Domain.ITUNES_SHOW:
                case Parsec.Domain.APPS:
                case Parsec.Domain.IBOOKS:
                    try {
                        expectParsecCard([expectedDomains[i].split(" ").pop(), options.expectedString, 'iBooks Store'], options.expectedString, Parsec.EXIT_CARD_BUTTONNAMES, tapParsecFunc);
                    } finally {
                        this.getToParsecSearchResults();
                    }
                    break;
                // Parsec card if Spotlight without navbar name, otherwise Safari
                case Parsec.Domain.WIKI:
                    try {
                        if (this.name() === 'Safari') {
                            expectSafari(options.expectedString, tapParsecFunc);
                        } else {
                            expectParsecCard(null, options.expectedString, Parsec.EXIT_CARD_BUTTONNAMES, tapParsecFunc);
                        }
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Parsec card if Spotlight with navbar name matching last part of domain or expectedString, otherwise Safari
                case Parsec.Domain.SHOWTIMES:
                    try {
                        if (this.name() === 'Safari') {
                            try {
                                expectSafari(options.expectedString, tapParsecFunc);
                            } finally {
                                this.captureParsecScreenshot(searchString + '_PunchOut');
                            }
                        } else {
                            expectParsecCard([expectedDomains[i].split(" ").pop(), options.expectedString], options.expectedString, Parsec.EXIT_CARD_BUTTONNAMES, tapParsecFunc);
                        }
                    } finally {
                        this.getToParsecSearchResults();
                    }
                    break;
                // Safari
                case Parsec.Domain.MOVIE:
                case Parsec.Domain.WEBSITE:
                case Parsec.Domain.WEB:
                case Parsec.Domain.BING:
                case Parsec.Domain.WEB_VIDEOS:
                case Parsec.Domain.LYRA:
                case Parsec.Domain.CONVERSION:
                    try {
                        expectSafari(options.expectedString, tapParsecFunc);
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Maps
                case Parsec.Domain.MAPS:
                    try {
                        expectMaps(options.expectedString, tapParsecFunc);
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Corresponding app if Spotlight, otherwise Safari
                case Parsec.Domain.NEWS:
                    try {
                        if (this.name() === 'Safari') {
                            expectSafari(options.expectedString, tapParsecFunc);
                        } else {
                            expectApp(this.bundleIDForDomain(expectedDomains[i].toUpperCase()), "", tapParsecFunc);
                        }
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Corresponding app if iPhone (app doesn't exist on iPad), otherwise Safari
                case Parsec.Domain.STOCKS:
                case Parsec.Domain.WEATHER:
                    try {
                        if (target.model() === 'iPad') {
                            expectSafari(options.expectedString, tapParsecFunc);
                        } else {
                            expectApp(this.bundleIDForDomain(expectedDomains[i].toUpperCase()), options.expectedString, tapParsecFunc);
                        }
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Expect app
                case Parsec.Domain.APP_HIST_CLOCK:
                case Parsec.Domain.PODCASTS:
                case Parsec.Domain.MUSIC:
                case Parsec.Domain.CONTACTS:
                case Parsec.Domain.NOTES:
                case Parsec.Domain.CALENDAR:
                case Parsec.Domain.MAIL:
                case Parsec.Domain.REMINDERS:
                case Parsec.Domain.MESSAGES:
                case Parsec.Domain.PASSBOOK:
                case Parsec.Domain.CALCULATOR:
                    try {
                        expectApp(this.bundleIDForDomain(expectedDomains[i].toUpperCase()), options.expectedString, tapParsecFunc);
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                // Whether card or safari depends on whether the parsec result has card_sections
                case Parsec.Domain.TWITTER:
                case Parsec.Domain.SPORTS:
                    try {
                        if (this.parsecResultHasCardSections(options.parsecApiHost, searchString, expectedDomains[i])) {
                            expectParsecCard(null, options.expectedString, Parsec.EXIT_CARD_BUTTONNAMES, tapParsecFunc);
                        } else {
                            expectSafari(options.expectedString, tapParsecFunc);
                        }
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.getToParsecSearchResults();
                    }
                    break;
                case Parsec.Domain.SIRI_SUGGEST:
                    try {
                        var appName = this.inspect(elemToTap).name.split(',')[0].trim();
                        UIALogger.logMessage("Selecting App '%0'".format(appName));
                        expectApp(this.bundleIDForDomain(appName.toUpperCase(), {'appName':appName}), options.expectedString, tapParsecFunc);
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.launch();
                    }
                    break;
                case Parsec.Domain.NEARBY:
                    try {
                        var expectedString = this.inspect(elemToTap).name.split(',')[0].trim();
                        UIALogger.logMessage("Performing maps search on '%0'".format(expectedString));
                        expectMaps(expectedString, tapParsecFunc);
                        target.activeApp().assertExists(UIAQuery.query('BrowseSplitView'));
                    } finally {
                        this.captureParsecScreenshot(searchString + '_PunchOut');
                        this.launch();
                    }
                    break;
                default:
                    UIALogger.logError("Unexpected domain: " + expectedDomains[i]);
                    throw new UIAError("Unexpected domain: " + expectedDomains[i]);
                    break;
            }
        }
    }
}

/**
 * Returns the bundle ID of the punch-out app for the given domain.
 *
 * @param {string} domain - the domain under test
 * @param {string} options.appName - the original unchanged app name
 *
 * @returns {string} the bundle id of the app the domain punches out to.
 */
UIAApp.prototype.bundleIDForDomain = function bundleIDForDomain(domain, options)
{
    var options = UIAUtilities.defaults(options, {
        appName:domain,
    });

    switch (domain) {
        case Parsec.Domain.STOCKS:
            return 'com.apple.stocks';
        case Parsec.Domain.WEATHER:
            return 'com.apple.weather';
        case Parsec.Domain.APPS:
            return 'com.apple.AppStore';
        case Parsec.Domain.IBOOKS:
            return 'com.apple.iBooks';
        case Parsec.Domain.ITUNES_ARTIST:
        case Parsec.Domain.ITUNES_TV:
        case Parsec.Domain.ITUNES_SONG:
        case Parsec.Domain.ITUNES_ALBUM:
        case Parsec.Domain.ITUNES_MOVIE:
        case Parsec.Domain.ITUNES_AUDIOBOOK:
        case Parsec.Domain.ITUNES_VIDEO:
        case Parsec.Domain.ITUNES_SHOW:
            return 'com.apple.MobileStore';
        case Parsec.Domain.ITUNES_PODCAST:
            return 'com.apple.podcasts';
        case Parsec.Domain.APP_HIST_CLOCK:
            return 'com.apple.mobiletimer';
        case Parsec.Domain.PODCASTS:
            return 'com.apple.podcasts';
        case Parsec.Domain.MUSIC:
        case Parsec.Domain.ITUNES_VIDEO:
            return 'com.apple.Music';
        case Parsec.Domain.NEWS:
            return 'com.apple.news';
        case Parsec.Domain.CONTACTS:
            return 'com.apple.MobileAddressBook';
        case Parsec.Domain.NOTES:
            return 'com.apple.mobilenotes';
        case Parsec.Domain.CALENDAR:
            return 'com.apple.mobilecal';
        case Parsec.Domain.MAIL:
            return 'com.apple.mobilemail';
        case Parsec.Domain.REMINDERS:
            return 'com.apple.reminders';
        case Parsec.Domain.MESSAGES:
            return 'com.apple.MobileSMS';
        case Parsec.Domain.PASSBOOK:
            return 'com.apple.Passbook';
        case Parsec.Domain.CALCULATOR:
            return 'com.apple.calculator';
        default:
            return findBundleID(options.appName);
    }

    // Attempt to derive the bundleID from the app's name
    function findBundleID(domain) {
        // Try all variations of the domain name alone
        var domainVariations = [domain, domain.toLowerCase(), domain.toUpperCase()];
        // Try all variations of 'mobile'  + the domain name
        var mobileVariations = ['', 'mobile', 'Mobile'];
        for (var i = 0; i < domainVariations.length; i++) {
            for (var j = 0; j < mobileVariations.length; j++) {
                var bundleID = 'com.apple.%0%1'.format(mobileVariations[j], domainVariations[i]);
                var app = target.appWithBundleID(bundleID);
                if (app.name() && app.name().toLowerCase() === domain.toLowerCase()) {
                    return bundleID;
                }
            }
        }
        throw new UIAError("Could not determine bundle id for domain '%0'".format(domain))
    }
}

/**
 * Extracts the results from the spotlight or safari search tables and categorizes them
 * by domain.
 * (Replaces parsecGetUIResults)
 *
 * @param {array} domains - optional domains to wait for before collecting all results
 * @param {array} options.additionalDomains - additional domains to check that aren't included in Parsec.Domain
 *              (e.g. apps for Lyra)
 * @param {bool} options.andQuery - whether to look for all domains (true) or any domains (false)
 * @param {int} options.timeout - how long to wait for query to match
 *
 * @returns {Object} an associative array of result snapshots keyed by the parsec RESULT_TYPES
 */
UIAApp.prototype.parsecResultsQuery = function parsecResultsQuery(domains, options)
{
    options = UIAUtilities.defaults(options, {
        additionalDomains:[],
        andQuery:false,
        timeout:10,
    });

    if (!domains) {
        domains = [];
    }
    domains = domains.concat(options.additionalDomains)
    var predicate = [];
    for (var i = 0; i < domains.length; i++) {
        predicate.push("name contains[c] '" + domains[i] + "'");
    }
    if (predicate.length > 0) {
        if (options.andQuery) {
            this.waitUntilPresent(UIAQuery.withPredicate(predicate.join(" && ")).isVisible(), options.timeout);
        } else {
            this.waitUntilPresent(UIAQuery.withPredicate(predicate.join(" || ")).isVisible(), options.timeout);
        }
    }

    var sectionNames = UIAQuery.Parsec.SEARCH_RESULTS_SECTION_NAMES;
    var parsecResults = new Object();

    var allDomains = Parsec.DOMAIN_LIST.concat(options.additionalDomains.map(function(n) {return n.toUpperCase();}));
    for (var i = 0; i < sectionNames.length; i++) {
        UIALogger.logMessage("Parsec result: " + sectionNames[i]);
        // check if parsec name is in DOMAIN_LIST and add it to the results object
        for (var j = 0; j < allDomains.length; j++) {
            if (sectionNames[i].toUpperCase().indexOf(allDomains[j]) > -1) {
                parsecResults[allDomains[j]] = UIAQuery.tableViews().isVisible().andThen((UIAQuery.tableCells().below(sectionNames[i]).above('UITableViewSectionElement')).orElse(UIAQuery.tableCells().below(sectionNames[i])));
                break;
            }
        }
    }

    return parsecResults;
}


/**
 * Alternates between typing characters of query string and retrieving the resulting domain info.
 *
 * @param {string} query - the string to type in spotlight or safari
 * @param {array} domains - domains to wait for before collecting all results (pass [] to skip the check)
 * @param {int} options.startLength - how many characters of the string to type before the first check
 *
 * @returns {Object} an associative array of parsec results keyed by each substring of query
 */
UIAApp.prototype.parsecDomainsWhileTyping = function parsecDomainsWhileTyping(query, domains, options)
{
    options = UIAUtilities.defaults(options, {
        startLength:3,
    });

    var str = query.substring(0,options.startLength);
    var i = options.startLength;
    var resultsDict = new Object();

    // Perform initial substring search
    this.parsecSearch(str);

    // Collect the search results and type one more character of the string
    do {
        resultsDict[str] = this.parsecResultsQuery(domains, {andQuery:true, timeout:Parsec.RESULTS_TIMEOUT});
        this.typeString(query[i]);
        i++;
        str = query.substring(0, i);
    } while (i < query.length)

    resultsDict[str] = this.parsecResultsQuery(domains, {andQuery:true, timeout:Parsec.RESULTS_TIMEOUT});

    return resultsDict;
}

/**
 * Performs a search for the specified string and validates the specified domain appears
 *
 * @param {string} searchString - the string to search for
 * @param {string} domain - the expected domain
 * @param {object} options - a dictionary object of optional arguments
 * @param {object} [options.enterTextOptions={}] - options to be passed onto the enterText action
 * @param {bool} [options.checkTopHitDomain=false] - if a result is designated a 'Top Hit' it will appear under the
 *                  the Top Hit header instead of under it's specific domain; checkTopHitDomain indicates whether
 *                  to check for Top Hit if the expected domain is not found
 * @param {array} [options.domainContents=[]] - a list of strings to query for under a given domain
 * @param {bool} [options.cancelSearch=false] - whether to tap the Cancel button after performing/validating a search
 * @param {bool} [options.shouldDumpFeedback=false] - whether to use parsec_tool to dump feedback data after performing a query
 * @param {int} [options.timeout=30] - the max amount of time to wait for a result to display after typing the query
 * @param {bool} [args.shouldEngageResult=false] - whether to tap the first matching parsec result
 * @param {boolean}  [options.requiresEnterKey=false] - Spotlight requires enter to continue search with typed text.
 *                                                     - set to false if want to manually trigger the search via Search btn, or suggestion
 *                                                     - set to true to automatically press enter
 * @returns {None}
 *
 * @throws If we don't find the expected domain
 */
UIAApp.prototype.quickSearchAndValidateDomain = function quickSearchAndValidateDomain(searchString, domain, options) {
    options = UIAUtilities.defaults(options, {
        enterTextOptions: {setValueToEnterText:false, setValueIfValueDoesNotMatch:true},
        checkTopHitDomain: false,
        domainContents: [],
        cancelSearch: false,
        shouldDumpFeedback: false,
        timeout: 30,
        shouldEngageResult: false,
        requiresEnterKey: false,
    });

    try {
        // Search for domain (or optionally top hit)
        var domainQuery = UIAQuery.withPredicate("name contains[c] '%0'".format(domain));
        var query = domainQuery = UIAQuery.Parsec.SEARCH_RESULTS_SECTION.andThen(domainQuery);

        var topHitQuery;
        if (options.checkTopHitDomain) {
            topHitQuery = UIAQuery.withPredicate("name contains[c] 'Top Hit'");
            topHitQuery = UIAQuery.Parsec.SEARCH_RESULTS_SECTION.andThen(topHitQuery);
            query = domainQuery.orElse(topHitQuery);
        }
        this.parsecSearch(searchString, {requiresEnterKey: options.requiresEnterKey, delay:0.0, enterTextOptions:options.enterTextOptions});
        UIAUtilities.assert(this.waitUntilPresent(query, options.timeout), "Unable to find domain '%0'".format(domain));

        // Optionally search the contents beneath the domain
        if (options.domainContents) {
            UIALogger.logMessage('Checking domain contents for %0'.format(options.domainContents));
            for (var i = 0; i < options.domainContents.length; i++) {
                var domainStringQuery = UIAQuery.withPredicate("any identifiers contains[c] '%0'".format(options.domainContents[i]));
                var domainNextSectionQuery = UIAQuery.query('UITableViewSectionElement').below(domainQuery).first();
                var domainContentsQuery = domainStringQuery.below(domainQuery).above(domainNextSectionQuery);
                if (options.checkTopHitDomain) {
                    var topHitNextSectionQuery = UIAQuery.query('UITableViewSectionElement').below(topHitQuery).first();
                    domainContentsQuery = domainContentsQuery.orElse(domainStringQuery.below(topHitQuery).above(topHitNextSectionQuery));
                }

                // Check the domain contents before scrolling in case it's a Top Hits match
                // If no match then scroll to the matching section header and check again
                // (Workaround for <rdar://problem/25368009> Coordinates for off-screen Spotlight results section headers are all zero.)
                if (!this.waitUntilPresent(domainContentsQuery, options.timeout)) {
                    this.scrollToVisibleIfExists(domainQuery);
                    UIAUtilities.assert(this.waitUntilPresent(domainContentsQuery, options.timeout),
                    "Unable to find '%0' under domain '%1' or 'Top Hit'".format(options.domainContents[i], domain));
                }
            }
        }

        if (options.shouldEngageResult) {
            var itemToTap;
            if (typeof domainContentsQuery !== 'undefined') {
                itemToTap = domainContentsQuery.first();
            } else {
                var domainNextSectionQuery = UIAQuery.query('UITableViewSectionElement').below(domainQuery).first();
                var domainContentsQuery = UIAQuery.tableCells().below(domainQuery).above(domainNextSectionQuery);
                if (options.checkTopHitDomain) {
                    var topHitNextSectionQuery = UIAQuery.query('UITableViewSectionElement').below(topHitQuery).first();
                    domainContentsQuery = domainContentsQuery.orElse(UIAQuery.tableCells().below(topHitQuery).above(topHitNextSectionQuery));
                }
                itemToTap = domainContentsQuery.first();
            }
            this.tap(itemToTap);
        }
    } catch (e) {
        UIALogger.logError(e);
        UIALogger.logMessage("Actual search results: \n%0".format(tree(UIAQuery.tableViews().isVisible())));
        throw e;
    } finally {
        if (options.shouldEngageResult) {
            this.getToParsecSearchResults();
        }

        // Optionally cancel the search after validation is complete to force feedback to be sent by client.
        // Note, this will slow things down since the script will have to re-enter spotlight or the safari
        // search field for each query
        if (options.cancelSearch) {
            this.tapIfExists(UIAQuery.CANCEL_BUTTON);
        }

        // Force CoreParsec to dump feedback
        if (options.shouldDumpFeedback) {
            var task = target.performTask("/usr/local/bin/parsec_tool", ["feedback", "-dump"]);
            if (task.exitCode) {
                UIALogger.logError(task.stderr);
            } else {
                UIALogger.logDebug(task.stdout);
            }
        }
    }
}

/**
 * Iterates through a list of search objects, consisting of the search string and
 * expected domain and returns the results as an array of objects.
 * Note: doesn't currently support Top Hit domain option
 *
 * @param {array} searchData - array of search objects; each object consists of a
 *      'query' string and the expected 'domain', e.g.
 *      [{"query":"nelson mandela","domain":"Wikipedia"},{"query":"sfo maps","domain":"Maps"}]
 *      Each object can optionally include the 'topHit' bool to indicate whether to search for a Top Hit
 *      if the expected domain isn't found and the 'domainContents' array which consists of strings
 *      to search for under the matched domain.
 * @param {bool} [options.cancelSearch=false] - whether to tap the Cancel button after performing/validating a search
 * @param {bool} [options.shouldDumpFeedback=false] - whether to use parsec_tool to dump feedback data after performing a query
 * @param {int} [options.timeout=30] - the max amount of time to wait for a result to display after typing the query
 * @param {bool} [args.shouldEngageResult=false] - whether to tap the first matching parsec result
 * @param {boolean}  [options.requiresEnterKey=false] - Spotlight requires enter to continue search with typed text.
 *                                                     - set to false if want to manually trigger the search via Search btn, or suggestion
 *                                                     - set to true to automatically press enter
 *
 * @returns {array} - the results array for each search performed consisting of the 'query',
 *      expected 'domain', whether it passed or failed ('pass'), and the 'error' if failed, e.g.
 *      [{"query":"nelson mandela","domain":"Wikipedia","pass":true},{"query":"sfo maps","domain":"Maps",
 *      "pass":false,"error":"Did not find expected domain 'Maps' for query 'sfo maps'"}]
 */
UIAApp.prototype.validateDomainList = function validateDomainList(searchData, options) {
    options = UIAUtilities.defaults(options, {
        cancelSearch: false,
        shouldDumpFeedback: false,
        timeout: 30,
        shouldEngageResult: false,
        requiresEnterKey: false,
    });

    var results = new Object();
    var allDomainsPassed = true;
    for (var i = 0; i < searchData.length; i++) {
        var uniqueDomain = searchData[i].domain;
        var domain;
        if (searchData[i].domain_text) {
            domain = searchData[i].domain_text;
        } else {
            domain = uniqueDomain;
        }
        var searchOptions = UIAUtilities.defaults(searchData[i], {
            checkTopHitDomain: false,
            domainContents: [],
            cancelSearch: options.cancelSearch,
            shouldDumpFeedback: options.shouldDumpFeedback,
            timeout: options.timeout,
            shouldEngageResult: options.shouldEngageResult,
            requiresEnterKey: options.requiresEnterKey,
        });

        results[uniqueDomain] = new Object();
        results[uniqueDomain].query = searchData[i].query;
        results[uniqueDomain].pass = true;
        results[uniqueDomain].time = Date.now();
        results[uniqueDomain].client = this.name() === 'SpringBoard' ? 'Spotlight' : this.name();
        try {
            this.quickSearchAndValidateDomain(searchData[i].query, domain, searchOptions);
        } catch (e) {
            results[uniqueDomain].pass = false;
            results[uniqueDomain].error = e.message;
            allDomainsPassed = false;
        }
    }
    return [results, allDomainsPassed];
}

/**
 * Performs a search for the specified string and verifies the expected domains appear.
 * (Replaces parsecSearchAndValidateResult)
 *
 * @param {string} searchString - the string to search for
 * @param {array} expectedDomains - the expected parsec domains (one or more of Parsec.Domain.*).
 * @param {array} options.qualifiers - array of search qualifiers for the search strings
 * @param {array} options.expectedDomainText - the expected domain name if different from the Parsec.Domain
 *                  category (e.g. Lyra)
 * @param {string} options.expectedString - string to validate after tapping parsec result
 * @param {real} options.delay - the inter key delay to use when typing the search string
 * @param {bool} options.validatePunchout - whether to tap the first result in the domain and validate
 *                  app or card that appears
 * @param {array} options.expectedSubDomain - the expected sub domain behavior for a given result; e.g. the
 *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
 *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
 *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
 * @param {array} options.expectedDomainResults - array of array of results to check for under each expected domain
 * @param {array} options.topHit - indicates whether to check for the Top Hit domain if the expected domain
 *                  is not found
 * @param {string} options.parsecApiHost - the parsec server to query
 * @param {boolean}  options.requiresEnterKey - Spotlight requires enter to continue search with typed text.
 *                                            - set to false if want to manually trigger the search via Search btn, or suggestion
 *                                            - set to true to automatically press enter
 *
 * @returns {None} throws an exception if expected domain(s) are not found
 */
UIAApp.prototype.parsecSearchAndValidate = function parsecSearchAndValidate(searchString, expectedDomains, options)
{
    options = UIAUtilities.defaults(options, {
        qualifiers:[],
        expectedDomainText:[],
        expectedString:'',
        delay:0.3,
        validatePunchout:true,
        expectedSubDomain:[],
        expectedDomainResults:[],
        topHit:false,
        parsecApiHost:'api.smoot.apple.com',
        requiresEnterKey: true,
    });

    // Search for string, appending qualifiers if needed, until a matching parsec result is found
    var errors = []
    do {
        try {
            this.parsecSearch(searchString, options);
            this.verifyParsecResult(searchString, expectedDomains, options);
            return true;
        } catch (e) {
            errors.push(e);
            this.captureParsecScreenshot(searchString + '_SearchFailed');
        }
        searchString += ' ' + options.qualifiers.pop();
    } while (options.qualifiers.length)

    // Only include unique errors
    errors = errors.filter(function (value,index,self) {return self.indexOf(value) === index;})
    throw new UIAError(errors.join('. '));
}


/**
 * Validates that one of the given strings returns the expected parsec domain.
 * (Replaces parsecValidateAreaAny)
 *
 * @param   {array} searchStrings - the list of strings to search for; once the expected domain appears, search ceases.
 * @param   {string} expectedDomain - the expected parsec domain (one of Parsec.Domain.*). The first result in the domain
 *                  is selected and verified
 * @param {string} options.expectedDomainText - the expected domain name if different from the Parsec.Domain
 *                  category (e.g. Lyra)
 * @param   {string} options.expectedStrings - string to validate after tapping parsec result
 * @param   {array} options.qualifiers - array of search qualifiers for the search strings
 * @param   {int} options.delay - the interkey delay to use when typing in a search string
 * @param   {string} options.ParsecApiHost - the parsec environment to test against (carry, test, production, etc)
 * @param   {bool} options.lookupMovies - use a 'showtimes' search to define searchStrings for MOVIE domain
 * @param {bool} options.validatePunchout - whether to tap the first result in the domain and validate
 *                  app or card that appears
 * @param {array} options.expectedSubDomain - the expected sub domain behavior for a given result; e.g. the
 *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
 *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
 *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
 * @param {array} options.expectedDomainResults - array of results to check for under the expected domain
 * @param {bool} options.localSearch - indicates whether this is a local or parsec search
 * @param {array} options.topHit - indicates whether to check for the Top Hit domain if the expected domain
 *                  is not found
 * @param {boolean}  options.requiresEnterKey - Spotlight requires enter to continue search with typed text.
 *                                            - set to false if want to manually trigger the search via Search btn, or suggestion
 *                                            - set to true to automatically press enter
 *
 * @returns {bool} - true if a matching domain is found in the UI, otherwise throws an exception
 */
UIAApp.prototype.validateParsecDomain = function validateParsecDomain(searchStrings, expectedDomain, options)
{
    options = UIAUtilities.defaults(options, {
        qualifiers:[],
        expectedDomainText:null,
        expectedStrings:[],
        delay:0.3,
        ParsecApiHost:'production',
        lookupMovies:false,
        validatePunchout:true,
        expectedSubDomain:null,
        expectedDomainResults:[],
        localSearch:false,
        topHit:false,
        requiresEnterKey: true,
    });

    var parsecApiHost = this.mapParsecEnvironmentToApiHost(options.ParsecApiHost);
    options.parsecApiHost = parsecApiHost;
    options.expectedDomainText = [options.expectedDomainText];

    this.interKeyDelay = options.delay;

    // If Domain is MOVIE and lookupMovies is true, then get showtimes domain from parsec server and set
    // searchStrings to the list of movie names
    if (options.lookupMovies) {
        var newSearchStrings = this.getMoviesInTheaters(parsecApiHost);
        if (newSearchStrings && newSearchStrings.length > 0) {
            UIALogger.logMessage("Setting searchStrings to " + newSearchStrings);
            searchStrings = newSearchStrings;
            options.expectedStrings = newSearchStrings;
        }
    }

    // expectedSubDomain and expectedDomainResults need to be passed as arrays to parsecSearchAndValidate
    if (options.expectedSubDomain && typeof options.expectedSubDomain !== 'object') {
        options.expectedSubDomain = [options.expectedSubDomain];
    }
    if (options.expectedDomainResults && options.expectedDomainResults.length > 0
        && typeof options.expectedDomainResults[0] !== 'object') {
        options.expectedDomainResults = [options.expectedDomainResults];
    }

    // Search for each string, appending qualifiers if needed, until a matching parsec result is found
    var errors = [];
    for (var i = 0; i < searchStrings.length; i++) {
        var searchString = searchStrings[i];
        if (options.expectedStrings && options.expectedStrings.length > 0) {
            if (options.expectedStrings[i]) {
                UIALogger.logDebug("Using " + options.expectedStrings[i] + " as expectedString");
                options.expectedString = options.expectedStrings[i];
            } else {
                UIALogger.logDebug("Using " + searchString + " as expectedString");
                options.expectedString = searchString;
            }
        }

        try {
            if (this.parsecSearchAndValidate(searchString, [expectedDomain], options)) {
                return true;
            }
        } catch (e) {
            UIALogger.logError(e);
            var error = e.message || e;

            // if domain wasn't found in UI, query api
            if (!options.localSearch && error.indexOf("Query did not yield expected domain") >= 0) {
                var url = this.mapTrainToParsecURL("https://"+parsecApiHost+"/search?q="+searchString.replace(/\s+/g, '+').replace(/#/g, '%23'));
                var httpQueryResult = UIAUtilities.httpQueryUrl(url, {timeout:20});

                // if the query failed, update error and run more diagnostics
                if (!httpQueryResult.success) {
                    error += "; api query failed.";
                    if (UIAUtilities.pingTest('8.8.8.8', 3, 10).packetsReceived > 0) {
                        var pingResult = UIAUtilities.pingTest(parsecApiHost, 3, 10);
                        if (pingResult.packetsReceived > 0) {
                            error += "; " + ((pingResult.packetsTransmitted || 0) - (pingResult.packetsReceived || 0)) + " ping failures against " + parsecApiHost;
                        } else {
                            error = "PARSEC SERVER DOWN? " + error + "; pinging " + parsecApiHost + " failed";
                        }
                    } else {
                        error = "NETWORK DOWN? " + error + "; pinging google failed";
                    }
                } else { // if the query succeeded, check and log the results
                    if (this.getExpectedParsecResult(httpQueryResult.responseText, expectedDomain)) {
                        error += "; expected domain found by querying " + parsecApiHost + ".";
                    } else {
                        error += "; successfully queried " + parsecApiHost +", but matching domain not found";
                    }
                }
            }
            errors.push(error);
        }
    }

    // Only include unique errors
    errors = errors.filter(function (value,index,self) {return self.indexOf(value) === index;})
    throw new UIAError(errors.join('. '));
}

/**
 * The main function for the parsec reliability tests for both safari and spotlight.
 * Picks a string from the searchStrings argument to use during the test. Searches that string n
 * number of times where n=iterations. Each time a search gets a result, the total and passes counters are both incremented.
 * Each time a search fails, but the server is successfully queried, total is incremented.
 * These results are then passed to munin (TBD - need UIALogger support) and then extracted by the report.
 * (Replaces parsecTestReliability)
 *
 * @param   {array} searchStrings - the list of strings to search for; once the expected domain appears, search ceases.
 * @param   {int} options.iterations - the number of times to repeat the search
 * @param   {int} options.delay - the interkey delay to use when typing in a search string
 * @param   {string} options.ParsecApiHost - the parsec environment to test against (carry, test, production, etc)
 *
 * @returns {bool} - true if a matching domain is found in the UI, otherwise throws an exception
 */
UIAApp.prototype.parsecTestReliability = function parsecTestReliability(searchStrings, options) {

    options = UIAUtilities.defaults(options, {
        iterations:3,
        delay:0.3,
        ParsecApiHost:'production',
    });

    // array shuffle helper function for randomizing search strings
    function shuffle(o) {
        for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
        return o;
    };

    var parsecApiHost = this.mapParsecEnvironmentToApiHost(options.ParsecApiHost);
    var searchStrings = shuffle(searchStrings);
    UIALogger.logDebug("Reordered search strings: " + searchStrings);

    function hasParsecResult(str) {
        var url = target.activeApp().mapTrainToParsecURL("https://"+parsecApiHost+"/search?q="
            + str.replace(/\s+/g, '+').replace(/#/g, '%23'));
        var queryResult = UIAUtilities.httpQueryUrl(url);
        if (queryResult.success) {
            return target.activeApp().parsecParseApiResult(queryResult.responseText).length > 0
        }
    };

    // Find a string which returns results from the API
    var foundString = false;
    for (var i = 0; i < searchStrings.length; i++) {
        var searchString = searchStrings[i];
        if (hasParsecResult(searchString)) {
            UIALogger.logMessage("Using search string '" + searchString + "'");
            foundString = true;
            break;
        }
    }

    if (!foundString) {
        throw new UIAError("None of the search strings are returning parsec results via the api");
    }

    var passes = 0, total = 0;

    // loop for each iteration (usually 10). Search and record results and update the pass and total counters as necessary
    for (var i = 0; i < options.iterations; i++) {
        UIALogger.logMessage("Attempt #" + (i+1) + " searching for '" + searchString + "'");
        this.parsecSearch(searchString);
        var parsecResults = this.parsecResultsQuery(null);
        if (Object.keys(parsecResults).length > 0) {
            passes++;
            total++;
        } else {
            if (hasParsecResult(searchString)) {
                total++;
            } else if (total === 0 && i >=4) {
                break; // stop if we can't hit the server after 5 tries
            }
        }
    }

    UIALogger.logMessage(
            "TEST RESULTS:\n\nTotal Results: " + total
            + "\nPassed Results: " + passes
            + "\n");

    // add the results as munin variables (Note, this is not quite supported yet... eta end of March-ish)
//     UIALogger.logInfo({
//         parsec_reliability_total: total,
//         parsec_reliability_passes: passes,
//         parsec_search_string: searchString
//     });


}

/**
 * Parses the response text (JSON) from a query to the parec server, logs each of the results,
 * and returns them as an array of parsec response objects.
 * (replaces parsecParseResult)
 *
 * @param   {string} responseText - the response text from the parsec query
 *
 * @returns {array} - an array of parsec results
 */
UIAApp.prototype.parsecParseApiResult = function parsecParseApiResult(responseText) {
    var d = [], ret = [];
    try {
        d = JSON.parse(responseText);
    } catch (e) {}
    for (var i=0; i<d.length; ++i) {
        var results = d[i].results;
        if (results) {
            for (var a =0; a<results.length; ++a) {
                var r = results[a];
                if (r) {
                    UIALogger.logMessage('Parsec Result: ' + r.section_header +  ' : ' + r.title);
                    ret.push(r);
                }
            }
        }
    }
    return ret;
}

/**
 * Parses the response text (JSON) from a query to the parsec server.
 * Returns true/false based on whether or not the given expectedResult was found in the results
 * (replace parsecParseAndLogResult)
 *
 * @param   {string} responseText - the response text from the parsec query
 * @param   {string} expectedResult - the expected result (string in domain header)
 *
 * @returns {object} the matching domain object if found, null otherwise
 */
UIAApp.prototype.getExpectedParsecResult = function getExpectedParsecResult(responseText, expectedResult) {

    var parsecResults = this.parsecParseApiResult(responseText);

    for (var i = 0; i < parsecResults.length; i++) {
        var domain = parsecResults[i].section_header;
        if (domain.toLowerCase().indexOf(expectedResult.toLowerCase()) > -1) {
            UIALogger.logDebug("Found expected domain in api response: " + expectedResult);
            return parsecResults[i]
        }
    }
    UIALogger.logDebug("Did not find expected domain in api response: " + expectedResult);
    return null
}


/**
 * Parses the response text (JSON) from a query to the parsec server.
 * Returns true/false based on whether or not result with a section_header matching
 * expectedResult contains the card_sections key (indicating whether punchout will
 * display the parsec card
 *
 * @param   {string} parsecApiHost - the server to query
 * @param   {string} query - the search string to use for the query
 * @param   {string} expectedResult - the expected result (string in domain header)
 *
 * @returns {bool} whether the matching result has the card_sections key
 */
UIAApp.prototype.parsecResultHasCardSections = function parsecResultHasCardSections(parsecApiHost, query, expectedResult) {

    parsecApiHost = parsecApiHost ? parsecApiHost : "api.smoot.apple.com";
    var url = this.mapTrainToParsecURL("https://"+parsecApiHost+"/search?q=" + query.replace(/\s+/g, '+').replace(/#/g, '%23')
        + "&locale=en-US");
    var httpQueryResult = UIAUtilities.httpQueryUrl(url, {timeout:20});
    var parsecResult = this.getExpectedParsecResult(httpQueryResult.responseText, expectedResult);

    return parsecResult ? (parsecResult.card_sections ? true : false) : false;

}


/**
 * Queries the SHOWTIMES domain and returns the list of movies currently playing in theaters
 *
 * @param   {string} parsecApiHost - the server from which to query the showtimes
 *
 * @returns {array} the array of movies currently playing in theaters or null if none found
 */
UIAApp.prototype.getMoviesInTheaters = function getMoviesInTheaters(parsecApiHost)
{
    parsecApiHost = parsecApiHost ? parsecApiHost : "api.smoot.apple.com";
    var url = this.mapTrainToParsecURL("https://"+parsecApiHost+"/search?q=showtimes&locale=en-US");
    var httpQueryResult = UIAUtilities.httpQueryUrl(url, {timeout:20});
    var showtimes = this.getExpectedParsecResult(httpQueryResult.responseText, Parsec.Domain.SHOWTIMES);
    if (showtimes && showtimes.description && showtimes.description.length > 0) {
        searchStrings = showtimes.description.split(",");
        if (searchStrings.length > 0 && searchStrings[0] && searchStrings[0] != " ") {
            return searchStrings.map(function(n) {return n.trim();});
        }
    }
    return null;
}


// /**
//  * Determines whether parsic card is in view
//  *
//  * @returns {bool} true if parsec card is showing, false otherwise
//  */
// UIAApp.prototype.isParsecCard = function isParsecCard() {

//     // Navbar name is one of the parsec domains?
//     var predicate = [];
//     for (var i = 0; i < Parsec.DOMAIN_GROUP_LIST.length; i++) {
//         predicate.push("name contains[c] '" + Parsec.DOMAIN_GROUP_LIST[i] + "' ");
//     }
//     predicate = predicate.join(' OR ');

//     // Verify navbar exists
//     var navBarQuery = UIAQuery.navigationBars().withPredicate(predicate).isVisible();
//     if (this.exists(navBarQuery)) {
//         return true;
//     }
//     return false
// }

/**
 *  Taps the appropriate nav bar button to close the parsec card.
 *
 */
UIAApp.prototype.exitParsecCard = function exitParsecCard() {
    var navBar = UIAQuery.navigationBars().isVisible();
    if (this.exists(navBar)) {
        UIALogger.logMessage("Attempting to exit the parsec card");
        for (var i = 0; i < Parsec.EXIT_CARD_BUTTONNAMES.length; i++) {
            var btn = navBar.andThen(UIAQuery.buttons().withPredicate("name contains[c] '" + Parsec.EXIT_CARD_BUTTONNAMES[i] + "'").isVisible());
            if (this.exists(btn)) {
                this.waitForViewToDisappear("controllerClass == 'MKPlaceInfoViewController' \
                    || controllerClass == 'SKRemoteProductViewController' || controllerClass == 'SBSearchWikipediaViewController' \
                    || controllerClass == 'SearchUICardViewController'",
                    Parsec.PAGELOAD_TIMEOUT, function() {this.tap(btn);});
                return;
            }
        }
    }
}

/**
 * Maps a parsec enviroment name to a server hostname.  Defaults to api-carry
 * (Replaces parsecMapParsecAPIHost)
 *
 * @param   {string} name - the name of the parsec environment
 *
 * @returns {string} the url of the matching api host
 */
UIAApp.prototype.mapParsecEnvironmentToApiHost = function mapParsecEnvironmentToApiHost(name) {
    name = name.split(':').pop();
    var production = 'api.smoot.apple.com';
    return ({
        'ci': 'api-ci.parsec.apple.com',
        'continuous integration': 'api-ci.parsec.apple.com',
        'continuous': 'api-ci.parsec.apple.com',
        'test': 'api-test.parsec.apple.com',
        'carry': 'api-carry.smoot.apple.com',
        'production/seed': production,
        'production': production,
        'seed': production,
        'smoot': production,
        'staging': 'api-stg.smoot.apple.com'
    })[name ? name.toLowerCase() : null] || production;
}

/**
 * Maps a train to the corresponding parsec url (determines key and agent)
 *
 * @returns {string} the updated url with 'agent' and 'key' added
 */
UIAApp.prototype.mapTrainToParsecURL = function mapTrainToParsecURL(url) {

    var isSafari = this.name() === 'Safari' ? true : false;
    var agent = (this.name() === 'Safari' ? 'safari' : 'spotlight') + '-'
        + (target.model() === 'iPad' ? 'ipad' : 'iphone');
    var userAgent = null;
    var build = target.systemBuild();
    var re = /([0-9]+)[A-Z]{1}.*/;
    var buildPrefix = re.exec(build)[1];
    if (buildPrefix && parseInt(buildPrefix) >= 13) {
        agent += '-'+build;
        url += '&agent='+agent+'&key=granite0323&locale=en-US';
        // userAgent = (isSafari ? "SafariShared/601.1.18 (" : "Parsec/1 (") + target.mobileGestaltQuery('ProductType')
        //     + "; " + target.systemName() + " " + build + ") " + (isSafari ? 'Safari/600.1.4' : 'Spotlight/1.0');
    } else {
        url += "&agent="+agent+'&key=andromeda&locale=en-US';
    }
    return url;
}

/**
 * Saves a screenshot of the current parsec view with given name
 *
 * @param {string} identifier Identifier to tag the screenshot file name with
 */
UIAApp.prototype.captureParsecScreenshot = function captureParsecScreenshot(identifier) {
    if (Parsec.SCREENSHOTS.Enabled) {
        performTask('/bin/mkdir', [Parsec.SCREENSHOTS.Directory]);
        var now = new Date();
        var screenName = Parsec.SCREENSHOTS.Directory + "Parsec_" + identifier + "_" + now.getTime() + ".png";
        UIATarget.localTarget().captureScreenWithName(screenName);
    }
}

/**
 * Determines the query required to select a search result in a Parsec search
 * result table. Returned query is dependent on options.searchCateogry and
 * options.searchPredicate. If null is give for both values we return
 * the first result in the list. If values is given for searchCateogry or/and
 * searchPredicate we used them to refind the result.
 *
 * Expected starting states: N/A. Non UI dependent.
 *
 * @param {null|string}     searchCategory - Category for search results. (example types: Suggested Website,
 *                                  On This Page, Goolge Search, Top Hit, ect)
 * @param {null|string}     searchPredicate - Predicate to search against the search results
 *                                  (example: "ANY identifiers == 'recursion'")
 *
 * @param {null|string}     resultIndex - result Index you want. Possible Value: First, Last, ANY INDEX
 *
 * @param {string}     widget - widget name if target is a widget
 *
 * @returns Query for link selection
 */
UIAApp.prototype.determineSearchResultQuery = function determineSearchResultQuery(options) {
    options = UIAUtilities.defaults(options, {
        searchCategory: null,
        searchPredicate: null,
        resultIndex: null,
        widget: '',
    });

    // no filter options, lets return the first result
    if (!options.searchCategory && !options.searchPredicate) {
        UIALogger.logMessage('Getting first displayed result of search.');
        return UIAQuery.tableViews().andThen(UIAQuery.tableCells());
    }

    // get a result at particular index under a category
    else if (options.searchCategory && options.resultIndex) {
        UIALogger.logMessage(
            'Getting result at position [%0] under category: %1'
            .format(options.resultIndex, options.searchCategory)
        );

        var resultsBelowCategory = UIAQuery.tableCells().below(options.searchCategory);

        // if more sections, limit list of results by the section boundary.
        var numSectionsAfterSearchCategory = this.count(UIAQuery.Parsec.SEARCH_RESULTS_SECTION.below(UIAQuery.tableViews().andThen(options.searchCategory)));
        if (numSectionsAfterSearchCategory > 0) {
            resultsBelowCategory = resultsBelowCategory.above(UIAQuery.Parsec.SEARCH_RESULTS_SECTION);
        }

        // Special Case for Spotlight Suggestions as they dont have section title
        // we will never have a real seciton title with a '_' so its safe.
        if (options.searchCategory == Parsec.TEXT_SIRI_SUGGESTIONS) {
            var second_section = UIAQuery.Parsec.SEARCH_RESULTS_SECTION.atIndex(0);
            resultsBelowCategory = UIAQuery.tableCells().above(second_section);
        }

        if (options.widget) {
            resultsBelowCategory = UIAQuery.query(options.searchCategory).parent().parent().parent().andThen(UIAQuery.tableCells());
        }

        if (options.resultIndex == 'first') {
            return resultsBelowCategory.first();
        } else if (options.resultIndex == 'last') {
            return resultsBelowCategory.last();
        }

        return resultsBelowCategory.atIndex(options.resultIndex);
    }

    // filter by predicate only
    else if (!options.searchCategory && options.searchPredicate) {
        UIALogger.logMessage(
            'Getting first search result with applied predicate: %0'
            .format(options.searchPredicate)
        );
        return UIAQuery.tableViews().andThen(UIAQuery.withPredicate(options.searchPredicate));
    }

    // filter by category and predicate if needed
    else {
        UIALogger.logMessage('Getting search result with category: %0'.format(options.searchCategory));

        // lets grab the elements in the cateogory
        var categoryQuery = UIAQuery.tableCells().below(UIAQuery.tableViews().andThen(options.searchCategory))

         // if more sections, limit list of results by the section boundary.
        var numSectionsAfterSearchCategory = this.count(UIAQuery.Parsec.SEARCH_RESULTS_SECTION.below(UIAQuery.tableViews().andThen(options.searchCategory)));
        if (numSectionsAfterSearchCategory > 0) {
            categoryQuery = categoryQuery.above(UIAQuery.Parsec.SEARCH_RESULTS_SECTION);
        }

        // Special Case for Spotlight Suggestions as they dont have section title
        // we will never have a real seciton title with a '_' so its safe.
        if (options.searchCategory == Parsec.TEXT_SIRI_SUGGESTIONS) {
            var second_section = UIAQuery.Parsec.SEARCH_RESULTS_SECTION.atIndex(0);
            categoryQuery = UIAQuery.tableCells().above(second_section);
        }

        if (options.widget) {
            categoryQuery = UIAQuery.query(options.searchCategory).parent().parent().parent().andThen(UIAQuery.tableCells());
        }

        if (options.searchPredicate) {
            UIALogger.logMessage('Applying predicate: %0'.format(options.searchPredicate));
            return categoryQuery.andThen(UIAQuery.withPredicate(options.searchPredicate));
        }

        return categoryQuery;
    }
}


