
load('UIAApp.js');
load('UIAApp+Camera.js');

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Localization Strings                                                           */
/*                                                                                        */
/*      A dictionary of localization look up strings                                      */
/*                                                                                        */
/******************************************************************************************/

LocStrings.MESSAGE_BODY = target.localizedString("body.label", {
                tableName:"Accessibility",
                bundlePath:"/System/Library/AccessibilityBundles/MessageUIFramework.axbundle",
});

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Query Constants                                                                */
/*                                                                                        */
/*      App specific queries that will be used frequently                                 */
/*                                                                                        */
/******************************************************************************************/

UIAQuery.MAIL_TO_FIELD = UIAQuery.textFields("toField");
UIAQuery.MAIL_CC_FIELD = UIAQuery.textFields("ccField");
UIAQuery.MAIL_BCC_FIELD = UIAQuery.textFields("bccField");
UIAQuery.MAIL_SUBJECT_FIELD = UIAQuery.textViews("subjectField");
UIAQuery.MAIL_MESSAGE_BODY = UIAQuery.textViews("Message body");

UIAQuery.MAIL_SEND_BUTTON = UIAQuery.buttons("Send");

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/

/**
 *  enterRecipientsForField - Enters multiple recipients into the specified field of the mail composition UI
 *
 *  @param {array} recipients - an array of recipients or account IDs to send the message to
 *  @param {UIAQuery} field - a UIAQuery for the field to enter recipients under (i.e. to, cc, bcc)
 **/
UIAApp.prototype.enterRecipientsForField = function enterRecipientsForField(recipients, field) {

    // Validate preconditions
    UIAUtilities.assert(recipients instanceof Array, 'No recipients specified to enter');

    this.tapIfExists(UIAQuery.staticTexts("Cc/Bcc, From:").isVisible());
    this.tap(field);

    // Enter recipients
    try {
        for (var recipientIndex = 0; recipientIndex < recipients.length; recipientIndex++) {
            var recipient = recipients[recipientIndex];
            if (recipient == null) {
                continue;
            }

            UIALogger.logMessage('Entering recipient "' + recipient + '"');
            this.enterText(field, recipient + '\n');
        }
    } catch (error) {
        throw new UIAError('Could not enter recipients:' + error.message);
    }
}

/**
 *  Sends an email. Assume's we're already on a mail composition view.
 *
 * @param {string}  recipients - an email address or an array of email addresses to send to
 * @param {object}  options - a dictionary object of optional arguments
 * @param {string}  options.cc - an email address or an array of email addresses to CC
 * @param {string}  options.bcc - an email address or an array of email addresses to BCC
 * @param {string}  options.subject - the subject of the email
 * @param {string}  options.body - the body of the email
 *
 */
UIAApp.prototype.composeEmail = function composeEmail(recipients, options) {
    var options = UIAUtilities.defaults(options, {
        cc: null,
        bcc: null,
        subject: null,
        body: null,
    });

    if (recipients == null || recipients.length == 0) {
        throw new UIAError("Cannot send an email without a recipient.");
    }

    if (recipients != null && !(recipients instanceof Array)) { recipients = [recipients]; }
    if (options.cc != null && !(options.cc instanceof Array)) { options.cc = [options.cc]; }
    if (options.cc != null && !(options.bcc instanceof Array)) { options.bcc = [options.bcc]; }

    // Enter recipients
    if (recipients != null && recipients.length > 0) {
        this.enterRecipientsForField(recipients, UIAQuery.MAIL_TO_FIELD);
    }

    // Enter cc
    if (options.cc != null && options.cc.length > 0) {
        this.enterRecipientsForField(options.cc, UIAQuery.MAIL_CC_FIELD);
    }

    // Enter bcc
    if (options.bcc != null && options.bcc.length > 0) {
        this.enterRecipientsForField(options.bcc, UIAQuery.MAIL_BCC_FIELD);
    }

    // Enter subject line
    if (options.subject != null) {
        this.enterText(UIAQuery.MAIL_SUBJECT_FIELD, options.subject)
    }

    // Enter message text
    if (options.body != null) {
        this.enterText(UIAQuery.MAIL_MESSAGE_BODY, options.body)
    }

    UIALogger.logDebug('Sending message');
    this.tap(UIAQuery.MAIL_SEND_BUTTON);

    if (this.exists(UIAQuery.VISIBLE_SHEETS)) {
        // workaround for <rdar://problem/18860367> Explicit delay needed for photos > emailPhoto
        target.delay(1);
        UIALogger.logDebug("Sending a small copy of the photo.")
        this.tap(UIAQuery.VISIBLE_SHEETS.andThen(UIAQuery.buttons().beginsWith("Small")));
    }
}

/**
 *  Checks to see if an email client is setup on the device. Once check is
 *  done, if an app reference is passed, we launch that app.
 *
 * @param {object} app (optional) - reference to app
 */
UIAApp.prototype.isEmailClientSetup = function isEmailClientSetup(app) {
    var retval = false;
    var mail = target.appWithBundleID('com.apple.mobilemail');
    mail.launch();

    if ( !mail.exists('Welcome to Mail') ) {
        retval = true;
    }

    if (app) {
        app.launch();
    }

    return retval;
}
