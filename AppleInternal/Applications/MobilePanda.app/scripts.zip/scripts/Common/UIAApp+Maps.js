load('UIAApp.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Localization Strings                                                */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/

/** MapKit.framework and MapKitFramework.axbundle Strings: */

/** Add to Existing Contact */
LocStrings.ADD_TO_EXISTING_CONTACT =    target.localizedString(
                                            'Add to Existing Contact',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Add to Favorites */
LocStrings.ADD_TO_FAVORITES =           target.localizedString(
                                            'Add to Favorites',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Subscribing (Favoriting) a Transit Line **/
LocStrings.ADD_TO_FAVORITES_IN_FOOTER_ACTION =  target.localizedString(
                                                    'Add to Favorites [Footer action]',
                                                    {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                                );

/** Address */
LocStrings.ADDRESS =                    target.localizedString(
                                            'Address',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Call */
LocStrings.CALL =                   target.localizedString(
                                        'Call',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** Compass */
LocStrings.COMPASS =                    target.localizedString(
                                            'COMPASS_BUTTON',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Create New Contact */
LocStrings.CREATE_NEW_CONTACT =     target.localizedString(
                                        'Create New Contact',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** DEPARTURES */
LocStrings.DEPARTURES =                 target.localizedString(
                                            'Departure_section_header',
                                            {tableName:'Caboose', bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Directions */
LocStrings.DIRECTIONS =                 target.localizedString(
                                            'Directions',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Directions Not Available */
LocStrings.DIRECTIONS_NOT_AVAILABLE =   target.localizedString(
                                            'Directions Not Available',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Driving time */
LocStrings.DRIVING_TIME =               target.localizedString(
                                            'DRIVING_TIME_FORMAT',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Favorite */
LocStrings.FAVORITE =               target.localizedString(
                                        'Add_Favorite_Actions_Row',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** Favorited */
LocStrings.FAVORITED =              target.localizedString(
                                        'Remove_Favorite_Actions_Row',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** Find out more on */
LocStrings.FIND_OUT_MORE_ON =       target.localizedString(
                                        'Find out more on %@ ',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/* This is part of the official app view on the placecard to get the app off the app store */
LocStrings.GET_IN_PLACECARD =       target.localizedString(
                                        'GET',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** Map marker */
LocStrings.DROPPED_MARKER =             target.localizedString(
                                            'Map pin',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** More photos */
LocStrings.MORE_PHOTOS =            target.localizedString(
                                        'More photos',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/** Flyover Tour */
LocStrings.FLYOVER_TOUR =               target.localizedString(
                                            'MAPS_CARD_FLYOVER_TOUR',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Located Inside */
LocStrings.LOCATED_INSIDE =             target.localizedString(
                                            'Located Inside',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Map containing */
LocStrings.MAP_CONTAINING =             target.localizedString(
                                            'MAP_CONTAINING',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );

/* Button title for Message in the placecard action row */
LocStrings.MESSAGE =                    target.localizedString(
                                            'Message',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/* 'More…' button that, when tapped, displays a list of transit information. */
LocStrings.MORE_ELLIPSIS =              target.localizedString(
                                            'More_ellipsis',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** More Info */
LocStrings.MORE_INFO =                  target.localizedString(
                                            'MORE_INFO',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** My Location */
LocStrings.MY_LOCATION =                target.localizedString(
                                            'My Location',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Open provider */
LocStrings.OPEN_PROVIDER =              target.localizedString(
                                            'PlaceCardSectionHeader',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Photos from */
LocStrings.PHOTOS_FROM =                target.localizedString(
                                            'REVIEW_PHOTO_WITH_PROVIDER_FORMAT_PLURAL',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );

/** time to drive to the location */
LocStrings.PLACECARD_ETA_DRIVING =      target.localizedString(
                                            'PlaceCard_ETA_Driving',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** time to use transit to the location */
LocStrings.PLACECARD_ETA_TRANSIT =      target.localizedString(
                                            'PlaceCard_ETA_Transit',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** time to walk to the location */
LocStrings.PLACECARD_ETA_WALKING =      target.localizedString(
                                            'PlaceCard_ETA_Walking',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Remove Favorite */
LocStrings.REMOVE_FAVORITE =            target.localizedString(
                                            'Remove Favorite',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Unsubscribing (UnFavoriting) a Transit Line **/
LocStrings.REMOVE_FROM_FAVORITES_IN_FOOTER_ACTION = target.localizedString(
                                                        'Remove from Favorites [Footer action]',
                                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                                    );

/** Share */
LocStrings.SHARE =                      target.localizedString(
                                            'Share_Action_Row',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Share Address */
LocStrings.SHARE_ADDRESS =               target.localizedString(
                                            'ADDRESS_SHARE_BUTTON',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Show All */
LocStrings.SHOW_ALL =                  target.localizedString(
                                            'Placecard Show all operating hours',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Show Today */
LocStrings.SHOW_TODAY =                target.localizedString(
                                            'Placecard Show operating hours today',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Tracking */
LocStrings.TRACKING =                   target.localizedString(
                                            'TRACKING_BUTTON_LABEL',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );

/** Tracking - Off */
LocStrings.TRACKING_OFF =               target.localizedString(
                                            'TRACKING_BUTTON_VALUE_OFF',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );

/** Tracking - On */
LocStrings.TRACKING_ON =                target.localizedString(
                                            'TRACKING_BUTTON_VALUE_ON',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );

/** Tracking - Heading */
LocStrings.TRACKING_ON_WITH_HEADING =   target.localizedString(
                                            'TRACKING_BUTTON_VALUE_ON_WITH_HEADING',
                                            {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/MapKitFramework.axbundle'}
                                        );
/** Tracking - Determining Location */
LocStrings.TRACKING_BUTTON_VALUE_PROGRESS = target.localizedString(
                                            'TRACKING_BUTTON_VALUE_PROGRESS',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Transit Advisory */
LocStrings.TRANSIT_ADVISORY =           target.localizedString(
                                            'Transit Advisory',
                                            {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                        );

/** Transit time */
LocStrings.TRANSIT_TIME =               target.localizedString(
                                            'TRANSIT_TIME_FORMAT',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Walking time */
LocStrings.WALKING_TIME =               target.localizedString(
                                            'WALKING_TIME_FORMAT',
                                            {tableName:"Accessibility", bundlePath:"/System/Library/AccessibilityBundles/MapKitFramework.axbundle"}
                                        );

/** Website */
LocStrings.WEBSITE =                target.localizedString(
                                        'Website',
                                        {bundlePath:'/System/Library/Frameworks/MapKit.framework'}
                                    );

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAQuery.MAP_VIEW       = UIAQuery.query('MKMapView'),
UIAQuery.MAP_VIEW_MUNIN = UIAQuery.query('MKMuninView').orElse(UIAQuery.withPredicate('controllerClassName == "MuninPIPViewController"')),

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Helpers                                                                        */
/*                                                                                        */
/*      Helper fnctions                                                                   */
/*                                                                                        */
/******************************************************************************************/

/**
 * Waits for 'TouchEventsCompleted' event after running function passed to it
 *
 * @param {function} Function to execute
 */
UIAApp.prototype.waitForTouchEvent = function waitForTouchEvent(func) {
    var touchEventsCompleted = UIAWaiter.waiter('TouchEventsCompleted');
    func.call(this);
    if (!touchEventsCompleted.wait(5)) {
        throw new UIAError('Touch events did not complete');
    }
};

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/

/**
 * Pans the mapview from the start to end offsets
 *
 * @param {UIAPoint} startOffset Point to start pan at
 * @param {UIAPoint} endOffset Point to end pan at
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
 **/
UIAApp.prototype.panMap = function panMap(startOffset, endOffset, inMuninView) {
    var panOptions = {};
    panOptions.touchCount = 1;
    panOptions.duration = 1.0;
    panOptions.startOffset = startOffset;
    panOptions.endOffset = endOffset;
    this.waitForTouchEvent(function() {
        if (inMuninView) {
            this.drag(UIAQuery.MAP_VIEW_MUNIN.isVisible(), panOptions);
        }
        else {
            this.drag(UIAQuery.MAP_VIEW.isVisible(), panOptions);
        }
    });
};

/**
 * Pan mapview down => finger up
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
**/
UIAApp.prototype.panMapDown = function panMapDown(inMuninView) {
    UIALogger.logMessage("Panning down...");
    this.waitForTouchEvent(function() {
        this.panMap({x:0.5, y:0.7}, {x:0.5, y:0.2}, inMuninView);
    });
};

/**
 * Pan mapview left => finger to the right
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
 **/
UIAApp.prototype.panMapLeft = function panMapLeft(inMuninView) {
    UIALogger.logMessage("Panning left...");
    this.waitForTouchEvent(function() {
        this.panMap({x:0.1, y:0.5}, {x:0.9, y:0.5}, inMuninView);
    });
};

/**
 * Pan mapview right => finger to the left
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
**/
UIAApp.prototype.panMapRight = function panMapRight(inMuninView) {
    UIALogger.logMessage("Panning right...");
    this.waitForTouchEvent(function() {
        this.panMap({x:0.9, y:0.5}, {x:0.1, y:0.5}, inMuninView);
    });
};

/**
 * Pan mapview up => finger down
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
 **/
UIAApp.prototype.panMapUp = function panMapUp(inMuninView) {
    UIALogger.logMessage("Panning up...");
    this.waitForTouchEvent(function() {
        this.panMap({x:0.5, y:0.2}, {x:0.5, y:0.9}, inMuninView);
    });
};

/**
 * Pinches the mapview close (zoom out)
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
 **/
UIAApp.prototype.pinchMapClose = function pinchMapClose(inMuninView) {
    this.waitForTouchEvent(function() {
        if (inMuninView) {
            this.pinchClose(UIAQuery.MAP_VIEW_MUNIN);
        }
        else {
            this.pinchClose(UIAQuery.MAP_VIEW);
        }
    });
};

/**
 * Pinches the mapview open (zoom in)
 *
 * @param {boolean} inMuninView False by default to target the main Maps view. Set to true to target the Munin view
 **/
UIAApp.prototype.pinchMapOpen = function pinchMapOpen(inMuninView) {
    this.waitForTouchEvent(function() {
        if (inMuninView) {
            this.pinchOpen(UIAQuery.MAP_VIEW_MUNIN);
        }
        else {
            this.pinchOpen(UIAQuery.MAP_VIEW);
        }
    });
};

/**
 * Pitches the mapview from the start to end offsets with 2 fingers
 *
 * @param {UIAPoint} startOffset Point to start pitch at
 * @param {UIAPoint} endOffset Point to end pitch at
 **/
UIAApp.prototype.pitchMap = function pitchMap(startOffset, endOffset) {
    var pitchOptions = {};
    pitchOptions.touchCount = 2;
    pitchOptions.duration = 1.0;
    pitchOptions.startOffset = startOffset;
    pitchOptions.endOffset = endOffset;
    this.waitForTouchEvent(function() {
        this.drag(UIAQuery.MAP_VIEW, pitchOptions);
    });
};

/**
 * Pitches the mapview down
 **/
UIAApp.prototype.pitchMapDown = function pitchMapDown() {
    UIALogger.logMessage("Pitching down...");
    this.waitForTouchEvent(function() {
        this.pitchMap({x:0.5, y:0.5}, {x:0.5, y:0.8});
    });
};

/**
 * Pitches the mapview up
 **/
UIAApp.prototype.pitchMapUp = function pitchMapUp() {
    UIALogger.logMessage("Pitching up...");
    this.waitForTouchEvent(function() {
        this.pitchMap({x:0.5, y:0.5}, {x:0.5, y:0.2});
    });
};

/**
 * Rotates mapview
 **/
UIAApp.prototype.rotateMap = function rotateMap() {
    UIALogger.logMessage("Rotating ...");
    this.waitForTouchEvent(function() {
        // This will rotate the mapview around the center of the mapview.
        this.rotate(UIAQuery.MAP_VIEW, {offset: { x: 0.5, y: 0.5}});
    });
};

/**
 * Zooms the mapview in
 **/
UIAApp.prototype.zoomMapIn = function zoomMapIn() {
    UIALogger.logMessage("Zooming in...");
    this.waitForTouchEvent(function() {
        this.doubleTap(UIAQuery.MAP_VIEW);
    });
};

/**
 * Zooms the mapview out
 **/
UIAApp.prototype.zoomMapOut = function zoomMapOut() {
    UIALogger.logMessage("Zooming out...");
    this.waitForTouchEvent(function() {
        this.twoFingerTap(UIAQuery.MAP_VIEW);
    });
};

