/**
 * @namespace
 */
CAMMediaRemote = {};

/**
 * Get the album name from Now Playing
 * 
 * @return {string} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingAlbum = function getNowPlayingAlbum() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return np.kMRMediaRemoteNowPlayingInfoAlbum;
}

/**
 * Get the artist name from Now Playing
 * 
 * @return {string} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingArtist = function getNowPlayingArtist() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return np.kMRMediaRemoteNowPlayingInfoArtist;
}

/**
 * Get the chapter number from Now Playing
 * 
 * @return {int} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingChapterNumber = function getNowPlayingChapterNumber() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseInt(np.kMRMediaRemoteNowPlayingInfoChapterNumber) + 1; //it starts at 0 so we add 1
}

/**
 * Get the deafult playback rate from Now Playing
 * 
 * @return {float} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingDefaultPlaybackRate = function getNowPlayingDefaultPlaybackRate() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseFloat(np.kMRMediaRemoteNowPlayingInfoDefaultPlaybackRate);
}

/**
 * Get the track duration from Now Playing
 * 
 * @return {float} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingDuration = function getNowPlayingDuration() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseFloat(np.kMRMediaRemoteNowPlayingInfoDuration);
}

/**
 * Get the elapsed time from Now Playing
 * 
 * @return {float} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingElapsedTime = function getNowPlayingElapsedTime() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseFloat(np.kMRMediaRemoteNowPlayingInfoElapsedTime);
}

/**
 * Get the playback rate from Now Playing
 * 
 * @return {float} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingPlaybackRate = function getNowPlayingPlaybackRate() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseFloat(np.kMRMediaRemoteNowPlayingInfoPlaybackRate);
}

/**
 * Get the queue index from Now Playing
 * 
 * @return {int} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingQueueIndex = function getNowPlayingQueueIndex() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseInt(np.kMRMediaRemoteNowPlayingInfoQueueIndex);
}

/**
 * Get the timestamp from Now Playing
 * 
 * @return {string} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingTimestamp = function getNowPlayingTimestamp() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return np.kMRMediaRemoteNowPlayingInfoTimestamp;
}

/**
 * Get the title from Now Playing
 * 
 * @return {string} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingTitle = function getNowPlayingTitle() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return np.kMRMediaRemoteNowPlayingInfoTitle;
}

/**
 * Get the total chapter count from Now Playing
 * 
 * @return {int} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingTotalChapterCount = function getNowPlayingTotalChapterCount() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseInt(np.kMRMediaRemoteNowPlayingInfoTotalChapterCount);
}

/**
 * Get the total queue count from Now Playing
 * 
 * @return {int} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingTotalQueueCount = function getNowPlayingTotalQueueCount() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseInt(np.kMRMediaRemoteNowPlayingInfoTotalQueueCount);
}

/**
 * Get the unique identifier from Now Playing
 * 
 * @return {int} null if nothing is playing
 */
CAMMediaRemote.getNowPlayingUniqueIdentifier = function getNowPlayingUniqueIdentifier() {
    var np = this._parseNowPlaying();
    if (!np) {
        return null;
    }
    return parseInt(np.kMRMediaRemoteNowPlayingInfoUniqueIdentifier);
}

/**
 * Is media playing?
 * 
 * @return {Boolean}
 */
CAMMediaRemote.isMediaPlaying = function isMediaPlaying() {
    var obj = UIATarget.localTarget().performTask('/usr/local/bin/coreautomationd', ['-command', 'mediaRemote.isMediaPlaying']);
    return Boolean(parseInt(obj.stdout));
}

/**
 * Get now playing information
 * This parses the output of `coreautomationd -command mediaRemote.nowPlayingInfo`
 * 99.9% of this is written by Chris Parks. If this doesn't work, throw stuff at him until he fixes it.
 * <rdar://problem/22336593> ER: output returned value as JSON
 * 
 * @return {object|bool} false if nothing is playing, an object with the nowplaying properties as keys
 */
CAMMediaRemote._parseNowPlaying = function _parseNowPlaying() {
    var obj = UIATarget.localTarget().performTask('/usr/local/bin/coreautomationd', ['-command', 'mediaRemote.nowPlayingInfo']);
    var s = obj.stdout;
    if (!s) {
        return false;
    }
    // Table to convert escapes to real values
    var escapes = {
        'n': '\n',
        'r': '\r',
        't': '\t',
        '"': '"',
        "'": "'",
    };

    var loop = function loop(block) {
        var quote = null;    // quote is " or ' if we're in a string
        var escape = false;  // escape is true if we just saw \
        var token = '';      // current token

        // Emit calls block() on the current token
        // and then resets the token
        var emit = function emit() {
            if (token.length) {
                block(token);
                token = '';
            }
        };

        for (var i = 0; i < s.length; ++i) {
            var c = s[i];

            if (quote) { // In a  string
                if (escape) { // In an escape
                    var unescaped = escapes[c] || c;
                    token += unescaped;
                    escape = false;
                } else if (c == '\\') { // About to escape
                    escape = true;
                } else if (c == quote) { // End of string
                    emit();
                    quote = null;
                } else { // Add anything else to the string
                    token += c;
                }
            } else {
                switch(c) {
                    // Ignore all of these, but terminate the last token
                    case '{':
                    case '}':
                    case ' ':
                    case '\n':
                    case '\r':
                    case '\t':
                    case '=':
                    case ';':
                        emit();
                        break;
                    // Start a new string and terminate the last token
                    case '"':
                    case "'":
                        emit();
                        quote = c;
                        break;
                    // Add to the current token
                    default:
                        token += c;
                        break;
                }
            }
        }
    }

    // Collect each token in an array
    var tokens = [];
    loop(function(token) {
        tokens.push(token);
    });

    var np = {};
    for (var i = 0; i <= tokens.length - 1; i++) {
        np[tokens[i]] = tokens[++i];
    };

    return np;
}