load('UIAApp.js');

/******************************************************************************/
/*                                                                            */
/*   Mark: Query Constants                                                    */
/*                                                                            */
/*      App specific queries that will be used frequently                     */
/*                                                                            */
/******************************************************************************/

/** Keyboard on app */
UIAQuery.KEYBOARD =         
                    UIAQuery.windows('UIRemoteKeyboardWindow').andThen(
                        UIAQuery.keyboard().isVisible()
                    );

/** Button to switch between keyboards. */
UIAQuery.KEYBOARD_SWITCHER_BUTTON =       
                    UIAQuery.windows('UIRemoteKeyboardWindow').andThen(
                        UIAQuery.keyboard().andThen(
                            UIAQuery.buttons('Next keyboard')
                        )
                    );

/** Button to switch between keyboards. */
UIAQuery.KEYBOARD_SHIFT_BUTTON =
                    UIAQuery.keyboard().andThen(
                        UIAQuery.buttons('shift')
                    );

/** Container listing keyboards we can switch to. */
UIAQuery.KEYBOARD_SWITCHER_CONTAINER =  
                    UIAQuery.windows('UIRemoteKeyboardWindow').andThen(
                        UIAQuery.tableViews('InputSwitcherTable')
                    );

/** Candidate Collection View */
UIAQuery.KEYBOARD_CANDIDATE_VIEW =
                    UIAQuery.keyboard().isVisible().andThen(
                        UIAQuery.collectionViews('UIKBCandidateCollectionView').bottommost()
                    );

/*****************************************************************************/
/*                                                                           */
/*   Mark: Actions                                                           */
/*                                                                           */
/*      Atomic units of UI automation and helper functions                   */
/*      These will assume the devices is already in the required state       */
/*                                                                           */
/*****************************************************************************/

/**
 *  getKeyboardID - Gets the current keyboard's id.
 *
 **/
UIAApp.prototype.getKeyboardID = function getKeyboardID() {
    this.assertExists(
        UIAQuery.KEYBOARD, 
        'Keyboard is not visible. Cannot get keyboard ID.'
    );

    // this is a horrible hack to use in till radar: 20100497 is finished.
    return this.inspect(UIAQuery.KEYBOARD).uiaxElement.valueForKey('kAXInputIdentifierAttribute');
}

/**
 *  switchKeyboard - Switches to the specified keyboard via a kid.
 *
 * @param {string}  kid - specific system keyboard ID 
 *                   (e.g. ja_JP-Romaji@sw=QWERTY-Japanese;hw=US), which indicates 
 *                   language, type, and layout.
 *
 * @throws If unable to switch keyboards.
 **/
UIAApp.prototype.switchKeyboard = function switchKeyboard(kid) {
    var currentKeyboard = this.getKeyboardID();
    UIALogger.logMessage('Current keyboard is \'%0\''.format(currentKeyboard));
    UIALogger.logMessage('Attempting to switch to keyboard \'%0\''.format(kid));

    if (kid === currentKeyboard) {
        // Nothing to do here. The current keyboard is the same as kid.
        UIALogger.logMessage('Keyboard is already set to \'%0\''.format(kid));
    } else {
        this.tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
        this.waitForKeyboard(10);
        var startingKeyboard = this.getKeyboardID();
        currentKeyboard = startingKeyboard;
        while (currentKeyboard !== kid) {
            this.tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
            this.waitForKeyboard(10);
            currentKeyboard = this.getKeyboardID();

            // Back to startingKeyboard in the cyclic switching.  This means kid cannot be found in the Globe menu.
            UIAUtilities.assertNotEqual(
                startingKeyboard,
                currentKeyboard,
                'Cannot switch keyboard to \'%0\''.format(kid)
            );
        }
        UIALogger.logMessage('Keyboard successfully switched to \'%0\''.format(kid));
    }
}


