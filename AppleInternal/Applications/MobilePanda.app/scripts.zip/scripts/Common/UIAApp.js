load("UIATarget.js");
load("UIAUtility.js");

/*******************************************************************************/
/*                                                                             */
/*   Mark: Localized String Constants                                          */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/

LocStrings = {

    /** UIKit.framework and UIKit.axbundle Strings: */

    /** Active Route */
    ACTIVE_ROUTE:           target.localizedString(
                                'ACTIVE_ROUTE_LABEL',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/VectorKit.axbundle'}
                            ),
    /** Alternate Route */
    ALTERNATE_ROUTE:        target.localizedString(
                                'ALTERNATE_ROUTE_LABEL',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/VectorKit.axbundle'}
                            ),


    /** Cancel */
    CANCEL:                 target.localizedString(
                                'Cancel',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Clear*/
    CLEAR:                  target.localizedString(
                                'Clear',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Clear Text */
    CLEAR_TEXT:             target.localizedString(
                                'clear.button.text',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** Contacts */
    CONTACTS:               target.localizedString(
                                'Contacts',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Delete */
    DELETE:                 target.localizedString(
                                'delete.key',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** Done */
    DONE:                   target.localizedString(
                                'Done',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Edit */
    EDIT:                  target.localizedString(
                                'Edit',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Favorites */
    FAVORITES:              target.localizedString(
                                'Favorites',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Navigation in progress */
    NAV_IN_PROGRESS:        target.localizedString(
                                'status.backgroundactivity.navigation',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** OK */
    OK:                     target.localizedString(
                                'OK',
                                {bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Search */
    SEARCH:                 target.localizedString(
                                'keyboard.return.key.search',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** Return */
    RETURN:                 target.localizedString(
                                'keyboard.return.key.default',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** CoreLocation.framework Strings: */


    /** Compose */
    COMPOSE:
                            target.localizedString(
                                'compose.button',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** Select All */
    SELECT_ALL:
                            target.localizedString(
                                'Select All',
                                {tableName:'Localizable', bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Cut */
    CUT:
                            target.localizedString(
                                'Cut',
                                {tableName:'Localizable', bundlePath:'/System/Library/Frameworks/UIKitCore.framework'}
                            ),

    /** Allow */
    LOCATION_ALLOW:         target.localizedString(
                                'LOCATION_CLIENT_PERMISSION_OK',
                                {tableName:'locationd', bundlePath:'/System/Library/Frameworks/CoreLocation.framework'}
                            ),

    /** Don't Allow */
    LOCATION_DONT_ALLOW:    target.localizedString(
                                'DONT_ALLOW',
                                {tableName:'locationd', bundlePath:'/System/Library/Frameworks/CoreLocation.framework'}
                            ),

    /** Open */
    OPEN:                   target.localizedString(
                                'Open',
                                {bundlePath:'/System/Library/PrivateFrameworks/WebUI.framework'}
                            ),

    /** Open this page in “%@”?*/
    OPEN_THIS_PAGE_IN:      target.localizedString(
                                'Open this page in “%@”?',
                                {bundlePath:'/Applications/MobileSafari.app'}
                            ),

    /** Activity Indicator In Progress */
    IN_PROGRESS:            target.localizedString(
                                'activity.indicator.inprogress.label',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** Activity Indicator Progress Halted */
    PROGRESS_HALTED:        target.localizedString(
                                'activity.indicator.progresshalted.label',
                                {tableName:'Accessibility', bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle'}
                            ),

    /** View in Store */
    VIEW_IN_STORE:          target.localizedString(
                                'VIEW_IN_STORE',
                                {bundlePath:'/System/Library/Frameworks/StoreKit.framework'}
                            ),

    /** wants to open */
    WANTS_TO_OPEN:          target.localizedString(
                                'SCHEME_APPROVAL_PROMPT_TITLE',
                                {tableName:'SchemeApproval', bundlePath:'/System/Library/Frameworks/MobileCoreServices.framework'}
                            ),
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Delete keyboard button */
UIAQuery.DELETE_KEY = UIAQuery.keyboard().andThen(UIAQuery.keys().withPredicate('name ==[c] "Delete" OR name ==[c] "%0"'.format(LocStrings.DELETE)));

/** Right navigation bar button */
UIAQuery.RIGHT_NAV_BUTTON = UIAQuery.query('right-nav-button');

/** Back (left) navigation bar button */
UIAQuery.BACK_NAV_BUTTON = UIAQuery.query('back-nav-button');

/** Cancel button */
UIAQuery.CANCEL_BUTTON = UIAQuery.query('cancel-button').orElse(UIAQuery.buttons(LocStrings.CANCEL));

/** Done button */
UIAQuery.DONE_BUTTON = UIAQuery.buttons('Done');

/** Continue button */
UIAQuery.CONTINUE_BUTTON = UIAQuery.buttons('Continue');

/** More Info button */
UIAQuery.MORE_INFO_BUTTON = UIAQuery.buttons('More Info');

/** Done button on navigation bar */
UIAQuery.NAV_BAR_DONE_BUTTON = UIAQuery.navigationBars().andThen(UIAQuery.buttons('Done'));

/** Search button in keyboard **/
UIAQuery.SEARCH_BUTTON = UIAQuery.buttons('Search');

/** Default button */
UIAQuery.DEFAULT_BUTTON = UIAQuery.query('default-button');

/** Continuity button */
UIAQuery.CONTINUITY_BUTTON = UIAQuery.query('continuity-button');

/** Leftmost navigation bar */
UIAQuery.LEFT_NAVBAR = UIAQuery.navigationBars().isVisible().leftmost();  // isVisible identifies master from master-detail when in portrait orientation

/** Rightmost navigation bar */
UIAQuery.RIGHT_NAVBAR = UIAQuery.navigationBars().rightmost();

/** Topmost navigation bar */
UIAQuery.TOP_NAVBAR = UIAQuery.navigationBars().topmost();

/** Bottommost navigation bar */
UIAQuery.BOTTOM_NAVBAR = UIAQuery.navigationBars().bottommost();

/** Visible navigation bars */
UIAQuery.VISIBLE_NAVBARS = UIAQuery.navigationBars().isVisible();

/** Status bar activity item view */
UIAQuery.STATUS_BAR_ACTIVITY_VIEW = UIAQuery.query("UIStatusBarActivityItemView"),

/** especially for maps search, the "where do you want to go" box and keyboard button **/
UIAQuery.SEARCH_BAR    = UIAQuery.searchBars();

/** Visible action sheets */
UIAQuery.VISIBLE_SHEETS = UIAQuery.actionSheets().isVisible();

/** Visible popover */
UIAQuery.VISIBLE_POPOVERS = UIAQuery.popovers().isVisible();

/** Leftmost table view */
UIAQuery.LEFT_TABLE = UIAQuery.tableViews().leftmost();

/** Rightmost table view */
UIAQuery.RIGHT_TABLE = UIAQuery.tableViews().rightmost();

/** Topmost table view */
UIAQuery.TOP_TABLE = UIAQuery.tableViews().topmost();

/** Bottommost table view */
UIAQuery.BOTTOM_TABLE = UIAQuery.tableViews().bottommost();

/** Leftmost collection view*/
UIAQuery.LEFT_COLLECTION_VIEW = UIAQuery.collectionViews().leftmost();

/** Rightmost collection view */
UIAQuery.RIGHT_COLLECTION_VIEW = UIAQuery.collectionViews().rightmost();

/** Topmost collection view */
UIAQuery.TOP_COLLECTION_VIEW = UIAQuery.collectionViews().topmost();

/** Bottommost collection view */
UIAQuery.BOTTOM_COLLECTION_VIEW = UIAQuery.collectionViews().bottommost();

/** All colection views*/
UIAQuery.VISIBLE_COLLECTION_VIEWS = UIAQuery.collectionViews().isVisible();

UIAQuery.CELLS = UIAQuery.withPredicate("behavior in {'TableCell', 'CollectionCell'}");

/** Toolbar share button */
UIAQuery.SHARE_BUTTON = UIAQuery.toolbars().andThen(UIAQuery.buttons('Share'));

/** Mail composition view */
UIAQuery.MAIL_COMPOSE_VIEW = UIAQuery.query('MFMailComposeView');

/** Activity Indicator In Progress */
UIAQuery.ACTIVITY_IN_PROGRESS = UIAQuery.activityIndicators(LocStrings.IN_PROGRESS);

/** Activity Indicator Progress Halted */
UIAQuery.ACTIVITY_PROGRESS_HALTED = UIAQuery.activityIndicators(LocStrings.PROGRESS_HALTED);

/** Share sheet */
UIAQuery.SHARE_SHEET = UIAQuery.query('ActivityListView');

UIAQuery.PHOTO_BROWSER_TITLE = UIAQuery.query('PUPhotoBrowserTitleView');

UIAQuery.PHOTO_CONTROLLER_VIEW = UIAQuery.query('UIViewControllerWrapperView');

UIAQuery.ORB_PEEK_VIEW = UIAQuery.query('UITransitionView').andThen(UIAQuery.query('_UIPreviewPresentationContainerView'));

/** Action sheet or alert */
UIAQuery.PROMPT_CONTAINER = UIAQuery.actionSheets().orElse(UIAQuery.alerts());

UIAQuery.EMAIL_ADDRESS_FIELD = UIAQuery.textFields().withPredicate(
                                    'any identifiers contains[c] "Email" or placeholderText contains[c] "Email"'
                                );

UIAQuery.EMAIL_PASSWORD_FIELD = UIAQuery.secureTextFields().withPredicate(
                                    'any identifiers contains[c] "Password" or placeholderText contains[c] "Password"'
                                );

/** Various alerts asking to allow access to location */
UIAQuery.ALLOW_LOCATION_ALERT = (function() {
    var keys = [
        'LOCATION_CLIENT_PERMISSION_ALWAYS',
        'LOCATION_CLIENT_PERMISSION_WHENINUSE',
        'LOCATION_CLIENT_PERMISSION_REPROMPT',
        'LOCATION_CLIENT_PERMISSION_UPGRADE_WHENINUSE_ALWAYS',
        ];
    var tableName = 'locationd';
    var bundlePath = '/System/Library/Frameworks/CoreLocation.framework';

    var query = null;
    for (var i = 0; i < keys.length; i++) {
        var string = target.localizedString(keys[i], {tableName:tableName, bundlePath:bundlePath});
        var components = string.split(/%@/);

        var predicate = 'name BEGINSWITH "%0"'.format(components.shift());

        while (components > 1) {
            predicate += ' AND name CONTAINS "%0"'.format(components.shift());
        }

        if (components.length > 0) {
            predicate += ' AND name ENDSWITH "%0"'.format(components.shift());
        }

        if (!query) {
            query = UIAQuery.alerts().withPredicate(predicate);
        } else {
            query = query.orElse(UIAQuery.alerts().withPredicate(predicate));
        }
    }

    return query;
})();

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIStateDescription = {
/** unknown */
    UNKNOWN:                'unknown',

/** Action sheet */
    ACTION_SHEET:           'action sheet',

/** Mail composition */
    MAIL_COMPOSITION:       'mail composition',

/** Add bookmark */
    ADD_BOOKMARK:           'add bookmark',

/** Add to home */
    ADD_TO_HOME:            'add to home',

/** Media playback */
    MEDIA_PLAYBACK:         'media playback',

/** Printer list */
    PRINTER_LIST:           'printer list',

/** Printer options */
    PRINTER_OPTIONS:        'printer options',

/** Video */
    VIDEO:                  'video',

/** Parsec */
    PARSEC_CARD:            'parsec card',

/** Orb */
    PEEK_VIEW:              'peek view',

}

/**
 * @extends UIAApp
 */

/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State                                                    */
/*                                                                             */
/*      A function to determine which UI state the app is currently in         */
/*                                                                             */
/*******************************************************************************/

/**
 *  This function returns a description of the UI currently being displayed.
 *  (constants for possible values are found under UIStateDescription)
 *
 * @returns {string} a string describing the currently displayed UI
 */
UIAApp.prototype.currentUIState = function currentUIState() {
    UIALogger.logMessage("Evaluating current UI state ...");

    var currentUIState = UIStateDescription.UNKNOWN;

    var applicationInfo = this.inspect(UIAQuery.application());
    var navigationBarInfo = applicationInfo.inspect(UIAQuery.VISIBLE_NAVBARS);
    var navigationBarName = (navigationBarInfo) ? navigationBarInfo.name : null;
    if (navigationBarName && navigationBarName.length > 0) {
        UIALogger.logMessage("Navigation bar name is %0".format(navigationBarName));
    }

    switch (navigationBarName) {
        case "Add Bookmark":
            currentUIState = UIStateDescription.ADD_BOOKMARK;
            break;
        case "Add to Home":
            currentUIState = UIStateDescription.ADD_TO_HOME;
            break;
        case "Printer":
            currentUIState = UIStateDescription.PRINTER_LIST;
            break;
        case "Printer Options":
            currentUIState = UIStateDescription.PRINTER_OPTIONS;
            break;
        case "Maps":
        case "iTunes Store":
        case "App Store":
        case "iBooks Store":
        case "Wikipedia":
        case "SearchUICardView":
        case "SPUISearchDetailsView":
        case "SKUIDocumentContainerView":
        case "Sports":
        case "Twitter":
        case "Now Playing in Theaters":
        case "Movies":
        case "TV Show":
        case "TV Episode":
            currentUIState = UIStateDescription.PARSEC_CARD;
            break;
        default:
        {
            if (applicationInfo.exists(UIAQuery.MAIL_COMPOSE_VIEW.isVisible())) {
                currentUIState = UIStateDescription.MAIL_COMPOSITION;
            } else if (applicationInfo.exists(UIAQuery.query("AVVideoLayerView").isVisible())) {
                currentUIState = UIStateDescription.VIDEO;
            } else if (applicationInfo.exists(UIAQuery.ORB_PEEK_VIEW.isVisible())) {
                currentUIState = UIStateDescription.PEEK_VIEW;
            } else if (!arguments.callee.caller.name || arguments.callee.name != arguments.callee.caller.name) {
                // only log this warning when not called from a similarly named function
                UIALogger.logWarning("Current UI state unknown.");
            }
        }
    }

    return currentUIState;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Tasks                                                               */
/*                                                                             */
/*      A high-level goal we are trying to accomplish.                         */
/*      Comprised of multiple Action functions and do not assume state         */
/*                                                                             */
/*******************************************************************************/

/**
 *  Brings up the search field, enters the search string ending with the search button.
 *  (By default the function taps on the status bar to bring up the search field, clears the field before starting and ignores auto-suggested text.)
 *
 * @param   {string}  searchString - the string to type into the search field
 * @param   {object}  options - a dictionary object of optional arguments
 * @param   {boolean} [options.dragDownForSearchField=false] - if true the function drags down to reveal the search bar
 * @param   {object}  [options.dragDownInsideQuery=UIAQuery.application()] - query used to identify the element to drag down in
 * @param   {object}  [options.searchField=UIAQuery.searchBars()] - query used to identify the search field in the UI
 * @param   {object}  [options.enterTextOptions={}] - options to be passed onto the enterText action
 * @param   {bool}  [options.requiresEnterKey=true] - if true this types the enter key at the end
 * @param   {bool}  [options.clearSuggested=false] - if true this will clear out auto-completed suggestions
 * @returns {object}
 */
UIAApp.prototype.search = function search(searchString, options) {
    options = UIAUtilities.defaults(options, {
        dragDownForSearchField: false,
        dragDownInsideQuery: UIAQuery.application(),
        searchField: UIAQuery.searchBars().isVisible(),
        enterTextOptions: {},
        requiresEnterKey: true,
        clearSuggested: false,
    });

	UIALogger.logMessage("Searching for: %0".format(searchString));
    // UIALogger.logMessage('Using options: %0'.format(JSON.stringify(options)));

    if (!this.exists(options.searchField)) {
        if (!options.dragDownForSearchField) {
            this.tap(UIAQuery.statusBars());
        } else {
            this.dragDownInside(options.dragDownInsideQuery);
        }
    }

    this.enterText(options.searchField, searchString, options.enterTextOptions);

    if (options.clearSuggested && !options.enterTextOptions.setValueToEnterText) {
        // To clear auto-suggested text, type delete in the keyboard
        // and add back the character in case it got deleted by mistake.
        var originalURLValue = this.inspect(options.searchField).value;
        this.tap(UIAQuery.DELETE_KEY);
        var URLValueAfterDelete = this.inspect(options.searchField).value;
        if (originalURLValue.length > URLValueAfterDelete.length) {
            this.typeString(originalURLValue.slice(-1));
        }
    }

    if (options.requiresEnterKey) {
        this.typeString("\n");
    }

	return true;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions and Helpers                                                 */
/*                                                                             */
/*      Atomic units of UI automation and helper functions                     */
/*      These will assume the devices is already in the required state         */
/*                                                                             */
/*******************************************************************************/

// MARK: Actions - Drags and Swipes

/**
 *  Calls UIAApp.drag with typical offsets needed to drag up.
 *  (see [UIAApp.drag]{@link UIAApp#drag} for more info)
 *
 *  @param {UIAQuery} query - Query describing element to set
 *  @param {UIADragOptions} options - options to be set
 */
UIAApp.prototype.dragUpInside = function dragUpInside(query, options) {
    options = UIAUtilities.defaults(options, {
        fromOffset: {x:0.5, y:0.85},
        toOffset: {x:0.5, y:0.15},
    });

	this.drag(query, options);
}

/**
 *  Calls UIAApp.drag with typical offsets needed to drag down.
 *  (see [UIAApp.drag]{@link UIAApp#drag} for more info)
 *
 *  @param {UIAQuery} query - Query describing element to set
 *  @param {UIADragOptions} options - options to be set
 */
UIAApp.prototype.dragDownInside = function dragDownInside(query, options) {
    options = UIAUtilities.defaults(options, {
        fromOffset: {x:0.5, y:0.15},
        toOffset: {x:0.5, y:0.85},
    });

	this.drag(query, options);
}

/**
 *  Calls UIAApp.UIAApp.drag with typical offsets needed to drag left.
 *  (see [UIAApp.drag]{@link UIAApp#drag} for more info)
 *
 *  @param {UIAQuery} query - Query describing element to set
 *  @param {UIADragOptions} options - options to be set
 */
UIAApp.prototype.dragLeftInside = function dragLeftInside(query, options) {
    options = UIAUtilities.defaults(options, {
        fromOffset: {x:0.85, y:0.5},
        toOffset: {x:0.15, y:0.5},
    });

	this.drag(query, options);
}

/**
 *  Calls UIAApp.drag with typical offsets needed to drag right.
 *  (see [UIAApp.drag]{@link UIAApp#drag} for more info)
 *
 *  @param {UIAQuery} query - Query describing element to set
 *  @param {UIADragOptions} options - options to be set
 */
UIAApp.prototype.dragRightInside = function dragRightInside(query, options) {
    options = UIAUtilities.defaults(options, {
        fromOffset: {x:0.15, y:0.5},
        toOffset: {x:0.85, y:0.5},
    });

	this.drag(query, options);
}

/**
 *  Performs the swipe from left edge gesture to navigate to previous view.
 **/
UIAApp.prototype.swipeFromLeftEdge = function swipeFromLeftEdge() {
    // We're swiping horizontally from the left edge of the screen.
    // The x-coordinate then should start from 0.0 and go to the other end of the screen.
    // y-axis starts near top of screen, in case keyboard is up
    this.drag(UIAQuery.application(), {fromOffset:{x:0.0, y:0.5}, toOffset:{x:0.999, y:0.5}, duration:0.5});
}

/**
 *  Performs the swipe from right edge gesture to navigate to next view.
 **/
UIAApp.prototype.swipeFromRightEdge = function swipeFromRightEdge() {
    // We're swiping horizontally from the right edge of the screen.
    // The x-coordinate then should start from 0.999 and go to the other end of the screen.
    // y-axis starts near top of screen, in case keyboard is up
    this.drag(UIAQuery.application(), {fromOffset:{x:0.9999, y:0.5}, toOffset:{x:0.0, y:0.5}, duration:0.5});
}

/**
 *  Performs swipe from top edge
 **/
UIAApp.prototype.swipeFromTopEdge = function swipeFromTopEdge() {
    // We're swiping vertically from the top bezel of the device.
    // The y-coordinate then should start from 0.0 and go to the other end of the screen.
    // x-axis is in middle of screen throughout the swipe
    this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.0}, toOffset:{x:0.5, y:0.999}, duration:0.5});
}

UIAApp.prototype.swipeFromTopRightEdgeToMiddle = function swipeFromTopRightEdgeToMiddle() {
    // We're swiping diagonally from the top right bezel of the device to the Middle of the Screen.
    // This is due to new gestures introduced for Control Center on certain devices
    // The y-coordinate then should start from 0.0 and go to the middle of the screen.
    // x-axis is in middle of screen at the end of the swipe from the top right edge.
    this.drag(UIAQuery.application(), {fromOffset:{x:0.9, y:0.0}, toOffset:{x:0.5, y:0.5}, duration:1.0});
}


/**
 *  Performs a swipe from bottom edge
 **/
UIAApp.prototype.swipeFromBottomEdge = function swipeFromBottomEdge() {
    // We're swiping vertically from the bottom bezel of the device.
    // The y-coordinate then should start from 0.999 and go to the other end of the screen.
    // x-axis is in middle of screen throughout the swipe
    this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.999}, toOffset:{x:0.5, y:0.0}, duration:0.5});
}

/**
 *  Performs swipe from top edge until the queried element becomes visible.
 *
 * @param {UIAQuery} query - Query describing element to swipe to.
 * @param   {object}  options - a dictionary object of optional arguments.
 * @param   {number} [options.duration=0.5] - how long to drag for each swipe.
 * @param   {number} [options.timeout=30] - how long to look for the queried element.
 **/
UIAApp.prototype.swipeDownUntilVisible = function swipeDownUntilVisible(query, options) {
    options = UIAUtilities.defaults(options, {
        duration: 0.5,
        timeout: 30,
    });

    var timeout = Date.now() + options.timeout * 1000;
    while (!this.exists(query.isVisible()) && Date.now() < timeout) {
        // We're swiping down from the top of the screen.
        // The y-coordinate then should start from 0.1 and go to the middle of the screen.
        // x-axis is in middle of screen throughout the swipe
        this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.1}, toOffset:{x:0.5, y:0.5}, duration:options.duration});
    }
}

/**
 *  Performs a swipe from bottom edge until the queried element becomes visible.
 *
 * @param {UIAQuery} query - Query describing element to swipe to.
 **/
UIAApp.prototype.swipeUpUntilVisible = function swipeUpUntilVisible(query, options) {
    options = UIAUtilities.defaults(options, {
        duration: 0.5,
        timeout: 30,
    });

    var timeout = Date.now() + options.timeout * 1000;
    while (!this.exists(query.isVisible()) && Date.now() < timeout) {
        // We're swiping up from the bottom of the screen.
        // The y-coordinate then should start from 0.1 and go to the middle of the screen.
        // x-axis is in middle of screen throughout the swipe
        this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.9}, toOffset:{x:0.5, y:0.5}, duration:options.duration});
    }
}

// MARK: Actions - Text

/**
 *  This function enters text into a view; text field, text view, search field, etc.
 *  If setValueToEnterText it will use inject the text into the view, otherwise it will tap
 *  the view to set focus and type the text.  If shouldSetValueIfValueDoesNotMatchTypedText
 *  it will use setValue as a backup if it can't confirm the text entered.  If shouldClearTextBeforeTyping
 *  it will tap the "Clear Text" button before typing.  If shouldAcceptSuggestions it will allow auto-suggest.
 *
 * @param   {string}  query - a query for the view to type into; text field, text view, search field, etc.
 * @param   {object}  options - a dictionary object of optional arguments
 * @param   {boolean} [options.clearTextBeforeTyping=true] - if true the function will clear the text field before entering text
 * @param   {boolean} [options.setValueToEnterText=false] - if true the function will programatically set the text
 * @param   {boolean} [options.setValueIfValueDoesNotMatch=true] - if true the function will programatically set the text on failures
 * @param   {boolean} [options.acceptSuggestions=true] - if true the function will accept auto-suggested text
 * @param   {boolean} [options.allowTypeStringToRetry=false] - if true the function will retry typeString when encountering an error (file a radar before using!)
 * @returns {object}
 */
UIAApp.prototype.enterText = function enterText(query, text, options) {

    options = UIAUtilities.defaults(options, {
        clearTextBeforeTyping: true,
        setValueToEnterText: false,
        setValueIfValueDoesNotMatch: false,
        acceptSuggestions: false,
        allowTypeStringToRetry: false,
    });

    // FIXME: should check keyboard focus once we've added that to SnapNode

    // set focus
    var validQuery = UIAQuery.query(query);
    this.tap(validQuery);

    this.waitUntilPresent( UIAQuery.keyboard(), 5 );
    if (! this.exists(UIAQuery.keyboard())) {
        throw new UIAError('Keyboard did not appear');
    }

    if (options.clearTextBeforeTyping) {
        var clearTextQuery = validQuery.andThen(UIAQuery.buttons(LocStrings.CLEAR_TEXT));
        this.tapIfExists(clearTextQuery);
        this.tapIfExists(UIAQuery.navigationBars().andThen(UIAQuery.buttons(LocStrings.CLEAR_TEXT).isVisible()));

        var URLValueBeforeDelete = this.inspect(validQuery).value;
        var URLValueAfterDelete = "Not empty";

        while (URLValueBeforeDelete && URLValueAfterDelete && URLValueBeforeDelete != URLValueAfterDelete) {
            // Hit delete key until the string is empty
            URLValueBeforeDelete = this.inspect(validQuery).value;
            this.tap(UIAQuery.DELETE_KEY);
            URLValueAfterDelete = this.inspect(validQuery).value;
        }
    }

    var remainingText = text;
    do {
        try {
            if (options.setValueToEnterText) {
                this.setControl(validQuery, remainingText);
            } else {
                this.typeString(remainingText, options);
            }
            var remainingText = "";
        } catch(error) {
            target.stackshot();
            if (!options.allowTypeStringToRetry) {
                if (!options.setValueIfValueDoesNotMatch) {
                    throw error;
                } else {
                    this.setControl(validQuery, text);
                    break;
                }
            }
            UIALogger.logError(error);
            var value =  this.inspectElementKey(query, "value");
            if (typeof value === 'string' && (text.length - value.length < remainingText.length)) {
                remainingText = text.slice(value.length);
            } else {
                if (!options.setValueIfValueDoesNotMatch) {
                    // no progress made
                    throw error;
                } else {
                    this.setControl(validQuery, text);
                    break;
                }
            }
        }
    } while (remainingText.length);

    if (options.setValueIfValueDoesNotMatch) {
        var value =  this.inspectElementKey(query, "value");
        if (typeof value === 'string' && value !== text) {
            UIALogger.logDebug("The actual value is '%0' and the expected value is '%1'.".format(value, text));
            UIALogger.logDebug("Using setValue to set the correct text.")
            this.setControl(validQuery, text);
        }
    }
}

/**
 * Standard login functionality for a sign in sheet. Takes in a user
 * name and password with optional query parameters for the user/password
 * text fields. Function assumes we start at the login page.
 *
 * @param   {string}    user - User name for login in
 * @param   {string}    password - Password for login in
 * @param   {object}    options - a dictionary object of optional arguments
 * @param   {UIAQuery}  options.userField - Query for field where user name will be typed in
 * @param   {UIAQuery}  options.passwordField - Query for field where password will be typed in
 * @param   {boolean}   [options.clearTextBeforeTyping=true]- If true the function will clear the text field before entering text
 * @param   {boolean}   [options.acceptSuggestions=false] - If true the function will accept auto-suggested text
 *
 *  @returns None
 **/
UIAApp.prototype.login = function login(user, password, options) {
    options = UIAUtilities.defaults(options, {
        userField: UIAQuery.textFields().contains('SignIn'),
        passwordField: UIAQuery.secureTextFields().contains('SignIn'),
        clearTextBeforeTyping: true,
        acceptSuggestions: false,
    });

    if (!user || !password) {
        throw new UIAError('Both a user name and password is needed to login.');
    }

    this.enterText(options.userField, user, options);
    this.enterText(options.passwordField, password, options);
    this.typeString('\n');
}

// MARK: Actions - Pickerwheels

/**
 *  This function sets the values for all the wheels inside a picker.
 *  The number of values to set must equal the number of wheels in the picker
 *  (an undefined or null entry in the values array will direct the method to skip setting a designated wheel's value)
 *
 * @param   {string}  pickerQuery       - a query for the picker where the picker wheels are nested in
 * @param   {Array}   values            - a list of values to set for each wheel, in the order of the wheels
 * @param   {object}  options           - a dictionary object of optional arguments
 *
 * @throw Error if picker values cannot be set
 */
UIAApp.prototype.setPickerValues = function setPickerValues(pickerQuery, values, options) {
    if (! (values instanceof Array)) {
        throw new UIAError("An array of values must be passed in!");
    } else {
        UIALogger.logMessage("Values to set to picker wheels (from left to right): %0".format(JSON.stringify(values)))
    }

    options = UIAUtilities.defaults(options, {
    });

    var wheelsQuery = pickerQuery.andThen(UIAQuery.pickerWheels());

    var wheelCount = this.count(wheelsQuery);
    if (wheelCount > values.length) {
        throw new UIAError("Not enough values to pass into the picker; picker has %0 wheels!".format(wheelCount));

    } else if (wheelCount < values.length) {
        throw new UIAError("Too many values to pass into picker; picker has %0 wheels!".format(wheelCount));

    } else {
        UIALogger.logMessage("Picker has %0 wheels; will set them to values %1 respectively".format(wheelCount, JSON.stringify(values)));
        for (var i=0; i < wheelCount; i++) {
            if (values[i] === undefined || values[i] === null) {
                UIALogger.logMessage("No value to set for wheel %0; skipping...".format(i));
                continue;
            }
            UIALogger.logMessage("Attempting to adjust picker to '%0' on wheel %1...".format(values[i], i));
            this.setControl(wheelsQuery.atIndex(i), values[i]);
        }
    }
}


// MARK: Navigation

UIAApp.prototype.dismissActionSheet = function dismissActionSheet() {
    // action sheets
    if (this.exists(UIAQuery.VISIBLE_SHEETS)) {
        UIALogger.logMessage("Action sheet visible. Dismissing...");

        var sheetDelete   = UIAQuery.VISIBLE_SHEETS.andThen(UIAQuery.buttons().beginsWith('Delete'));
        if (this.exists(sheetDelete)) {
            // special case for email composition on iPhone
            UIALogger.logWarning("Email draft will be deleted.");
            this.tap(sheetDelete);
        } else {
            this.tap(UIAQuery.VISIBLE_SHEETS.andThen(UIAQuery.buttons().last()));
        }
    }

    return true;
}

UIAApp.prototype.dismissPopovers = function dismissPopovers() {
    if (this.exists(UIAQuery.VISIBLE_POPOVERS)) {
        UIALogger.logMessage("Popover visible. Dismissing...");
        var cancelButton = UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.CANCEL_BUTTON.isVisible());
        if (this.exists(cancelButton)) {
            this.tap(cancelButton);
        } else {
            this.dismissPopover();
        }

        return true;
    } else if (this.exists("SidebarContentDimmingView")) {
        this.tap("SidebarContentDimmingView");
    }

    return false;
}

/**
 * Navigate a navigation hierarchy by tapping table cells. The navigation path
 * is defined by an array of identifiers for table cells to be tapped
 *
 * @param {array} items - An array of query-compatible strings or objects
 *                        containing a query field and (optionally) a title field
 *
 * @example
 *   var success = settings.navigateNavigationViews([
 *       'Cell1',                               // Find 'Cell1' and wait for view with 'Cell1' title to appear
 *       {
 *           query: 'Cell2',                    // Find 'Cell2'
 *           title: 'Cell2 Title',              // Wait for view with 'Cell2 Title' to appear
 *       },
 *       {
 *           query: UIAQuery.contains('Cell3'), // Find element containing 'Cell3'
 *                                              // Wait for view with any title to appear
 *       },
 *   ]);
 *
 * @returns {boolean} true if navigation path was successfully navigated
 * @throw Error if any item is malformed (non-string, non-object, or object missing query field)
 */
UIAApp.prototype.navigateNavigationViews = function navigateNavigationViews(items) {
    function isHorizontalRegularUI() {
        return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
    }

    try {
        this.launch();
    } catch (e) {
        UIALogger.logError(e);
        return false; // TODO: <rdar://problem/20182379> [UIA2] navigateNavigationViews should throw
    }
    if (!this.returnToTopLevel()) {
        return false; // TODO: <rdar://problem/20182379> [UIA2] navigateNavigationViews should throw
    }

    var regularWidthScreen = isHorizontalRegularUI();
    for (var i = 0; i < items.length; ++i) {
        var obj = items[i];

        if (typeof obj === 'string') {
            // FIXME: Workaround for <rdar://problem/21001505>
            // Settings is returning garbage data for offscreen table elements
            var query = UIAQuery.tableCells(obj);
            var title = obj;
        } else if (typeof obj === 'object') {
            if (obj.query) {
                var query = obj.query;
            } else {
                throw new UIAError('Each object in array must have a query field');
            }

            if (obj.title) {
                var title = obj.title;
            } else {
                UIALogger.logMessage('Skipping title verification for ' + obj);
                var title = null;
            }
        } else {
            throw new UIAError('Each element of array must be an object with a query field or a string');
        }

        var options = {};
        if (typeof title === 'string') {
            options.predicate = 'navigationItemTitle == "%0"'.format(title);
        }
        var viewDidAppear = UIAWaiter.waiter('ViewDidAppear', options);

        var isCellInRightTable = (regularWidthScreen && i === 0) ? false : true;
        var cell = isCellInRightTable ? UIAQuery.RIGHT_TABLE.andThen(query) : UIAQuery.LEFT_TABLE.andThen(query);
        this.scrollToVisible(cell);
        var info = this.inspect(cell);

        // The first cell of a split-view (left table) should be skipped if already selected
        if (isCellInRightTable || !(info && info.isSelected)) {
            for (var retryCounter = 0; retryCounter < 2; retryCounter++) {
                this.tap(cell);
                if (viewDidAppear.wait(5)) {
                    // FIXME: In a split-view there's some sluggishness when changing the detail pane
                    if (!isCellInRightTable) {
                        this.delay(1);
                    }
                    break;
                } else {
                    var newInfo = this.inspect(cell);
                    if (newInfo && (info.rect.y != newInfo.rect.y)) {
                        // new cells can change the possition of existing cells rdar://problem/21973728
                        UIALogger.logMessage("View did not load and cell moved (trying again): %0".format(obj));
                    } else {
                        UIALogger.logWarning("Failed to load new view: %0".format(obj));
                        break;
                    }
                }
            }
        }
    }
    return true;
}

/**
 * Return to top-most navigation view in the hierarchy.
 *
 * @param {object} options - Options dictionary
 * @param {array}  options.leftButtonsToAvoid - Array of names of buttons to avoid
 *
 * @returns {bool} true if successful, false otherwise
 */
UIAApp.prototype.returnToTopLevel = function returnToTopLevel(options) {
    var buttonsToAvoid = ['Edit', 'Refresh', 'Add', 'New'];
    if (options && options.leftButtonsToAvoid) {
        buttonsToAvoid.concat(options.leftButtonsToAvoid)
    }

    var navbar = UIAQuery.navigationBars().isVisible().last();
    var navbarInfo = UIAQuery.navigationBars().last();
    if (!navbarInfo || !navbarInfo.isVisible) {
        return;
    }

    var iPad = target.model() === 'iPad';
    for(var i = 0; i < 10; ++i) {
        // Dismiss any active action sheets
        if (this.exists(UIAQuery.VISIBLE_SHEETS)) {
            this.dismissActionSheet();
            continue;
        }

        // Dismiss any active popovers
        if (this.exists(UIAQuery.VISIBLE_POPOVERS)) {
            this.dismissPopovers();
            continue;
        }

        // Delete an email composition on iPad
        if (this.exists(UIAQuery.MAIL_COMPOSE_VIEW.isVisible())) {
            UIALogger.logMessage("Dismiss email composition");
            this.tap(UIAQuery.CANCEL_BUTTON);
            this.dismissActionSheet();
            continue;
        }

        // Tap the back button if it doesn't match something weird
        var backButton = navbar.andThen(UIAQuery.BACK_NAV_BUTTON);
        var backButtonInfo = this.inspect(backButton);
        if (backButtonInfo && backButtonInfo.isVisible) {
            var name = backButtonInfo.label || backButtonInfo.identifier;
            if (name && !buttonsToAvoid.contains(name)) {
                UIALogger.logMessage("Tapping back button: " + name);
                this.tap(backButton);
                continue;
            }
        }

        // Tap the cancel button
        if (this.tapIfExists(navbar.andThen(UIAQuery.CANCEL_BUTTON.isVisible()))) {
            continue;
        }

        // Tap the cancel button on a search
        if (this.tapIfExists(UIAQuery.searchBars().parent().andThen('Cancel').isVisible())) {
            continue;
        }

        // Tap the done button
        if (this.tapIfExists(navbar.andThen(UIAQuery.buttons('Done').isVisible()))) {
            continue;
        }

        UIALogger.logMessage("Returned to top level");
        return true;
    }
    UIALogger.logMessage("Failed to return to top level");
    return false;
}

// MARK: Waiters

/**
 * Set up a waiter, execute the body, and then wait for the matching
 * notification or discard the waiter if the body raised an exception
 *
 * @param {object} compatible - Waiter-compatible object
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitFor = function waitFor() {
    var event, predicate, body, waiter, value, timeout = 10;

    switch (arguments.length) {
        case 2:
            event = arguments[0];
            body = arguments[1];
            break;
        case 3:
            event = arguments[0];
            predicate = arguments[1]
            body = arguments[2];
            break;
        case 4:
            event = arguments[0];
            predicate = arguments[1]
            timeout = arguments[2];
            body = arguments[3];
            break;
        default:
            throw new UIAError('waitFor requires three or four arguments');
            break;
    }

    waiter = (predicate) ? UIAWaiter.withPredicate(event, predicate) : UIAWaiter.waiter(event);
    try {
        value = body.call(this);
    } catch (e) {
        waiter.discard();
        throw e;
    }

    if (!waiter.wait(timeout)) {
        throw new UIAError('Timed out waiting for notification using ' + waiter.description());
    }

    return value;
}

/**
 * Set up a waiter for an Alert, execute the body, and then wait for the
 * matching Alert or discard the waiter if the body raised an exception
 *
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitForAlert = function waitForAlert() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('TRUEPREDICATE');
    args.unshift('Alert');

    return this.waitFor.apply(this, args);
}

/**
 * Set up a waiter for an Announcement, execute the body, and then wait for the
 * matching Announcement or discard the waiter if the body raised an exception
 *
 * @param {string} announcement - Title of announcement to match
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitForAnnouncement = function waitForAnnouncement() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('announcement == "%0"'.format(args.shift()));
    args.unshift('Announcement');

    return this.waitFor.apply(this, args);
}

/**
 * Set up a waiter for a view to appear, execute the body, and then wait for the
 * matching view or discard the waiter if the body raised an exception
 *
 * @param {string} predicate - predicate string with key(s) (controllerTitle, controlerClass, navigationItemTitle, tabBarItemTitle)
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitForViewToAppear = function waitForViewToAppear() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('ViewDidAppear');

    return this.waitFor.apply(this, args);
}

/**
 * Set up a waiter for a view to disappear, execute the body, and then wait for the
 * matching view or discard the waiter if the body raised an exception
 *
 * @param {string} predicate - predicate string with key(s) (controllerTitle, controlerClass, navigationItemTitle, tabBarItemTitle)
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitForViewToDisappear = function waitForViewToDisappear() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('ViewDidDisappear');

    return this.waitFor.apply(this, args);
}

/**
 * Set up a waiter for an application to become active, execute the body, and
 * then wait for the matching application or discard the waiter if the body
 * raised an exception
 *
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitToBecomeActive = function waitToBecomeActive() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('bundleID == "%0" AND state = "%1"'.format(this.bundleID(), "Foreground"));
    args.unshift('ApplicationStateChanged');

    return this.waitFor.apply(this, args);
}

/**
 * Set up a waiter for web page to load, execute the body, and then wait for the
 * event or discard the waiter if the body raised an exception
 *
 * @param {number} [timeout=10] - Optional timeout. Default 10 seconds
 * @param {function} body - Function to execute before waiting
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.waitForWebPageLoaded = function waitForWebPageLoaded() {
    var body, waiter, value, timeout = 10;

    switch (arguments.length) {
        case 1:
            body = arguments[0];
            break;
        case 2:
            timeout = arguments[0];
            body = arguments[1];
            break;
        default:
            throw new UIAError('waitForWebPageLoaded requires one or two arguments');
            break;
    }

    waiter = UIAWaiter.withPredicate('WebPageLoaded', 'progress == 1');
    try {
        value = body.call(this);
    } catch (e) {
        waiter.discard();
        throw e;
    }

    UIALogger.logMessage("Waiting %0 seconds for page to load ...".format(timeout));
    if (!waiter.wait(timeout)) {
        throw new UIAError('Timed out waiting for notification using ' + waiter.description());
    } else {
        UIALogger.logMessage('Event encountered. Web page appears to have loaded.');
    }

    return value;
}

/**
 * Push an alert handler for alerts that may or may not appear during the
 * execution of the second argument. The alert handler is always popped after
 * the second argument finishes executing. The second argument is always bound
 * to the app.
 *
 * @example
 *      var handler = function() {
 *          var app = target.activeApp();
 *          if (app.exists(UIAQuery.contains('use your location'))) {
 *              app.tap('Cancel');
 *              return true;
 *          } else {
 *              return false;
 *          }
 *      };
 *
 *      this.withAlertHandler(handler, function() {
 *          this.changeWallpaper();
 *      });
 *
 * @param {function} handler - Function to push on alert handler stack
 * @param {function} body - Function to execute
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.withAlertHandler = function withAlertHandler(handler, body) {
    return UIAAlertManager.usingAlertHandler(handler, body.bind(this));
}

/**
 * Push a query for alerts that are deterministically triggered by the execution
 * of the second argument. The query is always popped after the second argument
 * finishes executing. The second argument should handle the alert inline after
 * triggering it. The second argument is always bound to the app.
 *
 * @example
 *      var locationAlert = UIAQuery.contains('Disable Location Services?');
 *      this.handlingAlertsInline(locationAlert, function() {
 *          this.tap(UIAQuery.tableCells('Disable Location Services'));
 *          this.tap('OK');
 *      });
 *
 * @param {function} query - Query to push on alert query stack
 * @param {function} body - Function to execute
 *
 * @returns {any} value of body() if body() succeeded
 */
UIAApp.prototype.handlingAlertsInline = function handlingAlertsInline(query, body) {
    return UIAAlertManager.ignoringAlerts(query, body.bind(this));
}

/**
 * Manually scrolls a TableView or CollectionView looking for a particular element. This is useful for views that
 * have large amounts of children and would otherwise cause scrollToVisible to fail due to too many elements in the
 * snapshot. If pane has both TableView and a CollectionView, preference with be given to the TableView.
 *
 * @param {function} query - Query to search for in UICollectionView or UITableView
 * @param {object} options - Options dictionary
 * @param {number} options.direction - A valid UIAUtilities.RelativeDirections. i.e.:
 *                      UIAUtilities.RelativeDirections.UP to scroll up to find query
 *                      UIAUtilities.RelativeDirections.DOWN to scroll down to find query,
 *                      UIAUtilities.RelativeDirections.RIGHT to scroll right to find query,
 *                      UIAUtilities.RelativeDirections.LEFT to scroll left to find query
 * @param {number} options.maxScrollAttempts - The max attempts of scrolling to search for the query
 */
UIAApp.prototype.manualScrollToVisible = function manualScrollToVisible(query, options) {
    options = UIAUtilities.defaults(options, {
        direction: UIAUtilities.RelativeDirections.DOWN,
        maxScrollAttempts: 100,
    });

    var isStartOfView = (function isStartOfView(groupedItemViewTypeQuery) {
        var pageIndex = this.inspectElementKey(groupedItemViewTypeQuery, 'pageIndex');
        // page index starts at 1
        return pageIndex === 1;
    }).bind(this);

    var isEndOfView = (function isEndOfView(groupedItemViewTypeQuery) {
        var pageIndex = this.inspectElementKey(groupedItemViewTypeQuery, 'pageIndex');
        var pageCount = this.inspectElementKey(groupedItemViewTypeQuery, 'pageCount');
        return pageIndex && pageCount && pageCount <= pageIndex;
    }).bind(this);

    var scrollForQueryInDirection = (function (query, groupedItemViewTypeQuery, direction, maxScrollAttemps) {
        for (var numberOfScrolls = 0; numberOfScrolls < maxScrollAttemps; numberOfScrolls++) {
            if (this.exists(query.isVisible())) {
                return;
            }
            if (!scrollInDirection(direction, groupedItemViewTypeQuery)) {
                // scroll one more time because final element may be on cusp of page
                scrollInDirection(direction, groupedItemViewTypeQuery);
                if (this.exists(query.isVisible())) {
                    return;
                }
                throw new UIAError('Scrolled to end of %0. Could not find query %1.'.format(groupedItemViewTypeQuery['baseClassName'], query['description']));
            }
        }

        throw new UIAError('Scrolled %0 times and could not find element.'.format(maxScrollAttemps));
    }).bind(this);

    var scrollInDirection = (function (direction, groupedItemViewTypeQuery) {
        var searchBarXYOffSet = {x:0.5, y:0.3};
        switch (direction) {
            case UIAUtilities.RelativeDirections.LEFT:
                this.dragRightInside(groupedItemViewTypeQuery);
                return !isStartOfView(groupedItemViewTypeQuery);
            case UIAUtilities.RelativeDirections.RIGHT:
                this.dragLeftInside(groupedItemViewTypeQuery);
                return !isEndOfView(groupedItemViewTypeQuery);
            case UIAUtilities.RelativeDirections.UP:
                this.dragDownInside(groupedItemViewTypeQuery, {
                    fromOffset: searchBarXYOffSet,
                });
                return !isStartOfView(groupedItemViewTypeQuery);
            case UIAUtilities.RelativeDirections.DOWN:
                this.dragUpInside(groupedItemViewTypeQuery, {
                    toOffset: searchBarXYOffSet,
                });
                return !isEndOfView(groupedItemViewTypeQuery);
            default:
                throw new UIAError("Direction: %0 is not a valid direction. Valid directions are in 'UIAUtilities.RelativeDirections'.".format(direction));
        }
    }).bind(this);

    this.withFauxCellsDisabled(function () {
        var snapshot = this.inspect(UIAQuery.application());
        if (snapshot.exists(UIAQuery.withPredicate("ANY descendants.behavior contains 'TableView'"))) {
            scrollForQueryInDirection(query, UIAQuery.tableViews(), options['direction'], options['maxScrollAttempts']);
        } else if (snapshot.exists(UIAQuery.withPredicate("ANY descendants.behavior contains 'CollectionView'"))) {
            scrollForQueryInDirection(query, UIAQuery.collectionViews(), options['direction'], options['maxScrollAttempts']);
        } else {
            throw new UIAError("Unable to scroll as view does not contain 'TableView' or 'CollectionView'");
        }
    });
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Assertions                                                          */
/*                                                                             */
/*      Functions that perform validations and throw UIAErrors                 */
/*                                                                             */
/*******************************************************************************/

/**
 *  Throws exception if there is no element matching the given query
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} message - error message if thrown
 *  @param  {object} info - additional info to pass to the UIAError constructor
 **/
UIAApp.prototype.assertExists = function assertExists(query, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier: "Failed exists assertion.",
    });

    if (this.exists(query)) return;
    if (!message) message = "Assert exists failed.  %0".format(UIAQuery.query(query).description());
    throw new UIAError(message, info);
}

/**
 *  Throws exception if an element matches the given query
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} message - error message if thrown
 *  @param  {object} info - additional info to pass to the UIAError constructor
 **/
UIAApp.prototype.assertNotExists = function assertNotExists(query, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier: "Failed does not exist assertion.",
    });

    if (!this.exists(query)) return;
    if (!message) message = "Assert not exist failed.  %0".format(UIAQuery.query(query).description());
    throw new UIAError(message, info);
}

/**
 *  Throws exception if there is no visible element matching the given query
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} message - error message if thrown
 *  @param {object} info - additional info to pass to the UIAError constructor
 **/
UIAApp.prototype.assertVisible = function assertVisible(query, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier: "Failed visible assertion.",
    });

    if (this.exists(query.isVisible())) return;
    if (!message) message = "Assert visible failed.  %0".format(UIAQuery.query(query).description());
    throw new UIAError(message, info);
}

/**
 *  Throws exception if there is no enabled element matching the given query
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} message - error message if thrown
 *  @param {object} info - additional info to pass to the UIAError constructor
 **/
UIAApp.prototype.assertEnabled = function assertEnabled(query, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier: "Failed enabled assertion.",
    });

    if (this.exists(query.isEnabled())) return;
    if (!message) message = "Assert enabled failed.  %0".format(UIAQuery.query(query).description());
    throw new UIAError(message, info);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Inspection                                                          */
/*                                                                             */
/*      Functions that perform inspection and throw UIAErrors                  */
/*                                                                             */
/*******************************************************************************/

/**
 *  Throws exception if there is no element matching the given query or 'key' attribute doesn't exist
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} key - attribute to return
 *
 *  @returns 'key' value
 **/
UIAApp.prototype.inspectElementKey = function inspectElementKey(query, key) {
    var node = this.inspect(UIAQuery.query(query));
    if (node === undefined) {
        throw new UIAError('%0 does not exist'.format(query.description()));
    }
    var value = node[key];
    if (value === undefined) {
        throw new UIAError('%0 does not have a value for "%1"'.format(query.description(), key));
    }
    return value;
}

/**
 *  Throws exception if there is no element matching the given query or 'value' attribute doesn't exist
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} key - attribute to return
 *
 *  @returns 'value' value
 **/
UIAApp.prototype.valueOf = function valueOf(query) {
    return this.inspectElementKey(query, 'value');
}

/**
 *  Throws exception if there is no element matching the given query or 'name' attribute doesn't exist
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *  @param  {string} key - attribute to return
 *
 *  @returns 'name' value
 **/
UIAApp.prototype.nameOf = function nameOf(query) {
    return this.inspectElementKey(query, 'name');
}

/**
 *  Alert hack to deal with slow moving UI
 *  Updated from older 'alertHack' to take a stackshot on failure
 *  to heop with debugging.
 *  <rdar://problem/20476611> remove me when fixed!!!
 *  @param  {UIAQuery} query - UIAQuery for element to tap on alert.
 *  @param  {object} options - a dictionary object of additional arguments
 *  @param  {object} [options.alertTimeout=3] - number of seconds to wait for the alert to appear
 *  @param  {object} [options.waiterTimeout=3] - number of seconds to wait for the alert to disappear
 *
 **/
UIAApp.prototype._dismissAlertWithQuery = function _dismissAlertWithQuery(query, options) {
    options = UIAUtilities.defaults(options, {
        alertTimeout: 3,
        waiterTimeout: 3,
    });

    function alertWaiter(alertInfo) {
        var controllerClassName = alertInfo ? alertInfo.controllerClassName : null;
        var waiterPredicate = controllerClassName ? 'controllerClass = "%0"'.format(controllerClassName) : 'true = true';
        return UIAWaiter.withPredicate(
            'ViewDidDisappear',
            waiterPredicate
        );
    }

    if (this.waitUntilPresent(UIAQuery.alerts().isVisible(), options.alertTimeout)) {
        var alertInfo = this.inspect(UIAQuery.alerts().isVisible());
        var waiter = alertWaiter(alertInfo);

        this.tap(query);

        if (!waiter.wait(options.waiterTimeout)) {
            target.stackshot();
            alertInfo = this.inspect(UIAQuery.alerts().isVisible());
            if (alertInfo) {
                UIALogger.logError("Did not dismiss alert '%0' after first attempt".format(alertInfo.name));

                // reset our waiter
                waiter = alertWaiter(alertInfo);

                // using tapIfExists in case alert has gone aways in interm
                if (this.tapIfExists(query) && !waiter.wait(options.waiterTimeout)) {
                    throw new UIAError("Failed to dismiss alert: '%0'".format(this.nameOf(UIAQuery.alerts())));
                }
            } else {
                UIALogger.logWarning('Did not recieved ViewDidDisappear notification but no alerts found');
            }
        }
    } else {
        UIALogger.logWarning('An expected alert failed to appear within a %0 second timeout'.format(options.alertTimeout));
    }
}

/**
 *  Checks to see if the horizontal size class of an element is compact
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *
 * @returns {boolean} true horizontal size class of the element matching the query is compact
 **/
UIAApp.prototype.isHorizontalSizeClassCompact = function isHorizontalSizeClassCompact(query) {
    return this.inspectElementKey(query, 'horizontalSizeClass') == UIUserInterfaceSizeClass.COMPACT;
}

/**
 *  Checks to see if the horizontal size class of an element is regular
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *
 * @returns {boolean} true horizontal size class of the element matching the query is regular
 **/
UIAApp.prototype.isHorizontalSizeClassRegular = function isHorizontalSizeClassRegular(query) {
    return this.inspectElementKey(query, 'horizontalSizeClass') == UIUserInterfaceSizeClass.REGULAR;
}

/**
 *  Checks to see if the vertical size class of an element is compact
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *
 * @returns {boolean} true vertical size class of the element matching the query is compact
 **/
UIAApp.prototype.isVerticalSizeClassCompact = function isVerticalSizeClassCompact(query) {
    return this.inspectElementKey(query, 'verticalSizeClass') == UIUserInterfaceSizeClass.COMPACT;
}

/**
 *  Checks to see if the vertical size class of an element is regular
 *
 *  @param  {object} query - query compatible for element to check for existance of
 *
 * @returns {boolean} true vertical size class of the element matching the query is regular
 **/
UIAApp.prototype.isVerticalSizeClassRegular = function isVerticalSizeClassRegular(query) {
    return this.inspectElementKey(query, 'verticalSizeClass') == UIUserInterfaceSizeClass.REGULAR;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Handlers                                                            */
/*                                                                             */
/*******************************************************************************/

/**
 * Alert handler to allow access to location when requested
 *
 * @returns {boolean} true if an alert was handled
 *
 * Note: Matches 'always', 'when in use', 'reprompt' and 'when in use always' varients of this alert
 *
 */
UIAApp.prototype.allowAccessToLocationAlertHandler = function allowAccessToLocationAlertHandler() {
    return target.performHandlerOnAppWithAlert(UIAQuery.ALLOW_LOCATION_ALERT, function(app, alertInfo) {
        app._dismissAlertWithQuery(UIAQuery.ALLOW_LOCATION_ALERT.andThen(UIAQuery.buttons(LocStrings.LOCATION_ALLOW)));
        return true;
    });
}

/**
 * Alert handler to deny access to location when requested
 *
 * @returns {boolean} true if an alert was handled
 *
 * Note: Matches 'always', 'when in use', 'reprompt' and 'when in use always' varients of this alert
 *
 */
UIAApp.prototype.denyAccessToLocationAlertHandler = function denyAccessToLocationAlertHandler() {
    return target.performHandlerOnAppWithAlert(UIAQuery.ALLOW_LOCATION_ALERT, function(app, alertInfo) {
        app._dismissAlertWithQuery(UIAQuery.ALLOW_LOCATION_ALERT.andThen(UIAQuery.buttons(LocStrings.LOCATION_DONT_ALLOW)));
        return true;
    });
}
