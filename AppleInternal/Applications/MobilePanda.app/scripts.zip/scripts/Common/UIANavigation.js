
UIALogger.logNavigation = function (msg) {
    UIALogger.logMessage("NAVIGATION: %0".format(msg));
}

/**
 * @class
 */

var UIANavigation = function (app, transitions, states) {
	this.transitions = transitions;
	this.states = states;

	//this.paths = getAllPaths(transitions);

    this.navigateUp = navigateUp;
    this.app = app;

    this.conditions = getTransitionConditions(this.transitions);
    this.evaluatedConditions = null;

    function getTransitionConditions(transitions) {
        var conditions = {}
        for (var i=0, transition; transition = transitions[i]; i++) {
            var condition =  transition.transition.condition;
            if (condition) {
                conditions[UIANavigation._getConditionKey(condition)] = condition;

            }
        }
        return conditions;
    }

    function navigateUp(options) {
        UIALogger.logMessage('Attempting to navigate up');

        var buttonsToAvoid = ['Edit', 'Refresh', 'Add'];
        var allowPopovers = false;

        if (options && options.leftButtonsToAvoid) {
            buttonsToAvoid.concat(options.leftButtonsToAvoid)
        }
        if (options && options.allowPopovers) {
            allowPopovers = options.allowPopovers;
        }

        var navbar = UIAQuery.navigationBars().isVisible().last();
        var navbarInfo = UIAQuery.navigationBars().last();
        if (!navbarInfo || !navbarInfo.isVisible) {
            return;
        }

        var iPad = target.model() === 'iPad';

        // Dismiss any active action sheets
        if (this.app.exists(UIAQuery.VISIBLE_SHEETS)) {
            this.app.dismissActionSheet();
            return true;
        }

        // Dismiss any active popovers
        if (this.app.exists(UIAQuery.VISIBLE_POPOVERS) && !allowPopovers) {
            this.app.dismissPopovers();
            return true;
        }

        // Delete an email composition on iPad
        if (this.app.exists(UIAQuery.MAIL_COMPOSE_VIEW.isVisible())) {
            UIALogger.logMessage("Dismiss email composition");
            this.app.tap(UIAQuery.CANCEL_BUTTON);
            this.app.dismissActionSheet();
            return true;
        }

        // Tap the back button if it doesn't match something weird
        var backButton = navbar.andThen(UIAQuery.BACK_NAV_BUTTON);
        var backButtonInfo = this.app.inspect(backButton);
        if (backButtonInfo && backButtonInfo.isVisible) {
            var name = backButtonInfo.label || backButtonInfo.identifier;
            if (name && !buttonsToAvoid.contains(name)) {
                UIALogger.logMessage("Tapping back button: " + name);
                this.app.tap(backButton);
                return true;
            }
        }

        // Tap the cancel button
        if (this.app.tapIfExists(navbar.andThen(UIAQuery.CANCEL_BUTTON.isVisible()))) {
            UIALogger.logMessage("Tapping Cancel button");
            return true;
        }

        // Tap the cancel button on a search
        if (this.app.tapIfExists(UIAQuery.searchBars().parent().andThen('Cancel')) ) {
            UIALogger.logMessage("Tapping Search Bar Cancel button");
            return true;
        }

        // Tap the done button
        if (this.app.tapIfExists(navbar.andThen(UIAQuery.buttons('Done').isVisible()))) {
            UIALogger.logMessage("Tapping Done button");
            return true;
        }

        throw new UIAError('Failed to navigate up');
    }
};

UIANavigation._getConditionKey = function (condition) {
    var key = null;
    if (condition) {
        key = condition.action.name;
        if (condition.options) {
            key += "_" + JSON.stringify(condition.options);
        }
    }
    return key;
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Device States                                                       */
/*                                                                             */
/*      Get information about the state of the device                          */
/*                                                                             */
/*******************************************************************************/
UIANavigation.prototype.updateNavigation = function() {
    var updatedTransitions = this.transitions;
    var newConditions = evaluateConditions(this.app, this.conditions);

    if (!this.evaluatedConditions || JSON.stringify(this.evaluatedConditions) != JSON.stringify(newConditions) ) {
        UIALogger.logMessage("Transition states have changed");
        var validTransitions = [];
        updatedTransitions = [];
        for (var i=0, transition; transition = this.transitions[i]; i++) {
            var condition = transition.transition.condition;
            var transitionValid = Boolean(condition == null || newConditions[UIANavigation._getConditionKey(condition)])
            transition.valid = transitionValid;
            // UIALogger.logMessage(JSON.stringify(transition));
            updatedTransitions.push(transition);
            if (transitionValid) {
                validTransitions.push(transition);
            }

        }
        for (var i=0, transition; transition = validTransitions[i]; i++) {
            // UIALogger.logMessage("from: " + transition.from + " to: " + transition.to);
        }
        this.paths = getAllPaths(validTransitions);
    }

    this.transitions = updatedTransitions
    this.evaluatedConditions = newConditions;


    function evaluateConditions(app, conditions) {
        var evaluatedConditions = {}
        for (var key in conditions) {
            var action = conditions[key].action;
            var options = conditions[key].options;
            evaluatedConditions[key] = action.call(app, options);
        }
        return evaluatedConditions;
    }

    function getAllPaths(transitions) {
        // Check is arrays are identical
        function arraysIdentical(a, b) {
            var i = a.length;
            if (i != b.length) return false;
            while (i--) {
                if (a[i] !== b[i]) return false;
            }
            return true;
        };

        // Grow paths from existing paths and defined state transitions.
        function addNewPaths(transitions, paths) {
            var newPaths = [];
            for (var i=0, path; path = paths[i]; i++) {
                for (var j=0, transition; transition = transitions[j]; j++) {
                    // add new path based on last state of existing path, if the toState doesn't already exist in the path
                    if (transition.from == path[path.length - 1] && path.indexOf(transition.to) == -1) {
                        var newPath = path.concat(transition.to);
                        newPaths.push( newPath );
                    }
                }
            }

            // Remove elements that are already in the list
            for (var i=newPaths.length-1, newPath; newPath = newPaths[i]; i--) {
                for (var j=0, path; path = paths[j]; j++) {
                    if ( arraysIdentical(newPath, path) ) {
                        newPaths.splice(i, 1);
                    }
                }
            }
            return newPaths;
        }

        var paths = [];
        // Start with the basic paths in the defined transitions
        for (var i=0, transition; transition = transitions[i]; i++) {
            path = [transition.from, transition.to];
            paths.push(path);
        }

        // Add new paths and grow the possible paths
        var newPaths = [];
        do {
            newPaths = addNewPaths(transitions, paths);
            if (newPaths.length) {
                paths = paths.concat(newPaths);
            }
        } while(newPaths.length);

        return paths.sort();
    }
}



/**
 * Check is state exists
 *
 * @param {String} stateID - State identifier to check
 *
 * @returns {boolean} Returns true if state exists
 */
UIANavigation.prototype.hasState = function(stateID) {
    return this.getStates().indexOf(stateID) != -1;
}

/**
 * Get list of states
 *
 * @returns {Array} Returns sorted list of all valid state identifiers
 */
UIANavigation.prototype.getStates = function() {
    var allStates = new Array();
    for (var state in this.states) {
        allStates.push(state);
    }
    return allStates.sort();
}

/**
 * Check that the device is in the specified state
 *
 * @param {String} stateID - State identifier to check
 *
 * @returns {boolean} Returns true if the device is in the state
 */
UIANavigation.prototype.isCurrentState = function(stateID) {
    if (this.hasState(stateID)) {
        var action = this.states[stateID].action;
        var options = this.states[stateID].options;
        return action.call(this.app, options);
    }
    return false;
}

/**
 * Get the current state of the device
 *
 * @returns {String} Returns state ID of that the device is currently in
 */
UIANavigation.prototype.getCurrentState = function() {
    for (var i=0, state; state = this.getStates()[i]; i++) {
        if (this.isCurrentState(state)) {
            return state;
        }
    }
    throw new UIAError("Could not determine the current state. Please update the app's state machine.");
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: State Navigation                                                    */
/*                                                                             */
/*      Get information navigating between states                              */
/*                                                                             */
/*******************************************************************************/

/**
 * Check if a path exists to navigate from one state to another.
 *
 * @param {String} fromState - State identifier of starting location
 * @param {String}   toState - State identifier of ending location
 *
 * @returns {boolean} Returns true if path exists
 */
UIANavigation.prototype.hasPath = function(fromState, toState) {
	for (var i=0, path; path = this.paths[i]; i++) {
		if (path[0] == fromState && path[path.length-1] == toState) {
			return true;
		}
	}
	return false;
}

/**
 * Get all navigation paths that exist to navigate from one state to another.
 *
 * @param {String} fromState - State identifier of starting location
 * @param {String}   toState - State identifier of ending location
 *
 * @returns {Array} Returns list of valid paths to navigate between the two states
 */
UIANavigation.prototype.getPaths = function(from, to) {
	var validPaths = [];
    // Return all paths that start with 'fromState' and end with 'toState'
	for (var i=0, path; path = this.paths[i]; i++) {
		if (path[0] == from && path[path.length-1] == to) {
			validPaths.push(path);
		}
	}
    // Sort paths by shortest to longest paths
	return validPaths.sort(function (a, b) { return a.length - b.length; });
}

/**
 * Check if a transition exists directly between two states.
 *
 * @param {String} fromState - State identifier of starting location
 * @param {String}   toState - State identifier of ending location
 *
 * @returns {bool} Returns true if transition exists
 */
UIANavigation.prototype.hasTransition = function(fromState, toState) {
	for (var i=0, transition; transition = this.transitions[i]; i++) {
		if (fromState == transition.from && toState == transition.to && transition.valid && transition.transition) {
			return true;
		}
	}
	return false;
}

/**
 * Get transition function between two states.
 *
 * @param {String} fromState - State identifier of starting location
 * @param {String}   toState - State identifier of ending location
 *
 * @returns {object} Returns transition object {action, options}. null if transition doesn't exist.
 */
UIANavigation.prototype.getTransitionAction = function(fromState, toState) {
	for (var i=0, transition; transition = this.transitions[i]; i++) {
		if (fromState == transition.from && toState == transition.to && transition.valid && transition.transition) {
			return transition.transition;
		}
	}
	return null;
}

/**
 * Perform transition to state
 *
 * @param {String} toState - State identifier to transition to
 *
 * @throws If transition to specified views fails.
 * @throws If transition from specified view does not exist
 */
UIANavigation.prototype.transitionTo = function(toState) {
    var currentState = this.getCurrentState();
    var transition = this.getTransitionAction(currentState, toState);
    if (transition) {
        transition.action.call(this.app, transition.options);
        if (!this.isCurrentState(toState)) {
            UIALogger.logError("Failed to perform transition from '%0' to '%1'".format(currentState, toState));
        }
	} else {
        throw new UIAError("Transition from '%0' to '%1' doesn't exist".format(currentState, toState));
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Navigation Actions                                                  */
/*                                                                             */
/*      Perform transitions between states                                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Navigate to known state
 *
 * @returns {String} Description of the ending state (null if state is unknown)
 */
UIANavigation.prototype.getToKnownState = function() {
    var isNavigateUpSuccuss = true;
	while (isNavigateUpSuccuss && this.getCurrentState() == null) {
		UIALogger.logMessage("Unknown state.  Navigating up");
        isNavigateUpSuccuss = this.navigateUp();
	}
	return this.getCurrentState();
}

/**
 * Navigate to the specified state.  Calls app.launch() first to ensure the app is active and visible
 *
 * @param {String} toState - State identifier of ending location
 *
 * @throws If transition to specified view fails.
 * @throws If transition to specified view results in being in an unknown view.
 *
 * @returns Returns true if the specified state is reached.
 */
UIANavigation.prototype.goTo = function(toState) {
    this.app.launch();
    var reachedTarget = false;

    this.updateNavigation();
    if (!this.hasState(toState)) {
        throw new UIAError('State %0 is not defined'.format(toState));
    }

    // get the known state
    var fromState = this.getToKnownState();
    if (fromState == toState) {
        UIALogger.logMessage('Successfully reached %0'.format(toState));
        return true;
    }

    // get paths to desired state
    var paths = this.getPaths(fromState, toState);
    if (!paths.length) {
        UIALogger.logMessage('No path exists from %0 to %1'.format(fromState, toState));
        if (this.navigateUp()) {
            reachedTarget = this.goTo(toState);
        }

        return reachedTarget
    }

    var nextStateForPaths = [];
    for (var i=0, path; path = paths[i]; i++) {
        if (nextStateForPaths.indexOf(path[1]) == -1) {
            nextStateForPaths.push(path[1]);
        }
    }

    for (var i=0, nextState; nextState = nextStateForPaths[i]; i++) {
        UIALogger.logMessage('Transition from %0 to %1'.format(fromState, nextState));
        this.transitionTo(nextState);
        reachedTarget = this.goTo(toState);
        break;
    }

    if (!this.isCurrentState(toState)) {
        throw new UIAError(
            "Failed to perform transition from '%0' to '%1' after exhausting all state paths."
            .format(fromState, toState)
        );
    }

    return reachedTarget;
}
