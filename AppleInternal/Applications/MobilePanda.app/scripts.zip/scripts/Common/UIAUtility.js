

/**
 * @namespace
 */

UIAUtilities = {};

/**
 * Build a new object with the properties of a and b. Attempts to merge b's
 * properties with a's properties when there's a tie - that is, objects are
 * merged recursively and arrays are concatenated. b's non-array and non-object
 * properties override a's properties where there's a tie. Neither object is
 * mutated.
 *
 * @example
 * > var a = {x: 10, y: [1, 2, 3], z: {m: 45}}
 * > var b = {x: "hello", y:[123], z: {n: 342}}
 * > UIAUtilities.merge(a, b);
 * { x: 'hello',
 *   y: [ 1, 2, 3, 123 ],
 *   z: { m: 45, n: 342 } }
 *
 * @param {object} a Object whose properties will be copied into new object
 * @param {object} b Object whose properties will be copied into new object
 *                 possibly merging with or overriding a's properties.
 * @returns {object}
 */
UIAUtilities.merge = function merge(a, b) {
    a = a || {};
    b = b || {};
    var out = {};
    for (var key in a) {
        if (a.hasOwnProperty(key)) {
            out[key] = a[key];
        }
    }
    for (var key in b) {
        if (b.hasOwnProperty(key)) {
            if (b[key] instanceof Array && a[key] instanceof Array) {
                out[key] = a[key].concat(b[key]);
            } else if (b[key] instanceof Date && a[key] instanceof Date) {
                out[key] = b[key];
            } else if (typeof b[key] === 'object' && typeof a[key] === 'object') {
                out[key] = this.merge(a[key], b[key]);
            } else {
                out[key] = b[key];
            }
        }
    }
    return out;
}

/**
 * Build a new object with the properties of a and b. b's properties
 * override a's properties where there's a tie. Neither object is mutated.
 *
 * @example
 * > var a = {x: 10, y: [1, 2, 3], z: {m: 45}}
 * > var b = {x: "hello", y:[123], z: {n: 342}}
 * > UIAUtilities.override(a, b);
 * { x: 'hello',
 *   y: [ 123 ],
 *   z: { n: 342 } }
 *
 * @param {object} a Object whose properties will be copied into new object
 * @param {object} b Object whose properties will be copied into new object
 *                 possibly overriding a's properties.
 * @returns {object}
 */
UIAUtilities.override = function override(a, b, logResult) {
    a = a || {};
    b = b || {};
    var out = {};
    for (var key in a) {
        if (a.hasOwnProperty(key)) {
            out[key] = a[key];
        }
    }
    for (var key in b) {
        if (b.hasOwnProperty(key)) {
            out[key] = b[key];
        }
    }

    if (logResult === true) UIALogger.logDebug("Properties: " + JSON.stringify(out));

    return out;
}

/**
 * Version of UIAUtilities.override with the arguments flipped.
 * Build a new object with the properties of a and b. a's properties
 * override b's properties where there's a tie. Neither object is mutated.
 *
 * @example
 * > var a = {x: 10, y: 12}
 * > UIAUtilities.defaults(a, {
 *     x: 12,
 *     z: 16
 *   });
 * { x: 10,
 *   y: 12,
 *   z: 16 }
 *
 * @param {object} a Object whose properties will be copied into new object
 * @param {object} b Object whose properties will be copied into new object
 *                 possibly overriding a's properties.
 * @returns {object}
 */
UIAUtilities.defaults = function defaults(a, b, logResult) {
    return this.override(b, a, logResult);
}

/**
 * Get the value of a key from an object and then remove that key. If the key
 * does not exist in the object, returns null or the specified defaultValue.
 *
 * @param {object} object Object that may or may not have key
 * @param {string} key Key to lookup and remove from object
 * @param {object} [defaultValue=null] Value to return if key is not in object
 * @returns {object}
 */
UIAUtilities.popKey = function popKey(object, key, defaultValue) {
    if (typeof defaultValue === 'undefined') {
        defaultValue = null;
    }
    if (object.hasOwnProperty(key)) {
        var value = object[key];
        delete object[key];
        return value;
    }
    return defaultValue;
}

/**
 * Return number within the range [min..max]
 *
 * @param {number} value
 * @param {number} min
 * @param {number} max
 * @param {string} desc- a description of the value to use in logging
 * @returns {number}
 */
UIAUtilities.clamp = function randomInt(value, min, max, desc) {
    if (max < min) {
        UIALogger.logWarning('Swapping limits because max was less than min (min:%0, max:%1)'.format(max, min));
        [min, max] = [max, min];
    }

    var descStr = (typeof desc === 'string') ? 'for \"%0\" '.format(desc) : '';

    if (value < min) {
        UIALogger.logWarning('Value given %0 was too low (using %1)'.format(descStr, min));
        value = min;
    } else if (value > max) {
        UIALogger.logWarning('Value given %0 was too high (using %1)'.format(descStr, max));
        value = max;
    }

    return value;
}

/**
 * Return a random integer in the range [min..max]
 *
 * @param {number} min Minimum possible value
 * @param {number} max Maximum possible value
 * @returns {number}
 */
UIAUtilities.randomInt = function randomInt(min, max) {
    var scale = max - min + 1;
    var random = Math.random();
    return Math.floor(random * scale) + min;
}

/**
 * Return a random element from the given array
 *
 * @param {array} min Minimum possible value
 * @returns {object}
 */
UIAUtilities.randomItem = function randomItem(array) {
    return array[Math.floor(Math.random()*array.length)]
}

/**
 *  Throws exception if expression evaluates to false
 *
 *  @param  {string} expression - expression to evaluate
 *  @param  {string} message - error message if thrown
 *  @param {object} info - additional info to pass to the Error constructor (used by VerboseError)
 **/
UIAUtilities.assert = function assert(expression, message, info) {

    if (expression) return;
    if (!message) message = "Assert failed";
    throw new UIAError(message, info);

}

/**
 *  Throws exception if value1 is not equal to value2
 *
 *  @param  {string}  value1 - one of two values to compare
 *  @param  {string}  value2 - the other value
 *  @param  {string}  message - error message if thrown
 *  @param {object} info - additional info to pass to the Error constructor (used by VerboseError)
 **/
UIAUtilities.assertEqual = function assertEqual(value1, value2, message, info) {

    if (!message) message = "Assert equal failed";
    message += ": '" + value1 + "' != '" + value2 + "'";
    if (!info) info = {};
    if (typeof info.identifier == "undefined") info.identifier = "Failed equal assertion";
    this.assert(value1 == value2, message, info);

}

/**
 *  Throws exception if value1 is equal to value2
 *
 *  @param  {string} value1 - one of two values to compare
 *  @param  {string} value2 - the other value
 *  @param  {string} message - error message if thrown
 *  @param {object} info - additional info to pass to the Error constructor (used by VerboseError)
 **/
UIAUtilities.assertNotEqual = function assertNotEqual(value1, value2, message, info) {

    if (!message) message = "Assert not equal failed";
    message += ": '" + value1 + "' == '" + value2 + "'";
    if (!info) info = {};
    if (typeof info.identifier == "undefined") info.identifier = "Failed not equal assertion";
    this.assert(value1 != value2, message, info);

}

/**
 *  Escapes single and double quotes in a string.
 *
 * @param   {string}  string - the string to escape
 * @returns {string}
 **/
UIAUtilities.escapeQuotes = function escapeQuotes(string) {
    return string.replace(/([\"\'])/g, "\\$1");
}

/**
 *  Escapes double quotes in a string.
 *
 * @param   {string}  string - the string to escape
 * @returns {string}
 **/
UIAUtilities.escapeDoubleQuotes = function escapeDoubleQuotes(string) {
    return string.replace(/([\"])/g, "\\$1");
}

/**
 * Escapes ICU regular expression characters, single and double quotes in a string.
 *
 * @param   {string}  string - the string to escape
 * @returns {string}
 **/
UIAUtilities.escapeString = function escapeString(string) {
    return string.replace(/([\*\?\+\[\(\)\{\}\^\$\]\|\.\/\"\'\\])/g, "\\\\\\$1");
}


/**
 * Build an object with the specifies keys mapped to an increasing sequence of
 * positive numbers. Also maps numbers back to keys for reverse lookup
 *
 * @example
 *   var colors = toEnum('Red', 'Green', 'Blue')
 *   colors.Red === colors.Red
 *   colors.Red < colors.Green
 *   colors[colors.Red] === 'Red'
 *
 * @param   {string}  string - the string to escape
 * @returns {string}
 **/
UIAUtilities.toEnum = function toEnum() {
    var obj = {};
    for(var i = 0; i < arguments.length; ++i) {
        var name = arguments[i];
        var tag = i + 1;
        UIAUtilities.assert(!obj.hasOwnProperty(name), 'Duplicate key: %0'.format(name));
        UIAUtilities.assert(typeof name === 'string', 'Key is not a string: %0'.format(name));
        obj[name] = tag;
        obj[tag] = name;
    }
    return obj;
}

/** @} End of utility group */

UIAUtilities.ElapsedTimeWaiter = function() {
    this.markTime = new Date();
}

UIAUtilities.ElapsedTimeWaiter.prototype = {
    reset: function reset() {
        this.markTime = new Date();
    },

    elapsedSeconds: function elapsedSeconds() {
        return ((new Date()).valueOf() - this.markTime.valueOf())/1000;
    },

    logElapsedTime: function logElapsedTime() {
        UIALogger.logMessage(Math.floor(this.elapsedSeconds()).toString() + " seconds elapsed since mark")
    },

	delayUntilElapsedTime: function delayUntilElapsedTime(seconds) {
        if (seconds < 1) return;
        var elapsedSeconds = this.elapsedSeconds();
        var timeRemaining = seconds - elapsedSeconds;
        if (timeRemaining < 1) return;
        UIALogger.logMessage(Math.floor(elapsedSeconds).toString() + " seconds elapsed since mark.  Delaying for " + Math.floor(timeRemaining).toString() + " seconds.")
        target.delay(timeRemaining);
	}
}

/**
 * The built in string object
 * @extends String
 */

if (!String.prototype.format) {
    Object.defineProperty(String.prototype, 'format', {
        /**
         * Returns a new string replacing specific occurrences of '%' prefixed identifiers with argument data.
         *
         * - occurrences of "%%" replaced with '%'
         * - occurrences of "%<n>" with arguments[n]
         * - occurrences of "%(<key>)" with arguments[length-1][key]
         *
         * @function String#format
         * @returns {string} the reformatted string
         */
        value: function format() {
            var argv = arguments;
            var argc = argv.length;

            var last = argv[argc - 1];
            var kwargs = (argc && typeof last === 'object') ? last : null;

            return this.replace(/%([%]|[\d]+|\([^)]+\))/g, function(match) {
                var string = "";

                if (match === "%%") {
                    string = "%";
                } else if (match[1] === '(') {
                    if (!kwargs) {
                        throw new UIAError("Format key used without providing keyed arguments");
                    }

                    var key = match.slice(2, match.length - 1);
                    string = kwargs[key];
                } else {
                    var index = parseInt(match.slice(1, match.length));
                    if (isNaN(index)) {
                        string = match;
                    } else if (index < argc) {
                        string = argv[index];
                    } else {
                        throw new UIAError("Format index '" + index + "' out of range.");
                    }
                }

                if (typeof string === 'undefined') string = "";
                if (typeof string === 'object' && string instanceof Date) string = string.toISOString();
                if (typeof string !== 'string') string = JSON.stringify(string);

                return string;
            });
        },
    });
}

if (!String.prototype.contains) {
    Object.defineProperty(String.prototype, 'contains', {
        /**
         * Return true if string contains substring otherwise false
         *
         * @function String#contains
         * @param {string} string to look for in the string
         * @returns {bool}
         **/
        value: function contains(x) {
            return this.indexOf(x) !== -1;
        },
    });
}

if (!String.prototype.beginsWith) {
    Object.defineProperty(String.prototype, 'beginsWith', {
        /**
         * Return true if string starts with parameter otherwise false
         *
         * @function String#beginsWith
         * @param {string} string to look for in the string
         * @returns {bool}
         **/
        value: function beginsWith(s) {
            return this.slice(0, s.length) === s;
        },
    });
}

if (!String.prototype.startsWith) {
    Object.defineProperty(String.prototype, 'startsWith', {
        /**
         * Return true if string starts with parameter otherwise false
         *
         * @function String#beginsWith
         * @param {string} string to look for in the string
         * @returns {bool}
         **/
        value: String.prototype.beginsWith,
    });
}

if (!String.prototype.endsWith) {
    Object.defineProperty(String.prototype, 'endsWith', {
        /**
         * Return true if string ends with parameter otherwise false
         *
         * @function String#endsWith
         * @param {string} string to look for in the string
         * @returns {bool}
         **/
        value: function endsWith(s) {
            return this.slice(-s.length) === s;
        },
    });
}

if (!String.prototype.capitalize) {
    Object.defineProperty(String.prototype, 'capitalize', {
        value: function capitalize(s) {
            return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
        },
    });
}

/**
 * The built in array object
 * @extends Array
 */

if (!Array.prototype.contains) {
    Object.defineProperty(Array.prototype, 'contains', {
        /**
         * Return true if array contains value otherwise false
         *
         * @function Array#contains
         * @param {any} value to look for in array
         * @returns {bool}
         **/
        value: function contains(x) {
            return this.indexOf(x) !== -1;
        },
    });
}


if (!Array.prototype.equalsAsSet) {
        /**
         * Return true if array contains the same values as another given array.
         * Order of elements is ignored (essentially a set comparison)
         * Does NOT check for deep/nested arrays!
         *
         * @function Array#equalsAsSet
         * @param {arr} array to compare value to
         * @returns {bool}
         **/
    Object.defineProperty(Array.prototype, 'equalsAsSet', {
        value: function equalsAsSet(arr) {
            return JSON.stringify(this.sort()) === JSON.stringify(arr.sort());
        }
    });
}

if (!Array.prototype.unique) {
    Object.defineProperty(Array.prototype, 'unique', {
        /**
         * Removes any duplicates from an array.
         *
         * @function Array#unique
         * @param {arr} array to remove any duplicate values on
         * @returns {arr} array with only unique values
         **/
        value: function unique() {
            var seen = {};
            return this.reduce(
                function(acc, element) {
                    if (typeof seen[element] === 'undefined') {
                        acc.push(element);
                        seen[element] = true;
                    }
                    return acc;
                },
                []
            );
        }
    });
}

if (!Array.prototype.remove) {
    Object.defineProperty(Array.prototype, 'remove', {
        /**
         * Removes instances of a given value from an array
         *
         * @function Array#remove
         * @param {arr} array to remove value from
         * @returns {arr} array with all instances of the value removed
         **/
        value: function remove() {
            var what, a = arguments, L = a.length, ax;
            while (L && this.length) {
                what = a[--L];
                while ((ax = this.indexOf(what)) !== -1) {
                    this.splice(ax, 1);
                }
            }
            return this;
        }
    });
}

/**
 * The built in Date object
 * @extends Date
 */

if (!Date.prototype.sameDayAs) {
        /**
         * Return true if date is of the same day as another date
         *
         * @function Array#sameDayAs
         * @param {otherDate} other date to compare value to
         * @returns {bool}
         **/
    Object.defineProperty(Date.prototype, 'sameDayAs', {
        value: function sameDayAs(otherDate) {
            return this.getDate() === otherDate.getDate() && this.getMonth() === otherDate.getMonth() && this.getFullYear() === otherDate.getFullYear();
        }
    });
}


/**
 * The current Date constructor can parse DateTime string, but not time strings.
 * This function parses a time string, and returns a new Date with the date components of the passed-in Date object (or new Date())
 *
 * @param {string}   - string representation of the time component of DateTime, i.e. "3:00 PM"
 * @param {Date}     - Date object to override the time components with
 * @returns new Date Object with the parsed time components
 * @extends Date
 */
Date.parseTime = function parseTime(timeStr, dt) {
    if (!dt) dt = new Date();

    var time = timeStr.match(/(\d+)(?::(\d\d))?\s*(p?)/i);
    if (!time) return new Date(NaN);

    var hours = parseInt(time[1], 10);
    if (hours == 12 && !time[3]) {
        hours = 0;
    } else {
        hours += (hours < 12 && time[3]) ? 12 : 0;
    }

    dt.setHours(hours);
    dt.setMinutes(parseInt(time[2], 10) || 0);
    dt.setSeconds(0, 0);
    return dt;
}

/**
 * Replacement for the bind method for binding a function in-place
 *
 * @example
 *   var f = UIAUtilities.bind({x: 10}, function() {
 *     return this.x + this.x;
 *   });
 *
 * @param {object}   - "this" object to bind function to
 * @param {function} - function to be bound to "this"
 * @param {...any}   - Optional arguments to partially apply bound function to
 * @returns bound function
 **/
UIAUtilities.bind = function bind() {
    UIAUtilities.assert(arguments.length >= 2, 'Must specify this object and function');
    var x = arguments[0];
    var f = arguments[1];
    var args = Array.prototype.slice.call(arguments, 2);
    return Function.prototype.bind.apply(f, [x].concat(args));
}

/**
 * Sets the device orienation if it isn't already set correctly.
 *
 * @param {orientation} - the orientation to which the device should be set.
 *
 * @returns - throws an error if something orientation can't be set.
 **/
UIAUtilities.setDeviceOrientation = function setDeviceOrientation(orientation) {
    if (target.deviceOrientation() !== orientation) {
        var stateChangedEvent = UIAWaiter.waiter('OrientationChanged');
        UIALogger.logDebug("Setting device orientation to %0".format(orientation));
        target.setDeviceOrientation(orientation);
        if (!stateChangedEvent.wait(3)) {
            throw new UIAError("Never got the 'Orientation Changed' event.");
        }
    }
    else {
        UIALogger.logDebug("Device orientation was already set correctly--exiting.");
    }
}

/**
 * Queries an http server and records header and status info
 *
 * @param {string} url - the url to query
 * @param {int} options.timeout - the timeout in seconds (default is 30)
 * @param {array} options.curlArgs - list of addition arguments to append to curl command
 *
 * @returns {object} - an object containing the information about the query:
 *      result.success {bool}
 *      result.exitCode {int}
 *      result.timedOut {bool}
 *      result.signal {int}
 *      result.stderr {string}
 *      result.stdout {string}
 *  If successful curl request:
 *      result.responseText {string} === result.stdout
 *      result.responseHeaders {object}
 *      result.requestHeaders {object}
 *      result.statusCode {int}
 *      result.statusText {string}
 *      result.method {string}
 *      result.remotePath {string}
 *      result.remoteHostName {string}
 *      result.remotePort {int}
 *      result.remoteIP {string}
 *      result.requestHTTPVersion {string}
 *      result.responseHTTPVersion {string}
 *
 **/
UIAUtilities.httpQueryUrl = function httpQueryUrl(url, options) {
    options = UIAUtilities.defaults(options, {
        timeout:30,
        curlArgs:[],
    });

    UIALogger.logDebug("Additional curl arguments: " + options.curlArgs);
    var result = target.performTask('/usr/local/bin/curl', ['-v', url].concat(options.curlArgs), options.timeout);

    result.success = false;

    if (result.timedOut) {
        UIALogger.logError('('+url+'): operation timed out');
        return result;
    }

    // if there was an error return without parsing
    if (result.exitCode != 0) {
        UIALogger.logError('('+url+'): failed with exit code: '+result.exitCode);
        UIALogger.logError('('+url+'): stderr: '+result.stderr);
        UIALogger.logError('('+url+'): stdout: '+result.stdout);
        return result;
    }

    result.responseText = result.stdout;

    // init some variables that get parsed out of stderr
    result.responseHeaders = {};
    result.requestHeaders = {};
    result.statusCode = null;
    result.statusText = null;
    result.method = null;
    result.remotePath = null;
    result.remoteHostName = null;
    result.remotePort = null;
    result.remoteIP = null;
    result.requestHTTPVersion = null;
    result.responseHTTPVersion = null;

    var foundHostInfo = false,
        stdErrLines = result.stderr.split(/\s*\n\s*/g),
        foundStatus = false,
        foundRequestInfo = false, match;

    // parse stderr for information
    for (var i=0; i<stdErrLines.length; i++) {
        var line = stdErrLines[i];
        if (line.length == 0) continue;

        // clean out junk
        line = line.replace(/^[\s\d\-:]+/g, '');
        if (line.length == 0) continue;

        if (!foundHostInfo && line[0] === '*'
                && (match = /^\*\s+Connected\s+to\s+([\w\d\.]+)\s+\((\d+\.\d+\.\d+\.\d+)\)\s+port\s+(\d+)\s+\(#\d+\)$/.exec(line))) {
            result.remoteHostName = match[1];
            result.remoteIP = match[2];
            result.remotePort = parseInt(match[3]);
            foundHostInfo = true;
        } else if (line[0] === '>') {
            if (!foundRequestInfo && (match = /^>\s+(GET|POST|PUT|HEAD|DELETE)\s+([\/\w\d\-\s]+)\s+HTTP\/([\d\.]+)$/.exec(line))) {
                result.method = match[1];
                result.remotePath = match[2];
                result.requestHTTPVersion = match[3];
                foundRequestInfo = true;
            } else if (match = /^>\s+([\w\d\-]+):\s+(.+)$/.exec(line)){
                result.requestHeaders[match[1]] = match[2];
            }
        } else if (line[0] === '<') {
            if (!foundStatus && (match = /^<\s+HTTP\/([\d\.]+)\s+(\d+)\s+(.+)$/.exec(line))) {
                result.responseHTTPVersion = match[1];
                result.statusCode = parseInt(match[2]);
                result.statusText = match[3];
                foundStatus = true;
            } else if (match = /^<\s+([\w\d\-]+):\s+(.+)$/.exec(line)) {
                result.responseHeaders[match[1]] = match[2];
            }
        }
    }

    if (result.statusCode == 200)
        result.success = true;

    UIALogger.logMessage('('+url+'): responded with HTTP status: '+result.statusCode);

    return result;
}

/**
 * Pings the host, logs the result, and returns information about the ping
 *
 * @param {string} host - the ip or host name to ping
 * @param {int} options.pingCount - the number of times to ping the remote host (default is 5)
 * @param {int} options.timeout - the timeout for the operation in seconds (default is 30)
 *
 * @returns {object} - an object containing the information about the pings:
 *      result.success {bool}
 *      result.exitCode {int}
 *      result.timedOut {bool}
 *      result.signal {int}
 *      result.stderr {string}
 *      result.stdout {string}
 *  If successful ping request:
 *  	result.packetsTransmitted {int}
 *  	result.packetsReceived {int}
 *  	result.packetLoss {int}
 *  	result.minTime {float}
 *  	result.averageTime {float}
 *  	result.maxTime {float}
 */
UIAUtilities.pingTest = function pingTest(host, options) {
    options = UIAUtilities.defaults(options, {
        pingCount:5,
        timeout:30,
    });

	var result = target.performTask("/sbin/ping", ['-c', String(options.pingCount), host], options.timeout);

	result.success = false;

	if (result.timedOut) {
		UIALogger.logError('('+host+'): operation timed out');
		return result;
	}

	if (result.exitCode != 0) {
		UIALogger.logError('('+host+') failed with exit code: '+result.exitCode);
        if (result.stderr) {
    		UIALogger.logError('('+host+') stderr: '+result.stderr);
        }
        if (result.stdout) {
            UIALogger.logError('('+host+') stdout: '+result.stdout);
        }
		return result;
	}

	result.packetsTransmitted = null;
	result.packetsReceived = null;
	result.packetLoss = null;
	result.minTime = null;
	result.averageTime = null;
	result.maxTime = null;

	var lines = result.stdout.split(/\s*\n\s*/g), match;

	for (var i=0; i<lines.length; i++) {
		if (match = /^(\d+)\s+packets\s+transmitted,\s+(\d+)\s+packets\s+received,\s+([\d\.]+)%\s+packet\s+loss$/.exec(lines[i])) {
			result.packetsTransmitted = parseInt(match[1]);
			result.packetsReceived = parseInt(match[2]);
			result.packetLoss = (result.packetsTransmitted - result.packetsReceived) / result.packetsTransmitted;
		} else if (match = /^round-trip\s+min\/avg\/max\/stddev\s+=\s+([\d\.]+)\/([\d\.]+)\/([\d\.]+)\/([\d\.]+)\s+ms$/.exec(lines[i])) {
			result.minTime = parseFloat(match[1]);
			result.averageTime = parseFloat(match[2]);
			result.maxTime = parseFloat(match[3]);
		}
	}

	if (result.packetLoss == 0)
		result.success = true;

	UIALogger.logMessage('(' + host + '): transmitted = ' + result.packetsTransmitted + ', received = ' + result.packetsReceived
		+ ', loss = ' + (result.packetLoss*100) + '%, avg round trip = ' + result.averageTime + 'ms');

	return result;
}

/**
 * Runs a "test" action followed by a "cleanup" action. The "cleanup" action is executed even if
 * the "test" action fails, and the error thrown by the "test" action is re-thrown after the "cleanup"
 * action completes or fails itself.
 *
 * @example:
 *     UIAUtilities.safeCleanup({
 *         test: function() {
 *             messages.deleteThreads(threads, args.deleteOptions);
 *         },
 *         cleanup: function() {
 *             messages.getToThreadList();
 *         },
 *     });
 *
 * @param {object} obj - Specifies actions to run
 * @param {function} [obj.test] - A test action to run
 * @param {function} [obj.cleanup] - A cleanup action to run
 */
UIAUtilities.safeCleanup = function safeCleanup(obj) {
    var testError, cleanupError, error;
    try {
        obj.test();
    } catch (error) {
        testError = error;
        error = null;
        UIALogger.logMessage('Caught test error; will rethrow after cleanup: ' + testError);
    }

    try {
        obj.cleanup();
    } catch (error) {
        cleanupError = error;
        error = null;
        if (testError) {
            UIALogger.logMessage('Caught error during cleanup; will log before rethrowing test error: ' + cleanupError);
        } else {
            UIALogger.logMessage('Caught error during cleanup; rethrowing: ' + cleanupError);
        }
    }

    if (cleanupError && testError) {
        UIALogger.logError(cleanupError);
        throw testError;
    } else if (cleanupError) {
        throw cleanupError;
    } else if (testError) {
        UIALogger.logMessage('Rethrowing test error now that cleanup has finished');
        throw testError;
    }
}

/**
 * Logs JSON style objects to the results dictionary of a TestAutomation test if it exists
 * If the UITest is being called outside of TestAutomation this has no effect.
 * Logged objects are merged with existing results using update.
 * Newer values will replace old values for the same key.
 *
 * @example:
 *     UIAUtilities.logTAResults({'outcome': '35.0'});
 *
 * @param {object} obj - Key, Value pairs to add to the results of the TestAutomation test
 */
UIALogger.logTAResults = function logTAResults(obj) {
    return UIALogger.logDebug(null, {
        'ObjectType': 'TAResult',
        'Object': obj
    });
}

/**
 *  Returns the total number of seconds that have passed since Jan 1, 1970
 */
UIAUtilities.getCurrentTimeInSeconds = function getCurrentTimeInSeconds() {
    var d = new Date();
    var tis = d.getTime() / 1000;
    return tis;
}

/**
 * Predefined relative directions
 */
UIAUtilities.RelativeDirections = {
    UP: 1,
    DOWN: 2,
    LEFT: 3,
    RIGHT: 4,
}
