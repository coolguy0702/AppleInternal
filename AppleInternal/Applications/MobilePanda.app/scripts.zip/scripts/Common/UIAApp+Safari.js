load('UIAApp.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Localization Strings                                                */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/

/** Address in Safari TextField */
LocStrings.ADDRESS_IN_SAFARI =      target.localizedString(
                                        'address.text',
                                        {tableName:'SafariServicesAccessibility', bundlePath:'/System/Library/AccessibilityBundles/SafariServices.axbundle'}
                                    );

/** Continue */
LocStrings.CONTINUE =               target.localizedString(
                                        'CONTINUE',
                                        {tableName:'Accessibility', bundlePath:'/System/Library/PreferenceBundles/AccessibilitySettings.bundle'}
                                    );

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Helpers                                                                        */
/*                                                                                        */
/*      Helper functions                                                                   */
/*                                                                                        */
/******************************************************************************************/

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/
