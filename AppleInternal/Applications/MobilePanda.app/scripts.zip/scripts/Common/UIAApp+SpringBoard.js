load('UIAApp.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Localization Strings                                                */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/

/** Call Failed */
LocStrings.CALL_FAILED =    target.localizedString(
                                'CALL_FAILED',
                                {tableName: 'USSD', bundlePath: '/System/Library/CoreServices/SpringBoard.app'}
                            );

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/
