/**
 * UIA2 Library for the semaphore tool. Please see http://semaphore.apple.com
 * for more info about the tool.
 */

load('UIAUtility.js');

/**
 * @namespace
 */
Semaphore = {};

/**
 * Constants for possible semphore states.
 */
Semaphore.States = {
    LOCKED:        'locked',

    UNLOCKED:      'unlocked',

    NONEXISTENT:   'nonexistent',
};

/**
 * Constants for possible semphore actions.
 */
Semaphore.Actions = {
    LOCK:        'lock',

    UNLOCK:      'unlock',

    STATUS:      'status',

    DELETE:      'delete',
};

/**
 * Constants for semaphore request transport methods.
 */
Semaphore.TransportMethods = {
    NETWORK:     'network',

    HOST:        'host',
};

/**
 * Semaphore class.
 */
Semaphore.Semaphore = class {
    /**
     * Creates a sempahore object
     *
     * @param {string} uuid - the UUID of the semaphore
     * @param {object} options - optional arguments
     * @param {string} options.transport - specify the method by which semaphore requests will be transported
     *
     * @returns {bool} true if the specified status was acheived, false if there was a timeout
     */
    constructor(uuid, options) {
        options = UIAUtilities.defaults(options, {
            transport: 'network',
        });

        this.uuid = uuid;
        this.lastError = null;
        this.lastPayload = {};

        if (options.transport === Semaphore.TransportMethods.HOST) {
            this.transport = new Semaphore.HostTransport();
        } else {
            this.transport = new Semaphore.NetworkTransport();
        }
    }

    /**
     * Unlocks the semaphore.
     *
     * @param {object} payload - optional payload used to associate data with a semaphore
     *
     * @returns {bool} true on success, false otherwise
     *
     * @throws if an error occurrs
     */
    lock(payload) {
        var result = this.request(Semaphore.Actions.LOCK, payload);

        if (!result['locked']) {
            throw new UIAError('Error locking semaphore');
        }

        return Boolean(result['success']);
    }

    /**
     * Locks the semaphore.
     *
     * @param {object} payload - optional payload used to associate data with a semaphore
     *
     * @returns {bool} true on success, false otherwise
     *
     * @throws if an error occurrs
     */
    unlock(payload) {
        var result = this.request(Semaphore.Actions.UNLOCK, payload);

        if (result['locked']) {
            throw new UIAError('Error unlocking semaphore');
        }

        return Boolean(result['success']);
    }

    /**
     * Fetches the status of the semaphore.
     *
     * @returns {string} the status of the semaphore (locked, nonexistent, etc.)
     */
    status() {
        var result = this.request(Semaphore.Actions.STATUS);

        if ('locked' in result) {
            if (result['locked']) {
                return Semaphore.States.LOCKED;
            } else {
                return Semaphore.States.UNLOCKED;
            }
        } else {
            return Semaphore.States.NONEXISTENT;
        }
    }

    /**
     * Deletes the semaphore.
     *
     * @returns {bool} true on success, false otherwise
     */
    remove() {
        var result = this.request(Semaphore.Actions.DELETE);

        return Boolean(result['success']);
    }

    /**
     * Waits for the semaphore to have a specified status.
     *
     * @param {string} status - the status for which to wait
     * @param {object} options - optional arguments
     * @param {int} options.pollInterval - specify the number of seconds to wait in between poll requests
     * @param {int} options.timeout - specify the timeout in seconds
     *
     * @returns {bool} true if the specified status was acheived, false if there was a timeout
     */
    wait(status, options) {
        options = UIAUtilities.defaults(options, {
            pollInterval: 5,
            timeout: 300,
        });

        var startTime = Date.now() / 1000;

        while (status !== this.status()) {
            var currentTime = Date.now() / 1000;
            if (currentTime > startTime + options.timeout) {
                UIALogger.logWarning('Timed out waiting for semaphore');
                return false;
            }

            target.delay(options.pollInterval);
        }

        return true;
    }

    /**
     * Sends a request to the semaphore service with the specified action.
     *
     * @param {string} action - the action to perform
     * @param {object} payload - optional payload used to associate data with a semaphore
     *
     * @returns {object} the result from the semaphore service
     */
    request(action, payload) {
        var response = this.transport.request(this.uuid, action, payload);

        if ('errorString' in response) {
            this.lastError = response.errorString;
        } else {
            this.lastError = null;
        }

        this.lastPayload = {};
        for (var key in response) {
            if (key !== 'locked' && key !== 'success' && key !== 'errorString') {
                this.lastPayload[key] = response[key];
            }
        }

        return response;
    }

    /**
     * Connects to the semaphore service and downloads the payload.
     *
     * @returns {object} returns the payload data
     */
    fetchPayload() {
        this.status();
        return this.lastPayload;
    }
};

Semaphore.NetworkTransport = class NetworkTransport {
    /**
     * Sends a request to the semaphore service via a network connection.
     *
     * @param {string} uuid - the UUID of the semaphore
     * @param {string} action - the action to perform
     * @param {object} payload - optional payload used to associate data with a semaphore
     *
     * @returns {object} the raw response from the semaphore service
     */
    request(uuid, action, payload) {
        var url = 'http://semaphore.apple.com/%0'.format(action);
        var request = {'uuid': uuid};
        if (typeof payload === 'object' && payload !== null) {
            request = UIAUtilities.merge(request, payload);
        }

        var options = ['-d', JSON.stringify(request)];
        var response = UIAUtilities.httpQueryUrl(url, {curlArgs: options});

        return JSON.parse(response.responseText);
    }
};

Semaphore.HostTransport = class HostTransport {
    /**
     * Sends a request to the semaphore service via a host connection.
     *
     * @param {string} uuid - the UUID of the semaphore
     * @param {string} action - the action to perform
     * @param {object} payload - optional payload used to associate data with a semaphore
     *
     * @returns {object} the raw response from the semaphore service
     */
    request(uuid, action, payload) {
        var requestFilename = '/tmp/uia2-semaphore-request.json';
        var responseFilename = '/tmp/uia2-semaphore-response.json';
        var startTime = Date.now() / 1000;
        var expirationTime = startTime + 60;

        var request = {
            'uuid': uuid,
            'action': action,
            'payload': payload,
            'time': startTime,
            'expiration': expirationTime,
        };

        // Write the request file
        var requestFile = new UIAFile(requestFilename);
        requestFile.open('w','unicode');
        requestFile.write(JSON.stringify(request));
        requestFile.close();

        // Wait for the response to appear
        UIALogger.logDebug('Waiting for the semaphore response file to appear');
        var response = null;
        while (true) {
            if ((Date.now() / 1000) > expirationTime) {
                target.performTask('/bin/rm', [requestFilename]);
                throw new UIAError('Semaphore request timed out over host transport');
            }

            if (UIAFile.fileExists(responseFilename)) {
                UIALogger.logDebug('The semaphore response file has appeared');

                // Read the response
                var responseFile = new UIAFile(responseFilename);
                responseFile.open('r','unicode');
                var readSuccess = true;
                try {
                    response = JSON.parse(responseFile.read());
                } catch (e) {
                    UIALogger.logDebug('Unable to read JSON file');
                    UIALogger.logDebug('%0'.format(e));
                    readSuccess = false;
                } finally {
                    responseFile.close();
                }

                if (readSuccess === true) {
                    break;
                }
            }

            target.delay(0.5);
        }


        // Delete the response
        target.performTask('/bin/rm', [responseFilename]);

        return response;
    }
};
