
load('UIAApp.js');
load('UIAApp+Camera.js');
load('UIAApp+Photos.js');

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Localization Strings                                                           */
/*                                                                                        */
/*      A dictionary of localization look up strings                                      */
/*                                                                                        */
/******************************************************************************************/

/** Delete Draft String */
LocStrings.DELETE_DRAFT =   target.localizedString(
                                'DELETE_DRAFT',
                                {tableName:"Main", bundlePath:"/System/Library/Frameworks/MessageUI.framework"}
                            );

/** MMS Messaging Requires Your Phone Number **/
LocStrings.PHONE_NUMBER_MISSING_ALERT = target.localizedString("MMS_PHONE_NUMBER_MISSING_TITLE", {
                                tableName:"SMSPlugin",
                                bundlePath:"/System/Library/SpringBoardPlugins/ChatKit.servicebundle"});

/** MMS Messaging Requires Your Phone Number - cancel button title **/
LocStrings.PHONE_NUMBER_MISSING_CANCEL = target.localizedString("MMS_INFORMATION_MISSING_CANCEL", {
                                tableName:"SMSPlugin",
                                bundlePath:"/System/Library/SpringBoardPlugins/ChatKit.servicebundle"});

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Query Constants                                                                */
/*                                                                                        */
/*      App specific queries that will be used frequently                                 */
/*                                                                                        */
/******************************************************************************************/

/** Navigation bar found in the composition UI */
UIAQuery.MESSAGE_NEW_COMPOSE_NAVBAR = UIAQuery.navigationBars('New Message').orElse(
    UIAQuery.navigationBars('New iMessage')).orElse(
        UIAQuery.navigationBars('New MMS'));

/** Message to field */
UIAQuery.MESSAGE_TO_FIELD = UIAQuery.textFields('To:').orElse(UIAQuery.textViews('To:'));

/** Message body text entry view */
UIAQuery.MESSAGE_ENTRY_VIEW = UIAQuery.query('MessageEntryView');

/** Message send button */
UIAQuery.MESSAGE_SEND_BUTTON = UIAQuery.buttons('Send').orElse(UIAQuery.buttons('sendButton')).orElse(UIAQuery.query('sendButton'));

/** Messages attach photo to message button */
UIAQuery.PHOTO_BUTTON = UIAQuery.buttons('photoButton').isVisible();

/** Messages arrow button to expand options */
UIAQuery.ARROW_BUTTON = UIAQuery.buttons('arrowButton').isVisible();

/** Scroll view that comes up over the keyboard when sending a photo or video message */
UIAQuery.SELECT_PICTURE_SCROLL_VIEW = UIAQuery.scrollViews('_PXUIScrollView');

/** Send Message Progress Indicator */
UIAQuery.SEND_MESSAGE_PROGRESS_BAR = UIAQuery.query('NavigationBar').andThen(UIAQuery.withPredicate('behavior == "ProgressIndicator"'));

/** Done button in Camera mode */
UIAQuery.CAMERA_DONE_BUTTON = UIAQuery.buttons('Done').orElse(UIAQuery.buttons('PUReviewScreenDoneButton'));

/******************************************************************************************/
/*                                                                                        */
/*   Mark: Actions                                                                        */
/*                                                                                        */
/*      Atomic units of UI automation and helper functions                                */
/*      These will assume the devices is already in the required state                    */
/*                                                                                        */
/******************************************************************************************/

/**
 *  enterMessageRecipients - Enters multiple recipients into the To: field of the message composition UI
 *
 *  @param {array} recipients - an array of recipients or account IDs to send the message to
 **/
UIAApp.prototype.enterMessageRecipients = function enterMessageRecipients(recipients) {

    // Validate preconditions
    UIAUtilities.assert(recipients instanceof Array, 'No recipients specified to enter');
    UIAUtilities.assert(this.isInMessagesCompositionUI(), 'Message composition UI not found');
    this.assertExists(UIAQuery.MESSAGE_NEW_COMPOSE_NAVBAR, 'New message composition UI not found');

    // Enter recipients
    try {
        this.tap(UIAQuery.MESSAGE_TO_FIELD);
        // Clear field
        while (this.inspect(UIAQuery.MESSAGE_TO_FIELD).value !== undefined) {
            this.tap(UIAQuery.keyboard().andThen(UIAQuery.keys('Delete')));
        }

        for (var recipientIndex=0; recipientIndex<recipients.length; recipientIndex++) {
            var recipient = recipients[recipientIndex];

            UIALogger.logMessage('Entering recipient "%0"'.format(recipient));
            if (recipient == 'MY_PHONE_NUMBER' && target.phoneNumber()){
                UIALogger.logMessage('Using the phone number of the device: ' + target.phoneNumber());
                recipient = target.phoneNumber();
            }
            this.enterText(UIAQuery.MESSAGE_TO_FIELD, '%0\n'.format(recipient), {clearTextBeforeTyping:false, allowTypeStringToRetry:true}); // allowTypeToRetry for rdar://problem/21972515
        }

        // This extra return character should exit the To: field and move focus on the message body field
        this.enterText(UIAQuery.MESSAGE_TO_FIELD, '\n', {clearTextBeforeTyping:false});
    } catch (error) {
        error.message = 'Could not enter recipients\n' + error.message;
        throw new UIAError(error.message);
    }
};

/**
 *  enterMessageText - Enters text into the message body field of the message composition UI
 *
 *  @param {string} text - text content of the message being composed
 **/
UIAApp.prototype.enterMessageText = function enterMessageText(text) {

    // Validate preconditions
    UIAUtilities.assert(text, 'No text to enter specified');
    UIAUtilities.assert(this.isInMessagesCompositionUI(), 'Message composition UI not found');

    // Enter recipients
    try {
        // If there are multiple photo objects attached to the message or 
        // if it is a draft that contains text from previous test run,
        // it may appear in contracted form that is a button with 'Photo Message' text in
        // the beginning, or a button with first words of text entered earlier.
        // In such cases we need to tap Send button in order to unfold message text and invoke Keyboard.
        var substrLength = ((text.length > 10) ? 10 : text.length);
        var buttonTextPredicate = 'behavior == "Button" AND name contains "%0"'.format(text.substr(0, substrLength));
        if (this.exists(UIAQuery.withPredicate('behavior == "Button" AND name contains "Photo Message"')) ||
            this.exists(UIAQuery.withPredicate(buttonTextPredicate))) {
            this.tap(UIAQuery.MESSAGE_SEND_BUTTON.isVisible().isEnabled());
        }
        this.tap(UIAQuery.MESSAGE_ENTRY_VIEW);
        UIALogger.logMessage('Entering in message "%0"'.format(text));
        this.enterText(UIAQuery.MESSAGE_ENTRY_VIEW.andThen(UIAQuery.textFields()), text);
    } catch (error) {
        error.message = 'Could not enter message text\n%0'.format(error.message);
        throw error;
    }
};

/**
 *  addMediaToMessage - Selects or captures media to include in the message from the message composition UI
 *
 *  @param {object} media - an object describing the type of media to include in the message
 *  @param {object} media.type = "photo" - type of media to include; "photo", "video" or "audio"
 *  @param {object} media.library - name of the library to include
 *  @param {object} media.mediaDuration - duration to record media (if recording)
 **/
UIAApp.prototype.addMediaToMessage = function addMediaToMessage(media) {
    // Validate preconditions
    if (typeof media !== 'object') {
        UIALogger.logWarning('No media description provided');
        return;
    }
    media = UIAUtilities.defaults(media, {
        type:'photo',
        library:null,
        mediaDuration:5,
    });

    UIAUtilities.assert(this.isInMessagesCompositionUI(), 'Cannot add media.  Not in composition UI');

    // Add the specified media
    try {
        UIALogger.logMessage('Adding %0 to message'.format(media.type));

        if (media.type === 'audio') {
            var audioButton = UIAQuery.buttons('axAudioButton').isVisible();
            if (!this.exists(audioButton)) {
                // Clear text
                UIALogger.logMessage('Clearing message field');
                this.enterMessageText('');
            }

            UIAUtilities.assert(this.exists(audioButton), 'Audio record button is not visible');

            UIALogger.logMessage('Capturing %0'.format(media.type));
            this.touchAndHold(audioButton, media.mediaDuration);
        } else {
            // TODO: As of 17A316 access to Photo Library is available via separate button at the bottom icon bar 
            if (media.library !== null) {
                UIALogger.logMessage('Selecting %0 from library "%1"'.format(media.type, media.library));
                this.waitForViewToAppear('navigationItemTitle == "Photos"', function() {
                    this.tap(UIAQuery.PHOTO_LIRBARY_BUTTON);
                });

                this.waitUntilPresent(media.library, 2);
                this.tap(media.library);

                if (UIATarget.localTarget().model() !== 'iPad') {
                    this.waitUntilPresent(UIAQuery.PHOTOS_FIRST_IN_ALBUM, 2);
                    this.tap(UIAQuery.PHOTOS_FIRST_IN_ALBUM);
                } else if (this.waitUntilPresent(UIAQuery.PHOTOS_FIRST_IN_ALBUM), 2) {
                    this.tap(UIAQuery.PHOTOS_FIRST_IN_ALBUM);
                }
                if (this.waitUntilPresent(UIAQuery.CAMERA_CHOOSE_BUTTON.orElse(UIAQuery.CAMERA_USE_BUTTON), 2)){
                    this.tap((UIAQuery.CAMERA_CHOOSE_BUTTON).orElse(UIAQuery.CAMERA_USE_BUTTON));
                }
            } else {
                if (this.waitUntilPresent(UIAQuery.ARROW_BUTTON, 3)) {
                    //<rdar://problem/23691755>
                    target.delay(2);
                    this.tap(UIAQuery.ARROW_BUTTON);
                }

                // As of 17A316 Photo button opens only Camera, no options for Photo Album
                var cameraViewWaiter = UIAWaiter.withPredicate(
                    'ViewDidAppear',
                    'controllerClass == "CAMPreviewViewController"'
                );
                this.tap(UIAQuery.PHOTO_BUTTON);
                UIAUtilities.assert(
                    cameraViewWaiter.wait(10),
                    'Failed to open Camera from Messages'
                );

                UIALogger.logMessage('Capturing %0'.format(media.type));

                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.query('CameraMode'), 10),
                    'Failed to get to Camera controls'
                );

                if (media.type === 'photo') {
                    this.setCameraMode(CameraMode.PHOTO);
                } else if (media.type === 'video') {
                    this.setCameraMode(CameraMode.VIDEO);
                } else {
                    var error = new UIAError(
                        'Unknown or unsupported media type "%0"'.format(media.type),
                        {identifier:'Message media type is unknown'}
                    );
                    UIALogger.logError(error);
                }

                target.delay(2); // FIXME

                if (media.type === 'video') {
                    // if we're taking a video start the video now
                    target.delay(media.mediaDuration);
                    this.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);
                }

                var reviewViewWaiter = UIAWaiter.withPredicate(
                    'ViewDidAppear',
                    'controllerClass = "PUOneUpViewController"'
                );

                // stop taking video or take the photo
                this.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);

                if (!reviewViewWaiter.wait(10)) {
                    throw new UIAError('Review View did not appear after taking a picture or video for a message.');
                }

                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.CAMERA_DONE_BUTTON.isVisible(), 10),
                    'Done button did not appear'
                );
                var messagesViewWaiter = UIAWaiter.withPredicate(
                    'ViewDidAppear',
                    'controllerClass = "AEMessagesShelfViewController"'
                );
                this.tapIfExists(UIAQuery.CAMERA_DONE_BUTTON.isVisible());
                UIAUtilities.assert(
                    messagesViewWaiter.wait(10.0),
                    'Failed to get back to Messages view from Camera'
                );
            }
        }
    } catch (error) {
        error.message = 'Could not add media to message: [%0]\n'.format(error.message);
        throw error;
    }
    UIALogger.logMessage('Media attached');
};

/**
 *  Checks the delivery status of the last message
 *
 * @returns {boolean} true if not delivered, false otherwise
 */
UIAApp.prototype.messageNotDelivered = function messageNotDelivered(timeout) {
    var result = true;

    // If progress bar is present, wait until it's gone 
    if (this.waitUntilPresent(UIAQuery.SEND_MESSAGE_PROGRESS_BAR, 5)) {
        // Fail the test if the process timed out
        UIAUtilities.assert(
            (this.waitUntilAbsent(UIAQuery.SEND_MESSAGE_PROGRESS_BAR, timeout)), 
            'Sending process timed out after %0 sec, but not completed'.format(timeout)
        );
    }

    // Number of elements in TableCell collection within the thread 
    var cellCnt = this.count(UIAQuery.query('TranscriptCollectionView').andThen(UIAQuery.tableCells())); 
    if (cellCnt === 0) {
        return result;
    }

    // Delivery Status query
    var deliveryStatusQuery = UIAQuery.query("TranscriptCollectionView").andThen(UIAQuery.tableCells().atIndex(cellCnt - 1)).andThen(UIAQuery.staticTexts());
    if (this.waitUntilPresent(deliveryStatusQuery, 30)) {
        // Delivery Status of the last message ("Not Delivered", "Delivered" or "Read")
        var deliveryStatus = this.inspect(deliveryStatusQuery).name;
        UIALogger.logMessage('Delivery status of the last message in the current thread: "%0"'.format(deliveryStatus));
        if (deliveryStatus !== 'Not Delivered') {
            result = false;
        }
    } else {
        // If delivery status is not shown, the message is delivered
        UIALogger.logMessage('Delivery status is not shown');
        result = false;
    }
    UIALogger.logMessage('Message Not Delivered: %0'.format(result));
    return result;
}; 

/**
 *  Sends a message.
 *
 * @param {object}  options - a dictionary object of optional arguments
 * @param {string}  options.recipients - an array of phone numbers or addresses to send to
 * @param {string} options.text - text to include in the message body
 * @param {object} options.media - an object describing the type of media to include in the message
 * @param {number} options.timeout - (Optional) timeout (in seconds) to wait for delivery of the message  
 *  (see [UIAApp+Message.addMediaToMessage]{@link UIAApp+Message#addMediaToMessage} for more details)
 */
UIAApp.prototype.sendMessage = function sendMessage(options) {
    options = UIAUtilities.defaults(options, {
        recipients: null,
        text: null,
        media: null,
        timeout: 60, 
    });

    if (options.text !== null && options.media !== null && options.media.type === 'audio') {
        throw new UIAError("Cannot specify both text and media='audio'");
    }

    if (options.recipients && !(options.recipients instanceof Array)) {
        options.recipients = [options.recipients];
    }

    // Enter recipients
    if (options.recipients && options.recipients.length > 0) {
        this.enterMessageRecipients(options.recipients);
    }

    // Enter message text
    if (options.text !== null) {
        this.enterMessageText(options.text);
    }

    // Add media
    if (options.media !== null) {
        this.addMediaToMessage(options.media);
    }

    // Send
    try {
        var sendAudioMessage = UIAQuery.buttons('ActionMenuChatSend');
        if (this.exists(sendAudioMessage)) {
            // Send audio message
            UIALogger.logMessage('Sending audio message');
            this.tap(sendAudioMessage);
        } else if (this.waitUntilPresent(UIAQuery.MESSAGE_SEND_BUTTON.isVisible().isEnabled(), 2)) {
            // If there are multiple photo objects attached to the message or 
            // if it is a draft that contains text from previous test run,
            // it may appear in contracted form that is a button with 'Photo Message' text in
            // the beginning, or a button with first words of text entered earlier.
            // In such cases we need to tap Send button twice.
            if (this.exists(UIAQuery.withPredicate('behavior == "Button" AND name contains "Photo Message"'))) {
                this.tap(UIAQuery.MESSAGE_SEND_BUTTON.isVisible().isEnabled());
            } else if (options.text !== null) {
                var substrLength = ((options.text.length > 10) ? 10 : options.text.length);
                var buttonTextPredicate = 'behavior == "Button" AND name contains "%0"'.format(options.text.substr(0, substrLength));
                if (this.exists(UIAQuery.withPredicate(buttonTextPredicate))) {
                    this.tap(UIAQuery.MESSAGE_SEND_BUTTON.isVisible().isEnabled());
                }
            }
            // Send regular message
            UIALogger.logMessage('Sending message');
            //<rdar://problem/23691755>
            this.delay(2);
            this.tap(UIAQuery.MESSAGE_SEND_BUTTON.isVisible().isEnabled());
        } else {
            throw new UIAError('Cannot send message. No button to tap');
        }
        // This handles the case, when the Send Audio Message is not executed.
        this.tapIfExists(sendAudioMessage);
        if (this.messageNotDelivered(options.timeout)) {
            throw new UIAError('The message was not delivered');
        }
    }
    catch (error) {
        error.message = 'Could not send message\n' + error.message;
        throw new UIAError(error.message);
    }
};

/**
 * Set up a waiter for a message announcement, execute the body, and then wait for the matching announcement
 *
 * @param {object}  options - a dictionary object of optional arguments
 * @param {array}  [options.messages=null] - an array of objects describing messages to expect {text:<text>, sender:<address or phone number>}
 * @param {array}  [options.messageCount=1] - the number of messages to expect (unused if messages is specified)
 * @param {number} [options.timeout=60] - how long to wait for the incomming messages
 * @param {function} trigger - a function to execute before waiting
 *
 * @returns {number} the percent of the expected messages that were confirmed
 */
UIAApp.prototype.receiveMessages = function receiveMessages(options, trigger) {
    options = UIAUtilities.defaults(options, {
        messages:null,
        messageCount:1,
        timeout:60,
    });

    var messageCount = (options.messages) ? options.messages.length : options.messageCount;
    var expectedMessages = (options.messages) ? options.messages : [];

    // initialize messages array so that they all have the same format
    var expectedMessage;
    for (var messageIndex = 0; messageIndex < expectedMessages.length; messageIndex++) {
        expectedMessage = expectedMessages[messageIndex];

        if (!(typeof expectedMessage.text === 'string' || expectedMessage.text instanceof String)) {
            expectedMessage.text = null;
        }

        if (!(typeof expectedMessage.sender === 'string' || expectedMessage.sender instanceof String)) {
            expectedMessage.sender = null;
        }

        expectedMessages[messageIndex] = expectedMessage;
    }

    var messageCounter = 0; // the count of announcements have been verified

    // used by announcement waiter to verify the incomming message announcements
    var verifyReceivedMessage = function verifyReceivedMessage(messageInfo) {
        if (expectedMessages.length) {
            for (var messageIndex = 0; messageIndex < expectedMessages.length; messageIndex++) {
                var isMatch = true;
                var expectedMessage = expectedMessages[messageIndex];
                var announcement = messageInfo.announcement;

                UIALogger.logDebug('Checking announcement "%0" ...'.format(announcement));

                if (expectedMessage.text !== null) {
                    // check message text
                    UIALogger.logDebug('... with text "%0"'.format(expectedMessage.text));
                    isMatch &= (announcement.indexOf(expectedMessage.text) > 0);
                }

                if (expectedMessage.sender !== null) {
                    UIALogger.logDebug('... from sender "%0"'.format(expectedMessage.sender));

                    var addressExp = new RegExp(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/);
                    var digits = [];

                    // if the string does not match the addressExp above and includes digits,
                    // assume this is a phone number and verify the digits only
                    if (expectedMessage.sender.match(addressExp) === null) {
                        // if the sender contains only digits use an alternate which matches the sequence of digits
                        digits = expectedMessage.sender.match(/(^[+])|(\d)/g);
                    }

                    if (digits !== null && digits.length > 0) {
                        var matchString = (".*" + digits.join("[^\d]*") + ".*").replace("+", "\\+");
                        UIALogger.logDebug('... (match using %0)'.format(matchString));
                        isMatch &= (announcement.match(matchString) !== null);
                    } else {
                        isMatch &= (announcement.indexOf(expectedMessage.sender) > -1);
                    }
                }

                if (expectedMessage.media) {
                    // check media
                    UIALogger.logDebug('... for media attachment');
                    isMatch &= (announcement.indexOf('attachment') > 0);
                }

                if (isMatch) {
                    UIALogger.logDebug('Announcement received is a match');
                    expectedMessages.splice(messageIndex, 1);
                    messageIndex--;   // remove found messages
                    messageCounter++;
                } else {
                    UIALogger.logDebug('Announcement received is not a match');
                }
            }
        } else {
            UIALogger.logDebug('Announcement received');
            messageCounter++;
        }
    };

    var waiter = UIAWaiter.withPredicate('Announcement', 'announcement CONTAINS "Message received:"', {count:messageCount});

    trigger.call(this);

    UIALogger.logMessage('Waiting up to %0 seconds for %1 message(s)'.format(options.timeout, messageCount));
    waiter.wait(options.timeout, verifyReceivedMessage);

    var percentReceived = (messageCounter/messageCount)*100;

    UIALogger.logDebug('%0% of expected messages received'.format(percentReceived));

    var textString;
    var senderString;
    for (var messageIndex = 0; messageIndex < expectedMessages.length; messageIndex++) {
        expectedMessage = expectedMessages[messageIndex];
        textString = ((expectedMessage.text !== null) && (expectedMessage.text.length > 0)) ? ' with text "%0"'.format(expectedMessage.text) : "";
        senderString = ((expectedMessage.sender !== null) && (expectedMessage.sender.length > 0)) ? ' from "%0"'.format(expectedMessage.sender) : "";
        UIALogger.logWarning('Failed to receive message from sender "%0" with text "%1"'.format(senderString, textString));
    }

    return percentReceived;
};

/**
 * Set up a waiter for incomming message announcements, send a message and then wait for the announcements
 *
 * @param {object}  options - a dictionary object of optional arguments
 * @param {object}  [options.sendOptions={}] - options to configure the message send
 *  (see [UIAApp+Message.sendMessage]{@link UIAApp+Message#sendMessage} for more details on options)
 * @param {object}  [options.receiveOptions={}] - options to configure the message reply
 *  (see [UIAApp+Message.recieveMessage]{@link UIAApp+Message#receiveMessages} for more details on options)
 * @param {array}  [options.minPercent=100] - the minimum percent of message count to expect
 * @param {number} [options.retryCount=0] - how many times to retry if minPercent condition is not met
 */
UIAApp.prototype.sendReceiveMessage = function sendReceiveMessage(options) {
    options = UIAUtilities.defaults(options, {
        sendOptions:{},
        receiveOptions:{},
        minPercent:100,
        retryCount:0
    });

    if (options.recipients && !(options.recipients instanceof Array)) {
        options.recipients = [options.recipients];
    }

    // when no other validation is specified assume that there should be a response from each recipient
    if ((options.receiveOptions.messageCount === 'undefined') &&
        (typeof options.receiveOptions.messages === 'undefined') &&
        (typeof options.sendOptions.recipients !== 'undefined')) {

        options.receiveOptions.messages = [];
        var recipients = options.sendOptions.recipients;

        for (var recipientIndex = 0; recipientIndex < recipients.length; recipients++) {
            options.receiveOptions.messages.push({sender:recipients[recipientIndex]});
        }

    } else {
        options.receiveOptions.messageCount = 1;
    }

    var retryCounter = 0;
    var runningPercent = 0;
    var percentReceived;
    var message;
    do {
        percentReceived = this.receiveMessages(options.receiveOptions, function() {
            this.sendMessage(options.sendOptions);
        });
        runningPercent = ((runningPercent*retryCounter)+percentReceived)/(retryCounter+1);

        if (runningPercent < options.minPercent) {
            if (retryCounter < options.retryCount) {
                message = '%0% of the expected responses received'.format(percentReceived);
                UIALogger.logWarning('%0 (attempt %1 of %2)'.format(message, retryCounter+1, options.retryCount+1));
            } else {
                message = '%0% of the total expected message responses received was less than the required %1%'.format(runningPercent, options.minPercent);
                throw new UIAError(message, {identifier:'Not all of the expected message responses were received'});
            }
        } else {
            break;
        }

    } while (retryCounter++ < options.retryCount);
};

UIAApp.prototype.isInMessagesCompositionUI = function isInMessagesCompositionUI() {
    var wait = 2;
    return this.waitUntilPresent(UIAQuery.MESSAGE_ENTRY_VIEW, wait);
};
