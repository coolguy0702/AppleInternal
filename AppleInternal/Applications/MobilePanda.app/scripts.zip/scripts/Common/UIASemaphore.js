/**
 * UIA2 Library for the semaphore tool. Please see http://semaphore.apple.com
 * for more info about the tool.
 *
 * High level functions and helpers:
 *		- lock: locks semaphore
 *		- unlock: unlocks semaphore
 *      - isLocked: returns true/false if semaphore is locked
 *		- getPayload: gets the payload info from the semaphore
 *      - pollForLocked: polls semaphore for locked state. Throws if  if polling time is exhausted
 *      - pollForUnlocked: polls semaphore for unlocked state. Throws if if polling time is exhausted
 *
 *      - poll: polls semaphore for desired locked state. Returns state if polling time is exhausted
 *      - getStatus: gets unparsed semaphore response object (stdout of curl call)
 *      - getLockStatus: returns if semaphore is 'locked' or 'unlocked'
 */

/**
 * @namespace
 */
UIASemaphore = {};

/**
 * Constants for possible semphore states.
 */
UIASemaphore.States = {
    LOCKED:        'locked',

    UNLOCKED:      'unlocked',
};

/**
 * Constants for possible semphore actions.
 */
UIASemaphore.Actions = {
    LOCK:        'lock',

    UNLOCK:      'unlock',

    STATUS:      'status',
        
    DELETE:      'delete',
};

/**
 * Calls the semaphore on the supplied uuid with supplied action (lock, unlock,
 * status). Optionally takes a payload.
 *
 * @memberof UIASemaphore
 * @param {string} action - Action for the semaphore (lock, unlock, status)
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {object} options.payload - Object of key/value pairs to send with
 *						curl call.
 *
 * @returns {object} semaphore response object (stdout of curl call)
 *
 * @throws If curl to semaphore was unsuccessful
 */
UIASemaphore.callSemaphore = function callSemaphore(action, uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        payload: null,
    });

    if (action !== UIASemaphore.Actions.LOCK
            && action !== UIASemaphore.Actions.UNLOCK
            && action !== UIASemaphore.Actions.STATUS
            && action !== UIASemaphore.Actions.DELETE) {
        throw new UIAError('Unsupported action: \'%0\''.format(action));
    }

    var url = 'http://semaphore.apple.com/%0.json'.format(action);
    var postObject = {'uuid':uuid};
    if (options.payload) postObject = UIAUtilities.merge(postObject, options.payload);
    options.curlArgs = ['-d', JSON.stringify(postObject)];

    UIALogger.logMessage('Calling semaphore with action \'%0\''.format(action));
    var result = UIAUtilities.httpQueryUrl(url, options);

    if (!result.success) {
        throw new UIAError('Unable curl semaphore for %0.'.format(action));
    }

    UIALogger.logMessage('Semaphore response: %0'.format(result.responseText));

    return JSON.parse(result.responseText);
}

/**
 * locks/unlocks a semaphore and parses the result. If command
 * succeeded returns true.
 *
 * @memberof UIASemaphore
 * @param {string} action - Action for the semaphore (lock, unlock)
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {object} options.payload - Object of key/value pairs to send with
 *						curl call.
 * @param {object} options.throwOnFail - Throw if lock/unlock command fails
 *
 * @returns {boolean} true if command succeeds, false otherwise
 *
 * @throws If lock/unlock command failed.
 */
UIASemaphore.setLock = function setLock(action, uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        payload: null,
        throwOnFail: true,
    });

    if (action !== UIASemaphore.Actions.LOCK
            && action !== UIASemaphore.Actions.UNLOCK) {
        throw new UIAError('Unsupported action: \'%0\''.format(action));
    }

    var result = this.callSemaphore(action, uuid, options);

    if (result.success && result.success === 1) {
        return true;
    }

    if (options.throwOnFail) {
        throw new UIAError('Unable to set lock to \'%0\''.format(action));
    } else {
    	return false;
    }
}

/**
 * Locks a semaphore for the specified uuid.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {object} options.payload - Object of key/value pairs to send with
 *						curl call.
 * @param {object} options.throwOnFail - Throw if lock/unlock command fails
 *
 * @returns {boolean} true if command succeeds, false otherwise
 *
 * @throws If lock/unlock command failed.
 */
UIASemaphore.lock = function lock(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        payload: null,
        throwOnFail: true,
    });

    return this.setLock(UIASemaphore.Actions.LOCK, uuid, options);
}

/**
 * Unlocks a semaphore for the specified uuid.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {object} options.payload - Object of key/value pairs to send with
 *						curl call.
 * @param {object} options.throwOnFail - Throw if lock/unlock command fails
 *
 * @returns {boolean} true if command succeeds, false otherwise
 *
 * @throws If lock/unlock command failed.
 */
UIASemaphore.unlock = function unlock(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        payload: null,
        throwOnFail: true,
    });

    return this.setLock(UIASemaphore.Actions.UNLOCK, uuid, options);
}

/**
 * Gets the status of a semaphore for the specified uuid. Returns the
 * entire semaphore response object (stdout of curl call).
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 *
 * @returns {object} semaphore response object (stdout of curl call)
 *
 * @throws If uuid for semaphore is not enabled or status is malformed.
 */
UIASemaphore.getStatus = function getStatus(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
    });

    var result = this.callSemaphore(UIASemaphore.Actions.STATUS, uuid, options);

    if (result.errorString && result.errorString.indexOf('No status for uuid') > -1) {
        throw new UIAError('uuid \'%0\' is not enabled.'.format(uuid));
    }

    if (result.locked == null) {
        throw new UIAError('No locked status for uuid \'%0\''.format(uuid));
    }

    return result;
}

/**
 * Gets the locked status of a semaphore for the specified uuid. Returns
 * either 'locked' or 'locked' parsed from semaphore response.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 *
 * @returns {string} Returns 'locked' or 'locked' parsed from semaphore
 *						response object (stdout of curl call)
 *
 * @throws If locked value is malformed.
 */
UIASemaphore.getLockStatus = function getLockStatus(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
    });

    var result = this.getStatus(uuid, options);

    if (result.locked === 1) {
        return UIASemaphore.States.LOCKED;
    } else if (result.locked === 0) {
        return UIASemaphore.States.UNLOCKED;
    } else {
        throw new UIAError('Unexpected locked value \'%0\' for uuid \'%1\''.format(result.locked, uuid));
    }
}

/**
 * Returns true/false if the semaphore is locked.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 *
 * @returns {boolean} True, semaphore locked. False, semaphore unlocked.
 */
UIASemaphore.isLocked = function isLocked(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
    });

    if (this.getLockStatus(uuid, options) === UIASemaphore.States.LOCKED) {
        return true;
    } else {
        return false;
    }
}

/**
 * Gets the payload of a semaphore for the specified uuid.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 *
 * @returns {null|string} Returns payload of the semaphore or null if
 *						payload doesn't exists.
 */
UIASemaphore.getPayload = function getPayload(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
    });

    var result = this.getStatus(uuid, options);

    delete(result.locked);
    if (Object.keys(result).length === 0 ) {
    	result = null;
    }

    return result;
}

/**
 * Polls a semaphore until the lock state is changed to the supplied state
 * or until we exceed the polling time. If no 'waitForState' is given,
 * we default to waiting for a 'unlocked' state. If no pollTime is given, we
 * default to 300 seconds.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {number} options.waitForState - Lock state to poll for
 * @param {number} options.pollTime - Amount of time to poll for
 * @param {number} options.delayTime - Time to delay before next semaphore call
 *
 * @returns {string} Returns semaphore lock state
 */
UIASemaphore.poll = function poll(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        waitForState: UIASemaphore.States.UNLOCKED,
        pollTime: 300,
        delayTime: 5,
    });

    var result;

    for (var i = 0; i < Math.floor(options.pollTime/options.delayTime); i++) {
        try {
            result = this.getLockStatus(uuid);
        } catch (e) {
            target.delay(options.delayTime);
            continue;
        }

        if (result !== options.waitForState) {
            target.delay(options.delayTime);
        } else {
            break;
        }
    }

    UIALogger.logMessage('Polling complete. Semaphore state: \'%0\'.'.format(result));

    return result;
}

/**
 * Polls a semaphore until the lock state is changed 'unlocked'
 * or until we exceed the polling time. If we exceed the wait time and the
 * semaphore is not in the desired state we throw.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {number} options.waitForState - Lock state to poll for
 * @param {number} options.pollTime - Amount of time to poll for
 * @param {number} options.delayTime - Time to delay before next semaphore call
 *
 * @throws If semaphore still locked after exhausting the polling time.
 */
UIASemaphore.pollForUnlocked = function pollForUnlocked(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        waitForState: UIASemaphore.States.UNLOCKED,
        pollTime: 300,
        delayTime: 5,
    });

    if (this.poll(uuid, options) === UIASemaphore.States.LOCKED) {
        throw new UIAError('Semaphore \'%0\' never unlocked'.format(uuid));
    }
}

/**
 * Polls a semaphore until the lock state is changed 'lock'
 * or until we exceed the polling time. If we exceed the wait time and the
 * semaphore is not in the desired state we throw.
 *
 * @memberof UIASemaphore
 * @param {string} uuid - uuid of the semaphore
 * @param {object} options - Options dictionary
 * @param {number} options.timeout - Timeout for the curl operation in seconds
 * @param {number} options.waitForState - Lock state to poll for
 * @param {number} options.pollTime - Amount of time to poll for
 * @param {number} options.delayTime - Time to delay before next semaphore call
 *
 * @throws If semaphore still unlocked after exhausting the polling time.
 */
UIASemaphore.pollForLocked = function pollForLocked(uuid, options) {
    options = UIAUtilities.defaults(options, {
        timeout: 30,
        waitForState: UIASemaphore.States.LOCKED,
        pollTime: 300,
        delayTime: 5,
    });

    if (this.poll(uuid, options) === UIASemaphore.States.UNLOCKED) {
        throw new UIAError('Semaphore \'%0\' never locked'.format(uuid));
    }
}







