

load("UIAUtility.js");

/**
 * @extends UIATarget
 */

if (typeof target == 'undefined') {
    target = UIATarget.localTarget();
}

// Add bound versions of the UIATarget functions to the global namespace
// FIXME: why can't we iterate through the property keys?
for (var propertyKey in UIATarget.prototype) {
    var property = UIATarget.prototype[propertyKey];
    if (typeof property == 'function') {
        if (typeof this[propertyKey] == 'undefined') {
            UIALogger.logDebug("Adding function '" + propertyKey + "' to the global namespace and binding to local target.");
            this[propertyKey] = property.bind(target);
        } else {
            UIALogger.logDebug("Function '" + propertyKey + "' already exists in the global namespace.  Skip binding.");
        }
    }
}

/**
 * Checks the active apps for alerts and passes the app which contains the alert to the callback function
 *
 * @param  {object} query - query for the alert
 * @param  {function} callback - function to call with the alert's app
 *
 * @returns {boolean} the value returned by the callback function
 */
UIATarget.prototype.performHandlerOnAppWithAlert = function performHandlerOnAppWithAlert(query, callback) {
    var apps = target.activeApps();
    for (var index = 0; index < apps.length; index++) {
        var app = apps[index];
        var alertInfo;
        if (alertInfo = app.inspect(query)) {
            return callback(app, alertInfo);
        }
    }

    return false;
}

/**
 * Takes stackshots
 *
 * @param   {object} options            - a dictionary object of optional arguments
 * @param   {string} [options.basePath] - path to save the stackshots to
 * @param   {number} [options.count=2]  - number of stackshots to take (default 2, value must be between 1 and 20)
 * @param   {number} [options.delay=1]  - number of seconds between stackshots (default 1, values less than 1 result in a single stackshot)
 */
UIATarget.prototype.stackshot = function stackshot(options) {
    options = UIAUtilities.defaults(options, {
        count: 2,
        delay: 1,
        basePath: '/var/mobile/Library/Logs/CrashReporter',
    });

    var count = UIAUtilities.clamp(options.count, 1, 20, 'count');
    var delay = UIAUtilities.clamp(options.delay, 1, 10, 'delay');
    var seconds = delay * count;

    var stackshotCommand = 'crstackshot';
    var stackshotArguments = '-b \"%0\" -d %1 -s %2'.format(options.basePath, delay, count);

    var shellPath = '/bin/sh';
    var shellCommand = '(%0 %1 &); sleep %2; killall %0 -INT'.format(stackshotCommand, stackshotArguments, seconds);
    var shellArguments = ['-c', shellCommand];

    UIALogger.logMessage("Taking %0 stackshots using %1 second delay ...".format(count, delay));
    var result = this.performTask(shellPath, shellArguments, seconds + 10);
    if (typeof result.stderr === 'string' && result.stderr.length > 0) {
        UIALogger.logDebug("stderr:\n" + result.stderr);
    }

    if (typeof result.stdout === 'string' && result.stdout.length > 0) {
        UIALogger.logDebug("stdout:\n" + result.stdout);
    }
}