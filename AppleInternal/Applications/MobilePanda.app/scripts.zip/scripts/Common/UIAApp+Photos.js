load('UIAApp.js');

UIAQuery.PHOTOS_MOVIE_SCRUBBER = UIAQuery.withPredicate('name contains[c] "Video playback contro"');
UIAQuery.PHOTOS_MOVIE_PLAY_BUTTON = UIAQuery.buttons('Play Video');
UIAQuery.PHOTOS_MOVIE_PAUSE_BUTTON = UIAQuery.buttons('Pause');
UIAQuery.PHOTOS_THUMBNAIL_SELECT_BUTTON = UIAQuery.buttons('Select');

/** Button getting first photo in an album view. */
UIAQuery.PHOTOS_FIRST_IN_ALBUM = UIAQuery.VISIBLE_COLLECTION_VIEWS.andThen(UIAQuery.tableCells().first());
/** Button getting last photo in an album view. */
UIAQuery.PHOTOS_LAST_IN_ALBUM = UIAQuery.VISIBLE_COLLECTION_VIEWS.andThen(UIAQuery.tableCells().last());
/** Element present when we're on the review view after taking a picture */
UIAQuery.REVIEW_VIEW_CONTAINER = UIAQuery.query('CAMReviewViewControllerContainerView');
/** Camera view for adding a new photo to a message*/
UIAQuery.CAMERA_VIEW = UIAQuery.query('CAMTopBar').orElse(UIAQuery.query('CAMViewfinderView'));
UIAQuery.PHOTOS_WHATS_NEW_CONTINUE_BUTTON = UIAQuery.buttons(
    target.localizedString(
        'WHATS_NEW_MEMORIES_CONTINUE',
        {tableName:'PhotosUI',bundlePath:'/System/Library/Frameworks/PhotosUI.framework'}
    ));
UIAQuery.PHOTOS_THUMBNAILS = UIAQuery.VISIBLE_COLLECTION_VIEWS.andThen(UIAQuery.tableCells());
UIAQuery.PHOTOS_PHOTO_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.beginsWith("Photo");
UIAQuery.PHOTOS_IRIS_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.beginsWith("Live Photo");
UIAQuery.PHOTOS_VIDEO_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.beginsWith("Video");
UIAQuery.PHOTOS_SLOMO_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.beginsWith("Slow motion");
UIAQuery.PHOTOS_TIMELAPSE_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.beginsWith("Time lapse");
UIAQuery.PHOTOS_ALL_VIDEO_TYPES_THUMBNAILS = UIAQuery.PHOTOS_THUMBNAILS.withPredicate('name contains[c] "Video"');

/**
 *  Returns the number of photo/video thumbnails in a "collection".
 *  Assumes we are on UI with a photo/video "collection" (e.g. Camera Roll or Photos).
 *
 *  @returns {int} the number of photo/video thumbnails in the current view
 **/
UIAApp.prototype.numberOfThumbnails = function numberOfThumbnails() {

    var thumbCount = this.count(UIAQuery.PHOTOS_THUMBNAILS);
    UIALogger.logDebug("Counted " + thumbCount + " thumbnails in the UI");

    var thumbCountLabel = UIAQuery.query('PUPhotosGlobalFooterView').andThen(UIAQuery.staticTexts());
    var thumbCountFromLabel = 0;

    var thumbCountInfo = this.inspect(thumbCountLabel);
    if (thumbCountInfo) {
        var labelText = thumbCountInfo.name;
        if (labelText.indexOf("days remaining before deletion") < 0) {
            var photoCount = parseInt(labelText.split(" ")[0]);
            var videoCount = 0;

            if (labelText.indexOf(",") >= 0) {
                videoCount = parseInt(labelText.split(" ")[2]);
            }
            thumbCountFromLabel = photoCount + videoCount;
        }
    }

    thumbCount = thumbCount >= thumbCountFromLabel ? thumbCount : thumbCountFromLabel;

    return thumbCount;
}


/**
 *  Selects thumbnails using multi-selection UI.
 *  Assumes we are on UI with a photo/video "collection" (e.g. Camera Roll or Photos) and
 *  the UI has a navigation bar with "Select" button
 *
 * @param {array} thumbsToSelect Array of indexes mapping to which thumbnails to select.
 *                               If not specified, will select 1 random image by default.
 *
 */
UIAApp.prototype.selectThumbnails = function selectThumbnails(thumbsToSelect) {
    this.tapIfExists(UIAQuery.PHOTOS_THUMBNAIL_SELECT_BUTTON);

    for (var i = 0; i < thumbsToSelect.length; i++) {
        this.tap(thumbsToSelect[i]);
    }
}

/**
 *  Selects all thumnails with the multi-selection UI. Assumes we are on a UI with a photo/video
 *  collection (i.e. Camera Roll or Photos) with a "Select" button.
 *
 */
UIAApp.prototype.selectAllThumbnails = function selectAllThumbnails() {

    var thumbnailCount = this.numberOfThumbnails();
    if (thumbnailCount == 0) {
        UIALogger.logDebug("No photos/videos to select.");
        return;
    }

    UIALogger.logDebug("Number of thumbnails is [" + thumbnailCount + "]. Selecting all of them...");

    var allThumbs = [];
    for (var i = 0; i < thumbnailCount; i++) {
        var currentThumb = UIAQuery.PHOTOS_THUMBNAILS.atIndex(i);
        allThumbs.push(currentThumb);
    }

    this.selectThumbnails(allThumbs);
}



/**
*       Function: deleteAndConfirm
*           Deletes the current photo being viewed. Assumes we are in the single photo detail view.
**/
UIAApp.prototype.deleteAndConfirm = function deleteAndConfirm(){
    if (!this.waitUntilPresent(UIAQuery.buttons('Delete').isEnabled(), 2)) {
        throw new UIAError("Delete button is not enabled");
    }
    this.tap(UIAQuery.buttons('Delete'));

    var deletePhotoButton = UIAQuery.buttons('Delete Photo');
    var deleteVideoButton = UIAQuery.buttons('Delete Video');
    var deleteItemButton = UIAQuery.buttons().withPredicate('ANY identifiers BEGINSWITH "Delete "');
    var deleteButton = deletePhotoButton.orElse(deleteVideoButton).orElse(deleteItemButton);
    this.delay(1);

    this.tap(deleteButton);
}


/**
*  Deletes all photos/videos. Assumes we are on a UI with a photo/video collection (i.e. Camera Roll or Photos)
*
*/
UIAApp.prototype.deleteAllPhotos = function deleteAllPhotos() {

    if (this.numberOfThumbnails() == 0) {
        UIALogger.logDebug("No photos/videos to delete.");
        return;
    }

    this.selectAllThumbnails();
    this.deleteAndConfirm();
}


/**
 *  Exits the Photos detail view. Assumes we are on a UI with a photo/video detail view
 *
 */
UIAApp.prototype.exitPhotoView = function exitPhotoView() {
    UIALogger.logDebug("Exiting the photo detail view.");
    this.tap(UIAQuery.BACK_NAV_BUTTON)
}


/**
 *  Exits the Photos detail view. Assumes we are on a UI with a photo/video detail view
 *
 */
UIAApp.prototype.editPhoto = function editPhoto() {
    UIALogger.logDebug("Editing the current photo.");

    this.tap(UIAQuery.buttons("Edit"));

    if ( !this.exists(UIAQuery.buttons("Done").isVisible()) || !this.exists(UIAQuery.buttons("Crop").isVisible()) ) {
        throw new UIAError("'Done' and 'Crop' buttons aren't visible. Are we on the Edit UI?");
    }

    UIALogger.logDebug("Tapping 'Edit' button led us to the correct UI. Tapping 'Cancel' to go back.");
    this.tap(UIAQuery.buttons("Cancel"));
}


/**
 *  Scrolls the current table of photos and verifies that it has indeed scrolled.
 *
 */
UIAApp.prototype.scrollPhotoCollection = function scrollPhotoCollection() {

    // TODO: get the initial position of the collection view once this property is exposed
    // See <rdar://problem/18446528> ER: Need to expose kAXScrollStatusAttribute in UIA2

    // TODO: if we're on page one, scroll down. Otherwise, scroll up

    UIALogger.logDebug("Scrolling up...");
    photos.drag("PUCollectionView", {fromOffset:{x:0.5, y:0.2}, toOffset:{x:0.5, y:0.8}});

    UIALogger.logDebug("Scrolling down...");
    photos.drag("PUCollectionView", {fromOffset:{x:0.5, y:0.8}, toOffset:{x:0.5, y:0.2}});

    // TODO: Verify that the table position changed

}

/**
 *  Plays a video for the given duration.
 *  Assumes we are on UI with a video detail view
 *
 * @param {int} playbackDuration - Duration of playback in seconds.
 *
 */
UIAApp.prototype.playVideo = function playVideo(playbackDuration) {

    // if (!this.waitUntilPresent(UIAQuery.PHOTOS_MOVIE_SCRUBBER)) {
    //     throw new UIAError("Movie scrubber is not visible. Are you on a video's detail view?");
    // }



    UIALogger.logDebug("Playing the video.");
    this.tap(UIAQuery.PHOTOS_MOVIE_PLAY_BUTTON);
    this.tap(UIAQuery.application(), {offset: {x: 0.5, y: 0.5}});
    target.delay(0.5);
    var initialScrubberValue = this.valueOf(UIAQuery.PHOTOS_MOVIE_SCRUBBER);

    target.delay(playbackDuration);

    if (!this.exists(UIAQuery.PHOTOS_MOVIE_SCRUBBER)) {
        this.tap(UIAQuery.beginsWith('Video'));
        if (!this.waitUntilPresent(UIAQuery.PHOTOS_MOVIE_SCRUBBER)) {
            throw new UIAError("Movie scrubber is not visible after tapping the video playing.");
        }
    }

    var finalScrubberValue = this.valueOf(UIAQuery.PHOTOS_MOVIE_SCRUBBER);

    if (initialScrubberValue == finalScrubberValue) {
        throw new UIAError("Scrubber position did not change.");
    }

    // play indefinitely if duration < 1
    if (playbackDuration < 1) {
        return;
    }

    // tap pause
    this.tapIfExists(UIAQuery.PHOTOS_MOVIE_PAUSE_BUTTON);
}
