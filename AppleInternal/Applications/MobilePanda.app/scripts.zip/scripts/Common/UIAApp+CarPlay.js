load('UIAApp.js');
load('SpringBoard.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Localization Strings                                                */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*                                                                             */
/*******************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAQuery.CarPlay = {
    // home button and icons
    HOME_BUTTON:        UIAQuery.windows('SBStarkStatusBarWindow').andThen(UIAQuery.query('UIStatusBarHomeItemView')).andThen(UIAQuery.buttons()),
    MAPS_ICON:          UIAQuery.windows('SBStarkIconWindow').andThen(UIAQuery.icons('Maps')),

    /* General queries */
    BACK_BUTTON:        UIAQuery.buttons('Back').leftmost().onScreen('CarPlay'),
    DONE_BUTTON:        UIAQuery.buttons('Done').onScreen('CarPlay'),
    CLEAR_BUTTON:       UIAQuery.buttons('Clear').onScreen('CarPlay'),
    END_BUTTON:         UIAQuery.buttons('End').onScreen('CarPlay'),
    KEYBOARD:           UIAQuery.query('UIKeyboard').onScreen('CarPlay'),

    /** Activity Indicator In Progress */
    ACTIVITY_IN_PROGRESS:   UIAQuery.activityIndicators(LocStrings.IN_PROGRESS).onScreen('CarPlay'),

    /* CarPlay focus */
    FOCUS:              UIAQuery.withPredicate('hasFocus == true'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

// Primary interface
PrimaryInterface = {
    TOUCH_SCREEN:       'touch_screen',
    KNOB:               'knob',
};

// Object for simulating CarPlay knob events
var knob = UIATarget.localTarget().knob();

// Max tries for knob rotation
var KNOB_ROTATION_MAX_TRIES = 35;

// Default timeout
var CARPLAY_DEFAULTTIMEOUT = 5

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. These take care of reaching */
/*      the appropriate views                                                      */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Locate knob focus on a given UI element in CarPlay
 *
 * @param {string} carplayQuery UIAQuery in carplay to move knob focus on.
 */
UIAApp.prototype.locateKnobFocusInCarPlay = function locateKnobFocusInCarPlay(carplayQuery) {
    // Rotate clockwise
    if (this.rotateKnobInCarPlay({clockwise: true}, carplayQuery)) {
        return;
    }
    // Rotate counterclockwise
    if (this.rotateKnobInCarPlay({clockwise: false}, carplayQuery)) {
        return;
    }
    // if we got here, we failed to locate knob focus on the specific element
    throw new UIAError('Failed to locate knob focus');
};

/**
 * Rotate knob clockwise or counterclockwise until a given UI element is focused or to the end in CarPlay
 *
 * @param {object} options An options dictionary
 * @param {boolean} [options.clockwise=true] - rotate knob clockwise or counterclockwise
 * @param {string} carplayQuery UIAQuery in carplay to move knob focus on.
 * @returns true if the given query is focused.
 */
UIAApp.prototype.rotateKnobInCarPlay = function rotateKnobInCarPlay(options, carplayQuery) {
    options = UIAUtilities.defaults(options, {
        clockwise:       true,
    });

    var rotateStep = options.clockwise ? 1 : -1;
    // Rotate knob until knob focus does not move or carplayQuery is focused
    var tries = 0;
    var previousKnobFocus = currentKnobFocus = null;
    do {
        if (currentKnobFocus = target.activeApp().inspect(UIAQuery.CarPlay.FOCUS))  {
            UIALogger.logMessage('Current knob focus is "%0"'.format(currentKnobFocus.name));
        }

        if (this.exists(carplayQuery.withPredicate('hasFocus == true'))) {
            return true;
        }

        if (previousKnobFocus && currentKnobFocus && previousKnobFocus.uiaxElement === currentKnobFocus.uiaxElement) {
            break;
        }
        previousKnobFocus = currentKnobFocus;
        knob.rotate(rotateStep);
        tries++;
    } while (tries < KNOB_ROTATION_MAX_TRIES);

    return false;
};

/**
 * Simulated tap in carplay primary interface
 *
 * @param {object} options An options dictionary
 * @param {null | string} [options.primaryInterface=null] - one of PrimaryInterface.*
 *          if null, PrimaryInterface.TOUCH_SCREEN is used.
 * @param {string} carplayQuery UIAQuery in carplay to do simulated tap on.
 */
UIAApp.prototype.simulatedTapInCarPlay = function simulatedTapInCarPlay(options, carplayQuery) {
    options = UIAUtilities.defaults(options, {
        primaryInterface:       PrimaryInterface.TOUCH_SCREEN,
    });

    switch (options.primaryInterface) {
        case PrimaryInterface.TOUCH_SCREEN:
            this.tap(carplayQuery);
            break;
        case PrimaryInterface.KNOB:
            UIAUtilities.assert(
                this.waitUntilPresent(carplayQuery, CARPLAY_DEFAULTTIMEOUT),
                'Failed to get query result'
            );
            this.locateKnobFocusInCarPlay(carplayQuery);
            knob.pressSelect();
            break;
        default:
            throw new UIAError('Not supported carplay primary interface "%0"'.format(options.primaryInterface));
    }
};

/**
 * Simulated click menu in carplay primary interface
 *
 * @param {object} options An options dictionary
 * @param {null | string} [options.primaryInterface=null] - one of PrimaryInterface.*
 *          if null, PrimaryInterface.TOUCH_SCREEN is used.
 */
UIAApp.prototype.simulatedClickMenuInCarPlay = function simulatedClickMenuInCarPlay(options) {
    options = UIAUtilities.defaults(options, {
        primaryInterface:       PrimaryInterface.TOUCH_SCREEN,
    });

    switch (options.primaryInterface) {
        case PrimaryInterface.TOUCH_SCREEN:
            // <rdar://problem/28695574> Did not find the element of home button in carplay AX when in map views
            // <rdar://problem/28695684> Remove workaround of <rdar://problem/28695574>
            UIATarget.localTarget().clickMenu();
            // End of workaround for <rdar://problem/28695574>
            break;
        case PrimaryInterface.KNOB:
            var appStateChangedWaiter = UIAWaiter.withPredicate(
                'ApplicationStateChanged',
                'state == "Suspended"'
            );
            knob.pressHome();
            // wait for app suspended or timeout
            appStateChangedWaiter.wait(CARPLAY_DEFAULTTIMEOUT);
            break;
        default:
            throw new UIAError('Not supported carplay primary interface "%0"'.format(options.primaryInterface));
    }
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Helper functions                                                       */
/*                                                                             */
/*******************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Handlers                                                            */
/*                                                                             */
/*      Alert handlers for the app. e.g. safari.accessContactsAlertHandler     */
/*                                                                             */
/*******************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Assertions                                                          */
/*                                                                             */
/*      Assertion functions for the app. e.g. safari.assertActiveURL           */
/*                                                                             */
/*******************************************************************************/
