load('UIAApp.js');
load('UIAUtility.js')
load('SpringBoard.js');
load('UIAApp+PiP.js');
/**

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common InCall queries */
/** @namespace **/
UIAQuery.InCall = {

	/** Phone Control View that contains in call options (add call, FaceTime, speaker, etc...)*/
	PHONE_AUDIO_CONTROL_VIEW: UIAQuery.query('PHAudioCallControlsView').isVisible(),

	/** Phone Control View that contains deterministic options (end call, answer call, decline call, etc...)*/
	SUPER_BOTTOM_BAR: UIAQuery.query('PHBottomBar').isVisible(),

	/** View that contains participant in call*/
	PARTICIPANTS_VIEW: UIAQuery.query('PHCallParticipantsView').isVisible(),

	/** View that contains video overlay view in call*/
	VIDEO_CALL_VIEW: UIAQuery.query('PHVideoCallInterfaceOverlayView'),

	/** Mute Button in Phone Control View*/
	MUTED_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('mute')),

	/** Keypad Button in Phone Control View*/
	KEYPAD_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('keypad')),

	/** Speaker Button in Phone Control View*/
	SPEAKER_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('speaker')),

	/** Add Button in Phone Control View*/
	ADD_CALL_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('add call')),

	/** FaceTime Button in Phone Control View*/
	FACETIME_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('FaceTime')),

	/** Contacts Button in Phone Control View*/
	CONTACTS_BUTTON: UIAQuery.query('PHAudioCallControlsView').andThen(UIAQuery.buttons('contacts')),

	/** Accept Call Button in Deterministic View*/
	ACCEPT_BUTTON: UIAQuery.query('PHBottomBar').andThen(UIAQuery.buttons('Accept')),

	/** Decline Call Button in Deterministic View*/
	DECLINE_BUTTON: UIAQuery.query('PHBottomBar').andThen(UIAQuery.buttons('Decline')),
	
	/** Answer Call Button in Deterministic View*/
	ANSWER_BUTTON: UIAQuery.query('PHBottomBar').andThen(UIAQuery.buttons('Answer')),

	/** End Call Button in Deterministic View*/
	END_CALL_BUTTON: UIAQuery.query('PHBottomBar').andThen(UIAQuery.buttons('End call')),

	/** Caller Text in Participant View*/
	CALL_SUBTEXT: UIAQuery.contains('PHSingleCallParticipantLabelView').andThen(UIAQuery.staticTexts()),
	
	/** Caller Text in Participants View*/
	CALLERS_SUBTEXT: UIAQuery.contains('PHMultipleCallParticipantLabelView').withPredicate("ALL children.name != 'hold'").andThen(UIAQuery.staticTexts()),

	/** Status Bar For Application To Detect Call*/
	STATUS_BAR: UIAQuery.statusBars('UIStatusBar').isVisible(),

};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the App   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to In Call Services */
/** @namespace **/
UIStateDescription.InCall = {
    
    /** (Active) FaceTime Video */
    FACETIME_VIDEO:             'FaceTime Video',

    /** (Active) FaceTime Audio */
    FACETIME_AUDIO: 			'FaceTime Audio',

    /** (Active) Phone */
    PHONE:               		'Phone',

    /** (Background) FaceTime Video */
    BACKGROUND_FACETIME_VIDEO: 	'Background FaceTime Video',

    /** (Background) FaceTime Audio */
    BACKGROUND_FACETIME_AUDIO: 	'Background FaceTime Audio',

    /** (Background) Phone */
    BACKGROUND_PHONE: 			'Background Phone',

    /** Inactive Call State */
    INACTIVE: 					'Inactive',

};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other App specific constants                                       */
/*                                                                             */
/*******************************************************************************/

Label = {	
	FACETIME_AUDIO: 					'FaceTime Audio',
	FACETIME_VIDEO: 					'FaceTime',
	BACKGROUND_PHONE_PROMPT: 			'Touch to return to call',
	BACKGROUND_FACETIME_AUDIO_PROMPT: 	'Touch to resume FaceTime Audio',
	BACKGROUND_FACETIME_VIDEO_PROMPT: 	'Touch to resume FaceTime', 
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the App is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.
* See InCall UIStateDescription constants for possible values.
* Any criteria for defining a state should be very exact so
* there is no confusion on state. We should always throw
* if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in InCall UIStateDescription.
*
* @throws If cannot determine state.
*/
springboard.currentInCallState = function currentInCallState() {

  	if (springboard.exists(UIAQuery.InCall.CALL_SUBTEXT.andThen(UIAQuery.contains(Label.FACETIME_AUDIO)))) {
  		return UIStateDescription.InCall.FACETIME_AUDIO;
  	} else if (springboard.exists(UIAQuery.InCall.VIDEO_CALL_VIEW.orElse(UIAQuery.InCall.CALL_SUBTEXT.andThen(UIAQuery.contains(Label.FACETIME_VIDEO))))) {
		return UIStateDescription.InCall.FACETIME_VIDEO;
    } else if (springboard.exists(UIAQuery.InCall.CALL_SUBTEXT)) {
		return UIStateDescription.InCall.PHONE;
    } else if (springboard.exists(UIAQuery.InCall.STATUS_BAR.andThen(UIAQuery.contains(Label.BACKGROUND_FACETIME_AUDIO_PROMPT)))) {
		return UIStateDescription.InCall.BACKGROUND_FACETIME_AUDIO;
    } else if (springboard.exists(UIAQuery.InCall.STATUS_BAR.andThen(UIAQuery.contains(Label.BACKGROUND_FACETIME_VIDEO_PROMPT)))) {
		return UIStateDescription.InCall.BACKGROUND_FACETIME_VIDEO;
    } else if (springboard.exists(UIAQuery.InCall.STATUS_BAR.andThen(UIAQuery.contains(Label.BACKGROUND_PHONE_PROMPT)))) {
		return UIStateDescription.InCall.BACKGROUND_PHONE;
    } else if (!springboard.exists(UIAQuery.InCall.CALL_SUBTEXT))  {
		return UIStateDescription.InCall.INACTIVE
    } else {
    	// if we got here, we don't have no clue where we are...
    	throw new UIAError('Could not determine state.');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets to in call control view, performs actions if in background state:
 * (INACTIVE)
 * 
 * Expected starting state: Works for any InCall UI State

 * @throws If not in an In Call Active State.
 **/
springboard.getToInCallView = function getToInCallView(){
	var currentState = this.currentInCallState();

	if (currentState === UIStateDescription.InCall.INACTIVE) {
		throw new UIAError('Could not get to In Call View of an non active call state');
	}

	if (this.stateIsBackgroundState(currentState)) {
		this.tap(UIAQuery.InCall.STATUS_BAR);
	}
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Return If State is a Background State
 *
 * @param {string} state - State that will be interigated
 *
 * @returns {boolean} If state is background state.
 */
springboard.stateIsBackgroundState = function stateIsBackgroundState(state) {
	return state.indexOf('Background') > -1;
}

/**
 * Return if State is a Background In Call State
 *
 * @returns {boolean} If state is background state.
 *
 * @throws If current state cannot be determined.
 */
springboard.isInBackgroundCall = function isInBackgroundCall() {
	var currentState = this.currentInCallState();
	return ((currentState === UIStateDescription.InCall.BACKGROUND_FACETIME_AUDIO) || 
			(currentState === UIStateDescription.InCall.BACKGROUND_FACETIME_VIDEO) || 
			(currentState === UIStateDescription.InCall.BACKGROUND_PHONE));
			//in active call state
}

/**
 * Return if State is in an In Call State
 *
 * @returns {boolean} If state is in call.
 *
 * @throws If current state cannot be determined.
 */
springboard.isInCall = function isInCall() {
	//check if is in INACTIVE STATE for call
	try {
		var currentState = this.currentInCallState();
		//check the phone control exists or if in a background mode
		if (currentState !==  UIStateDescription.InCall.INACTIVE) {
			return ((springboard.exists(UIAQuery.InCall.PHONE_AUDIO_CONTROL_VIEW)) || (springboard.exists((UIAQuery.InCall.VIDEO_CALL_VIEW).andThen(UIAQuery.InCall.END_CALL_BUTTON))) || (currentState.indexOf('Background') > -1));
		}
	} catch (e) {
		UIALogger.logError(e);
		throw new UIAError('Error in trying to find call state for In Call');
		return false;
	}
}

/**
 * Return If Device is Receiving a Call
 *
 * @returns {boolean} If device is receiving call.
 *
 * @throws If current state cannot be determined.
 */
springboard.isReceivingCall = function isReceivingCall() {
	
	//check state if in call
	if (this.isInCall()) {
		UIALogger.logMessage('Device is in a "In Call" cannot be receiving a call');
		return false; 
	}

	//check if accept or decline buttons are showing
	return (
		(springboard.exists(UIAQuery.InCall.ACCEPT_BUTTON) && springboard.exists(UIAQuery.InCall.DECLINE_BUTTON)) ||
		(springboard.exists(UIAQuery.InCall.ANSWER_BUTTON))
	);
}

/** 
 * Returns a boolean if the current string is a phone number
 * 
 * @param {string} contact - The contact string that will be verified against.
 *
 * @returns {boolean} If the string is a phone number.
 */
 springboard.isPhoneNumber = function isPhoneNumber(contact) {

	var filteredContact  = contact.replace('(','').replace(')','').replace('+','').replace(/ /g,'').replace('-','');

	// We cannot just look for digits due to invisible unicode characters in Phone and FaceTime Audio display caller IDs. See rdar://problem/21268389
	return (!/[A-Z]/gi.test(filteredContact));
 }

/**
 * Returns a phone number after removing all occurrences of (,), -, +, and ' '
 *
 * @param {string} phoneNumber - The phone number to clean
 *
 * @returns {string} the cleaned phone number
 *
 * @throws 	If Phone Number is not a valid type, must be string.
 * 			If Phone Number cannot be parsed for any digits.
 */
springboard.cleanedPhoneNumber = function cleanedPhoneNumber(phoneNumber) {

    if (phoneNumber === 'undefined' || typeof(phoneNumber) !== 'string') {
        UIALogger.logMessage('Phone Number:' + typeof(phoneNumber) + ':' + phoneNumber);
        throw new UIAError('Phone number is not valid value');
    }

    UIALogger.logMessage('Parsing Number:' + phoneNumber)

    var numbers = phoneNumber.match(/[\d*#]+/g);
    if (numbers === null) {
    	throw new UIAError('The Phrase %0 cannot be cleaned into a phone number'.format(phoneNumber));
    }
    return numbers.join('');
}

/**
 * Returns boolean if the contact is one of the active calls
 *
 * @param {object} contact - Dictionary containing acceptable contact information to validate the call
 * @param {string} [contact.phoneNumber] - Phone number
 * @param {string} [contact.email] - Email address (Apple ID)
 * @param {string} [contact.name]  - Name (usually resolved by AddressBook Framework)
 *
 * @returns {boolean} if is the active call.
 */
springboard.isActiveCall = function isActiveCall(contact) {
	
    var callerIDs = springboard.activeCall().split('&');
 	
    for (var i = 0; i < callerIDs.length; i++) {
    	var callerID = callerIDs[i];
    	UIALogger.logMessage("Interrogating caller id: %0".format(callerID))

    	// Special case conference calls
    	if (contact.name === 'Conference') {
    		UIALogger.logMessage('We are on a conference call.');
        	return true;    	
    	} else if (springboard.isPhoneNumber(callerID)) {
    		UIALogger.logMessage("Checking phone number: %0".format(callerID))
    		if (contact.phoneNumber !== undefined) {
	    		var cleanedCallerID = springboard.cleanedPhoneNumber(callerID);
	    		var cleanedContact = springboard.cleanedPhoneNumber(contact.phoneNumber);
	    		if (!cleanedContact.contains(cleanedCallerID) && !cleanedCallerID.contains(cleanedContact)) {
	        		UIALogger.logMessage('The number: %0 does not contain the active call %1'.format(cleanedContact,cleanedCallerID));
	    		} else {
	    			UIALogger.logMessage('The number: %0 contains the active call %1'.format(cleanedContact,cleanedCallerID));
	    			return true;
	    		}
    		}
    	} else {
    		if ((callerID.match(contact.email) == contact.email) || (callerID.match(contact.name) == contact.name)) {
    			return true;
    		}
    	}
    }

    return false;
}


/**
 * Returns active call callerID 
 *
 * @returns {string} active call number received or 'Conference' if in conference call
 *
 * @throws If there is no active call.
 */
springboard.activeCall = function activeCall() {
	//TODO: <rdar://problem/21078498> uncomment after radar fixed for active counts on facetime are > 1
	if (/*target.activeCallCount() < 1 || */(!this.isInCall() && !this.isReceivingCall())) {
		throw new UIAError('There is no active call in foreground to interrogate');
	}
	return springboard.inspect(UIAQuery.InCall.CALL_SUBTEXT.orElse(UIAQuery.InCall.CALLERS_SUBTEXT)).name;
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
* Answer the current call 
*
* Expected starting states: Is in receiving call state
*
* @throws If is not in receiving call state.
*/
springboard.answerCall = function answerCall() {
	if (this.isReceivingCall()) {
		springboard.tap(UIAQuery.InCall.ACCEPT_BUTTON.orElse(UIAQuery.InCall.ANSWER_BUTTON));
	} else {
		throw new UIAError('Device is not receiving a call to answer.')
	}
}

/**
* Decline the current call 
*
* Expected starting states: Is in receiving call state
*
* @throws If is not in receiving call state.
*/
springboard.declineCall = function declineCall() {
	if (this.isReceivingCall()) {
		springboard.tap(UIAQuery.InCall.DECLINE_BUTTON);
	} else {
		throw new UIAError('Device is not receiving a call to decline.')
	}
}

/**
* End the current call 
*
* Expected starting states: Is in an in call state
*
* @throws 	If is not in an in call state.
*			If UI error occurs and cannot end call.
*			If Timeout waiting for the end call to be visible.
*			If Timeout wiating for the end call to disappear after tap.
*/
springboard.endCall = function endCall() {
	if (this.isInBackgroundCall()) {
		//in background tap background call and then tap end call
		springboard.tap(UIAQuery.InCall.STATUS_BAR);

		if (springboard.waitUntilPresent(UIAQuery.InCall.END_CALL_BUTTON)) {
			// FaceTime Video buttons are often invisible. Make them appear if needed
			if (!springboard.exists(UIAQuery.InCall.END_CALL_BUTTON.isVisible())) {

				springboard.tap(UIAQuery.application());
				
				var success = springboard.waitUntilPresent(UIAQuery.InCall.END_CALL_BUTTON.isVisible(), 20);
			    if (!success) {
			        throw new UIAError('Wait until End call button becomes visible timed out');
			    }
			    //TODO SEB This delay is a workaround for bug rdar://problem/21107198:
	        	springboard.delay(1);
		    }

			springboard.tap(UIAQuery.InCall.END_CALL_BUTTON);
			if (!springboard.waitUntilAbsent(UIAQuery.InCall.END_CALL_BUTTON)) {
				throw new UIAError('Device did not end the call');
			}
		}
	} else if (this.isInCall()) {
		// Exit FaceTime Video PiP if needed
		if (springboard.exists(UIAQuery.SpringBoard.FULLSCREEN_PIP)) {
			springboard.fullScreenPip();
		}

		// FaceTime Video buttons are often invisible. Make them appear if needed
		if (!springboard.exists(UIAQuery.InCall.END_CALL_BUTTON.isVisible())) {
			springboard.tap(UIAQuery.application());
			var success = springboard.waitUntilPresent(UIAQuery.InCall.END_CALL_BUTTON.isVisible(), 20);
		    if (!success) {
		        throw new UIAError('Wait until End call button becomes visible timed out');
		    }
		    //TODO SEB This delay is a workaround for bug rdar://problem/21107198:
        	springboard.delay(1);
	    }

		//in call and then tap end call
		springboard.tap(UIAQuery.InCall.END_CALL_BUTTON);
		if (!springboard.waitUntilAbsent(UIAQuery.InCall.END_CALL_BUTTON)) {
			throw new UIAError('Device did not end the call');
		}

	} else if (this.currentInCallState() === UIStateDescription.InCall.INACTIVE) {
		UIALogger.logMessage('Device has inactive call state');
	} else {
		throw new UIAError('Device does not have a call to end. In unknown state');
	}
}

/**
 * Ends all existing calls
 *
 * Expected starting states: None
 *
 * @throws 	If UI error occurs and cannot end call.
 */
springboard.endAllCalls = function endAllCalls() {
    var callCount = target.activeCallCount();
    UIALogger.logMessage('Starting CallCount: %0'.format(callCount));
    while (callCount != 0) {
        this.endCall();
        callCount = target.activeCallCount();
        UIALogger.logMessage('Current CallCount: %0'.format(callCount));
    }
}

/**
 * Confirm call is being made wait for 'timeout' seconds
 *
 * @param {object} contact - Dictionary containing acceptable contact information to validate the call
 * @param {string} [contact.phoneNumber] - Phone number (e.g. "408-867-5309")
 * @param {string} [contact.email] - Email address, i.e. Apple ID (e.g. "johnnyappleseed@icloud.com")
 * @param {string} [contact.name]  - Name, usually resolved by AddressBook Framework (e.g. "Johnny Appleseed")
 * @param {int} 	timeout - Optional timeout. Seconds to wait for outgoing call. Defaults to 10.
 *
 * @returns {boolean} True if call becomes active before timeout, false if timed out waiting for active call.
**/
springboard.waitForCallActive = function waitForCallActive(contact,timeout) {
	
	if (typeof(timeout) !== "number") {
		UIALogger.logMessage(
			'Malformed timeout (must be type "string") \
			or no value provided in options dictionary to wait for: %0, defaulting to 10'.format(timeout)
		);
		timeout = 10;
	}

	UIALogger.logMessage('Waiting for call to become active for contact %0'.format(JSON.stringify(contact, null, 2)));
	if (this.waitUntilPresent(UIAQuery.InCall.SUPER_BOTTOM_BAR,timeout)) {
		if (!contact || !this.isActiveCall(contact)) {
			UIALogger.logError('The caller label: %0 does not match the active call'.format(JSON.stringify(contact, null, 2)));
			return false;
		}
		return true;
	}
	//Waited and did not enter if (timed out)
	UIALogger.logError('Waited to validate calling view and timed out');
	return false;
}

/**
 * Wait to Receive Call
 *
 * @param {int} timeout 	- Seconds to wait for incoming call
 * @param {object} body 	- The function that will be executed when the call has been received
 * @param {string} 	[state] - Optional State. Argument for body that will represent incoming call state
 * For in call state specifics refer to SpringBoard+InCallServices.js > UIStateDescription.InCall
 *
 * @returns {boolean} True if receiving a call before timeout, false if timed out waiting for call.
**/
springboard.waitToReceiveCall = function waitToReceiveCall(timeout, body) {

	//Wait for Accept and Decline Bar to become present and execute body (if exists)
	if (springboard.waitUntilPresent(UIAQuery.InCall.ACCEPT_BUTTON, timeout)) {
		var currentState = springboard.currentInCallState();
		UIALogger.logMessage('Waiting to receive call, in state: %0'.format(currentState));

		if (currentState === UIStateDescription.InCall.INACTIVE) {
			throw new UIAError('Unknown state entered for received call cannot be Inactive');
		}
		if (body) {
			body(currentState);
		}
		return true;
	}
	return false
}

/**
 * Wait for a call from a specific Contact.
 *
 * @param {object} contact - Dictionary containing any acceptable contact information to validate the call
 * @param {string} [contact.phoneNumber] - Phone number (e.g. "408-867-5309")
 * @param {string} [contact.email] - Email address, i.e. Apple ID (e.g. "johnnyappleseed@icloud.com")
 * @param {string} [contact.name]  - Name, usually resolved by AddressBook Framework (e.g. "Johnny Appleseed")
 * @param {boolean} answer 		- True if we should answer the incoming phone call after verification.
 * @param {string} 	callState 	- Optional callState. The Call state that should match the incoming call.
 * @param {int} 	timeout 	- Optional timeout. Seconds to wait for incoming call. Defaults to 10.
 * For in call state specifics refer to SpringBoard+InCallServices.js > UIStateDescription.InCall
 *
 * @returns {boolean} True if receiving a call before timeout, false if timed out waiting for call.
 *
 * @throws  If call state is not satisfied.
 *			If contact does not match the current callerID.
 */
springboard.waitForCallFromContact = function waitForCallFromContact(contact, answer, callState, timeout) {

	if (typeof(timeout) !== "number") {
		UIALogger.logMessage(
			'Malformed timeout(must be type "string") \
			or no value provided in options dictionary to wait for: %0, defaulting to 10'.format(timeout)
		);
		timeout = 10;
	}

	return (
	    springboard.waitToReceiveCall(timeout,
	        function(state) {
	        	//verify if call state is included in 
	        	if (typeof(callState) === 'string' && callState !== '') {
	        		UIALogger.logMessage(
						'Malformed callState (must be type "string") or no value provided in options \
						dictionary to wait for: %0, not checking for particular state'.format(timeout)
					);
	        		if (state !== callState) {
	                	throw new UIAError(
	                		'Call state (%0) does not satisfy expected \
	                		call state %1.'.format(state,callState));
	            	}
	        	}

	            if(!springboard.isActiveCall(contact)){
	            	springboard.declineCall();
	            	throw new UIAError('Call contact %0 could not be confirmed as current call'.format(JSON.stringify(contact)));
	            }
	            
	            //If call should be answered answer the call.i If not, decline the call.
	            answer ? springboard.answerCall(): springboard.declineCall();
	        }

	    )
	);
} 
