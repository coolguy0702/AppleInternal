load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");


/**
 @namespace
 @augments UIASystemApp
 */
var springboard = target.systemApp();
var spotlight = target.appWithBundleID('com.apple.Spotlight')

/*******************************************************************************/
/*                                                                             */
/*   Mark: SpringBoard Localized String Constants                              */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*      To abstract the localized string constants for SpringBoard             */
/*                                                                             */
/*******************************************************************************/

LocStrings.SpringBoard = {

    /** Not Now */
    NOT_NOW: springboard.localizedString(
        'TOUCHID_APPROVAL_OPTIN_DIALOG_NOT_NOW_BUTTON_TITLE',
        {bundlePath:'/System/Library/PrivateFrameworks/AskPermission.framework'}
    ),

    /** Changed Not Now */
    NEW_NOT_NOW: springboard.localizedString(
        'AUTHENTICATION_OPTIN_DIALOG_BUTTON_DECLINE',
        {bundlePath:'/System/Library/PrivateFrameworks/AskPermission.framework'}
        ),

    /** Notifications */
    NOTIFICATIONS: springboard.localizedString(
        'NOTIFICATION_CENTER_MODE_ALL',
        {tableName:'SpringBoard'}
    ),

    /** Today */
    TODAY: springboard.localizedString(
        'TODAY',
        {tableName:'SpringBoard'}
    ),

}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIAQuery.SpringBoard = {
    /** Side app divider control for setting and sizing the side app */
    SIDE_APP_DIVIDER:                   UIAQuery.query('SideAppDivider').isVisible(),

    /** Control to access the side app switcher */
    SIDE_APP_SWITCHER_CONTROL:          UIAQuery.query('SBChevronView').isVisible(),

    /** Side app divider control for dismissing the side app */
    DISMISS_SIDE_APP:                   UIAQuery.beginsWith('Dismiss').isVisible(),

    /** The PiP window play button */
    PLAY_PIP:                           UIAQuery.buttons('Play'),

    /** The PiP window pause button */
    PAUSE_PIP:                          UIAQuery.buttons('Pause'),

    /** The PiP window close button */
    CLOSE_PIP:                          UIAQuery.buttons('Close'),

    /** The PiP window full screen button to return to the originating app **/
    FULLSCREEN_PIP:                     UIAQuery.buttons('Full Screen'),

    /** App Folder **/
    FOLDER:                             UIAQuery.query('SBFloatyFolderView'),

    /** Edit button in Today view **/
    TODAY_VIEW_EDIT_BUTTON:             UIAQuery.query('WGWidgetListFooterView').andThen('Edit'),

    /** Present whenever Control Center is active */
    CONTROL_CENTER:                     UIAQuery.query('ControlCenterView'),

    /** The scrollable platter with all Control Center pages */
    CONTROL_CENTER_PLATTER:             UIAQuery.query("CCUIControlCenterPagePlatterView"),

    /** Bulletin Window is the top-of-home-screen page that includes Notification Center and Today View*/
    BULLETIN_WINDOW:                    UIAQuery.query('SBBulletinWindow'),

    /** Notfiication Center */
    NOTIFICATION_CENTER:                UIAQuery.query('SBSearchEtceteraNotificationsLayoutContentView'),

    /** Today View */
    TODAY_VIEW:                         UIAQuery.query('SBSearchEtceteraTodayLayoutContentView').orElse('WGMajorListViewControllerView'),

    /** Spotlight */
    SPOTLIGHT:                          UIAQuery.query('SPUISearchView').andThen(UIAQuery.buttons('Cancel')),

    /** Parsec Card */
    PARSEC_CARD:                        UIAQuery.withPredicate("any identifiers == 'SPUINavigationBar'").andThen(UIAQuery.buttons('Back')),

    /** Brightness slider control within Control Center */
    BRIGHTNESS_SLIDER:                  UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('Brightness')),

    /** Timer app button within Control Center */
    TIMER_BUTTON_CC:                    UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.mobiletimer')).andThen(UIAQuery.withPredicate('label == "Timer"')),

    /** Alarm app button within Control Center */
    ALARM_BUTTON_CC:                    UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.mobiletimer')).andThen(UIAQuery.withPredicate('label == "Alarm"')),

    /** Stopwatch app button within Control Center */
    STOPWATCH_BUTTON_CC:                UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.mobiletimer')).andThen(UIAQuery.withPredicate('label == "Stopwatch"')),

    /** Camera app button within Control Center */
    CAMERA_BUTTON_CC:                   UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.camera')),

    /** Calculator app button within Control Center */
    CALCULATOR_BUTTON_CC:               UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.calculator')),

    /** Magnifier app button within Control Center */
    MAGNIFIER_BUTTON_CC:                UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.Magnifier')),

    /** Tap-to-Radar app button within Control Center */
    TAPTORADAR_BUTTON_CC:               UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.TapToRadar')),

    /** Notes app button within Control Center */
    NOTES_BUTTON_CC:                    UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.mobilenotes')),

    /** Voice Memos app button within Control Center */
    VOICEMEMOS_BUTTON_CC:               UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.VoiceMemos')),

    /** Wallet app button within Control Center */
    WALLET_BUTTON_CC:                   UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('com.apple.Passbook')),

    /** Guided Access app button within Control Center */
    GUIDED_ACCESS_BUTTON_CC:            UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.query('guided-access')),

    /** Connectivity box within Control Center */
    CONN_BOX_CC:                        UIAQuery.query('CCUIContentModuleContentContainerView').andThen(UIAQuery.switches('wifi-button').parent().parent().parent().parent()),

    /** AirDrop button within opened Connectivity box */
    AIRDROP_BUTTON:                     UIAQuery.scrollViews().andThen(UIAQuery.switches().contains('AirDrop')),

    /** Spotlight table view */
    SPOTLIGHT_TABLE_VIEW:               UIAQuery.withPredicate('behavior == "TableView" AND name == "SearchUITableView"'),
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

var UIStates = {
    /** Root icon view */
    ROOT_ICON_VIEW: {
        Description: 'Root Icon View',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.query('SBRootIconListView').isVisible());
        },
    },

    /** Control Center */
    CONTROL_CENTER: {
        Description: 'Control Center',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.SpringBoard.CONTROL_CENTER);
        },
    },

    /** Notification Center */
    NOTIFICATION_CENTER: {
        Description: 'Notification Center',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.SpringBoard.NOTIFICATION_CENTER);
        },
    },

    /** Today View */
    TODAY_VIEW: {
        Description: 'Today View',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.SpringBoard.TODAY_VIEW.isVisible());
        },
    },

    /** Spotlight */
    SPOTLIGHT: {
        Description: 'Spotlight',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.SpringBoard.SPOTLIGHT);
        },
    },

    /** Bulletin Window */
    BULLETIN_WINDOW: {
        Description: 'Bulletin Window',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.SpringBoard.BULLETIN_WINDOW);
        },
    },
}

// FIXME: This is a hack, but it's apparently what we do in UIA1
// Default user accounts for both iTunes/AppStore and Apple ID (iCloud).
// These can be the same but they don't necessarily have to be. The file
// version is generated by CAE/PersistAccountInfo.py
springboard.iTunesUsername = 'cluelessintern@icloud.com';
springboard.iTunesPassword = 'RememberRememberThe6thOfNovember';
springboard.appleID = springboard.iTunesUsername = 'cluelessintern@icloud.com';
springboard.appleIDPassword = springboard.iTunesPassword = 'RememberRememberThe6thOfNovember';
springboard.persistedAccountPath = '/usr/local/etc/scripterUIA/persisted_account_info.js';

// UIAFile isn't currently bridged on Customer installs. This check can be removed after <rdar://problem/27374264> is in a build.
// <rdar://problem/27374325> Remove UIAFile check from SpringBoard.js when unblocked
if (typeof UIAFile !== 'undefined' && UIAFile.fileExists(springboard.persistedAccountPath)) {
    load(springboard.persistedAccountPath);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State                                                    */
/*                                                                             */
/*      A function to determine which UI state the app is currently in         */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and SpringBoard for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
springboard.currentUIState = function currentUIState() {
    // Grab a snapshot to feed to the isCurrentState functions of the State objects
    var snapshot = this.inspect(UIAQuery.application());

    // List of all the state objects
    var states = Object.keys(UIStates).map(function (key) {
        return UIStates[key];
    });

    /*
    * For each state, check if we're in that state
    * using the isCurrentState function and the snapshot
    * If we are then log and return the State's description
    */
    for (i = 0; i < states.length; i++) {
        var state = states[i];
        if (state.isCurrentState(snapshot)) {
            var stateName = state.Description;
            UIALogger.logMessage('Currently in state "%0"'.format(stateName));
            return stateName;
        }
    }

    // if we got here, we don't have any idea where we are...
    throw new UIAError('Could not determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [state]                                                      */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Navigates to the top-of-home-screen Bulletin Window that includes Notification Center and Today View
 *
 * @returns {boolean} true if the targetPage is active
 */
springboard.getToBulletinWindow = function getToBulletinWindow() {
    UIALogger.logMessage('Navigating to notification center');

    if (!this.exists(UIAQuery.SpringBoard.NOTIFICATION_CENTER)) {
        if (target.isMainScreenOff()) {
            target.clickLock();
        }

        var maxAttempts = 3;
        var success = false;
        for (var i = 0; i < maxAttempts; i++) {
            UIALogger.logMessage('Attempt %0 of %1 to get to the Bulletin Window'.format(i+1, maxAttempts));
            this.swipeFromTopEdge();
            if (UIStates.BULLETIN_WINDOW.isCurrentState(this.inspect(UIAQuery.application()))) {
                UIALogger.logMessage('Successfully navigated to the top-of-home-screen Bulletin Window');
                success = true;
                break;
            } else {
                UIALogger.logError('Failed to get to the Bulletin Window');
            }
        }
        if (!success) {
            throw new UIAError('Failed to get to the Bulletin Window after %0 attempts'.format(maxAttempts));
        }
    }

    return success;
}

/**
 * Navigates to Notification Center
 *
 * @returns {boolean} true if Notification Center is active
 */
springboard.getToNotifications = function getToNotifications() {
    this.getToBulletinWindow();
    if (UIStates.TODAY_VIEW.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Got to Today View. Attempting to navigate to Notification Center');
        this.swipeFromRightEdge();
    }
    if (UIStates.NOTIFICATION_CENTER.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Successfully navigated to Notification Center');
        return true;
    } else {
        throw new UIAError ('Faled to navigate to Notification Center');
    }
}

/**
 * Navigates to Today View
 *
 * @returns {boolean} true if Today View is active
 */
springboard.getToWidgets = function getToWidgets() {
    if (!UIStates.TODAY_VIEW.isCurrentState(this.inspect(UIAQuery.application()))) {
        this.launch();
        var maxAttempts = 3;
        var success = false;
        for (var i = 0; i < maxAttempts; i++) {
            UIALogger.logMessage('Attempt %0 of %1 to get to the widgets view'.format(i+1, maxAttempts));
            target.clickMenu();
            this.swipeFromLeftEdge();
            if (spotlight.waitUntilPresent(UIAQuery.searchBars("SpotlightSearchField").isVisible())) {
                UIALogger.logMessage('Successfully navigated to widgets view');
                success = true;
                break;
            } else {
                UIALogger.logError('Failed to get to the widgets view');
            }
        }
        if (!success) {
            throw new UIAError('Failed to get to the widgets view after %0 attempts'.format(maxAttempts));
        }
    }
}

/**
 * Brings up control center if necessary
 *
 * @returns {boolean} true if control center is up
 */
springboard.getToControlCenter = function getToControlCenter() {
    // Due to differences in gestures between devices, start with Home screen
    target.clickMenu();
    this.launch();
    this.swipeFromBottomEdge();

    if (!this.waitUntilPresent(UIAQuery.SpringBoard.CONTROL_CENTER)) {
        target.clickMenu();
        this.swipeFromTopRightEdgeToMiddle();
        if (!this.waitUntilPresent(UIAQuery.query('CCUIContentModuleContainerView'))) {
            throw new UIAError('Failed to get to Control Center after swiping from the bottom and upper right edge of SpringBoard');
        } else {
            UIALogger.logMessage('Successfully pulled up Control Center from the upper right of the screen');
            return true;
        }
    } else {
        UIALogger.logMessage('Successfully pulled up Control Center');
        return true;
    }
}

/**
 * Brings up pull-down spotlight's zero keyword app predictions
 *
 * @returns {boolean} true if pull-down spotlight is up and
 *   app predictions are displayed
 *   (Left-of-home zkw is handled by getToZeroKeywordSearch.)
 */
springboard.getToPullDownZeroKeywordSearch = function getToPullDownZeroKeywordSearch(options) {
    options = UIAUtilities.defaults(options, {
    });

    UIALogger.logMessage("Navigating to pull-down zero-keyword search");

    // ensure that the first app prediction (which is at the top) is visible
    // Unfortunately UIAQuery.tableViews('SPUISearchTableView').andThen(UIAQuery.withValueForKey('SearchUICollectionViewCell', 'className')) will also match on "nearby" maps
    var firstPredictedApp = UIAQuery.tableViews('SPUISearchTableView').andThen(UIAQuery.withValueForKey('SearchUICollectionViewCell', 'className')).withPredicate('ANY identifiers ENDSWITH[c] ", Application"');
    var siriSuggestionsIsVisible = UIAQuery.query('SIRI APP SUGGESTIONS').isVisible(); // this is different from the "SIRI SUGGESTIONS" in left-of-home spotlight

    if (!this.exists(firstPredictedApp.isVisible())) {
        UIAUtilities.assert(this.getToSpotlight(), "Unable to navigate to pull-down spotlight!")

        // If the first predicted app is not visible AND we're not just in spotlight search (i.e. typing in a search term), then we need to scroll up to get to the first app
        //   probably can't happen in pull-down spotlight but may as well account for the possibility due to a future change
        if (!this.exists(firstPredictedApp.isVisible()) && !this.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
            this.scrollUp(firstPredictedApp);
        }

        // We may be in spotlight search instead of zkw.  If so, hit the "x" button in the search bar to get back to zkw
        // This may happen if there is a left-over search in spotlight, but may also happen as a result of scrolling to the first app prediction if it had not been visible
        // NOTE:  this is different from left-of-home zkw, where cancel just goes back to zkw search, and "x" only erases the text without going back to zkw.
        //        Here, "x" goes back to zkw, but cancel exits spotlight entirely.
        //        <rdar://problem/22501938> Cancel and "x" button behavior inconsistent between left-of-home and pull-down spotlight screens
        var clearTextButton = UIAQuery.withValueForKey('Clear text', 'label');
        if (this.exists(clearTextButton.isVisible())) {
            springboard.tap(clearTextButton);
        }

        // If this is shortly after powering up the phone (and/or the first time we use zkw after clicking "Continue" above, we may be on the zkw screen, but with app predictions missing!
        // Since they can't be displayed for a while yet, wait a while to allow the phone to catch up.
        // App predictions won't be displayed even after waiting on the zkw screen, but at that point, we'll be able to get them by exiting and re-entering spotlight.
        // We may have do do this several times depending on how long it takes app predictions to be ready.
        // <rdar://problem/22483543> App Predictions do not appear during first zkw display after an erase install
        var i = 0;
        this.waitUntilPresent(firstPredictedApp.isVisible(), 10);
        while (i++ < 5 && !this.exists(firstPredictedApp.isVisible())) {
            // We're likeley in the state where we're in zkw spotlight, but no app predictions are showing, even after waiting for a while in zkw.
            // To work around this, go back to switchboard home once, and then swipe over to zkw again to get app predictions.
            target.clickMenu();
            target.delay(2);
            this.dragDownInside(UIAQuery.application());
            this.waitUntilPresent(firstPredictedApp.isVisible(), 5); // there may be a delay in apps showing up even now
        }
        return Boolean(this.exists(firstPredictedApp.isVisible()) && this.exists(siriSuggestionsIsVisible));
    }
    return true;
}


/**
* Brings up pull-down spotlight if necessary
*
* @param {object} options Function arguments
* @param {boolean}  [options.dismissSplashScreen=true] - flag to indicate whether or not dismiss First Time Experience(FTE) splash
*
* @returns {boolean} true if pull-down spotlight is up
*   The resulting state may be a left-over search in which text already input, or
*   no input and zero-keyword app predictions displayed. To guarantee input in the search
*   bar is cleared and zero-keyword app predictions are shown, use getToPullDownZkw instead.
*   (Left-of-home zkw is handled by getToZeroKeywordSearch.)
*/
springboard.getToSpotlight = function getToSpotlight(options)
{
    options = UIAUtilities.defaults(options, {
        dismissSplashScreen: true,
    });

    UIALogger.logMessage("Navigating to pull-down spotlight");

    var spotlight = UIAQuery.query('SPUISearchHeader').orElse('SPUISearchView').isVisible();

    if (!this.exists(spotlight)) {
        this.launch();
        this.dragDownInside(UIAQuery.application());
    }

    // workaround for <rdar://problem/31083789> 15A240: Homing out of a cardview > invoke spotlight again, card is still there
    if (!this.exists(spotlight)) {
        // Cards has Back Nav Button, but sheets such as Maps, App Store has Cancel button in place of Back Nav Button
        var maxAttempts = 5;
        while (!this.exists(spotlight) && this.exists(UIAQuery.BACK_NAV_BUTTON) && maxAttempts > 0) {
            this.tap(UIAQuery.BACK_NAV_BUTTON.orElse(UIAQuery.CANCEL_BUTTON));
            maxAttempts -= 1;
        }
    }

    var splashScreen = UIAQuery.withPredicate("value BEGINSWITH 'You can search the web'").isVisible();

    // if dismissSplashScreen is set, and we have splash screen visible, we need to press Continue.
    // Splash screen dont appear if search field is not empty, so also clears the field if its not.
    if (options.dismissSplashScreen) {
        var clearTextButton = UIAQuery.withValueForKey('Clear text', 'label');
        springboard.tapIfExists(clearTextButton);
        if (this.waitUntilPresent(splashScreen, 5)) {
            this.tap(UIAQuery.buttons('Continue'));
        }
    }

    return this.exists(spotlight);
}

/**
 * Returns to the list of search results in Spotlight (common parsec wrapper for getToSpotlight)
 *
 * @throws if unable to navigate back to the search results
 */
UIAApp.prototype.getToParsecSearchResults = function getToParsecSearchResults() {
    if (this.currentUIState() === UIStateDescription.PARSEC_CARD) {
        this.exitParsecCard();
    }
    this.getToSpotlight();
}

/**
 * Drag out a secondary app from the side.
 * (Current app must not be springboard and both apps must support this and have already been launched.)
 *
 * @param {bool} options.splitScreen - if true, tap divider to allow two apps to be used
 * @param {bool} options.application - the application to use as the side app
 * @param {string} options.bundleID - the bundleID of the application to use as the side app
 *
 * @returns {boolean} true if the side app is up
 */
springboard.getToSideApp = function getToSideApp(options)
{
    options = UIAUtilities.defaults(options, {
        splitScreen:false,
        application:null,
    });

    if (target.activeApp().name() === 'SpringBoard' && !this.isInSideAppView()) {
        throw new UIAError("Must launch an app before this function can be used.", {identifier: "Must launch an app before this function can be used"});
    }

    if (!this.isInSideAppView()) {
        UIALogger.logMessage("Revealing side app");
        var stateChangedEvent = UIAWaiter.waiter('ApplicationStateChanged');
        this.swipeFromRightEdge();
        if (!stateChangedEvent.wait(3)) {
            UIALogger.logWarning("Never got the 'ApplicationStateChanged' event.  This may indicate an error.");
        }
        UIAUtilities.assert(this.isInSideAppView(), "Tried to reveal side app, but device did not end up in side app view", {identifier: "Tried to reveal side app, but device did not end up in side app view"});
    }
    else {
        UIALogger.logMessage("Side App View is already active.");
    }

    var application = options.application;
    if (!application && typeof options.bundleID != 'undefined') {
        application = target.appWithBundleID(options.bundleID);
    }

    // if a specific application has been specified then bring it up
    if (application) {
        var appQuery = UIAQuery.application(application.name()).isVisible();
        var activeApps = target.activeApps();
        if (activeApps.length < 2 || activeApps[1] !== application) {
            // bring up the app switcher and select an application
            if (target.activeApp().name() === application.name()) {
                // Application was already brought up when we launched the side app.
                UIALogger.logMessage('The application "%0" is up.'.format(application.name()));
            }
            else if (target.activeApp().exists(application.name())) {
                // app switcher was automatically brought up when we swiped to activate the side app.  Tap on the right app.
                UIALogger.logMessage('Bringing up "%0" as a side app'.format(application.name()));
                this.tap(application.name());
            }
            else {
                // Bring up the app switcher and choose the application.
                springboard.displaySideAppSwitcher();

                UIALogger.logMessage("Choosing %0 as the side app.".format(application.name()));
                stateChangedEvent = UIAWaiter.waiter('ApplicationStateChanged');
                this.tap(application.name());
                if (!stateChangedEvent.wait(3)) {
                     UIALogger.logWarning("Never got the 'ApplicationStateChanged' event while choosing our app.  This may indicate an error.");
                }
                if (target.activeApps().length > 1) {
                    for (var i=0; i<target.activeApps().length; i++) {
                        UIALogger.logMessage("activeApp[%0] = %1, application.name() == %2".format(i, target.activeApps()[i].name(), application.name() ))
                        if (target.activeApps()[i].exists(application.name())) {
                            UIALogger.logMessage("The app %0 is up".format(application.name()));
                            return;
                        }
                    }
                    throw new UIAError(
                        "Two apps are up, but the app %0 isn't active".format(application.name()),
                        {identifier: "Two apps are up, but expected app is not active after tapping it in the side-app switcher"}
                    );
                }
                else {
                    UIAUtilities.assert(
                        target.activeApp().exists(application.name()),
                        "The app %0 isn't active".format(application.name()),
                        {identifier: "App is not active after tapping it in the side-app switcher"}
                    );
                }
            }
        }
    }

    var activeApps = target.activeApps();
    if (options.splitScreen && activeApps.length < 2) {
        if (!this.waitUntilPresent(UIAQuery.SpringBoard.SIDE_APP_DIVIDER)) {
            throw new UIAError("Side App Divider is not present");
        }
        this.tap(UIAQuery.SpringBoard.SIDE_APP_DIVIDER);

        var timeout = 3;
        var started = new Date().getTime();
        var elapsed = 0;
        while (elapsed < timeout && activeApps.length < 2) {
            activeApps = target.activeApps();
            elapsed = (new Date().getTime() - started) / 1000;
        }
        UIAUtilities.assert(target.activeApps().length > 1, "Assert active apps greater than 1 failed.", {identifier:"Split screen mode should have been activated, but wasn't"});
    }

    return true;
}

/**
 * Brings up zero keyword search if necessary
 *
 * @returns {boolean} true if zkw / left-of-home spotlight is up, and app predictions are being shown
 * (Pull-down spotlight is handled by getToSpotlight.)
 */
springboard.getToZeroKeywordSearch = function getToZeroKeywordSearch(options) {
    options = UIAUtilities.defaults(options, {
    });

    UIALogger.logMessage("Navigating to left-of-home Zero Keyword Search view");

    // ensure that the first app prediction (which is at the top) is visible
    // Unfortunately UIAQuery.tableViews('SPUISearchTableView').andThen(UIAQuery.withValueForKey('SearchUICollectionViewCell', 'className')) will also match on "nearby" maps
    var firstPredictedApp = UIAQuery.tableViews('SPUISearchTableView').andThen(UIAQuery.withValueForKey('SearchUICollectionViewCell', 'className')).withPredicate('ANY identifiers ENDSWITH[c] ", Application"');
    var siriSuggestionsIsVisible = UIAQuery.query('SIRI SUGGESTIONS').isVisible();

    if (!this.exists(firstPredictedApp.isVisible())) {
        this.launch();
        this.swipeFromLeftEdge(UIAQuery.application());

        // We may be on the intro screen that one sees the first time after an erase install, instead of normal spotlight.  If so, we need to press "continue"
        if (this.exists(UIAQuery.withPredicate("value BEGINSWITH 'You can search the web'").isVisible())) {
            // Tap and touch don't work on "Continue" below, but swipe does
            // <rdar://problem/22506386> tap and touch operations do not work on "Continue" in the introduction to Spotlight screen
            this.swipeDown(UIAQuery.withPredicate("value BEGINSWITH 'Continue'"));
        }

        // If the first predicted app is not visible AND we're not just in spotlight search (i.e. typing in a search term), then we need to scroll up to get to the first app
        if (!this.exists(firstPredictedApp.isVisible()) && !this.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
            this.scrollUp(firstPredictedApp);
        }

        // We may be in spotlight search instead of zkw.  If so, hit "cancel" to get back to zkw
        //  This may happen if there is a left-over search in spotlight, but may also happen as a result of scrolling to the first app prediction if it had not been visible
        //  This is different from the equivalent operation in pull-down spotlight.
        //  <rdar://problem/22501938> Cancel and "x" button behavior inconsistent between left-of-home and pull-down spotlight screens
        if (this.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
            this.tap(UIAQuery.CANCEL_BUTTON);
        }

        // If this is shortly after powering up the phone (and/or the first time we use zkw after clicking "Continue" above, we may be on the zkw screen, but with app predictions missing!
        // Since they can't be displayed for a while yet, wait a while to allow the phone to catch up.
        // App predictions won't be displayed even after waiting on the zkw screen, but at that point, we'll be able to get them by exiting and re-entering spotlight.
        // We may have do do this several times depending on how long it takes app predictions to be ready.
        // <rdar://problem/22483543> App Predictions do not appear during first zkw display after an erase install
        var i = 0;
        this.waitUntilPresent(firstPredictedApp.isVisible(), 10);
        while (i++ < 5 && !this.exists(firstPredictedApp.isVisible())) {
            // We're likeley in the state where we're in zkw spotlight, but no app predictions are showing, even after waiting for a while in zkw.
            // To work around this, go back to switchboard home once, and then swipe over to zkw again to get app predictions.
            target.clickMenu();
            target.delay(2);
            this.swipeFromLeftEdge(UIAQuery.application());
            this.waitUntilPresent(firstPredictedApp.isVisible(), 5); // there may be a delay in apps showing up even now
        }
        return Boolean(this.exists(firstPredictedApp.isVisible()) && this.exists(siriSuggestionsIsVisible));
    }
    return true;
}

/**
 * Navigates to the first page of SpringBoard app icons
 *
 * @throws if the first page is not reached
 */
springboard.getToFirstIconPage = function getToFirstIconPage() {

    this.launch();
    this.getToAppLauncher();

    var curPage = this.inspectElementKey(UIAQuery.query('SBIconListPageControl'), 'pageIndex');
    var prevPage = curPage - 1; // value of prevPage during first loop is irrelevant, it just needs to be different than curPage
    if (curPage < 1) {
        while (curPage < 1 && curPage !== prevPage) { // will break if pageIndex doesn't change, prevents infinite loop
            UIALogger.logDebug('Attempting to move springboard one page forward');
            this.swipeFromRightEdge(UIAQuery.application());

            prevPage = curPage;
            curPage = this.inspectElementKey(UIAQuery.query('SBIconListPageControl'), 'pageIndex');
        }
    } else if (curPage > 1) {
        while (curPage > 1 && curPage !== prevPage) { // will break if pageIndex doesn't change, prevents infinite loop
            UIALogger.logDebug('Attempting to move springboard one page backward');
            this.swipeFromLeftEdge(UIAQuery.application());

            prevPage = curPage;
            curPage = this.inspectElementKey(UIAQuery.query('SBIconListPageControl'), 'pageIndex');
        }
    }

    if (this.inspectElementKey(UIAQuery.query('SBIconListPageControl'), 'pageIndex') !== 1) {
        throw new UIAError('The first page of Springboard was not reached', {identifier: 'The first page of Springboard was not reached'});
    }
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Tasks                                                               */
/*                                                                             */
/*      A high-level goal we are trying to accomplish.                         */
/*      Comprised of multiple Action functions and do not assume state         */
/*                                                                             */
/*******************************************************************************/

/*
 * Creates a folder by draging an app on top of another
 * app. Additional apps can then be added to newly created
 * folder.
 *
 * Expected starting states: Any
 *
 * @param {string[]} args.apps - Apps to add to create a folder. Must
 *                          include at least two apps. Name comes
 *                          from label display in UI for app.
 * @param {object} options
 * @param {null|string} folderName - Optional name for folder. If not set,
 *                              will use system determined name
 *
 * @throws If elements don't exist in main SpringBoard view or if
 *          cannot add element to folder.
 */
springboard.createFolder = function createFolder(apps, options) {
    options = UIAUtilities.defaults(options, {
        folderName: null,
        verify: true,
    });

    this.launch();
    UIAUtilities.assert(
        apps.length >= 2,
        'At least two apps are required to create a folder'
    );

    this.dragIconOnTo(apps[0], apps[1]);

    // check we are in folder view after drag
    if (!this.waitUntilPresent(UIAQuery.SpringBoard.FOLDER, 3)) {
        UIALogger.logDebug('Folder creation view did not appear. Checking to see if any folder exists with the given apps inside it.');
        var folderIconQuery = this.folderIconQuery({children:[apps[0], apps[1]]});
        UIAUtilities.assert(
            this.exists(folderIconQuery),
            "No folder with apps ['%0', '%1'] exists after dragging them ontop of each other.".format(apps[0],apps[1])
        );
        this.getToIcon(folderIconQuery);
        this.tap(folderIconQuery);
        // check we are in folder view after tapping it
        if (!this.waitUntilPresent(UIAQuery.SpringBoard.FOLDER, 3)) {
            throw new UIAError('Folder creation view did not appear after tapping the folder icon.');
        }
    }

    if (options.folderName) {
        this.enterText(
            UIAQuery.buttons('Clear text').isVisible(),
            options.folderName,
            {clearTextBeforeTyping:false}
        );
    } else {
        // otherwise we need to get the auto-generated name
        options.folderName = this.inspectElementKey(UIAQuery.query("Folder name"), 'value');
    }

    // close folder
    target.clickMenu();

    // add any remaining elements
    if (apps.length > 2) {
        this.addToFolder(
            apps.slice(2),
            options.folderName,
            {verifyElements: false, dragOptions: {holdDuration: 2, duration: 3}}
        );
    }

    // Hard delay to allow for the folder to quickly 'slide' to a new place on-screen
    // Removal being tracked in <rdar://33686381>
    this.delay(1);

    // verify everything was added
    if (options.verify) {
        this.verifyFolderAndElements(options.folderName, apps);
    }
}

/*
 * Adds specified elements to specified folder
 *
 * Expected starting states: Any
 *
 * @param {string[]} elements - Elements to be added
 * @param {string} folder - Folder to add to
 * @param {object} options
 * @param {boolean} options.verifyElement - Flag, if set verifies element(s)
 *                          added to folder
 * @param {dictionary} options.dragOptions - Sets options for icon drag timing
 *
 * @throws If elements don't exist in main SpringBoard view or if
 *          cannot add element to folder.
 */
springboard.addToFolder = function addToFolder(elements, folder, options) {
    options = UIAUtilities.defaults(options, {
        verifyElements: true,
        dragOptions: {holdDuration: 3, duration: 4},
    });

    this.launch();

    for (var i = 0; i < elements.length; i++) {
        // Delay added due to loss of multiple drag sessions as mentioned in <rdar://31900155>
        this.waitUntilReady();
        UIAUtilities.assert(
            this.exists(UIAQuery.icons(elements[i])),
            "Element '%0' does not exist in main SpringBoard view.".format(elements[i])
        );
        springboard.dragIconOnTo(elements[i], folder, options.dragOptions);
    }

    if (options.verifyElements) {
        this.verifyFolderAndElements(folder, elements);
    }
}

/**
 * Renames an existing folder
 *
 * @param   {string}  folderName - the name of the existing folder
 * @param   {string}  newFolderName - a new name for the folder
 * @param   {object}  options - a dictionary object of optional arguments
 *
 * @returns {boolean} true if the folder was renamed
 */
springboard.renameFolder = function renameFolder(folderName, newFolderName)
{
    if (!folderName) {
        throw new UIAError("Name of folder not specified");
    }

    if (!newFolderName) {
        throw new UIAError("New name for folder not specified");
    }

    var folderIconQuery = this.folderIconQuery({name:folderName});
    this.getToIcon(folderIconQuery);
    this.tap(folderIconQuery);
    try {
        var nameFieldQuery = UIAQuery.query(folderName + ', Folder');
        this.touchAndHold(nameFieldQuery, 2);
        this.enterText(nameFieldQuery, newFolderName);
        UIAUtilities.assert(this.exists(UIAQuery.textFields(folderName)), "Folder with the new name '" + newFolderName + "' does not exist");
    } finally {
        // make sure the folder is closed if something goes wrong
        try {
            this.getToAppLauncher();
        } catch (e) {
            UIALogger.logError(e);
        }
    }

    var newFolderIconQuery = this.folderIconQuery({name:newFolderName});

    return this.exists(newFolderIconQuery);
}

/**
 * Empty folder
 *
 * @param   {string}  folderName - the name of a folder
 * @param   {object}  options - a dictionary object of optional arguments
 *
 * @returns {boolean} true if the folder is no longer found after emptying it
 */
springboard.emptyFolder = function emptyFolder(folderName, options)
{
    var iconInFolder = UIAQuery.query('SBFolderIconListView').andThen('Icon');
    var folderIconQuery = this.folderIconQuery({name:folderName});
    while (this.waitUntilPresent(folderIconQuery, 1)) {
        // while there is still a folder that matches the query, empty it (it should go away once empty)
        this.getToIcon(folderIconQuery);
        this.tap(folderIconQuery);
        try {
            // enter shaky icon mode and drag out of the folder
            this.drag(iconInFolder, {hold: 3, duration: 4, toOffset: {x: 1, y: 4}})
        } finally {
            // make sure the folder is closed if something goes wrong
            try {
                this.getToAppLauncher();
            } catch (e) {
                UIALogger.logError(e);
            }
        }
    }

    return this.exists(folderIconQuery);
}

/**
 * Calls UIAApp.search with options required for SpringBoard set
 *  (see [UIAApp.search]{@link UIAApp#search} for more details)
 */
springboard.search = function search(searchString, options) {
    options = UIAUtilities.defaults(options, {
        dragDownForSearchField: true,
        searchField: UIAQuery.searchBars().isVisible().orElse(UIAQuery.textFields().isVisible()).orElse(UIAQuery.textViews().isVisible()),
    });

    this.__proto__.search.apply(this, [searchString, options]);  // calling proto implementation
}

/**
 * Drags brightness slider up and down, verifies the brightness value changed.
 *
 * Required Starting View: Control Center
 */
springboard.checkBrightnessControl = function checkBrightnessControl() {
    // Check if we are in Control Center view and Brightness slider is available
    var currentUI = this.currentUIState();
    UIAUtilities.assert(
        (currentUI === UIStates.CONTROL_CENTER.Description),
        'Failed to get to Control Center view. Current UI state: %0'.format(currentUI)
    );
    UIAUtilities.assert(
        (this.exists(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER)),
        'Brightness slider control does not exist'
    );

    // Get the initial position of the slider
    var previousBrightness = this.getValueFromPercentString(this.inspect(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER).value);
    UIALogger.logMessage('Initial Brightness value: %0'.format(previousBrightness));

    // Different sets of drag options depending on the initial position of the slider
    var firstDragOptions = {fromOffset: {x: 0.5, y: 0.7}, toOffset: {x: 0.5, y: 0.3}};
    var secondDragOptions = {fromOffset: {x: 0.5, y: 0.3}, toOffset: {x: 0.5, y: 0.7}};
    if (previousBrightness >= 50) {
        firstDragOptions = {fromOffset: {x: 0.5, y: 0.3}, toOffset: {x: 0.5, y: 0.7}};
        secondDragOptions = {fromOffset: {x: 0.5, y: 0.7}, toOffset: {x: 0.5, y: 0.3}};
    }

    // Try to drag the slider and verify the value changed
    this.drag(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER, firstDragOptions);
    var currentBrightness = this.getValueFromPercentString(this.inspect(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER).value);
    UIALogger.logMessage('Modified Brightness value: %0'.format(currentBrightness));
    UIAUtilities.assertNotEqual(
        previousBrightness,
        currentBrightness,
        'Failed to change Brightness value using Control Center slider'
    );

    // Try to drag the slider back and verify the value changed again
    this.drag(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER, secondDragOptions);
    previousBrightness = this.getValueFromPercentString(this.inspect(UIAQuery.SpringBoard.BRIGHTNESS_SLIDER).value);
    UIALogger.logMessage('Restored Brightness value: %0'.format(previousBrightness));
    UIAUtilities.assertNotEqual(
        previousBrightness,
        currentBrightness,
        'Failed to restore Brightness value using Control Center slider'
    );
}

/**
 * Launches specified app from Control Center and verifies it is active
 *
 * Required Starting View: Control Center
 * 
 * @param {object} [options] - Test arguments 
 * @param {string} [options.appName] - Name of app to launch 
 */
springboard.launchAppFromCC = function launchAppFromCC(options) {
    // Check arguments
    UIAUtilities.assert(
        (options.appName.length > 0),
        'Invalid argument options.appName'
    );
    // Check if we are in Control Center view and app button is available
    var currentUI = this.currentUIState();
    UIAUtilities.assert(
        (currentUI === UIStates.CONTROL_CENTER.Description),
        'Failed to get to Control Center view. Current UI state: %0'.format(currentUI)
    );
    
    var app = this.getCCAppButtonQuery(options.appName);
    UIAUtilities.assert(
        (this.exists(app.buttonQuery)),
        'Button for "%0" app does not exist'.format(options.appName)
    );

    var appWaiter = UIAWaiter.withPredicate(
        'ApplicationStateChanged', 
        'bundleID == "%0" AND state == "Foreground"'.format(app.bundleID)
    );

    this.scrollToVisible(app.buttonQuery);
    this.tap(app.buttonQuery);

    var waitRes = appWaiter.wait(10.0);
    var active = target.activeApp().bundleID();
    UIALogger.logMessage('Active app: %0'.format(active));
    if ((active !== app.bundleID) && (!waitRes)) {
        throw new UIAError('Failed to launch "%0" app from Control Center'.format(options.appName));
    }
}

/**
 * Opens Connectivity panel within Control Center, taps Airdrop, sets specified mode
 *
 * Required Starting View: Control Center
 *
 * @param {object} [options] - Test arguments
 * @param {object} [options.mode] - Airdrop mode
 */
springboard.setAirdropMode = function setAirdropMode(options) {
    // Check arguments
    UIAUtilities.assert(
        (options.mode.length > 0),
        'Invalid argument options.mode'
    );
    // Check if we are in Control Center view
    var currentUI = this.currentUIState();
    UIAUtilities.assert(
        (currentUI === UIStates.CONTROL_CENTER.Description),
        'Failed to get to Control Center view. Current UI state: %0'.format(currentUI)
    );

    // Force touch Conn box to invoke Conn panel 
    this.touchForPopGesture(UIAQuery.SpringBoard.CONN_BOX_CC);
    UIAUtilities.assert(
        (this.waitUntilPresent(UIAQuery.SpringBoard.AIRDROP_BUTTON, 5.0)),
        'Failed to open Conn panel'
    );

    // Waiters for AirDrop panel is appeared and disappeared
    var airDropPanelOpenWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass == "CCUIMenuModuleViewController" AND controllerTitle == "AirDrop"'
    );
    var airDropPanelCloseWaiter = UIAWaiter.withPredicate(
        'ViewDidDisappear',
        'controllerClass == "CCUIMenuModuleViewController" AND controllerTitle == "AirDrop"'
    );

    // Tap AirDrop button to open AirDrop Modes panel
    this.tap(UIAQuery.SpringBoard.AIRDROP_BUTTON);
    if (!airDropPanelOpenWaiter.wait(5.0)) {
        throw new UIAError('Failed to open AirDrop Modes panel');
    }

    // Choose the AirDrop mode specified in parameters
    var modeButton = UIAQuery.query('CCUIMenuModuleStackView').andThen(UIAQuery.buttons(options.mode));
    UIAUtilities.assert(
        (this.exists(modeButton)),
        'Button with option "%0" does not exist'.format(options.mode)
    );

    this.tap(modeButton);
    if (!airDropPanelCloseWaiter.wait(5.0)) {
        throw new UIAError('Failed to close AirDrop Modes panel');
    }

    // Dismiss Conn panel
    this.tap(UIAQuery.query('CCUIContentModuleBackgroundView'));
}

/*
 * Scrolls up and down Spotlight page
 *
 * Required Starting View: Spotlight
 */
springboard.scrollSpotlightView = function scrollSpotlightView() {
    // Check if the device in a required UI state
    var currentUI = this.currentUIState();
    UIAUtilities.assert(
        (currentUI === UIStates.SPOTLIGHT.Description),
        'Device is not in a required state. Current UI state is "%0"'.format(currentUI)
    );

    this.drag(UIAQuery.SpringBoard.SPOTLIGHT_TABLE_VIEW, {fromOffset: {x: 0.5, y: 0.9}, toOffset: {x: 0.5, y: 0.1}});
    this.delay(1); // Just to make gestures look more natural
    this.drag(UIAQuery.SpringBoard.SPOTLIGHT_TABLE_VIEW, {fromOffset: {x: 0.5, y: 0.1}, toOffset: {x: 0.5, y: 0.9}});
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation and helper functions                     */
/*      These will assume the devices is already in the required state         */
/*                                                                             */
/*******************************************************************************/

/**
 * Returns a UIAQuery for a folder icon
 *
 * @param   {object}  options - a dictionary object of optional arguments
 * @param   {boolean} options.name - the name of the folder
 * @param   {boolean} options.children - the display name of apps contained in the folder
 *
 * @returns {object} the query
 */
springboard.folderIconQuery = function folderIconQuery(options)
{
    options = UIAUtilities.defaults(options, {
        name:null,
        children:null
    });

    var predicate;

    if (options.name) {
        predicate = "label == '" + options.name + " folder'";
    } else {
        predicate = "label ENDSWITH 'folder'";
    }

    if (options.children instanceof Array) {
        for (var childIndex = 0; childIndex < options.children.length; childIndex++)
        {
            var name = options.children[childIndex];
            predicate = predicate + " AND ANY children.label == '" + name + "'";
        }
    }

    return UIAQuery.withPredicate(predicate);
}

/**
 * Returns a UIAQuery for an icon
 *
 * @param   {object}  options - a dictionary object of optional arguments
 * @param   {boolean} options.name - the name of the folder
 * @param   {boolean} options.bundleID - the bundle id for an app icon
 *
 * @returns {object} the query
 */
springboard.iconQuery = function iconQuery(options)
{
    options = UIAUtilities.defaults(options, {
        name:null,
        bundleID:null
    });

    var predicate = null;

    if (options.name) {
        predicate = "label == '" + options.name + "'";
    }

    if (options.bundleID) {
        predicate = (predicate) ? predicate + " AND " : "";
        predicate = predicate + "bundleID == '" + options.bundleID + "'";
    }

    return UIAQuery.withPredicate(predicate);
}

/**
 * Dismiss the side application.
 *
 * @returns {None} - throws an error if the side app is still up.
 */
springboard.dismissSideApp = function dismissSideApp()
{
    if (!this.isInSideAppView()) {
        UIALogger.logMessage("Not in side app view.  Don't need to dismiss it.");
        return;
    }

    UIALogger.logMessage('Dismissing side app');

    if (!this.tapIfExists(UIAQuery.SpringBoard.DISMISS_SIDE_APP)) {
        this.drag(UIAQuery.SpringBoard.SIDE_APP_DIVIDER, {toQuery:"Application", toOffset:{x:0.9, y:0.5}});
    }

    if (this.isInSideAppView()) {
        throw new UIAError("Tried to dismiss the side app, but side app view is still active.", {identifier:"Tried to dismiss the side app, but side app view is still active"});
    }
}

/**
 * Display the Medusa switcher
 *
 * @returns {None} - throws an error if the Medusa switcher cannot be displayed.
 */
springboard.displaySideAppSwitcher = function displaySideAppSwitcher()
{
    if (springboard.exists("SBSideSwitcherContainerView")) {
        UIALogger.logMessage("Already in side app switcher.  Returning.");
        return;
    }

    if (!this.isInSideAppView()) {
        throw new UIAError("Not in side app view.  Cannot display the Medusa switcher from here.", {identfier: "Must be in side app view before the switcher can be brought up"});
    }

    UIALogger.logMessage('Dragging down the side app switcher chevron.');
    var stateChangedEvent = UIAWaiter.waiter('ViewDidDisappear');
    this.dragDownSideAppSwitcherChevron();
    if (!stateChangedEvent.wait(3)) {
         UIALogger.logWarning("Did not get the 'ViewDidDisappear' event while dragging down the side app switcher chevron.");
    }

    springboard.assertExists("SBSideSwitcherContainerView", "Not in the Side App Switcher View");
}


/**
 * Return true if a side app or side app switcher is active and false if not
 *
 * @returns {boolean} false if the side app is still up
 */
springboard.isInSideAppView = function isInSideAppView()
{

    if (this.exists(UIAQuery.SpringBoard.SIDE_APP_DIVIDER)) {
        return true;
    }

    // If the app switcher is showing as the side app, the above statement will fail, because the side app divider isn't visible.
    if (this.exists(UIAQuery.SpringBoard.DISMISS_SIDE_APP)) {
        return true;
    }

    return false;
}

/**
 * Drags the Side App chevron down to reveal the side app switcher
 *
 * @returns {None} - will throw an error if the swipe didn't work.
 */
springboard.dragDownSideAppSwitcherChevron = function dragDownSideAppSwitcherChevron()
{
    if (this.exists(UIAQuery.SpringBoard.SIDE_APP_SWITCHER_CONTROL)) {
        springboard.drag(UIAQuery.SpringBoard.SIDE_APP_SWITCHER_CONTROL, {fromOffset:{x:0.5, y:0.0}, toQuery: UIAQuery.application(), toOffset: {x: 0.80, y: 0.9}});
    } else {
        // Handle a hidden chevron by dragging down twice
        var activeApps = target.activeApps();
        var sideApp = activeApps[activeApps.length - 1];
        sideApp.drag(UIAQuery.application(), {fromOffset: {x: 0.5, y: 0}, toOffset: {x: 0.5, y: 0.5}, duration: 0.5});
        sideApp.drag(UIAQuery.application(), {fromOffset: {x: 0.5, y: 0}, toOffset: {x: 0.5, y: 0.5}, duration: 0.5});
    }
}

/**
 * Returns true if the device is showing two active apps at once (split screen mode or 'pinned' mode)
 *
 * @returns {boolean} true if device has two active apps, false if not.
 */
springboard.isInSplitScreenMode = function isInSplitScreenMode()
{
    return ((target.activeApps().length > 1) ? true : false);
}

/**
 * Activates the Split Screen if there's an Active Side App.
 *
 * @returns {boolean} throws an error if the split screen couldn't be activated.
 */
springboard.activateSplitScreenFromActiveSideApp = function activateSplitScreenFromActiveSideApp()
{
    if (target.activeApps().length > 1) {
        UIALogger.logMessage("Split Screen is already Active.");
        return;
    }

    UIAUtilities.assert(springboard.isInSideAppView(), "Cannot pin the app - no active side app", {identifier: "Cannot pin the app - no active side app"});

    this.tap(UIAQuery.SpringBoard.SIDE_APP_DIVIDER);

    //<rdar://problem/19552428> Need a notification when split screen becomes active
    // Until that happens, let's wait for the number of active apps to become two
    var timeout = 3;
    var started = new Date().getTime();
    var elapsed = 0;
    while (elapsed < timeout) {
        if (target.activeApps().length == 2) {
            UIALogger.logMessage("Two apps are active.  Device is now in split screen mode.");
            return;
        }
        elapsed = (new Date().getTime() - started) / 1000;
        UIALogger.logMessage('Waiting for two apps to become active: elapsed: %0, timeout: %1'.format(elapsed, timeout));
        target.delay(0.25);
    }
    UIAUtilities.assert(target.activeApps().length > 1, "There is only one active app.  The split screen is not up.", {identifier: "Split screen should have been activated, but it wasn't"});
}

/**
 * Resizes the Side App -- assumes there's either a side app or a split screen up.
 *
 * @param   {number} dragToXValue - a number from 0-1 indicating where on the screen to resize to.
 * @param   {object}  options - a dictionary object of optional arguments
 * @param   {boolean} options.expectedAppPercent - indicates the approximate percentage of the screen that the app should use
 *
 * @returns {} throws an error if the side app couldn't be resized.
 */
springboard.resizeSideApp = function resizeSideApp(dragToXValue, options)
{
    options = UIAUtilities.defaults(options, {
        expectedAppPercent:null
    });

    if (!this.exists(UIAQuery.SpringBoard.SIDE_APP_DIVIDER)) {
        throw new UIAError("Side app was not up when this function was called.  It cannot be resized.", {identifier: "Side App must be active for resize to take place"});
    }

    var stateChangedEvent = UIAWaiter.waiter('TouchEventsCompleted');
    this.drag(UIAQuery.SpringBoard.SIDE_APP_DIVIDER, {toQuery:"Application", toOffset:{x:dragToXValue, y:0.5}});
    if (!stateChangedEvent.wait(3)) {
        UIALogger.logWarning("Never got the 'TouchEventsCompleted' event.  This may indicate an error.");
    }

    if ((typeof options.expectedAppPercent !== 'undefined') && options.expectedAppPercent) {
        var theAppWidth = parseInt(Number(target.activeApps()[0].inspect("Application").rect.width));
        var springboardWidth = parseInt(Number(target.systemApp().inspect("Application").rect.width));
        var appWidthPercent = theAppWidth/springboardWidth;
        options.expectedAppPercent = Number(options.expectedAppPercent);
        if ((options.expectedAppPercent - .1 < appWidthPercent) && (appWidthPercent < options.expectedAppPercent + .1)) {
            UIALogger.logMessage("App Percent is correct--expected %0, got %1".format(options.expectedAppPercent, appWidthPercent));
        }
        else {
            throw new UIAError("App Percent is not as expected--expected %0, got %1".format(options.expectedAppPercent, appWidthPercent), {identifier: "App percent is not as expected"});
        }
    }
}

/**
 * Deactivates the Split Screen if it's up.
 *
 * @returns {None} throws error if the split screen cannot be dismissed
 */
springboard.deactivateSplitScreen = function deactivateSplitScreen()
{
    if (target.activeApps().length < 2) {
        UIALogger.logMessage("Split screen is not currently active.  No need to do anything");
        return;
    }

    UIALogger.logMessage("Tapping Side App Divider to deactivate Split Screen.");
    var stateChangedEvent = UIAWaiter.waiter('ViewDidAppear');
    this.tap(UIAQuery.SpringBoard.SIDE_APP_DIVIDER);
    if (!stateChangedEvent.wait(3)) {
        UIALogger.logWarning("Never got the 'ViewDidAppear' event for deactiving the split screen.  This may indicate an error.");
    }

    //<rdar://problem/20228764> UIA2: Need a notification when the split screen gets dismissed
    // Until that happens, let's wait for the number of active apps to become one
    var timeout = 3;
    var started = new Date().getTime();
    var elapsed = 0;
    while (elapsed < timeout) {
        if (target.activeApps().length == 1) {
            UIALogger.logMessage("One app is active.  Device is no longer in split screen mode.");
            return;
        }
        elapsed = (new Date().getTime() - started) / 1000;
        UIALogger.logMessage('Waiting for only one app to be active: elapsed: %0, timeout: %1'.format(elapsed, timeout));
        target.delay(0.25);
    }
    UIAUtilities.assert(target.activeApps().length < 2, "Two apps are active.  Split screen did not deactivate", {identifier: "Split screen did not deactivate"});
}

/*
 * Verifies that specified elements exist within specifiec folder
 *
 * Expected starting states: Any view
 *
 * @param {string} folder - Name of folder to check for
 * @param {array of strings} elements - Elements to search for in folder
 *
 * @throws If folder doesn't exist or elements don't exist in folder.
 */
springboard.verifyFolderAndElements = function verifyFolderAndElements(folder, elements) {
    this.launch();
    UIAUtilities.assert(
        this.exists(UIAQuery.icons(folder)),
        "Folder '%0' does not exist.".format(folder)
    );

    this.openFolder(UIAQuery.icons(folder));

    for (var i = 0; i < elements.length; i++) {
        UIAUtilities.assert(
            this.exists(UIAQuery.SpringBoard.FOLDER.andThen(UIAQuery.icons(elements[i]))),
            "Element '%0' does not exist in folder '%1'.".format(elements[i], folder)
        );
    }

    // close folder
    target.clickMenu();
}

/*
 * In the current view, drags an icon onto another icon
 *
 * @param {string} icon - icon to drag
 * @param {string} onToIcon - icon to drag onto
 */
springboard.dragIconOnTo = function dragIconOnTo(icon, onToIcon, dragOptions) {
    var dragOptions = UIAUtilities.defaults(dragOptions, {
        holdDuration: 3,
        duration: 4,
        toQuery: UIAQuery.icons(onToIcon),
    });

    this.drag(UIAQuery.icons(icon), dragOptions);
    // sometimes the icons will re-organize themselves mid-move and the calculated endpoint is now wrong
    // when this happens the moved icon is relatively close. One more drag is sufficient.
    if (this.exists(UIAQuery.icons(icon))) {
        // Delay added due to loss of multiple drag sessions as mentioned in <rdar://31900155>
        this.waitUntilReady();
        this.dragIfExists(UIAQuery.icons(icon), dragOptions);
    }
}

/**
 * Check if a widget is enabled in the Today View
 *
 * @param {string} widget - Title of widget displayed in Today View
 *
 * @returns {boolean} true on success, false otherwise
 */
springboard.isWidgetEnabled = function isWidgetEnabled(widget) {

    this.getToWidgets();
    return this.exists(UIAQuery.SpringBoard.TODAY_VIEW.andThen(widget.toUpperCase()));
};

/**
 * Check whether a widget is visible in the edit view of the Today view. The edit view is
 * the view in which widgets can be added and removed.
 *
 * @param {string} widget - Title of widget displayed in Today view
 *
 * @returns {boolean} true if the widget is visible, false otherwise
 */
springboard.isWidgetVisibleInEditView = function isWidgetVisibleInEditView(widget) {

	this.getToWidgets();
	this.tap(UIAQuery.SpringBoard.TODAY_VIEW_EDIT_BUTTON);

	var result = this.exists(UIAQuery.query(widget));

	// clean up after ourselves
	this.tap(UIAQuery.query('Done'));

	return result;
};

/**
 * Enable a list of widgets by name in the Today View
 *
 * @param {array} widgets - String titles of widgets to enable in Today View
 *
 * @returns {boolean} true on success, false otherwise
 */
springboard.enableWidgets = function enableWidgets(widgets) {

    this.getToWidgets();

    var widgetsToEnable = [];
    var count = widgets.length;
    for (var i = 0; i < count; i++) {
        var widgetName = widgets[i];
        if (!this.isWidgetEnabled(widgetName)) {
            widgetsToEnable.push(widgetName);
        }
    }

    if (widgetsToEnable.length > 0) {
        this.tap(UIAQuery.SpringBoard.TODAY_VIEW_EDIT_BUTTON);
        var count = widgetsToEnable.length;
        for (var i = 0; i < count; i++) {
            var widgetName = widgetsToEnable[i];
            var enableWidgetButton = UIAQuery.buttons('Insert %0'.format(widgetName));
            this.scrollToVisible(enableWidgetButton);
            this.tap(enableWidgetButton);
        }
        this.tap(UIAQuery.buttons('Done'));
    }

    // check that all widgets were indeed enabled
    var retValue = true;
    count = widgets.length;
    for (var i = 0; i < count; i++) {
        var widgetName = widgets[i];
        if (!this.isWidgetEnabled(widgetName)) {
            retValue = false;
            break;
        }
    }

    return retValue;
};

/**
 * Removes all widgets from Today except the specified widget
 *
 * @param {array} widgets - String titles of widgets to leave displayed in Today view
 *
 * @returns {boolean} true on success, false otherwise
 */
springboard.removeAllWidgetsExcept = function removeAllWidgetsExcept(widgets) {

    this.getToWidgets();
    this.tap(UIAQuery.query('WGWidgetListFooterView').andThen('Edit'));
    var predicate = "name BEGINSWITH 'Delete'";
    var count = this.count(UIAQuery.withPredicate(predicate));
    var prevCount = 0;
    while(count > 0 && prevCount !== count) {
        this.tap(UIAQuery.withPredicate(predicate));
        this.tap(UIAQuery.withPredicate(predicate).parent().andThen('Remove'));

        prevCount = count;
        count = this.count(UIAQuery.withPredicate(predicate));
    }
    this.tap(UIAQuery.buttons('Done'));

    // add back desired widgets
    var enableSucceeded = this.enableWidgets(widgets);

    // get count of enabled widgets in Today View
    var numVisibleWidgets = this.count(UIAQuery.query('WGWidgetPlatterView'));

    // confirm only specified widgets exist
    return enableSucceeded && (numVisibleWidgets == widgets.length);
};

/**
 * Taps the Show More/Show Less button on the specified widget
 *
 * @param {string} widget - Title of widget displayed in Today View
 *
 * @returns {boolean} true on success, false otherwise
 */
springboard.widgetTapShowMoreLess = function widgetTapShowMoreLess(widget) {
    return springboard.tapIfExists(UIAQuery.query(widget.toUpperCase()).parent(), {offset: {x: 0.95, y: 0.5}});
};

/**
 * Puts the specified widget into Compact or Expanded mode. May need to
 * tap Show More/Show Less several times to determine when it is
 * in the correct display mode
 *
 * @param {string} widget - Title of widget displayed in Today View
 * @param {boolean} expanded - true to set Expanded mode, false to set Compact mode
 *
 * @returns {void}
 */
springboard.widgetSetDisplayMode = function widgetSetDisplayMode(widget, expanded) {

    // using this .parent().parent().. chaining until this radar is resolved
    // <rdar://problem/25863149> .above() method failing to find element
    var query = UIAQuery.query(widget.toUpperCase()).parent().parent().parent('WGWidgetShortLookView');
    var height = this.inspect(query).rect.height;
    this.widgetTapShowMoreLess(widget);

    var new_height = this.inspect(query).rect.height;

    if (expanded) {
        if (new_height < height) {
            this.widgetTapShowMoreLess(widget);
        }
    } else {
        if (new_height > height) {
            this.widgetTapShowMoreLess(widget);
        }
    }
};

/**
 * Scrolls the specified widget into view on the screen.
 * If the widget has been scrolled into view and then changed
 * to Expanded mode, the widget may hang off the bottom
 * of the screen. Calling this method again will unfortunately
 * not scroll the entire widget into view again.
 *
 * @param {string} widget - Title of widget displayed in Today View
 *
 * @returns {void}
 */
springboard.scrollToWidget = function scrollToWidget(widget) {

    if (!this.widgetsAreOnScreen()) {
        this.getToWidgets();
    }

    // using this .parent().parent().. chaining until this radar is resolved
    // <rdar://problem/25863149> .above() method failing to find element
    this.scrollToVisible(UIAQuery.query(widget.toUpperCase()).parent().parent().parent('WGWidgetShortLookView'));
};

/**
 * Determines whether widgets in the Today View are currently visible
 * on the screen
 *
 * @returns {boolean} true if widgets are visible, false otherwise
 */
springboard.widgetsAreOnScreen = function widgetsAreOnScreen() {
    var pageControlQuery = UIAQuery.query('SBIconListPageControl');
    return this.exists(pageControlQuery) && (this.inspectElementKey(pageControlQuery, 'pageIndex') === 0)
};

/**
 * Converts string value with percent sign, e.g. '50%', to integer, e.g. 50
 *
 * @param {string} stringValue - string that needs to be converted (e.g. '50%')
 * @returns {integer} - integer value included in the original string
 */
springboard.getValueFromPercentString = function getValueFromPercentString(stringValue) {
    var valueLength = stringValue.length;
    var intValue = parseInt(stringValue.slice(0, valueLength - 1));
    return intValue;
};

/**
 * Returns query for specified Control Center app
 *
 * @param {string} - app name
 *
 * @returns {object} - query for the requested app button within Control Center
 */
springboard.getCCAppButtonQuery = function getCCAppButtonQuery(appName) {
    var result = {};
    switch (appName) {
    case 'Timer':
        result.buttonQuery = UIAQuery.SpringBoard.TIMER_BUTTON_CC;
        result.bundleID = 'com.apple.mobiletimer';
        break;
    case 'Camera':
        result.buttonQuery = UIAQuery.SpringBoard.CAMERA_BUTTON_CC;
        result.bundleID = 'com.apple.camera';
        break;
    case 'Calculator':
        result.buttonQuery = UIAQuery.SpringBoard.CALCULATOR_BUTTON_CC;
        result.bundleID = 'com.apple.calculator';
        break;
    case 'Alarm':
        result.buttonQuery = UIAQuery.SpringBoard.ALARM_BUTTON_CC;
        result.bundleID = 'com.apple.mobiletimer';
        break;
    case 'Stopwatch':
        result.buttonQuery = UIAQuery.SpringBoard.STOPWATCH_BUTTON_CC;
        result.bundleID = 'com.apple.mobiletimer';
        break;
    case 'Magnifier':
        result.buttonQuery = UIAQuery.SpringBoard.MAGNIFIER_BUTTON_CC;
        result.bundleID = 'com.apple.Magnifier';
        break;
    case 'Tap-to-Radar':
    case 'Tap-To-Radar':
        result.buttonQuery = UIAQuery.SpringBoard.TAPTORADAR_BUTTON_CC;
        result.bundleID = 'com.apple.TapToRadar';
        break;
    case 'Notes':
        result.buttonQuery = UIAQuery.SpringBoard.NOTES_BUTTON_CC;
        result.bundleID = 'com.apple.mobilenotes';
        break;
    case 'Voice Memos':
        result.buttonQuery = UIAQuery.SpringBoard.VOICEMEMOS_BUTTON_CC;
        result.bundleID = 'com.apple.VoiceMemos';
        break;
    case 'Wallet':
        result.buttonQuery = UIAQuery.SpringBoard.WALLET_BUTTON_CC;
        result.bundleID = 'com.apple.Passbook';
        break;
    case 'Guided Access':
        result.buttonQuery = UIAQuery.SpringBoard.GUIDED_ACCESS_BUTTON_CC;
        result.bundleID = 'com.apple.Preferences';
        break;
    default:
        throw new UIAError('"%0" app is requested'.format(appName));
    }
    return result;
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Handlers                                                            */
/*                                                                             */
/*******************************************************************************/

/**
 * Returns a true if an alert was found and handled and false if not
 *
 * @returns {boolean} true if an alert was handled
 */
springboard.standardAlertHandler = (function standardAlertHandler()
{
    var didHandleAlert = false;

    var alertQuery = UIAQuery.alerts()
    var alertInfo = this.inspect(UIAQuery.alerts());
    if (alertInfo) {
        var title = alertInfo.name;
        UIALogger.logDebug("SpringBoard's standard alert handler found an alert with the title '" + title + "'");
        switch (title) {
            case "Apple ID Password":
                this.enterText(alertQuery.andThen(UIAQuery.secureTextFields()), springboard.appleIDPassword);
                this.tap(alertQuery.andThen(UIAQuery.buttons("OK")));
                didHandleAlert = true;
                break;
            case "Password Incorrect":
                if (this.exists("Enter voicemail password")) {
                    UIALogger.logWarning("Device does not have voicemail password set");
                    this.tap(alertQuery.andThen(UIAQuery.buttons("Cancel")));
                    didHandleAlert = true;
                }
                break;
            case "iCloud Backup":
                // assume the settings were intended if we encounter this
                this.tap(alertQuery.andThen(UIAQuery.buttons("OK")));
                didHandleAlert = true;
                break;
            case "Apple ID Verification":
                this.tap(alertQuery.andThen(UIAQuery.buttons("Not Now")));
                didHandleAlert = true;
                break;
            case "Add iCloud Drive to Your Home Screen?":
                this.tap(alertQuery.andThen(UIAQuery.buttons("Not Now")));
                didHandleAlert = true;
                break;
            case "Sign In to iTunes Store":
                this.tap(alertQuery.andThen(UIAQuery.buttons("Cancel")));
                didHandleAlert = true;
                break;
            case "You must enter both your Apple ID and password.":
                this.tap(alertQuery.andThen(UIAQuery.buttons("Cancel")));
                didHandleAlert = true;
                break;
            case "App Installation":
                this.tapIfExists("Install")
                break;
            case "Software Update":
                this.tap(alertQuery.andThen(UIAQuery.buttons().withPredicate('name contains[c] "later"')));
                didHandleAlert = true;
                break;
            case "Unable to Download Item":
                this.tap(alertQuery.andThen(UIAQuery.buttons('Done')));
                didHandleAlert = true;
                break;
            case 'Cellular Data Account':
                this.tap(alertQuery.andThen(UIAQuery.buttons('Later')));
                didHandleAlert = true;
                break;

            // Remove once <rdar://problem/32119492> has been resolved.
            case 'User Disconnected from WiFi':
                this.tap(alertQuery.andThen(UIAQuery.buttons('Dismiss')));
                didHandleAlert = true;
                break;
            case 'Seeing WiFi Problems?':
                this.tap(alertQuery.andThen(UIAQuery.buttons('Dismiss')));
                didHandleAlert = true;
                break;
            // Remove once <rdar://problem/34175189> has been resolved.
            case 'Finish Setting Up iPhone':
            case 'Finish Setting Up iPad':
                this.tap(alertQuery.andThen(UIAQuery.buttons(LocStrings.SpringBoard.NOT_NOW).orElse(UIAQuery.buttons(LocStrings.SpringBoard.NEW_NOT_NOW))));
                didHandleAlert = true;
                break;
        }

        // workaround for <rdar://problem/23187298>
        if (!didHandleAlert && alertInfo.exists(UIAQuery.endsWith("Open a Radar?"))) {
            this.tap(alertQuery.andThen(UIAQuery.buttons('Ignore')));
            didHandleAlert = true;
        }

        /**
         * If alert fails to disappear, take a stackshot and retry
         *
         * @param {string}   name - The name of the alert for logging
         * @param {string}   substring - The substring o look for in the alert title
         * @param {UIAQuery} query - Query for the button to tap to dismiss the alert
         * @param {string}   [error] - Optional error to log if handling is triggered
         */
        var dismissWithRetry = function dismissWithRetry(name, substring, query, error) {
            if (!didHandleAlert && title.contains(substring)) {
                if (typeof error !== 'undefined') {
                    UIALogger.logError(error);
                }
                // FIXME: <rdar://problem/20476611> remove me when fixed!!!
                try {
                    this._dismissAlertWithQuery(alertQuery.andThen(query));
                    didHandleAlert = true;
                } catch (e) {
                    UIALogger.logError('Failed to dismiss alert with query [%0] in Springboard Alert Handler'.format(query));
                }
            }
        }.bind(this);

        // Allow location tracking since that's what most testing will want
        // Retry is workaround for <rdar://problem/22059237>
        dismissWithRetry(
            'Location Alert',
            'to access your location',
            UIAQuery.buttons('Allow Whenever Using the App').orElse(
                UIAQuery.buttons('Always Allow').orElse(
                    UIAQuery.buttons('Allow').orElse(
                        UIAQuery.buttons('Always')
                    )
                )
            )
        );

        // Just try to get rid of this one
        // Retry is workaround for <rdar://problem/22189795>
        dismissWithRetry(
            'Storage Alert',
            'Storage Almost Full',
            UIAQuery.buttons('Done'),
            'Storage Almost Full - tests may fail unexpectedly when device is running with low storage'
        );

        if (!didHandleAlert && title.contains("Turn On Location Services")) {
            // Don't want to go to settings app
            this.tap(alertQuery.andThen(UIAQuery.buttons("Cancel")));
            didHandleAlert = true;
        }

        if (!didHandleAlert && target.mobileGestaltQuery('green-tea') && title.startsWith("Allow ") && title.endsWith("to use wireless data?")) {
            // Allow apps to use WLAN and cellular data
            this.tap(alertQuery.andThen(UIAQuery.buttons("WLAN & Cellular")));
            didHandleAlert = true;
        }

        // voicemail alerts
        if (!didHandleAlert
            && this.exists(alertQuery.andThen('Voicemail'))
            && this.exists(alertQuery.andThen(UIAQuery.buttons('Listen')))) {
                this.tap(alertQuery.andThen(UIAQuery.buttons('Close')));
                didHandleAlert = true;
        }

        if (!didHandleAlert) {
            // we should always avoid launching Settings unless the script is expecting that
            // if there is button named 'Settings' and a 'Cancel' or 'OK' button, then tap 'Cancel' or 'OK'
            var buttonsInfo = this.inspectAll(UIAQuery.alerts().andThen(UIAQuery.buttons()));
            if (buttonsInfo instanceof Array) {
                var isSettingsButton = buttonsInfo.map( function(info) {return info.name}).contains("Settings");
                if (isSettingsButton) {
                    didHandleAlert = this.tapIfExists(alertQuery.andThen(UIAQuery.buttons('OK').orElse(UIAQuery.buttons('Cancel'))));
                }
            }
        }
    }
    return didHandleAlert;
}).bind(springboard);

/**
 * Push And Handle Enterprise Apps Installation Alert
 * @param {string[]} [args.urls=[]] - array of URLs
 * @returns {None} throws error if alert creationg/handling failed
 */
springboard.appInstallationAlertHandler = function appInstallationAlertHandler(urls)
{
    // wait timeout (add a little cushion)
    var timeout = 100;
    var installAlertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('would like to install'));
    try {
        for(var index = 0; index < urls.length; ++index) {
            UIALogger.logMessage("URL: '%0'".format(urls[index]));
            var launchAppArgs = ["-url", urls[index]];

            // Create waiter
            var waiter = UIAWaiter.withPredicate(
                             'ViewDidAppear',
                              'controllerClass == "UIAlertController"'
                         );

            springboard.handlingAlertsInline(installAlertQuery, function() {
                // Trigger alert (also the waiter's event trigger)
                performTask("/usr/local/bin/LaunchApp", launchAppArgs);

                // Event waiting
                if (!waiter.wait(timeout)) {
                     throw new UIAError("Something went wrong. Event did not appear.");
                }

                //handle alert
                springboard.tap("Install");
            });
        }
    } catch (e) {
        UIALogger.logMessage("Exception while running LaunchApp command")
        throw e;
    return;
    }
}

/**
 * Purchase an app in spotilight.
 * @param {string}   appleIDPassword - appleIDPassword
 * @returns {None}
 */
springboard.purchaseAppInSpotlight = function purchaseAppInSpotlight(appleIDPassword) {
    var iTunesPasswordAlert = UIAQuery.alerts().andThen(UIAQuery.contains('Sign In to iTunes Store'));
    var purchaseButton = UIAQuery.buttons('PurchaseButton');
    var waiter = UIAWaiter.waiter('Alert');

    var iTunesSignInHandler = function() {
        var app = target.activeApp();
        var password = UIAQuery.secureTextFields();
        if (app.exists(iTunesPasswordAlert)) {
            app.enterText(password, appleIDPassword);
            app.tap('OK');
            return true;
        }
        else {
            return false;
        }
    };

    if ((!this.waitUntilPresent(purchaseButton.withPredicate('label == "Download" OR label == "GET"'))) ) {
        throw new UIAError('Purchase button did not appear.');
    }

    this.tap(purchaseButton.isVisible());

    this.withAlertHandler(iTunesSignInHandler, function() {
        // Trigger alert (also the waiter's event trigger)
        if (this.exists(purchaseButton.withPredicate('label == "INSTALL"'))) {
            UIALogger.logMessage('Tapping INSTALL BUTTON.');
            this.tap(UIAQuery.buttons('PurchaseButton').isVisible());
            waiter.wait(5);
        }
    });
    return;
}


/**
 * Purchase an app in spotilight.
 * @param {string}   passcode - Complex passcode to honor policies
 * @returns {None}
 */
springboard.handlePasscodeRequirementAlert = function handlePasscodeRequirementAlert(passcode) {
    var passcodeRequirementAlertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('Passcode Requirement'));
    var newPasscodeAlertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('New passcode'));
    var reEnterPasscodeAlertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('Re-enter your new passcode'));
    var continueButton = UIAQuery.buttons('Continue');
    var saveButton = UIAQuery.buttons('Save');

    // Get an app instance
    var app = target.activeApp();
    app.handlingAlertsInline(passcodeRequirementAlertQuery, function() {
        // Trigger first alert
        app.tap(continueButton);
        app.handlingAlertsInline(newPasscodeAlertQuery, function() {
            this.enterText(UIAQuery.secureTextFields().withPredicate('name == "Password"'), passcode);
            this.tap(continueButton);
            app.handlingAlertsInline(reEnterPasscodeAlertQuery, function() {
                this.enterText(UIAQuery.secureTextFields().withPredicate('name == "Password"'), passcode);
                this.tap(saveButton);
            });
        });
    });
    return;
}
