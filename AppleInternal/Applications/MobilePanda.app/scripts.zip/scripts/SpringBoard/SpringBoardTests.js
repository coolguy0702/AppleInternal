
load('UIATesting.js');
load('SpringBoard.js');
load('SpotlightTests.js');
load('SpringBoard+InCallServices.js');
load('UIAUtility.js');

UIAUtilities.assert(typeof SpringBoardTests === 'undefined', 'SpringBoardTests has already been defined.')

/** @namespace */

SpringBoardTests = {

    /**
     * Get to SpringBoard. Tap the target app icon. Wait 10 seconds to verify that the app launched and remained active.
     *
     * @param {object} args Test arguments
     * @param {array}  [args.apps=["com.apple.Preferences"]] - array of the bundle ids for the apps to launch (use 'all' to launch all)
     * @param {object} [args.launchOptions={"deactivate": true}] - a dictionary object containing options to be passed into UIAApp.launch
     *  (see [UIAApp.launch]{@link UIAApp#launch} for options that can be passed through through launchOptions)
     * @param {bool} [args.verifyUsingSwitcher=false] - if true close and reopen each app using the switcher
     * @param {bool} [args.quit=false] - if true close the app after verifying launch
     * @param {object} [args.quitOptions={}] - a dictionary object containing options to be passed into UIAApp.quit
     */
    launchApps: function launchApps(args)
    {
        var args = UIAUtilities.defaults(args, {
            apps: ["com.apple.Preferences"],
            launchOptions: {deactivate: true},
            verifyUsingSwitcher: false,
            quit: false,
            quitOptions: {}
        });

        // Limit the number of children we retrieve in case we're looking at iTunes or App Store
        // <rdar://problem/19736144> UIA2: kAXErrorCannotComplete when taking snapshot of iTunes or App Store apps
        if (typeof target.defaultSnapshotBreadth !== 'undefined') {
            // We need to retrieve at least as many children as there are app icons on SpringBoard
            var breadth = target.defaultSnapshotBreadth = target.applicationDisplayIdentifiers().length * 2;
            UIALogger.logMessage("Overriding default snapshot breadth to %0".format(breadth));
        }

        UIAUtilities.assert(
            target.activeApps()[0].name() !== 'Setup',
            'Failed to launch app(s) - still in SetupBuddy.', {
                identifier: 'Errors launching apps - still in SetupBuddy',
            }
        );

        var apps = args.apps;
        if (!(apps instanceof Array)) {
            if ((typeof apps == 'string') && (apps.match(/all/i))) {
                // special keyword case for 'all' will include all apps
                apps = target.applicationDisplayIdentifiers();
            } else {
                apps = [apps];
            }
        }

        UIALogger.logDebug(["\nApp(s):"].concat(apps).join("\n    "));

        // make a copy of the options with usingSwitcher enabled if we need to validate using switcher
        var optionsUsingSwitcher;
        if (args.verifyUsingSwitcher) {
            optionsUsingSwitcher = args.launchOptions.override(args.launchOptions, {usingSwitcher:true});
        }

        var failedApps = [];    // keep an array of the app bundle ids that fail for logging purposes
        var errors = [];    // keep an array of the errors that are thrown for logging purposes
        for (var index = 0; index < apps.length; index++) {
            try {
                var bundleID = apps[index];
                if (typeof bundleID == 'string') {
                    var app = target.appWithBundleID(bundleID);
                }

                // workaround for <rdar://problem/22134658>; remove when fixed
                if (args.launchOptions.deactivate) {
                    app.deactivate();
                }

                app.launch(args.launchOptions);
                UIALogger.logMessage("Waiting for 10 seconds");
                target.delay(10);
                var result = app.isRunning(); // double check the app is still active.
                if (!result) {
                    // <rdar://problem/19565194> [Monarch] 13A163: Fitness app does not appear on N51
                    if (app.bundleID() === 'com.apple.Fitness') {
                        UIALogger.logMessage("Failed to launch Fitness via SpringBoard. Calling LaunchApp now...");
                        target.performTask("/usr/local/bin/LaunchApp",['com.apple.Fitness']);
                        result = target.activeApps()[0].bundleID() === 'com.apple.Fitness';

                    }
                    if (!result) {
                        UIALogger.logMessage("Failed to launch " + app.name() + " Frontmost app is " + target.activeApps()[0].name());
                        failedApps.push(app.bundleID());
                    }
                } else {
                    // relaunch the application using the app switcher for verification
                    if (args.verifyUsingSwitcher) {
                        app.deactivate();
                        app.launch(optionsUsingSwitcher);
                    }

                    if (args.quit) {
                        app.quit(args.quitOptions);
                    }
                }
            } catch (error) {
                UIALogger.logError(error);
                failedApps.push(app.bundleID());
                errors.push(error);
            }
        }

        if (errors.length) {
            // Rethrow the first error we raised
            throw errors[0];
        } else if (failedApps.length == 1) {
            var message = 'Error launching app: %0'.format(failedApps[0]);
            throw new UIAError(message, {identifier: message});
        } else if (failedApps.length > 1) {
            var message = [
                'Errors encountered launching the following app(s):'
            ].concat(failedApps).join('\n    ');

            throw new UIAError(message, {identifier: 'Errors launching apps'});
        }
    },

    /**
     * Quit one or more apps
     *
     * @param {object} args Test arguments
     * @param {array}  [args.apps=["com.apple.Preferences"]] - array of bundle ids or UIAApp objects to launch (use 'all' to launch all)
     * @param {object} [args.launchOptions={"quit":true}] - a dictionary object containing options to be passed into UIAApp.launch
     *  (see [UIAApp.launch]{@link UIAApp#launch} for options that can be passed through through launchOptions)
     * @param {object} [args.quitOptions={}] - a dictionary object containing options to be passed into UIAApp.quit
     *  (see [UIAApp.quit]{@link UIAApp#quit} for options that can be passed through through quitOptions)
     */
    quitApps: function quitApps(args)
    {
        var args = UIAUtilities.defaults(args, {
            apps: ["com.apple.Preferences"],
            launchOptions: {},
            quit: true,
            quitOptions: {}
        });

        SpringBoardTests.launchApps.call(this, args);  // wrapper around launchApps with different defaults
    },

    /**
     * Delete an app. Throws if no app is specified.
     *
     * @param {object} args Test arguments
     * @param {string} [args.app=null] - a bundle id or UIAApp object to delete
     */
    deleteApp: function deleteApp(args)
    {
        var args = UIAUtilities.defaults(args, {
            app: null,
        });

        if (!args.app) {
            throw new UIAError('No app specified, not deleting an app', {identifier: 'No app specified to delete'});
        }

        springboard.getToFirstIconPage();
        attempt = 0;
        while (!springboard.exists(UIAQuery.icons(args.app).isVisible()) && attempt < 10) {
            UIALogger.logMessage('Did not find %0 after attempt %1'.format(args.app, attempt));
            springboard.swipeFromRightEdge(UIAQuery.application());
            attempt = attempt + 1;
        }

        springboard.touchAndHold(UIAQuery.icons(args.app), 3);
        if (!springboard.exists(UIAQuery.icons(args.app).andThen(UIAQuery.buttons().contains('Delete')))) {
            throw new UIAError("App [%0] doesn't have a 'Delete' button--likely not a deletable app!".format(app), {identifier: 'Tried to delete an un-deletable app'});
        }

        UIALogger.logMessage('Deleting app now');
        springboard.handlingAlertsInline(UIAQuery.alerts().contains('Delete'), function() {
            springboard.tap(UIAQuery.icons(args.app).andThen(UIAQuery.buttons().contains('Delete')));
            springboard.tap(UIAQuery.buttons('Delete'));
        });
        target.delay(1);
        target.clickMenu();
    },

    /**
     * Perform a spotlight search
     *
     * @param {object} args Test arguments
     * @param {string} [args.searchString="Settings"] - the search string to enter
     * @param {object} [args.resultQuery=null] - query on something displayed as a result of the search
     * @param {bool}   [args.tapResult=false] - if true tap the result
     * @param {object} [args.appToExpect=null] - the app to expect after tapping on the result
     * @param {object} [args.searchOptions=null] - a dictionary object containing options to be passed into UIAApp.search
     *  (see [UIAApp.search]{@link UIAApp#search} for more details on options that can be passed through searchOptions)
     */
    search: function search(args) {
        var args = UIAUtilities.defaults(args, {
            searchString: 'Settings',
            resultQuery: null,
            tapResult: true,
            appToExpect: 'com.apple.Preferences',
            searchOptions: null
        });

        UIALogger.logMessage('SpringBoard searching has been deprecated. Please use "SpotlightTests" instead.'+
                             ' Calling SpotlightTests.search with the given options...');

        SpotlightTests.search(args)
    },

    /**
     * Perform a spotlight search and scroll the results
     * @param {object} args Test arguments
     * @param {string} [args.searchString="Settings"] - the search string to enter
     * @param {object} [args.resultQuery=null] - query on something displayed as a result of the search
     * @param {bool}   [args.tapResult=false] - if true tap the result
     * @param {object} [args.appToExpect=null] - the app to expect after tapping on the result
     * @param {object} [args.searchOptions=null] - a dictionary object containing options to be passed into UIAApp.search
     *  (see [UIAApp.search]{@link UIAApp#search} for more details on options that can be passed through searchOptions)
     */
    searchAndScroll: function searchAndScroll(args) {
        SpringBoardTests.search(args);
        springboard.scrollSpotlightView();
    }, 

    /**
     * Launch an app as a side app
     *
     * @param {object} args Test arguments
     * @param {string}  [args.sideApp=null] - bundleID of the side app to use
     * @param {string} [args.initialApp=null] - bundleID of the iniital app to use for testing.  This would be launched first.
     * @param {bool} [args.splitScreen=false] - set to true if split screen will be used.  Otherwise, only the side app will be frontmost.
     * @param {bool} [args.prelaunchSideApp=false] - indicates that the app to be used as the side app (if it exists) will be launched before the test begins
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     */
    launchSideApp: function launchSideApp(args)
    {
        var args = UIAUtilities.defaults(args, {
            sideApp: null,
            initialApp: null,
            splitScreen: false,
            prelaunchSideApp: false,
            deviceOrientation: null
        });

        var options = new Object();
        if (typeof args.sideApp !== 'undefined' && args.sideApp) {
            options.bundleID = args.sideApp;
        }
        if (typeof args.splitScreen !== 'undefined') {
            options.splitScreen = args.splitScreen;
        }

        // Launch the side app first to make sure it's available in the app switcher when we need it.
        if (args.prelaunchSideApp && (typeof options.bundleID !== 'undefined')) {
            var app = target.appWithBundleID(options.bundleID);
            UIALogger.logMessage("Launching the App '" + app.name() + "' in preparation for it being the side app.");
            app.launch();
        }

        // Launch the initial app to make sure an app is up when we launch the side app.
        if (typeof args.initialApp !== 'undefined' && args.initialApp) {
            var app = target.appWithBundleID(args.initialApp);
            UIALogger.logMessage("Launching the App '" + app.name() + "' as initial app.");
            app.launch();
        }

        springboard.getToSideApp(options);

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Resize side app -- assumes the there's an active side app or split screen
     *
     * @param {object} args Test arguments
     * @param {number} [args.dragToXValue=0.5] - a number from 0-1 indicating where on the screen to resize to.
     * @param {string}  [args.expectedAppPercent=null] - the approximate percentage of the screen that the first app should take up (between 0-1)
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     * @eligibleResource NOT hardwareModel CONTAINS[c] 'J71' AND NOT hardwareModel CONTAINS[c] 'J72' AND NOT hardwareModel CONTAINS[c] 'J73' AND NOT hardwareModel CONTAINS[c] 'J85' AND NOT hardwareModel CONTAINS[c] 'J86' AND NOT hardwareModel CONTAINS[c] 'J87'
     */
    resizeSideApp: function resizeSideApp(args)
    {
        var args = UIAUtilities.defaults(args, {
            dragToXValue: 0.5,
            expectedAppPercent: null,
            deviceOrientation: null,
        });

        var options = new Object();
        if (typeof args.expectedAppPercent !== 'undefined' && args.expectedAppPercent) {
            options.expectedAppPercent = args.expectedAppPercent;
        }

        springboard.resizeSideApp(args.dragToXValue, options);

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Dismiss the side app if one or more apps are up.
     *
     * @param {object} args Test arguments
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     */
    dismissSideApp: function dismissSideApp(args)
    {
        var args = UIAUtilities.defaults(args, {
            deviceOrientation: null,
        });

        springboard.dismissSideApp();

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Get to the side app switcher.  A side app should already be present (i.e. launch side app should be used before this)
     *
     * @param {object} args Test arguments
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     */
    displaySideAppSwitcher: function displaySideAppSwitcher(args)
    {
        var args = UIAUtilities.defaults(args, {
            deviceOrientation: null,
        });

        springboard.displaySideAppSwitcher();

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },


    /**
     * Activate the split screen -- assumes the there's an active side app
     *
     * @param {object} args Test arguments
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     * @eligibleResource NOT hardwareModel CONTAINS[c] 'J71' AND NOT hardwareModel CONTAINS[c] 'J72' AND NOT hardwareModel CONTAINS[c] 'J73' AND NOT hardwareModel CONTAINS[c] 'J85' AND NOT hardwareModel CONTAINS[c] 'J86' AND NOT hardwareModel CONTAINS[c] 'J87'
     */
    activateSplitScreen: function activateSplitScreen(args)
    {
        var args = UIAUtilities.defaults(args, {
            deviceOrientation: null,
        });

        springboard.activateSplitScreenFromActiveSideApp();

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Deactivate the split screen -- assumes the there's an active split side screen
     *
     * @param {object} args Test arguments
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     * @param {bool}  [args.checkForInitialSplitScreen=false] - orientation to set the device to.
     * @eligibleResource NOT hardwareModel CONTAINS[c] 'J71' AND NOT hardwareModel CONTAINS[c] 'J72' AND NOT hardwareModel CONTAINS[c] 'J73' AND NOT hardwareModel CONTAINS[c] 'J85' AND NOT hardwareModel CONTAINS[c] 'J86' AND NOT hardwareModel CONTAINS[c] 'J87'
     */
    deactivateSplitScreen: function deactivateSplitScreen(args)
    {
        var args = UIAUtilities.defaults(args, {
            deviceOrientation: null,
        });

        if (typeof args.checkForInitialSplitScreen !== 'undefined' && args.checkForInitialSplitScreen) {
            if (!springboard.isInSplitScreenMode()) {
                throw new UIAError("Not running test--device not initially in Split Screen Mode", {identifier: "Device not initially in split screen mode"});
            }
        }

        springboard.deactivateSplitScreen();

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Verifies Medusa Fullscreen Behavior -- assumes there's been a side app already launched/pinned
     *
     * @param {object} args Test arguments
     * @param {string} [args.app="com.apple.Preferences"] - bundleID of the app to launch.  This could be the side app or an app that is not sticky
     * @param {bool}  [args.checkForInitialSplitScreen=false] - if this is set to true, fails the test if the split screen is not already up.
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     * @eligibleResource NOT hardwareModel CONTAINS[c] 'J71' AND NOT hardwareModel CONTAINS[c] 'J72' AND NOT hardwareModel CONTAINS[c] 'J73' AND NOT hardwareModel CONTAINS[c] 'J85' AND NOT hardwareModel CONTAINS[c] 'J86' AND NOT hardwareModel CONTAINS[c] 'J87'
     */
    verifyMedusaFullScreenBehavior : function verifyMedusaFullScreenBehavior(args)
    {
        var args = UIAUtilities.defaults(args, {
            app: "com.apple.Preferences",
            deviceOrientation: null,
            checkForInitialSplitScreen: false,
        });

        if (typeof args.checkForInitialSplitScreen !== 'undefined' && args.checkForInitialSplitScreen) {
            if (!springboard.isInSplitScreenMode()) {
                throw new UIAError("Not running test--device not initially in Split Screen Mode", {identifier: "Device not initially in split screen mode"});
            }
        }

        // Launch the app
        app = target.appWithBundleID(args.app);
        if ((target.activeApp() !== target.systemApp()) && (!springboard.isInSideAppView())) {
            UIALogger.logMessage("Clicking the menu button to launch SpringBoard.");
            var stateChangedEvent = UIAWaiter.waiter('PidStatusChanged');
            target.clickMenu();
            if (!stateChangedEvent.wait(3)) {
                UIALogger.logWarning("Never got the 'PidStatusChanged' event after clicking the menu button.  This may indicate an error.");
            }
        }

        UIALogger.logMessage("Launching the App '" + app.name() + "' and checking for full screen mode.");
        app.launch();

        // Check for side app view
        UIAUtilities.assert(
            !springboard.isInSideAppView(),
            "The app is not in full screen mode--there is a side app onscreen",
            {identifier: "The app is not in full screen mode--there is a side app onscreen"}
        );

        // Check for split screen view
        UIAUtilities.assert(
            !springboard.isInSplitScreenMode(),
            "The app is not in full screen mode--there is a split screen up",
            {identifier: "The app is not in full screen mode--there is a split screen up"}
        );

        // Make sure the right app is active
        UIAUtilities.assert(
            (app.name() === target.activeApp().name()),
            "Expected %0 to be up, but instead %1 is active".format(app.name(), target.activeApp().name()),
            {identifier: "Expected app is not onscreen."}
        );

        // Check to make sure the app is the right size
        UIALogger.logDebug("Checking the app width and height.");
        var appWidth = target.activeApps()[0].inspect("Application").rect.width;
        var appHeight = target.activeApps()[0].inspect("Application").rect.height;
        var mainScreenWidth =  target.mainScreen().rect().width;
        var mainScreenHeight =  target.mainScreen().rect().height;
        UIAUtilities.assert(
            (mainScreenWidth - 1 < appWidth) && (appWidth < mainScreenWidth + 1),
            "Expected the app width to be around %0, but instead it's %1".format(mainScreenWidth, appWidth),
            {identifier: "App width is not as expected"}
        )
        UIAUtilities.assert(
            (mainScreenHeight - 1 < appHeight) && (appHeight < mainScreenHeight + 1),
            "Expected the app height to be around %0, but instead it's %1".format(mainScreenHeight, appHeight),
            {identifier: "App height is not as expected"}
        )

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Verifies that Pinned Apps are Sticky -- assumes there's been a side app already launched/pinned
     *
     * @param {object} args Test arguments
     * @param {string} [args.app="com.apple.mobilesafari"] - bundleID of the app to launch.  This should be an app that is sticky.
     * @param {bool}  [args.checkForInitialSplitScreen=false] - if this is set to true, fails the test if the split screen is not already up.
     * @param {string}  [args.expectedAppPercent=null] - the approximate percentage of the screen that the first app should take up (between 0-1)
     * @param {number} [args.deviceOrientation=null] - expected orientation of the device at the end of the test (use the ptest key desiredOrientation to set it)
     * @eligibleResource NOT hardwareModel CONTAINS[c] 'J71' AND NOT hardwareModel CONTAINS[c] 'J72' AND NOT hardwareModel CONTAINS[c] 'J73' AND NOT hardwareModel CONTAINS[c] 'J85' AND NOT hardwareModel CONTAINS[c] 'J86' AND NOT hardwareModel CONTAINS[c] 'J87'
     */
    verifyStickyPinnedApp : function verifyStickyPinnedApp(args)
    {
        var args = UIAUtilities.defaults(args, {
            app: "com.apple.mobilesafari",
            deviceOrientation: null,
            expectedAppPercent: null,
            checkForInitialSplitScreen: false,
        });

        if (typeof args.checkForInitialSplitScreen !== 'undefined' && args.checkForInitialSplitScreen) {
            if (!springboard.isInSplitScreenMode()) {
                throw new UIAError("Not running test--device not initially in Split Screen Mode", {identifier: "Device not initially in split screen mode"});
            }
        }

        // Launch the app
        app = target.appWithBundleID(args.app);
        if ((target.activeApp() !== target.systemApp()) && (!springboard.isInSideAppView())) {
            UIALogger.logMessage("Clicking the menu button to launch SpringBoard.");
            var stateChangedEvent = UIAWaiter.waiter('PidStatusChanged');
            target.clickMenu();
            if (!stateChangedEvent.wait(3)) {
                UIALogger.logWarning("Never got the 'PidStatusChanged' event after clicking the menu button.  This may indicate an error.");
            }
        }
        UIALogger.logMessage("Launching the App '" + app.name() + "' and checking for full screen mode.");
        app.launch();

        // Check for split screen view
        UIAUtilities.assert(
            springboard.isInSplitScreenMode(),
            "The device is not in split screen mode",
            {identifier: "The device is not in split screen mode"}
        );
        UIALogger.logMessage("Verified that the device is in split screen mode.");

        // Make sure the right app is active
        UIAUtilities.assert(
            (app.name() === target.activeApp().name()),
            "Expected %0 to be up, but instead %1 is active".format(app.name(), target.activeApp().name()),
            {identifier: "Expected app is not onscreen."}
        );
        UIALogger.logMessage("Verified that %0 is active.".format(app.name()));

        // Check to make sure the app is the right size
        UIALogger.logDebug("Checking the app width and height.");

        if (args.expectedAppPercent) {
            var appWidth = parseInt(Number(target.activeApps()[0].inspect("Application").rect.width));
            var mainScreenWidth =  parseInt(Number(target.mainScreen().rect().width));
            var appWidthPercent = appWidth/mainScreenWidth;
            var expectedAppPercent = Number(args.expectedAppPercent);
            if ((expectedAppPercent - .1 < appWidthPercent) && (appWidthPercent < (expectedAppPercent + .1))) {
                UIALogger.logMessage("App Percent is correct--expected %0, got %1".format(expectedAppPercent, appWidthPercent));
            }
            else {
                throw new UIAError("App Percent is not as expected--expected %0, got %1".format(expectedAppPercent, appWidthPercent), {identifier: "App percent is not as expected"});
            }
        }

        var appHeight = target.activeApps()[0].inspect("Application").rect.height;
        var mainScreenHeight =  target.mainScreen().rect().height;
        UIAUtilities.assert(
            (mainScreenHeight - 1 < appHeight) && (appHeight < mainScreenHeight + 1),
            "Expected the app height to be around %0, but instead it's %1".format(mainScreenHeight, appHeight),
            {identifier: "App height is not as expected"}
        )

        // check the device orientation
        if (typeof args.deviceOrientation !== 'undefined' && args.deviceOrientation) {
            UIALogger.logMessage("Checking device orientation.");
            UIAUtilities.assert(
                springboard.interfaceOrientation() === args.deviceOrientation,
                "Expected an orientation of %0, but actual orientation is %1".format(args.deviceOrientation, springboard.interfaceOrientation()),
                {identifier:"final orientation is incorrect"}
            );
        }

        return UIATestResult.PASS;
    },

    /**
     * Navigates through the notificaiton center UI
     *
     * @param {object} args Test arguments
     * @eligibleResource not hardwareModel contains 'J99'
     */
    navigateNotificationCenter: function navigateNotificationCenter(testDate)
    {
        springboard.launch();
        if (!springboard.getToNotifications()) {
            throw new UIAError("Did not get to notification center");
        }

        target.clickMenu();
    },

    /**
     * Toggles control center options
     *
     * @param {object} args Test arguments
     * @param {array} [args.buttons=["Wi-Fi", "Bluetooth", "Do Not Disturb", "Lock orientation", "Airplane Mode"]] - Buttons to toggle
     * @param {bool} [args.roundtrip=true] - Toggle from first state to second state and back if true, otherwise just toggle to next state
     */
    toggleControlCenterOptions: function toggleControlCenterOptions(args) {
        args = UIAUtilities.defaults(args, {
            buttons: [
                "Wi-Fi",
                "Bluetooth",
                "Do Not Disturb",
                "Lock orientation",
                "Airplane Mode",
            ],
            roundtrip: true,
        });

        function getButtonQuery(button) {
            switch(button) {
                case 'Wi-Fi':
                    return UIAQuery.query(button).orElse(UIAQuery.query('WLAN'));
                default:
                    return UIAQuery.query(button);
            }
        }

        var toggleControlCenterButton = function toggleControlCenterButton(buttonName) {
            var success = false;
            var buttonQuery = getButtonQuery(buttonName);

            UIALogger.logDebug("Toggling '%0' to next state".format(buttonName));
            var value = springboard.inspectElementKey(buttonQuery, 'value');

            // Toggle to next state
            springboard.tap(buttonQuery);  // timeout: rdar://problem/20123215
            success = (springboard.waitUntilPresent(buttonQuery.withPredicate("value != '%0'".format(value)), 6));

            if (args.roundtrip) {
                // Toggle back to previous state
                UIALogger.logDebug("Toggling '%0' back to previous state".format(buttonName));
                springboard.tap(buttonQuery); // timeout: rdar://problem/20123215
                success &= (springboard.waitUntilPresent(buttonQuery.withPredicate("value == '%0'".format(value)), 6));
            }

            return success;
        }

        if (!springboard.getToControlCenter()) {
            throw new UIAError('Failed to navigate to Control Center');
        }
        for (var index in args.buttons) {
            UIAUtilities.assert(
                toggleControlCenterButton(args.buttons[index]),
                "Failed to toggle '%0'".format(args.buttons[index])
            );
        }
    },

    /**
     * Spotlite version of the Parsec validation test. Appends results to the parsec.json log.
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchStrings=["president", "vaccine", "cthulhu", "president wiki", "vaccine wiki"]] - an array of search strings
     * @param {string} [args.expectedDomain="WIKIPEDIA"] - the result header to look for
     * @param {array} [args.expectedDomainText=""] - the expected domain name if different from the Parsec.Domain category (e.g. Lyra)
     * @param {array} [args.expectedStrings=[]] - string to validate after tapping parsec result
     * @param {int} [args.retries=0] - the number of times to retry the searches before giving up
     * @param {array} [args.qualifiers=[]] - an array of search qualifiers for the search strings
     * @param {int} [args.delay=0.3] - the interkey delay to use when typing in a search string
     * @param {string} [args.ParsecApiHost="production"] - the parsec environment to test against (carry, test, production, etc)
     * @param {bool} [args.lookupMovies=false] - use a 'showtimes' search to define searchStrings for MOVIE domain
     * @param {string} [args.networkType="wifi"] - 'wifi' or 'cell'
     * @param {bool} [args.validatePunchout=true] - whether to tap the parsec result and validate app or card that opens
     * @param {array} [args.expectedSubDomain=""] - the expected sub domain behavior for a given result; e.g. the
     *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
     *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
     *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
     * @param {array} [args.expectedDomainResults=[]] - array of results to check for under the expected domain
     * @param {bool} [args.localSearch=false] - indicates whether this is a local or parsec search
     * @param {bool} [args.topHit=true] - indicates whether to check for Top Hits domain if expected domain is not found
     * @param {boolean}  [args.requiresEnterKey=true] - Spotlight requires enter to continue search with typed text.
     *                                                     - set to false if want to manually trigger the search via Search btn, or suggestion
     *                                                     - set to true to automatically press enter
     */
    validateParsecDomain: function validateParsecDomain(args)
    {
        var args = UIAUtilities.defaults(args, {
                searchStrings: ["president", "vaccine", "cthulhu", "president wiki", "vaccine wiki"],
                expectedDomain: Parsec.Domain.WIKI,
                expectedDomainText: "",
                expectedStrings: [],
                retries: 0,
                qualifiers: [],
                delay:0.3,
                ParsecApiHost:'production',
                lookupMovies: false,
                networkType: 'wifi',
                validatePunchout: true,
                expectedSubDomain:"",
                expectedDomainResults: [],
                localSearch: false,
                topHit:true,
                requiresEnterKey: true,
        });

        springboard.launch();
        var data = new Object();
        data.client = 'Spotlight';
        data.searchDomain = args.expectedDomain;
        data.model = target.model();

        try {
            springboard.validateParsecDomain(args.searchStrings, args.expectedDomain.toUpperCase(), args)
            data.result = 'Pass';
        } catch (e) {
            data.result = 'Fail';
            throw e;
        } finally {
            data.client = 'Spotlight';
            data.searchDomain = args.expectedDomain;
            data.model = target.model();
            data.date = Date.now();
            var logFile = '/tmp/parsec/parsec.json';
            var cmd = "echo '" +  JSON.stringify(data) + "' >> " + logFile
            UIALogger.logDebug(JSON.stringify(target.performTask('/bin/mkdir', ['-p', '/tmp/parsec'], 10)));
            UIALogger.logDebug(JSON.stringify(target.performTask('/bin/sh', ['-c', cmd], 10)));
            var catResult = target.performTask('/bin/cat', [logFile]);
            if (catResult.exitCode == 0) {
                UIALogger.logDebug(catResult.stdout);
            } else {
                UIALogger.logDebug(catResult.stderr);
            }
        }

        return UIATestResult.PASS;
    },

    /**
     * Spotlite version of the Parsec reliability test.
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchStrings=["nelson mandela wiki", "hunger games itunes", "coldplay itunes", "chipotle"]] - an array of search strings
     * @param {int} [args.iterations=10] - the number of times to perform the search
     * @param {int} [args.delay=0.3] - the interkey delay to use when typing in a search string
     * @param {string} [args.ParsecApiHost="production"] - the parsec environment to test against (carry, test, production, etc)
     */
    parsecReliabilityTest: function parsecReliabilityTest(args)
    {
        var args = UIAUtilities.defaults(args, {
                searchStrings: ["nelson mandela wiki", "hunger games itunes", "coldplay itunes", "chipotle"],
                iterations: 10,
                delay:0.3,
                ParsecApiHost:'production',
        });

        springboard.launch();
        springboard.parsecTestReliability(args.searchStrings, args);
        return UIATestResult.PASS;

    },

    /**
     * Validates all specified domains using the corresponding search query and saves to a results array of objects
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchData=[{"query":"nelson mandela","domain":"Wikipedia","topHit":true,"domainContents":["nelson mandela"]},{"query":"sfo maps","domain":"Maps"}]]
     *       - an array of search objects
     * @param {bool} [args.cancelSearch=false] - whether to tap the Cancel button after performing/validating a search
     * @param {bool} [args.shouldDumpFeedback=false] - whether to use parsec_tool to dump feedback data after performing a query
     * @param {int} [args.timeout=30] - the max amount of time to wait for a result to display after typing the query
     * @param {bool} [args.shouldEngageResult=false] - whether to tap the first matching Parsec result
     * consisting of the query string and expected domain.
     * @param {bool} [args.shouldEngageResult=false] - whether to tap the first matching Parsec result consisting of the query string and expected domain.
     * @param {boolean}  [args.requiresEnterKey=false] - Spotlight requires enter to continue search with typed text.
     *                                                     - set to false if want to manually trigger the search via Search btn, or suggestion
     *                                                     - set to true to automatically press enter
     */
    validateAllParsecDomains: function validateAllParsecDomains(args) {
        var args = UIAUtilities.defaults(args, {
            searchData: [],
            cancelSearch: false,
            shouldDumpFeedback: false,
            timeout: 30,
            shouldEngageResult: false,
            requiresEnterKey: false,
        });

        results = springboard.validateDomainList(args.searchData, args);
        UIALogger.logTAResults({parsecResults:results[0]});
        UIAUtilities.assert(results[1], 'At least one domain failed.');
    },

    /**
     * Validate that Siri Suggestions, Nearby, and News appear in zero keyword search view
     *
     * @param {object} args Test arguments
     * @param {string} [args.expectedDomains=["SIRI SUGGESTIONS", "NEARBY", "NEWS"]] - the result headers to look for in ZKW
     * @param {array} [args.expectedStrings=[]] - string to validate after tapping parsec result
     * @param {bool} [args.validatePunchout=false] - whether to tap the parsec result and validate app or card that opens
     * @param {array} [args.expectedSubDomains=[]] - the expected sub domain behavior for a given result; e.g. the
     *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
     *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
     *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
     * @param {array} [args.expectedDomainResults=[[", Application"], [", Nearby"], ["cnn.com"]]] - array of array of results to check for under each expected domain
     */
    validateZeroKeywordView: function validateZeroKeywordView(args)
    {
        var args = UIAUtilities.defaults(args, {
                expectedDomains: [Parsec.Domain.SIRI_SUGGEST, Parsec.Domain.NEARBY, Parsec.Domain.NEWS],
                expectedStrings: [],
                validatePunchout: false,
                expectedSubDomain:'',
                expectedDomainResults: [[', Application'], [', Nearby'], ['cnn.com']],
        });

        springboard.getToZeroKeywordSearch();
        springboard.verifyParsecResult("", args.expectedDomains, args);

        return UIATestResult.PASS;
    },

    /**
     * Wait for a call from a specific contact.
     *
     * @targetApps SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {object} [args.contact="{phoneNumber: 411}"] - Dictionary containing acceptable contact information to validate the call
     * @param {string} [args.contact.phoneNumber="411"] - Phone number (e.g. "408-867-5309")
     * @param {string} [args.contact.email = ""]  - Email address, i.e. Apple ID (e.g. "johnnyappleseed@icloud.com")
     * @param {string} [args.contact.name = ""]   - Name, usually resolved by AddressBook Framework (e.g. "Johnny Appleseed")
     * @param {int}      [args.timeout=200]       - Duration to wait for incoming call
     * @param {boolean}  [args.answer=true]       - Should answer the incoming call
     * @param {string}   [args.callState="Phone"] - State that the incoming call should be throws error if not matching
     */
    waitToReceiveCall: function waitToReceiveCall(args) {
        args = UIAUtilities.defaults(args, {
            contact:    {phoneNumber: '411',
                        email: '',
                        name: '',
                        },
            timeout:    200,
            answer:     true,
            callState:  'Phone',
        });

        UIALogger.logDebug('*** SEB *** args: %0'.format(JSON.stringify(args, null, 2)));
        if (!springboard.waitForCallFromContact(args.contact, args.answer, args.callState, args.timeout)) {
            throw new UIAError('Waited to receive call from call and timed out');
        }
    },

    /**
     * End the current call in the call service
     *
     * @targetApps SpringBoard
     * @param {objects} args        - Test Arguments
     */
    endCall: function endCall(args) {
        args = UIAUtilities.defaults(args, {

        });
        springboard.endCall();
    },

    /**
     * Wait And Handle Vpp App Install Alert
     *
     * @targetApps SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {int} [args.waitTime=120] - wait for the InstallApp alerts to appear
     */
    unlockAndHandleAlerts: function unlockAndHandleAlerts(args) {
        args = UIAUtilities.defaults(args, {
                waitTime:    120,
            });

        var timeout = args.waitTime;
        var started = new Date().getTime();
        var elapsed = 0;
        var alertEncountered = false;

        var locked = target.systemApp().lock();
        if ((typeof locked === 'undefined' || locked) && target.isLocked()) {
            target.delay(args.lockTime);
        } else {
            throw new UIAError('Could not lock device');
        }

        var unlocked = target.systemApp().unlock();
        if (typeof unlocked === 'undefined' || unlocked) {
            UIALogger.logPass('Successfully locked and unlocked device');
        } else {
            throw new UIAError('Could not unlock device');
        }

        while (elapsed < timeout) {
            alertEncountered = springboard.standardAlertHandler();
            if (alertEncountered) {
                UIALogger.logMessage("VPP App Install Alert Encountered")
            }
            elapsed = (new Date().getTime() - started) / 1000;
        }
        if(!alertEncountered) {
            UIALogger.logMessage("VPP App Install Alert Never Encountered")
        }
    },

    /**
     * Push And Handle Enterprise Apps Installation Alert
     *
     * @targetApps SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {string[]} [args.urls=[]] - array of URLs
     */
    pushAndHandleEnterpriseAppsAlert: function pushAndHandleEnterpriseAppsAlert(args) {
        var args = UIAUtilities.defaults(args, {
                urls: [],
        });
        springboard.appInstallationAlertHandler(args.urls)
    },

    /**
     * Purchase App in Spotlight
     *
     * @targetApps SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {string} [args.AppleID="PERSISTEDAPPLEID"]                   - AppleID
     * @param {string} [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"]   - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
     * @param {string} [args.resultQuery="Smashy Road"] - query on something displayed as a result of the search
     * @param {string} [args.searchString="Smashy Road"] - the search string to enter
     */
    purchaseAppInSpotlight: function purchaseAppInSpotlight(args) {
        var args = UIAUtilities.defaults(args, {
                username: 'PERSISTEDAPPLEID',
                password: 'PERSISTEDAPPLEIDPASSWORD',
                searchString:'Smashy Road',
                resultQuery:'Smashy Road',
        });
        SpringBoardTests.search(args);
        springboard.purchaseAppInSpotlight(args.AppleIDPassword);
    },

    /**
     * Handle Passcode Requirement Alert
     *
     * @targetApps SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {string} [args.passcode="qa1-23"] - Complex passcode
     */
    handlePasscodeRequirementAlert: function handlePasscodeRequirementAlert(args) {
        var args = UIAUtilities.defaults(args, {
                passcode: 'qa1-23',
        });
        springboard.handlePasscodeRequirementAlert(args.passcode);
    },

    /**
     * Creates a folder by dragging an app on top of another
     * app. Additional apps can then be added to newly created
     * folder.
     *
     * @targetApps SpringBoard
     *
     * @param {string[]}  [args.apps=["Clock", "Reminders"]] - Apps to add to create a folder. Must
     *                          include at least two apps. Name comes from label display in UI for app.
     * @param {object}    [args.options]
     * @param {null|string} [args.options.folderName=null] - Optional name for folder.
     *                               If not set, will use system determined name.
     * @param {boolean} [args.options.verify=true] - Flag, verify folder created and apps inside.
     */
    createFolder: function createFolder(args) {
        var args = UIAUtilities.defaults(args, {
            apps: ['Clock', 'Reminders'],

            // options
            options: {
                folderName: null,
                verify: true,
            }
        });

        springboard.createFolder(args.apps, args.options);
    },

    /**
     * Verify that a widget is enabled or disabled in the Today View
     *
     * @param {string} [args.widget="News"] - Title of widget displayed in Today view
     * @param {boolean} [args.enabled=true] - Flag indicating whether the widget should be enabled.
     */
    verifyWidgetEnabledOrDisabled: function verifyWidgetEnabledOrDisabled(args) {
        var args = UIAUtilities.defaults(args, {
                widget: "News",
                enabled: true,
        });

        UIAUtilities.assertEqual(args.enabled, springboard.isWidgetEnabled(args.widget));
    },

    /**
     * Verify that a widget is or is not listed in the Today View's edit view. The edit view
     * is the view in which widgets can be added and removed.
     *
     * @param {string} [args.widget="News"] - Title of widget displayed in Today view
     * @param {boolean} [args.listed=true] - Flag indicating whether the widget should be listed.
     */
    verifyWidgetListedOrNotListedInEditView: function verifyWidgetListedOrNotListedInEditView(args) {
        var args = UIAUtilities.defaults(args, {
                widget: "News",
                listed: true,
        });

        UIAUtilities.assertEqual(args.listed, springboard.isWidgetVisibleInEditView(args.widget));
    },


    /**
     * Verify that we're able to navigate to Today View
     */
    getToTodayView: function getToTodayView(args) {
        args = UIAUtilities.defaults(args, {});
        springboard.getToWidgets();
    },

    /**
     * Check brightness control in Control Center 
     */
    checkBrightnessControl: function checkBrightnessControl() {
        springboard.getToControlCenter();
        springboard.checkBrightnessControl();
    },

    /**
     * Launch app from Control Center 
     * 
     * @param {object} [args] - Test arguments 
     * @param {string} [args.appName = "Timer"] - App name 
     */
    launchAppsFromControlCenter: function launchAppsFromControlCenter(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Timer', 
        });
        springboard.getToControlCenter();
        springboard.launchAppFromCC(args);
    }, 

    /**
     * Set Airdrop mode in Control Center
     * 
     * @param {object} [args] - Test arguments
     * @param {string} [args.mode = "Everyone"] - AirDrop mode
     */
    setAirdropMode: function setAirdropMode(args) {
        args = UIAUtilities.defaults(args, {
            mode: 'Everyone', 
        });
        springboard.getToControlCenter();
        springboard.setAirdropMode(args);
    },
}
