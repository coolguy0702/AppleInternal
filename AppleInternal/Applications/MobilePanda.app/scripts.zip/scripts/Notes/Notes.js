load('UIAApp.js');
load('UIAApp+Mail.js');
load('UIAApp+Photos.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof notes === 'undefined',
    'notes undefined'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common notes queries */
UIAQuery.Notes = {
    /* Delete button: */
    DELETE_NOTE: UIAQuery.tableViews().andThen(UIAQuery.buttons().contains('Delete note').orElse(UIAQuery.buttons().contains('Delete'))),

    /* Sharing options button: */
    SHARE_NOTE: UIAQuery.contains('Share'),

    /* Mail button when sharing: */
    EMAIL_NOTE: UIAQuery.tableCells('Mail'),

    // auditied for after UI change:
    /* Create a new note: */
    NEW_NOTE_BUTTON:                    UIAQuery.buttons('New note'),

    /* First note in some specified folder */
    TOP_NOTE:                           UIAQuery.tableViews().last().andThen(UIAQuery.tableCells().first()),

    /** Notes in some specified folder */
    NOTES:                              UIAQuery.tableViews().last().andThen(UIAQuery.tableCells()),

    /* Textview of the note. Texxt content is stored inside this element. */
    NOTE_TEXT_CONTENT:                  UIAQuery.textViews().orElse(UIAQuery.textFields('note')),

    /* Attachments brower button */
    ATTACHMENTS_BUTTON:                 UIAQuery.buttons('attachment browser').isVisible(),

    /* Move To button */
    MOVE_TO_BUTTON:                     UIAQuery.buttons().contains('Move To'),

    /* Move To button */
    TRASH_BUTTON:                       UIAQuery.buttons().contains('Trash'),

    /* Delete current note button */
    DELETE_CURRENT_NOTE_BUTTON:         UIAQuery.actionSheets().andThen(UIAQuery.buttons('Delete Note')),

    /* Share Option - Copy */
    SHARE_OPTION_COPY_BUTTON:           UIAQuery.actionSheets().andThen(UIAQuery.tableCells('Copy')),

    /* Photo Library on current note. */
    TAKE_PHOTO_BUTTON:                  UIAQuery.actionSheets().andThen(UIAQuery.buttons().contains('Take Photo')),

    /* Pen tool button */
    PEN_TOOL_BUTTON:                    UIAQuery.buttons('Pen tool'),

    /* Note table cells in search result view: */
    SEARCHED_NOTES:                     UIAQuery.tableViews().andThen(UIAQuery.tableCells()),

    /* Table Views: */
    TABLE_VIEWS: UIAQuery.tableViews(),

    TEXT_OPERATION_BUTTON:              UIAQuery.keyboard().andThen(UIAQuery.buttons("Text operations")),

    /** New Folder Button */
    NEW_FOLDER:                         UIAQuery.buttons('New Folder'),

    LOOKUP_RESULTS_VIEW:                UIAQuery.query("_UIFallbackPresentationWindow").andThen("AXRemoteElement").andThen("UITableViewSectionElement").orElse('No Content Found'),

    /** Splash Screen Upgrade Button **/
    UPGRADE_BUTTON:                     UIAQuery.buttons().contains('Upgrade').isVisible(),

    /** Button to return to Folders view from single folder view */
    FOLDERS_BUTTON:                     UIAQuery.buttons().contains('Folders'),

    /** Progress indicator */
    PROGRESS_INDICATOR:                 UIAQuery.withPredicate('name contains "Syncing notes"').orElse(UIAQuery.withPredicate('behavior == "ActivityIndicator" AND name == "In Progress"')),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Notes */
UIStateDescription.Notes = {
    /** Welcome page */
    WELCOME:                                    'welcome page',

    /**  Folder list of notes. */
    MAIN_FOLDER_LIST:                           'folder list',

    /** Edit folders. */
    MAIN_FOLDER_LIST_EDIT:                      'folder list (edit mode)',

    /** Edit folders. One or more folders selected */
    MAIN_FOLDER_LIST_EDIT_SELECTED:             'folder list (edit mode and folder(s) selected)',

    /** Contents of folder. List of notes. */
    FOLDER_CONTENTS:                            'contents of folder',

    /** Edit mode on the contents of folder. */
    FOLDER_CONTENTS_EDIT:                       'contents of folder (edit mode)',

    /** Edit mode on the contents of folder. One or more notes selected */
    FOLDER_CONTENTS_EDIT_SELECTED:              'contents of folder (edit mode and element(s) selected)',

    /** List of attchments for the folder. */
    ATTACHMENTS_LIST:                           'attachments list',

    /** Edit mode on a note. Same mode for compose. */
    EDIT_NOTE:                                  'compose/edit a note',

    /** Edit mode on a note. Same mode for compose. Delete note prompt. */
    EDIT_NOTE_DELETE:                            'compose/edit a note (delete)',

    /** Edit mode on a note. Same mode for compose. Photo options prompt. */
    EDIT_NOTE_PHOTO_OPTIONS:                     'compose/edit a note (photos options)',

    /** Share note menu. */
    EDIT_NOTE_SHARE_MENU:                        'share menu',

    /** Edit mode on a note. Same mode for compose. Finger write page. */
    EDIT_NOTE_FINGER_STYLO:                     'compose/edit a note (finger stylo)',

    /** Search Mode */
    SEARCH:                                     'search',

    /** Turn on icloud notification (can come up at different times) */
    TURN_ON_ICLOUD:                             'turn on iCloud notification',

    /** Overlay Lookup search results */
    LOOKUP_RESULTS:                             'lookup results overlay',

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 *   @namespace {UIAApp} Notes
 */
var notes = target.appWithBundleID('com.apple.mobilenotes');

/**
 *  Constants for Notes
 */
notes.Constants = {
    NOTES:                                        'Notes',
};

function isHorizontalRegularUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription
 * constants defined in UIAApp and Notes for possible values.
 *
 * TODO: Once notes UI is locked down, we should review.
 * TODO: Add states for 'Aa' and speach
 * TODO: Flush out more of the share menu
 *
 * @returns {string} Description of current UI state from a list of
 *           possible constants contained in UIStateDescription.
 */
notes.getCurrentUIState = function getCurrentUIState() {
    this.launch();

    if (this.exists(UIAQuery.contains('Welcome to Notes').orElse(UIAQuery.contains('Welcome to\nNotes')).orElse(UIAQuery.contains('Upgrade')))) {
        return UIStateDescription.Notes.WELCOME;
    }

    if (this.exists(UIAQuery.Notes.LOOKUP_RESULTS_VIEW)) {
        return UIStateDescription.Notes.LOOKUP_RESULTS;
    }

    // / because someone could name a folder 'Folders'...
    if (this.exists(UIAQuery.navigationBars('Folders').isVisible())
            && this.exists(UIAQuery.Notes.NEW_FOLDER) ) {
        return UIStateDescription.Notes.MAIN_FOLDER_LIST;
    }

    if ( this.exists(UIAQuery.contains('ON MY I'))) {
        if (this.exists(UIAQuery.Notes.TRASH_BUTTON.isEnabled())) {
            return UIStateDescription.Notes.MAIN_FOLDER_LIST_EDIT_SELECTED;
        } else {
            return UIStateDescription.Notes.MAIN_FOLDER_LIST_EDIT;
        }
    }

    if (this.exists(UIAQuery.contains("Turn On iCloud"))){
        return UIStateDescription.Notes.TURN_ON_ICLOUD;
    }

    if (this.exists(UIAQuery.Notes.NEW_NOTE_BUTTON.isEnabled())) {
        return UIStateDescription.Notes.FOLDER_CONTENTS;
    }

    if (this.exists(UIAQuery.Notes.MOVE_TO_BUTTON)) {
        if (this.exists(UIAQuery.Notes.TRASH_BUTTON.isEnabled())) {
            return UIStateDescription.Notes.FOLDER_CONTENTS_EDIT_SELECTED;
        } else {
            return UIStateDescription.Notes.FOLDER_CONTENTS_EDIT;
        }
    }

    if (this.exists(UIAQuery.searchBars().isVisible())
            && this.exists(UIAQuery.searchBars().isVisible().siblings().andThen(UIAQuery.buttons('Cancel').isVisible()))) {
        return UIStateDescription.Notes.SEARCH;
    }

    if (this.exists(UIAQuery.navigationBars('ICNoteEditorView').isVisible())) {
        return UIStateDescription.Notes.EDIT_NOTE;
    }

    if (this.exists(UIAQuery.Notes.DELETE_CURRENT_NOTE_BUTTON)) {
        return UIStateDescription.Notes.EDIT_NOTE_DELETE;
    }

    // TODO: Flush out more of the share menu
    if (this.exists(UIAQuery.Notes.SHARE_OPTION_COPY_BUTTON)) {
        return UIStateDescription.Notes.EDIT_NOTE_SHARE_MENU;
    }

    if (this.exists(UIAQuery.Notes.PEN_TOOL_BUTTON)) {
        return UIStateDescription.Notes.EDIT_NOTE_FINGER_STYLO;
    }

    if (this.exists(UIAQuery.Notes.TAKE_PHOTO_BUTTON)) {
        return UIStateDescription.Notes.EDIT_NOTE_PHOTO_OPTIONS;
    }

    if ( this.exists(UIAQuery.navigationBars('Attachments').isVisible()) ) {
        return UIStateDescription.Notes.ATTACHMENTS_LIST;
    }

    // if we get to here, we have no idea where we are...
    throw new UIAError('Cannot determine state.');
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/**
* Navigation function to get to the main folder list UI from some starting
* state. Any critia for defining a transition from a state to the main
* folder list state should be very exact so we always end up in the main
* folder list state or else throw.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If transition from startin state to main folder list UI has not been
*           defined in this function yet. This means we need to update the
*           this function to detect this state.
*         If we were unable to transition from starting state to
*           MAIN_FOLDER_LIST state.
*/
notes.getToFolderList = function getToFolderList() {
    this.launch();

    var maxDepth = 5;
    UIALogger.logMessage('Navigating to %0 UI'.format(UIStateDescription.Notes.MAIN_FOLDER_LIST));

    for (var i = 0; i < maxDepth; i++) {
        var currentState = this.getCurrentUIState();
        UIALogger.logMessage('Current state: \'%0\''.format(currentState));

        if (currentState === UIStateDescription.Notes.MAIN_FOLDER_LIST) {
            return;
        }

        var waiter = UIAWaiter.waiter('ViewDidAppear');
        switch (currentState) {
            case UIStateDescription.Notes.FOLDER_CONTENTS:
                this.tap(UIAQuery.BACK_NAV_BUTTON);
                break;

            case UIStateDescription.Notes.EDIT_NOTE:
                // if the note list is in search mode, the back button is invisible
                this.tapIfExists(UIAQuery.CANCEL_BUTTON);
                this.tap(UIAQuery.BACK_NAV_BUTTON);
                break;

            case UIStateDescription.Notes.EDIT_NOTE_DELETE:
            case UIStateDescription.Notes.EDIT_NOTE_PHOTO_OPTIONS:
            case UIStateDescription.Notes.EDIT_NOTE_SHARE_MENU:
                this.tapIfExists('Done');
                if (!this.tapIfExists(UIAQuery.CANCEL_BUTTON)) {
                    this.dismissPopover();
                }
                break;

            case UIStateDescription.Notes.ATTACHMENTS_LIST:
            case UIStateDescription.Notes.EDIT_NOTE_FINGER_STYLO:
            case UIStateDescription.Notes.MAIN_FOLDER_LIST_EDIT:
            case UIStateDescription.Notes.MAIN_FOLDER_LIST_EDIT_SELECTED:
            case UIStateDescription.Notes.LOOKUP_RESULTS:
                this.tap('Done');
                break;

            case UIStateDescription.Notes.FOLDER_CONTENTS_EDIT:
            case UIStateDescription.Notes.FOLDER_CONTENTS_EDIT_SELECTED:
            case UIStateDescription.Notes.SEARCH:
                this.tap(UIAQuery.CANCEL_BUTTON);
                break;

            case UIStateDescription.Notes.TURN_ON_ICLOUD:
                this.handlingAlertsInline(UIAQuery.alerts().andThen('Turn On iCloud'), function() {
                        this.tapIfExists('Not Now');
                });
                break;
            case UIStateDescription.Notes.WELCOME:
                if (this.waitUntilPresent(UIAQuery.Notes.UPGRADE_BUTTON.orElse(UIAQuery.CONTINUE_BUTTON), 10)) {
                    this.tapIfExists(UIAQuery.Notes.UPGRADE_BUTTON);
                    this.tapIfExists(UIAQuery.CONTINUE_BUTTON);
                }
                this.handlingAlertsInline(UIAQuery.alerts().andThen('Turn On iCloud'), function() {
                    this.tapIfExists('Not Now');
                });
                break;
            default:
                // we found and new state and need to update
                throw new UIAError('Current UI State unexpected. Update getToFolderList with new state: %0'.format(currentState));
        }
        waiter.wait(2);
    }

    var previousState = currentState;
    currentState = this.getCurrentUIState();

    if (currentState !== UIStateDescription.Notes.MAIN_FOLDER_LIST) {
        throw new UIAError('Could not get to \'%0\' UI from \'%1\' UI'.format(UIStateDescription.Notes.MAIN_FOLDER_LIST, currentState));
    }

}

/**
* Navigation function to get to a folder. If no folder is
* specified, we default to the 'Notes' folder.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*/
notes.getToFolder = function getToFolder(options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
    });

    this.getToFolderList();
    this.tap(UIAQuery.tableCells(options.folder));
    if (this.waitUntilPresent(UIAQuery.Notes.NEW_NOTE_BUTTON)) {
        new UIAError('Failed to get to folder');
    }
}

/**
* Navigation function to get to the top note in a folder. If no folder is
* specified, we default to the 'Notes' folder.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*/
notes.getToTopNoteInFolder = function getToTopNoteInFolder(options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
    });

    this.getToFolder(options);
    this.tap(UIAQuery.Notes.TOP_NOTE);
}

/**
* Navigation function to get a new note page within a folder. If no folder is
* specified, we default to the 'Notes' folder.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*/
notes.getToNewNote = function getToNewNote(options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
        location: 'ON MY I',
    });

    this.getToFolder(options);

    if (target.model() === 'iPad') {
        this.dismissPopover();
    }
    this.tapIfExists(UIAQuery.Notes.NEW_NOTE_BUTTON.isEnabled());
}

/**
 * If any dialogs, popovers, etc are open, we dismiss them so we get to
 * a known state
 *
 * Expected starting states: EDIT_NOTE*
 *
 * @return None
 */
notes.getToDefaultNoteState = function getToDefaultNoteState() {
    this.dismissPopovers();
    var currentState = this.getCurrentUIState();
    switch (currentState) {
        case UIStateDescription.Notes.EDIT_NOTE:
            this.dismissKeyboard();
            break;
        case UIStateDescription.Notes.EDIT_NOTE_PHOTO_OPTIONS:
            this.tapIfExists('Cancel');
            break;
        case UIStateDescription.Notes.EDIT_NOTE_FINGER_STYLO:
            this.tap('Done');
            break;
        default:
    }
}

/**
 * Deprecated. Should be using getToFolderList()
 */
notes.getToTopLevel = function getToTopLevel() {
    if (!this.launch()) throw new UIAError('Could not launch Notes!');

    if ( this.exists(UIAQuery.alerts('Folder Name')) ) {
        this.tapIfExists('Cancel');
        return;
    } else if ( this.exists(UIAQuery.navigationBars('Accounts')) ) {
        this.tapIfExists('Done');
        return;
    } else if ( !this.exists(UIAQuery.navigationBars('Accounts')) ) {
        this.tapIfExists('Back');
        this.tapIfExists('Cancel');
        this.tapIfExists('Done');

        this.tapIfExists(UIAQuery.popovers().andThen('Back').orElse('Back'));
        return;
    } else {
        throw new UIAError('Cannot determine where we are. Cannot get to top level.');
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - createNote          */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Create Folder
 *
 * @param {string} name - Folder Name
 *
 * @throws if Folder Exists
 */
notes.createFolder = function createFolder(name) {
    this.getToFolderList();

    if (this.exists(UIAQuery.tableCells(name))) {
        throw new UIAError('Folder "%0" already exists'.format(name));
    }

    this.handlingAlertsInline(
        UIAQuery.alerts('New Folder'),
        function() {
          this.tap(UIAQuery.Notes.NEW_FOLDER);
          this.typeString(name);
          this.tap('Save');
      }
    );

    // This shouldn't happen, but its here just incase
    if (this.exists(UIAQuery.alerts())) {
        this.handlingAlertsInline(
          UIAQuery.alerts('Name Taken'),
          function() {
            this.tap('OK');
            throw new UIAError('Folder "%0" already exists'.format(name));
            }
        );
    }
}

/**
 * Create a note
 *
 * @param {array} noteContents - Array of strings to be
 *                     typed into the note.
 * @param {object} options - Options dictionary
 * @param {string} options.folder - Folder name where note will be created
 * @param {string} options.leaveOpenForEditing - If set, note will not
 *                  be validated after creation but rather will be
 *                  left open for editing.
 */
notes.createNote = function createNote(noteContents, options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
        leaveOpenForEditing: false,
    });

    var numNotes = this.getFolderNoteCount(options);

    this.getToNewNote(options);
    // bring keyboard up
    if (!this.exists(UIAQuery.keyboard().isVisible())) {
        this.tap(UIAQuery.Notes.NOTE_TEXT_CONTENT);
    }
    this.waitUntilPresent(UIAQuery.keyboard(), 5);
    if (!this.exists(UIAQuery.keyboard())) {
        throw new UIAError('Keyboard did not appear');
    }
    this.typeStrings(noteContents);

    if (!options.leaveOpenForEditing) {
        // get back to top
        this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);

        UIAUtilities.assertEqual(
            numNotes + 1,
            notes.getFolderNoteCount(options),
            'Note was not created.'
        );
    }
}

/**
 * Opens up the search bar and preforms search.
 *
 * * @param {string} searchTerm - Term to search against
 */
notes.searchNotes = function searchNotes(searchTerm, options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
        dragDownForSearchField: true,
        dragDownInsideQuery: UIAQuery.Notes.TABLE_VIEWS,
    });

    this.getToFolderList();
    UIAUtilities.assertNotEqual(
        0,
        this.getFolderNoteCount(options),
        'No notes exist in folder \'%0\'. Cannot search.'.format(options.folder)
    );

    this.getToFolder(options);
    this.dragDownInside(options.dragDownInsideQuery)
    
    options.searchField = UIAQuery.staticTexts("Search").parent()
    this.search(searchTerm, options);
}

/**
 * Search for a note with a given substring. If we do not find a search
 * result, we throw. If we do find search results, we access the first
 * matching result.
 *
 * @param {string} searchTerm - Term to search against
 */
notes.searchAndAccessNote = function searchAndAccessNote(searchTerm, options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
    });

    this.searchNotes(searchTerm, options);

    UIAUtilities.assertNotEqual(
        0,
        this.getSearchResultCount(),
        'Search preformed but there were no results.'
    );

    this.tapIfExists(UIAQuery.Notes.TOP_NOTE);
}

/**
 *  Deletes a note in the specified folder. The note to delete
 *  is determined by index in the notes list. If no index is
 *  given we default to deleting the top note.
 *  If not folder is specified, we default to 'Notes'.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {object} options - Options dictionary
 * @param {string|integer|array|null} If a single integer is given, we delete
 *                  at that index. If an array of integers are given, we delete all
 *                  notes with indexes in the list. If a string 'All' is given, we delete all
 *                  notes. If null, we delete the top note.
 * @param {string} args.folder="Notes" - Folder to create note in.
 */
notes.deleteNotes = function deleteNotes(options) {
    options = UIAUtilities.defaults(options, {
        toDelete: null,
        folder: notes.Constants.NOTES,
    });

    var numNotes = this.getFolderNoteCount(options);
    UIAUtilities.assertNotEqual(numNotes, 0, 'No notes folder. Cannot delete.')

    var deleteIndexs = this.getDeletionIndexs(options.toDelete, numNotes);
    this.getToFolder(options);

    // indexs are backwards so we should be able to loop normally
    for (var i = 0; i < deleteIndexs.length; i++) {
        // no waiter exists for folder list to note list transition
        if (!this.waitUntilPresent(UIAQuery.Notes.NOTES.atIndex(deleteIndexs[i]), 2)) {
            UIAError('Notes list did not appear.');
        }
        this.swipeLeft(UIAQuery.Notes.NOTES.atIndex(deleteIndexs[i]));
        this.tap(UIAQuery.Notes.DELETE_NOTE);
    }

    UIAUtilities.assertEqual(
        (numNotes - deleteIndexs.length),
        notes.getFolderNoteCount(options),
        'Correct number of notes deleted.'
    );
}

/**
 * Deletes a note by name in the specified folder. 
 *
 *
 * @param {object} args - Options dictionary
 * @param {string} args.folder="" - Folder to delete note from.
 * @param {string} args.note="" - Name of note to delete.

 */
notes.deleteNote = function deleteNote(args) {
    var numNotes = this.getFolderNoteCount(args);
    UIAUtilities.assertNotEqual(
        numNotes, 0, 
        'No notes folder. Cannot delete.'
    );

    this.getToFolder(args);
    this.swipeLeft(UIAQuery.tableViews().andThen(UIAQuery.staticTexts(args.note)));
    this.tap(UIAQuery.Notes.DELETE_NOTE);

    UIAUtilities.assertEqual(
        (numNotes - 1),
        this.getFolderNoteCount(args),
        'Correct number of notes deleted.'
    );
}

/**
 * From inside a note, manipulates note content by selecing, cutting, copying,
 * and pasting against expected values.
 *
 * @param {stirng} beginingContent - Content note starts with.
 * @param {stirng} contentAfterDelete - Content note after delete and before the copy.
 * @param {string} expectedFinalContent - Expected content note ends with.
 */
notes.cutCopyPaste = function cutCopyPaste(beginingContent, contentAfterDelete, expectedFinalContent) {
    this.getToTopNoteInFolder();
    this.tap(UIAQuery.Notes.NOTE_TEXT_CONTENT);

    this.ccpActions(["Select All", "Cut"]);
    this.confirmExpectedNoteContent("");

    this.ccpActions(["Paste"]);
    this.confirmExpectedNoteContent(beginingContent);

    this.ccpActions(["Select", "Copy"]);
    this.tap('Delete');
    this.confirmExpectedNoteContent(contentAfterDelete);
    this.ccpActions(["Paste"]);
    this.confirmExpectedNoteContent(expectedFinalContent);
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - getNoteCount                     */
/*      Other helper functions. E.g. - getNoteTextContent                      */
/*                                                                             */
/*******************************************************************************/

/**
 * From inside a note, taps the necessary buttons to bring up the email
 * page. From there, attempts to email note.
 *
 * @param {string} recipient - Address the will recieve email
 * @param {object}  options - a dictionary object of optional arguments
 * @param {string}  options.subject - the subject of the email
 */
notes.emailNote = function emailNote(recipient, options) {
    // dismiss entertext mode if keyboard up
    this.tapIfExists('Done');

    this.tap(UIAQuery.Notes.SHARE_NOTE);
    this.tap(UIAQuery.Notes.EMAIL_NOTE);

    this.composeEmail([recipient], options);
}

/**
 * Get the number of notes in the specified folder.
 */
notes.getFolderNoteCount = function getFolderNoteCount(options) {
    options = UIAUtilities.defaults(options, {
        folder: notes.Constants.NOTES,
    });

    this.getToFolderList();
    // <rdar://problem/44136798> Wait until sync process is completed before counting notes
    if (this.waitUntilPresent(UIAQuery.Notes.PROGRESS_INDICATOR, 5.0)) {
        if (!this.waitUntilAbsent(UIAQuery.Notes.PROGRESS_INDICATOR, options.syncTimeout) && !options.ignoreSpinner) {
            throw new UIAError('Failed to sync Notes with iCloud');
        }
    }
    var theCount;
    try {
        theCount = parseInt(this.inspect(UIAQuery.tableCells('Notes').andThen(UIAQuery.staticTexts())).label);
    }
    catch (e) {
        // for iPads
        theCount = parseInt(this.nameOf(UIAQuery.tableCells(options.folder).children()).replace(',', ''));
    }
    UIALogger.logMessage('Notes in the folder: %0'.format(theCount));
    return theCount;
}

/**
 * Get the number of notes currently in the search result view
 */
notes.getSearchResultCount = function getSearchResultCount() {
    return this.count(UIAQuery.Notes.SEARCHED_NOTES);
}

/**
 * Gets the text content on a note.
 *
 * Required Starting View: Inside a note.
 */
notes.getNoteTextContent = function getNoteTextContent() {
    return this.valueOf(UIAQuery.Notes.NOTE_TEXT_CONTENT);
}

/**
 * Takes an array of strings and enters them into an already selected
 * field in the current view. If more than one element in the array
 * the strings will be seperated by a newline.
 *
 * @param {array} strings - Array of strings to enter into text field.
 */
notes.typeStrings = function typeStrings(strings) {
    this.typeString(strings.join("\n"));
}

/**
 * Add a sketch to a note
 *
 * @param {object} options
 * @param {int} [options.num_lines] - How many lines to draw in the sketch
 */
notes.addSketch = function addSketch(options) {
    options = UIAUtilities.defaults(options, {
        num_lines: 100,
    });

    this.getToDefaultNoteState();

    this.tapIfExists('Show toolbar');
    this.tap('Sketch');

    var offset = 0;

    // On non-ipads the sketch area is overlayed by a toolbar :(
    if (target.model() !== 'iPad') {
        var toolbar_height = notes.inspect(UIAQuery.query('ICDrawingView')).rect.height;
        var canvas_height = notes.inspect(UIAQuery.withPredicate('label CONTAINS "sketching area"')).rect.height;
        offset = (toolbar_height/canvas_height) * 100;
        UIALogger.logDebug('Calculated x offset for toolbar: %0'.format(offset));
    }

    for (var l = 0; l < options.num_lines; l++) {
        UIALogger.logMessage('Drawing line %0 of %1'.format(l+1, options.num_lines));
        this.randomLine(offset);
    }
    //exit the sketch, makes it easier for everywhere else
    this.tap('Done');
}

/**
 * Text to add to a note
 *
 * @param {object} options
 * @param {array|string} [options.text] String or array of strings of what to type
 */
notes.addText = function addText(options) {
    options = UIAUtilities.defaults(options, {
        text: 'Waffles',
    });
    // if the keyboard is already up lets just use it
    if (!this.exists(UIAQuery.keyboard())) {
        this.getToDefaultNoteState();
        //@TODO get the keyboard up
        //<rdar://problem/22014709> ER: UIA2: get rect of visible part of an element.
    }
    if (typeof options.text === 'string') {
        this.typeString(options.text);
    } else {
        this.typeStrings(options.text);
    }
    // <rdar://problem/22037213> UIA2: Unable to call dismissKeyboard() after typeString()
    notes.delay(.5);
    this.dismissKeyboard();
}

/**
 * Add a Photo or video attachment to a note
 * @param {object} options
 * @param {string} [options.collection="Camera Roll"] Collection to use
 * @param {string} [options.collection="photo"] Type to add, either photo or video
 *
 * @returns {bool} Returns false if there are no thumbnails of the selected type, true on success
 */
notes.addAttachment = function addAttachment(options) {
    options = UIAUtilities.defaults(options, {
        collection: 'Camera Roll',
        type: 'photo',
    });
    this.getToDefaultNoteState();
    this.tapIfExists('Show toolbar');
    this.tap('Photos');
    this.tap('Photo Library');
    this.tap(options.collection);
    if (options.type === 'photo') {
        var num_photos = this.count(this.photoThumbnails());
    } else {
        var num_photos = this.count(this.videoThumbnails());
    }
    if (num_photos == 0) {
        return false;
    }
    var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "PLPhotoTileViewController"'});
    if (options.type === 'photo') {
        this.tap(this.photoThumbnails());
    } else {
        this.tap(this.videoThumbnails());
    }
    waiter.wait(1);
    this.tap(UIAQuery.buttons('Use').orElse(UIAQuery.buttons('Choose')));
    return true;
}

/**
 * Opens the dialog box for the cut/copy/paste options
 *
 * Required Starting View: Inside a note.
 */
notes.ccpActions = function cppActions(actions) {
    if (!this.waitUntilPresent(UIAQuery.Notes.NOTE_TEXT_CONTENT, 1)) {
        throw new UIAError("Note text area is not present");
    }
    this.touchAndHold(UIAQuery.Notes.NOTE_TEXT_CONTENT, 1);

    for (var i = 0; i < actions.length; i++ ) {
        var waiter = UIAWaiter.waiter("ValueChanged");

        var currentAction = actions[i];

        var keyboardActions = {"Cut":UIAQuery.buttons("Cut"), "Copy":UIAQuery.buttons("Copy"), "Paste":UIAQuery.buttons("Paste")};
        if (isHorizontalRegularUI() && keyboardActions[currentAction]) {
            // Do actions on Keyboard when the are supported
            this.tapIfExists(UIAQuery.Notes.TEXT_OPERATION_BUTTON);

            var actionButton = UIAQuery.query(keyboardActions[currentAction]).isEnabled();
            if (!this.exists(actionButton)) {
                throw new UIAError("Action '%0' is not available view keyboard.".format(currentAction));
            }
            this.tap(actionButton);
        }
        else {
            // Bring up menu bar if needed
            if (!this.exists(UIAQuery.menuItems().isVisible())) {
                this.touchAndHold(UIAQuery.Notes.NOTE_TEXT_CONTENT, 1);
                if (!this.waitUntilPresent(UIAQuery.menuItems().isVisible())) {
                    throw new UIAError("Menu bar never appeared");
                }
            }

            // Perform action
            var menuAction = UIAQuery.menuItems(currentAction)
            if (!this.waitUntilPresent(menuAction, 2)) {
                throw new UIAError("Action '%0' does not exist.".format(currentAction));
            }
            this.tap(menuAction);
        }

        waiter.wait(1);
    }
}

/**
 * Checks to see if the passed values are the same. If not, we throw.
 */
notes.confirmExpectedNoteContent = function confirmExpectedNoteCount(expected) {
    var currentContent = this.getNoteTextContent();

    if ((currentContent === undefined) && (expected === "") ) {
        return;
    }

    if ( expected !== currentContent ) {
        throw new UIAError("Note content unexpected. Expecting: '%0' Actual: '%1'".format(expected, currentContent));
    }
}

/**
 * Checks to see if an email account is configured on device.
 * If not, we throw.
 */
notes.confirmEmailClientSetup = function confirmEmailClientSetup() {
    if (!this.isEmailClientSetup(notes)) {
        throw new UIAError("A mail client is not yet setup on this device.");
    }
}

/**
 * Generates an array of note indexes for deletion.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {string|integer|array|null} toDelete - If a single integer is given, we return
 *                  this number in array form. If an array of integers are given, we sort
 *                  them in backwards order and return it. If a string 'All' is given,
 *                  we generate an array of [numNotes .. 0] and return it. If null, we
 *                  return an array of [0]
 * @param {integer} numNotes - Max number of notes
 */
notes.getDeletionIndexs = function getDeletionIndexs(toDelete, numNotes) {
    var deleteIndexs = [];

    if (toDelete == null) {
        // if no toDelete given, lets default to the first note
        deleteIndexs.push(0);
    } else if (toDelete == 'All') {
        // generate backwards range i.e. (numNotes ... 0)
        deleteIndexs = (function(i) {max = i; array=[]; while(array.push(i--)<=max){}; return array }).call(this, numNotes-1);
    } else if (typeof toDelete === 'number' && toDelete % 1 === 0) {
        // single element
        deleteIndexs.push(toDelete);
    } else if (typeof toDelete == 'object' && toDelete.length > 0) {
        // if an array, lets copy and sort backwards
        deleteIndexs = toDelete;
        deleteIndexs.sort(function(a,b){return b - a}); // sort ints backwards
    } else {
        throw new UIAError('Index for deletion incorrectly formated.');
    }

    return deleteIndexs;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Get a random point between the min and max
 *
 * @param  {int} min Minimum number
 * @param  {int} max Maximum number
 *
 * @return {double} A double to be used as a point offset
 */
notes.randomPoint = function randomPoint(min, max) {
    if (!min) {
        min = 0;
    }
    if (!max) {
        max = 100;
    }
    return (Math.floor(Math.random()*(max-min+1)+min))/100;
}

/**
 * Draw a random line in a sketching area
 *
 * @param  {int} xoffset X offset so that we don't tap on a toolbar by accident
 */
notes.randomLine = function randomLine(xoffset) {
    var toolbar = 0;
    if(xoffset) {
        toolbar = xoffset;
    }
    this.drag(UIAQuery.withPredicate('label CONTAINS "sketching area"'), {startOffset: {x: this.randomPoint(0, 100), y: this.randomPoint(toolbar, 100)}, duration: 0.01, endOffset: {x: this.randomPoint(0, 100), y: this.randomPoint(toolbar, 100)}});
}
