load('UIATesting.js');
load('Notes.js');

UIAUtilities.assert(
    typeof NotesTests === 'undefined',
    'NotesTests undefined'
);

/**
 * Default note testing arguments. All function comment
 * parameter listings should exactly match these!
 */
var TEST_ARG_DEFAULTS = {
    TITLE: 'Notes to Defend Mankind!',
    BODY: 'This is the specialist note',
    BODYBEFORECOPY: 'This is the specialist ',
    BODY_MANIPULATED: 'This is the specialist notenote',
    SEARCH_KEYWORD_FROM_BODY: 'specialist',
    EMAIL_RECIPIENT: "weliketesting@me.com",
    EMAIL_SUBJECT: "This is an Emailed Note",
    FOLDER: 'Notes',
};

/**
 * @namespace NotesTests
 */
var NotesTests = {
    /**
     * Create a new note. If 'leaveOpenForEditing' is set to true,
     * the note will not be validated but left open.
     *
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string} [args.title="Notes to Defend Mankind!"]
     *                       - (Required) Title of note.
     * @param {string} [args.body="This is the specialist note"]
     *                       - (Optional) Body of note.
     * @param {string} [args.folder="Notes"]
     *                       - (Optional) Folder to create note in.
     *                          If not specified, we default to 'Notes'.
     * @param {string} [args.leaveOpenForEditing=false]
     *                       - (Optional) If set to false, we validate +1
     *                          notes have been created. If set to true,
     *                          we leave newly created note open.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    createNote: function createNote(args) {
        args = UIAUtilities.defaults(args, {
            title: TEST_ARG_DEFAULTS.TITLE,
            body: TEST_ARG_DEFAULTS.BODY,
            folder: TEST_ARG_DEFAULTS.FOLDER,
            leaveOpenForEditing: false,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        UIALogger.logTAResults({'apple':1});
        notes.createNote(
            [args.title, args.body],
            args
        );
    },

    /**
     * Searches for a note based on the passed search term and the specified
     * folder. If a result(s) are found, we access the first note. If no folder
     * is given, we default to 'Notes'.
     *
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string} [args.searchTerm="specialist"]
     *                     - (Required) Keyword/substring to search for in Notes
     * @param {string} [args.folder="Notes"]
     *                       - (Optional) Folder to create note in.
     *                          If not specified, we default to 'Notes'.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    searchAndAccessNote: function searchAndAccessNote(args) {
        args = UIAUtilities.defaults(args, {
            searchTerm: TEST_ARG_DEFAULTS.SEARCH_KEYWORD_FROM_BODY,
            folder: TEST_ARG_DEFAULTS.FOLDER,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        notes.searchAndAccessNote(
            args.searchTerm,
            args
        );
    },

    /**
     * Deletes one or more notes in the specified folder. The note to delete
     * is determined by index in the notes list. If no index is
     * given we default to deleting the top note.
     * If not folder is specified, we default to 'Notes'.
     *
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string|integer|array|null} [args.toDelete=0] - (Optional) If a single integer is given,
     *                      we delete at that index. If an array of integers are given, we delete all
     *                      notes with indexes in the list. If a string 'All' is given, we delete all
     *                      notes. If null, we delete the top note.
     * @param {string} [args.folder="Notes"]
     *                       - (Optional) Folder to create note in.
     *                          If not specified, we default to 'Notes'.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    deleteOneOrMoreNotes: function deleteOneOrMoreNotes(args) {
        args = UIAUtilities.defaults(args, {
            toDelete: 0,
            folder: TEST_ARG_DEFAULTS.FOLDER,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        notes.deleteNotes(args);
    },

    /**
     * Delete a named note in the given folder.
     * 
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string} [args.folder="Notes"] - (Optional) Folder to delete note in.
     * @param {string} [args.note="Notes to Defend Mankind!"] - (Optional) Note to delete.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    deleteNote: function deleteNote(args) {
        args = UIAUtilities.defaults(args, {
            folder: TEST_ARG_DEFAULTS.FOLDER,
            note: TEST_ARG_DEFAULTS.TITLE,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        notes.deleteNote(args);
    },
    
    /**
     * Email a newly created note.
     *
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteBody="This is the specialist note"]
     *                       - (Required) Body of note.
     * @param {string} [args.recipient="weliketesting@me.com"]
     *                       - (Required) Email address to send note to.
     * @param {string} [args.subject="This is an Emailed Note"]
     *                       - (Required) Title of email.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    emailNote: function emailNote(args) {
        args = UIAUtilities.defaults(args, {
            recipient: TEST_ARG_DEFAULTS.EMAIL_RECIPIENT,
            subject: TEST_ARG_DEFAULTS.EMAIL_SUBJECT,
            noteBody: TEST_ARG_DEFAULTS.BODY,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        notes.confirmEmailClientSetup();

        notes.createNote(
            [args.noteBody],
            {
                leaveOpenForEditing: true,
                syncTimeout: args.syncTimeout,
                ignoreSpinner: args.ignoreSpinner,
            }
        );

        notes.emailNote(args.recipient, args);
    },

    /**
     * Cuts, copies, and pastes text into note.
     *
     * @targetApps MobileNotes
     *
     * @param {object} args - Test arguments
     * @param {string} [args.body="This is the specialist note"]
     *                       - (Required) Body of note.
     * @param {string} [args.bodyBeforeCopy="This is the specialist "]
     *                       - (Required) Body of note after delete but before the copy.
     * @param {string} [args.manipulatedBody="This is the specialist note"]
     *                       - (Required) Body of note after cut/copy multiplication.
     * @param {integer} [args.syncTimeout=60]
     *                       - (Optional) Timeout to sync with iCLoud.
     * @param {boolean} [args.ignoreSpinner=false]
     *                       - (Optional) If set to true, we won't
     *                          raise an exception on iCloud Sync spinner
     *                          after the time is out.
     */
    cutCopyPasteNoteContent: function cutCopyPasteNoteContent(args) {
        args = UIAUtilities.defaults(args, {
            body: TEST_ARG_DEFAULTS.BODY,
            bodyBeforeCopy: TEST_ARG_DEFAULTS.BODYBEFORECOPY,
            manipulatedBody: TEST_ARG_DEFAULTS.BODY_MANIPULATED,
            syncTimeout: 60,
            ignoreSpinner: false,
        });

        notes.createNote(
            [args.body],
            args
        );

        notes.cutCopyPaste(args.body, args.bodyBeforeCopy, args.manipulatedBody);
    },
};



