load('UIAApp.js');
load('UIAUtility.js')
load('SpringBoard.js');

UIAUtilities.assert(
        typeof reminders === 'undefined',
        'reminders has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAQuery.Reminders = {
    /** 'Search' bar buttons for searching through Reminders */
    SEARCH_BAR: UIAQuery.searchBars().beginsWith('UISearchBar'),
    SEARCH_RESULTS_TABLE: UIAQuery.tableViews().leftmost(),
    CANCEL_BUTTON: UIAQuery.buttons('Cancel'),

    /** 'Scheduled' buttons for accessing time-sensitive Reminders */
    SCHEDULED_BUTTON: UIAQuery.buttons().beginsWith('Scheduled'),
    SCHEDULED_BUTTON_IPAD: UIAQuery.tableCells().andThen('Scheduled').parent(),

    /** 'New List' buttons */
    NEW_LIST_BUTTON: UIAQuery.scrollViews().beginsWith('RemindersCardStackView').andThen(UIAQuery.buttons()).first(),
    NEW_LIST_BUTTON_IPAD: UIAQuery.toolbars('UIToolbar').andThen(UIAQuery.buttons('Add List')),

    /** 'Edit' buttons */
    MORE_INFO:   UIAQuery.buttons('More Info').bottommost(),
    EDIT_BUTTON: UIAQuery.buttons('Edit').rightmost(),
    DONE_BUTTON: UIAQuery.buttons('Done'),

    /** Reminders tables*/
    REMINDERS_TABLE: UIAQuery.tableViews('RemindersTableView'),

    /** Evalution queries are used to determine whether we're in a certain state or not */
    Evaluation: {
        /** Present when all reminders lists are visible */
        VISIBLE_CARD_STACK: UIAQuery.scrollViews('RemindersCardStackView').isVisible(),

        /** Present when the menu for creating a new reminder or list is open */
        CREATE_NEW_MENU: UIAQuery.actionSheets().beginsWith('Create new'),

        /** Present when we're in the 'New List' state */
        NEW_LIST: UIAQuery.textFields('New List'),

        /** Present when we're in the 'Search' state */
        SEARCH: UIAQuery.query('RemindersSearchView').andThen(UIAQuery.buttons('Cancel')),

        /** Present when viewing a reminders list */
        LIST_VIEW: UIAQuery.query('RemindersHeaderTextField'),

        /** Present when editing a specific reminders list */
        EDIT_REMINDERS_LIST: UIAQuery.query('Color'),

        /** Present when viewing the list of all reminders lists */
        VISIBLE_ADD_LIST_TOOLBAR: UIAQuery.toolbars().andThen(UIAQuery.buttons('Add List').isVisible()),

        NAV_BARS: {
            /** Present when we're in the 'Create Reminder' state */
            CREATE_REMINDER: UIAQuery.navigationBars('Create Reminder'),

            /** Present when selecting a color for a reminders list */
            SELECT_COLOR: UIAQuery.navigationBars('Color'),

            /** Present when changing the list to which a new reminder will be added */
            CHANGE_LIST: UIAQuery.navigationBars('Change List'),

            /** Present when selecting a location for a reminder */
            LOCATION: UIAQuery.navigationBars('Location'),

            /** Present when selecting a frequency for a repeating reminder */
            REPEAT: UIAQuery.navigationBars('Repeat'),

            /** Present when selecting a custom frequency for a repeating reminder */
            CUSTOM_REPEAT: UIAQuery.navigationBars('Custom'),

            /** Present when viewing reminder details */
            DETAILS: UIAQuery.navigationBars('Details'),
        },
    },
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of string, function mappings describing the possible      */
/*      UI states of the app. The Description is a human readable identifier   */
/*      for the state and the isCurrentState is a function that returns true   */
/*      when the snapshot argument is in that state and false otherwise.       */
/*                                                                             */
/*******************************************************************************/

var UIStates = {
    /** States for the various tabs */

    /** Stack of reminders lists */
    REMINDERS_STACK: {
        Description: 'Reminders Card Stack',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.VISIBLE_CARD_STACK)
            && snapshot.exists(UIAQuery.Reminders.SEARCH_BAR);
        },
    },

    /** Single list of reminders */
    REMINDERS_LIST: {
        Description: 'Single Reminders List',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.LIST_VIEW)
            && !snapshot.exists(UIAQuery.Reminders.SEARCH_BAR)
            && !snapshot.exists(UIAQuery.Reminders.Evaluation.EDIT_REMINDERS_LIST)
            && !snapshot.exists(UIAQuery.Reminders.Evaluation.NEW_LIST);
        },
    },

    /** Top-level view with list of reminders lists */
    ALL_REMINDERS_LISTS: {
        Description: 'All Reminders Lists',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.VISIBLE_ADD_LIST_TOOLBAR)
            && !snapshot.exists(UIAQuery.Reminders.Evaluation.EDIT_REMINDERS_LIST);
        },
    },

    /** Edit a specific list of reminders */
    EDIT_REMINDERS_LIST: {
        Description: 'Edit List',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.EDIT_REMINDERS_LIST)
            && !snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.SELECT_COLOR);
        },
    },

    /** Create new... */
    CREATE_NEW_MENU: {
        Description: 'Create New Reminder Or List Menu',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.CREATE_NEW_MENU);
        },
    },

    /** Create reminder */
    CREATE_REMINDER: {
        Description: 'Create Reminder',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.CREATE_REMINDER);
        },
    },

    /** New list */
    NEW_LIST: {
        Description: 'New List',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NEW_LIST);
        },
    },

    /** Search */
    SEARCH: {
        Description: 'Search',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.SEARCH);
        },
    },

    /** Select color for reminders list */
    SELECT_COLOR: {
        Description: 'Select Color',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.SELECT_COLOR);
        },
    },

    /** Change the list to which a new reminder will be added */
    CHANGE_LIST: {
        Description: 'Change List',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.CHANGE_LIST);
        },
    },

    /** Select a location for a reminder */
    LOCATION: {
        Description: 'Location',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.LOCATION);
        },
    },

    /** Select a frequency for a repeating reminder */
    REPEAT: {
        Description: 'Repeat',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.REPEAT);
        },
    },

    /** Select a custom frequency for a repeating reminder */
    CUSTOM_REPEAT: {
        Description: 'Custom Repeat',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.CUSTOM_REPEAT);
        },
    },

    /** Reminder details */
    DETAILS: {
        Description: 'Details',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Reminders.Evaluation.NAV_BARS.DETAILS);
        },
    },
};

var reminders = target.appWithBundleID('com.apple.reminders');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
reminders.STR_LOCATION = 'Location';
reminders.STR_REMIND_ME_AT_A_LOCATION = 'Remind me at a location';
reminders.STR_CURRENT_LOCATION = 'Current Location';
reminders.STR_DETAILS = 'Details';
reminders.STR_WHEN_I_ARRIVE = 'When I arrive';
reminders.STR_WHEN_I_LEAVE = 'When I leave';

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state. See the Reminders UIStates constant
* for possible values. Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in the Reminders UIStates constant.
*
* @throws If cannot determine state.
*/
reminders.currentUIState = function currentUIState() {

    // Grab a snapshot to feed to the isCurrentState functions of the State objects
    var snapshot = this.inspect(UIAQuery.application());

    // List of all the state objects
    var states = Object.keys(UIStates).map(function (key) {
        return UIStates[key];
    });

    /*
    * For each state, check if we're in that state
    * using the isCurrentState function and the snapshot
    * If we are then log and return the State's description
    */
    for (i = 0; i < states.length; i++) {
        var state = states[i];
        if (state.isCurrentState(snapshot)) {
            var stateName = state.Description;
            UIALogger.logMessage('Currently in state %0'.format(stateName));
            return stateName;
        }
    }

    // if we got here, we don't have any idea where we are...
    throw new UIAError('Could not determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

 /**
  * Returns to the main view - a list of stacks with the option to create a new one.
  *
  * @throws If we do not end up on the main Stack view.
  */

 reminders.getToStackView = function getToStackView() {

    this.launch();

    if (UIATarget.localTarget().model() === 'iPad') {
        UIALogger.logMessage('We are on the correct view for iPad');
        return;
    }

    // If we are in the process of searching OR picking a color in edit, abort.
    this.tapIfExists(UIAQuery.Reminders.CANCEL_BUTTON);

    // If we are in the process of editing or adding a reminder, abort.
    this.tapIfExists(UIAQuery.Reminders.DONE_BUTTON);

    var reminderStack = UIAQuery.scrollViews('RemindersCardStackView');
    var topListOfStack = UIAQuery.buttons().atIndex(0).withPredicate('name != "New list"');

     var otherReminders = UIAQuery.buttons('Stack of other lists');
     this.tapIfExists(otherReminders);

     if (!this.exists(reminderStack.isVisible()) || this.exists(otherReminders.isVisible())) {
         throw new UIAError('Failed to return to Reminders stack view');
     }

 }

/**
 * Select the existing list that matches the given name. If no name is given,
 * select an arbitrary list.  If the useScheduledList argument is true, then
 * select the Scheduled list instead.
 *
 * @param {string}  listName - The desired name of the new list.
 * @param {boolean} useScheduledList - Override listName, and use the Scheduled list.
 *
 * @throws if item cannot be navigated to, checked, or verified.
 */

 reminders.getToListView = function getToListView(listName) {
    this.launch();
    this.getToStackView();

    var isiPad = (UIATarget.localTarget().model() === 'iPad');
    var reminderStack = UIAQuery.scrollViews('RemindersCardStackView');

    if (listName) {
        var namedListQuery = reminderStack.andThen(UIAQuery.buttons(listName));
        var namedListQuery_IPAD = UIAQuery.tableViews().leftmost().andThen(UIAQuery.staticTexts(listName)).parent();

        this.tap( isiPad ? namedListQuery_IPAD : reminderStack );
    } else {
        UIALogger.logWarning('No list name passed in - select an arbitrary list.');
        var anyListQuery = reminderStack.andThen(UIAQuery.buttons().withPredicate("name != 'New list'"));
        var anyListQuery_IPAD = UIAQuery.tableViews().leftmost().andThen(UIAQuery.tableCells().any());

        this.tap( isiPad ? anyListQuery_IPAD : anyListQuery);
    }
 }

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


/**
 * Creates a new List with given options
 *
 * @param {object}  options  - Arguments dictionary.
 * @param {string}  options.listName - The desired name of the new list.
 * @param {string}  options.listColor - Should we validate that a checkmark appeared?
 *
 * @throws if item cannot be navigated to, checked, or verified.
 */
 reminders.createList = function createList(options) {

     options = UIAUtilities.defaults(options, {
         listColor: 'red',
         listName: 'CreateList Test',
     });

    options.listColor = options.listColor.toLowerCase();

    this.getToStackView();

    if (UIATarget.localTarget().model() === 'iPad') {
      this.tap(UIAQuery.Reminders.NEW_LIST_BUTTON_IPAD);
    }
    else {
      this.tap(UIAQuery.Reminders.NEW_LIST_BUTTON);
    }

    //Enter the name of the new list
    this.enterText('RemindersHeaderTextField', options.listName);

    //Select the desired color
    this.tap(UIAQuery.query('RemindersListColorPickerView').andThen(UIAQuery.buttons(options.listColor)));

    //Finished.
    this.tap(UIAQuery.query('RemindersListHeaderView').andThen(UIAQuery.buttons('Done')));

 }

 /**
 * Adds a new reminder with specified note to an arbitrary list.
 *
 * @param {string} name     - The name of the reminder to be added.
 * @param {string} listName - The name of the list to add the reminder to.
 * @param {boolean} isArrivalReminder - True if the reminder should be triggered on arrival.
 * @param {string} location - Name of the desired reminder location.
 * @param {string} date - The date/time (yyyy:mm:dd:hh::mm) of the reminder.
 * @param {string} repeat - How frequently the reminder is repeated.
 * @param {string} endRepeat - The date the reminder stops repeating (yyyy:mm:dd:hh:mm).
 * @param {string} priority - The priority of the reminder.
 * @param {string} notes - The notes appended to the reminder.
 *
 */

reminders.addReminder = function addReminder(options) {

    options = UIAUtilities.defaults(options, {
        name: 'Utah Road Trip!',
        listName: 'Reminders',
        isArrivalReminder: false,
    });

    UIALogger.logMessage("Creating a reminder: " + options.name);

    var newReminderCell = UIAQuery.Reminders.REMINDERS_TABLE.children().last();
    var newReminderTextView = UIAQuery.textViews().bottommost();

    this.getToStackView();
    this.getToListView(options.listName);

    this.tap(newReminderCell);
    this.enterText(newReminderTextView, options.name + "\n", {allowTypeStringToRetry:true});       // allowTypeToRetry for rdar://problem/21972515

    //Tap the cell we just added, to reveal the More Info button.
    var addedReminder = UIAQuery.tableCells(options.name).bottommost();
    this.tap(UIAQuery.Reminders.REMINDERS_TABLE.andThen(addedReminder));
    this.tap(UIAQuery.Reminders.MORE_INFO);

    //TODO this.setDateReminder()
    this.setLocationReminder(options.isArrivalReminder, options.location);
    this.setPriority(options.priority);
    this.setNotes(options.notes);

    this.tap(UIAQuery.Reminders.DONE_BUTTON);
}

 /**
 *  markReminderAsCompleted - Mark the completion of a reminder
 * Adds a new reminder with specified note to an arbitrary list.
 *
 * @param {string} name     - The name of the reminder to mark as completed.
 **/

 reminders.markReminderAsCompleted = function markReminderAsCompleted(name) {
    this.getToStackView();
    this.enterText(UIAQuery.Reminders.SEARCH_BAR, name);

    //The desired Reminder should be the topmost one.  All the marked ones are at the bottom of the result-set
    var desiredReminder = UIAQuery.Reminders.SEARCH_RESULTS_TABLE.andThen(UIAQuery.buttons().topmost());
    var isMarked = this.inspect(desiredReminder)['value'] === 'Checked';

    if (isMarked) {
       throw new UIAError('Reminder is already marked as completed.');
    } else {
       this.tap(desiredReminder);
    }

    //If the desired reminder is somehow not checked after we just attempted to, we failed.
    if (this.inspect(desiredReminder)['value'] != 'Checked') {
       throw new UIAError('Reminder was not marked after attempt.');
    }

 }

 /**
 *  deleteReminder - Delete the reminder with the given name.
 * Deletes the desired reminder.
 *
 * @param {string} name     - The name of the reminder to delete.
 **/

 reminders.deleteReminder = function deleteReminder(name) {
    this.getToStackView();

    this.tap(UIAQuery.Reminders.SEARCH_BAR); // needed for setting focus in iPad
    this.enterText(UIAQuery.Reminders.SEARCH_BAR, name);

    //The desired Reminder should be the topmost one.
    var targetReminder = UIAQuery.Reminders.SEARCH_RESULTS_TABLE.andThen(UIAQuery.tableCells().topmost());

    //If the desired reminder query fails to find anything, we're looking for a reminder that
    //doesn't exist. -- FAIL
    try {
       this.tap(targetReminder);
    } catch (e) {
        throw new UIAError('Could not find reminder ' + name);
    }

    var deleteCell = UIAQuery.Reminders.REMINDERS_TABLE.andThen(UIAQuery.tableCells().withPredicate('name contains "' + name + '"'));

    this.tap(UIAQuery.Reminders.EDIT_BUTTON);

    //The only button in the containing cell with the Reminder name is its own delete button.
    this.tap(deleteCell.andThen(UIAQuery.buttons().withPredicate("name contains '" + name + "'")));

    var deleteButton = UIAQuery.Reminders.REMINDERS_TABLE.andThen(UIAQuery.buttons("Delete").bottommost());

    try {
        this.tap(deleteButton);
    } catch (e) {
        throw new UIAError('Could not delete the reminder' + name);
    }
    // TODO: BETTER VERIFICATION
    this.tap(UIAQuery.Reminders.DONE_BUTTON);

}
/**
 * Verifies whether the actual reminder count matches the expected reminder count in the given list name.
 *
 * @param {number} reminderCount - The expected number of reminders.
 * @param {object} options
 * @param {string} options.listName  - The name of the list to look for reminders.
 */
reminders.validateReminderCount = function validateReminderCount(reminderCount, options) {
    options = UIAUtilities.defaults(options, {
        listName: 'Reminders',
    });

    this.getToListView(options.listName);
    UIALogger.logMessage('Number of expected reminders: %0'.format(reminderCount));
    //Get the count of the actual reminders from UI
    var actualReminderCount = this.count(UIAQuery.tableViews('RemindersTableView').andThen('TableCell'));
    UIALogger.logMessage('Number of actual reminders: %0'.format(actualReminderCount));
    if (reminderCount !== actualReminderCount){
        throw new UIAError("Incorrect number of reminders in the list. Expected: '%0', Actual: '%1'".format(reminderCount, actualReminderCount));
    }
}

/**
 * Validate that the current reminder name matches the expected reminder name in the Reminder list .
 * @param {string} name - The name of the reminder to check.
 *  */
reminders.validateReminder = function validateReminder(name) {
    this.getToStackView();
    this.enterText(UIAQuery.Reminders.SEARCH_BAR, name);
    var targetReminder = UIAQuery.Reminders.SEARCH_RESULTS_TABLE.andThen(UIAQuery.tableCells().topmost());
    if(! this.exists(targetReminder)){
        throw new UIAError('Could not find reminder:%0' .format(name));
    }

}

 /******************************************************************************************/
 /*                                                                                        */
 /*   Mark: Actions                                                                        */
 /*                                                                                        */
 /*      Atomic units of UI automation and helper functions                                */
 /*      These will assume the devices is already in the required state                    */
 /*                                                                                        */
 /******************************************************************************************/

 /**
  *  setLocationReminder - Sets the location info for this reminder
  *
  * @param {boolean} isArrivalReminder - True if reminder should be triggered on arrival.
  *                                      False if reminder should be triggered on departure.
  * @param {string} location - The location to set this reminder to
  *
  **/

 reminders.setLocationReminder = function setLocationReminder(isArrivalReminder, location) {
      if (location) {
         //Location
         var locationSwitch = UIAQuery.switches(reminders.STR_REMIND_ME_AT_A_LOCATION);
         this.setControl(locationSwitch, 1);

         var locationCell = UIAQuery.staticTexts(reminders.STR_LOCATION).parent();
         this.tap(locationCell);

         this.enterText(UIAQuery.searchBars().bottommost(), location);

         //Look for the StaticText with location, and tap its parent
         try {
             var searchResults = UIAQuery.tableViews().bottommost();
             var result = UIAQuery.staticTexts().withPredicate('name contains "{}"'.format(location));
             this.tap(searchResults.andThen(result));
         } catch (e) {
             this.tap(reminders.STR_CURRENT_LOCATION);
         }

         if (isArrivalReminder) {
             //Concatenation workaround - format function doesnt work
             this.tap(UIAQuery.buttons().withPredicate('name contains "' + reminders.STR_WHEN_I_ARRIVE + '"'));
         } else {
             //Concatenation workaround - format function doesnt work
             this.tap(UIAQuery.buttons().withPredicate('name contains "' + reminders.STR_WHEN_I_LEAVE + '"'));
         }

         //Finished.  Tap details to return to more info.
         this.tap(UIAQuery.buttons(reminders.STR_DETAILS));
     }
  }

 /**
  *  setPriority - Sets the priority info for this reminder
  *
  * @param {string} priority - The priority to set for this reminder (None, Low, Medium, High).
  *
  **/

 reminders.setPriority = function setPriority(priority) {
     if (priority) {
         var priorityControls = UIAQuery.segmentedControls().bottommost();
         try {
             this.tap(priorityControls.andThen(priority));
         } catch (e) {
             this.tap(priorityControls.andThen('None'));
         }
     }
 }


 /**
  *  setNotes - Sets the notes for this reminder
  *
  * @param {string} notes - The notes to set for this reminder.
  **/

 reminders.setNotes = function setNotes(notes) {
     if (notes) {
         var notesView = UIAQuery.textViews('AXReminderNotesIdentifier').bottommost();
         this.enterText(notesView, options.notes);
     }
  }
