load('UIATesting.js');
load('Reminders.js');

UIAUtilities.assert(typeof RemindersTests === 'undefined', 'RemindersTests has already been defined.');

/** @namespace */

var RemindersTests = {

    /**
     * Adds a new reminder with specified note to an arbitrary list.
     *
     * @targetApps Reminders
     *
     * @param {string} name     - The name of the reminder to be added.
     * @param {boolean} isArrivalReminder - True if the reminder should be triggered on arrival.
     * @param {string} location - Name of the desired reminder location.
     * @param {string} date - The date/time (yyyy:mm:dd:hh::mm) of the reminder.
     * @param {string} repeat - How frequently the reminder is repeated.
     * @param {string} endRepeat - The date the reminder stops repeating (yyyy:mm:dd:hh:mm).
     * @param {string} priority - The priority of the reminder.
     * @param {string} notes - The notes appended to the reminder.
     *
     */

    addReminder: function addReminder(args) {
        args = UIAUtilities.defaults(args, {
            name: 'Utah Road Trip!',
            isArrivalReminder: false,
        });

        reminders.launch();
        reminders.addReminder(args);
    },

    /**
     * Marks a reminder as completed.
     *
     * @targetApps Reminders
     *
     * @param {string} name     - The name of the reminder to mark as completed.
     *
     */

    markReminderAsCompleted: function markReminderAsCompleted(args) {
        args = UIAUtilities.defaults(args, {
            name: 'Utah Road Trip!',
        });

        reminders.launch();
        reminders.markReminderAsCompleted(args.name);
    },

    /**
     * Deletes a reminder.
     *
     * @targetApps Reminders
     *
     * @param {string} name     - The name of the reminder to delete.
     *
     */

    deleteReminder: function deleteReminder(args) {
        args = UIAUtilities.defaults(args, {
            name: 'Utah Road Trip!',
        });

        reminders.launch();
        reminders.deleteReminder(args.name);
    },

    /**
     * Verifies whether the actual reminder count matches the expected reminder count in the given list name.
     *
     * @targetApps Reminders
     * @param {object} args - Test arguments
     * @param {string} [args.listName="Reminders"] - (Optional) The name of the list to  look for reminders.
     * @param {number} [args.reminderCount=0] - (Required) The number of expected reminders.
     */
    validateReminderCount: function validateReminderCount(args) {
        args = UIAUtilities.defaults(args, {
            listName: 'Reminders',
            reminderCount: 0,
        });

        reminders.launch();
        reminders.validateReminderCount(args.reminderCount, args);
    },

/**
 * Validate that the current reminder name matches the expected reminder name in the Reminder list .
 *
 * @targetApps Reminders
 * @param {string} [args.name="Utah Road Trip!"] - The name of the reminder to check.
 *
 */

validateReminder: function validateReminder(args) {
    args = UIAUtilities.defaults(args, {
        name: 'Utah Road Trip!',
    });
    
    reminders.validateReminder(args.name);
},
}
