load('UIATesting.js');
load('Safari.js');

UIAUtilities.assert(
    typeof SafariTests === 'undefined',
    'SafariTests has already been defined.'
);

/** @namespace */
var SafariTests = {

    /**
     * Load the specified URL.
     *
     * @overrideID Load URL
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string}          [args.URL="http://pttest.apple.com/perfmarketing-power/testcontent/digg.html"] - (required) the URL to load
     * @param {number}          [args.loadTimeout=120] - Max time allowed to load page
     * @param {null|string}     [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}     [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    loadURL: function loadURL(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            URL:                    'http://pttest.apple.com/perfmarketing-power/testcontent/digg.html',

            // Optional paramters
            loadTimeout:            120,

            // Optional paramters, validation of loaded result:
            loadedURL:              null,
            loadedContent:          null,
        }, true);

        safari.loadURL(args.URL, args);
    },

    /**
     * Load each of the specified URLs in turn. Performs scroll up/down on each page loaded.
     *
     * @overrideID Load URLs
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {array}          [args.URLs=["http://www.youtube.com", "http://finance.yahoo.com"]] - (required) the URL to load
     * @param {number}         [args.loadTimeout=120] - Max time allowed to load page
     * @param {null|string}    [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}    [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    loadURLs: function loadURLs(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            URLs:                    ["http://www.youtube.com", "http://finance.yahoo.com"],

            // Optional parameters
            loadTimeout:            120,
            newTab:                 true,

            // Optional parameters, validation of loaded result:
            loadedURL:              null,
            loadedContent:          null,
        }, true);

        safari.loadURLs(args.URLs, args);
    },

   /**
     * Uses the URL field to perform a search via the searchString. This
     * test is very versatile in that it allows us to audit search
     * results for specific substrings and/or categories. Loading the
     * search result is optional.
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string}          [args.searchString="recursion"] - (required) String to use for the search
     *
     * @param {bool}            [args.loadSearchResult=true] - If true, load search results (press enter).
     * @param {number}          [args.loadTimeout=120] - Max time allowed to load page
     *
     * @param {null|string}     [args.searchCategory=null] - Category for search results. (example types: Suggested Website,
     *                                  On This Page, Goolge Search, Top Hit, ect)
     * @param {null|string}     [args.searchPredicate=null] - Predicate to search against the search results
     *                                  (example: "ANY identifiers == 'recursion'")
     *
     * @param {null|string}     [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}     [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    search: function search(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            searchString:           'recursion',

            // Optional paramters
            loadSearchResult:       true,
            loadTimeout:            120,

            // Optional paramters, options to enhance search:
            searchCategory:         null,
            searchPredicate:        null,

            // Optional paramters, validation of loaded result:
            loadedURL:              null,
            loadedContent:          null,
        }, true);

        safari.urlSearch(args.searchString, args);
    },


    /**
     * Load page from link on page. If no URL is given to load before hand,
     * function will load first link on current page.
     *
     * This function takes optional parameters linkName and linkPredicate.
     * If neither of theses are specified we will click some link on the
     * page. If one or both are specified, we use them to finer filter
     * the link selection.
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {null|string}          [args.URL="http://pttest.apple.com/perfmarketing-power/"] - The URL for the page to select the link from
     * @param {number}          [args.loadTimeout=120] - Max time allowed to load page
     *
     * @param {null|string}     [args.linkName=null] - Name of the link to click
     * @param {null|string}     [args.linkPredicate=null] - Predicate string to search against a link to select
     *                                  (example: "ANY identifiers contains 'Wikipedia'" will select the wikipedia link on the page.)
     *
     * @param {null|string}     [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}     [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    loadFromLink: function loadFromLink(args) {
        args = UIAUtilities.defaults(args, {
            // Optional paramters
            URL:                    'http://pttest.apple.com/perfmarketing-power/',
            urlLoadTimeout:         120,
            linkLoadTimeout:        60,

            // Optional paramters, options to select a link
            linkName:               null,
            linkPredicate:          null,

            // Optional paramters, validation of loaded result:
            loadedURL:              null,
            loadedContent:          null,

        }, true);

        if (args.URL) {
            safari.loadURL(args.URL, { 'loadTimeout': args.urlLoadTimeout });
        }
        args.loadTimeout = args.linkLoadTimeout;
        safari.loadFromLink(args);
    },

    /**
     * Navigate the web page through a use of 'forward', 'back', and 'reload'
     * commands. These commands are presented via an array 'actions'.
     * Test can also take an optional array of URLs to visit before the
     * navigation starts. Test can also take an optional arrays of
     * 'loadedURLs' and 'loadedContents' to do validation. 'URLs'
     * can also be used for validation purposes and superceeds 'loadedURLs'.
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {null|array}          [args.actions=["reload"]] - Array of actions
     *
     * @param {null|array}          [args.URLs=["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html"]] - Array of URLs to load before nagivation.
     * @param {number}              [args.loadTimeout=120] - Max time allowed to load page
     *
     * @param {null|array}          [args.loadedURL=null] - Array of URLs that should be active following a navigation command
     * @param {null|array}          [args.loadedContent=null] - Array of predicate strings used to validate content on the loaded page after a navigation command.
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    navigateForwardBackRefresh: function navigateForwardBackRefresh(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters
            actions:                ['reload'],

            // Optional paramters, URLs to visit before hand
            URLs:                   ['http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html'],
            loadTimeout:            120,

            // Optional paramters, validation of loaded result:
            loadedURLs:             null,
            loadedContents:         null,
        }, true);

        if (args.URLs) {
            args.loadedURLs = safari.loadURLs(args.URLs, args);
        }

        safari.navigateForwardBackRefresh(args.actions, args);
    },

    /**
     * Test refreshing a web page. Takes in a optional URL to load
     * beforehand.
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {null|string}     [args.URL="http://pttest.apple.com/perfmarketing-power/testcontent/digg.html"] - The URL to load before reload call.
     * @param {number}          [args.loadTimeout=120] - Max time allowed to load page
     * @param {null|string}     [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}     [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    refresh: function refresh(args) {
        args = UIAUtilities.defaults(args, {
            // Optional paramters, URL to visit beforehand
            URL:                   'http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html',
            loadTimeout:            120,

            // Optional paramters, validation of loaded result:
            loadedURL:             null,
            loadedContent:         null,
        }, true);

        if (args.URL) {
            args.loadedURL = safari.loadURL(args.URL, args);
        }

        safari.reloadPage(args);
    },

    /**
     * Safari version of the Parsec validation test. Appends results to the parsec.json log.
     *
     * @overrideID ValidateParsecDomain Base Definition
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchStrings=["president", "vaccine", "cthulhu", "president wiki", "vaccine wiki"]] - an array of search strings
     * @param {string} [args.expectedDomain="WIKIPEDIA"] - the result header to look for
     * @param {array} [args.expectedDomainText=""] - the expected domain name if different from the Parsec.Domain category (e.g. Lyra)
     * @param {array} [args.expectedStrings=["president", "vaccine", "cthulhu", "president", "vaccine"]] - string to validate after tapping parsec result
     * @param {int} [args.retries=0] - the number of times to retry the searches before giving up
     * @param {array} [args.qualifiers=[]] - an array of search qualifiers for the search strings
     * @param {int} [args.delay=0.3] - the interkey delay to use when typing in a search string
     * @param {string} [args.ParsecApiHost="production"] - the parsec environment to test against (carry, test, production, etc)
     * @param {bool} [args.lookupMovies=false] - use a 'showtimes' search to define searchStrings for MOVIE domain
     * @param {string} [args.networkType="wifi"] - 'wifi' or 'cell'
     * @param {bool} [args.validatePunchout=true] - whether to tap the parsec result and validate app or card that opens
     * @param {array} [args.expectedSubDomain=""] - the expected sub domain behavior for a given result; e.g. the
     *                  itunes store domain lumps all the itunes categories (artist, ibooks, etc) under one domain
     *                  header; expectedSubDomain specifies which category we expect a given result to fall into.
     *                  This affects expected punchout behavior (whether to iTunes, podcasts, ibooks, etc).
     */
    validateParsecDomain: function validateParsecDomain(args) {
        args = UIAUtilities.defaults(args, {
                searchStrings: ["president", "vaccine", "cthulhu", "president wiki", "vaccine wiki"],
                expectedDomain: Parsec.Domain.WIKI,
                expectedDomainText: "",
                expectedStrings: [],
                retries: 0,
                qualifiers: [],
                delay:0.3,
                ParsecApiHost:'production',
                lookupMovies: false,
                networkType: 'wifi',
                validatePunchout: true,
                expectedSubDomain:"",
        });

        safari.launch();

        var data = {};

        try {
            safari.validateParsecDomain(args.searchStrings, args.expectedDomain.toUpperCase(), args);
            data.result = 'Pass';
        } catch (e) {
            data.result = 'Fail';
            throw e;
        } finally {
            data.client = 'Safari';
            data.searchDomain = args.expectedDomain;
            data.model = target.model();
            data.date = Date.now();
            var logFile = '/tmp/parsec/parsec.json';
            var cmd = "echo '" +  JSON.stringify(data) + "' >> " + logFile;
            UIALogger.logDebug(JSON.stringify(target.performTask('/bin/mkdir', ['-p', '/tmp/parsec'], 10)));
            UIALogger.logDebug(JSON.stringify(target.performTask('/bin/sh', ['-c', cmd], 10)));
            var catResult = target.performTask('/bin/cat', [logFile]);
            if (catResult.exitCode === 0) {
                UIALogger.logDebug(catResult.stdout);
            } else {
                UIALogger.logDebug(catResult.stderr);
            }
        }

        return UIATestResult.PASS;
    },

    /**
     * Safari version of the Parsec reliability test.
     *
     * @overrideID ParsecReliabilityTest Base Definition
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchStrings=["nelson mandela wiki", "hunger games itunes", "coldplay itunes", "chipotle"]] - an array of search strings
     * @param {int} [args.iterations=10] - the number of times to perform the search
     * @param {int} [args.delay=0.3] - the interkey delay to use when typing in a search string
     * @param {string} [args.ParsecApiHost="production"] - the parsec environment to test against (carry, test, production, etc)
     */
    parsecReliabilityTest: function parsecReliabilityTest(args) {
        args = UIAUtilities.defaults(args, {
                searchStrings: ["nelson mandela wiki", "hunger games itunes", "coldplay itunes", "chipotle"],
                iterations: 10,
                delay:0.3,
                ParsecApiHost:'production',
        });

        if (!springboard.launch()) {
            throw new UIAError('Could not launch SpringBoard');
        }

        safari.parsecTestReliability(args.searchStrings, args);
        return UIATestResult.PASS;
    },

    /**
     * Validates all specified domains using the corresponding search query and saves to a results array of objects
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {array}  [args.searchData=[{"query":"nelson mandela","domain":"Wikipedia"},{"query":"sfo maps","domain":"Maps"}]] - an array of search objects
     * @param {bool} [args.shouldDumpFeedback=false] - whether to use parsec_tool to dump feedback data after performing a query
     * @param {int} [args.timeout=30] - the max amount of time to wait for a result to display after typing the query
     * @param {bool} [args.shouldEngageResult=false] - whether to tap the first matching Parsec result
     * consisting of the query string and expected domain.
     */
    validateAllParsecDomains: function validateAllParsecDomains(args) {
        args = UIAUtilities.defaults(args, {
            searchData: [],
            shouldDumpFeedback: false,
            timeout: 30,
            shouldEngageResult: false,
        });

        results = safari.validateDomainList(args.searchData, args);
        UIALogger.logTAResults({parsecResults:results[0]});
        UIAUtilities.assert(results[1], 'At least one domain failed.');
    },


    /**
     * Performs an Orb peek gesture on a link in safari and verifies that the peek view appears.
     *
     * @overrideID Peek At URL
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string} [args.url="http://pttest.apple.com/perfmarketing-power/"] - initial url to load before starting test
     * @param {string} [args.identifier="Amazon"] - identifier to search for as button or link
     * @param {string} [args.peekValidation="Amazon"] - string to validate when in peek view
     */
    peekAtURL: function peekAtURL(args) {
        args = UIAUtilities.defaults(args, {
            url: 'http://pttest.apple.com/perfmarketing-power/',
            identifier: 'Amazon',
            peekValidation: 'Amazon',
        });

        safari.loadURL(args.url);

        var query = UIAQuery.buttons(args.identifier).orElse(UIAQuery.links(args.identifier).first());
        safari.assertExists(query, "Could not find a Safari link or button with identifier '" + args.identifier + "' to peek at");

        try {
            safari.touchDownForPeekGesture(query);

            UIAUtilities.assert(
                safari.currentUIState() === UIStateDescription.PEEK_VIEW,
                'We are not in safari peek view.'
            );

            UIAUtilities.assert(
                safari.exists(UIAQuery.Safari.LINK_PEEK_VIEW.andThen(UIAQuery.withPredicate("name contains[c] '" + args.peekValidation + "'"))),
                "Peek view doesn't contain the expected string '" + args.peekValidation + "'"
            );
        } finally {
            safari.releaseTouches();
        }
    },

    /**
     * Performs an Orb pop gesture on a safari link and verifies that the web page appears
     *
     * @overrideID Pop URL
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string} [args.url="http://pttest.apple.com/perfmarketing-power/"] - initial url to load before starting test
     * @param {string} [args.identifier="Amazon"] - identifier to search for as button or link
     * @param {string} [args.popValidation="pttest.apple.com/perfmarketing-power/testcontent/amazon.html"] - a string to search for in the URL
     */
    popURL: function popURL(args) {
        args = UIAUtilities.defaults(args, {
            url: 'http://pttest.apple.com/perfmarketing-power/',
            identifier: 'Amazon',
            popValidation: 'pttest.apple.com/perfmarketing-power/testcontent/amazon.html',
        });

        safari.loadURL(args.url);

        var query = UIAQuery.buttons(args.identifier).orElse(UIAQuery.links(args.identifier).first());
        safari.assertExists(query, "Could not find a Safari link or button with identifier '" + args.identifier + "' to pop open");

        var popQuery = UIAQuery.buttons("URL").andThen(UIAQuery.staticTexts().withPredicate("name contains[c] '" + args.popValidation + "'"));

        safari.touchForPopGesture(query);

        UIAUtilities.assert(
            safari.currentUIState() === UIStateDescription.Safari.WEB_PAGE,
            'We are not in the safari webpage view.'
        );

        safari.getToURLEntryUI();

        UIAUtilities.assert(
            safari.exists(popQuery),
            "Pop view doesn't contain the expected safari url '" + args.popValidation + "'"
        );
    },

    /**
     * Tests Whether the specified bookmark titles exist in Safari
     *
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string} [args.tab="Bookmarks"] - the bookmarks tab in which to look for links
     * @param {array} [args.folders=["Favorites"]] - the folder path within bookmarks to navigate to
     * @param {array} [args.bookmarkTitles=["Apple"]] - an array of bookmark titles that should be in the tab
     */
    verifyBookmarksExist: function verifyBookmarksExist(args) {
        args = UIAUtilities.defaults(args, {
            tab: 'Bookmarks',
            folder: 'Favorites',
            bookmarkTitles: ['Apple'],
        });
        safari.verifyBookmarksExist(args);
    },

    /**
     * Loads a bookmark/saved link that is choosen from one of the tabs in
     * the bookmarks menu. Tabs include 'Bookmarks', 'Reading List', 'Shared Links'.
     *
     * @overrideID Load Bookmark
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string}          [args.bookmarksTab="Bookmarks"] - (Required) Name of the tab to use in bookmarks menu.
     *                              Tabs include 'Bookmarks', 'Reading List', 'Shared Links'.
     * @param {null|string}     [args.savedLinkName="Apple"] - Name of the saved link to load (e.g. bookmark name)
     * @param {array}           [args.folderPath=["Favorites"]] - Array of folder names to transverse
     * @param {boolean}         [args.random=false] - If true, a random bookmark/saved link is choosen
     *
     * @param {null|string}     [args.loadedURL=null] - URL that should be active following the page load
     * @param {null|string}     [args.loadedContent=null] - Predicate string used to validate content on the loaded page
     *                                  (example: "ANY identifiers == 'recursion'")
     */
    loadSavedLink: function loadSavedLink(args) {
        args = UIAUtilities.defaults(args, {
            // Required paramters
            bookmarksTab:           'Bookmarks',

            // Optional paramters, options to select a saved link
            savedLinkName:          'Apple',
            folderPath:             ['Favorites'],
            random:                 false,

            // Optional paramters, validation of loaded result:
            loadedURL:              null,
            loadedContent:          null,
        }, true);

        safari.loadSavedLink(args);
    },

   /**
	* Open pages in new tabs then returns to the specified tab and verifies that it still loaded.
	*
	* @param {object} args Test arguments
	* @param {string} [args.URLs=["http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html", "http://pttest.apple.com/perfmarketing-power/testcontent/google.html"]] - URLSs of the pages to load
	* @param {string} [args.validationPredicate="behavior == 'Link'"] - predicate string used to validate content on the loaded page
	* @param {number} [args.loadTimeout=120] - maximum amount of time to wait for the page to load
    * @param {number} [args.tabIndex=0] - the tab number that will be checked to see if still loaded.
	*/
	openPageFromPreviousTab: function openPageFromPreviousTab(args){
    	args = UIAUtilities.defaults(args, {
            URLs: ['http://pttest.apple.com/perfmarketing-power/testcontent/smithsonian.html', 'http://pttest.apple.com/perfmarketing-power/testcontent/google.html'],
            validationPredicate:'behavior == "Link"',
            loadTimeout:120,
            tabIndex:0,
        }, true);

        try {
            var urlOptions = {loadTimeout:120, newTab:false};
            var firstURL = args.URLs.slice(0,1);
            var newTabURLs = args.URLs.slice(1, args.URLs.length);

            safari.loadURLs(firstURL, urlOptions);
            urlOptions.newTab = true;
            safari.loadURLs(newTabURLs, urlOptions);

            safari.validateTabLoaded(args.tabIndex, args.validationPredicate);
        } finally {
            try {
                safari.getToWebPageUI();
            } catch (error) {
                UIALogger.logError(error);
            }
        }
    },

    /**
     * Load the specified URL to install profile on the watch to test customer install OTA updates.
     *
     * @overrideID Load loadURLToInstallOTAProfile
     * @targetApps MobileSafari
     *
     * @param {object} args Test arguments
     * @param {string}          [args.profileURL="http://otaserver1.apple.com/Profiles/OTASeedSignOffDeveloperV2.mobileconfig"] - (required) the URL or the profile to install
     * @param {string}          [args.profileApp="com.apple.Preferences"] - The bundleID of the app which will install the profile. Defaults to Preferences
     * @param {bool}            [args.restartAfterInstall=false] - Whether to restart after the installation of the profile
     * @param {number}          [args.loadTimeout=120] - Max time allowed to load page
     * @param {string}          [args.passcode="111111"] - Passcode of the device
     */
    loadURLToInstallOTAProfile: function loadURLToInstallOTAProfile(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            profileURL: 'http://otaserver1.apple.com/Profiles/OTASeedSignOffDeveloperV2.mobileconfig',
            profileApp: 'com.apple.Preferences',
            restartAfterInstall: false,
            // Optional parameters
            loadTimeout: 120,
            passcode: '111111',
        }, true);

        safari.loadURLToInstallOTAProfile(args);
    },
}
