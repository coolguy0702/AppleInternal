load('UIAApp.js');
load('UIAApp+Parsec.js');
load('UIAApp+Safari.js');
load('UIAUtility.js');
load('SpringBoard.js');

if (typeof safari !== 'undefined') {
    if (!(safari instanceof UIAApp)) {
        throw new UIAError("safari has already been defined to something not an instance of UIAApp! Value: %0".format(safari));
    }
    if (safari.bundleID() !== 'com.apple.mobilesafari') {
        var oldDefinition = safari.bundleID();
        var safari = target.appWithBundleID('com.apple.mobilesafari');
        UIALogger.logWarning("'safari' was redefined from '%0' to '%1'".format(oldDefinition, safari.bundleID()));
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.Safari = {
    /** 'Compose' button of the leftmost navigation bar*/
    ADDRESS_FIELD: UIAQuery.textFields(LocStrings.ADDRESS_IN_SAFARI).isVisible().orElse(UIAQuery.buttons(LocStrings.ADDRESS_IN_SAFARI).isVisible()),

    /** Interactive version of the Address Field */
    URL_ENTRY: UIAQuery.textFields(LocStrings.ADDRESS_IN_SAFARI).isVisible(),

    /** 'URL' button*/
    URL_BUTTON: UIAQuery.buttons('URL'),

    /** 'Back' button of the web page toolbar*/
    BACK_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Back')),

    /** 'Forward' button of the web page toolbar */
    FORWARD_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Forward')),

    /** Show Bookmarks, Hide Bookmarks*/
    BOOKMARKS_BUTTON: UIAQuery.buttons('Show Bookmarks').orElse(UIAQuery.buttons('Hide Bookmarks')),

    /** Bookmarks/back button in Bookmarks menu */
    BOOKMARKS_BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Bookmarks')).orElse(UIAQuery.buttons('All')),

    /** Container holder tab controller for Bookmarks menu */
    BOOKMARKS_TAB_CONTROLLER: UIAQuery.segmentedControls(),

    /** Container of the list of bookmarks in Bookmarks menu */
    BOOKMARKS_CONTAINER: UIAQuery.tableViews('BookmarksTableView'),

    /** Opens the web page toolbar. */
    PAGES_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Pages')),

    /** 'New Page' button of the page selection toolbar*/
    // not working on iPads <rdar://problem/18522601> '+' button in safari's tab overview is missing ax label; not spoken by VO
    NEW_PAGE_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('New page')).orElse(UIAQuery.buttons('New tab')),

    /** 'Private' button of the page selection toolbar*/
    PRIVATE_BUTTON: UIAQuery.toolbars().orElse(UIAQuery.query('TabOverview')).andThen(UIAQuery.buttons().beginsWith('Private')).orElse(UIAQuery.buttons('Private Browsing')),

    /** Page load error*/
    PAGE_LOAD_ERROR: UIAQuery.withPredicate('ANY identifiers CONTAINS "Cannot Open Page" OR ANY identifiers CONTAINS "Safari cannot open the page"'),

    /** Link Peek View*/
    LINK_PEEK_VIEW: UIAQuery.ORB_PEEK_VIEW.andThen('_SFBrowserView').andThen('_SFLinkPreviewHeader'),

    /** Reload button in address bar */
    RELOAD_BUTTON: UIAQuery.buttons('ReloadButton'),

    /* Tabs button opens web page toolbar */
    TABS_BUTTON:  UIAQuery.toolbars().andThen(UIAQuery.buttons().contains('Tabs')),

    /** 'New Page' button -  */
    NEW_WEBPAGE_BUTTON: UIAQuery.buttons().contains('AddTabButton'),

    /* Queries for common alerts */
    Alerts: {
        ACCESS_CONTACTS:          UIAQuery.contains('“Safari” Would Like to Access Your Contacts'),
    },
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Safari */
UIStateDescription.Safari = {
    /** Web page content */
    WEB_PAGE:               'web page content',

    /** Web page URL entry */
    URL_ENTRY:              'web page URL entry',

    /** Web pages */
    TAB_VIEW:               'web pages in tab view',

    /** Web pages (private) */
    TAB_VIEW_PRIVATE:       'web pages in tab view (private)',

    /** History */
    HISTORY:                'history',

    /** Bookmarks */
    BOOKMARKS_LIST:         'bookmarks',

    /** Bookmarks (editing mode) */
    BOOKMARKS_EDIT:         'bookmarks (edit)',

    /** Bookmarks (edit a single entry) */
    BOOKMARKS_EDIT_ENTRY:   'bookmarks (edit a entry)',

    /** Bookmarks folder */
    BOOKMARKS_FOLDER:       'bookmark folder',

    /** Bookmarks folder (edit) */
    BOOKMARKS_FOLDER_EDIT:  'bookmark folder (edit)',

    /** Reading list */
    READING_LIST:           'reading list',

    /** Social links */
    SOCIAL_LINKS:           'social links',

    /** Subscriptions */
    SUBSCRIPTIONS:          'subscriptions',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/


/**
 * @namespace {UIAApp} safari
 */
var safari = target.appWithBundleID('com.apple.mobilesafari');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.
* See Safari UIStateDescription constants for possible values.
* Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw
* if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Safari UIStateDescription.
*
* @throws If cannot determine state.
*/
safari.currentUIState = function currentUIState() {
    // TODO: make constants for my switch statement
    // TODO: make constants for queries

    var currentUIState =  this.__proto__.currentUIState.apply(this);
    if (currentUIState !== UIStateDescription.UNKNOWN) {
        return currentUIState;
    }

    var applicationInfo = this.inspect(UIAQuery.application());
    if (applicationInfo.exists(UIAQuery.Safari.URL_ENTRY)) {
        return UIStateDescription.Safari.URL_ENTRY;
    }

    if ((applicationInfo.exists(UIAQuery.webViews()) ||
         applicationInfo.exists(UIAQuery.query('SafariWebView').isVisible()) ||
         applicationInfo.exists(UIAQuery.buttons(UIAQuery.Safari.RELOAD_BUTTON))) &&
        // ipads don't have a popover for bookmarks
        !applicationInfo.exists(UIAQuery.Safari.BOOKMARKS_TAB_CONTROLLER) &&
        !applicationInfo.exists(UIAQuery.Safari.PRIVATE_BUTTON)) {
            return UIStateDescription.Safari.WEB_PAGE;
    }

    if (applicationInfo.exists(UIAQuery.Safari.PRIVATE_BUTTON))  {
        if ( safari.inspectElementKey(UIAQuery.Safari.PRIVATE_BUTTON, 'isSelected') ) {
            return UIStateDescription.Safari.TAB_VIEW_PRIVATE;
        } else {
            return UIStateDescription.Safari.TAB_VIEW;
        }
    }

    if (applicationInfo.exists(UIAQuery.actionSheets())) {
        return UIStateDescription.ACTION_SHEET;
    }

    // at this point we know we are in the bookmark/reeadingList/socialLinks menu
    var applicationNavBar = applicationInfo.inspect(UIAQuery.navigationBars().isVisible());
    if (!applicationNavBar) {
        throw new UIAError('Failed to find a visible navigation bar for Safari');
    }
    switch (applicationNavBar.name) {
        case 'Subscriptions':
            return UIStateDescription.Safari.SUBSCRIPTIONS;
        case 'Shared Links':
        case 'SHARED LINKS':
            return UIStateDescription.Safari.SOCIAL_LINKS;
        case 'HISTORY':
        case 'History':
            return UIStateDescription.Safari.HISTORY;
        case 'Reading List':
        case 'READING LIST':
            return UIStateDescription.Safari.READING_LIST;
        case 'Edit Folder':
            return UIStateDescription.Safari.BOOKMARKS_FOLDER_EDIT;
        case 'Edit Bookmark':
            return UIStateDescription.Safari.BOOKMARKS_EDIT_ENTRY;
        case 'Bookmarks':
        case 'All':
            if (!applicationInfo.exists(UIAQuery.buttons('Edit'))) {
                return UIStateDescription.Safari.BOOKMARKS_EDIT;
            }
            return UIStateDescription.Safari.BOOKMARKS_LIST;
        // check to see if we are in folder in bookmars
        default:
            if (applicationInfo.exists(UIAQuery.buttons('All')) || applicationInfo.exists(UIAQuery.buttons('Bookmarks'))) {
                if (applicationInfo.exists(UIAQuery.buttons('Edit'))) {
                    return UIStateDescription.Safari.BOOKMARKS_FOLDER;
                }
            }
    }

    // if we got here, we don't have no clue where we are...
    throw new UIAError('Could not determine state.');
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigation function to get to the web page UI from some starting state.
* Any critia for defining a transition from a state to the web page state
* should be very exact so we always end up in the web page state or else
* throw.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If transition from startin state to web page UI has not been
*           defined in this function yet. This means we need to update the
*           this function to detect this state.
*         If we were unable to transition from starting state to
*           WEB_PAGE state.
*/
safari.getToWebPageUI = function getToWebPageUI() {
    this.launch();

    var currentState = this.currentUIState();
    if (currentState === UIStateDescription.Safari.WEB_PAGE) {
        return;
    }

    UIALogger.logMessage('Navigating to %0 UI'.format(UIStateDescription.Safari.WEB_PAGE));

    switch (currentState) {
        case UIStateDescription.Safari.URL_ENTRY:
            this.tapIfExists(UIAQuery.CANCEL_BUTTON.orElse(UIAQuery.buttons('Hide keyboard')));
            this.dismissPopover();
            break;

        case UIStateDescription.Safari.TAB_VIEW:
        case UIStateDescription.Safari.TAB_VIEW_PRIVATE:
        case UIStateDescription.VIDEO:
            this.tap(UIAQuery.buttons('Done'));
            break;

        case UIStateDescription.Safari.HISTORY:
        case UIStateDescription.Safari.BOOKMARKS_LIST:
        case UIStateDescription.Safari.BOOKMARKS_EDIT:
        case UIStateDescription.Safari.BOOKMARKS_FOLDER:
        case UIStateDescription.Safari.BOOKMARKS_FOLDER_EDIT:
        case UIStateDescription.Safari.BOOKMARKS_EDIT_ENTRY:
        case UIStateDescription.Safari.READING_LIST:
        case UIStateDescription.Safari.SOCIAL_LINKS:
        case UIStateDescription.Safari.SUBSCRIPTIONS:
            this.tapIfExists(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back').isVisible()));
            this.tap(UIAQuery.Safari.BOOKMARKS_BUTTON.orElse(UIAQuery.buttons('Done')));
            this.tapIfExists(UIAQuery.buttons('Done'));
            break;

        case UIStateDescription.ACTION_SHEET:
        case UIStateDescription.ADD_BOOKMARK:
        case UIStateDescription.ADD_TO_HOME:
        case UIStateDescription.PRINTER_OPTIONS:
            if (!this.tapIfExists(UIAQuery.CANCEL_BUTTON)) {
                this.dismissPopover();
            }
            break;

        case UIStateDescription.PARSEC_CARD:
            this.exitParsecCard();
            this.tapIfExists(UIAQuery.CANCEL_BUTTON.orElse(UIAQuery.buttons('Hide keyboard')));
            this.dismissPopover();
            break;

        default:
            // we found and new state and need to update
            throw new UIAError(
                'Current UI State unexpected. Update getToWebPageUI with new state: %0'
                .format(currentState)
            );
    }

    var previousState = currentState;

    if (previousState === UIStateDescription.Safari.TAB_VIEW ||
        previousState === UIStateDescription.Safari.TAB_VIEW_PRIVATE) {
            this.delay(1);  //TODO: make a shame radar for the delay
    }

    currentState = this.currentUIState();

    if (currentState !== UIStateDescription.Safari.WEB_PAGE) {
        throw new UIAError(
            'Could not get to \'%0\' UI from \'%1\' UI'
            .format(UIStateDescription.Safari.WEB_PAGE, currentState)
        );
    }
}

/**
* Get to URL/search entry UI.
*
* Expected starting states: Works for any UI state.
*
* @throws If unable to navigate to the web page UI.
*/
safari.getToURLEntryUI = function getToURLEntryUI() {
    this.launch();

    var currentState = this.currentUIState();
    if (currentState === UIStateDescription.Safari.URL_ENTRY) {
        return;
    }

    // this function will do the leg work for us
    this.getToWebPageUI();
    UIALogger.logMessage('Navigating to URL entry UI.');

    // address bar will disappear when scrolled down a page
    // need to bring it up again
    if (!this.exists(UIAQuery.Safari.RELOAD_BUTTON)) {
        this.tap(UIAQuery.Safari.URL_BUTTON);
    }

    // address bar can be a button. In order to interact we need to tap it
    // and make it a text field
    if (!this.exists(UIAQuery.Safari.URL_ENTRY) && this.exists(UIAQuery.Safari.ADDRESS_FIELD)) {
        this.tap(UIAQuery.Safari.ADDRESS_FIELD);
    }

    if (!this.waitUntilPresent(UIAQuery.Safari.URL_ENTRY, 5)) {
        throw new UIAError(
            'Could not get to \'%0\' UI from \'%1\' UI'
            .format(UIStateDescription.Safari.URL_ENTRY, currentState)
        );
    }
}

/**
* Gets to desired tab in the Bookmarks menu and tries to be intelligent about it.
* This menu includes access to 'Reading List', 'Shared Links', and
* 'Subscriptions' tabs.
*
* Expected starting states: Works for any UI state.
*
* @throws If unable to navigate to the bookmarks menu UI.
*/
safari.getToTabInBookmarksMenu = function getToTabInBookmarksMenu(options) {
    options = UIAUtilities.defaults(options, {
        tab: 'Bookmarks',
    });

    this.launch();
    UIALogger.logMessage('Navigating to Bookmarks menu UI.');

    var startingState = this.currentUIState();
    switch (startingState) {
        case UIStateDescription.Safari.SUBSCRIPTIONS:
        case UIStateDescription.Safari.SOCIAL_LINKS:
        case UIStateDescription.Safari.READING_LIST:
        case UIStateDescription.Safari.BOOKMARKS_FOLDER_EDIT:
        case UIStateDescription.Safari.BOOKMARKS_EDIT_ENTRY:
        case UIStateDescription.Safari.BOOKMARKS_EDIT:
        case UIStateDescription.Safari.BOOKMARKS_LIST:
        case UIStateDescription.Safari.BOOKMARKS_FOLDER:
            UIALogger.logMessage('Already in Bookmarks menu.');
            break;
        default:
            // if we get here we not in bookmarks menu at all
            this.getToWebPageUI();
            this.tap(UIAQuery.Safari.BOOKMARKS_BUTTON);
            startingState = this.currentUIState();
            break;
    }

    // We should now be in the bookmarks menu.
    UIALogger.logMessage('Attempting to get to the desired tab in bookmarks menu.');

    // Get to a top level of the menu
    switch (startingState) {
        case UIStateDescription.Safari.BOOKMARKS_FOLDER_EDIT:
        case UIStateDescription.Safari.BOOKMARKS_EDIT_ENTRY:
            this.tap(UIAQuery.Safari.BOOKMARKS_BACK_BUTTON);
            break;
        case UIStateDescription.Safari.BOOKMARKS_EDIT:
            this.tap(UIAQuery.buttons('Done'));
            break;
        case UIStateDescription.Safari.BOOKMARKS_FOLDER:
            this.tap(UIAQuery.Safari.BOOKMARKS_BACK_BUTTON);
            break;
        case UIStateDescription.Safari.SUBSCRIPTIONS:
        case UIStateDescription.Safari.SOCIAL_LINKS:
        case UIStateDescription.Safari.READING_LIST:
        case UIStateDescription.Safari.BOOKMARKS_LIST:
            // top levels
            break;
        default:
            throw new UIAError(
                'Current UI State unexpected. Update getToBookmarksMenu with new state: %0'
                .format(startingState)
            );
    }

    // Now set the correct tab
    this.tap(UIAQuery.Safari.BOOKMARKS_TAB_CONTROLLER.andThen(options.tab));

    var newState = this.currentUIState();
    if (newState !== UIStateDescription.Safari.BOOKMARKS_LIST &&
        newState !== UIStateDescription.Safari.READING_LIST &&
        newState !== UIStateDescription.Safari.SUBSCRIPTIONS &&
        newState !== UIStateDescription.Safari.SOCIAL_LINKS) {
            throw new UIAError(
                'Could not get to desired Bookmarks tab from \'%0\' UI. Current state: \'%1\''
                .format(startingState, newState)
            );
    }
}

/**
 * Returns to the list of search results in Safari (common parsec wrapper for getToURLEntryUI)
 *
 * @throws if unable to navigate back to the search results
 */
UIAApp.prototype.getToParsecSearchResults = function getToParsecSearchResults() {
    this.getToURLEntryUI();
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/*
 * Attempts to load a web page and error checks page is loaded. Takes in
 * function reference that starts the page load process. This process could
 * be entering url in address bar, pressing refreash, gestures, ect.
 *
 * Expected starting states: TODO:
 *
 * @param {function} action - Function to execute that starts page load process.
 * @param {object} options - Options dictionary
 * @param {number} options.loadTimeout - Max time allowed to load page
 * @param {string} options.loadedContent - Query compatible string or dictionary
 *                       used to validate content on the loaded page.
 * @param {string} options.loadedURL - URL that should be active following
 *                       the page load.
 */
safari.loadPageWith = function loadPageWith(action, options) {
    this.waitForWebPageLoaded(
        options.loadTimeout,
        function () {
            action.call(this, options);
        }
    );

    // check for page load error
    if (this.inspect(UIAQuery.Safari.PAGE_LOAD_ERROR)) {
        throw new UIAError('Page load error');
    }

    // validate the resulting page
    if (options.loadedContent) {
        this.assertExistsOnWebPage(options.loadedContent);
    }

    // validate the active url
    if (options.loadedURL) {
        this.assertActiveURL(options.loadedURL);
    }
}

/**
 * Uses the URL field to perform a search via the searchString. Can
 * refine search results by specifying substrings and/or categories.
 *
 * @param {object} args Test arguments
 * @param {string}          searchString - String to use for the search
 *
 * @param {bool}            options.loadSearchResult - If true, load search results (press enter).
 * @param {number}          options.loadTimeou - Max time allowed to load page
 *
 * @param {null|string}     options.searchCategory - Category for search results. (example types: Suggested Website,
 *                                  On This Page, Goolge Search, Top Hit, ect)
 * @param {null|string}     options.searchPredicate - Predicate to search against the search results
 *                                  (example: "ANY identifiers == 'recursion'")
 *
 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")
 */
safari.urlSearch = function urlSearch(searchString, options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        loadSearchResult: true,
    });

    this.getToWebPageUI();
    UIALogger.logMessage('Attempting URL search on: "%0" ...'.format(searchString));

    var searchResultQuery = this.determineSearchResultQuery(options);

    // perform search and wait for results to populate
    safari.enterURLSearchStr(searchString);
    this.waitUntilPresent(searchResultQuery, 3);    // using this b/c no waiter event exists
    this.assertExists(searchResultQuery, 'Search yielded no results.');

    if (options.loadSearchResult) {
        safari.loadPageWith(
            function() {
                safari.tap(searchResultQuery);
            },
            options
        );
    }
}

/**
 * Navigate the web page through a use of 'forward', 'back', and 'reload'
 * commands. These commands are presented via an array 'actions'.
 * Optional arrays 'loadedURLs' and 'loadedContents' can be used to do validation.
 *
 * @param {object} args Test arguments
 * @param {null|array}          args.actions - Array of actions
 * @param {null|array}          args.loadedURL - Array of URLs that should be active following a navigation command
 * @param {null|array}          args.loadedContent - Array of predicate strings used to validate content on the loaded page after a navigation command.
 *                                  (example: "ANY identifiers == 'recursion'")
 */
safari.navigateForwardBackRefresh = function navigateForwardBackRefresh(actions, options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        loadedURL: null,
        loadedURLs: null,
        loadedContent: null,
        loadedContents: null,
    });

    this.getToWebPageUI();
    //TODO: make this function better...

    if (typeof actions !== 'object') {
        throw new UIAError('Incorrect argument to function. \'action\' is a list of strings (urls)');
    }

    var boundsCheck = function(array, index) {
        if (array[index] === undefined){
            throw new UIAError('Cannot complete navigation. Page outside of navigation bounds.');
        }
        return index;
    };

    var URLIndex = null;
    if (options.loadedURLs) {
        URLIndex = options.loadedURLs.length - 1;
        UIALogger.logMessage('loadedURLs length: %0'.format(URLIndex));
        UIALogger.logMessage('loadedURLs/history: %0'.format(JSON.stringify(options.loadedURLs)));
    }

    var contentsIndex = null;
    if (options.loadedContents) {
        contentsIndex = options.loadedContents.length - 1;
        UIALogger.logMessage('contentsIndex length: %0'.format(contentsIndex));
    }

    for (var i = 0; i < actions.length; ++i) {
        switch (actions[i]) {
            case 'forward':
                // options.loadedURL = history[boundsCheck.call(this, hIndex++)];
                if (options.loadedURLs) {
                    options.loadedURL = options.loadedURLs[boundsCheck.call(this, options.loadedURLs, ++URLIndex)];
                }

                if (options.loadedContents) {
                    options.loadedContent = options.loadedContents[boundsCheck.call(this, options.loadedContents, ++contentsIndex)];
                }

                this.navigateForward(options);
                break;
            case 'back':
                // options.loadedURL = history[boundsCheck.call(this, hIndex--)];
                if (options.loadedURLs) {
                    options.loadedURL = options.loadedURLs[boundsCheck.call(this, options.loadedURLs, --URLIndex)];
                    UIALogger.logMessage("LOOK HERE: index: %0".format(URLIndex));
                    UIALogger.logMessage("LOOK HERE: %0".format(options.loadedURL));
                }

                if (options.loadedContents) {
                    options.loadedContent = options.loadedContents[boundsCheck.call(this, options.loadedContents, --contentsIndex)];
                }

                this.navigateBack(options);
                break;
            case 'reload':
                // options.loadedURL = history[boundsCheck.call(this, hIndex)];
                if (options.loadedURLs) {
                    options.loadedURL = options.loadedURLs[boundsCheck.call(this, options.loadedURLs, URLIndex)];
                }

                if (options.loadedContents) {
                    options.loadedContent = options.loadedContents[boundsCheck.call(this, options.loadedContents, contentsIndex)];
                }

                this.reloadPage(options);
                break;
            default:
                throw new UIAError('Incorrect command passed to navigate. Must use \'forward\', \'back\', \'reload\' only.');
        }
    }
}

/**
 * Load a web page from the specified URL
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {string} URL - URL of the page to load
 * @param {object} options - Options dictionary
 * @param {number} [options.loadTimeout=120] - Max time allowed to load page
 * @param {string} options.loadedContent - Query compatible string or dictionary
 *                       used to validate content on the loaded page.
 * @param {string} options.loadedURL - URL that should be active following
 *                       the page load.
 *
 * @throws If unable to load the page.
 */
safari.loadURL = function loadURL(URL, options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
    });

    if (!((typeof URL === 'string') || (URL instanceof String))) {
        throw new UIAError('URL to load not specified');
    }

    this.getToWebPageUI();
    UIALogger.logMessage('Loading page with URL "%0" ...'.format(URL));

    this.loadPageWith(
        function() {
            this.enterURL(URL);
        },
        options
    );
}

/**
 * Takes a list of urls and loads them one at time.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {array} URLs - Array of URLs to load.
 * @param {object} options - Options dictionary
 * @param {number} [options.loadTimeout=120] - Max time allowed to load page
 * @param {string} options.loadedContent - Query compatible string or dictionary
 *                       used to validate content on the loaded page.
 * @param {string} options.loadedURL - URL that should be active following
 *                       the page load.
 *
 * @returns {array} Array of URLs we have visited. The first URL will
 *                      be the URL of the starting page.
 *
 * @throws If unable to load the page.
 */
safari.loadURLs = function loadURLs(URLs, options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        newTab: false,
    });

    if (typeof URLs !== 'object') {
        throw new UIAError('Incorrect argument to function. URLs is a list of strings (urls)');
    }

    this.getToWebPageUI();
    var history = [this.getActiveURL()]; // a record of pages

    for (var i = 0; i < URLs.length; ++i) {
        if (options.newTab) {
            this.tapIfExists(UIAQuery.Safari.TABS_BUTTON);
            this.tap(UIAQuery.Safari.NEW_WEBPAGE_BUTTON);
        }

        options.loadedURL = (options.loadedURLs && (options.loadedURLs[i])) ? options.loadedURLs[i] : null;
        options.loadedContent = (options.loadedContents && (options.loadedContents[i])) ? options.loadedContents[i] : null;

        this.loadURL(URLs[i], options);

        this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.8}, toOffset:{x:0.5, y:0.1}});
        this.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.1}, toOffset:{x:0.5, y:0.8}});

        history.push(safari.getActiveURL());
    }

    return history;
}

/**
 * Click a link on a web page.
 *
 * This function takes optional parameters linkName and linkPredicate.
 * If neither of theses are specified we will click some link on the
 * page. If one or both are specified, we use them to finer filter
 * the link selection.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {object} options Test arguments
 * @param {null|string}     options.linkName - Name of the link to click
 * @param {null|string}     options.linkPredicate - Predicate string to search against a link to select
 *                                  (example: "ANY identifiers contains 'Wikipedia'" will select the wikipedia link on the page.)
 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")
 * @param {number}          [options.loadTimeout=60] - Max time allowed to load page
 */
safari.loadFromLink = function loadFromLink(options) {
    options = UIAUtilities.defaults(options, {
        linkName: null,
        linkPredicate: null,
        loadedURL: null,
        loadedContent: null,
        loadTimeout: 60,
    });

    this.getToWebPageUI();

    var linkQuery = this.determineLinkQuery(options);
    this.assertExists(linkQuery, 'No links on page with specified criteria.');
    UIALogger.logMessage('Loading page from link %0 ...'.format(linkQuery.description()));

    this.loadPageWith(
        function() {
            this.tap(linkQuery);
        },
        options
    );
}

/*
 * Navigate back and wait for page to load
 *
 * Expected starting states: UIStateDescription.Safari.WEB_PAGE
 *                           UIStateDescription.Safari.URL_ENTRY
 *
 * @param {object} options - Options dictionary
 * @param {boolean}         options.useGestures - If true, use swipe from left/right gestures
 * @param {number}          options.loadTimeout - Max amount of time to wait for the page to load
 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")
 */
safari.navigateBack = function navigateBack(options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        useGestures: false,
    });

    this.getToWebPageUI();
    UIALogger.logMessage('Loading previous page ...');

    this.loadPageWith(
        function() {
            if (options.useGestures) {
                this.swipeFromLeftEdge();
            } else {
                this.tap(UIAQuery.Safari.BACK_BUTTON);
            }
        },
        options
    );
}

/*
 * Navigate forward and wait for page to load
 *
 * Expected starting states: UIStateDescription.Safari.WEB_PAGE
 *                           UIStateDescription.Safari.URL_ENTRY
 *
 * @param {object} options - Options dictionary
 * @param {boolean}         options.useGestures - If true, use swipe from left/right gestures
 * @param {number}          options.loadTimeout - Max amount of time to wait for the page to load
 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")

 */
safari.navigateForward = function navigateForward(options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        useGestures: false,
    });

    this.getToWebPageUI();
    UIALogger.logMessage('Loading next page ...');

    this.loadPageWith(
        function() {
            if (options.useGestures) {
                this.swipeFromRightEdge();
            } else {
                this.tap(UIAQuery.Safari.FORWARD_BUTTON);
            }
        },
        options
    );
}

/*
 * Reloads the current webpage
 *
 * Expected starting states: UIStateDescription.Safari.WEB_PAGE
 *                           UIStateDescription.Safari.URL_ENTRY
 *
 * @param {object} options - Options dictionary
 * @param {number}          options.loadTimeout - Max amount of time to wait for the page to load
 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")
 * @param {bool}            options.useGestures - Refresh gesturing does not exist. Flag exist for future use
 *                                  and for logging for naviagtion functions.
 */
safari.reloadPage = function reloadPage(options){
    options = UIAUtilities.defaults(options, {
        loadTimeout: 120,
        useGestures: false,
    });

    this.getToWebPageUI();
    UIALogger.logMessage('Reloading page ..');

    if (options.useGestures) {
        UIALogger.logMessage('No gestures exists for reloading page. Will tap reload button instead.');
    }

    this.loadPageWith(
        function() {
            UIALogger.logMessage('Reloading page ..');
            this.tap(UIAQuery.Safari.RELOAD_BUTTON);
        },
        options
    );
}

/**
 * Loads a bookmark/saved link choosen from one of the tabs in
 * the bookmarks menu
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {object} options Test arguments
 * @param {null|string}     options.bookmarksTab - Name of the tab to use in bookmarks menu
 * @param {null|string}     options.savedLinkName - Name of the saved link to load
 * @param {string[]}        options.folderPath - Array of folder names to transverse
 * @param {boolean}         options.random - If true, a random bookmark/saved link is choosen

 * @param {null|string}     options.loadedURL - URL that should be active following the page load
 * @param {null|string}     options.loadedContent - Predicate string used to validate content on the loaded page
 *                                  (example: "ANY identifiers == 'recursion'")
 */
safari.loadSavedLink = function loadSavedLink(options) {
    options = UIAUtilities.defaults(options, {
        bookmarksTab: 'Bookmarks',
        savedLinkName: 'Apple',
        folderPath: ['Favorites'],
        random: false,
        loadedURL: null,
        loadedContent: null,
    });

    this.getToTabInBookmarksMenu(options.bookmarksTab);
    UIALogger.logMessage('Attempting to load saved link \'%0\''.format(options.savedLinkName));

    if (options.folderPath && !options.random) {
        this.descendFolderStructure(options.folderPath);
    }

    if (options.random) {
        UIALogger.logMessage('Choosing a random bookmark/saved link.');
        options.savedLinkName = this.findRandomSavedLink();
    }

    this.loadPageWith(
        function() {
            if (!this.exists(UIAQuery.tableViews().andThen(options.savedLinkName))) {
                throw new UIAError(
                    'Bookmark/Saved link \'%0\' does not exist'
                    .format(options.savedLinkName)
                );
            }

            this.tap(UIAQuery.tableViews().andThen(options.savedLinkName));
        },
        options
    );
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/*
 * Gets the active url in the address bar.
 *
 * Expected starting states: UIStateDescription.Safari.WEB_PAGE
 *                           UIStateDescription.Safari.URL_ENTRY
 *
 * @returns (string) The active url
 *
 * @throws If starting state is not WEB_PAGE or URL_ENTRY (i.e. a place where
 *          there shouldn't be an active url).
 */
safari.getActiveURL = function getActiveURL() {
    var currentState = this.currentUIState();

    if (currentState !== UIStateDescription.Safari.WEB_PAGE &&
        currentState !== UIStateDescription.Safari.URL_ENTRY) {
            throw new UIAError(
                'Cannot determine active URL from incorrect state: \'%0\''
                .format(currentState)
            );
    }

    var URL = this.inspect('Application').uiaxElement.valueForKey('kAXActiveURLAttribute');
    UIALogger.logDebug('Active URL is %0'.format(URL));

    return URL;
}

/*
 * Set options before attempting to enter url in address bar. Will
 * navigate to URL_ENTRY UI if needed. Please note, the difference
 * between this function and enterURLSearchStr is the predefined
 * options.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {string} URL - the URL to enter
 * @param {object} options - Options dictionary
 *                   (see [UIAApp.search]{@link UIAApp#search} for more details
 *                    regarding acceptable options)
 * @param {bool} options.requiresEnterKey - If true, this types the enter key
 *                    at the end of text input
 * @param {bool} options.clearSuggested - If true, this will clear out
 *                    auto-completed suggestions
 */
safari.enterURL = function enterURL(URL, options) {
    options = UIAUtilities.defaults(options, {
        requiresEnterKey: true,
        clearSuggested: true,
    });

    this.enterURLSearchStr(URL, options);
}

/*
 * Sets options and navaigates to URL_ENTRY. Then attempts
 * to enter string in address bar. Please note, the difference
 * between this function and enterURL is the predefined
 * options.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {string} URL - the URL to enter
 * @param {object} options - Options dictionary
 *                   (see [UIAApp.search]{@link UIAApp#search} for more details
 *                    regarding acceptable options)
 * @param {object} options.searchField - Query identifies the search field in the UI
 * @param {bool} options.requiresEnterKey - If true this types the enter key
 *                    at the end of text input
 * @param {object}  [options.enterTextOptions={}] - options to be passed onto the enterText action
 */
safari.enterURLSearchStr = function enterURLSearchStr(URL, options) {
    options = UIAUtilities.defaults(options, {
        searchField: UIAQuery.Safari.ADDRESS_FIELD,
        requiresEnterKey: false,
        enterTextOptions: {},
    });

    this.getToURLEntryUI();

    // <rdar://problem/23974546> Remove work around of rdar://problem/21972515
    options.enterTextOptions.allowTypeStringToRetry = true;
    // setValueToEnterText: <rdar://problem/23499980>
    var englishWordRe = /^[\x00-\x7F]*$/;
    var isNonEnglishWord = englishWordRe.test(URL) ? false : true;
    options.enterTextOptions.setValueToEnterText = isNonEnglishWord;

    return this.__proto__.search.apply(this, [URL, options]);
}

/**
 * Determines the query required to select a link on web page. Query
 * is dependent on values of linkName and linkPredicate. If null is
 * give for both we return a query a generic link. If values are given
 * for linkName or/and linkPredicate we used them to refind the result.
 *
 * Expected starting states: N/A. Non UI dependent.
 *
 * @param {null|string}     linkName - Name of the link to click
 * @param {null|string}     linkPredicate - Predicate string to search against a link to select
 *                                  (example: "ANY identifiers contains 'Wikipedia'" will select the wikipedia link on the page.)
 *
 * @returns Query for link selection
 */
safari.determineLinkQuery = function determineLinkQuery(options) {
    options = UIAUtilities.defaults(options, {
        linkName: null,
        linkPredicate: null,
    });

    var linkBehavior = 'behavior == "Link"';

    if (!options.linkName && !options.linkPredicate) {
        return UIAQuery.withPredicate(linkBehavior);
    }
    else if (options.linkName && !options.linkPredicate) {
        return UIAQuery.withPredicate('any identifiers == "%0"'.format(options.linkName)).withPredicate(linkBehavior);
    }
    else if (!options.linkName && options.linkPredicate) {
        return UIAQuery.withPredicate(options.linkPredicate).withPredicate(linkBehavior);
    }
    else {
        return UIAQuery.withPredicate('any identifiers == "%0"'.format(options.linkName)).withPredicate(options.linkPredicate).withPredicate(linkBehavior);
    }
}

/**
 * Descends folders in the bookmarks menu
 *
 * Expected starting states:
 *              case UIStateDescription.Safari.BOOKMARKS_LIST
 *
 * @param {string[]} folders - Array of folders
 *
 * @returns None
 */
safari.descendFolderStructure = function descendFolderStructure(folders) {
    if (!(folders instanceof Array) || folders.length < 1) {
        throw new UIAError('Incorrect folder path.');
    }

    for (var i = 0; i < folders.length; i++) {
        if (!this.exists(UIAQuery.Safari.BOOKMARKS_CONTAINER.andThen(folders[i]))) {
            throw new UIAError('Folder with name \'%0\' does not exist.'.format(folders[i]));
        }

        UIALogger.logMessage('Descending to folder \'%0\''.format(folders[i]));
        this.tap(UIAQuery.Safari.BOOKMARKS_CONTAINER.andThen(folders[i]));

        // need a waitUntilPresent as we move to fast
        if (!this.waitUntilPresent(UIAQuery.navigationBars(folders[i], 3))) {
            throw new UIAError('Could not get to folder.');
        }
    }
}

/**
 * Finds the name of a random bookmark/saved link from one of tabs in the
 * bookmarks menu. Function not particularly intelligent: will not descend
 * folders unless its the 'Favorites' folder.
 *
 * Expected starting states:
 *              case UIStateDescription.Safari.SUBSCRIPTIONS
 *              case UIStateDescription.Safari.SOCIAL_LINKS
 *              case UIStateDescription.Safari.READING_LIST
 *              case UIStateDescription.Safari.BOOKMARKS_LIST
 *
 * @returns Name of a random saved link
 */
safari.findRandomSavedLink = function findRandomSavedLink(options) {
    UIALogger.logMessage('Attempting to find random saved link.');

    // standard folders in Bookmarks menu
    var predicate = 'not (name contains[c] "Folder" \
                        and name contains[c] "Favorites" \
                        and name contains[c] "History" \
                        and name contains[c] "User Guide")';
    var query = UIAQuery.tableViews().andThen(
                    UIAQuery.tableCells().withPredicate(predicate)
                );

    // if there's a favorites menu, check there as this is where most
    // bookmarks are saved
    if (this.exists(UIAQuery.Safari.BOOKMARKS_CONTAINER.andThen('Favorites'))) {
        this.descendFolderStructure(['Favorites']);
    }

    var count = safari.count(query);
    if (count === 0) {
        throw new UIAError('No bookmarks/saved links to select.');
    }

    var rand = UIAUtilities.randomInt(0, count-1);
    var link = this.inspect(query.atIndex(rand).andThen(UIAQuery.staticTexts())).name;
    UIALogger.logMessage('Choosing random link: \'%0\''.format(link));

    return link;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Assertions                                                          */
/*                                                                             */
/*      Functions that perform validations and throw UIAErrors                 */
/*      These are Safari specific assertions only                              */
/*                                                                             */
/*******************************************************************************/

/**
* Checks for the element identifier by the validationQuery on a loaded and
* displayed web page.
*
* Expected starting states: N/A. None UI dependent.
*
* @param {object} validationQuery - Query for element which should exist
*                                       under the web view
*
* @throws If unable to validate the query on the current web page.
*/
safari.assertExistsOnWebPage = function assertExistsOnWebPage(validationQuery, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier:'Failed page load validation',
    });

    if (!(validationQuery instanceof UIAQuery)) {
        validationQuery = UIAQuery.withPredicate(validationQuery);
    }

    if (!message) {
        message = 'Loaded page did not contain %0'.
                        format(validationQuery.description());
    }

    validationQuery = UIAQuery.webViews().andThen(validationQuery);
    safari.waitUntilPresent(validationQuery, 10);
    safari.assertExists(validationQuery, message, info);
}

/**
* Checks URL against the active URL.
*
* Expected starting states: N/A. None UI dependent.
*
* @param {string} URL - string which should be active
*
* @throws If unable to verify the active URL.
*/
safari.assertActiveURL = function assertActiveURL(URL, message, info) {
    info = UIAUtilities.defaults(info, {
        identifier:'Failed active URL assertion',
    });

    if (!message) {
        message = 'Active URL %0 is not %1'.format(activeURL, URL);
    }

    var activeURL = this.getActiveURL();
    UIAUtilities.assertEqual(activeURL, URL, message, info);
}

/**
* Verifies bookmark links exist in a specific folder
*
* @param {string} tab - tab in which bookmarks reside
* @param {array} folders - the folder path within bookmarks to navigate to
* @param {array} bookmarkTitles - an array of bookmark titles that should be in the tab
*/
safari.verifyBookmarksExist = function verifyBookmarksExist(options) {
    this.getToTabInBookmarksMenu(options);
    this.descendFolderStructure([options.folder]);

    UIALogger.logMessage('In desired folder, examining bookmarks');

    for (var i = 0; i < options.bookmarkTitles.length; i++) {
        UIALogger.logMessage('Looking for bookmark with name %0'.format(options.bookmarkTitles[i]));
        if (!this.exists(UIAQuery.staticTexts().contains(options.bookmarkTitles[i]))) {
            throw new UIAError('Bookmark with name \'%0\' does not exist.'.format(options.bookmarkTitles[i]));
        }
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Handlers                                                            */
/*                                                                             */
/*******************************************************************************/

/**
 * Handler for Parsec Access Contact alert appears nondeterministically
 *
 * @returns {None}
 */
safari.accessContactsAlertHandler = function accessContactsAlertHandler() {
    var app = target.activeApp();
    var alertQuery = UIAQuery.Safari.Alerts.ACCESS_CONTACTS;

    if (app.exists(alertQuery)) {
        var alert = app.inspect(alertQuery);
        if (alert && alert.label) {
            UIALogger.logMessage("Received '%0' Alert".format(alert.label));
            UIALogger.logMessage("Trying to 'OK' on alert");
        }
        return app.tapIfExists(UIAQuery.query('OK'));
    }
    return false;
}

/**
 * Load and install a profile via a URL
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {object} options - Options dictionary
 * @param {number} [options.loadTimeout=30] - Max time allowed to load page
 * @param {string} [options.profileURL="http://otaserver1.apple.com/Profiles/OTASeedSignOffDeveloperV2.mobileconfig"] - URL of the profile to load
 * @param {string} [options.profileApp="com.apple.Preferences"] - The bundleID of the app which will install the profile. Defaults to Preferences
 * @param {bool} [options.restartAfterInstall=false] - Whether to restart after the installation of the profile
 * @param {string} [options.passcode="111111"] - Passcode to enter in when trying to install the profile
 *
 * @throws If unable to load the page.
 */
safari.loadURLToInstallOTAProfile = function loadURLToInstallOTAProfile(options) {
    options = UIAUtilities.defaults(options, {
        loadTimeout: 30,
        profileURL: "http://otaserver1.apple.com/Profiles/OTASeedSignOffDeveloperV2.mobileconfig",
        profileApp: "com.apple.Preferences",
        restartAfterInstall: false,
        passcode: '111111',
    });

    var profileAlertPredicate = 'controllerClass = "_SBAlertController" OR controllerTitle contains [c]"profile"';
    var chooseDevicePredicate = 'controllerTitle = "Choose a Device"';
    var restartAlertPredicate = 'controllerTitle contains [c]"Restart"';
    var profileFailedPredicate = 'controllerTitle = "Profile Installation Failed"';
    var profileApp = target.appWithBundleID(options.profileApp);
    var profileSettingsQuery = UIAQuery.tableCells().contains('Profile');
    var profileInstallQuery = UIAQuery.contains('Profile Installation');
    var profileInstallSwitchName = 'Profile Installation';
    
    // Allow "Profile Installation" in Settings if it exists
    var settingsApp = target.appWithBundleID('com.apple.Preferences');
    try {
        settingsApp.launch();
    } catch (error) {
        UIALogger.logError(error);
        if (!settingsApp.waitUntilPresent(UIAQuery.application())) {
            throw error;
        }
    }
    settingsApp.returnToTopLevel();
    UIALogger.logMessage('Navigating to Settings -> General -> Profilles (or Profiles & Device Management)');
    if (!settingsApp.navigateNavigationViews(['General'])) {
        throw new UIAError('Could not get to General');
    }
    if (settingsApp.waitUntilPresent(profileSettingsQuery)) {
        settingsApp.scrollToVisible(profileSettingsQuery);
        settingsApp.tapIfExists(profileSettingsQuery);

        if (settingsApp.waitUntilPresent(UIAQuery.switches().andThen(profileInstallQuery))) {
            UIALogger.logMessage('Enabling Profile Installation');
            if (!settingsApp.setSwitchSetting(profileInstallSwitchName, true)) {
                throw new UIAError('Failed to enable Profile Installation');
            }
        } else {
            UIALogger.logMessage('Profile Installation switch not found');
        }
    }
    else {
        UIALogger.logMessage('Profiles Setting not found. Skipping');
    }

    // Get to the profile URL
    this.getToWebPageUI();
    UIALogger.logMessage('Loading page with URL "%0" ...'.format(options.profileURL));

    var profileAppWaiter = UIAWaiter.withPredicate('ApplicationStateChanged', 'bundleID = "%0"'.format(profileApp));

    // Handle the profile install alert in the Safari page
    this.handlingAlertsInline(UIAQuery.alerts().withPredicate(profileAlertPredicate), function() {
        var profileAlertWaiter = UIAWaiter.withPredicate('Alert', profileAlertPredicate);
        this.enterURL(options.profileURL);

        // It's possible that we wind up skipping the alert in Safari and go right to the 'Install' screens
        profileAlertWaiter.wait(10);

        // Allow the installation of the profile
        this.handlingAlertsInline(UIAQuery.alerts().withPredicate(chooseDevicePredicate), function() {
            var chooseDeviceWaiter = UIAWaiter.withPredicate('ViewDidAppear', chooseDevicePredicate);
            target.activeApp().tap(UIAQuery.buttons("Allow"));

            if (chooseDeviceWaiter.wait(5)) {
                target.activeApp().tap(UIAQuery.buttons().contains("Watch"));
            }
        });
    });

    // Transition to the new app which installs the profile
    if (!profileAppWaiter.wait(10)) {
        // Make doubly sure the current active app isn't present
        var currentApp = target.activeApp().bundleID();
        UIALogger.logMessage('Current active app is %0'.format(currentApp));

        if (currentApp !== options.profileApp) {
            throw new UIAError('"%0" did not become active within timeout. Current active app is %1'.format(options.profileApp, currentApp));
        } else {
            UIALogger.logMessage('Switched to "%0" to finish installing the profile!'.format(currentApp));
        }
    }

    // Install the profile with 3 taps of "Install" on various views
    profileApp.tap(UIAQuery.buttons("Install").isVisible());

    if (profileApp.exists(UIAQuery.navigationBars('Enter Passcode'))) {
        if (options.passcode) {
            profileApp.typeString(options.passcode);
        } else {
            throw new UIAError('OTA required passcode but passcode was not provided in arguments');
        }
    }

    // TODO: <rdar://problem/33763952> Remove delay from 31692927
    this.delay(5);

    this.handlingAlertsInline(UIAQuery.alerts().withPredicate(profileAlertPredicate).orElse(UIAQuery.alerts().withPredicate(restartAlertPredicate)), function() {
        profileApp.tap(UIAQuery.buttons("Install").isVisible());

        this.handlingAlertsInline(UIAQuery.alerts().withPredicate(profileFailedPredicate), function() {
            // Allow the installation of the profile (This last tap could be an alert)
            var profileFailedWaiter = UIAWaiter.withPredicate('ViewDidAppear', profileFailedPredicate);
            profileApp.tap(UIAQuery.buttons("Install").isVisible());

            if (profileFailedWaiter.wait(5)) {
                throw new UIAError(
                    'Profile installation failed! The cause was: "%0"'
                    .format(
                        profileApp.inspect(UIAQuery.alerts().withPredicate(profileFailedPredicate)
                        .andThen(UIAQuery.staticTexts().atIndex(1))).name
                    )
                );
            }
        });

        if (options.restartAfterInstall) {
            profileApp.waitUntilPresent(UIAQuery.buttons("Restart").isVisible(), 30);
            profileApp.tap(UIAQuery.buttons("Restart"));
        }
        else {
            // Restart dialog with 'Not Now' button doesn't appear for some profile installations
            if (profileApp.waitUntilPresent(UIAQuery.buttons("Not Now").isVisible(), 30)) {
                profileApp.tap(UIAQuery.buttons("Not Now"));
            }

            // Wait 30 seconds for Verified text to appear after installing profile
            if (!profileApp.waitUntilPresent(UIAQuery.contains('Verified'), 30)) {
                throw new UIAError('Logging profile not installed!');
            } else {
                UIALogger.logMessage('Verified text found. Success in installing logging profile.');
            }
            // Click "Done" on "Profile Installed" view
            if (profileApp.waitUntilPresent(UIAQuery.buttons("Done").isVisible(), 30)) {
                profileApp.tap(UIAQuery.buttons("Done")); 
            }
        }
    });
}
