load("UIATesting.js");
load("SpringBoard.js");
load("Keynote.js");

if (typeof KeynoteTestUtilities !== 'undefined') throw new UIAError("KeynoteTestUtilities has already been loaded!", {identifier:"UIA module already loaded"});
if (typeof KeynoteTest !== 'undefined') throw new UIAError("KeynoteTest has already been loaded!", {identifier:"UIA module already loaded"});

var KeynoteTestUtilities = {
    _cleanedBool: function _cleanedBool(boolString) {
        return (typeof boolString == 'string') ? boolString.match(/^true$/i) :
               (typeof boolString == 'number' ) ? (boolString != 0) :
               (typeof boolString == 'boolean' ) ? boolString : undefined;
    },

    _cleanedString: function _cleanedString(string) {
        return string ? String(string) : undefined;
    },

    _cleanedStringArray: function _cleanedStringArray(thunk) {
        var arr = [];
        if (typeof thunk == 'undefined') return arr;
        else if (thunk === null) return arr;
        else if (thunk instanceof Array) {
            for (var i in thunk) {
                arr.push( this._cleanedString(thunk[i]) );
            }

        } else {
            arr.push( this._cleanedString(thunk) );
        }

        return arr;
    },

    defaultTestArgs: function defaultTestArgs(args, customDefaults) {
        // First override with custom defaults if available
        if (typeof customDefaults == 'object') args = UIAUtilities.defaults(args, customDefaults);

        return UIAUtilities.defaults(args, {
            DocumentName:               "",
            NewDocumentName:            "",
            DocumentTheme:              "",
            DocumentSize:               "",
            DocumentContents:           [],
            DocumentNames:              [],
        });
    },

    // Parses args dictionary into calendar test arguments
    parseOptions: function parseOptions(args) {
        // First do type-checking
        var options = {
            DocumentName:               this._cleanedString(args.DocumentName),
            NewDocumentName:            this._cleanedString(args.NewDocumentName),
            DocumentTheme:              this._cleanedString(args.DocumentTheme),
            DocumentSize:               this._cleanedString(args.DocumentSize),
            DocumentContents:           args.DocumentContents.map( function(dc) {return keynote._cleanedDocumentContent(dc);} ),
            DocumentNames:              this._cleanedStringArray(args.DocumentNames),
        };

        UIALogger.logMessage("Keynote options passed in: %0".format(JSON.stringify(options)));
        return options;
    },
};


/**
 * @namespace KeynoteTests
 */
var KeynoteTests = {

/*******************************************************************************/
/*                                                                             */
/*   Mark: KeynoteTests Public API - Navigation                                */
/*                                                                             */
/*      This is where test interfaces for handling Keynote navigation          */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Launches Keynote, and walks through the splashscreen if necessary
     * This test is an interface test to the Keynote library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    launchApp: function launchApp(args) {
        keynote.launchApp();
    },


/*******************************************************************************/
/*                                                                             */
/*   Mark: KeynoteTests Public API - Documents                                 */
/*                                                                             */
/*      This is where test interfaces for handling events                      */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Creates a new document
     * This test is an interface test to the Keynote library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.DocumentTheme="Gradient"]                                                                     - Document template to start with
     * @param {string}              [args.DocumentSize="Standard"]                                                                      - Document template to start with
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SAMPLE TEXT","Overwrite":false}]]     - Contents to add to document
     */
    createDocument: function createDocument(args) {
        args = KeynoteTestUtilities.defaultTestArgs(args);
        var options = KeynoteTestUtilities.parseOptions(args);

        keynote.createDocument(options.DocumentName, options);
    },

    /**
     * Edits an existing document in Keynote
     * This test is an interface test to the Keynote library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.NewDocumentName=""]                                                                           - New Name of document
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"MODIFIED TEXT","Overwrite":true}]]    - Contents to add to document
     */
    editDocument: function editDocument(args) {
        args = KeynoteTestUtilities.defaultTestArgs(args);
        var options = KeynoteTestUtilities.parseOptions(args);

        keynote.editDocument(options.DocumentName, options);
    },

    /**
     * Delete existing document(s) in Keynote
     * This test is an interface test to the Keynote library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string[]}      [args.DocumentNames=["SAMPLE NAME"]]      - (Required) Name of document
     */
    deleteDocuments: function deleteDocuments(args) {
        args = KeynoteTestUtilities.defaultTestArgs(args);
        var options = KeynoteTestUtilities.parseOptions(args);

        keynote.deleteDocuments(options.DocumentNames);
    },

    /**
     * Delete ALL existing document(s) in Keynote
     * This test is an interface test to the Keynote library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    deleteAllDocuments: function deleteAllDocuments(args) {
        keynote.deleteAllDocuments();
    },
};
