load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');

if (typeof keynote !== 'undefined') throw new UIAError("Keynote has already been loaded!", {identifier:"UIA module already loaded"});

/*******************************************************************************/
/*                                                                             */
/*   Mark: Keynote Query Constants                                             */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIAQuery.Keynote = {
    // FIRST_LAUNCH_SPLASHSCREEN: UIAQuery.query("TIAFirstLaunchDocumentStackContainerView"),

    CONTINUE_BUTTON: UIAQuery.buttons("Continue"),

    USE_ICLOUD_BUTTON: UIAQuery.buttons("Use iCloud"),

    START_USING_BUTTON: UIAQuery.buttons("View My Presentations").orElse(UIAQuery.buttons("Use Keynote")).orElse(UIAQuery.buttons("Presentations")),

    // NAVIGATION BAR BUTTONS
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Back")),

    DOCUMENTS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Presentations")),

    ADD_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Add")),

    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Done")),

    EDIT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Edit")),

    DELETE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Delete")),

    CANCEL_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Cancel")),

    CHOOSE_DOCUMENT_SIZE_CONTROL: UIAQuery.query("TIATemplateHeaderView"),

    RENAME_DOCUMENT_TEXTFIELD: UIAQuery.textFields("Rename Presentation").isVisible(),

    get EXIT_DOCUMENT_EDIT_BUTTON () { return this.DONE_BUTTON.orElse(this.DOCUMENTS_BUTTON).orElse(this.BACK_BUTTON); },

    DELETE_DOCUMENT_BUTTON: UIAQuery.beginsWith("Delete").withPredicate("name CONTAINS 'Presentation' OR name CONTAINS 'All Devices'"),

    DOCUMENT_MANAGER_VIEW: UIAQuery.query("TSADocumentManagerView"),

    EMPTY_DOCUMENT_MANAGER_VIEW: UIAQuery.query("TSADocumentManagerNoDocView"),

    DOCUMENT_EDIT_VIEW: UIAQuery.query("TSDScrollView"),

    DOCUMENT_PAGE_SETUP_VIEW: UIAQuery.query("TPDocSetupScrollView"),

    FIRST_LAUNCH_VIEW: UIAQuery.query("TSAFirstLaunchView"),

    CREATE_DOCUMENT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Create Presentation")),

    SELECT_CREATE_DOCUMENT_BUTTON: UIAQuery.staticTexts().withPredicate('name contains[c] "Create Presentation"').parent(),
};



/*******************************************************************************/
/*                                                                             */
/*   Mark: Keynote UI State Constants                                          */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIStateDescription.Keynote = {
    FIRST_LAUNCH_VIEW:          'FIRST LAUNCH',
    DOCUMENT_MANAGER_VIEW:      'DOCUMENT MANAGER',
    EDIT_DOCUMENT_VIEW:         'EDIT DOCUMENT',
    CHOOSE_TEMPLATE_VIEW:       'CHOOSE TEMPLATE',
    DOCUMENT_EDIT_SELECTION:    'DOCUMENT EDIT SELECTION',
    DOCUMENT_COLLAB_SELECTION:  'DOCUMENT COLLAB SELECTION',
    DOCUMENT_PAGE_SETUP_VIEW:   'DOCUMENT PAGE SETUP',
}

/**
    @namespace
    @augments UIAApp
*/
var keynote = target.appWithBundleID("com.apple.Keynote");



/*******************************************************************************/
/*                                                                             */
/*   Mark: Keynote Constants and Enums                                         */
/*                                                                             */
/*      Enums used by the Keynote library, for internal and external API use   */
/*                                                                             */
/*******************************************************************************/

keynote.DOCUMENT_SIZES = {
    STANDARD:   'Standard',
    WIDE:       'Wide',
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Private UIAApp Extension Methods                 */
/*                                                                             */
/*      UIAApp extension methods that are specifically useful for Keynote      */
/*                                                                             */
/*******************************************************************************/

keynote._enterTextAndDismiss = function _enterTextAndDismiss(query, text, overwrite) {
    if (overwrite === undefined) overwrite = true;
    this.enterText(query, String(text), {clearTextBeforeTyping: Boolean(overwrite)});

    var keyboard = UIAQuery.keyboard();
    if (this.exists(keyboard)) {
        UIALogger.logMessage("Dismissing keyboard");
        this.dismissKeyboard()
        this.tapIfExists(keyboard.andThen(UIAQuery.buttons('Done').orElse(UIAQuery.buttons('Search'))));
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Keynote Navigation & Navigation Setup            */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

function isHorizontalCompactUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.COMPACT;
}

function isHorizontalRegularUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
}

keynote._navigationBarValueIs = function _navigationBarValueIs(navigationBarValue) {
    var navigationBarInfo = this.inspect(UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.TOP_NAVBAR.isVisible())) || this.inspect(UIAQuery.TOP_NAVBAR.isVisible());
    var navigationBarName = navigationBarInfo ? navigationBarInfo.name : null;
    return navigationBarName === navigationBarValue;
}

keynote.NAVIGATION_VIEW_TRANSITIONS = [
    { from: UIStateDescription.Keynote.EDIT_DOCUMENT_VIEW, to: UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW, transition:{action: function() { keynote.tap(UIAQuery.Keynote.EXIT_DOCUMENT_EDIT_BUTTON); keynote.tapIfExists(UIAQuery.Keynote.EXIT_DOCUMENT_EDIT_BUTTON); }} },
    { from: UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Keynote.DOCUMENT_EDIT_SELECTION, transition:{action:keynote.tap, options:UIAQuery.Keynote.EDIT_BUTTON} },
    { from: UIStateDescription.Keynote.DOCUMENT_EDIT_SELECTION, to: UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW, transition:{action:keynote.tap, options:UIAQuery.Keynote.DONE_BUTTON} },
    { from: UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Keynote.CHOOSE_TEMPLATE_VIEW, transition:{action:function() { keynote.tap(UIAQuery.Keynote.CREATE_DOCUMENT_BUTTON); keynote.tapIfExists(UIAQuery.Keynote.SELECT_CREATE_DOCUMENT_BUTTON); }} },
    { from: UIStateDescription.Keynote.DOCUMENT_PAGE_SETUP_VIEW, to: UIStateDescription.Keynote.EDIT_DOCUMENT_VIEW, transition:{action: function() { keynote.tap(UIAQuery.query("Done")); keynote.tapIfExists(UIAQuery.query("Done")); }} },
    { from: UIStateDescription.Keynote.FIRST_LAUNCH_VIEW, to: UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW, transition:{action: function () { keynote._walkThroughFirstLaunch(); }} },

];

// Define functions for determining current app's view state
keynote.NAVIGATION_VIEWS = {};
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW]          = {action:keynote.exists, options:UIAQuery.Keynote.DOCUMENT_MANAGER_VIEW};
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.EDIT_DOCUMENT_VIEW]             = {action:keynote.exists, options:UIAQuery.Keynote.DOCUMENT_EDIT_VIEW};
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.DOCUMENT_EDIT_SELECTION]        = {action: function() { return keynote._navigationBarValueIs('Select a Document') || (keynote.exists(UIAQuery.Keynote.DOCUMENT_MANAGER_VIEW) && keynote.exists(UIAQuery.Keynote.DONE_BUTTON)); } };
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.CHOOSE_TEMPLATE_VIEW]           = {action: function() { return keynote._navigationBarValueIs('Choose a Theme') || keynote._navigationBarValueIs('Themes'); } };
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.DOCUMENT_PAGE_SETUP_VIEW]       = {action:keynote.exists, options:UIAQuery.Keynote.DOCUMENT_PAGE_SETUP_VIEW};
keynote.NAVIGATION_VIEWS[UIStateDescription.Keynote.FIRST_LAUNCH_VIEW]              = {action:keynote.exists, options:UIAQuery.Keynote.FIRST_LAUNCH_VIEW};

// Defines Keynote Navigation
keynote.navigation = new UIANavigation(keynote, keynote.NAVIGATION_VIEW_TRANSITIONS, keynote.NAVIGATION_VIEWS);



/*******************************************************************************/
/*                                                                             */
/*   Mark: Keynote Library Public API - Navigation                             */
/*                                                                             */
/*      This is where all public API methods for Keynote Navigation            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Safari for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
keynote.currentUIState = function currentUIState() {
    var currentUIState = this.navigation.getCurrentState() || 'UNKNOWN STATE';
    UIALogger.logMessage("UI is currently on '%0'".format(currentUIState));
    return currentUIState;
}

/**
 * Launches Keynote.  This differs from keynote.launch() in that it will walk through the first-time splashscreen
 *
 * @throws If unable to launch Keynote or walk through the splashscreen to the Document Manager View
*/
keynote.launchApp = function launchApp() {
    this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW);
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Keynote Library Public API - Document Management                    */
/*                                                                             */
/*      This is where all public API methods for Keynote Navigation            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Create new document
 *
 * @param {string}   DocumentName           - Name of the document
 * @param {object}   DocumentOptions        - Name of the keynote
 *
 * @throws If unable to create a new document
 */
keynote.createDocument = function createDocument(DocumentName, DocumentOptions) {
    DocumentOptions = keynote._defaultDocumentOptions(DocumentOptions);

    this.navigation.goTo(UIStateDescription.Keynote.CHOOSE_TEMPLATE_VIEW);
    this.tap( UIAQuery.Keynote.CHOOSE_DOCUMENT_SIZE_CONTROL.andThen( DocumentOptions.DocumentSize ) );
    this.tap( UIAQuery.tableCells(DocumentOptions.DocumentTheme) );

    this.waitUntilPresent(UIAQuery.Keynote.DOCUMENT_EDIT_VIEW, 10);
    this._renameDocument("Presentation", DocumentName);
    this.editDocument(DocumentName, DocumentOptions);
}

/**
 * Edit existing document
 *
 * @param {string}   DocumentName           - Name of the document to be edited
 * @param {object}   DocumentOptions        - Name of the keynote
 *
 * @throws If unable to find or edit document
 */
keynote.editDocument = function editDocument(DocumentName, DocumentOptions) {
    if (DocumentOptions.NewDocumentName) {
        this._renameDocument(DocumentName, DocumentOptions.NewDocumentName);
        DocumentName = DocumentOptions.NewDocumentName;
    }

    this._getToDocument(DocumentName);
    this._applyDocumentContents(DocumentOptions.DocumentContents);

    UIALogger.logMessage("Finished applying changes to document; exiting document");
    this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW);
}

/**
 * Deletes a list of existing documents.  Assumes all documents are uniquely named
 *
 * @param {string|string[]}    DocumentName         - Name(s) of the documents to be deleted
 *
 * @throws If unable to find or delete the listed documents
 */
keynote.deleteDocuments = function deleteDocuments(DocumentNames) {
    DocumentNames = this._toStringList(DocumentNames);
    var documents = DocumentNames.map( (function (dn) { return this._findDocument(dn); }).bind(this) );

    this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_EDIT_SELECTION);
    for (var i in documents) this.tap( documents[i] );

    this._tapDeleteDocument();

    var remainingFiles = DocumentNames.filter( (function (dn) { return this._findDocument(dn, true); }).bind(this) );
    if (remainingFiles.length > 0) throw new UIAError("The following files did not appear to be deleted: %0".format(JSON.stringify(remainingFiles)), {identifier:"Document(s) could not be deleted"});
    else UIALogger.logMessage("Successfully deleted the following files: %0".format(JSON.stringify(DocumentNames)));
}

keynote.deleteAllDocuments = function deleteAllDocuments() {
    this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_EDIT_SELECTION);
    var allDocuments = UIAQuery.Keynote.DOCUMENT_MANAGER_VIEW.andThen( UIAQuery.buttons().withPredicate("parent.name != 'UISegmentedControl' AND parent.name != 'TIADocumentManagerSearchBar'") );

    var buttonNames = this.inspectAll(allDocuments).map( function (n) {return n.name;} );
    for (var i in buttonNames) {
        this.tap( UIAQuery.buttons(buttonNames[i]).parent() );
    }

    this._tapDeleteDocument();

    if (this.exists( UIAQuery.Keynote.EMPTY_DOCUMENT_MANAGER_VIEW )) {
        UIALogger.logMessage("All documents appear to have been successfully deleted");
    } else {
        var remainingDocs = this.inspectAll(allDocuments).map( function (n) {return n.name;} )
                                                         .map( (function (n) {return this.inspect( UIAQuery.buttons(n).parent() ).name;}).bind(this) );
        throw new UIAError("The following files were not deleted:  %0".format(JSON.stringify(remainingDocs)), {identifier:"Some files were not deleted"});
    }
}

keynote.sendDocument = function sendDocument() {
    /* DocumentName, Format/Keynote, Word, ePub, PDF/, SendMethod/tons of options/ */
}

keynote.shareDocument = function shareDocument() {
    // DocumentName, ShareOptions/Allow editing, View only/, Password, PasswordHint
    // should return Share Link
}

keynote.stopSharingDocument = function stopSharingDocument() {
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Variable/Argument Sanitizers                     */
/*                            and Struct Defaults                              */
/*                                                                             */
/*      Sanitizes variables against types and Keynote-specific enums/structs   */
/*                                                                             */
/*******************************************************************************/

keynote._toStringList = function _toStringList(x) {
    if (x === undefined || x === null) throw new UIAError("List is null or empty!", {identifier:"Invalid list"});
    else if (x instanceof Array) return x.map( function (i) {return String(i);} );
    else return [ String(x) ];
}

/**
 * Asserts that a value is in an enum of { key : value }
 *
 * @param {enum}    enumDict     - Enum to check against (implemented in JS as an object)
 * @param {string}  value        - Key to check
 * @param {string}  description  - Description of the key (for error logging)
 *
 * @throws If the value was not found in the enum
 */
keynote._assertEnumValue = function _assertEnumValue(enumDict, value, description) {
    var enumValues = Object.keys(enumDict).map(function (k) { return enumDict[k]; });
    if (! enumValues.contains(value)) {
        throw new UIAError("Invalid %0 value provided ('%1'); accepted enum values are %2!".format(description, value, JSON.stringify(enumValues)), {identifier:'Invalid %0'.format(description)});
    } return value;
}

keynote._defaultDocumentOptions = function _defaultDocumentOptions(DocumentOptions) {
    DocumentOptions = UIAUtilities.defaults((typeof DocumentOptions !== "object") ? {} : DocumentOptions, {
        DocumentTheme:                      'Gradient',
        DocumentSize:                       'Standard',
        NewDocumentName:                    undefined,
        DocumentContents:                   [],
    });

    DocumentOptions.DocumentTheme       = String(DocumentOptions.DocumentTheme);
    DocumentOptions.NewDocumentName     = (DocumentOptions.NewDocumentName == undefined) ? undefined : String(DocumentOptions.NewDocumentName);
    DocumentOptions.DocumentSize        = this._assertEnumValue(this.DOCUMENT_SIZES, String(DocumentOptions.DocumentSize), "Document Size");
    DocumentOptions.DocumentContents    = DocumentOptions.DocumentContents.map( (function (dc) {return this._cleanedDocumentContent(dc);}).bind(this) );
    return DocumentOptions;
}

keynote._cleanedDocumentContent = function _cleanedDocumentContent(DocumentContent) {
    DocumentContent = UIAUtilities.defaults((typeof DocumentContent !== "object") ? {} : DocumentContent, {
        DocumentSection:                    '',
        Contents:                           '',
        Overwrite:                          false,
    });
    DocumentContent.DocumentSection = String(DocumentContent.DocumentSection);
    DocumentContent.Contents        = String(DocumentContent.Contents);
    DocumentContent.Overwrite       = Boolean(DocumentContent.Overwrite);
    return DocumentContent;
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Navigation                                       */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigating to specific documents in Keynote                        */
/*                                                                             */
/*******************************************************************************/

/**
 * Asserts device is in a specified view in Keynote
 *
 * @param {enum} ExpectedView            - The expected view (enum UIStateDescription.Keynote)
 *
 * @throws If current view !== ExpectedView
 */
keynote._ensureCurrentViewIs = function _ensureCurrentViewIs(ExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView !== ExpectedView) throw new UIAError("UIA expected to be in the '%0' view but is currently in the '%1' view instead!".format(ExpectedView, ActualView), {identifier:"Device in unexpected view"});
    return true;
}

/**
 * Asserts device is NOT in a specified view in Keynote
 *
 * @param {enum} NotExpectedView            - The unexpected view (enum UIStateDescription.Keynote)
 *
 * @throws If current view === NotExpectedView
 */
keynote._ensureCurrentViewIsNot = function _ensureCurrentViewIsNot(NotExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView === NotExpectedView) throw new UIAError("UIA expected to not be in the '%0' view but currently is!".format(NotExpectedView), {identifier:"Device in unexpected view"});
    return true;
}

keynote._walkThroughFirstLaunch = function _walkThroughFirstLaunch() {
    var validQueries = [ UIAQuery.Keynote.CONTINUE_BUTTON, UIAQuery.Keynote.CONTINUE_BUTTON, UIAQuery.Keynote.USE_ICLOUD_BUTTON, UIAQuery.Keynote.START_USING_BUTTON, ];
    var button = validQueries.reduce(function (qA, qB, idx, arr) { return qA.orElse(qB.isVisible()); }, UIAQuery.withPredicate('FALSEPREDICATE'));
    while (this.exists(UIAQuery.Keynote.FIRST_LAUNCH_VIEW)) {
        this.waitUntilPresent(button, 60);
        this.tap(button);
        this.delay(2); // This is necessary b/c the taps enter a race condition otherwise
    }
}

/**
 * Walks to Manage Document View, and returns the UIAQuery to the document, if found.  Useful for building other Keynote library functions
 *
 * @param {string}      DocumentName         - Name of the document to be renamed
 * @param {bool}        DontThrow            - If set to true, will return false upon failure to find document (instead of throwing UIAError)
 *
 * @throws If unable to find the document, and DontThrow is set to false
 *
 * @returns Returns UIAQuery to the document if the document is found; undefined otherwise
 */
keynote._findDocument = function _findDocument(DocumentName, DontThrow) {
    DocumentName = String(DocumentName);
    this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW);

    var documentQuery = UIAQuery.beginsWith("%0,".format(DocumentName)).leaves().parent();
    var numMatchingDocuments = this.count(documentQuery);

    var returnQuery = undefined;
    var msg = "";
    var errorID = "";

    if (numMatchingDocuments < 1) {
        msg = "Did not find a document named '%0'".format(DocumentName);
        errorID = "Didn't find the target document matching name";

    } else if (numMatchingDocuments > 1) {
        msg = "Found %0 documents with name matches the given name (beginsWith): '%1'".format(numMatchingDocuments, DocumentName);
        errorID = "Found multiple documents matching name";

    } else {
        msg = "One match found; will assume this is the target document!";
        returnQuery = documentQuery;
    }

    UIALogger.logMessage(msg);
    if (returnQuery === undefined) {
        if (DontThrow === true) return undefined;
        else throw new UIAError(msg, {identifier:errorID});
    } else return returnQuery;
}

/**
 * Opens the document
 *
 * @param {string}      DocumentName         - Name of the document to be renamed
 *
 * @throws If unable to find or open the document
 */
keynote._getToDocument = function _getToDocument(DocumentName) {
    var documentQuery = keynote._findDocument(DocumentName);
    this.tap(documentQuery);
    this.waitUntilPresent(UIAQuery.Keynote.DOCUMENT_EDIT_VIEW, 10);
}

/**
 * Tap the Delete Document while in Select Document view, and handles the Verify iCloud Document Delete alert that appears once
 *
 * @throws If unable to delete document
 */
keynote._tapDeleteDocument = function _tapDeleteDocument() {
    var _deleteDocumentAlertHandler = function() {
        var app = keynote;
        if (app.exists(UIAQuery.withPredicate("name CONTAINS[c] 'Deleting '"))) {
            app.tap(UIAQuery.alerts().andThen('Delete'));
            return true;
        } return false;
    };

    this.withAlertHandler(_deleteDocumentAlertHandler, function () {
        this.tap( UIAQuery.Keynote.DELETE_BUTTON );
        this.tap( UIAQuery.Keynote.DELETE_DOCUMENT_BUTTON );

        this.navigation.goTo(UIStateDescription.Keynote.CHOOSE_TEMPLATE_VIEW);
        this.navigation.goTo(UIStateDescription.Keynote.DOCUMENT_MANAGER_VIEW);
    });
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Editing Documents                                */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigation in Keynote                                              */
/*                                                                             */
/*******************************************************************************/

/**
 * Rename an existing document.  Assumes all documents are uniquely named
 *
 * @param {string}   DocumentName           - Name of the document to be renamed
 * @param {object}   NewDocumentName        - New name for the document
 *
 * @throws If unable to find or rename document
 */
keynote._renameDocument = function _renameDocument(DocumentName, NewDocumentName) {
    NewDocumentName = String(NewDocumentName);
    var documentQuery = this._findDocument(DocumentName);

    var newDocumentQuery = this._findDocument(NewDocumentName, true);
    if (newDocumentQuery !== undefined) {
        throw new UIAError("Cannot rename document to '%0' because another such document already exists!".format(NewDocumentName), {identifier:"Document rename conflict"});
    }

    this.tap( documentQuery.andThen(UIAQuery.beginsWith('Rename')) );
    this.waitUntilPresent(UIAQuery.Keynote.RENAME_DOCUMENT_TEXTFIELD, 10);
    this._enterTextAndDismiss(UIAQuery.Keynote.RENAME_DOCUMENT_TEXTFIELD, NewDocumentName);

    if (keynote._findDocument(NewDocumentName) !== undefined) UIALogger.logMessage("Successfully renamed document to '%0'".format(NewDocumentName));
}

/**
 * Apply a list of changes to a document.  Assumes device is currently in Edit Document View
 *
 * @param {DocumentContent[]}   DocumentContents           - List of changes to apply to a document.  Schema for DocumentContent is defined in the documentation for keynote._cleanedDocumentContent()
 *
 * @throws If unable to apply the specified changed to a document
 */
keynote._applyDocumentContents = function _applyDocumentContents(DocumentContents) {
    this.waitUntilPresent(UIAQuery.Keynote.DOCUMENT_EDIT_VIEW, 10);
    for (var i in DocumentContents) {
        var content = DocumentContents[i];
        UIALogger.logMessage("Attempting to write to document %0 [%1]:    %2".format(content.DocumentSection, content.Overwrite ? "OVERWRITE" : "APPEND", content.Contents));
        this._enterTextToDocumentSection(content.DocumentSection, content.Contents, content.Overwrite);
    }
}

/**
 * Enters text to page section.  Assumes device is currently in Edit Document View
 *
 * @param {string}      DocumentSection     - Name of the page section (i.e. 'Body', 'Center Header')
 * @param {string}      Contents            - Content to add to document
 * @param {bool}        Overwrite           - If true; clear all text inside field prior to typing in Contents
 *
 * @throws If unable to add the specified contents into the specified document section
 */
keynote._enterTextToDocumentSection = function _enterTextToDocumentSection(DocumentSection, Contents, Overwrite) {
    DocumentSection  = String(DocumentSection);
    var textfield = UIAQuery.textFields().contains(DocumentSection);
    this.tap(textfield, {tapCount: 2});
    this._enterTextAndDismiss(textfield, Contents, Overwrite);

    // Tap on somewhere outside the keyboard to exit from keyboard view (works for both iPhones and iPads)
    if (this.exists(UIAQuery.keyboard())) {
        this.tap('TSDScrollView');
    }
}

