load('UIATesting.js');
load('Calculator.js');

UIAUtilities.assert(
    typeof CalculatorTests === 'undefined',
    'CalculatorTests undefined'
);

/**
 * @namespace CalculatorTests
 */
var CalculatorTests = {

    /**
      * Preform a calculation
      *
      * @eligibleResource deviceClass == 'iPhone'
      * @targetApps Calculator
      *
      * @param {object} args - Test arguments
      * @param {string} [args.calculation="1+1"] - Required the calcuation to preform
      * @param {string} [args.expectedResult="2"] - Required the expected result of the calculation
      * @param {boolean} [args.shouldClear=true] - Optional if false continue the previous calculation
      */
    calculate: function calculate(args) {
        args = UIAUtilities.defaults(args, {
            calculation: "1+1",
            expectedResult: "2",
            shouldClear: true,
        })
        
        calculator.calculate(args.calculation, args.shouldClear);
        calculator.verifyResult(args.expectedResult);
    },
}
