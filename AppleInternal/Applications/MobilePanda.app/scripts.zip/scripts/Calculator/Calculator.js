load('UIAApp.js');
load('SpringBoard.js');

if (typeof calculator !== 'undefined') {
    if (!(calculator instanceof UIAApp)) {
        throw new UIAError("calculator has already been defined to something not an instance of UIAApp! Value: %0".format(calculator));
    }
    if (calculator.bundleID() !== 'com.apple.calculator') {
        var oldDefinition = calculator.bundleID();
        var calculator = target.appWithBundleID('com.apple.calculator');
        UIALogger.logWarning("'calculator' was redefined from '%0' to '%1'".format(oldDefinition, calculator.bundleID()));
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common calculator queries */
UIAQuery.Calculator = {
    /** 'Result' Static text */
    RESULT:     UIAQuery.query("Result"),

    /** 'clear' button */
    CLEAR:      UIAQuery.buttons("clear"),

    /** 'all clear' button */
    ALL_CLEAR:  UIAQuery.buttons("all clear"),

    /** 'plus, minus' button */
    PLUS:       UIAQuery.buttons("plus, minus"),

    /** 'percent' button */
    PERCENT:    UIAQuery.buttons("percent"),

    /** 'divide' button */
    DIVIDE:     UIAQuery.buttons("divide"),

    /** 'multiply' button */
    MULTIPLY:     UIAQuery.buttons("multiply"),

    /** 'subtract' button */
    SUBTRACT:     UIAQuery.buttons("subtract"),

    /** 'add' button */
    ADD:     UIAQuery.buttons("add"),

    /** 'decimal' button */
    DECIMAL:     UIAQuery.buttons("decimal"),

    /** 'equals ' button */
    EQUALS:     UIAQuery.buttons("equals"),

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Calculator */
UIStateDescription.Calculator = {
/** Standard */
    STANDARD:              'standard',

/** Scientific */
    SCIENTIFIC:            'scientific',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

//Need list of constants to map from x or * to MULTIPLY

/**
    @namespace
    @augments UIAApp
*/
var calculator = target.appWithBundleID('com.apple.calculator');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Calculator for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
calculator.currentUIState = function currentUIState() {
    throw new UIAError('Not yet implemented.');
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Calculate
 *
 * @param {string} calculation - The calculation to preform. i.e. "1+1"
 */
calculator.calculate = function calculate(calculation, shouldClear) {
    this.getToAppTopLevel();

    if (shouldClear) {
        this.clear();
    }

    for (var i = 0; i < calculation.length; i++) {
        var curChar = calculation[i];
        switch (curChar) {
            case '*':
            case 'x':
            case 'X':
                this.tap(UIAQuery.Calculator.MULTIPLY);
                break;
            case '/':
                this.tap(UIAQuery.Calculator.DIVIDE);
                break;
            case '+':
                this.tap(UIAQuery.Calculator.ADD);
                break;
            case '-':
                this.tap(UIAQuery.Calculator.SUBTRACT);
                break;
            case '=':
                this.tap(UIAQuery.Calculator.EQUALS);
                break;
            case '%':
                this.tap(UIAQuery.Calculator.PERCENT);
                break;
            case '.':
                this.tap(UIAQuery.Calculator.DECIMAL);
                break;
            default:
                this.tap(curChar);
                break;
        }
    }
    if (curChar != '=') {
        this.tap(UIAQuery.Calculator.EQUALS);
    }
}

/**
 * Verify Result
 *
 * @param {string} expectedResult - The expected result of a calculation
 */
calculator.verifyResult = function verifyResult(expectedResult) {
    if (expectedResult != this.displayedNumber()) {
        throw new UIAError("Did not find the expected result.");
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialCalculatorNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Clear the current calculation
 */
calculator.clear = function clear() {
    this.tap(UIAQuery.Calculator.CLEAR.orElse(UIAQuery.Calculator.ALL_CLEAR));
}

/**
 * Returns the currently displayed number
 *
 * @returns {string} the number currently displayed
 */
calculator.displayedNumber = function displayedNumber() {
    var snapshot = this.inspect(UIAQuery.Calculator.RESULT);
    if (!snapshot) {
        throw new UIAError("Issue getting calculator snapshot");
    }
    var number = snapshot.value;
    return number.split(",").join("");
}

/**
 * Navigation control. Gets to top level of app.
 */
calculator.getToAppTopLevel = function getToAppTopLevel() {
    this.launch();
}

