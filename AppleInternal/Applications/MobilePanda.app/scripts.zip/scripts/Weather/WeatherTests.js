
load('UIATesting.js');
load('SpringBoard.js');
load('Weather.js');


if (typeof WeatherTests !== 'undefined') {
    throw new UIAError("Namespace 'WeatherTests' has already been defined.");
}

/**
 * @namespace WeatherTests
 */
var WeatherTests = {

    /**
     * Performs an Orb peek gesture on a city and verifies that the peek view appears.
     * 
     * @targetApps MobileWeather
     *
     * @param {object} args Test arguments
     * @param {string} [args.cityName="New York"] - Name of the city to peek on.
     */
    peekForCityInfo: function peekForCityInfo(args) {
        args = UIAUtilities.defaults(args, {
            cityName: "New York",
        });

        var id = {predicate: 'TRUEPREDICATE'};

        weather.getToView(UIStateDescription.Weather.CITY_LIST);

        var cityNameQuery = UIAQuery.withPredicate("name beginswith '%0'".format(args.cityName));
        var cityQuery = UIAQuery.buttons().isVisible().andThen(cityNameQuery);

        weather.touchDownForPeekGesture(cityQuery);

        var inPeekView = (weather.currentUIState() === UIStateDescription.Weather.CITY_PEEK);
        var cityNameInPeekView = weather.exists(UIAQuery.Weather.CITY_PEEK_VIEW.andThen(cityNameQuery));

        weather.releaseTouches();

        UIAUtilities.assert(
            inPeekView,
            'We are not in the peek view.'
        );

        UIAUtilities.assert(
            cityNameInPeekView,
            "Peek view doesn't contain information for the expected city."
        );
    },

    /**
     * Performs an Orb pop gesture on a city and verifies that the detail view appears.
     * 
     * @targetApps MobileWeather
     *
     * @param {object} args Test arguments
     * @param {string} [args.cityName="New York"] - Name of the city to peek on.
     */
    popForCityDetails: function popForCityDetails(args) {
        args = UIAUtilities.defaults(args, {
            cityName: "New York",
        });

        var id = {predicate: 'TRUEPREDICATE'};

        weather.getToView(UIStateDescription.Weather.CITY_LIST);

        var cityNameQuery = UIAQuery.withPredicate("name beginswith '%0'".format(args.cityName));
        var cityQuery = UIAQuery.buttons().isVisible().andThen(cityNameQuery);

        weather.touchForPopGesture(cityQuery);

        var inPeekView = (weather.currentUIState() === UIStateDescription.Weather.CITY_PEEK);
        var cityNameInPeekView = weather.exists(UIAQuery.Weather.CITY_PEEK_VIEW.andThen(cityNameQuery));


        UIAUtilities.assert(
            weather.currentUIState() === UIStateDescription.Weather.CITY_DETAIL,
            'We are not in the city detail view.'
        );

        UIAUtilities.assert(
            weather.exists(cityNameQuery),
            "Detail view doesn't contain information for the expected city."
        );
    },

    /**
     * Swipes to a location in Weather App's saved cities
     *
     * @targetApps MobileWeather
     * 
     * @param {object} args Test arguments
     * @param {string} [args.city="North Pole"] - Name of city to be added e.g., Denver or Atlanta
     *
     * @throws Error if city cannot be found
     */
    swipeToCity: function swipeToCity(args){
        //default arguments
        args = UIAUtilities.defaults(args, {
            city: 'North Pole',
        });

        //launch the weather app
        weather.launch();
        
        //swipe to city
        weather.swipeToCity(args.city);

        //validate city was found
        UIAUtilities.assert(weather.getCurrentCity() === args.city, 
          "Cannot swipe to " + args.city +" because it was not found."
        );

    },

    /**
     * Removes a city in Weather App's saved cities
     *
     * @targetApps MobileWeather
     *
     * @param {object} args Test arguments
     * @param {string} [args.city="North Pole"] - Name of city to be added e.g., Denver or Atlanta
     * throws Error if city could not be deleted or found to be deleted
     */
    deleteCity: function deleteCity(args){
        //default arguments
        args = UIAUtilities.defaults(args, {
            city: 'North Pole',
        });

        //launch weather app
        weather.launch();

        //delete city from edit cities view
        weather.deleteCity(args.city);

        //validate city was deleted
        weather.getToView(UIStateDescription.Weather.CITY_LIST);
        UIAUtilities.assert(!weather.exists(UIAQuery.contains(args.city)), 
          args.city +" still exists in saved cities, not deleted or multiple cities with name exist."
        );


    },

    /**
     * Adds a city in Weather App's saved cities
     *
     * @targetApps MobileWeather
     *
     * @param {object} args Test arguments
     * @param {string} [args.city="North Pole"] - Name of city to be added e.g., Denver, CO or Atlanta, GA
     * @param {string} [args.country="United States"] - (optional) Name of country to be added 
     * (allows partial matches, adds first matched city)
     */
    addCity: function addCity(args) {

        //default arguments
        args = UIAUtilities.defaults(args, {
            city: 'North Pole',
            country: 'United States'
        });


        //launch weather app
        weather.launch();

        //delete city from edit cities view
        weather.addCity(args);

        //validate city was added
        weather.getToView(UIStateDescription.Weather.CITY_LIST);
        UIAUtilities.assert(weather.exists(UIAQuery.contains(args.city)), "City: " + 
          args.city + " was not added to save cities in app."
        );

        //TODO Handle case with multiple cities with same name
    },
     


    /**
     * Travel to the weather channel site on safari
     *
     * @targetApps MobileWeather MobileWeb
     *
     * @param {object} args Test arguments
     */
    goToWeatherChannelPage: function goToWeatherChannelPage(args) {
      //default arguments
        args = UIAUtilities.defaults(args, {
        });

        //launch weather app
        weather.launch();

        //use safari to check if traveled weather page
        weather.goToWeatherChannelPage();
        
    },

    /**
     * Scrolls through hourly and daily forecasts for a specified city 
     *
     * @targetApps MobileWeather 
     *
     * @param {object} [args] Test arguments 
     * @param {string} [args.cityName="New York"] - Name of the city to get weather details for
     * 
     * @alertHandlers weather.allowLocationServicesAlertHandler 
     */
    checkCityWeather: function checkCityWeather(args) {
        args = UIAUtilities.defaults(args, {
              cityName: 'New York', 
        });

        // Launch Weather app
        weather.launch();
        // Navigate to a detail view of specified city
        weather.navigateToCity(args.cityName);
        // Scroll hourly forecasts horizontally 
        weather.scrollHourlyForecast();
        // Scroll daily forecast vertically 
        weather.scrollDailyForecast();
    },
};
