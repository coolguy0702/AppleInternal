load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('Safari.js');

UIAUtilities.assert(
    typeof weather === 'undefined',
    'weather has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Weather queries */
UIAQuery.Weather = {

    /** Visable location paging **/
    CITY_DETAIL_PAGEINDICATOR: UIAQuery.pageIndicators().isVisible(),

    /** Weather Channel Button **/
    WEATHER_CHANNEL_BUTTON: UIAQuery.buttons('The Weather Channel').isVisible(),

    /** Edit Cities button. Goes to the cities list view. */
    EDIT_CITIES_BUTTON: UIAQuery.buttons('Edit Cities').isVisible(),

    /** Add City button. Goes to the add a city view. */
    ADD_CITY_BUTTON: UIAQuery.buttons('Add City').isVisible(),

    /** In Edit Screen Tempurature F/C Scale**/
    TEMPURATURE_SCALE_BUTTON: UIAQuery.buttons('Temperature scale').isVisible(),

    /** Text above the search box in the add city view */
    SEARCH_HEADER: UIAQuery.query('Enter city, zip code, or airport location').isVisible(),

    /** Peek view presented when Orb touching on a city in the list view */
    CITY_PEEK_VIEW: UIAQuery.query('UITransitionView').andThen('WAWeatherCityView'),

    /** City Colleciton View (used for swiping between cities) **/
    CITY_COLLECTION: UIAQuery.collectionViews('UICollectionView'),

    /** Weahter city view query **/
    WEATHER_CITY_VIEW: UIAQuery.query('WAWeatherCityView').isVisible(),

    /** Hourly forecasts scroll belt */
    HOURLY_FORECASTS_SCROLL: UIAQuery.query('HourlyScrollerBeltView').isVisible(),

    /** Daily forecast scroll view */
    DAILY_FORECAST_SCROLL: UIAQuery.query('UIScrollView').isVisible().andThen(UIAQuery.withPredicate('label CONTAINS "Daily Forecasts"')),

    /* Queries for weather specific alerts */
    Alerts: {
        ALWAYS_ALLOW_BUTTON:                    UIAQuery.buttons('Always Allow'),
        ALLOW_LOCATION_SERVICES:                UIAQuery.alerts().contains('Allow “Weather” to access your location?'),
    },
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Clock */
UIStateDescription.Weather = {
    /**  City List */
    CITY_LIST: 'City List',

    /**  City Detail */
    CITY_DETAIL: 'City Detail',
    
    /**  City Peek View */
    CITY_PEEK: 'City Peek',

    /**  Add City */
    ADD_CITY: 'Add City',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

Labels = {

};

/**
 * @namespace {UIAApp} weather
 */
var weather = target.appWithBundleID('com.apple.weather'); 


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Weather for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
weather.currentUIState = function currentUIState() {

    if (this.exists(UIAQuery.Weather.CITY_PEEK_VIEW)) {
        return UIStateDescription.Weather.CITY_PEEK;
    } else if (this.exists(UIAQuery.Weather.EDIT_CITIES_BUTTON)) {
        return UIStateDescription.Weather.CITY_DETAIL;
    } else if (this.exists(UIAQuery.Weather.ADD_CITY_BUTTON)) {
        return UIStateDescription.Weather.CITY_LIST;
    } else if (this.exists(UIAQuery.Weather.SEARCH_HEADER)) {
        return UIStateDescription.Weather.ADD_CITY;
    } else {
        throw new UIAError('Unrecognized application state.');
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets to a specified view in the Weather application.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} viewName - Name of view/UI state.
 *
 * @returns none
 */
weather.getToView = function getToView(viewName) {
    this.launch();

    //If in Add City mode, trying to get to other state hit cancel button
    if (this.currentUIState() === UIStateDescription.Weather.ADD_CITY && viewName !==  UIStateDescription.Weather.ADD_CITY) {
        this.tap(UIAQuery.CANCEL_BUTTON);
    }

    //Don't move to other UIState if not needed
    if (this.currentUIState() === viewName) {
        return;
    }
    
    switch (viewName) {
        case UIStateDescription.Weather.CITY_LIST:
            this.tap(UIAQuery.Weather.EDIT_CITIES_BUTTON);
            break;
        case UIStateDescription.Weather.ADD_CITY:
            this.tapIfExists(UIAQuery.Weather.EDIT_CITIES_BUTTON);
            this.tap(UIAQuery.Weather.ADD_CITY_BUTTON);
            break;
        case UIStateDescription.Weather.CITY_DETAIL:
        case UIStateDescription.Weather.CITY_PEEK:
            throw new UIAError('View "%0" is not a uniquely identifiable view. Could not navigate to it.'.format(viewName));
            break;
        default:
            throw new UIAError('View "%0" is not a reconized view. Could not navigate to it.'.format(viewName));
    }
}

/**
 * Gets to the detail view for the specified city in the Weather application.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} cityName - Name of the city to view.
 *
 * @returns none
 */
weather.getToDetailViewForCity = function getToDetailViewForCity(cityName) {
    this.getToView(UIStateDescription.Weather.CITY_LIST);

    var cityQuery = UIAQuery.buttons().isVisible().andThen(UIAQuery.withPredicate('name beginswith "%0"'.format(cityName)));

    this.tap(cityQuery);
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


/**
 * Performs navigation to city within app.
 * 
 * @param {string} city - City to be navigated to.
 * @throws error if does not exist in saved cities
 */
 weather.navigateToCity = function navigateToCity(city) {

    if (this.currentUIState() === UIStateDescription.Weather.CITY_DETAIL) {
        this.swipeToCity(city);
    }
    else{
        this.tapToCity(city);
    }

 }

/**
 * Performs swipe to city within app. 
 * Requires the view to be in paged cities view.
 * 
 *
 * @param {string} city - City to be navigated to.
 * @throws error if does not exist in saved cities
 */
weather.swipeToCity = function swipeToCity(city) {
    //navigate to paged cities view
    this.getToView(UIStateDescription.Weather.CITY_DETAIL);

    var cityPageCount = this.getSavedCitiesCount();
    var currentPageIndex = this.getCurrentCityIndex();


    //walk backwards and try to find city
    var index = this.getCurrentCityIndex()

    var LOOP_BOUND = 20;
    
    while (index > 0 && LOOP_BOUND > 0) {

        if (this.getCurrentCity() === city) {
            return;
        }
        UIALogger.logMessage('Swiping to City at index: ' + index + ' out of: ' + cityPageCount);
        //swipe backward

        this.swipeToPreviousCity();
        index = this.getCurrentCityIndex();

        LOOP_BOUND--;
    }

    if (LOOP_BOUND === 0) {
        throw new UIAError('Reached Loop Bound Limit Uncontrolled Function');
    }

    LOOP_BOUND = 20;

    while (index < cityPageCount && LOOP_BOUND > 0) {

        if (this.getCurrentCity() === city) {
            return;
        }
        UIALogger.logMessage('Swiping to City at index: ' + index + ' out of: ' + cityPageCount);
        //swipe forward
        this.swipeToNextCity();
        index = this.getCurrentCityIndex();

        LOOP_BOUND--;
    }

    if (LOOP_BOUND === 0) {
        throw new UIAError('Reached Loop Bound Limit Uncontrolled Function');
    }
    
    throw new UIAError('City: ' + city + ' could not be found in paged cities view');
    return;
}

/**
 * Delete city from the saved city list
 * Requires nothing.
 * @throws error if city is not saved in app.
 *
 * @param {string} city - City to be deleted.
 *
 */
 weather.deleteCity = function deleteCity(city) {
    //go to edit mode
    this.getToView(UIStateDescription.Weather.CITY_LIST);

    var cityQuery = UIAQuery.contains(city);
    //Find if city is available
    if (!this.exists(cityQuery)) {
        throw new UIAError('City: '+city+' could not be found in edit cities view');
        //TODO better validation of city example city = 'new' would delete 'new york' or 'new orleans'
    }

    var options = {fromOffset: {x: 0.75, y: 0.5}, toOffset: {x: 0.25, y: 0.5}}
    //swipe to display delete
    this.drag(cityQuery,options);

    //press the delete button
    this.tap('Delete');

 }

/**
 * Add city to the saved city list
 * Requires nothing.
 * 
 *
 * @param {object} args Test arguments
 * @param {string} [args.city="North Pole"] - the name of city to be added e.g., Denver, CO or Atlanta, GA
 * @param {string} [args.country="United States"] - (optional) the name of country to be added 
 * (allows partial matches, adds first matched city)
 */
weather.addCity = function addCity(options) {
    //go to edit mode
    this.getToView(UIStateDescription.Weather.CITY_LIST);

    //go to add cities button
    this.tap(UIAQuery.Weather.ADD_CITY_BUTTON);

    var searchText = options.city;

    if (options.country !== null)
        searchText += ', ' + options.country;

    //type the city name into the keyboard
    //check if keyboard is active
    this.search(searchText);


    if (!UIAQuery.staticTexts().first().isVisible()) {
        throw new UIAError('No city: '+city+' was found in add cities search view');
    }
    //select first cell in the search should throw error if nothing found
    this.tap(UIAQuery.staticTexts().first());

 },


/**
 * Press the Weather Channel Page Button
 * Requires nothing.
 * @throws error if button could not be found
 */
 weather.goToWeatherChannelPage = function goToWeatherChannelPage() {

    //get options for validatino query and timeout
    var options = {
    
        loadTimeout:    140,
        loadedContent:  UIAQuery.contains('The Weather Channel'),

    }

    //use safri to load weather channel page
    safari.loadPageWith(function() {

        weather.tap(UIAQuery.Weather.WEATHER_CHANNEL_BUTTON);

    }, options);
 }

 /**
  * Scrolling through hourly forecasts 
  * Requires the view to be in weather city view.
  * 
  * @throws error if not in city detail view.
  */
 weather.scrollHourlyForecast = function scrollHourlyForecast() {
    // Check if in correct view (state) to scroll hourly forecasts
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in weather city detail view in order to scroll hourly forecasts');
    }

    // Scroll options (right to left)
    var r2lOptions = {fromOffset: {x: 1.00, y: 0.60}, toOffset: {x: 0.00, y: 0.60}};

    // Scroll options (left to right)
    var l2rOptions = {fromOffset: {x: 0.00, y: 0.60}, toOffset: {x: 1.00, y: 0.60}};

    // Scroll left
    this.drag(UIAQuery.Weather.HOURLY_FORECASTS_SCROLL, r2lOptions);
    // Scroll right
    this.drag(UIAQuery.Weather.HOURLY_FORECASTS_SCROLL, l2rOptions);
 }

 /**
  * Scrolling through daily forecast 
  * Requires the view to be in weather city view.
  * 
  * @throws error if not in city detail view.
  */
 weather.scrollDailyForecast = function scrollDailyForecast() {
    // Check if in correct view (state) to scroll daily forecasts
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in weather city detail view in order to scroll hourly forecasts');
    }

    // Scroll options (bottom to top)
    var b2tOptions = {fromOffset: {x: 0.50, y: 0.80}, toOffset: {x: 0.50, y: 0.00}, duration: 0.8};

    // Scroll options (top to bottom)
    var t2bOptions = {fromOffset: {x: 0.50, y: 0.20}, toOffset: {x: 0.50, y: 1.00}, duration: 0.8};

    // Scroll up
    this.drag(UIAQuery.Weather.DAILY_FORECAST_SCROLL, b2tOptions);
    // Scroll down
    this.drag(UIAQuery.Weather.DAILY_FORECAST_SCROLL, t2bOptions);
 }

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Navigate back to the top level of app.
 */
weather.returnToTopLevel = function returnToTopLevel() {
    if (this.exists(UIAQuery.VISIBLE_POPOVERS)) {
        this.dismissPopover();
    }

    this.tapIfExists(UIAQuery.CANCEL_BUTTON);
    this.tapIfExists(UIAQuery.buttons('Done'));
}

/**
 * Performs swipe to next city within app. 
 * Requires the view to be in paged cities view.
 *
 * @throws error if not in paged cities view.
 */
weather.swipeToNextCity = function swipeToNextCity() {
    //check if in correct view (state) to swipe to next city
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in paged cities view in order to swipe to next city');
    }

    //drag options (right to left)
    var r2lOptions = {fromOffset: {x: 1.00, y: 0.85}, toOffset: {x: 0.00, y: 0.85}};

    //swipe
    this.drag(UIAQuery.Weather.CITY_COLLECTION,r2lOptions);
}

/**
 * Performs swipe to previous city within app. 
 * Requires the view to be in paged cities view.
 * 
 * @throws error if not in paged cities view.
 *
 */
weather.swipeToPreviousCity = function swipeToPreviousCity() {
    
    //check if in correct view (state) to swipe to next city
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in paged cities view in order to swipe to previous city');
    }

    //drag options (left to right)
    var l2rOptions = {fromOffset: {x: 0.00, y: 0.85}, toOffset: {x: 1.00, y: 0.85}};

    //swipe 
    this.drag(UIAQuery.Weather.CITY_COLLECTION,l2rOptions);
}

/**
 * Performs tap navigation through edit screen to city within app. 
 * 
 *
 * @param {string} city - City to be navigated to.
 * @throws error if does not exist in saved cities
 */
weather.tapToCity = function tapToCity(city) {
    //navigate to paged cities view
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_LIST) {
        this.getToView(UIStateDescription.Weather.CITY_LIST);
    }
    //if city is not available
    if (!this.exists(UIAQuery.contains(city))) {
        throw new UIAError('City: '+city+' could not be found in edit cities view');
    }
    //tap city
    this.tap(UIAQuery.contains(city).isVisible());
}

/**
 * Calculates current city index in paged view
 * Requires the view to be in paged cities view.
 * 
 * @returns {number} string of current index
 * @throws error if not in paged cities view.
 */
weather.getCurrentCityIndex = function getCurrentCityIndex() {
    //check if in correct view (state) to swipe to next city
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in paged cities view in order to get index');
    }
    
    if (!this.exists(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR)) {
        throw new UIAError('Cannot find Page Indicator To Abstract Information');
    }

    //Get City Index 'Cupertino, city [1] of 3'
    var indexes = this.inspect(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR).value.match(/\d+/g);
    return indexes[0] - 1;
}

/**
 * Returns current city in paged view
 * Requires the view to be in paged cities view. 
 *
 * @returns {string} string of current city
 * @throws error if not in paged cities view.
 */
 weather.getCurrentCity = function getCurrentCity() {
    //check if in correct view (state) to swipe to next city
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in paged cities view in order to get city numbers');
    }
    
    if (!this.exists(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR)) {
        throw new UIAError('Cannot find Page Indicator To Abstract Information');
    }


    //Get City Index 'Cupertino, city 1 of 3'
    return this.inspect(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR).value.split(',')[0];
}

/**
 * Calculates number of cities in paged view
 * Requires the view to be in paged cities view.
 * 
 * @returns {number} string of current size
 *
 * @throws error if not in paged cities view.
 * 
 */
weather.getSavedCitiesCount = function getCurrentCityIndex() {
    //check if in correct view (state) to swipe to next city
    if (this.currentUIState() !== UIStateDescription.Weather.CITY_DETAIL) {
        throw new UIAError('App must be in paged cities view in order to get city numbers');
    }
    
    if (!this.exists(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR)) {
        throw new UIAError('Cannot find Page Indicator To Abstract Information');
    }
    //Get City Count 'Cupertino, city 1 of [3]'
    var indexes = this.inspect(UIAQuery.Weather.CITY_DETAIL_PAGEINDICATOR).value.match(/\d+/g);
    return indexes[1];

    //TODO: Add ability to get count when in edit mode
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Handlers                                                            */
/*                                                                             */
/*      Alert handlers for the app. e.g. safari.accessContactsAlertHandler     */
/*                                                                             */
/*******************************************************************************/

/**
 * Handles Allow Location Services alert that appears on first launch of Weather app
 *
 * @returns {boolean} true if an alert was handled 
 */
weather.allowLocationServicesAlertHandler = function allowLocationServicesAlertHandler() {
    var app = target.activeApp();
    var alertQuery = UIAQuery.Weather.Alerts.ALLOW_LOCATION_SERVICES;
    if (app.exists(alertQuery)) {
        var alert = app.inspect(alertQuery);
        if (alert && alert.label) {
            UIALogger.logMessage('Received \'%0\' Alert'.format(alert.label));
            UIALogger.logMessage('Trying to dismiss \'%0\' Alert'.format(alert.label));
        }
        return app.tapIfExists(UIAQuery.Weather.Alerts.ALWAYS_ALLOW_BUTTON);
    } 
    return false;
};