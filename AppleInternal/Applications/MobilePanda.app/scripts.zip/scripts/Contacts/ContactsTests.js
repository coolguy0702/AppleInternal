load('UIATesting.js');
load('Contacts.js');
load('SpringBoard.js');
load('UIAApp+AddressBook.js');

if (typeof ContactsTests === 'undefined') {
    /**
     * @namespace
     */
    var ContactsTests = {


        /**
         * Add a new contact to the addressbook and validate it.
         *
         * @targetApps Contacts
         *
         * @param {object} args - Test arguments
         * @param {string} [args.firstName="TestFirstName"] - Required first name of new contact
         * @param {string} [args.lastName="TestLastName"] - Optional last name of new contact
         * @param {string} [args.company=null] - Optional company of the new contact
         * @param {string} [args.phone=null] - Optional Phone number of the contact
         * @param {string} [args.email=null] - Optional Email of the contact
         * @param {string} [args.url=null] - Optional URL of the contact
         */
         newContact: function newContact(args) {
            args = UIAUtilities.defaults(args, {
                firstName: "TestFirstName",
                lastName: "TestLastName",
                company: null,
                phone: null,
                email: null,
                url: null,
            });
            contacts.getToMainScreen();
            var fullName = contacts.generateFullName(args.firstName,args.lastName);
            var curNumContacts = contacts.getNumSearchResults(fullName);
            contacts.getToMainScreen();
            contacts.addNewContact(args);
            contacts.validateContact(args);
            contacts.getToMainScreen();
            var newNumContacts = contacts.getNumSearchResults(fullName);
            if (newNumContacts-curNumContacts != 1) {
                throw new UIAError("Did not find the expected number of contacts. Found: %0 Expected: %1".format(newNumContacts, curNumContacts+1), {identifier:"Did not find the expected number of contacts."});
            }
         },
         /**
         * Edit a contact in the addressbook and validate the changes.
         *
         * @targetApps Contacts
         *
         * @param {object} args - Test arguments
         * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
         * @param {string} [args.firstName=null] - Optional first name of new contact
         * @param {string} [args.lastName="EditedLastName"] - Optional last name of new contact
         * @param {string} [args.company=null] - Optional company of the new contact
         * @param {string} [args.phone=null] - Optional Phone number of the contact
         * @param {string} [args.email=null] - Optional Email of the contact
         * @param {string} [args.url=null] - Optional URL of the contact
         */
         editContact: function editContact(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                firstName: null,
                lastName: "EditedLastName",
                company: null,
                phone: null,
                email: null,
                url: null,
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.editContact(args);
            contacts.validateContact(args);
         },
         /**
         * Flicks the contact list up and down.
         * (Adds two contacts if there aren't enough to enable flicking)
         *
         * @targetApps Contacts
         *
         * @param {object} args - Test arguments
         * @param {boolean} [args.addContacts="true"] - Optional adds 2 more contacts if there are not enough to flick
         */
         flickContactList: function flickContactList(args) {
            args = UIAUtilities.defaults(args, {
              addContacts: true,
            })
            contacts.getToMainScreen();

            var numContacts = contacts.count(UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells()));
            UIALogger.logMessage("Num Contacts: " + numContacts); // print the number of contacts in the table
            if (numContacts < 2) {
              if (args.addContacts) {
                UIALogger.logMessage("Not enough contacts in the list, adding two more.");
                contacts.addNewContact({firstName:"Randy",lastName:"Lahey"});
                contacts.addNewContact({firstName:"Corey",lastName:"Trevor"});
                contacts.getToMainScreen();
              } else {
                throw new UIAError("Not enough contacts in the list");
              }

            }

            // TODO: move all of this flicking logic into a library function
            var visibleCells = UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells().isVisible());
            var firstFullCell = visibleCells.atIndex(0);
            var lastFullCell = visibleCells.atIndex(contacts.count(UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells().isVisible()))-1);
            for (var i = 0; i < 3; i++) {
                // now flick the second table cell that is currently visible // using the first sometimes results in tapping the search bar
                contacts.flick(lastFullCell, {toQuery: firstFullCell, duration: 0.05});
            }
            for (var i = 0; i < 3; i++) {
                contacts.flick(firstFullCell, {toQuery:lastFullCell, duration: 0.05});
            }
         },
         /**
          * Select specified contact from contact list.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          */
          selectContact: function selectContact(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
            });
            contacts.getToMainScreen();
            // check if we can scroll to the specifiec contact
            contacts.search(args.searchString);
          },
         /**
          * Adds a new phone number to the specified contact and validates it.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.phone=null] - Optional Phone number of the contact
          */
          addNewPhoneNumber: function addNewPhoneNumber(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                phone: "4085555555",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.editContact(args);
            contacts.validateContact(args);
          },
         /**
          * Adds a new email to the specified contact and validates it.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.email=null] - Optional Phone number of the contact
          */
          addNewEmail: function addNewEmail(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                email: "TestEmailAccount@icloud.com",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.editContact(args);
            contacts.validateContact(args);
          },
         /**
          * Adds a photo to the specified contact.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.method="Take"] - Optional method to add photo to the contact ("Take" or "Choose")
          */
          addPhoto: function addPhoto(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                method: "Take",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.addPhoto(args.method);
          },
         /**
          * Shares the specified contact via mail.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.email="john_mccabe@apple.com"] - Optional email address to send the contact card to
          */
          mailContactCard: function shareContactCardMail(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                email: "john_mccabe@apple.com",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.shareContactCard("Mail",args.email);

            throw new UIAError("Test not fully implemented.");
          },
         /**
          * Shares the specified contact via messages.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.phoneNumber="2155275839"] - Optional phone number to send the contact card to
          */
          messageContactCard: function shareContactCardMessage(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                phoneNumber: "2155275839",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.shareContactCard("Message",args.phoneNumber);

            throw new UIAError("Test not fully implemented.");
          },

         /**
          * Send text message to the specified contact.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.searchString="TestFirstName"] - Required search string to find desired contact
          * @param {string} [args.message="Test Message"] - Optional text message to send to the contact
          */
          messageContact: function messageContact(args) {
            args = UIAUtilities.defaults(args, {
                searchString: "TestFirstName",
                message: "Test Message",
            });
            contacts.getToMainScreen();
            contacts.search(args.searchString);
            contacts.messageContact(args.message);
          },

         /**
          * Delete the specified contact and checks that there is one less contact.
          *
          * @targetApps Contacts
          *
          * @param {object} args - Test arguments
          * @param {string} [args.firstName="TestFirstName"] - Required first name of new contact
          * @param {string} [args.lastName=null] - Optional last name of new contact
          */
          deleteContact: function deleteContact(args) {
            args = UIAUtilities.defaults(args, {
                firstName: "NewFirstName",
                lastName: null,
            });
            contacts.getToMainScreen();
            var fullName = contacts.generateFullName(args.firstName,args.lastName);
            var curNumContacts = contacts.getNumSearchResults(fullName);
            if (curNumContacts == 0) {
                throw new UIAError("No matching contact to delete.");
            }
            contacts.search(fullName);
            contacts.deleteContact();

            var newNumContacts = contacts.getNumSearchResults(fullName);
            if (curNumContacts-newNumContacts != 1) {
                throw new UIAError("Did not find the expected number of contacts. Found: %0 Expected: %1".format(newNumContacts, curNumContacts-1), {identifier:"Did not find the expected number of contacts."});
            }
          },

        /**
         * Verifies the number of contacts.
         *
         * @targetApps Contacts
         *
         * @param {object} args - Test arguments
         * @param {integer} [args.numContacts=15] - Number of contacts to verify
         */
        verifyNumberOfContacts: function verifyNumberOfContacts(args) {
            args = UIAUtilities.defaults(args, {
                numContacts: 15,
            });
            contacts.getToMainScreen();
            contacts.verifyNumberOfContacts(args.numContacts);
        },

    }
}
