load('UIAApp.js');
load('UIAApp+AddressBook.js');
load('Messages.js');
load('SpringBoard.js');

if (typeof contacts !== 'undefined') {
    if (!(contacts instanceof UIAApp)) {
        throw new UIAError("contacts has already been defined to something not an instance of UIAApp! Value: %0".format(contacts));
    }
    if (contacts.bundleID() !== 'com.apple.MobileAddressBook') {
        var oldDefinition = contacts.bundleID();
        var contacts = target.appWithBundleID('com.apple.MobileAddressBook');
        UIALogger.logWarning("'contacts' was redefined from '%0' to '%1'".format(oldDefinition, contacts.bundleID()));
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Contacts Query Constants                                            */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIAQuery.Contacts = {
    /** Navigation bar with 'All Contacts' title */
    ALL_CONTACTS_NAVBAR: UIAQuery.navigationBars(LocStrings.ALL_CONTACTS),

    /** Navigation bar with 'Contacts' title */
    CONTACTS_NAVBAR: UIAQuery.navigationBars('Contacts').orElse(UIAQuery.navigationBars('People')),

    CONTACT_INFO_CARD: UIAQuery.query('CNContactHeaderDisplayView').orElse(UIAQuery.tableViews('CNContactView')),

    VISIBLE_EDIT_BUTTON: UIAQuery.buttons('Edit').isVisible(),

    ADD_ADDRESS_BUTTON: UIAQuery.tableCells(LocStrings.ADD_ADDRESS).andThen(UIAQuery.buttons()),

    ADD_URL_BUTTON: UIAQuery.tableCells(LocStrings.ADD_URL).andThen(UIAQuery.buttons()),

    SEARCH_BAR: UIAQuery.searchBars('SearchBar'),
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Contacts UI State Constants                                         */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIStateDescription.Contacts = {
    /** Contacts in top-most view */
    MAIN_VIEW:              'main view',

    /** New Contact view */
    NEW_CONTACT:            'add new contact',

    /** Label choosing view for a contact field */
    LABEL:                  'label view',

    /** Ringtone selection view for a contact */
    RINGTONE:               'ringtone view',

    /** Text tone selection view for a contact */
    TEXT_TONE:              'text tone view',

    /** Vibration selection view for a contact */
    VIBRATION:              'vibration view',

    /** New vibration selection view for a contact */
    NEW_VIBRATION:          'new vibration',

    /** View for selecting classic ringtones, text tones, or vibrations */
    CLASSIC:                'classic view',

    /** Country select view for a contact */
    COUNTRY:                'country selection',

    /** Birthday calendar select view for a contact */
    BIRTHDAY_CALENDAR:      'birthday calendar',

    /** Social media select view for a contact */
    SOCIAL_MEDIA:           'social media',

    /** Instant message select view for a contact */
    INSTANT_MESSAGE:        'instant message',

    /** Add a field view for a contact */
    ADD_FIELD:              'add field',

    /** Link contacts for a contact */
    /* NOTE: Not supported due to the navigation bar for this and the main
    /*  view being the same without a good way to differentiate between the two. */
    // LINK_CONTACTS:          'link contacts',

    /*  Contact information view */
    CONTACT_INFO_VIEW:      'contact info',

    /*  view of external contact e.g. from siri */
    EXTERN_CONTACT_INFO_VIEW: 'extern contact info',

    /** Contact edit view */
    CONTACT_EDIT_VIEW:      'contact edit',

    /** Search view */
    SEARCH:                 'search contact',

};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var contacts = target.appWithBundleID('com.apple.MobileAddressBook');



/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state. See Contacts UIStateDescription constants
* for possible values. Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Contacts UIStateDescription.
*
* @throws If cannot determine state.
*/
contacts.currentUIState = function currentUIState() {
    var navBarName = null;
    if (this.exists(UIAQuery.Contacts.SEARCH_BAR) && this.exists(UIAQuery.navigationBars('Contacts').andThen(UIAQuery.buttons('Cancel')))) {
        return UIStateDescription.Contacts.SEARCH;
    } else if (this.exists(UIAQuery.VISIBLE_NAVBARS)) {
        navBarName = this.nameOf(UIAQuery.VISIBLE_NAVBARS);
    }

    switch (navBarName) {
        case 'Contacts':
        case 'People':
            /* NOTE: 'CNContactView' should target tableViews only, as the navBar
            /*   version doesn't hold the contact info anymore. <rdar://problem/24570067> */
            if (this.exists(UIAQuery.tableViews('CNContactView'))) {
                if (this.exists(UIAQuery.buttons('Edit'))) {
                    return UIStateDescription.Contacts.CONTACT_INFO_VIEW;
                } else if (this.exists(UIAQuery.staticTexts('Create New Contact'))) {
                    return UIStateDescription.Contacts.EXTERN_CONTACT_INFO_VIEW;
                }
                return UIStateDescription.Contacts.CONTACT_EDIT_VIEW;
            }
            return UIStateDescription.Contacts.MAIN_VIEW;
        case 'New Contact':
            return UIStateDescription.Contacts.NEW_CONTACT;
        case 'CNContactView':
            /* NOTE: 'CNContactView' should target tableViews only, as the navBar
            /*   version doesn't hold the contact info anymore. <rdar://problem/24570067> */
            if (this.exists(UIAQuery.buttons('Edit'))) {
                return UIStateDescription.Contacts.CONTACT_INFO_VIEW;
            }
            return UIStateDescription.Contacts.CONTACT_EDIT_VIEW;
        case 'Label':
            return UIStateDescription.Contacts.LABEL;
        case 'Ringtone':
            return UIStateDescription.Contacts.RINGTONE;
        case 'Text Tone':
            return UIStateDescription.Contacts.TEXT_TONE;
        case 'Vibration':
            return UIStateDescription.Contacts.VIBRATION;
        case 'New Vibration':
            return UIStateDescription.Contacts.NEW_VIBRATION;
        case 'Classic':
            return UIStateDescription.Contacts.CLASSIC;
        case 'Country':
            return UIStateDescription.Contacts.COUNTRY;
        case 'Birthday Calendar':
            return UIStateDescription.Contacts.BIRTHDAY_CALENDAR;
        case 'ABPickerTableView':
            if (this.exists(UIAQuery.query('Twitter'))) {
                return UIStateDescription.Contacts.SOCIAL_MEDIA;
            } else if (this.exists(UIAQuery.query('Skype'))) {
                return UIStateDescription.Contacts.INSTANT_MESSAGE;
            }
        case 'Add Field':
            return UIStateDescription.Contacts.ADD_FIELD;
        default:
            // if we got here, we don't have no clue where we are...
            /* NOTE: Entering a Contact Card from a search actually keeps
            /*   the navbar name 'Search', even though it's a contact card!
            /*   <rdar://problem/26658638> */
            if (this.exists(UIAQuery.tableViews('CNContactView'))) {
                if (this.exists(UIAQuery.buttons('Edit'))) {
                    return UIStateDescription.Contacts.CONTACT_INFO_VIEW;
                }
                return UIStateDescription.Contacts.CONTACT_EDIT_VIEW;
            }
            throw new UIAError('Could not determine state.');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigation function to get out of auxillary states. Max iterations is 5
* because max number of actions to the main screen of contacts is 4 actions.
* Added a cushion of 1 call.
*
* Any criteria for defining a transition from a state to another state
* should be very exact. Navigation function should always get to where
* they are meant to go or throw.
*
* Expected starting states: Works for any UI state in the app.
*
* @param {object} options
* @param {string} options.currentState - Can pass a starting state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state.
*/
contacts.exitAuxillaryUIStates = function exitAuxillaryUIStates(options) {
    options = UIAUtilities.defaults(options, {
        currentState: this.currentUIState(),
    });

    var keepTrying = true;

    for (var i = 0; i < 5 && keepTrying; i++) {
        options.currentState = this.currentUIState();

        UIALogger.logMessage("Current state: '%0'".format(options.currentState));

        switch (options.currentState) {
            case UIStateDescription.Contacts.NEW_CONTACT:
            case UIStateDescription.Contacts.CONTACT_EDIT_VIEW:
            case UIStateDescription.Contacts.LABEL:
            case UIStateDescription.Contacts.RINGTONE:
            case UIStateDescription.Contacts.TEXT_TONE:
            case UIStateDescription.Contacts.NEW_VIBRATION:
            case UIStateDescription.Contacts.COUNTRY:
            case UIStateDescription.Contacts.BIRTHDAY_CALENDAR:
            case UIStateDescription.Contacts.SOCIAL_MEDIA:
            case UIStateDescription.Contacts.INSTANT_MESSAGE:
            case UIStateDescription.Contacts.ADD_FIELD:
            // case UIStateDescription.Contacts.LINK_CONTACTS:
            case UIStateDescription.Contacts.SEARCH:
                this.tap(UIAQuery.buttons('Cancel'));
                break;
            case UIStateDescription.Contacts.CONTACT_INFO_VIEW:
                if (UIATarget.localTarget().model()  === 'iPad') {
                    UIALogger.logMessage('iPad does not exit contact card views!');
                    return options.currentState;
                } else {
                    this.tap(UIAQuery.BACK_NAV_BUTTON);
                }
                break;
            case UIStateDescription.Contacts.EXTERN_CONTACT_INFO_VIEW:
                this.tapIfExists(UIAQuery.buttons().contains('Cancel'));
                this.tapIfExists(UIAQuery.query('Element').contains('My Card')); 
                break; 
            case UIStateDescription.Contacts.VIBRATION:
            case UIStateDescription.Contacts.CLASSIC:
                this.tap(UIAQuery.BACK_NAV_BUTTON);
                break;
            // If we're already out of all auxillary states, we will fall through
            default:
                keepTrying = false;
                break;
        }
    }

    // lets get the new state
    options.currentState = this.currentUIState();

    switch (options.currentState) {
        case UIStateDescription.Contacts.MAIN_VIEW:
            UIALogger.logMessage('Got out of auxillary states.');
            return options.currentState;
        default:
            throw new UIAError('Could not exit auxillary states after 5 attempts.');
    }
}

/**
* Navigate to the Main Contact View.
*/
contacts.getToMainScreen = function getToMainScreen(){
    contacts.launch();

    UIALogger.logMessage('Attempting to get to Main Contact view...');

    this.exitAuxillaryUIStates();
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Add a new contact to the address book
 *
 * @param {object} options
 * @param {string} options.firstName - First name of the contact
 * @param {string} options.lastName - Last name of the contact
 * @param {string} options.company - Company of the contact
 * @param {string} options.phone - Phone number of the contact
 * @param {string} options.email - Email of the contact
 * @param {string} options.url - URL of the contact
 * @param {null | object} options.homeAddress=null - home address of the contact
 * @param {null | object} options.workAddress=null - work address of the contact
 */
contacts.addNewContact = function addNewContact(options) {
    this.getToMainScreen();
    this.tap(UIAQuery.buttons("Add").isVisible());
    this.editContact(options);
}

/**
 * Edit the currently selected contact
 *
 * @param {object} options
 * @param {string} options.firstName - First name of the contact
 * @param {string} options.lastName - Last name of the contact
 * @param {string} options.company - Company of the contact
 * @param {string} options.phone - Phone number of the contact
 * @param {string} options.email - Email of the contact
 * @param {string} options.url - URL of the contact
 * @param {null | object} options.homeAddress=null - home address of the contact
 * @param {null | object} options.workAddress=null - work address of the contact
 */
contacts.editContact = function editContact(options) {
    if (this.currentUIState() === UIStateDescription.Contacts.NEW_CONTACT) {
        UIALogger.logMessage('Creating a new contact. No "Edit" button to tap.');
    } else {
        this.tap(UIAQuery.navigationBars().andThen(UIAQuery.Contacts.VISIBLE_EDIT_BUTTON));
    }

    if (options.firstName) {
        //this.tap("First");// <rdar://problem/18343358>
        this.enterText(UIAQuery.withPredicate("placeholderText == '%0' OR placeholder == '%0'".format(LocStrings.FIRST_NAME)).first(), options.firstName);
    }

    if (options.lastName) {
        this.enterText(UIAQuery.withPredicate("placeholderText == '%0' OR placeholder == '%0'".format(LocStrings.LAST_NAME)).first(), options.lastName);
    }

    if (options.company) {
        this.enterText(UIAQuery.withPredicate("placeholderText == 'Company' OR placeholder == 'Company'").first(), options.company);
    }

    if (options.phone) {
        this.enterText("add phone", options.phone, {clearTextBeforeTyping: false});
    }

    if (options.email) {
        this.enterText("add email", options.email, {clearTextBeforeTyping: false});
    }

    // ringtone
    // texttone
    if (options.url) {
        this.enterText("add URL", options.url, {clearTextBeforeTyping: false});
    }

    //address
    if (options.homeAddress) {
        if (!this.exists(UIAQuery.HOME_ADDRESS_BUTTON)) {
            // scrollToVisible is required because of but rdar://problem/26101202 scrollTovisible() does not scroll the whole element in visible position
            this.scrollToVisible(UIAQuery.Contacts.ADD_URL_BUTTON);
            this.scrollToVisible(UIAQuery.Contacts.ADD_ADDRESS_BUTTON);
            this.tap(UIAQuery.Contacts.ADD_ADDRESS_BUTTON.isVisible());
            this.waitUntilPresent(UIAQuery.HOME_ADDRESS_BUTTON, 10);
        }
        this.enterAddress(UIAQuery.HOME_ADDRESS_ELEMENT, options.homeAddress);
    }

    if (options.workAddress) {
        if (!this.exists(UIAQuery.HOME_ADDRESS_BUTTON)) {
            // scrollToVisible is required because of but rdar://problem/26101202 scrollTovisible() does not scroll the whole element in visible position
            this.scrollToVisible(UIAQuery.Contacts.ADD_ADDRESS_BUTTON);
            this.tap(UIAQuery.Contacts.ADD_ADDRESS_BUTTON.isVisible());
            this.waitUntilPresent(UIAQuery.HOME_ADDRESS_BUTTON, 25);
        }
        if (!this.exists(UIAQuery.WORK_ADDRESS_BUTTON)) {
            // scrollToVisible is required because of but rdar://problem/26101202 scrollTovisible() does not scroll the whole element in visible position
            this.scrollToVisible(UIAQuery.tableCells(LocStrings.ADD_ADDRESS));
            this.tap(UIAQuery.Contacts.ADD_ADDRESS_BUTTON.isVisible());
            this.waitUntilPresent(UIAQuery.WORK_ADDRESS_BUTTON, 10);
        }
        this.enterAddress(UIAQuery.WORK_ADDRESS_ELEMENT, options.workAddress);
    }

    // birthday
    // date
    // related name
    // social profile
    // instant message
    // add field
    // linked contacts

    this.tap(UIAQuery.DONE_BUTTON)
}

/**
 * Validate that the current contact has the correct information
 *
 * @param {object} options
 * @param {string} options.firstName - First name of the contact
 * @param {string} options.lastName - Last name of the contact
 * @param {string} options.company - Company of the contact
 * @param {string} options.phone - Phone number of the contact
 * @param {string} options.email - Email of the contact
 * @param {string} options.url - URL of the contact
 * @returns {boolean} True if the current contact has ALL of the correct information
 */
contacts.validateContact = function validateContact(options) {
    // check if we are on the contact info page

    // Removed the 'isVisible()' portion of the query for firstName and lastName due to <rdar://problem/26114114>
    if (options.firstName) {
        UIAUtilities.assert(this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.withPredicate("ANY descendants.name contains '%0'".format(options.firstName)))), "Cannot find firstName in contact view");
    }
    if (options.lastName) {
        UIAUtilities.assert(this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.withPredicate("ANY descendants.name contains '%0'".format(options.lastName)))), "Cannot find lastName in contact view");
    }
    if (options.company) {
        if (!this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.contains(options.company).isVisible()))) throw new UIAError("Cannot find company in contact view");
    }
    if (options.phone) {
        //if (!this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.contains(options.phone).isVisible()))) throw new UIAError("Cannot find phone in contact view");
        // phone numbers get formatted...
    }
    if (options.email) {
        this.assertExists(UIAQuery.Contacts.CONTACT_INFO_CARD,"Not in correct view to validate email address:'%0'".format(options.email));
        this.assertExists(UIAQuery.contains(options.email),"Cannot find email address:'%0' in contact view.".format(options.email));
    }
    // ringtone
    // texttone
    if (options.url) {
        if (!this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.contains(options.url).isVisible()))) throw new UIAError("Cannot find url in contact view");
    }
    return true;
}

/**
 * Delete the currently selected contact
 */
contacts.deleteContact = function deleteContact() {
    this.tapIfExists(UIAQuery.Contacts.VISIBLE_EDIT_BUTTON);

    this.tap(UIAQuery.query('Delete Contact').last());
    this.tapIfExists(UIAQuery.query('Delete Contact').last());
}

/**
 * Add a photo for the currently selected contact
 *
 * @param {string} method - Take or Choose a photo for the contact
 */
 contacts.addPhoto = function addPhoto(method) {
    this.tapIfExists(UIAQuery.Contacts.VISIBLE_EDIT_BUTTON);
    this.tap(UIAQuery.contains("Add photo"));

    if (method == "Choose") {
        this.tap("Choose Photo");
    } else if (method == "Take") {
        this.tap("Take Photo");
        this.tap("PhotoCapture");
        this.tap("Use Photo");

    } else {
        throw new UIAError("Unexpected argument: '" + method + "' - please use 'Choose' or 'Take'");
    }
 }

/**
 * Search for a contact and tap on the first result
 *
 * @param {string} searchString - Search string to enter into the search field
 */
contacts.search = function search(searchString) {
    this.getToMainScreen();

    var searchBar = UIAQuery.Contacts.SEARCH_BAR

    this.enterText(searchBar, searchString);

    if (this.count(UIAQuery.tableViews("Search results").andThen('TableCell')) == 0) {
        // throw an error if we do not find any results
        throw new UIAError("No search results found for " + searchString);
    }
    // choose the first table cell in the search results
    this.tap(UIAQuery.tableViews("Search results").andThen(UIAQuery.tableCells().first()));
    // verify the search string appears in the contact view
    UIAUtilities.assert(this.exists(UIAQuery.Contacts.CONTACT_INFO_CARD.andThen(UIAQuery.withPredicate("ANY descendants.name contains '%0'".format(searchString)))), "Cannot find %0 in the Contact View".format(searchString));
}

/**
 * Get the number of contacts in the addressbook from a given search string
 *
 * @param {string} searchString - Search string to enter into the search field
 * @returns {int} the number of search results
 */
 contacts.getNumSearchResults = function getNumSearchResults(searchString) {
    this.getToMainScreen();

    var searchBar = UIAQuery.Contacts.SEARCH_BAR

    this.enterText(searchBar, searchString);

    var matchResult = UIAQuery.tableViews().andThen('Top Name Matches');
    this.waitUntilPresent(matchResult, 4);

    return this.count(UIAQuery.tableViews("Search results").andThen('TableCell'));
 }

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Message the currently selected contact
 *
 * @param {string} message - the content of the message
 */
contacts.messageContact = function messageContact(message) {
    var textButton = UIAQuery.contains('Text').first();
    if (this.exists(textButton.isVisible())) {
        this.tap(textButton);
    } else {
        throw new UIAError("Contact does not have a valid phone number to text.");
    }
    messages.enterMessageText(message);
    messages.tap("Send");
}

/**
 * Call the currently selected contact
 */
contacts.callContact = function callContact() {
    throw new UIAError("Not yet implemented.");
}

/**
 *  Enter address items into the currently editable address
 *
 * @param {object} address - contact address information for home or work, consisting of :
 * @param {string} address.street1 - First line of street address (e.g. '1 Infinite Loop')
 * @param {string} address.street2 - Second line of street address (e.g. 'MS 2343')
 * @param {string} address.city - City
 * @param {string} address.state - State or Province (ie British Columbia, Washington, New South Wales).
 * @param {string} address.postalcode - zip or postal code. (ie 97032, 'V8W 1W5', 'SW1A 2AB')
 * @param {string} address.country - country, (e.g. Canada, United States, France)
 */
contacts.enterAddress = function enterAddress(addressElement, address) {
    UIAUtilities.assert(address, 'Could not enter address as address is null');

    if (address.street1) {
        this.enterText(addressElement.andThen(UIAQuery.STREET).first(), address.street1);
    }
    if (address.street2) {
        this.enterText(addressElement.andThen(UIAQuery.STREET).last(), address.street2);
    }
    if (address.city) {
        this.enterText(addressElement.andThen(UIAQuery.CITY), address.city);
    }
    if (address.state) {
        this.enterText(addressElement.andThen(UIAQuery.STATE), address.state);
    }
    if (address.postalcode) {
        this.enterText(addressElement.andThen(UIAQuery.POSTAL_CODE), address.postalcode);
    }
    if (address.country) {
        this.enterText(addressElement.andThen(UIAQuery.COUNTRY), address.country);
    }
}

/**
 * Shares the current contact card
 *
 * @param {string} method - how to share the contact card
 * @param {string} toWhom - who to send the card to
 * @returns {boolean} true if we successfully share the contact card, else false
 */
contacts.shareContactCard = function shareContactCard(method,toWhom) {
    throw new UIAError("Not yet implemented.");

/*
    this.tap("Share Contact");
    this.tap(UIAQuery.query("ActionSheet").andThen(method));
    if (method == "Mail") {
        // enter email address and subject and hit send
    } else if (method == "Message") {
        // enter phone number and hit send
    } else {
        throw new UIAError("Invalid share method");
    }
    throw new UIAError("Library function not fully implemented");
    return false;
*/
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Non-UI helper functions. E.g. convertHourToMinutes                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Checks if we are in the contact detail view.
 *
 *  @returns {boolean} true if we are in the contact detail view, else false
 */
contacts.isInContactDetailView = function isInContactDetailView(message) {
    throw new UIAError("Not yet implemented.");
}

/**
 * Generate a full name from first and last names
 *
 * @param {string} first - the first name of the conctact
 * @param {string} last - the last name of the conctact
 * @returns {string} the generated full name of the contact
 */
contacts.generateFullName = function generateFullName(first,last) {
    // TODO: add localization for languages which flip the ordering of the first and last names
    var result = "";
    if (first) result += first;
    if (last) result += " " + last;
    return result;
}
