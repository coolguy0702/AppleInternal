
load('UIATesting.js');
load('Spotlight.js');
load('UIAUtility.js');

UIAUtilities.assert(typeof SpotlightTests === 'undefined', 'SpotlightTests has already been defined.')

/** @namespace */

SpotlightTests = {

    /**
     * Perform a spotlight search
     *
     * @param {object} args Test arguments
     * @param {string} [args.searchString="Settings"] - the search string to enter
     * @param {object} [args.resultQuery=null] - query on something displayed as a result of the search
     * @param {bool}   [args.tapResult=false] - if true tap the result
     * @param {object} [args.appToExpect=null] - the app to expect after tapping on the result
     * @param {object} [args.searchOptions=null] - a dictionary object containing options to be passed into UIAApp.search
     *  (see [UIAApp.search]{@link UIAApp#search} for more details on options that can be passed through searchOptions)
     */
    search: function search(args) {
        var args = UIAUtilities.defaults(args, {
            searchString: 'Settings',
            resultQuery: null,
            tapResult: true,
            appToExpect: 'com.apple.Preferences',
            searchOptions: null
        });

        target.clickMenu();

        // perform the search
        spotlight.search(args.searchString, args.searchOptions);

        if (args.appToExpect) {
            // appToExpect should be a UIAApp but we allow for bundle ids also
            if (typeof args.appToExpect == "string") args.appToExpect = target.appWithBundleID(args.appToExpect);

            // insure that appToExpect is a type we can deal with
            UIAUtilities.assert((args.appToExpect && (args.appToExpect instanceof UIAApp)), "App specified was not an instance of UIAApp. App:" + JSON.stringify(args.appToExpect));
        }

        // retrieve/print domains returned by query
        spotlight.parsecResultsQuery([]);

        // if the results query was not specified but we know what app we are looking for then generate a query for it
        if (!args.resultQuery) {
            args.resultQuery = UIAQuery.tableViews().andThen(UIAQuery.contains(args.searchString));
            if (args.appToExpect) {
                args.resultQuery = args.resultQuery.orElse(UIAQuery.tableViews().andThen(args.appToExpect.name()));
            }
        } else if (!(args.resultQuery instanceof UIAQuery)) {
            args.resultQuery = UIAQuery.query(args.resultQuery);
        }

        // check the results
        if (args.resultQuery) {
            UIAUtilities.assert(spotlight.waitUntilPresent(args.resultQuery, 5), "Search item not found: " + args.searchString, "Search item not found. " + args.resultQuery.description());
        }

        // select the result
        if (args.tapResult) {
            // validate app
            if (args.appToExpect) {
                var app = (typeof args.appToExpect == "string") ? target.appWithBundleID(args.appToExpect) : args.appToExpect;
                app.waitToBecomeActive(function () {
                    spotlight.tap(args.resultQuery);
                });
            } else {
                spotlight.tap(args.resultQuery);
            }
        }
    },
}
