load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");


var spotlight = target.appWithBundleID('com.apple.Spotlight');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIAQuery.Spotlight = {

    /** Spotlight */
    SPOTLIGHT:                          UIAQuery.query('SPUISearchView').andThen(UIAQuery.buttons('Cancel')),

    /** Parsec Card */
    PARSEC_CARD:                        UIAQuery.withPredicate("any identifiers == 'SPUINavigationBar'").andThen(UIAQuery.buttons('Back')),

    /** Spotlight table view */
    SPOTLIGHT_TABLE_VIEW:               UIAQuery.withPredicate('behavior == "TableView" AND name == "SearchUITableView"'),
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

var UIStates = {
    /** Spotlight */
    SPOTLIGHT: {
        Description: 'Spotlight',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Spotlight.SPOTLIGHT);
        },
    },
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State                                                    */
/*                                                                             */
/*      A function to determine which UI state the app is currently in         */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and SpringBoard for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
spotlight.currentUIState = function currentUIState() {
    // Grab a snapshot to feed to the isCurrentState functions of the State objects
    var snapshot = this.inspect(UIAQuery.application());

    // List of all the state objects
    var states = Object.keys(UIStates).map(function (key) {
        return UIStates[key];
    });

    /*
    * For each state, check if we're in that state
    * using the isCurrentState function and the snapshot
    * If we are then log and return the State's description
    */
    for (i = 0; i < states.length; i++) {
        var state = states[i];
        if (state.isCurrentState(snapshot)) {
            var stateName = state.Description;
            UIALogger.logMessage('Currently in state "%0"'.format(stateName));
            return stateName;
        }
    }

    // if we got here, we don't have any idea where we are...
    throw new UIAError('Could not determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [state]                                                      */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Opens Spotlight by pulling-down from main screen
*
* @param {object} options Function arguments
* @param {boolean}  [options.dismissSplashScreen=true] - flag to indicate whether or not dismiss First Time Experience(FTE) splash
*
* @returns {boolean} true if pull-down spotlight is up
*   The resulting state may be a left-over search in which text already input, or
*   no input and zero-keyword app predictions displayed.
*/
spotlight.launch = function (options)
{
    // this.__proto__.launch.apply(this);
    options = UIAUtilities.defaults(options, {
        dismissSplashScreen: true,
    });

    UIALogger.logMessage("Navigating to pull-down spotlight");

    target.clickMenu();
    target.systemApp().dragDownInside(UIAQuery.application());

    var spotlight_view = UIAQuery.query('SPUISearchHeader').orElse('SPUISearchView').isVisible();

    // workaround for <rdar://problem/31083789> 15A240: Homing out of a cardview > invoke spotlight again, card is still there
    if (!this.exists(spotlight_view)) {
        // Cards has Back Nav Button, but sheets such as Maps, App Store has Cancel button in place of Back Nav Button
        var maxAttempts = 5;
        while (!this.exists(spotlight_view) && this.exists(UIAQuery.BACK_NAV_BUTTON) && maxAttempts > 0) {
            this.tap(UIAQuery.BACK_NAV_BUTTON.orElse(UIAQuery.CANCEL_BUTTON));
            maxAttempts -= 1;
        }
    }

    // if dismissSplashScreen is set, and we have splash screen visible, we need to press Continue.
    // Splash screen dont appear if search field is not empty, so also clears the field if its not.
    if (options.dismissSplashScreen) {
        var clearTextButton = UIAQuery.withValueForKey('Clear text', 'label');
        var splashScreen = UIAQuery.withPredicate("value BEGINSWITH 'You can search the web'").isVisible();
        this.tapIfExists(clearTextButton);
        if (this.waitUntilPresent(splashScreen, 5)) {
            this.tap(UIAQuery.buttons('Continue'));
        }
    }

    return this.exists(spotlight_view);
}

/**
 * Returns to the list of search results in Spotlight (common parsec wrapper for getToSpotlight)
 *
 * @throws if unable to navigate back to the search results
 */
spotlight.getToParsecSearchResults = function getToParsecSearchResults() {
    if (this.currentUIState() === UIStateDescription.PARSEC_CARD) {
        this.exitParsecCard();
    }
    this.launch();
}

/**
 * Calls UIAApp.search with options required for Spotlight set
 *  (see [UIAApp.search]{@link UIAApp#search} for more details)
 */
spotlight.search = function search(searchString, options) {

    options = UIAUtilities.defaults(options, {
        dragDownForSearchField: true,
        searchField: UIAQuery.searchBars().isVisible().orElse(UIAQuery.textFields().isVisible()).orElse(UIAQuery.textViews().isVisible()),
    });

    this.launch(options);

    this.__proto__.search.apply(this, [searchString, options]);  // calling proto implementation
}