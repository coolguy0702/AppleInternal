#! /usr/local/bin/scripter2 -verboseerror YES -f

load('SpringBoard.js');
load('UIATestingEnvironment.js');
load('Podcasts.js');


function usage() {
    UIALogger.logDebug("usage: PodcastsCmd.js -h ");
    UIALogger.logDebug("       PodcastsCmd.js --help");
    UIALogger.logDebug("    --launchVerify              Launch the App and verify content in each tab")
    UIALogger.logDebug("    --searchAndSubscribe        Launch the App and Search and Subscribe to a Podcast")
    UIALogger.logDebug("    Example     ./PodcastsCmd.js --launchVerify");
}

function main(args) {
    var options = args;
    UIALogger.logDebug(options)
//    var options = new Options();
    if (options.help || options.h) {
        usage();
        return;
    }
    var testID;
    var testDescription;
    var args = [];
    var testFunction = undefined;
    var theTest = undefined;
    if (options.launchVerify) {
        args = [];
        testFunction = launchVerify;
        testID = 'Launch/Verify: ';
        testDescription = ' Open Podcasts and verify elements exist';
    }
    else if (options.searchAndSubscribe) {
        args = [];
        testFunction = searchAndSubscribe;
        testID = 'searchAndSubscribe: ';
        testDescription = 'Launch And select all the categories in the Featured Tab';
    }
    else {
        UIALogger.logMessage("ERROR: Failed to Run Any Test");
        usage();
        return true;
    }
    
    theTest = new UIATesting.Test(testID, args, testFunction, testDescription);
    
    UIALogger.logMessage("Starting Test: " + testDescription);
    theTest.run();
    
    if (theTest.testResult == 0) {
        UIALogger.logMessage("Test Failed");
        return false;
    }
    else {
        UIALogger.logMessage("Finish Successfully");
        return true;
    }
}

main();
