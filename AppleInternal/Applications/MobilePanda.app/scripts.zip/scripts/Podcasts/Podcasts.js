load('UIAApp.js');
load('SpringBoard.js');

if (typeof Podcasts === 'undefined') {

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for common Podcasts queries */
    UIAQuery.Podcasts = {
            /** 'Unplayed' button within a TabBar */
        UNPLAYED_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Unplayed')),
            
            /** 'My Podcasts' button within a TabBar */
        MYPODCASTS_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('My Podcasts')),
            
            /** 'Featured' button within a TabBar */
        FEATURED_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Featured')),
            
            /** 'Top Charts' button within a TabBar */
        TOPCHARTS_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Top Charts')),
            
            /** 'Search' button within a TabBar */
        SEARCH_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Search')),
            
            /** 'Edit' button within a NavigationBar */
        EDIT_NAVBAR: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Edit')),
            
            /** 'Done' button within a NavigationBar */
        DONE_NAVBAR: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Done')),
            
            /** 'SearchBar' */
        SEARCH_BAR: UIAQuery.query("SearchBar"),
            
            /** 'Cancel' button */
        CANCEL: UIAQuery.buttons("Cancel"),
            
        SUBSCRIBE: UIAQuery.buttons("Subscribe"),
            
            /** 'PurchaseButton' button */
        PURCHASEBUTTON: UIAQuery.buttons("PurchaseButton"),
        
        /** 'Subscribe' button */
        SUBSCRIBE:                   UIAQuery.alerts().andThen(UIAQuery.query("Subscribe")),

        
        
    };



    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: UI State Constants                                                  */
    /*                                                                             */
    /*      A dictionary of strings describing the possible UI states of the app   */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for possible UI state names specific to Podcasts */
    UIStateDescription.Podcasts = {
        /** Now Playing */
        NOW_PLAYING:                'now playing',

        /** 'Radio' */
        RADIO:                      'Radio',

        /** 'Playlists' */
        PLAYLISTS:                  'Playlists',

        /** 'Artists' */
        ARTISTS:                    'Artists',

        /** 'SONGS' */
        SONGS:                      'Songs',

        /** 'Albums' */
        ALBUMS:                     'Albums',

        /** 'Genres' */
        GENRES:                     'Genres',

        /** 'Compilations' */
        COMPILATIONS:               'Compilations',

        /** 'Composers' */
        COMPOSERS:                  'Composers',

        /** 'More' */
        MORE:                       'More',
        
            /** 'No Podcasts' Text */
        NO_PODCASTS:                "You have no podcasts.",

            /** 'New and Noteworthy' Text */
        NEW_NOTEWORTHY:              "New & Noteworthy",
        
            /** 'No Podcasts' Text */
        TOP_AUDIO_PODCASTS:          "Top Audio Podcasts",

    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/


    /**
        @namespace
        @augments UIAApp
    */
    var podcasts = target.appWithBundleID('com.apple.podcasts');


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get The Current UI State                                            */
    /*                                                                             */
    /*      A function to determine which UIState the app is currently in          */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Podcasts for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
     */
    podcasts.currentUIState = function currentUIState() {
        throw new UIAError("Not yet implemented");
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get To [page] functions                                             */
    /*                                                                             */
    /*      Helper functions for navigating to different pages within the app      */
    /*                                                                             */
    /*******************************************************************************/

    
    /**
     * Get to the Unplayed Tab
     */
    podcasts.getToUnplayedTab = function getToUnplayedTab() {
        podcasts.launch();
        podcasts.tap(UIAQuery.Podcasts.UNPLAYED_TABBAR);
        //wait for view to load , UIA2 is too fast
        target.delay(1);
        if (podcasts.exists(UIAQuery.staticTexts(UIStateDescription.Podcasts.NO_PODCASTS).isVisible())){
            UIALogger.logMessage("Success: '"+UIStateDescription.Podcasts.NO_PODCASTS+"' was valid on First launch");
            return true;
        }else{
            UIALogger.logError("'"+UIStateDescription.Podcasts.NO_PODCASTS+"' WAS NOT FOUND");
            return false;
        }
    }
    
    /**
     * Get to the My Podcasts Tab
     */
    podcasts.getToMyPodcastsTab = function getToMyPodcastsTab() {
        podcasts.launch();
        podcasts.tap(UIAQuery.Podcasts.MYPODCASTS_TABBAR);
        //wait for view to load , UIA2 is too fast
        target.delay(1);
        if (podcasts.exists(UIAQuery.staticTexts(UIStateDescription.Podcasts.NO_PODCASTS).isVisible())){
            UIALogger.logMessage("Success: '"+UIStateDescription.Podcasts.NO_PODCASTS+"' was valid on First launch");
            return true;
        }else{
            UIALogger.logError("'"+UIStateDescription.Podcasts.NO_PODCASTS+"' WAS NOT FOUND");
            return false;
        }
    }
    
    /**
     * Get to the Featured Tab
     */
    podcasts.getToFeaturedTab = function getToFeaturedTab() {
        podcasts.launch();
        podcasts.tap(UIAQuery.Podcasts.FEATURED_TABBAR);
        //wait for view to load , UIA2 is too fast
        target.delay(1);
        if (podcasts.waitUntilPresent(UIAQuery.staticTexts(UIStateDescription.Podcasts.NEW_NOTEWORTHY).isVisible(), 10)){
            UIALogger.logMessage("Success: '"+UIStateDescription.Podcasts.NEW_NOTEWORTHY+"' was valid on First launch");
            return true;
        }else{
            UIALogger.logError("'"+UIStateDescription.Podcasts.NEW_NOTEWORTHY+"' WAS NOT FOUND after 10 seconds");
            return false;
        }


    }
    
    /**
     * Get to the Top Charts Tab
     */
    podcasts.getToTopChartsTab = function getToTopChartsTab() {
        podcasts.launch();
        podcasts.tap(UIAQuery.Podcasts.TOPCHARTS_TABBAR);
        //wait for view to load , UIA2 is too fast
        target.delay(1);
        if (podcasts.waitUntilPresent(UIAQuery.staticTexts(UIStateDescription.Podcasts.TOP_AUDIO_PODCASTS).isVisible(), 10)){
            UIALogger.logMessage("Success: '"+UIStateDescription.Podcasts.TOP_AUDIO_PODCASTS+"' was valid on First launch");
            return true;
        }else{
            UIALogger.logError("'"+UIStateDescription.Podcasts.TOP_AUDIO_PODCASTS+"' WAS NOT FOUND after 10 seconds");
            return false;
        }

    }
    
    /**
     * Get to the Search Tab
     */
    podcasts.getToSearchTab = function getToSearchTab() {
        podcasts.launch();
        podcasts.tap(UIAQuery.Podcasts.SEARCH_TABBAR);
        //wait for view to load , UIA2 is too fast
        target.delay(1);

    }
    
    
    
    /***********************************************************************************/
    /*                                                                                 */
    /*   Mark: Tasks                                                                   */
    /*                                                                                 */
    /*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
    /*      These will be comprised of multiple Action functions                       */
    /*                                                                                 */
    /***********************************************************************************/

    
    /**
     * Subscribe to a Podcast by searching the Store
     *
     * @param {object} options
     * @param {string} options.podcastSearchTitle - the name of the podcast to search for
     * @param {string} options.podcastVerify - Name of the Podcast to verify after search
     */
    
    podcasts.searchForPodcast = function searchForPodcast(options) {
        if (target.activeApp().name() != 'Podcasts' && !springboard.isInSideAppView()) {
            podcasts.launch();
        }
        podcasts.getToSearchTab();
        //search here for options.podcastSearchTitle;
        UIALogger.logMessage("Searching for: " + options.podcastSearchTitle);
        this.enterText(UIAQuery.Podcasts.SEARCH_TABBAR, options.podcastSearchTitle, {setValueToEnterText: true});
        UIALogger.logMessage("Check the view now for the searched content: " + options.podcastVerify);
        UIALogger.logDebug(":::: No yet implemented");
        return true;
    }
    
    /**
     * Subscribe to a Podcast via a Feed URL
     *
     * @param {string} feedUrl - Podcast feed url to subscribe to
     */
    podcasts.subscribeToPodcastUsingURL = function subscribeToPodcastUsingURL(options) {
        if (!options.feedUrl) {
            options.feedUrl = "pcast://www.npr.org/rss/podcast.php?id=344098539";
        }
//        UIALogger.logDebug("***********************");
//        UIALogger.logDebug(options.feedUrl);
//        UIALogger.logDebug("***********************");
        
        var alertHandler = function() {
            var app = target.activeApp();
            var alertQuery = UIAQuery.Podcasts.SUBSCRIBE;
            if (alertQuery && app.exists(alertQuery)) {
                UIALogger.logMessage("Success: SUBSCRIBE button was valid, tap it");
                return app.tap(alertQuery);
            } else {
                throw new Error("'SUBSCRIBE' Button WAS NOT FOUND after 10 seconds");
            }
        }
        
        // Tap Subscribe button
        this.withAlertHandler(alertHandler, function() {
            var commandArgs = []
            UIALogger.logDebug("URL is "+ options.feedUrl);
            var pt = target.performTask("/usr/local/bin/LaunchApp", ["-url", options.feedUrl]);
            UIALogger.logDebug(pt);
            target.delay(5);
        });
        
        if (podcasts.waitUntilPresent(UIAQuery.Podcasts.PURCHASEBUTTON.isVisible(), 10)){
            UIALogger.logMessage("Success: Download button was valid");
//            this.tap(UIAQuery.Podcasts.PURCHASEBUTTON);
            return true;
        }else{
            UIALogger.logError("'Download' Button WAS NOT FOUND after 10 seconds");
            throw new Error("'Download' Button WAS NOT FOUND after 10 seconds");
        }
        
    }
    


}
