load('UIATesting.js');
load('Podcasts.js');

if (typeof PodcastsTests === 'undefined') {
    /**
     * @namespace Podcasts
     */
    var PodcastsTests = {

        /**
         * Launch Podcasts and Verify Tabs are present
         *
         * @param {object} args - Test arguments
         */
        launchAndVerifyTabs: function launchVerify(args) {
            this.testResult = 1;
            try {
                args = UIAUtilities.defaults(args, {});
                UIALogger.logMessage("Launch Podcasts");
                podcasts.launch();
                target.delay(3);
                var app = target.activeApp().name();
                if (app === 'Podcasts'){
                    UIALogger.logMessage("Active app is: " + app);
                }else{
                    UIALogger.logError("Active app was not Podcasts it was: " + app);
                    throw new Error("Active app was not Podcasts it was: " + app);
                }

                UIALogger.logMessage("Get to Unplayed Tab");
                podcasts.getToUnplayedTab();
                target.delay(1);
                
                
                UIALogger.logMessage("Get to My Podcasts Tab");
                podcasts.getToMyPodcastsTab();
                target.delay(1);
                
                UIALogger.logMessage("Get to Featured Tab");
                podcasts.getToFeaturedTab();
                target.delay(1);
                
                UIALogger.logMessage("Get to Top Charts Tab");
                podcasts.getToTopChartsTab();
                target.delay(1);
                
                UIALogger.logMessage("Get to Search Tab");
                podcasts.getToSearchTab();
                target.delay(1);
                UIALogger.logPass();

            }
            catch (e) {
                // Catch error, but continue
                UIALogger.logError(e);
                this.testError = e;
                this.testResult = 0;
                UIALogger.logFail();

            }
            return this.testResult;
        },

        /**
         * Subscribe to a Podcast through Search
         *
         * @param {object} args - Test arguments
         * @param {string} [args.podcastName="Serial"] - Required name of the podcast to subscribe to
         */
        searchAndSubscribe: function searchAndSubscribe(args) {
            this.testResult = 1;
            try {
                args = UIAUtilities.defaults(args, {'podcastSearchTitle': 'Serial', 'podcastVerify': 'Serial'});
                podcasts.launch();
                podcasts.searchForPodcast(args);
                target.delay(1);
                UIALogger.logPass();

            }
            catch (e) {
                // Catch error, but continue
                UIALogger.logError(e);
                this.testError = e;
                this.testResult = 0;
                UIALogger.logFail();

            }
            return this.testResult;
            
            
            
        },

        /**
         * Subscribe to a Podcast by a Feed URL
         *
         * @param {object} args - Test arguments
         * @param {string} "feed://www.npr.org/rss/podcast.php?id=344098539" - Required URL of the feed to subscribe to
         */
        subscribeByURL: function subscribeByURL(args) {
            args = UIAUtilities.defaults(args, {feedURL: "pcast://www.npr.org/rss/podcast.php?id=344098539"});
            this.testResult = 1;
            try {
                UIALogger.logMessage("Launch and subscribe by URL: " + args.feedURL )
                podcasts.subscribeToPodcastUsingURL(args);
                UIALogger.logMessage("Finshed Successfully" )
                UIALogger.logPass();
            }
            catch (e) {
                // Catch error, but continue
                UIALogger.logError(e);
                this.testError = e;
                this.testResult = 0;
                UIALogger.logFail();

            }
            return this.testResult;

        },
    }
}
