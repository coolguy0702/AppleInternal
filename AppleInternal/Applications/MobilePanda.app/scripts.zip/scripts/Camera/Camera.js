load('UIAApp.js');
load('Photos.js');
load('UIAApp+Camera.js');
load('SpringBoard.js');

if (typeof camera !== 'undefined') {
    if (!(camera instanceof UIAApp)) {
        throw new UIAError("camera has already been defined to something not an instance of UIAApp! Value: %0".format(camera));
    }
    if (camera.bundleID() !== 'com.apple.camera') {
        var oldDefinition = camera.bundleID();
        var camera = target.appWithBundleID('com.apple.camera');
        UIALogger.logWarning("'camera' was redefined from '%0' to '%1'".format(oldDefinition, camera.bundleID()));
    }
}
/**
    @namespace
    @augments UIAApp
*/
var camera = target.appWithBundleID('com.apple.camera');

/**
 * Contants for getThumbnailCount
 */
camera.MEDIA_TYPE = {};
camera.MEDIA_TYPE.Video = 'Video';
camera.MEDIA_TYPE.Photo = 'Photo';
camera.MEDIA_TYPE.Slomo = 'Slo-mo';
camera.MEDIA_TYPE.Timelapse = 'Time-lapse';
camera.MEDIA_TYPE.Iris = 'Live Photo';
camera.MEDIA_TYPE.AllVideoTypes = 'All Video Types';

/**
 * Contants for determining capture mode
 */
camera.VIDEO_CAPTURE_MODE = 'video';
camera.SLOMO_CAPTURE_MODE = 'slo-mo';
camera.TIMELAPSE_CAPTURE_MODE = 'time-lapse';

/**
 * @namespace
 */
UIAQuery.Camera = {
    /** Button for starting video capture */
    VIDEO_CAPTURE_BUTTON: UIAQuery.buttons('VideoCapture'),

    VIDEO_STOP_CAPTURE_BUTTON: UIAQuery.buttons('VideoCapture'),

    /** Button for starting slomo capture */
    SLOMO_CAPTURE_BUTTON: UIAQuery.buttons('SlomoCapture'),

    SLOMO_STOP_CAPTURE_BUTTON: UIAQuery.buttons('SlomoCapture'),

    /** Button with 'CAMImageWell' title */
    /** Changed name in <rdar://problem/21970698> */
    CAMERA_ROLL_BUTTON: UIAQuery.buttons('CAMImageWell').orElse(UIAQuery.buttons('GoToCameraRoll')),

    /** Button with 'PhotoCapture' title */
    PHOTO_CAPTURE_BUTTON: UIAQuery.buttons('PhotoCapture'),

    /** Button with 'CAMFilterButton' title */
    FILTERS_BUTTON: UIAQuery.buttons('CAMFilterButton'),

    /** Button with 'Delete' title in Camera Roll */
    DELETE_BUTTON: UIAQuery.buttons('Delete'),
};


/**
 *  Navigates camera UI to get to viewfinder (i.e. Camera with Iris open).
 *
 **/

camera.getToCamera = function getToCamera() {

    var irisWaiter = UIAWaiter.waiter("CameraIrisOpened");

    function waitForCameraIrisToOpen() {
        UIALogger.logDebug("Checking that camera iris is open");
        if (!camera.isCameraIrisOpen()) {
            if (!irisWaiter.wait(10)) {
                throw new UIAError("Camera iris never opened. Please file a Radar.");
            }
        }
    }

    this.launch();
    if (this.isInCamera()) {
        // Wait for the camera iris to open
        waitForCameraIrisToOpen();

        //We might be in the filters UI.  Select the 'Original/None' filter to get to Camera view.
        if (this.exists('CAMEffectsGridView')) {
            this.tap(UIAQuery.Camera.FILTERS_BUTTON);
        }
        // stops recording video if camera is currently capturing one
        this.stopVideoCapture()
    }
    else {
        UIALogger.logDebug("Main camera view is not present, assuming we are somewhere in the Camera Roll");

        if (this.waitUntilPresent(UIAQuery.buttons('Got It'), 2)) {
            UIALogger.logDebug("Dismissing the Explore popup explaining how to preview Live Photos");
            this.tap(UIAQuery.buttons('Got It'));
        }

        this.tap(UIAQuery.BACK_NAV_BUTTON);

        // Wait for the camera iris to open
        waitForCameraIrisToOpen();
    }
}

/**
*  Get the camera into the top-level of "Camera Roll" -- the UI where all of the
*  photo/video thumbnails are displayed.
*
**/
camera.getToCameraRoll = function getToCameraRoll() {
    this.launch();

    if (this.isInCameraRoll()) {
        return;
    }
    UIALogger.logDebug("Going to the camera roll.");

    this.getToCamera();

    var viewDisappearWaiter = UIAWaiter.withPredicate("ViewDidDisappear", "controllerClass == 'CAMViewfinderViewController'");

    UIALogger.logMessage("Waiting for CAMViewfinderViewController to disappear");

    this.tap(UIAQuery.Camera.CAMERA_ROLL_BUTTON);

    var viewDisappeared = viewDisappearWaiter.wait(10);

    if (!viewDisappeared) {
        throw new UIAError("Timed out waiting for CAMViewfinderViewController");
    } else {
        UIALogger.logMessage("Done waiting");
    }
}


/**
 *  Safe switch-over when tapping All Photos in the camera roll.
 *  Assumes we are currently examining an image in the Camera-specific roll.
 *
 **/
camera.switchoverToAllPhotos = function switchoverToAllPhotos() {
    this.getToCameraRoll();

    var photosWaiter = UIAWaiter.withPredicate("ApplicationStateChanged", "bundleID = 'com.apple.mobileslideshow' AND state = 'Foreground'");
    var currentViewDisappeared = UIAWaiter.withPredicate('ViewDidDisappear', "controllerClass == 'SBDeviceApplicationSceneViewController'");

    if (this.waitUntilPresent(UIAQuery.ALL_PHOTOS.isVisible(), 2)) {
        if (!this.inspect(UIAQuery.ALL_PHOTOS).isEnabled) {
            UIALogger.logWarning('"All Photos" button was not enabled (collecting stackshot)');
            target.stackshot();                                             // data collection for rdar://problem/22093803
            this.waitUntilPresent(UIAQuery.ALL_PHOTOS.isEnabled(), 10);     // workaround for rdar://problem/22093803
        }
        photosWaiter.unsafeReset();
        this.tap(UIAQuery.ALL_PHOTOS);
    }

    // 35 seconds!  Are you crazy?  No, but under low memory conditions our devices could be (see rdar://problem/22215641)
    var timeToLaunch = 0;
    var success = photosWaiter.wait(35, function(event, dt) {
        timeToLaunch = dt.toFixed(2);
    });

    if (!success) {
        throw new UIAError("Failed to launch Photos from Camera");
    }

    if (timeToLaunch > 10) {
        // this is here to track rdar://problem/22215641 in the presence of workaround
        UIALogger.logError(new Error("Time to launch Photos from Camera took %0 seconds".format(timeToLaunch)));
    }

    if (!currentViewDisappeared.wait(5)) {
        throw new UIAError("Camera did not disappear after launching Photos");
    }
    if (!photos.waitUntilReady()) {
        throw new UIAError("Photos never became ready");
    }

    // Necessary for view in <rdar://problem/25920120>
    photos.tapIfExists(UIAQuery.PHOTOS_WHATS_NEW_CONTINUE_BUTTON)
}

/**
 * Checks to see if are at the top-level "Camera Roll" view --
 * the UI where all of the photo/video thumbnails are displayed.
 *
 * @returns True if we're on the Camera Roll view.
 */
camera.isInCameraRoll = function isInCameraRoll() {
    return this.waitUntilPresent('PUPhotoBrowserTitleView', 2);
}

/**
 * Checks to see if the camera is active
 *
 * @returns True if the camera is active
 */
camera.isInCamera = function isInCamera() {
    return this.waitUntilPresent('CAMViewfinderView', 2);
}


/**
* Takes a picture with the given parameters
*
* @param {object} options - Test arguments
* @param {string} [options.captureMode="photo"] - Which picture mode to use: "photo", "square", or "portrait"
* @param {boolean} [options.clearCameraRoll=false] - Should we clear the existing camera roll first?
* @param {int} [options.pictureCount=1] - The number of pictures to take
* @param {int} [options.delay=0] - The time in seconds to delay between each photo
* @param {string} [options.flashMode="Off"] - Which flash mode to use: "On", "Off", or "Automatic"
* @param {string} [options.hdrMode="Off"] - Which HDR mode to use: "On", "Off", or "Auto"
* @param {boolean} [options.irisOn=false] - Should we make an Iris asset?
* @param {string} [options.cameraFilter=null] - Use a specific filter. String should equal the filter's name.
* @param {boolean} [options.burstMode=false] - Are we takng a burst photo?"
* @param {int} [options.burstDuration=10] - The time duration in seconds for taking a burst photo"
*/
camera.takePictureWithOptions = function takePictureWithOptions(options) {
    options = UIAUtilities.defaults(options, {
        captureMode     : 'photo',
        clearCameraRoll : false,
        pictureCount    : 1,
        delay           : 0,
        flashMode       : 'Off',
        hdrMode         : 'Off',
        irisOn          : false,
        cameraFilter    : null,
        burstMode       : false,
        burstDuration   : 10,
    });

    if (options.pictureCount > 1) {
        //turn off flash to keep device from getting too hot when taking multiple photos
        UIALogger.logMessage("Turning flash off to avoid overheating when taking multiple pictures");
        options.flashMode = "Off";
    } else if (!(options.pictureCount >= 0)){
        //!(options.pictureCount >= 0) will catch the cases where it's NaN or negative number.
        options.pictureCount = 1;
    }

    if(!(options.delay >= 0)){
        //!(options.delay >= 0) will catch the cases where it's NaN or negative number.
        options.delay = 3;
    }

    this.getToCamera();
    this.setCameraOptions(options);

    for (var i = 0; i < options.pictureCount; i++) {
        this.takePicture(options)
    }

}

/**
*  Captures a video.
*
* @param {object} options Test arguments
* @param {int}    [options.length=5] - The length of the video in seconds
* @param {string} [options.flashMode=null] - Which flash mode to use: "On", "Off", or "Automatic"
* @param {string} [options.captureMode="video"] - Which video mode to use: "video" or "slo-mo" or "time-lapse"
* @param {string} [options.cameraFacingMode=Back facing] - Choose front or rear facing camera: "Front" or "Back"
* @param {boolean}[options.stillDuringVideo=false] - Should we capture still(s) during video?
* @param {int}    [options.stillCount=1] - Number of photos to capture during Video, must enable stillDuringVideo to take effect
*
* @throws If selected Camera does not support still during video
*/
camera.captureVideoWithOptions = function captureVideoWithOptions(options) {
    options = UIAUtilities.defaults(options, {
        flashMode: null,
        captureMode: "video",
        cameraFacingMode: CameraFacingMode.BACK,
        length: 5,
        stillDuringVideo: false,
        stillCount: 1,
    });
    this.setCameraOptions(options);

    CAMERA_READY_TIMEOUT = 3;
    //Wait for blurry transition state to finish
    if (!this.waitUntilAbsent(UIAQuery.CAMERA_NOT_READY, CAMERA_READY_TIMEOUT)) {
        throw new UIAError('Camera was not ready to record after %0 seconds.'.format(CAMERA_READY_TIMEOUT))
    }
    //Delay required since capture button not always available instantly after blurry transition state
    this.delay(1);

    UIALogger.logDebug("Video capture started at %0, duration %1".format(new Date(Date.now()), options.length));
    if (options.captureMode === camera.VIDEO_CAPTURE_MODE) {
        this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);

        if (options.stillDuringVideo) {
            //Still during video, capture n stills spread evenly
            if (!this.exists(UIAQuery.Camera.PHOTO_CAPTURE_BUTTON)) {
                this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);
                throw new UIAError('This Camera does not support Still During Video');
            }

            var delayBetweenCapture = options.length / options.stillCount;
            for (var i = 0; i < options.stillCount; i++) {
                this.delay(delayBetweenCapture);
                UIALogger.logDebug("Photo captured during video, photo# %0 at %1".format(i+1, new Date(Date.now())));
                this.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);
            }
        } else {
            //Regular regular video capture
            this.delay(options.length);
        }
        this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);
        if (this.exists(UIAQuery.Camera.PHOTO_CAPTURE_BUTTON)) {
            throw new UIAError('Tapped button to end Video Capture but Photo Capture button still exists.');
        }
    } else if (options.captureMode === camera.SLOMO_CAPTURE_MODE) {
        this.tap(UIAQuery.Camera.SLOMO_CAPTURE_BUTTON);
        this.delay(options.length);
        this.tap(UIAQuery.Camera.SLOMO_STOP_CAPTURE_BUTTON);
    } else if (options.captureMode === camera.TIMELAPSE_CAPTURE_MODE) {
        this.tap(UIAQuery.Camera.PHOTO_CAPTURE_BUTTON);
        this.delay(options.length);
        this.tap(UIAQuery.Camera.PHOTO_CAPTURE_BUTTON);
    }
    UIALogger.logDebug("Video capture ended at %0".format(new Date(Date.now())));
}

camera.playVideoForDuration = function playVideoForDuration(duration) {

        if (!this.supportsVideo()) {
            throw new UIAError("Camera does not support video capture.");
        }

        var videoCount = this.getVideoCount();
        UIALogger.logDebug("Number of videos is [" + videoCount + "]");

        // record a video if there isn't one to play
        if (videoCount == 0) {
            UIALogger.logDebug("No videos to play. Taking one first...");

            UIALogger.logDebug("Going to the camera");
            camera.getToCamera();

            UIALogger.logDebug("Taking a video.");
            camera.captureVideoWithOptions();

            videoCount = this.getVideoCount();
            UIALogger.logDebug("Number of thumbnails after recording a video: [" + videoCount + "]");
        }

        photos.tap(UIAQuery.PHOTOS_ALL_VIDEO_TYPES_THUMBNAILS.last());

        if (!photos.exists(UIAQuery.PHOTO_CONTROLLER_VIEW.isVisible())) {
            throw new UIAError("We should be on the video detail view but we aren't.");
        }

        photos.playVideo(duration);

}

/**
 * Navigate to photos to get number of photos
 */
camera.getPhotoCount = function getPhotoCount(albumName) {
    return this.getThumbnailCount(camera.MEDIA_TYPE.Photo, albumName);
}

/**
 * Navigate to photos to get number of Iris assets
 */
camera.getIrisPhotoCount = function getIrisPhotoCount(albumName) {
    return this.getThumbnailCount(camera.MEDIA_TYPE.Iris, albumName);
}

/**
 * Navigate to photos to get number of videos
 */
camera.getVideoCount = function getVideoCount(captureMode, albumName) {
    if (captureMode === camera.VIDEO_CAPTURE_MODE) {
        return this.getThumbnailCount(camera.MEDIA_TYPE.Video, albumName);
    }
    else if (captureMode === camera.SLOMO_CAPTURE_MODE) {
        return this.getThumbnailCount(camera.MEDIA_TYPE.Slomo, albumName);
    }
    else if (captureMode === camera.TIMELAPSE_CAPTURE_MODE) {
        return this.getThumbnailCount(camera.MEDIA_TYPE.Timelapse, albumName);
    }
    else {
        return this.getThumbnailCount(camera.MEDIA_TYPE.AllVideoTypes, albumName);
    }

}

/**
 * Get the name of the Camera Roll: "Camera Roll" unless CPL is enabled, then "All Photos"
 */
camera.getCameraRollName = function getCameraRollName() {
  var cameraRollAlbumName = "Camera Roll";
  settings.navigateNavigationViews(["Photos"]);
  var cplSwitch = settings.inspect(UIAQuery.switches("iCloud Photos"));
  if (cplSwitch !== undefined && cplSwitch !== null && cplSwitch.value === '1') {
      cameraRollAlbumName = "All Photos";
  }
  return cameraRollAlbumName;
}

/**
 * Navigate to photos to get number of thumbnails
 */
camera.getThumbnailCount = function getThumbnailCount(thumbnailType, albumName) {
    var thumbnailCount = 0;
    
    photos.getToCollectionInView(albumName, "Albums");

    if (thumbnailType == camera.MEDIA_TYPE.Photo) {
        thumbnailCount = photos.count(UIAQuery.PHOTOS_PHOTO_THUMBNAILS);
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Iris) {
        thumbnailCount = photos.count(UIAQuery.PHOTOS_IRIS_THUMBNAILS);
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Video) {
    thumbnailCount = photos.count(UIAQuery.PHOTOS_VIDEO_THUMBNAILS);
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Slomo) {
        thumbnailCount = photos.count(UIAQuery.PHOTOS_SLOMO_THUMBNAILS);
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Timelapse) {
        thumbnailCount = photos.count(UIAQuery.PHOTOS_TIMELAPSE_THUMBNAILS);
    }
    else if (thumbnailType == camera.MEDIA_TYPE.AllVideoTypes) {
        thumbnailCount = photos.count(UIAQuery.PHOTOS_ALL_VIDEO_TYPES_THUMBNAILS);
    }
    else {
        thumbnailCount = photos.numberOfThumbnails();
    }
    UIALogger.logMessage("Thumbnail count for type '%0': %1".format(thumbnailType, thumbnailCount));
    return thumbnailCount;
}
