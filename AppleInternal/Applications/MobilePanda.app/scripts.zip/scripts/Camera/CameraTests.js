
load("UIATesting.js");
load("SpringBoard.js");
load("Camera.js");
load("Photos.js");
load("Settings.js");

if (typeof CameraTests !== 'undefined') {
    throw new UIAError("Namespace 'CameraTests' has already been defined.");
}

/**
 * @namespace
 */
var CameraTests = {

    /**
     * Takes a picture
     *
     * @targetApps Camera, MobileSlideShow, Preferences
     *
     * @param {object} args Test arguments
     * @param {boolean} [args.clearCameraRoll=false] - Should we clear the existing camera roll first?
     * @param {int} [args.pictureCount=1] - The number of pictures to take
     * @param {int} [args.delay=0] - The time in seconds to delay between each photo
     * @param {string} [args.flashMode="Off"] - Which flash mode to use: "On", "Off", or "Automatic"
     * @param {string} [args.hdrMode="Off"] - Which HDR mode to use: "On", "Off", or "Auto"
     * @param {boolean} [options.irisOn=false] - Should we make an Iris asset?
     * @param {string} [args.cameraFilter=null] - Use a specific filter. String should equal the filter's name.
     * @param {string} [args.captureMode='photo'] - Which capture mode to use {'photo', 'portrait', 'square', 'pano'}
     * @param {boolean} [args.burstMode=false] - Are we takng a burst photo?"
     * @param {int} [args.burstDuration=10] - The time duration in seconds for taking a burst photo"
     * @param {string} [args.cameraFacingMode="Back facing"] - Choose front or rear facing camera: "Front facing" or "Back facing"
     *
     * @alertHandlers camera.allowAccessToLocationAlertHandler  
     *
     */
    takePicture: function takePicture(args) {
        args = UIAUtilities.defaults(args, {
            clearCameraRoll: false,
            pictureCount: 1,
            delay: 5,
            flashMode: "Off",
            hdrMode: "Off",
            irisOn: false,
            cameraFilter: null,
            captureMode: 'photo',
            burstMode: false,
            burstDuration: 10,
            cameraFacingMode : CameraFacingMode.BACK,
        });

        /*********************************************
         * Step 1: Handle argument edge-cases.
         *********************************************/
        var expectedThumbnailIncrement = 1;
        if (args.hdrMode == "On") {
            //get the value of the Keep Normal Photo setting from the Settings app
            settings.launch();
            settings.navigateNavigationViews(["Camera"]);
            if(settings.inspect(UIAQuery.switches("Keep Normal Photo")).value == 1) {
                expectedThumbnailIncrement = 2;
            }
        }

        //If we're taking HDR photos, the camera roll will display both the normal photo and the HDR photo
        expectedThumbnailIncrement *= args.pictureCount;

        /*********************************************
         * Step 2: Set up verification conditions.
         *********************************************/
        var originalThumbsNumber = 0;
        var albumName = camera.getCameraRollName()
        if (args.irisOn && CameraCapability.supportsIris) {
            originalThumbsNumber = camera.getIrisPhotoCount(albumName);
        } else {
            originalThumbsNumber = camera.getPhotoCount(albumName);
        }

        if (args.clearCameraRoll) {
            UIALogger.logMessage("Checking to see if we have any pictures to delete...");
            camera.getToCameraRoll();
            if (!camera.exists(UIAQuery.query("No Photos or Videos"))) {
                UIALogger.logMessage("Clearing all photos and videos before taking a photo...");
                photos.getToCollectionInView(albumName, "Albums");
                photos.deleteAllPhotos();
            } else {
                UIALogger.logMessage("There are no photos or videos!");
            }
            originalThumbsNumber = 0;
        }

        UIALogger.logDebug("Number of thumbnails before taking picture is [" + originalThumbsNumber + "]");
        UIALogger.logDebug("Preparing to take " + args.pictureCount + " pictures with a " + args.delay + " second delay between each.");

        /*********************************************
         * Step 3: Test the target feature.
         *********************************************/
        camera.takePictureWithOptions(args);

        UIALogger.logDebug("Getting the count of thumbnails.");
        var finalThumbsNumber = 0;
        if (args.irisOn && CameraCapability.supportsIris) {
            finalThumbsNumber = camera.getIrisPhotoCount(albumName);
        } else {
            finalThumbsNumber = camera.getPhotoCount(albumName);
        }
        UIALogger.logDebug("Number of thumbnails after taking picture is [" + finalThumbsNumber + "]");

        /*********************************************
         * Step 4: Verification.
         *********************************************/
         if (originalThumbsNumber + expectedThumbnailIncrement != finalThumbsNumber) {
            UIALogger.logMessage("Expected " + (originalThumbsNumber + expectedThumbnailIncrement) + " thumbnails but found " + finalThumbsNumber);
            throw new UIAError("Final number of thumbnails was incorrect.");
        }


    },


    /**
     * Deletes the last picture from the camera roll.
     *
     * @targetApps Camera, MobileSlideShow
     *
     */
    deletePictureOrVideo: function deletePictureOrVideo() {
        /*********************************************
         * Step 1: Set up verification conditions.
         *********************************************/
        var originalThumbsNumber = camera.getThumbnailCount();
        var expectedThumbsNumber = originalThumbsNumber - 1;

        /*********************************************
         * Step 2: Handle edge case - No pictures present.
         *********************************************/
        if (0 == originalThumbsNumber) {
            originalThumbsNumber = 1;
            expectedThumbsNumber = 0;

            camera.takePictureWithOptions({
                pictureCount : 1,
            });
        }

        /*********************************************
         * Step 3: Test the target feature.
         *********************************************/
        camera.getToCameraRoll();
        camera.deleteAndConfirm();

        /*********************************************
         * Step 4: Verification.
         *********************************************/
        var finalThumbsNumber = camera.getThumbnailCount();
        if (finalThumbsNumber != expectedThumbsNumber) {
           throw new UIAError("Final number of thumbnails was incorrect.");
        }
    },

    /**
     * Captures a video.
     *
     * @targetApps Camera, MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {int}    [args.length=5] - The length of the video in seconds
     * @param {string} [args.flashMode=null] - Which flash mode to use: "On", "Off", or "Automatic"
     * @param {string} [args.captureMode="video"] - Which video mode to use: "video", "slo-mo", or "time-lapse"
     * @param {string} [args.cameraFacingMode=null] - Choose front or rear facing camera: "Front" or "Back"
     */
    captureVideo: function captureVideo(args) {
        args = UIAUtilities.defaults(args, {
            length: 5,
            flashMode: null,
            captureMode: "video",
            cameraFacingMode: null,
        });

        var albumName = camera.getCameraRollName();
        var originalThumbsNumber = camera.getVideoCount(args.captureMode,albumName);

        if (args.clearCameraRoll) {
            UIALogger.logMessage("Clearing all videos/photos before taking a photo...");
            camera.clearCameraRoll();
            originalThumbsNumber = 0;
        }

        var expectedThumbsNumber = originalThumbsNumber + 1;

        UIALogger.logDebug("Number of thumbnails before capturing video is [" + originalThumbsNumber + "]");
        UIALogger.logDebug("Preparing to capture " + args.length + " seconds of video.");

        camera.getToCamera();
        camera.captureVideoWithOptions(args);

        // go to Camera Roll  to see how many thumbnails we have now
        UIALogger.logDebug("Getting the count of thumbnails.");
        var finalThumbsNumber = camera.getVideoCount(args.captureMode,albumName);

        UIALogger.logDebug("Number of thumbnails after capturing is [" + finalThumbsNumber + "]");

        if (expectedThumbsNumber != finalThumbsNumber) {
            UIALogger.logMessage("Expected " + expectedThumbsNumber + " thumbnails but found " + finalThumbsNumber);
            throw new UIAError("Final number of thumbnails was incorrect.");
        }

    },

    /**
     * Deletes the last video from the camera roll.
     *
     * @targetApps Camera
     *
     */
    deleteVideo: function deleteVideo(args) {
        args = UIAUtilities.defaults(args, {

        });

        var id = {predicate: 'TRUEPREDICATE'};

        camera.getToCameraRoll();

        var originalThumbsNumber = photos.numberOfThumbnails();
        UIALogger.logDebug("Number of thumbnails before deleting a video is [" + originalThumbsNumber + "]");

        // record a video if there isn't one to delete
        if (originalThumbsNumber == 0) {
            UIALogger.logDebug("No photos to delete. Taking one first...");

            UIALogger.logDebug("Launching camera");
            camera.launch();
            target.delay(1);

            UIALogger.logDebug("Going to the camera");
            camera.getToCamera();
            target.delay(1);

            UIALogger.logDebug("Taking a video.");
            camera.captureVideo(5);
            camera.getToCameraRoll();
            originalThumbsNumber = photos.numberOfThumbnails();
            UIALogger.logDebug("Number of thumbnails after recording a video: [" + originalThumbsNumber + "]");
        }

        photos.tap(UIAQuery.PHOTOS_VIDEO_THUMBNAILS.last());

        if (!photos.exists(UIAQuery.PHOTO_BROWSER_TITLE.isVisible())) {
            throw new UIAError("We should be on the video detail view but we aren't.");
        }
        photos.deleteAndConfirm();

        // get to top level of camera roll
        camera.getToCameraRoll();

        // count number of thumbs we ended with
        var updatedThumbsNumber = photos.numberOfThumbnails();
        UIALogger.logDebug("Number of thumbnails after deleting: [" + updatedThumbsNumber + "]");

        if (updatedThumbsNumber != originalThumbsNumber - 1)
            throw "Unexpected number of thumbnails found after deleting photo";
    },



    /**
     *  Deletes all photos/videos from the camera roll, if there are any there.
     *
     * @targetApps Camera
     *
     */
    deleteAll: function deleteAll(args) {
        args = UIAUtilities.defaults(args, {

        });

        var id = {predicate: 'TRUEPREDICATE'};

        camera.getToCameraRoll();

        var originalThumbsNumber = photos.numberOfThumbnails();
        UIALogger.logDebug("Number of thumbnails before deleting a picture is [" + originalThumbsNumber + "]");

        // take a picture if there isn't one to delete
        if (originalThumbsNumber == 0) {
            UIALogger.logDebug("Nothing to delete. Taking a picture first...");

            UIALogger.logDebug("Launching camera");
            camera.launch();
            target.delay(1);

            UIALogger.logDebug("Going to the camera");
            camera.getToCamera();
            target.delay(1);

            UIALogger.logDebug("Taking a picture");
            camera.takePicture(args);
            camera.getToCameraRoll();
            originalThumbsNumber = photos.numberOfThumbnails();
            UIALogger.logDebug("Number of thumbnails before deleting: [" + originalThumbsNumber + "]");
        }

        photos.deleteAllPhotos();

        // get to top level of camera roll
        camera.getToCameraRoll();

        // count number of thumbs we ended with
        var updatedThumbsNumber = photos.numberOfThumbnails();
        UIALogger.logDebug("Number of thumbnails before deleting: [" + originalThumbsNumber + "]");
        UIALogger.logDebug("Number of thumbnails after deleting: [" + updatedThumbsNumber + "]");

        if (updatedThumbsNumber != 0) {
            UIALogger.logDebug("Expected 0 thumbnails but found " + updatedThumbsNumber);
            throw "Unexpected number of thumbnails found after deleting photo";
        }
    },


    /**
     * Plays the last video from the camera roll. Captures a new video if none exist.
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     * @param {int} [args.playbackDuration=3] - Duration of playback in seconds.
     */
    playCapturedVideo: function playCapturedVideo(args) {
        args = UIAUtilities.defaults(args, {
            playbackDuration: 3,
        });

        camera.playVideoForDuration(args.playbackDuration);
    },

    /**
     * Sets a portrait lighting effect.
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     * @param {int} [args.targetLighting="stage light"] - The desired lighting effect
     */
    setPortraitLighting: function setPortraitLighting(args) {
        args = UIAUtilities.defaults(args, {
            targetLighting: 'stage light',
        });

        camera.launch();
        camera.setCameraMode('portrait')
        camera.setPortraitLighting(args.targetLighting);
    },
};
