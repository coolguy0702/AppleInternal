load('UIAUtility.js');
load('UIAApp.js');
load('UIAApp+Message.js');
load('SpringBoard.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIAQuery.Messages = {
    /** 'Compose' button in message thread view */
    COMPOSE_BUTTON: UIAQuery.buttons('Compose').orElse(UIAQuery.buttons('composeButton')).orElse(UIAQuery.navigationBars().andThen(UIAQuery.buttons().rightmost())),

    /** 'Edit' button in message thread view */
    EDIT_BUTTON: UIAQuery.buttons('Edit'),

    /** 'Cancel' button in message thread view after 'Edit' has been tapped */
    CANCEL_EDIT_BUTTON: UIAQuery.navigationBars().leftmost().andThen('Cancel'),

    /** 'Details' button in conversation view */
    DETAILS_BUTTON: UIAQuery.buttons('Details'),

    /** Photo button in conversation view */
    PHOTO_BUTTON: UIAQuery.buttons('photoButton'),

    /** Send button in conversation view */
    SEND_BUTTON: UIAQuery.buttons('Send'),

    /** Audio button in conversation view */
    AUDIO_BUTTON: UIAQuery.buttons('axAudioButton'),

    /** Search bar in thread list view */
    SEARCH_BAR: UIAQuery.searchBars('Search'),

    /** Navigation bar found in the main thread view */
    THREAD_LIST_NAVBAR: UIAQuery.navigationBars().contains('Messages'),

    /** Navigation bar found when selecting details from conversation view */
    DETAILS_NAVBAR: UIAQuery.navigationBars().contains('Details'),

    /** 'Messages' button of the leftmost navigation bar */
    MESSAGES_BUTTON: UIAQuery.buttons('Messages'),

    /** Photo picker window */
    PHOTO_PICKER_WINDOW: UIAQuery.navigationBars('Photos').orElse(UIAQuery.collectionViews('PhotosGridView')),

    /** Search controller */
    SEARCH_CONTROLLER: UIAQuery.withPredicate('any identifiers contains "UISearchController"'),

    /** Navigation bar found when looking at a single conversation thread */
    CONVERSATION_NAVBAR: UIAQuery.navigationBars('Messages').andThen(UIAQuery.query('CKAvatarContactNameCollectionReusableView')),

    /** Button to go back from a Conversation view to the Thread List view */
    CONVERSATION_BACK_BUTTON: UIAQuery.buttons('back-nav-button'),

    /** Window on which we ask about the horizontal size class */
    MESSAGES_WINDOW: UIAQuery.query('AXChatMainWindow').orElse('CKConversationListTableView'),

    /** The 'A'  - app store icon, button to open messages app store */
    APPSTORE_BUTTON: UIAQuery.buttons('browserButton'),

    /** Pane with Message Nickname setup */
    MESSAGE_NICKNAME: UIAQuery.staticTexts().contains('Message Nickname'),

    /** The heading in the Whats New in Messages screen */
    WHATSNEW_VIEW: UIAQuery.staticTexts('What\’s New in Messages').orElse(UIAQuery.query('CKWelcomeView')),

    /** The Messages in iCloud screen in messages */
    ICLOUD_MESSAGES_VIEW: UIAQuery.staticTexts('Messages in iCloud'),

    /** Continue button - appears on Whats New in Messages view*/
    CONTINUE_BUTTON: UIAQuery.buttons('Continue'),

    /** "Use iCloud" button - appears on Messages in iCloud view*/
    USE_ICLOUD_BUTTON: UIAQuery.buttons('Use iCloud'),

    /** "Not Now" button - appears on Messages in iCloud view*/
    NOT_NOW_BUTTON: UIAQuery.buttons('Not Now'),

    /** The heading in the Send Money with Apple Pay screen */
    APPLEPAY_VIEW: UIAQuery.staticTexts('Send Money with Apple Pay'),

    /** Review view in Camera mode */
    CAMERA_REVIEW_VIEW: UIAQuery.query('PUReviewScreenControlBar'),

    /** The Share Name + photos view */
    SHARE_NAME_AND_PHOTOS_VIEW: UIAQuery.staticTexts().contains('Share your Name and Photo in Messages'),

    /** Setup later button - appears on Share Name + Photo Over Messages*/
    SETUP_LATER_BUTTON: UIAQuery.buttons('Setup Later').orElse(UIAQuery.buttons("Set Up Later in Settings"))
};

UIAQuery.Messages.APPSTORE = {
    /** Navigation bar found when looking at app in full screen - the messages' plugin apps */
    FULLSCREEN_APPVIEW_NAVBAR: UIAQuery.navigationBars('CKFullScreenAppView').andThen(UIAQuery.query('CKAvatarContactNameCollectionReusableView')),

    /** Dismiss button on App FullScreen View */
    DISMISS_BUTTON: UIAQuery.navigationBars().leftmost().andThen('Dismiss').isVisible(),

    /** App Browser button on the bottom left in AppStore view */
    APP_BROWSER_BUTTON: UIAQuery.collectionViews('appSelectionBrowserIdentifier').andThen('More'),

    /** Expand button on the top center in the AppStore view */
    EXPAND_BUTTON: UIAQuery.buttons('Expand app').isVisible(),

    /** Collapse button on the top center in the AppStore view */
    COLLAPSE_BUTTON: UIAQuery.buttons('Collapse app').isVisible(),

    /** AppStore default generic view*/
    MAIN_VIEW: UIAQuery.windows('UITextEffectsWindow').andThen('UIInputSetHostView').andThen('CKBrowserSwitcherFooterView').isVisible(),

    /** AppStore Apps List view*/
    APPSTORELIST_VIEW: UIAQuery.windows('UIRemoteKeyboardWindow').andThen('UIInputView').andThen(UIAQuery.tableCells('Store')).isVisible(),

    /** Apps list container at the bottom **/
    APPSLIST_VIEW: UIAQuery.collectionViews('appSelectionBrowserIdentifier'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIStateDescription.Messages = {
    /** Thread list view */
    THREAD_LIST:                'Messages',

    /** Edit button pressed in thread list view */
    THREAD_LIST_EDIT:           'Edit Messages',

    /** New Message view */
    NEW_MESSAGE:                'New Message',

    /** Conversation view */
    CONVERSATION:               'Conversation',

    /** Details view */
    DETAILS:                    'Details',

    /** Camera view */
    CAMERA:                     'Camera',

    /** Photo picker view */
    PHOTO_PICKER:               'Photo Picker',

    /** Search view is active */
    ACTIVE_SEARCH:              'Active Search',

    /** Review view after taking a photo */
    REVIEW_VIEW:                'Review View',

    /** Message Nickname view */
    MESSAGE_NICKNAME:           'Message Nickname',

    /** Whats New in Messages view */
    WHATSNEW_VIEW:              'Whats New in Messages',

    /** Messages in iCloud screen view */
    ICLOUD_MESSAGES_VIEW:       'Messages in iCloud',
 
    /** Share Name + Photo Over Messages */
    SHARE_NAME_AND_PHOTOS_VIEW: 'Share your Name and Photo Over Messages'
};

UIStateDescription.Messages.APPSTORE = {
    /** Conversation view */
    FULLSCREEN_APPVIEW:               'Full Screen App View',
};

/**
    @namespace
    @augments UIAApp
*/
var messages = target.appWithBundleID('com.apple.MobileSMS');

// Message bot numbers
messages.MessageBots = [
'4086434602', //MB1
'4086509301', //MB2
'4085643317', //MB3
'4085824540', //MB4
'4086237664', //MB5
'4085824150', //MB6
'4086433813', //MB7
'4084396460', //MB8
'4084395032', //MB9
'4085063425', //MB10
];


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state. See Messages UIStateDescription constants
* for possible values. Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Messages UIStateDescription.
*
* @throws If cannot determine state.
*/
messages.currentUIState = function currentUIState() {
    this.launch();
    var appInfo = this.inspect(UIAQuery.application());

    if (appInfo.exists(UIAQuery.Messages.WHATSNEW_VIEW)) {
        return UIStateDescription.Messages.WHATSNEW_VIEW;
    }

    if (appInfo.exists(UIAQuery.Messages.MESSAGE_NICKNAME)) {
        return UIStateDescription.Messages.MESSAGE_NICKNAME;
    }

    if (appInfo.exists(UIAQuery.Messages.ICLOUD_MESSAGES_VIEW)) {
        return UIStateDescription.Messages.ICLOUD_MESSAGES_VIEW;
    }

    if (appInfo.exists(UIAQuery.Messages.APPSTORE.FULLSCREEN_APPVIEW_NAVBAR)) {
        return UIStateDescription.Messages.APPSTORE.FULLSCREEN_APPVIEW;
    }

    if (appInfo.exists(UIAQuery.Messages.SEARCH_CONTROLLER) && appInfo.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
        return UIStateDescription.Messages.ACTIVE_SEARCH;
    }

    if (appInfo.exists(UIAQuery.Messages.CAMERA_REVIEW_VIEW)) {
        return UIStateDescription.Messages.REVIEW_VIEW;
    }

    if (appInfo.exists(UIAQuery.Messages.CONVERSATION_BACK_BUTTON)) {
        return UIStateDescription.Messages.CONVERSATION;
    }

    if (appInfo.exists(UIAQuery.Messages.PHOTO_PICKER_WINDOW)) {
        return UIStateDescription.Messages.PHOTO_PICKER;
    }

    if (appInfo.exists(UIAQuery.CAMERA_VIEW)) {
        return UIStateDescription.Messages.CAMERA;
    }

    if (appInfo.exists(UIAQuery.Messages.DETAILS_NAVBAR)) {
        return UIStateDescription.Messages.DETAILS;
    }

    if (appInfo.exists(UIAQuery.MESSAGE_NEW_COMPOSE_NAVBAR)) {
        return UIStateDescription.Messages.NEW_MESSAGE;
    }

    if (appInfo.exists(UIAQuery.Messages.APPLEPAY_VIEW)) {
        return UIStateDescription.Messages.APPLEPAY_VIEW;
    }

    if (appInfo.exists(UIAQuery.Messages.SHARE_NAME_AND_PHOTOS_VIEW)) {
        return UIStateDescription.Messages.SHARE_NAME_AND_PHOTOS_VIEW;
    }
 
    var navBar = appInfo.inspect(UIAQuery.navigationBars().leftmost());
    if (navBar) {
        var navBarName = navBar.name;

        // determine whether navBarName contains 'Messages'
        if (navBarName.indexOf('Messages') >= 0) {
            if (this.exists(UIAQuery.Messages.CANCEL_EDIT_BUTTON)) {
                return UIStateDescription.Messages.THREAD_LIST_EDIT;
            }
            if (this.exists(UIAQuery.Messages.APPSTORE.DISMISS_BUTTON)) {
                return UIStateDescription.Messages.APPSTORE.FULLSCREEN_APPVIEW;
            }
            return UIStateDescription.Messages.THREAD_LIST;
        }

        if (navBarName === UIStateDescription.Messages.DETAILS) {
            return UIStateDescription.Messages.DETAILS;
        }
    }

    // if we got here, we have no clue where we are...
    throw new UIAError('Could not determine state in Messages.');
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [state]                                                      */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 *  Navigation function to get to the main thread list view.
 */
messages.getToThreadList = function getToThreadList(options) {
    options = UIAUtilities.defaults(options, {
        currentState: this.currentUIState(),
        recurLevel: 0,
    });

    // Max depth from the top level is 2 actions. Adding 1 extra.
    if (options.recurLevel >= 3) {
        throw new UIAError('Could not get to thread list after 3 actions.');
    }

    if (options.recurLevel === 0) {
        this.launch();

        // dismiss popovers
        if (this.exists(UIAQuery.VISIBLE_POPOVERS)) {
            UIAUtilities.assert(
                this.dismissPopover() ||
                this.tapIfExists(UIAQuery.popovers().andThen(UIAQuery.CANCEL_BUTTON)),
                "Popover exists but couldn't be dismissed."
            );
        }

        // dismiss action sheets
        if (this.exists(UIAQuery.actionSheets())) {
            UIAUtilities.assert(
                this.tapIfExists(UIAQuery.actionSheets().andThen(UIAQuery.CANCEL_BUTTON)),
                "Action sheet exists but couldn't be dismissed."
            );
        }
    }

    switch (options.currentState) {
        case UIStateDescription.Messages.WHATSNEW_VIEW:
            this.tap(UIAQuery.Messages.CONTINUE_BUTTON);
            break;
        case UIStateDescription.Messages.MESSAGE_NICKNAME:
            this.tap(UIAQuery.CANCEL_BUTTON.isVisible());
            break;
        case UIStateDescription.Messages.ICLOUD_MESSAGES_VIEW:
            this.tap(UIAQuery.Messages.NOT_NOW_BUTTON);
            break;
        case UIStateDescription.Messages.THREAD_LIST_EDIT:
            this.tap(UIAQuery.Messages.CANCEL_EDIT_BUTTON);
            break;
        case UIStateDescription.Messages.DETAILS:
            if (this.isHorizontalSizeClassCompact(UIAQuery.Messages.MESSAGES_WINDOW)) {
                this.tap(UIAQuery.DONE_BUTTON);
            }
            break;
        case UIStateDescription.Messages.CONVERSATION:
            if (this.isHorizontalSizeClassCompact(UIAQuery.Messages.MESSAGES_WINDOW)) {
                this.tap(UIAQuery.Messages.CONVERSATION_BACK_BUTTON);
            }
            break;
        case UIStateDescription.Messages.CAMERA:
            this.tap((UIAQuery.CAMERA_DONE_BUTTON.isVisible()).orElse(UIAQuery.CANCEL_BUTTON.isVisible()));
            break;
        case UIStateDescription.Messages.REVIEW_VIEW:
            this.tap(UIAQuery.CAMERA_DONE_BUTTON.isVisible());
            break;
        case UIStateDescription.Messages.PHOTO_PICKER:
        case UIStateDescription.Messages.ACTIVE_SEARCH:
        case UIStateDescription.Messages.NEW_MESSAGE:
            this.tap(UIAQuery.CANCEL_BUTTON.isVisible());
            break;
        case UIStateDescription.Messages.APPSTORE.FULLSCREEN_APPVIEW:
            if (this.isHorizontalSizeClassCompact(UIAQuery.Messages.MESSAGES_WINDOW)) {
                this.tap(UIAQuery.Messages.APPSTORE.DISMISS_BUTTON);
            }
            break;
        case UIStateDescription.Messages.APPLEPAY_VIEW:
            this.tap(UIAQuery.Messages.CONTINUE_BUTTON);
            break;
        case UIStateDescription.Messages.SHARE_NAME_AND_PHOTOS_VIEW:
            this.tap(UIAQuery.Messages.SETUP_LATER_BUTTON);
            break;
        default:
            break;
    }

    options.currentState = this.currentUIState();

    // On Regular Horizontal Size Class when you're on the Conversation or Details view you also have the Thread List view
    if (this.exists(UIAQuery.Messages.MESSAGES_WINDOW) && this.isHorizontalSizeClassRegular(UIAQuery.Messages.MESSAGES_WINDOW)) {
        if (options.currentState === UIStateDescription.Messages.CONVERSATION
            || options.currentState === UIStateDescription.Messages.DETAILS) {
            UIALogger.logMessage('Successfully got to thread list.');
            return;
        }
    }

    if (options.currentState !== UIStateDescription.Messages.THREAD_LIST) {
        options.recurLevel++;
        this.getToThreadList(options);
        return;
    }

    UIALogger.logMessage('Successfully got to thread list.');
};

/**
 *  Navigation function to get to the 'New Message' view.
 */
messages.getToComposeUI = function getToComposeUI() {
    this.getToThreadList();
    this.tapIfExists(UIAQuery.Messages.COMPOSE_BUTTON);

    this.assertExists(
        UIAQuery.MESSAGE_NEW_COMPOSE_NAVBAR,
        'Could not get to New Message view.'
    );
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Tasks                                                               */
/*                                                                             */
/*      A high-level goal we are trying to accomplish.                         */
/*      Comprised of multiple Action functions and do not assume state         */
/*                                                                             */
/*******************************************************************************/

/**
 *  Sends a message to one or more recipients.
 *
 * @param {object}  options
 * @param {array} options.recipients - an array of phone numbers or
 *              addresses to send the message to.
 * @param {null|string} options.text - text to include in the message body.
 * @param {null|object} options.media - an object describing the type of media
 *              to include in the message.
 * @param {number} options.timeout - (Optional) timeout (in seconds) to wait for delivery of the message 
 *
 * @throws if message cannot be sent
 */
messages.sendMessage = function sendMessage(options) {
    options = UIAUtilities.defaults(options, {
        recipients: [springboard.appleID],
        text:'I am text.',
        media: null,
        timeout: 60, 
    });

    // Clear out text message since we are recording an audio file
    if (options.media !== null && options.media.type === 'audio') {
        options.text = null;
    }

    if (options.recipients && !(options.recipients instanceof Array)) {
        options.recipients = [options.recipients];
    }

    this.getToThreadList();

    // see if we can find an existing thread for this recipient and select if possible
    var threadCell = (options.recipients.length === 1) ? UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells().contains(options.recipients[0])) : null;

    if (threadCell && this.exists(threadCell)) {
        UIALogger.logMessage('Selecting thread "%0"'.format(options.recipients[0]));
        this.tap(threadCell);
        options.recipients = null;  // if the thread has already been selected, clear out the recipients option for the call to __proto__
        UIAUtilities.assert(this.isInMessagesCompositionUI(), 'Unable to load existing message thread');
    } else {
        this.getToComposeUI();
    }

    return this.__proto__.sendMessage.apply(this, [options]);  // calling proto implementation
};

/**
 *  Sends a message and waits for a response.
 *
 * @param {object}  options - a dictionary object of optional arguments
 * @param {object}  [options.sendOptions={}] - options to configure the message send
 *  (see [UIAApp+Message.sendMessage]{@link UIAApp+Message#sendMessage} for more details on options)
 * @param {object}  [options.receiveOptions={}] - options to configure the message reply
 *  (see [UIAApp+Message.recieveMessage]{@link UIAApp+Message#receiveMessages} for more details on options)
 * @param {number}  [options.minPercent=100] - the minimum percent of message count to expect
 * @param {number}  [options.retryCount=0] - how many times to retry if minPercent condition is not met
 * @param {number}  [options.timeout=60] - (Optional) timeout (in seconds) to wait for delivery of the message 
 *
 * @throws if message cannot be sent or is not received
 */
messages.sendReceiveMessage = function sendReceiveMessage(options) {
    options = UIAUtilities.defaults(options, {
        sendOptions: {
            recipients: [springboard.appleID],
            text:'I am text.',
            media: null,
            timeout: 60, 
        }
    });

    this.getToThreadList();
    this.__proto__.sendReceiveMessage.apply(this, [options]);
};

/**
 *  Sends message from lock screen, waits for response, and opens message
 *  from lock screen notification.
 *
 * @param {object}  options
 * @param {string} options.recipients - an array of phone numbers or
 *              addresses to send the message to.
 * @param {string} options.text - text to include in the message body.
 *
 * @throws if message doesn't appear or isn't opened from lock screen
 */
messages.openMessageFromLockedScreen = function openMessageFromLockedScreen(options) {
    options = UIAUtilities.defaults(options, {
        recipient: springboard.appleID,
        text:'Wake up!',
    });

    springboard.lock();
    var waiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass = "NCNotificationPriorityListViewController"'
    );

    UIALogger.logMessage('Sending message to [%0] with text [%1] expecting to get a response'.format(options.recipient, options.text));

    // use imtool to send message from locked screen
    target.performTask(
        '/usr/local/bin/imtool',
        ['message', '-h', options.recipient, '-m', options.text], 20
    );

    // wait for response
    UIAUtilities.assert(
        waiter.wait(30),
        'Did not receive message notification on locked screen'
    );

    var messageNotification = UIAQuery.query('SBDashBoardViewBase').andThen(UIAQuery.contains('MESSAGES'));
    waiter = UIAWaiter.withPredicate(
        'ApplicationStateChanged',
        'bundleID = "com.apple.MobileSMS" AND state = "Foreground"'
    );

    // swipe right on lock screen notification to open message
    springboard.dragRightInside(messageNotification, {flick: true});

    // confirm that we opened the right message
    UIAUtilities.assert(
        waiter.wait(10) && this.exists(UIAQuery.contains(options.text)),
        'Did not open message with desired recipient'
    );

    UIALogger.logMessage('Succesfully opened message from lock screen');
};

/**
 *  Deletes one or more thread.
 *
 * @param {object}  options
 * @param {null|array} options.threadNames - name(s) of thread(s) to be deleted.
 *              The string can be the contact name/number or text that is contained
 *              within a message. If threadNames is specified it will override
 *              the threadIndex and threadCount options.
 * @param {null|number} options.threadIndex - starting index of thread(s) to be
 *              deleted. Only used when threadNames is null.
 * @param {null|number} options.threadCount - number of threads to be deleted.
 *              Only used when threadNames is null.
 *
 * @throws if thread(s) cannot be deleted
 */
messages.deleteThreads = function deleteThreads(options) {
    options = UIAUtilities.defaults(options, {
        threadNames: null,
        threadIndex: 0,
        threadCount: 1,
        useSwipe: true,
    });

    if (options.threadNames && !(options.threadNames instanceof Array)) {
        options.threadNames = [options.threadNames];
    }

    if (options.threadNames) {
      UIALogger.logMessage('Will attempt to delete threads with the following text:\n');
      for (var i = 0; i < options.threadNames.length; i++) {
          UIALogger.logMessage('  "%0"\n'.format(options.threadNames[i]));
      }
    } else {
        UIALogger.logMessage('Will attempt to delete %0 threads starting at index %1.'.format(options.threadCount, options.threadIndex));
    }

    this.getToThreadList();

    var allCells = UIAQuery.LEFT_TABLE.andThen(UIAQuery.tableCells());
    this.assertExists(allCells, 'No message threads were found.');

    var loopCount;
    if (options.threadNames) {
        loopCount = options.threadNames.length;
    } else {
        loopCount = options.threadCount;
        UIAUtilities.assert(
            this.count(allCells) >= options.threadCount,
            'Trying to delete %0 threads, but only %1 threads exist.'.format(options.threadCount, this.count(allCells))
        );
    }

    var cell;
    var count;
    var index;
    if (options.useSwipe) {
        for (index = 0; index < loopCount; index++) {
            cell = (options.threadNames) ? allCells.contains(options.threadNames[index]) : allCells.atIndex(options.threadIndex);
            count = this.count(allCells);
            this.dragLeftInside(cell);
            this.tap(cell.andThen(UIAQuery.buttons('Delete')));
            UIAUtilities.assert(
                count > this.count(allCells),
                'Thread count did not change after trying to delete thread.'
            );
        }
    } else {
        this.tap(UIAQuery.Messages.EDIT_BUTTON);
        count = this.count(allCells);
        for (index = 0; index < loopCount; index++) {
            cell = (options.threadNames) ? allCells.contains(options.threadNames[index]) : allCells.atIndex(options.threadIndex + index);
            this.tap(cell);
        }
        this.tap('Delete');
        UIAUtilities.assert(
            count > this.count(allCells),
            'Thread count did not change after attempting to delete thread(s).'
        );
    }
};

/**
 * Verifies a Thread exists
 *
 * @param {array} threads - the contact names of threads we want to verify
 */
messages.verifyThreadsExist = function verifyThreadsExist(threads) {
    this.getToThreadList();

    for (var i = 0; i < threads.length; i++) {
        this.search(threads[i], true);
    }
};

/**
 * Verifies that a message exists in the transcript history
 *
 * @param {object} searchTerms - An object containing the search criteria used to find the message
 * @param {string} searchTerms.contact - Optionally specify a contact as displayed in the UI
 * @param {string} searchTerms.text - Specify the text of the message
 *
 * @returns {boolean} true if the message is found, false otherwise
 */
messages.verifyMessageExists = function verifyMessageExists(searchTerms) {
    this.getToThreadList();

    var options = {
        dragDownForSearchField: true,
    };

    // If a contact was specified, see if contact exists
    if (searchTerms.contact !== null) {
        UIALogger.logMessage('Searching by contact');
        this.search(searchTerms.contact, options);
    }

    // Check to see if the text exists
    if (searchTerms.text !== null) {
        UIALogger.logMessage('Searching by text');
        this.search(searchTerms.text, options);
    }
};

/**
 * Dump and collect messages logs
 *
 * @targetApps MobileSMS
 *
 */
messages.dumpAndCollectLogs = function dumpAndCollectLogs() {
    var waiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerTitle = "IDS Log Dump"'
    );

    messages.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.staticTexts('IDS Log Dump')), function() {
        var result = performTask('/usr/local/bin/idstool', ['dump'], 10);
        //Wait for slower devices.
        waiter.wait(30);
        springboard.tapIfExists(UIAQuery.alerts().andThen('OK'));
    });
};

/**
 * Uses the search bar to search for text in messages.
 *
 * @param {object}  options
 * @param {string} text - the text to search for. The text can be
 *            a contact name/number/address or text within a message.
 * @param {null|boolean} verifyResult - check to see if a result is found, throw
 *              an error if not.
 *
 * @throws if verifyResult is true and text is not found
 */
messages.search = function search(text, verifyResult) {
    this.getToThreadList();
    this.__proto__.search.apply(this, [text]);
    if (verifyResult) {
        UIAUtilities.assert(
            this.exists(UIAQuery.tableViews().leftmost().andThen(UIAQuery.tableCells())),
            'Text not found by search.'
        );
    }
};

/**
 *  Used to send a quick reply to Banner notifications
 *
 *  @param {string}   textMessage - Text to send using quick reply
 *  @param {integer}  timeout - the timeout period to wait for notification to arrive
 *
 */
messages.replyToBannerNotification = function replyToBannerNotification(textMessage, timeout) {
    var notificationViewWaiter = UIAWaiter.withPredicate('Announcement', 'announcement CONTAINS "MESSAGES"');
    //Go to home screen
    springboard.launch();
    try {
        springboard.handlingAlertsInline(UIAQuery.banners('NCNotificationShortLookView').andThen(UIAQuery.beginsWith('MESSAGES')), function() {
            // Wait for banner notification to appear
            if (notificationViewWaiter.wait(timeout)) {
                UIALogger.logMessage('Attempting to swipe down on notification');
                springboard.dragDownInside(UIAQuery.buttons().first(), {flick: true , duration:1 ,fromOffset: {x: 0.50, y: 0.10}, toOffset: {x: 0.50, y: 5}});
                springboard.enterText(UIAQuery.query('messageBodyField'),textMessage, {clearTextBeforeTyping:false, allowTypeStringToRetry:true});
                springboard.tapIfExists(UIAQuery.Messages.SEND_BUTTON);
                springboard.tapIfExists(UIAQuery.buttons('Dismiss'));

            } else {
                throw new UIAError("No Banner appeared within specified timeout period");
            }

        });
    } catch (error) {
        throw new UIAError("Quick Reply to Notificationed failed : " + error.message);
    }
};

/**
* Used to create a group message
* @param {object} options - a dictionary object of optional arguments
* @param {string} options.recipients - an array of phone numbers or addresses to send to
* @param {string} options.text - text to include in the message body
* @param {object} options.media - an object describing the type of media to include in the message
* @param {string} options.groupName - name of the group
* @param {number} options.timeout - (Optional) timeout (in seconds) to wait for delivery of the message 
*/
messages.createGroup = function createGroup(options) {
    options = UIAUtilities.defaults(options, {
        recipients: [springboard.appleID,UIAUtilities.randomItem(messages.MessageBots)],
        text:'Sending message to a group',
        media: null,
        groupName:'Group Message Test', 
        timeout: 60, 
    });

    //Send Message to multiple recipients
    messages.sendMessage(options);

    //Tap on More Info Button and enter group name
    var detailsViewWaiter = UIAWaiter.withPredicate('ViewDidAppear', 'navigationItemTitle = "Details"');
    try {
        this.tap(UIAQuery.MORE_INFO_BUTTON);
        if (!detailsViewWaiter.wait(10)) {
          throw new UIAError('Details View did not appear.');
        }
        this.tap(UIAQuery.textFields('Enter a Group Name'));
        UIALogger.logMessage('Entering in group name "%0"'.format(options.groupName));
        this.enterText(UIAQuery.textFields('Enter a Group Name'),options.groupName);
        UIALogger.logMessage('Entered group name "%0"'.format(options.groupName));
        this.tap(UIAQuery.DONE_BUTTON);
    } catch (error) {
        error.message = 'Group Name could not be entered: [0%]'.format(error.message);
        throw error;
    }

    //Validate group name displayed in conversation view

    var groupNameInConversationView = this.inspectElementKey(UIAQuery.query('CKAvatarTitleCollectionReusableView')
					   .andThen(UIAQuery.staticTexts()), 'label');

    if (groupNameInConversationView === options.groupName) {
        UIALogger.logMessage('Group Name matched. Expected Group Name: "%0". Group Name in Conversation View: "%1"'
                              .format(options.groupName, groupNameInConversationView));
    } else {
        throw new UIAError('Group Name did not match. Expected Group Name: "%0". Group Name in Conversation View: "1%"'
                            .format(options.groupName, groupNameInConversationView));
    }
};

/**
 * Open App Store in existing conversation or compose window
 *
 * @targetApps Messages
 *
 * @param {object} options Test arguments
 *
 * @param {string} [options.textToFindMessage=''] - text to find and open an existing message
 *
 * @param {array} [options.recipients=['MY_PHONE_NUMBER']] - New Message Only; an array of recipients or account IDs to send the message to <br>
 *                Default: MY_PHONE_NUMBER; phone number of the device if exists
 *
 **/
messages.getToAppStore = function getToAppStore(options) {
    options = UIAUtilities.defaults(options, {
        textToFindMessage: '',
        recipients: ['MY_PHONE_NUMBER'],
    });

    UIALogger.logMessage('Attempting to get to AppStore...');

    if (options.textToFindMessage) {
        UIALogger.logMessage('Search for existing conversation with text "%0"'.format(options.textToFindMessage));
        this.getToThreadList();
        this.tap(UIAQuery.withPredicate("name contains[c] '%0'".format(options.textToFindMessage)));
        this.waitUntilPresent(UIAQuery.Messages.CONVERSATION_NAVBAR);
    } else {
        UIALogger.logMessage('Opening new message window and typing recipients "%0"'.format(options.recipients));
        this.getToComposeUI();
        this.enterMessageRecipients(options.recipients);
    }

    // Arrow button hides the AppStore button
    this.tapIfExists(UIAQuery.ARROW_BUTTON);

    UIALogger.logMessage('Waiting for app store to open.');
    if (!this.waitUntilPresent(UIAQuery.Messages.APPSTORE.MAIN_VIEW)) {
        if (this.waitUntilPresent(UIAQuery.Messages.APPSTORE_BUTTON)) {
            UIALogger.logMessage('Tapping AppStore button to open app store.');
            this.tap(UIAQuery.Messages.APPSTORE_BUTTON);
        }
        this.assertExists(UIAQuery.Messages.APPSTORE.MAIN_VIEW, 'AppStore did not appear.');
    }
};

/**
 * Open Message's AppStore app list
 *
 * @targetApps Messages
 *
 * @param {object} options Test arguments
 *
 * @param {string} [options.textToFindMessage=''] - text to find and open an existing message
 *
 * @param {array} [options.recipients=['MY_PHONE_NUMBER']] - New Message Only; an array of recipients or account IDs to send the message to <br>
 *                Default: MY_PHONE_NUMBER; phone number of the device if exists
 *
 **/
messages.getToAppsList = function getToAppsList(options) {
    options = UIAUtilities.defaults(options, {
        textToFindMessage: '',
        recipients: ['MY_PHONE_NUMBER'],
    });

    UIALogger.logMessage('Attempting to get to AppsList...');

    // open AppStore
    this.getToAppStore(options);

    UIALogger.logMessage('waiting for apps list to appear.');
    if (!this.waitUntilPresent(UIAQuery.Messages.APPSTORE.APPSLIST_VIEW)) {
        throw new UIAError('AppStore Apps List did not appear.');
    }
};

/**
 * Launch a Message's AppStore app
 *
 * @targetApps Messages
 *
 * @param {object} options Test arguments
 *
 * @param {string} [options.appName=''] - app name to launch
 *
 * @param {string} [options.textToFindMessage=''] - text to find and open an existing message
 *
 * @param {array} [options.recipients=['MY_PHONE_NUMBER']] - New Message Only; an array of recipients or account IDs to send the message to <br>
 *                Default: MY_PHONE_NUMBER; phone number of the device if exists
 *
 **/
messages.launchAppStoreApp = function launchAppStoreApp(options) {
    options = UIAUtilities.defaults(options, {
        appName: '',
        textToFindMessage: '',
        recipients: ['MY_PHONE_NUMBER'],
    });

    UIALogger.logMessage('Attempting to launch AppStore App...');

    if (!options.appName) {
        throw new UIAError("Please provide Message's AppStore app name.");
    }

    if (!this.isRunning()) {
        this.launch();
    }

    if (!this.exists(UIAQuery.Messages.APPSTORE.APPSLIST_VIEW)) {
        this.getToAppsList(options);
    }

    UIALogger.logMessage('Tapping app "%0" in the list'.format(options.appName));
    this.tap(UIAQuery.Messages.APPSTORE.APPSLIST_VIEW.andThen(UIAQuery.tableCells().withPredicate("name contains[c] '%0' ".format(options.appName))));

    UIALogger.logMessage('Waiting for main app store view to open.');
    this.waitUntilPresent(UIAQuery.Messages.APPSTORE.MAIN_VIEW);
};
