load('UIATesting.js');
load('Messages.js');

UIAUtilities.assert(
    typeof MessagesTests === 'undefined',
    'MessagesTests has already been defined.'
);

/** @namespace */

var MessagesTests = {

    /**
    * Deletes specified message thread.
    *
    * @targetApps MobileSMS
    *
    * @param {string} [args.threadName=null] - the name of the thread to be deleted (allows partial matches, null deletes first thread)
    * @param {object} [args.deleteOptions=null] - additional options to configure the delete call
    *  (see [Messages.deleteThread]{@link Messages#deleteThread} for more details on options that can be passed through deleteOptions)
    */
    deleteThread: function deleteThread(args) {
        args = UIAUtilities.defaults(args, {
            threadName: null,
            threadIndex: 0,
            deleteOptions: null,
        });

        if (args.threadName) {
            args.threadNames = [args.threadName];
        }

        if (args.deleteOptions) {
            args.useSwipe = args.deleteOptions.useSwipe;
        }

        messages.deleteThreads(args);
    },

    /**
    * Deletes one or more message threads.
    *
    * @targetApps MobileSMS
    *
    * @param {object} args Test arguments
    * @param {null|array}    [args.threadNames=null] - the name(s) of the thread(s)
    *                               to be deleted (allows partial matches). If
    *                               threadNames is specified it will override the
    *                               threadIndex and threadCount options.
    * @param {number}           [args.threadIndex=0] - starting index of thread(s)
    *                               to be deleted. Only used when threadNames is null.
    * @param {number}           [args.threadCount=0] - number of threads to be deleted.
    *                               Only used when threadNames is null.
    * @param {boolean}          [args.useSwipe=true] - specifies whether to use swipe
    *                               left gesture to delete the threads. If this is
    *                               false, will use the Edit and Delete buttons to
    *                               delete the threads.
    */
    deleteThreads: function deleteThreads(args) {
        args = UIAUtilities.defaults(args, {
            threadNames: null,
            threadIndex: 0,
            threadCount: 1,
            useSwipe: true,
        });

        messages.deleteThreads(args);
    },

    /**
     * Send a message and waits for a response.
     *
     * @targetApps MobileSMS
     *
     * @param {object} args Test arguments
     * @param {object} [args.sendOptions=null] - options to configure the message send
     *  (see [UIAApp+Message.sendMessage]{@link UIAApp+Message#sendMessage} for more details on options that can be passed through sendOptions)
     * @param {object} [args.receiveOptions=null] - options to configure the message reply
     *  (see [UIAApp+Message.receiveMessages]{@link UIAApp+Message#receiveMessages} for more details on options that can be passed through receiveOptions)
     * @param {array}  [args.minPercent=100] - the minimum percent of message count to expect
     * @param {number} [args.retryCount=0] - how many times to retry if minPercent condition is not met
     */
    sendReceiveMessage: function sendReceiveMessage(args) {
        args = UIAUtilities.defaults(args, {
            sendOptions: {
                recipients: [UIAUtilities.randomItem(messages.MessageBots)],
                text:'I am text.',
                media: null,
                timeout: 60, 
            },
            receiveOptions: {
                messages: null,
                messageCount: 1,
                timeout: 60,
            },
            minPercent: 100,
            retryCount: 0,
        });

        if (!args.sendOptions.recipients) {
            args.sendOptions.recipients = [UIAUtilities.randomItem(messages.MessageBots)];
        }

        messages.sendReceiveMessage(args);
    },

    /**
     * Open message from locked screen.
     *
     * @targetApps MobileSMS
     *
     * @param {object} args Test arguments
     * @param {string} [args.recipient=null] - phone number or address of the recipient
     * @param {string} [args.text=null] - text to send in message
     */
    openMessageFromLockedScreen: function openMessageFromLockedScreen(args) {
        args = UIAUtilities.defaults(args, {
            recipient: UIAUtilities.randomItem(messages.MessageBots),
            text:'Wake up!',
        });

        messages.openMessageFromLockedScreen(args);
    },

    /**
     * Dump and collect messages logs
     *
     * @targetApps MobileSMS
     *
     */
    dumpAndCollectLogs: function dumpAndCollectLogs() {
        messages.dumpAndCollectLogs();
    },

    /**
     * verify message threads exist
     *
     * @targetApps MobileSMS
     *
     * @param {object} args - Test arguments
     * @param {array} [args.threadNames=[]] - Conversation Names to verify
     */
    verifyThreadsExist: function verifyThreadsExist(args) {
        args = UIAUtilities.defaults(args, {
            threadNames: [],
        });
        messages.verifyThreadsExist(args.threadNames);
        UIALogger.logMessage('Thread names verified, all conversations exist');
    },

    /**
     * Verify that a message exists in the transcript history
     *
     * @param {object} args - test arguments
     * @param {string} [args.contact=null] - Optionally specify a contact as displayed in the UI
     * @param {string} [args.text=""] - Specify the text of the message
     */
    verifyMessageExists: function verifyMessageExists(args) {
        args = UIAUtilities.defaults(args, {
            contact: null,
            text: '',
            threadNames: [],
        });

        messages.verifyMessageExists(args);
    },

    /**
     * Send a quick reply banner notification
     * @param {object} args - test arguments
     * @param {string}   textMessage - Text to send using quick reply
     * @param {integer}  timeout - the timeout period to wait for notification to arrive
     *
     */
    replyToBannerNotification: function replyToBannerNotification(args) {
        args = UIAUtilities.defaults(args, {
            textMessage : 'Quick Reply Test',
            timeout: 60,
        });
        messages.replyToBannerNotification(args.textMessage, args.timeout);
    },

    /**
     * Used to create a group message
     * @param {object} args - test arguments
     * @param {string} recipients - an array of phone numbers or addresses to send message to
     * @param {string} text - text to include in the message body
     * @param {object} media - an object describing the type of media to include in the message
     * @param {string} groupName - name of the group
     */
    createGroup: function createGroup(args) {
        args = UIAUtilities.defaults(args, {
              recipients: [springboard.appleID,UIAUtilities.randomItem(messages.MessageBots)],
              text:'Sending message to a group',
              media: null,
              groupName:'Group Message Test'
        });
        messages.createGroup(args);
    },
};
