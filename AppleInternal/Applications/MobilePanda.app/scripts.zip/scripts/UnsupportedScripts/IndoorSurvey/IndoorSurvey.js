load('UIAApp.js');
load('UIAUtility.js');
load('UIANavigation.js');
load('SpringBoard.js');
load('Settings.js');

UIAUtilities.assert(
    typeof survey === 'undefined',
    'survey has already been defined.'
);

var survey = target.appWithBundleID('com.apple.maps.bogota-surveyi');
survey.Views = {};
survey.Tasks = {};

load('IndoorSurveyViewsVenues.js');
load('IndoorSurveyViewsSurveys.js');
load('IndoorSurveyViewsStartSurvey.js');
load('IndoorSurveyViewsSurveyMode.js');
load('IndoorSurveyViewsSettings.js');
load('IndoorSurveyViewsBuildings.js');
load('IndoorSurveyViewsFloors.js');
load('IndoorSurveyViewsPositioningMode.js');
load('IndoorSurveyViewsSurveyOnMap.js');
load('IndoorSurveyViewsInternalSettings.js');
load('IndoorSurveyViewsReportProblem.js');
load('IndoorSurveyViewsSignIn.js');
load('IndoorSurveyViewsLicense.js');

load('IndoorSurveyTasksSignIn.js');
load('IndoorSurveyTasksLicense.js');
load('IndoorSurveyTasksVenues.js');
load('IndoorSurveyTasksBuildings.js');
load('IndoorSurveyTasksCommon.js');
load('IndoorSurveyTasksFloors.js');
load('IndoorSurveyTasksPositioningMode.js');
load('IndoorSurveyTasksSettings.js');
load('IndoorSurveyTasksStartSurvey.js');
load('IndoorSurveyTasksSurveyMode.js');
load('IndoorSurveyTasksSurveys.js');
load('IndoorSurveyTasksSurveyOnMap.js');
load('IndoorSurveyTasksInternalSettings.js');
load('IndoorSurveyTasksReportProblem.js');


UIStateDescription.Survey = {
    VENUES: 'VENUES',
    BUILDINGS: 'BUILDINGS',
    FLOORS: 'FLOORS',
    SURVEYS: 'SURVEYS',
    SETTINGS: 'SETTINGS',
    INTERNAL_SETTINGS: 'INTERNAL_SETTINGS',
    POSITIONING_MODE: 'POSITIONING_MODE',
    SURVEY_MAP: 'SURVEY_MAP',
    START_SURVEY: 'START_SURVEY',
    SURVEY_MODE: 'SURVEY_MODE',
    GET_STARTED: 'GET_STARTED',
    REPORT_PROBLEM: 'REPORT_PROBLEM',
    SIGNIN: 'SIGNIN',
    LICENSE: 'LICENSE',
};


survey.SURVEYSTATUS = {
    Invalid: "Alerts",
    Pending: "Pending Uploads",
    Uploaded: "Recently Uploaded",
};


survey.SWITCH = {
    On: true,
    Off: false,
};


survey.SCREENSHOTS = {
    Enabled: true,
    Folder: "/tmp/IndoorSurveyScreens/",
};


survey.SERVER = {
    QA1: "QA1",
    QA2: "QA2",
    Production: "Production",
    Custom: "Custom",
};


survey.sessionSettings = {
    isValidSignIn: false,
    shouldReuseSession: true,
    appleId: "arobot+1@apple.com",
    password: "aRobot123",
};


survey.viewPrototype = {
    dismissModalsAndGoBack: function dismissModalsAndGoBack() {
        var validatedView;
        var views = this.PREVIOUS_VIEWS;

        survey.Utils.assertViewIsCurrent([this]);

        this.dismissModals();
        this.performGoBackSteps();

        for (var i = 0, len = views.length; i < len; i += 1) {
            if (views[i].isCurrent()) {
                validatedView = views[i];
                break;
            }
        }

        if (views.length === 0) {
            validatedView = this;
        }

        if (validatedView) {
            return validatedView;
        }

        throw new UIAError('Ended up at an unexpected view: %0'.format(survey.currentView().STATE));
    },
};


survey.setPrototypeOnViews = function setPrototypeOnViews() {
    for (var key in survey.Views) {
        if (survey.Views.hasOwnProperty(key)) {
            Object.setPrototypeOf(survey.Views[key], survey.viewPrototype);
        }
    }
};


survey.Utils = {

    /**
     * Wrapper function around UIAApp.waitForViewToAppear
     * We have to use it due to issues in the Indoor Survey app
     * when several identical events are triggered while changing views
     *
     * If survey.Utils.waitForViewToAppear called with string as a first argument
     * then this string should be use as a predicate to pass to wrapped function
     * If first argument (args[0]) is not a string, then we using default predicate to pass to wrapped function
     * other arguments will be passed to the original function
     */
    waitForViewToAppear: function waitForViewToAppear() {
        // Defining predicate to skip *Navigation* controller class
        var DEFAULT_VIEW_PREDICATE = 'NOT (controllerClass LIKE "*Navigation*")';
        // Converting array-like collection "argument" (arguments passed to survey.Utils.waitForViewToAppear function) to the real array named "args"
        var args = Array.prototype.slice.call(arguments);

        if (typeof args[0] !== 'string') {
            args.unshift(DEFAULT_VIEW_PREDICATE);
        }

        // Calling original wrapped waitForViewToAppear function in the "survey" object scope with arguments from args array
        survey.waitForViewToAppear.apply(survey, args);
    },

    /**
     * @callback requestCallback
     * @param {object} view - View object
     */

    /**
     * @param {object} namespace - Any namespace (object) on which we want to find a member satisfies matchFunction
     * @param {requestCallback} matchFunction - Callback function which examines every object's member to satisfy some condition
     * @param {string} error - Error message when no member found in a namespace which satisfies matchFunction
     */
    findMemberOfNamespace: function findMemberOfNamespace(namespace, matchFunction, error) {
        var result = Object.getOwnPropertyNames(namespace).find(function (key) {
            return matchFunction(namespace[key]);
        });

        if (result) {
            return namespace[result];
        }

        throw new UIAError(error);
    },

    /**
     * @param {array} views - Array of Views objects
     */
    assertViewIsCurrent: function assertViewIsCurrent(views) {
        var isCurrent = false;
        var viewsStates = [];

        views.forEach(function(view) {
            viewsStates.push(view.STATE);
        });

        UIALogger.logMessage('===> "assertViewIsCurrent" for views: [%0]'.format(viewsStates.join(', ')));

        for (var i = 0, len = views.length; i < len; i += 1) {
            isCurrent = isCurrent || views[i].isCurrent();
        }

        UIAUtilities.assert(isCurrent,
            'Current view is not one of [%0]'.format(viewsStates.join(', '))
        );
    },

    invalidateSignIn: function invalidateSignIn() {
        survey.sessionSettings.isValidSignIn = false;
    },

    locationAlertHandler: function locationAlertHandler() {
        var alertQuery = UIAQuery.alerts().andThen(UIAQuery.contains("to access your location while you use the app"));

        if (springboard.exists(alertQuery)) {
            var alert = springboard.inspect(alertQuery);
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                UIALogger.logMessage("Trying to allow Indoor Survey to access device location...");
            }
            return springboard.tapIfExists(UIAQuery.query('Allow'));
        } else {
            return false;
        }
    },

    untrustedDeveloperAlertHandler: function untrustedDeveloperAlertHandler() {
        var alertQuery = UIAQuery.alerts("Untrusted Enterprise Developer");

        if (springboard.exists(alertQuery)) {
            var alert = springboard.inspect(alertQuery);
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                UIALogger.logMessage("Trying to enable Maps Server and Web profile...");
            }
            springboard.tapIfExists(alertQuery.andThen(UIAQuery.buttons("Cancel")));
            return settings.enableDeveloperProfile('Apple Inc. - Maps Server and Web');
        } else {
            return false;
        }
    },

    motionFitnessActivityAlertHandler: function motionFitnessActivityAlertHandler() {
        var alertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('“Indoor Survey” Would Like to Access Your Motion & Fitness Activity'));

        if (springboard.exists(alertQuery)) {
            var alert = springboard.inspect(alertQuery);
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                UIALogger.logMessage("Trying to allow Indoor Survey to access Motion and Fitness Activity...");
            }
            return springboard.tapIfExists(UIAQuery.query('OK'));
        } else {
            return false;
        }
    },

    /**
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     */
    waitForUploadToStart: function waitForUploadToStart(uploadOptions) {
        var time = new UIAUtilities.ElapsedTimeWaiter();

        uploadOptions = UIAUtilities.defaults(uploadOptions, {
            secToWaitStart: 10,
        });

        time.reset();

        UIALogger.logMessage("Waiting up to %0 seconds for upload to start...".format(uploadOptions.secToWaitStart));
        if (!survey.waitUntilPresent(UIAQuery.query("BGUploadProgressView"), uploadOptions.secToWaitStart)) {
            throw new UIAError("Survey upload does not start within %0 seconds!".format(uploadOptions.secToWaitStart));
        } else {
            UIALogger.logMessage("Survey upload started after %0".format(time.elapsedSeconds()));
        }
    },

    /**
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    waitForUploadToFinish: function waitForUploadToFinish(uploadOptions) {
        var time = new UIAUtilities.ElapsedTimeWaiter();

        uploadOptions = UIAUtilities.defaults(uploadOptions, {
            secToWaitFinish: 60,
        });

        time.reset();

        UIALogger.logMessage("Waiting up to %0 seconds for uploading to FINISH...".format(uploadOptions.secToWaitFinish));
        if (!survey.waitUntilAbsent(UIAQuery.query("BGUploadProgressView"), uploadOptions.secToWaitFinish)) {
            throw new UIAError("Survey upload does not finish within %0 seconds!".format(uploadOptions.secToWaitFinish));
        } else {
            UIALogger.logMessage("Survey upload finished after %0".format(time.elapsedSeconds()));
        }
    },

};


survey.currentUIState = function currentUIState() {
    return survey.currentView().STATE;
};


survey.currentView = function currentView() {
    return survey.Utils.findMemberOfNamespace(survey.Views, function (view) {
        return view.isCurrent();
    }, 'Could not identify the current view');
};


/**
 * @param {Object} args
 * @param {boolean} [args.trustApp=false] - Trust app before launch
 */
survey.launchApp = function launchApp(args) {
    args = UIAUtilities.defaults(args, {
        trustApp: false,
    });

    if (!survey.isRunning()) {
        if (args.trustApp) {
            settings.enableDeveloperProfile('Apple Inc. - Maps Server and Web');
        }
        survey.withAlertHandler(survey.Utils.locationAlertHandler, function() {
            survey.launch();
        });
    }
};


survey.quitApp = function quitApp() {
    try {
        UIALogger.logMessage('Trying to quit app in a normal way...');
        survey.quit();
    } catch (e) {
        UIALogger.logMessage('quit() failed, performing killall');
        target.performTask('/usr/bin/killall', ['Indoor Survey']);
    }
};


survey.getToVenues = function getToVenues() {
    var view;
    var attempts = 0;

    view = survey.currentView();
    view.dismissModals();

    while (attempts++ < 10 && view !== survey.Views.Venues) {
        view = view.dismissModalsAndGoBack();
    }
};

/**
 * @param {string} identifier - Used as a suffix to a screenshot filename
 */
survey.takeScreenshot = function takeScreenshot(identifier) {
    var screenshotName;

    if (survey.SCREENSHOTS.Enabled) {
        performTask('/bin/mkdir', [survey.SCREENSHOTS.Folder]);
        screenshotName = "%0IndoorSurvey_%1_%2.png".format(survey.SCREENSHOTS.Folder, identifier, (new Date()).getTime());
        UIATarget.localTarget().captureScreenWithName(screenshotName);
    }
};


survey.deleteScreenshots = function deleteScreenshots() {
    UIALogger.logMessage("Removing screenshots in folder '" + survey.SCREENSHOTS.Folder + "'");
    performTask("/bin/rm", ["-rf", survey.SCREENSHOTS.Folder]);
};


survey.setPrototypeOnViews();
