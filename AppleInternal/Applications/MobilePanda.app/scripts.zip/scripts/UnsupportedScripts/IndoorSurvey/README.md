App: Indoor Survey
Maintainer(s): Azat Karachurin, Taras Kurdyna
Maintainer(s) Email: akarachurin@apple.com, tkurdyna@apple.com
Maintainer(s) Team: Maps Web Eval
Maintainer(s) Team Manager: Nicolas Lelievre
Maintainer(s) Team Manager Email: nlelievre@apple.com
