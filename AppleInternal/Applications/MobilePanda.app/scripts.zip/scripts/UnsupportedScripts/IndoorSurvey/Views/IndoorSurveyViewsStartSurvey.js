survey.Views.StartSurvey = {

    get STATE() {
        return UIStateDescription.Survey.START_SURVEY;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Floors];
    },

    /** Venue Floor label **/
    VENUE_FLOOR_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts()),

    /** Back button **/
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back')).isVisible(),

    /** "Start Survey" button **/
    START_SURVEY_BUTTON: UIAQuery.buttons('Start Survey'),

    /** "Upload Survey" button in action sheet for edit survey functionality **/
    ACTION_UPLOAD_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Upload Survey')),

    /** "Discard Survey" button in action sheet for edit survey functionality **/
    ACTION_DISCARD_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Discard Survey')),

    /** "Cancel" button in action sheet for edit survey functionality **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** "Get Started" dialog block, for dialog identification purposes **/
    GET_STARTED_BLOCK: UIAQuery.query("BGTutorialView"),

    /** "Get Started" dialog scrollable block **/
    GET_STARTED_SCROLLABLE_BLOCK: UIAQuery.scrollViews('UIScrollView'),

    /** "Surveys" button on navigation bar **/
    SURVEYS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons().beginsWith('Surveys')),

    /** "Get Started" button on "Get Started" dialog **/
    GET_STARTED_BUTTON: UIAQuery.buttons('Get Started'),

    /** "Page Indicator" element on "Get Started" dialog **/
    GET_STARTED_PAGE_INDICATOR: UIAQuery.pageIndicators(),


    isCurrent: function isCurrent() {
        var isCurrentView;
        var isStartSurveyButtonDisplayed;
        var numberOfButtons;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        numberOfButtons = survey.inspectAll(UIAQuery.navigationBars().andThen(UIAQuery.buttons())).length;
        isStartSurveyButtonDisplayed = survey.exists(survey.Views.StartSurvey.START_SURVEY_BUTTON);
        isCurrentView = (numberOfButtons === 3) && isStartSurveyButtonDisplayed;
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    performGoBackSteps: function performGoBackSteps() {
        survey.Views.StartSurvey.tapOnBackButton();
    },

    dismissModals: function dismissModals() {
        var ss = survey.Views.StartSurvey;

        if (survey.exists(ss.ACTION_UPLOAD_SURVEY_BUTTON)) {
            ss.tapOnCancelActionButton();
        }

        if (ss.isGetStartedDialogDisplayed()) {
            ss.getToLastPageOnGetStartedDialog();
            ss.tapOnGetStartedButton();
        }
    },

    tapOnBackButton: function tapOnBackButton() {
        if (!survey.waitUntilPresent(survey.Views.StartSurvey.BACK_BUTTON)) {
            throw new UIAError('Back button did not show up!');
        }

        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.StartSurvey.BACK_BUTTON);
        });

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    getFloorLabel: function getFloorLabel() {
        return survey.inspect(survey.Views.StartSurvey.VENUE_FLOOR_LABEL).name;
    },

    tapOnStartSurveyButton: function tapOnStartSurveyButton() {
        if (!survey.waitUntilPresent(survey.Views.StartSurvey.START_SURVEY_BUTTON)) {
            throw new UIAError('Start Survey button did not show up!');
        }

        survey.tap(survey.Views.StartSurvey.START_SURVEY_BUTTON);

        if (!survey.waitUntilPresent(survey.Views.SurveyMode.END_BUTTON)) {
            throw new UIAError('END button on Survey Mode view did not show up!');
        }

        survey.Utils.assertViewIsCurrent([survey.Views.SurveyMode]);
    },

    tapOnSurveysButton: function tapOnSurveysButton() {
        if (!survey.waitUntilPresent(survey.Views.StartSurvey.SURVEYS_BUTTON)) {
            throw new UIAError('Surveys button did not show up!');
        }

        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.StartSurvey.SURVEYS_BUTTON);
        });

        survey.Utils.assertViewIsCurrent([survey.Views.Surveys]);
    },

    tapOnCancelActionButton: function tapOnCancelActionButton() {
        survey.tap(survey.Views.StartSurvey.ACTION_CANCEL_BUTTON);
    },

    tapOnUploadSurveyActionButton: function tapOnUploadSurveyActionButton() {
        survey.tap(survey.Views.StartSurvey.ACTION_UPLOAD_SURVEY_BUTTON);
    },

    tapOnDiscardSurveyActionButton: function tapOnDiscardSurveyActionButton() {
        survey.tap(survey.Views.StartSurvey.ACTION_DISCARD_SURVEY_BUTTON);
    },

    isGetStartedDialogDisplayed: function isGetStartedDialogDisplayed() {
        return survey.exists(survey.Views.StartSurvey.GET_STARTED_BLOCK);
    },

    isSurveysButtonEnabled: function isSurveysButtonEnabled() {
        if (!survey.waitUntilPresent(survey.Views.StartSurvey.SURVEYS_BUTTON, 3)) {
            throw new UIAError('Surveys button did not show up!');
        }

        return survey.inspect(survey.Views.StartSurvey.SURVEYS_BUTTON).isEnabled;
    },

    getToLastPageOnGetStartedDialog: function getToLastPageOnGetStartedDialog() {
        var ss = survey.Views.StartSurvey;
        var lastPageNumber = ss.getTotalPagesOnGetStartedDialog();

        ss.getToPageOnGetStartedDialog(lastPageNumber);
    },

    tapOnGetStartedButton: function tapOnGetStartedButton() {
        survey.tap(survey.Views.StartSurvey.GET_STARTED_BUTTON);

        if (!survey.waitUntilAbsent(survey.Views.StartSurvey.GET_STARTED_BUTTON)) {
            throw new UIAError('Get Started button did not disapper!');
        }
    },

    getCurrentPageOnGetStartedDialog: function getCurrentPageOnGetStartedDialog() {
        return survey.inspect(survey.Views.StartSurvey.GET_STARTED_PAGE_INDICATOR).pageIndex + 1;
    },

    getTotalPagesOnGetStartedDialog: function getTotalPagesOnGetStartedDialog() {
        return survey.inspect(survey.Views.StartSurvey.GET_STARTED_PAGE_INDICATOR).pageCount;
    },

    /**
     * @param {number} pageNumber - Number of the page on the dialog (numbering starts from 1)
     */
    getToPageOnGetStartedDialog: function getToPageOnGetStartedDialog(pageNumber) {
        var ss = survey.Views.StartSurvey;
        var total = ss.getTotalPagesOnGetStartedDialog();
        var cur = ss.getCurrentPageOnGetStartedDialog();
        var distance = Math.abs(cur - pageNumber);
        var options;

        var optionsSwipeLeft = {
            fromOffset: {x: 0.99, y: 0.5},
            toOffset: {x: 0.01, y: 0.5},
            duration: 0.3,
        };

        var optionsSwipeRight = {
            fromOffset: {x: 0.01, y: 0.5},
            toOffset: {x: 0.99, y: 0.5},
            duration: 0.3,
        };

        UIAUtilities.assert(pageNumber <= total && pageNumber >= 1,
            'Page number is out of bound. Number should be between %0 and %1'.format(1, total)
        );

        if (cur < pageNumber) {
            options = optionsSwipeLeft;
        } else if (cur > pageNumber) {
            options = optionsSwipeRight;
        }

        for (var i = 0; i < distance; i += 1) {
            survey.drag(ss.GET_STARTED_SCROLLABLE_BLOCK, options);
        }

        cur = ss.getCurrentPageOnGetStartedDialog();
        UIAUtilities.assert(cur === pageNumber,
            'Landed on wrong page [Expected page = %0, Actual page = %1]'.format(pageNumber, cur)
        );
    },

};
