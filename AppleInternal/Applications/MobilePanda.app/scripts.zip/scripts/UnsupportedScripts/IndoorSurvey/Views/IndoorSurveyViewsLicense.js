survey.Views.License = {

    get STATE() {
        return UIStateDescription.Survey.LICENSE;
    },

    get PREVIOUS_VIEWS() {
        return [];
    },

    /** "Disagree" button **/
    DISAGREE_BUTTON: UIAQuery.buttons('Disagree'),

    /** "Agree" button **/
    AGREE_BUTTON: UIAQuery.buttons('Agree'),

    /** "Terms and Conditions" alert **/
    ALERT_AGREEMENT: UIAQuery.alerts("Terms and Conditions"),

    /** "Terms and Conditions" alert **/
    AGREE_ALERT_BUTTON: UIAQuery.alerts().andThen(UIAQuery.buttons('Agree')),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.DISAGREE_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        throw new UIAError("'dismissModals' function is not implemented on %0 view".format(this.STATE));
    },

    performGoBackSteps: function performGoBackSteps() {
        throw new UIAError("'performGoBackSteps' function is not implemented on %0 view".format(this.STATE));
    },

    tapOnDisagreeButton: function tapOnDisagreeButton() {
        UIALogger.logMessage("Tapping on Disagree button");

        survey.waitForViewToAppear('controllerClass == "BGLoginViewController"', 5, function() {
            survey.tap(survey.Views.License.DISAGREE_BUTTON);
        });

        survey.Utils.assertViewIsCurrent([survey.Views.SignIn]);
    },

    tapOnAgreeButton: function tapOnAgreeButton() {
        UIALogger.logMessage("Tapping on Agree button");

        survey.waitForViewToAppear('controllerClass == "BGVenuesViewController"', 5, function() {
            survey.handlingAlertsInline(survey.Views.License.ALERT_AGREEMENT, function() {
                survey.tap(survey.Views.License.AGREE_BUTTON);
                survey.tap(survey.Views.License.AGREE_ALERT_BUTTON);
            });
        });

        survey.Utils.assertViewIsCurrent([survey.Views.Venues]);
    },

};
