survey.Views.PositioningMode = {

    get STATE() {
        return UIStateDescription.Survey.POSITIONING_MODE;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Settings];
    },

    /** "Cancel" navigation bar button **/
    NAV_CANCEL_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Cancel")),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(survey.Views.PositioningMode.NAV_CANCEL_BUTTON) && 
            !survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Send")));
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        // NOTHING TO DO
    },

    performGoBackSteps: function performGoBackSteps() {
        survey.Views.PositioningMode.tapOnCancelButton();
    },

    tapOnCancelButton: function tapOnCancelButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.PositioningMode.NAV_CANCEL_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

};
