survey.Views.SurveyMode = {

    get STATE() {
        return UIStateDescription.Survey.SURVEY_MODE;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.StartSurvey];
    },

    /** "Undo" button **/
    UNDO_BUTTON: UIAQuery.toolbars('BGActiveSurveyToolbar').andThen(UIAQuery.buttons('Undo')),

    /** "End" button **/
    END_BUTTON: UIAQuery.toolbars('BGActiveSurveyToolbar').andThen(UIAQuery.buttons('End')),

    /** "Drop point" button **/
    DROP_POINT_BUTTON: UIAQuery.toolbars("BGActiveSurveyToolbar").andThen(UIAQuery.buttons()).atIndex(1),

    /** Map container **/
    MAP: UIAQuery.query("Map"),

    /** "Save Survey" button in action sheet during Survey Mode **/
    ACTION_SAVE_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Save Survey')),

    /** "Discard Survey" button in action sheet during Survey Mode **/
    ACTION_DISCARD_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Discard Survey')),

    /** "Cancel" button in action sheet during Survey Mode **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** Discard survey alert dialog **/
    ALERT_DISCARD_SURVEY: UIAQuery.alerts().andThen('Discard Survey?'),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(survey.Views.SurveyMode.UNDO_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.ACTION_CANCEL_BUTTON)) {
            this.tapOnCancelActionButton();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        survey.Views.SurveyMode.goBackDiscardingSurvey();
    },

    goBackDiscardingSurvey: function goBackDiscardingSurvey() {
        var sm = survey.Views.SurveyMode;

        sm.tapOnEndButton();

        survey.handlingAlertsInline(sm.ALERT_DISCARD_SURVEY, function() {
            sm.tapOnDiscardSurveyActionButton();
            survey.delay(0.6); // have to wait 0.6 sec for alert to appear. Otherwise function is brittle
            survey.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Discard')));
        });

        if (!survey.waitUntilPresent(survey.Views.StartSurvey.START_SURVEY_BUTTON)) {
            throw new UIAError('Start Survey button did not show up!');
        }

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    /**
     * @param {object} args
     * @param {boolean} [args.waitForNextMinute=false] - Wait for the next minute before saving
     * @param {number} [args.secondsThreshold=55] - Second after which implicit wait for the next minute will be performed before saving
     */
    goBackSavingSurvey: function goBackSavingSurvey(args) {
        var dt, h24, h12, m, startSec;
        var secondsToWait = 0;

        args = UIAUtilities.defaults(args, {
            waitForNextMinute: false,
            secondsThreshold: 55,
        });

        this.tapOnEndButton();

        startSec = new Date().getSeconds();
        UIALogger.logMessage("> Saving survey initiated, currrent second: %0".format(startSec));

        if (args.waitForNextMinute || startSec >= args.secondsThreshold) {
            secondsToWait = 60 - startSec + 1;
        }

        if (secondsToWait > 0) {
            UIALogger.logMessage("> > Waiting %0 seconds for the next minute".format(secondsToWait));
            survey.delay(secondsToWait);
        }

        dt = new Date();

        this.tapOnSaveSurveyActionButton();

        h24 = dt.getHours();
        m = dt.getMinutes();

        h12 = ((dt.getHours() + 11) % 12 + 1);
        m = (m < 10) ? ('0' + m) : ('' + m);
        suffix = (h24 >= 12) ? 'PM' : 'AM';

        UIALogger.logMessage("< Survey saved with timestamp: %0".format(h12 + ':' + m + ' ' + suffix));

        if (!survey.waitUntilPresent(survey.Views.StartSurvey.START_SURVEY_BUTTON)) {
            throw new UIAError('Start Survey button did not show up!');
        }

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);

        return h12 + ':' + m + ' ' + suffix;
    },

    tapOnUndoButton: function tapOnUndoButton() {
        survey.tap(survey.Views.SurveyMode.UNDO_BUTTON);
    },

    tapOnEndButton: function tapOnEndButton() {
        survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyMode.END_BUTTON);
        });
    },

    tapOnDropPointButton: function tapOnDropPointButton() {
        survey.tap(survey.Views.SurveyMode.DROP_POINT_BUTTON);
    },

    tapOnSaveSurveyActionButton: function tapOnSaveSurveyActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyMode.ACTION_SAVE_SURVEY_BUTTON);
        });
    },

    tapOnDiscardSurveyActionButton: function tapOnDiscardSurveyActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyMode.ACTION_DISCARD_SURVEY_BUTTON);
        });
    },

    tapOnCancelActionButton: function tapOnCancelActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyMode.ACTION_CANCEL_BUTTON);
        });
    },

    /**
     * @param {object} fromOffset
     * @param {number} fromOffset.x - x offset in relative coordinates
     * @param {number} fromOffset.y - y offset in relative coordinates
     * @param {object} toOffset
     * @param {number} toOffset.x - x offset in relative coordinates
     * @param {number} toOffset.y - y offset in relative coordinates
     */
    panMap: function panMap(fromOffset, toOffset) {
        var panOptions = {
            touchCount: 1,
            duration: 0.2, // Duration of map panning action, in seconds
            fromOffset: fromOffset,
            toOffset: toOffset,
        };

        survey.drag(survey.Views.SurveyMode.MAP, panOptions);
    },

    /** Pan left => finger to the right **/
    panLeft: function panLeft() {
        UIALogger.logMessage("Panning left...");
        survey.Views.SurveyMode.panMap({x:0.4, y:0.5}, {x:0.6, y:0.5});
    },

    /** Pan right => finger to the left **/
    panRight: function panRight() {
        UIALogger.logMessage("Panning right...");
        survey.Views.SurveyMode.panMap({x:0.6, y:0.5}, {x:0.4, y:0.5});
    },

    /** Pan up => finger down **/
    panUp: function panUp() {
        UIALogger.logMessage("Panning up...");
        survey.Views.SurveyMode.panMap({x:0.5, y:0.45}, {x:0.5, y:0.55});
    },

    /** Pan down => finger up **/
    panDown: function panDown() {
        UIALogger.logMessage("Panning down...");
        survey.Views.SurveyMode.panMap({x:0.5, y:0.55}, {x:0.5, y:0.45});
    },

    /** Simulate zoom in by doing double tap action **/
    zoomIn: function zoomIn() {
        survey.tap(survey.Views.SurveyMode.MAP, {tapCount: 2});
    },

};
