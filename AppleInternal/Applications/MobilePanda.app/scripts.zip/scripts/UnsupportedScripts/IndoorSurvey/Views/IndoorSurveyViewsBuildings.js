survey.Views.Buildings = {

    get STATE() {
        return UIStateDescription.Survey.BUILDINGS;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Venues];
    },

    /** Venue Building label **/
    VENUE_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts()),

    /** Back button **/
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back')),

    /**
     * Build query to locate venue building by name
     * @param {string} buildingName - Name of the building
     */
    _buildingItemByNameQuery: function _buildingItemByNameQuery(buildingName) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.staticTexts(buildingName));
    },

    /**
     * Build query to locate venue building by index
     * @param {number} index - Index of the building in the list
     */
    _buildingItemByIndexQuery: function _buildingItemByIndexQuery(index) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.tableCells().atIndex(index));
    },

    isCurrent: function isCurrent() {
        var isBackButtonDisplayed;
        var isVenuesButtonDisplayed;
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isBackButtonDisplayed = survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Back").isVisible()));
        isVenuesButtonDisplayed = survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Indoor Survey").isVisible()));
        isCurrentView = isBackButtonDisplayed && isVenuesButtonDisplayed;
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    performGoBackSteps: function performGoBackSteps() {
        survey.Views.Buildings.tapOnBackButton();
    },

    dismissModals: function dismissModals() {
        // NOTHING TO DO
    },

    tapOnBackButton: function tapOnBackButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Buildings.BACK_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    /**
     * @param {string} buildingName - Name of the building
     */
    tapOnBuildingByName: function tapOnBuildingByName(buildingName) {
        var isElementAbsent, isElementPresent;

        survey.tap(survey.Views.Buildings._buildingItemByNameQuery(buildingName));
        isElementAbsent = survey.waitUntilAbsent(UIAQuery.tableViews('Empty list'), 30);
        isElementPresent = survey.waitUntilPresent(UIAQuery.tableCells('UITableViewCellAccessibilityElement'), 5);

        if (!isElementAbsent || !isElementPresent) {
            throw new UIAError('Buildings list is not fully loaded, cannot proceed!');
        }

        survey.delay(1);
        survey.Utils.assertViewIsCurrent([survey.Views.Floors]);
    },

    /**
     * @param {number} index - Index of the building in the list
     */
    tapOnBuildingByIndex: function tapOnBuildingByIndex(index) {
        var isElementAbsent, isElementPresent;

        survey.tap(survey.Views.Buildings._buildingItemByIndexQuery(index));
        isElementAbsent = survey.waitUntilAbsent(UIAQuery.tableViews('Empty list'), 30);
        isElementPresent = survey.waitUntilPresent(UIAQuery.tableCells('UITableViewCellAccessibilityElement'), 5);

        if (!isElementAbsent || !isElementPresent) {
            throw new UIAError('Buildings list is not fully loaded, cannot proceed!');
        }

        survey.delay(1);
        survey.Utils.assertViewIsCurrent([survey.Views.Floors]);
    },

    getVenueLabel: function getVenueLabel() {
        return survey.inspect(this.VENUE_LABEL).name;
    },

    getListOfBuildingNames: function getListOfBuildingNames() {
        var buildingNames = [];
        var tableCellNodes = survey.inspectAll(UIAQuery.tableViews().andThen(UIAQuery.tableCells()));

        tableCellNodes.forEach(function(node) {
            buildingNames.push(node.children[0].name);
        });

        return buildingNames;
    },

};
