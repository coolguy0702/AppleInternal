survey.Views.Settings = {

    get STATE() {
        return UIStateDescription.Survey.SETTINGS;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Venues];
    },

    /** "Settings" label **/
    SETTINGS_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts('Settings')),

    /** "Done" button **/
    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Done')),

    /** "Apple ID"/"Sign Out" menu item **/
    SIGNOUT_MENU_ITEM: UIAQuery.staticTexts().contains('Apple ID:'),

    /** "Sign Out" button on alert dialog **/
    SIGNOUT_ALERT_BUTTON: UIAQuery.buttons('Sign Out'),

    /** "Sign Out" alert dialog **/
    ALERT_SIGNOUT: UIAQuery.alerts("Sign Out of App?"),

    /** "Reset App" button in action sheet for Reset App functionality **/
    ACTION_RESET_APP_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Reset App')),

    /** "Cancel" button in action sheet for Reset App functionality **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** "Help" menu item **/
    HELP_MENU_ITEM: UIAQuery.staticTexts('Help'),

    /** "Show Survey Instructions" switch **/
    SWITCH_SHOW_SURVEY_INSTRUCTIONS: UIAQuery.switches("Show Survey Instructions Switch"),

    /** "Positioning Mode" menu item **/
    POSITIONING_MODE_MENU_ITEM: UIAQuery.staticTexts('Positioning Mode'),

    /** "Force Upload All Surveys" menu item **/
    FORCE_UPLOAD_MENU_ITEM: UIAQuery.staticTexts('Force Upload All Surveys'),

    /** "Report a Problem" menu item **/
    REPORT_PROBLEM_MENU_ITEM: UIAQuery.staticTexts('Report a Problem'),

    /** "Reset App" menu item **/
    RESET_APP_MENU_ITEM: UIAQuery.staticTexts('Reset App'),

    /** "Internal Settings" menu item **/
    INTERNAL_SETTINGS_MENU_ITEM: UIAQuery.staticTexts('Internal Settings'),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.SETTINGS_LABEL);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.ACTION_RESET_APP_BUTTON)) {
            this.tapOnCancelButtonInActionSheet();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        this.tapOnDoneButton();
    },

    tapOnDoneButton: function tapOnDoneButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Settings.DONE_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnSignOutMenuItem: function tapOnSignOutMenuItem() {
        survey.waitForViewToAppear('controllerClass == "BGLoginViewController"', 5, function() {
            survey.handlingAlertsInline(survey.Views.Settings.ALERT_SIGNOUT, function() {
                survey.tap(survey.Views.Settings.SIGNOUT_MENU_ITEM);
                survey.tap(survey.Views.Settings.SIGNOUT_ALERT_BUTTON);
            });
        });
        survey.Utils.assertViewIsCurrent([survey.Views.SignIn]);
        survey.Utils.invalidateSignIn();
    },

    getAppleId: function getAppleId() {
        // Extracting email substring from the string: "Apple ID: example@email.com"
        return survey.inspect(this.SIGNOUT_MENU_ITEM).label.substring(10).trim();
    },

    isSignOutMenuItemEnabled: function isSignOutMenuItemEnabled() {
        return survey.inspect(this.SIGNOUT_MENU_ITEM.parent()).isEnabled;
    },

    tapOnHelpMenuItem: function tapOnHelpMenuItem() {
        var safariStateChangedWaiter = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            'state == "Foreground" AND bundleID == "com.apple.mobilesafari"'
        );

        survey.tap(survey.Views.Settings.HELP_MENU_ITEM);

        if (!safariStateChangedWaiter.wait(5)) {
            throw new UIAError('Something went wrong. Mobile Safari browser was not launched.');
        } else {
            UIALogger.logMessage('Mobile Safari browser was launched and running on foreground');
        }
    },

    tapOnShowSurveyInstructionsSwitch: function tapOnShowSurveyInstructionsSwitch() {
        survey.tap(this.SWITCH_SHOW_SURVEY_INSTRUCTIONS);
    },

    isShowSurveyInstructionsSwitchStateOn: function isShowSurveyInstructionsSwitchStateOn() {
        return !!Number(survey.inspect(this.SWITCH_SHOW_SURVEY_INSTRUCTIONS).value);
    },

    tapOnPositioningModeMenuItem: function tapOnPositioningModeMenuItem() {
        survey.withAlertHandler(survey.Utils.locationAlertHandler, function() {
            survey.waitForViewToAppear('controllerClass == "BGPositioningViewController"', 15, function() {
                survey.tap(survey.Views.Settings.POSITIONING_MODE_MENU_ITEM);
            });
        });
        survey.Utils.assertViewIsCurrent([survey.Views.PositioningMode]);
    },

    tapOnForceUploadMenuItem: function tapOnForceUploadMenuItem() {
        survey.tap(this.FORCE_UPLOAD_MENU_ITEM);
    },

    tapOnReportProblemMenuItem: function tapOnReportProblemMenuItem() {
        survey.Utils.waitForViewToAppear('controllerClass == "MFMailComposeController"', 15, function() {
            survey.tap(survey.Views.Settings.REPORT_PROBLEM_MENU_ITEM);
        });
        survey.Utils.assertViewIsCurrent([survey.Views.ReportProblem]);
    },

    tapOnInternalSettingsMenuItem: function tapOnInternalSettingsMenuItem() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Settings.INTERNAL_SETTINGS_MENU_ITEM);
        });
        survey.Utils.assertViewIsCurrent([survey.Views.InternalSettings]);
    },

    tapOnResetAppMenuItem: function tapOnResetAppMenuItem() {
        if (survey.inspect(this.RESET_APP_MENU_ITEM.parent()).isEnabled) {
            survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
                survey.tap(survey.Views.Settings.RESET_APP_MENU_ITEM);
            });
        }
    },

    tapOnCancelButtonInActionSheet: function tapOnCancelButtonInActionSheet() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.Settings.ACTION_CANCEL_BUTTON);
        });
    },

    tapOnResetAppButtonInActionSheet: function tapOnResetAppButtonInActionSheet() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.Settings.ACTION_RESET_APP_BUTTON);
        });
    },

};
