survey.Views.SignIn = {

    get STATE() {
        return UIStateDescription.Survey.SIGNIN;
    },

    get PREVIOUS_VIEWS() {
        return [];
    },

    /** "Sign In..." button **/
    SIGNIN_BUTTON: UIAQuery.buttons("Sign In..."),

    /** "Forgot Apple Id or Password" button **/
    FORGOT_BUTTON: UIAQuery.buttons("Forgot Apple ID or Password?"),

    /** "Apple Id" textfield **/
    TEXTFIELD_APPLEID: UIAQuery.staticTexts('Apple ID').siblings().andThen(UIAQuery.textFields('UITextField')),

    /** "Apple Id" textfield **/
    TEXTFIELD_PASSWORD: UIAQuery.staticTexts('Password').siblings().andThen(UIAQuery.secureTextFields('UITextField')),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.SIGNIN_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        throw new UIAError("'dismissModals' function is not implemented on %0 view".format(this.STATE));
    },

    performGoBackSteps: function performGoBackSteps() {
        throw new UIAError("'performGoBackSteps' function is not implemented on %0 view".format(this.STATE));
    },

    tapOnSignInButton: function tapOnSignInButton() {
        survey.tap(this.SIGNIN_BUTTON);
    },

    tapOnForgotButton: function tapOnForgotButton() {
        survey.tap(this.FORGOT_BUTTON);
    },

    /**
     * @param {string} appleId - email used as Apple ID
     */
    typeInAppleIdField: function typeInAppleIdField(appleId) {
        UIALogger.logMessage("Typing '%0' in Apple ID field".format(appleId));
        survey.enterText(this.TEXTFIELD_APPLEID, appleId, {clearTextBeforeTyping: true});
    },

    /**
     * @param {string} password - Password
     */
    typeInPasswordField: function typeInPasswordField(password) {
        UIALogger.logMessage("Typing '%0' in Password field".format(password));
        survey.enterText(this.TEXTFIELD_PASSWORD, password, {clearTextBeforeTyping: true});
    },

    isSignInButtonEnabled: function isSignInButtonEnabled() {
        return survey.inspect(this.SIGNIN_BUTTON).isEnabled;
    },

};
