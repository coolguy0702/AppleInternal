survey.Views.InternalSettings = {

    get STATE() {
        return UIStateDescription.Survey.INTERNAL_SETTINGS;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Settings];
    },

    /** Back button **/
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back')),

    /** "Internal Settings" label **/
    INTERNAL_SETTINGS_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts('Internal Settings')),

    /** "Cancel" button in action sheet **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** "Upload Test Mode" switch **/
    SWITCH_UPLOAD_TEST_MODE: UIAQuery.switches("Survey Test Mode Switch"),

    /** "DS Authentication" switch **/
    SWITCH_DS_AUTHENTICATION: UIAQuery.staticTexts("DS Authentication").siblings().andThen(UIAQuery.switches()),

    /** "Server" button **/
    SERVER_BUTTON: UIAQuery.staticTexts("Server"),

    /** "Proactive Survey Alerts" switch **/
    SWITCH_PROACTIVE_SURVEY_ALERTS: UIAQuery.switches("Proactive Survey Alerts"),

    /** "Custom Portal URL" textfield **/
    TEXTFIELD_CUSTOM_PORTAL_URL: UIAQuery.textFields("Custom Portal URL TextField"),

    /** "Reset to defaults" button **/
    RESET_TO_DEFAULTS_BUTTON: UIAQuery.staticTexts("Reset to defaults"),

    /**
     * Build query to locate action sheet button for specified server
     * @param {string} server - survey.SERVER enumeration
     */
    _serverActionButtonQuery: function _serverActionButtonQuery(server) {
        return UIAQuery.actionSheets().andThen(UIAQuery.buttons(server));
    },


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.INTERNAL_SETTINGS_LABEL);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.ACTION_CANCEL_BUTTON)) {
            this.tapOnCancelButtonInActionSheet();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        this.tapOnBackButton();
    },

    tapOnBackButton: function tapOnBackButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.InternalSettings.BACK_BUTTON);
        });

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnUploadTestModeSwitch: function tapOnUploadTestModeSwitch() {
        survey.tap(this.SWITCH_UPLOAD_TEST_MODE);
    },

    isUploadTestModeSwitchStateOn: function isUploadTestModeSwitchStateOn() {
        return !!Number(survey.inspect(this.SWITCH_UPLOAD_TEST_MODE).value);
    },

    tapOnDSAuthenticationSwitch: function tapOnDSAuthenticationSwitch() {
        survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.InternalSettings.SWITCH_DS_AUTHENTICATION);
        });
        survey.Utils.invalidateSignIn();
    },

    isDSAuthenticationSwitchStateOn: function isDSAuthenticationSwitchStateOn() {
        return !!Number(survey.inspect(this.SWITCH_DS_AUTHENTICATION).value);
    },

    tapOnServerButton: function tapOnServerButton() {
        survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.InternalSettings.SERVER_BUTTON);
        });
    },

    /**
     * @param {string} server - survey.SERVER enumeration
     */
    tapOnServerButtonInActionSheet: function tapOnServerButtonInActionSheet(server) {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.InternalSettings._serverActionButtonQuery(server));
        });
        survey.Utils.invalidateSignIn();
    },

    getCurrentServer: function getCurrentServer() {
        return survey.inspect(this.SERVER_BUTTON.siblings()).label;
    },

    /**
     * @param {string} customUrl - URL of the server to point app to
     */
    typeInCustomPortalUrlField: function typeInCustomPortalUrlField(customUrl) {
        var keyboard = UIAQuery.keyboard();

        survey.enterText(this.TEXTFIELD_CUSTOM_PORTAL_URL, String(customUrl), {clearTextBeforeTyping: true});

        if (survey.exists(keyboard)) {
            survey.tap(keyboard.andThen(UIAQuery.buttons('Done')));
        }
    },

    tapOnCancelButtonInActionSheet: function tapOnCancelButtonInActionSheet() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.InternalSettings.ACTION_CANCEL_BUTTON);
        });
    },

    getCustomPortalUrl: function getCustomPortalUrl() {
        return survey.inspect(this.TEXTFIELD_CUSTOM_PORTAL_URL).value || '';
    },

    tapOnProactiveSurveyAlertsSwitch: function tapOnProactiveSurveyAlertsSwitch() {
        survey.tap(this.SWITCH_PROACTIVE_SURVEY_ALERTS);
    },

    isProactiveSurveyAlertsSwitchStateOn: function isProactiveSurveyAlertsSwitchStateOn() {
        return !!Number(survey.inspect(this.SWITCH_PROACTIVE_SURVEY_ALERTS).value);
    },

    tapOnResetToDefaults: function tapOnResetToDefaults() {
        survey.tap(this.RESET_TO_DEFAULTS_BUTTON);
    },

};
