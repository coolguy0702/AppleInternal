survey.Views.ReportProblem = {

    get STATE() {
        return UIStateDescription.Survey.REPORT_PROBLEM;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Settings];
    },

    /** "SEND" button **/
    SEND_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Send')),

    /** "Cancel" button **/
    CANCEL_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Cancel')),

    /** "Cancel" button in action sheet **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** "Delete Draft" button in action sheet **/
    ACTION_DELETE_DRAFT_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Delete Draft')),

    /** "Save Draft" button in action sheet **/
    ACTION_SAVE_DRAFT_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Save Draft')),

    /** "To" textfield **/
    TEXTFIELD_TO: UIAQuery.textFields('toField'),

    /** "CC" textfield **/
    TEXTFIELD_CC: UIAQuery.textFields('ccField'),

    /** "BCC" textfield **/
    TEXTFIELD_BCC: UIAQuery.textFields('bccField'),

    /** "Subject" textfield **/
    TEXTFIELD_SUBJECT: UIAQuery.textViews('subjectField'),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.SEND_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.ACTION_CANCEL_BUTTON)) {
            this.tapOnCancelButtonInActionSheet();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        this.discardProblemReport();
    },

    discardProblemReport: function discardProblemReport() {
        this.tapOnCancelButton();
        this.tapOnDeleteDraftButtonInActionSheet();
    },

    saveProblemReport: function saveProblemReport() {
        this.tapOnCancelButton();
        this.tapOnSaveDraftButtonInActionSheet();
    },

    /**
     * @param {array} listOfStrings - Array of the emails
     */
    _joinListItems: function _joinListItems(listOfStrings) {
        var concatenatedStrings = '';

        if (!(typeof listOfStrings !== 'undefined' && listOfStrings.length > 0)) {
            listOfStrings = ['bogota.qa@icloud.com'];
        }

        listOfStrings.forEach(function(stringItem) {
            concatenatedStrings += stringItem + '\n';
        });

        return concatenatedStrings;
    },

    tapOnCancelButton: function tapOnCancelButton() {
        survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.ReportProblem.CANCEL_BUTTON);
        });
    },

    /**
     * @param {string} email - Email address
     */
    typeInTOField: function typeInTOField(email) {
        survey.enterText(this.TEXTFIELD_TO, String(email), {clearTextBeforeTyping: true});
    },

    /**
     * @param {string} email - Email address
     */
    typeInCCField: function typeInCCField(email) {
        survey.tapIfExists(UIAQuery.staticTexts("Cc/Bcc:").isVisible());
        survey.enterText(this.TEXTFIELD_CC, String(email), {clearTextBeforeTyping: true});
    },

    /**
     * @param {string} email - Email address
     */
    typeInBCCField: function typeInBCCField(email) {
        survey.tapIfExists(UIAQuery.staticTexts("Cc/Bcc:").isVisible());
        survey.enterText(this.TEXTFIELD_BCC, String(email), {clearTextBeforeTyping: true});
    },

    /**
     * @param {string} subject - Subject of the email
     */
    typeInSubjectField: function typeInSubjectField(subject) {
        var currentSubj = survey.inspect(this.TEXTFIELD_SUBJECT).value;

        if (currentSubj) {
            if (!survey.exists(UIAQuery.menuItems().isVisible())) {
                survey.touchAndHold(this.TEXTFIELD_SUBJECT, 1);
                if (!survey.waitUntilPresent(UIAQuery.menuItems().isVisible())) {
                    throw new UIAError("Menu bar never appeared");
                }
            }
            survey.tapIfExists(UIAQuery.menuItems("Select All"));
            survey.tapIfExists(UIAQuery.menuItems("Cut"));
        }

        survey.enterText(this.TEXTFIELD_SUBJECT, String(subject));
    },

    tapOnCancelButtonInActionSheet: function tapOnCancelButtonInActionSheet() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.ReportProblem.ACTION_CANCEL_BUTTON);
        });
    },

    tapOnSendButton: function tapOnSendButton() {
        var appStateChangedWaiter = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            'state = "Suspended"'
        );

        survey.tap(this.SEND_BUTTON);

        if (!appStateChangedWaiter.wait(5)) {
            throw new UIAError('Something went wrong. Event did not appear.');
        }

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnDeleteDraftButtonInActionSheet: function tapOnDeleteDraftButtonInActionSheet() {
        var appStateChangedWaiter = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            'state = "Suspended"'
        );

        survey.tap(survey.Views.ReportProblem.ACTION_DELETE_DRAFT_BUTTON);

        if (!appStateChangedWaiter.wait(5)) {
            throw new UIAError('Something went wrong. Event did not appear.');
        }

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnSaveDraftButtonInActionSheet: function tapOnSaveDraftButtonInActionSheet() {
        var appStateChangedWaiter = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            'state = "Suspended"'
        );

        survey.tap(this.ACTION_SAVE_DRAFT_BUTTON);

        if (!appStateChangedWaiter.wait(5)) {
            throw new UIAError('Something went wrong. Event did not appear.');
        }

        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

};
