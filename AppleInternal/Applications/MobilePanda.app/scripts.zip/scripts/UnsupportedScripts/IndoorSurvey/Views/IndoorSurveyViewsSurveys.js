survey.Views.Surveys = {

    get STATE() {
        return UIStateDescription.Survey.SURVEYS;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.StartSurvey, survey.Views.Venues];
    },

    /** "Delete" button on bottom bar **/
    DELETE_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Delete')),

    /** "Close" button on upper navigation bar **/
    CLOSE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Close')),

    /** "Edit" button on upper navigation bar **/
    EDIT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Edit')),

    /** "Done" button on upper navigation bar **/
    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Done')),

    /** "Upload All"/"Upload" button on the bottom toolbar **/
    UPLOAD_TOOLBAR_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons().contains('Upload')),

    /** Upload survey inline button **/
    UPLOAD_SURVEY_BUTTON: UIAQuery.buttons('Upload Survey Button'),

    /** Table cell which represent each survey **/
    SURVEY_ITEMS: UIAQuery.tableViews().andThen(UIAQuery.tableCells()),

    /** Survey uploading indicator **/
    UPLOAD_PROGRESS: UIAQuery.query("BGUploadProgressView"),


    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.DELETE_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));

        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.DONE_BUTTON)) {
            this.tapOnDoneButton();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        this.tapOnCloseButton();
    },

    tapOnDeleteButton: function tapOnDeleteButton() {
        survey.tap(this.DELETE_BUTTON);
    },

    tapOnCloseButton: function tapOnCloseButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Surveys.CLOSE_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnEditButton: function tapOnEditButton() {
        survey.tap(this.EDIT_BUTTON);
    },

    tapOnDoneButton: function tapOnDoneButton() {
        survey.tap(this.DONE_BUTTON);
    },

    /**
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    tapOnUploadButtonOnToolbar: function tapOnUploadButtonOnToolbar(uploadOptions) {
        survey.tap(this.UPLOAD_TOOLBAR_BUTTON);

        survey.Utils.waitForUploadToStart(uploadOptions);
        survey.Utils.waitForUploadToFinish(uploadOptions);
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    tapOnUploadSurveyInlineButton: function tapOnUploadSurveyInlineButton(surveyInfo, uploadOptions) {
        var indices;

        surveyInfo = surveyInfo || {};

        surveyInfo.status = survey.SURVEYSTATUS.Pending;

        indices = this.getSurveyIndices(surveyInfo);

        UIAUtilities.assert(indices.length > 0, "Matching surveys cannot be found in Pending Uploads section");

        for (var i = indices.length - 1; i >= 0; i -= 1) {
            survey.tap(this.SURVEY_ITEMS.atIndex(indices[i]).andThen(this.UPLOAD_SURVEY_BUTTON));
        }

        survey.Utils.waitForUploadToStart(uploadOptions);
        survey.Utils.waitForUploadToFinish(uploadOptions);
    },

    /**
     * @param {number} index - Index of survey to upload
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    tapOnUploadSurveyInlineButtonByIndex: function tapOnUploadSurveyInlineButtonByIndex(index, uploadOptions) {
        var indices = this.getSurveyIndices({status: survey.SURVEYSTATUS.Pending});

        UIAUtilities.assert((index < indices.length) && (index >= 0), "Survey for index = %0 was not found in Pending Uploads section".format(index));

        survey.tap(this.SURVEY_ITEMS.atIndex(indices[index]).andThen(this.UPLOAD_SURVEY_BUTTON));

        survey.Utils.waitForUploadToStart(uploadOptions);
        survey.Utils.waitForUploadToFinish(uploadOptions);
    },

    /**
     * @param {string} title
     * @param {array} listOfSurveys - Array of SurveyInfo objects
     */
    _printSurveys: function _printSurveys(title, listOfSurveys) {
        var result = '';

        listOfSurveys.forEach(function(surveyInfo, idx) {
            result += "\n %0 = %1".format(idx + 1, JSON.stringify(surveyInfo, null, 4));
        });

        if (result.length > 0) {
            UIALogger.logMessage("%0 (%1 surveys total) %2".format(title.toUpperCase(), listOfSurveys.length, result));
        } else {
            UIALogger.logMessage("%0 No surveys found!".format(title.toUpperCase()));
        }
    },

    getListOfSurveys: function getListOfSurveys() {
        var i = 0;
        var status;
        var quadruplet = [];
        var surveysList = [];
        var names = [];
        var dtregex = /\s+\d{1,2}:\d{2}\s+(AM|PM)\s*$/; // " H[H]:MM AM|PM  "
        var nodes = survey.inspectAll(UIAQuery.tableViews().andThen(UIAQuery.staticTexts()));

        // Workaround for the bug when StaticText "UPLOAD" appears when view is "bounced" during swiping up or down
        nodes.forEach(function(node) {
            if (! /\s*UPLOAD\s*/.test(node.name)) {
                names.push(node.name.trim());
            }
        });

        while (names[i]) {
            if (names[i] === survey.SURVEYSTATUS.Pending ||
                names[i] === survey.SURVEYSTATUS.Uploaded ||
                names[i] === survey.SURVEYSTATUS.Invalid) {
                status = names[i++];
            } else {
                quadruplet = names.slice(i, i + 4);

                // Workaround for the bug when datetime StaticText is on third position instead of first. (happening in Recently Uploaded section if total num of surveys > 6)
                // Probably that bug was fixed when Size label was added
                // if (dtregex.test(triplet[2])) {
                //     triplet.unshift(triplet.pop());
                // }

                surveysList.push({
                    status: status,
                    datetime: dtregex.exec(quadruplet[0])[0].trim(),
                    venueName: quadruplet[1].trim(),
                    buildingName: quadruplet[2].split(' - ')[0].trim(),
                    floorName: quadruplet[2].split(' - ')[1].trim(),
                    size: quadruplet[3].trim(),
                });
                i += 4;
            }
        }

        this._printSurveys('List Of All Surveys Available: ', surveysList);

        return surveysList;
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    doesSurveyExist: function doesSurveyExist(surveyInfo) {
        return this.getSurveyIndices(surveyInfo).length > 0;
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     * @param {array} listOfSurveys - Array of SurveyInfo objects
     */
    doesSurveyExistInList: function doesSurveyExistInList(surveyInfo, listOfSurveys) {
        var exists = false;

        for (var i = 0, len = listOfSurveys.length; i < len; i += 1) {
            if (survey.Views.Surveys.isMatch(surveyInfo, listOfSurveys[i])) {
                exists = true;
                break;
            }
        }

        return exists;
    },

    /**
     * @param {object} matchCriteria
     * @param {string} [matchCriteria.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [matchCriteria.venueName] - Name of the Venue
     * @param {string} [matchCriteria.buildingName] - Name of the Building
     * @param {string} [matchCriteria.floorName] - Name of the Floor
     * @param {string} [matchCriteria.datetime] - Survey creation datetime
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    isMatch: function isMatch(matchCriteria, surveyInfo) {
        return (typeof matchCriteria === 'undefined') ||
               (((typeof matchCriteria.status       !== 'undefined') ? surveyInfo.status       === matchCriteria.status       : true) &&
                ((typeof matchCriteria.datetime     !== 'undefined') ? surveyInfo.datetime     === matchCriteria.datetime     : true) &&
                ((typeof matchCriteria.venueName    !== 'undefined') ? surveyInfo.venueName    === matchCriteria.venueName    : true) &&
                ((typeof matchCriteria.buildingName !== 'undefined') ? surveyInfo.buildingName === matchCriteria.buildingName : true) &&
                ((typeof matchCriteria.floorName    !== 'undefined') ? surveyInfo.floorName    === matchCriteria.floorName    : true));
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    getSurveyIndices: function getSurveyIndices(surveyInfo) {
        var surveysList = this.getListOfSurveys();
        var indices = [];

        surveysList.forEach(function(surveyItem, index) {
            if (survey.Views.Surveys.isMatch(surveyInfo, surveyItem)) {
                indices.push(index);
            }
        });

        UIALogger.logMessage('indices: %0'.format(indices));

        return indices;
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    getFilteredSurveysList: function getFilteredSurveysList(surveyInfo) {
        var filteredSurveysList;
        var title = '';

        filteredSurveysList = this.getListOfSurveys().filter(function(surveyItem) {
            return survey.Views.Surveys.isMatch(surveyInfo, surveyItem);
        });

        title = 'Filtered List of Surveys: \n' +
                '_______ Search predicate _______\n' +
                JSON.stringify(surveyInfo, null, 4) +
                '\n________________________________\n';

        this._printSurveys(title, filteredSurveysList);

        return filteredSurveysList;
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    tapOnSurvey: function tapOnSurvey(surveyInfo) {
        var indices = this.getSurveyIndices(surveyInfo);

        UIAUtilities.assert(indices.length > 0, 'Survey is not found');

        // If in Edit mode then tap on every survey pointed by indices array
        // If not in Edit mode then tap on survey pointed by the first item in indices array
        if (survey.exists(this.EDIT_BUTTON)) {
            survey.waitForViewToAppear(function() {
                survey.tap(survey.Views.Surveys.SURVEY_ITEMS.atIndex(indices[0]));
            });
        } else {
            indices.forEach(function(index) {
                survey.tap(survey.Views.Surveys.SURVEY_ITEMS.atIndex(index));
            });
        }
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {number} index - Index of the survey
     */
    tapOnSurveyByIndex: function tapOnSurveyByIndex(surveyStatus, index) {
        var indices = this.getSurveyIndices({status: surveyStatus});

        UIAUtilities.assert(indices.length > 0, 'There is no surveys in section = %0'.format(surveyStatus));
        UIAUtilities.assert((index < indices.length) && (index >= 0), 'No survey for the provided index');

        // Tap on survey by index in the "surveyStatus" section
        // We need two branches here because if not in "Edit mode" tap on survey will result in new view opening
        // and we need to wrap tap function in a waiter
        if (survey.exists(this.EDIT_BUTTON)) {
            survey.waitForViewToAppear(function() {
                survey.tap(survey.Views.Surveys.SURVEY_ITEMS.atIndex(indices[index]));
            });
        } else {
            survey.tap(this.SURVEY_ITEMS.atIndex(indices[index]));
        }
    },

    /**
     * @param {number} index - Index of the survey
     */
    _performSurveyDeletionBySwipeAction: function _performSurveyDeletionBySwipeAction(index) {
        var SURVEY = this.SURVEY_ITEMS.atIndex(index);
        var DELETE_SURVEY_INLINE_BUTTON = SURVEY.andThen(UIAQuery.buttons("Delete"));
        var dragOptions = {
            duration: 1,
            fromOffset: {x:0.7, y:0.5},
            toOffset: {x:0.05, y:0.5},
        };

        survey.drag(SURVEY, dragOptions);

        if (!survey.waitUntilPresent(DELETE_SURVEY_INLINE_BUTTON)) {
            throw new UIAError('Delete survey inline button did not show up!');
        }

        survey.tap(DELETE_SURVEY_INLINE_BUTTON);

        if (!survey.waitUntilAbsent(DELETE_SURVEY_INLINE_BUTTON)) {
            throw new UIAError('"Deleted" survey did not disappear!');
        }
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.status] - Status of the survey. Use survey.SURVEYSTATUS enum
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    deleteSurveyBySwipeAction: function deleteSurveyBySwipeAction(surveyInfo) {
        var indices = this.getSurveyIndices(surveyInfo);

        UIAUtilities.assert(indices.length > 0, 'Survey is not found');

        for (var i = indices.length - 1; i >= 0; i -= 1) {
            this._performSurveyDeletionBySwipeAction(indices[i]);
        }
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {number} index - Index of the survey
     */
    deleteSurveyBySwipeActionByIndex: function deleteSurveyBySwipeActionByIndex(surveyStatus, index) {
        var indices = this.getSurveyIndices({status: surveyStatus});

        UIAUtilities.assert(indices.length > 0, 'There is no surveys in section = %0'.format(surveyStatus));
        UIAUtilities.assert((index < indices.length) && (index >= 0), 'No survey for the provided index');

        this._performSurveyDeletionBySwipeAction(indices[index]);
    },

};
