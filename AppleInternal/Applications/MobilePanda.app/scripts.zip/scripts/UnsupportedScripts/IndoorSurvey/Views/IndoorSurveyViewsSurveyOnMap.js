survey.Views.SurveyOnMap = {

    get STATE() {
        return UIStateDescription.Survey.SURVEY_MAP;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Surveys];
    },

    /** "Edit" button on navigation bar **/
    SURVEYS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Surveys')),

    /** "Surveys" button on navigation bar **/
    EDIT_BUTTON: UIAQuery.toolbars('BGSurveyToolbar').andThen(UIAQuery.buttons('Edit')),

    /** "Upload Survey" button in action sheet **/
    ACTION_UPLOAD_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Upload Survey')),

    /** "Discard Survey" button in action sheet **/
    ACTION_DISCARD_SURVEY_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Discard Survey')),

    /** "Cancel" button in action sheet **/
    ACTION_CANCEL_BUTTON: UIAQuery.actionSheets().andThen(UIAQuery.buttons('Cancel')),

    /** Discard survey alert dialog **/
    ALERT_DISCARD_SURVEY: UIAQuery.alerts().andThen('Discard Survey?'),


    isCurrent: function isCurrent() {
        var isCurrentView;
        var numberOfButtons;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        numberOfButtons = survey.inspectAll(UIAQuery.navigationBars().andThen(UIAQuery.buttons())).length;
        isCurrentView = (numberOfButtons === 2) && survey.exists(this.EDIT_BUTTON);
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(this.ACTION_CANCEL_BUTTON)) {
            this.tapOnCancelActionButton();
        }
    },

    performGoBackSteps: function performGoBackSteps() {
        this.tapOnSurveysButton();
    },

    tapOnSurveysButton: function tapOnSurveysButton() {
        survey.waitForViewToAppear(function() {
            survey.tap(UIAQuery.BACK_NAV_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    tapOnEditButton: function tapOnEditButton() {
        survey.waitForViewToAppear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyOnMap.EDIT_BUTTON);
        });
    },

    /**
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    uploadSurvey: function uploadSurvey(uploadOptions) {
        this.tapOnEditButton();
        this.tapOnUploadSurveyActionButton();

        survey.Utils.waitForUploadToStart(uploadOptions);
        survey.Utils.waitForUploadToFinish(uploadOptions);
    },

    discardSurvey: function discardSurvey() {
        var som = survey.Views.SurveyOnMap;

        this.tapOnEditButton();

        survey.handlingAlertsInline(som.ALERT_DISCARD_SURVEY, function() {
            som.tapOnDiscardSurveyActionButton();
            survey.delay(0.6); // no external side effect to wait on
            survey.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Discard')));
        });
    },

    tapOnUploadSurveyActionButton: function tapOnUploadSurveyActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyOnMap.ACTION_UPLOAD_SURVEY_BUTTON);
        });
    },

    tapOnDiscardSurveyActionButton: function tapOnDiscardSurveyActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyOnMap.ACTION_DISCARD_SURVEY_BUTTON);
        });
    },

    tapOnCancelActionButton: function tapOnCancelActionButton() {
        survey.waitForViewToDisappear('controllerClass == "UIAlertController"', 5, function() {
            survey.tap(survey.Views.SurveyOnMap.ACTION_CANCEL_BUTTON);
        });
    },

};
