survey.Views.Floors = {

    get STATE() {
        return UIStateDescription.Survey.FLOORS;
    },

    get PREVIOUS_VIEWS() {
        return [survey.Views.Buildings, survey.Views.Venues];
    },

    /** Venue Building label **/
    VENUE_BUILDING_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts()),

    /** Back button **/
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Venues')).orElse(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back'))),

    /**
     * Build query to locate venue building floor by name
     * @param {string} floorName - Name of the floor
     */
    _floorItemByNameQuery: function _floorItemByNameQuery(floorName) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.staticTexts(floorName));
    },

    /**
     * Build query to locate venue building floor by index
     * @param {number} index - Index of the floor in the list
     */
    _floorItemByIndexQuery: function _floorItemByIndexQuery(index) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.staticTexts().atIndex(index));
    },

    isCurrent: function isCurrent() {
        var isBackButtonDisplayed;
        var isVenuesButtonDisplayed;
        var isStartSurveyButtonDisplayed;
        var isCurrentView;
        var isEditButtonDisplayed;
        var isSettingsButtonDisplayed;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isBackButtonDisplayed = survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Back").isVisible()));
        isVenuesButtonDisplayed = survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Venues").isVisible()));
        isSettingsButtonDisplayed = survey.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons("Settings").isVisible()));
        isStartSurveyButtonDisplayed = survey.exists(UIAQuery.buttons('Start Survey').isVisible());
        isEditButtonDisplayed = survey.exists(UIAQuery.toolbars('BGSurveyToolbar').andThen(UIAQuery.buttons('Edit')));
        isCurrentView = isBackButtonDisplayed &&
            !isVenuesButtonDisplayed &&
            !isStartSurveyButtonDisplayed &&
            !isEditButtonDisplayed &&
            !isSettingsButtonDisplayed;
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));
        return isCurrentView;
    },

    performGoBackSteps: function performGoBackSteps() {
        survey.Views.Floors.tapOnBackButton();
    },

    dismissModals: function dismissModals() {
        // NOTHING TO DO
    },

    getBuildingLabel: function getBuildingLabel() {
        return survey.inspect(survey.Views.Floors.VENUE_BUILDING_LABEL).name;
    },

    /**
     * @param {string} floorName - Name of the floor
     */
    tapOnFloorByName: function tapOnFloorByName(floorName) {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Floors._floorItemByNameQuery(floorName));
        });
        survey.Utils.assertViewIsCurrent([survey.Views.StartSurvey]);
    },

    /**
     * @param {number} index - Index of the floor in the list
     */
    tapOnFloorByIndex: function tapOnFloorByIndex(index) {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Floors._floorItemByIndexQuery(index));
        });
        survey.Utils.assertViewIsCurrent([survey.Views.StartSurvey]);
    },

    tapOnBackButton: function tapOnBackButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Floors.BACK_BUTTON);
        });
        survey.Utils.assertViewIsCurrent(this.PREVIOUS_VIEWS);
    },

    getListOfFloorNames: function getListOfFloorNames() {
        var floorNames = [];
        var tableCellNodes = survey.inspectAll(UIAQuery.tableViews().andThen(UIAQuery.tableCells()));

        tableCellNodes.forEach(function(node) {
            floorNames.push(node.children[0].name);
        });

        return floorNames;
    },

};
