survey.Views.Venues = {

    get STATE() {
        return UIStateDescription.Survey.VENUES;
    },

    get PREVIOUS_VIEWS() {
        return [];
    },

    /** "Venues" label **/
    VENUES_LABEL: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts('Venues')),

    /** "Settings" button **/
    SETTINGS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Settings')),

    /** "Surveys(#)" button **/
    SURVEYS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons().beginsWith('Surveys')),

    /** "All Venues" label **/
    ALL_VENUES_LABEL: UIAQuery.query("UITableViewSectionElement").andThen(UIAQuery.staticTexts("All Venues")),

    /** Search bar **/
    SEARCH_BAR: UIAQuery.searchBars("Search"),

    /** "Cancel" button **/
    CANCEL_BUTTON: UIAQuery.buttons('Cancel'),


    /**
     * Build query to locate venue by name
     * @param {string} venueName - Name of the venue
     */
    _venueItemByNameQuery: function _venueItemByNameQuery(venueName) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.staticTexts(venueName));
    },

    /**
     * Build query to locate venue by index
     * @param {number} index - Index of the venue in the list
     */
    _venueItemByIndexQuery: function _venueItemByIndexQuery(index) {
        return UIAQuery.tableViews().first().andThen(UIAQuery.tableCells().atIndex(index));
    },

    performGoBackSteps: function performGoBackSteps() {
        // DO NOTHING
    },

    isCurrent: function isCurrent() {
        var isCurrentView;

        UIALogger.logMessage('---> START "isCurrent" on %0 view'.format(this.STATE));
        isCurrentView = survey.exists(this.ALL_VENUES_LABEL) || (!survey.exists(UIAQuery.activityIndicators()) && survey.exists(this.SEARCH_BAR));
        UIALogger.logMessage('<--- END "isCurrent" on %0 view. Result = %1'.format(this.STATE, isCurrentView));

        return isCurrentView;
    },

    dismissModals: function dismissModals() {
        if (survey.exists(survey.Views.Venues.CANCEL_BUTTON)) {
            survey.Views.Venues.tapOnCancelSearchButton();
        }
    },

    tapOnSettingsButton: function tapOnSettingsButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Venues.SETTINGS_BUTTON);
        });
        survey.Utils.assertViewIsCurrent([survey.Views.Settings]);
    },

    tapOnSurveysButton: function tapOnSurveysButton() {
        survey.Utils.waitForViewToAppear(function() {
            survey.tap(survey.Views.Venues.SURVEYS_BUTTON);
        });
        survey.Utils.assertViewIsCurrent([survey.Views.Surveys]);
    },

    /**
     * @param {string} venueName - Name of the venue
     */
    tapOnVenueByName: function tapOnVenueByName(venueName) {
        var isElementAbsent, isElementPresent;

        survey.withMaximumSnapshotBreadth(1000, function() {
            survey.tap(survey.Views.Venues._venueItemByNameQuery(venueName), {timeout: 0});
        });

        isElementAbsent = survey.waitUntilAbsent(UIAQuery.tableViews('Empty list'), 120);
        isElementPresent = survey.waitUntilPresent(UIAQuery.tableCells('UITableViewCellAccessibilityElement'), 5);

        if (!isElementAbsent || !isElementPresent) {
            throw new UIAError('Venues list is not fully loaded, cannot proceed!');
        }

        survey.delay(1);
        survey.Utils.assertViewIsCurrent([survey.Views.Buildings]);
    },

    /**
     * @param {number} index - Index of the venue in the list
     */
    tapOnVenueByIndex: function tapOnVenueByIndex(index) {
        var isElementAbsent, isElementPresent;

        survey.withMaximumSnapshotBreadth(1000, function() {
            survey.tap(survey.Views.Venues._venueItemByIndexQuery(index + 1), {timeout: 0}); // We need (index+1) to skip tableCell with closest Venue
        });

        isElementAbsent = survey.waitUntilAbsent(UIAQuery.tableViews('Empty list'), 120);
        isElementPresent = survey.waitUntilPresent(UIAQuery.tableCells('UITableViewCellAccessibilityElement'), 5);

        if (!isElementAbsent || !isElementPresent) {
            throw new UIAError('Venues list is not fully loaded, cannot proceed!');
        }

        survey.delay(1);
        survey.Utils.assertViewIsCurrent([survey.Views.Buildings]);
    },

    /**
     * @param {string} venueName - Name of the venue
     */
    enterVenueNameInSearchBar: function enterVenueNameInSearchBar(venueName) {
        survey.search(venueName, {requiresEnterKey: false});
    },

    tapOnCancelSearchButton: function tapOnCancelSearchButton() {
        survey.tap(survey.Views.Venues.CANCEL_BUTTON);
    },

    isSurveysButtonEnabled: function isSurveysButtonEnabled() {
        return survey.inspect(survey.Views.Venues.SURVEYS_BUTTON).isEnabled;
    },

    getListOfVenueNames: function getListOfVenueNames() {
        var venueNames = survey.inspectAll(UIAQuery.tableViews().first().andThen(UIAQuery.staticTexts())).slice(1);
        return venueNames.map(function(snapshotNode) {
            return snapshotNode.name;
        });
    },

    getListOfSearchResults: function getListOfSearchResults() {
        var results = survey.inspectAll(UIAQuery.tableViews().first().andThen(UIAQuery.tableCells().children()));
        return results.map(function(snapshotNode) {
            return snapshotNode.name;
        });
    },

    getClosestVenue: function getClosestVenue() {
        var closestVenue = {};

        if (!survey.waitUntilPresent(UIAQuery.staticTexts("Closest Venue"), 10)) {
            throw new UIAError('Closest Venue did not show up!');
        }

        closestVenue.venueName = survey.inspect(UIAQuery.tableCells().andThen(UIAQuery.staticTexts()).atIndex(0)).name;
        closestVenue.distance = survey.inspect(UIAQuery.tableCells().andThen(UIAQuery.staticTexts()).atIndex(1)).name;

        return closestVenue;
    },

    tapOnClosestVenue: function tapOnClosestVenue() {
        survey.withMaximumSnapshotBreadth(1000, function() {
            survey.tap(survey.Views.Venues._venueItemByIndexQuery(0), {timeout: 0});
        });

        survey.Utils.assertViewIsCurrent([survey.Views.Buildings]);
    },

};
