load('UIATesting.js');
load('IndoorSurvey.js');
load('Safari.js');

if (typeof IndoorSurveyTests !== 'undefined') {
	throw new UIAError("Namespace 'IndoorSurveyTests' has already been defined.");
}

var IndoorSurveyTests = {
    /**
     * Session settings
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Session settings
     * @param {string} args.appleId - Apple ID
     * @param {string} args.password - Password
     * @param {boolean} args.shouldReuseSession - Reuse session flag
     */
    setSessionSettings: function setSessionSettings(args) {
        survey.sessionSettings = UIAUtilities.override(survey.sessionSettings, args);
    },

    /**
     * Launches the app
     *
     * @targetApps Indoor Survey
     */
    appCanBeLaunched: function appCanBeLaunched() {
        var t = survey.Tasks;

        t.Common.launchApp();
        t.Common.verifyAppIsRunning();
    },

    /**
     * User successfully signs in
     *
     * @targetApps Indoor Survey
     */
    userSignsInSuccessfully: function userSignsInSuccessfully() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedOut();
        t.Common.ensureUserSignedIn();
        t.Common.goToSettings();
        t.Settings.verifyAppleId(survey.sessionSettings.appleId);
        t.Settings.verifySignOutButtonEnabled();
    },

    /**
     * User successfully signs out
     *
     * @targetApps Indoor Survey
     */
    userSignsOutSuccessfully: function userSignsOutSuccessfully() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedIn();
        t.Common.goToSettings();
        t.Settings.signOut();
        t.SignIn.verifyViewIsCurrent();
    },

    /**
     * Sign In button enabled when AppleId and Password are provided
     *
     * @targetApps Indoor Survey
     */
    signInButtonEnabledWhenCredentialsProvided: function signInButtonEnabledWhenCredentialsProvided() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedOut();

        t.SignIn.clearSignInForm();
        t.SignIn.enterAppleId("test");
        t.SignIn.enterPassword("test");
        t.SignIn.verifySignInButtonEnabled();

        t.SignIn.clearSignInForm();
    },

    /**
     * Sign In button disabled when AppleId or Password are not provided
     *
     * @targetApps Indoor Survey
     */
    signInButtonDisabledWhenCredentialsNotProvided: function signInButtonDisabledWhenCredentialsNotProvided() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedOut();

        t.SignIn.clearSignInForm();
        t.SignIn.verifySignInButtonDisabled();

        t.SignIn.enterAppleId("test");
        t.SignIn.verifySignInButtonDisabled();

        t.SignIn.clearSignInForm();
        t.SignIn.enterPassword("test");
        t.SignIn.verifySignInButtonDisabled();

        t.SignIn.clearSignInForm();
    },

    /**
     * User unable to sign in with invalid credentials
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.appleId="abracadabra@abracadabra.blah"] - AppleId
     * @param {string} [args.password="prettyLongPassword123"] - Password
     * @param {string} [args.alertTitle="Invalid Credentials"] - Alert Title
     */
    userUnableToSignInWithInvalidCredentials: function userUnableToSignInWithInvalidCredentials(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            appleId: 'abracadabra@abracadabra.blah',
            password: 'prettyLongPassword123',
            alertTitle: 'Invalid Credentials'
        });

        t.SignIn.enterAppleId(args.appleId);
        t.SignIn.enterPassword(args.password);
        t.SignIn.verifyAlertForUnsuccessfulSignIn(args.alertTitle);
        t.SignIn.verifyViewIsCurrent();

        t.SignIn.clearSignInForm();
    },

    /**
     * Opens Venues view
     *
     * @targetApps Indoor Survey
     */
    venuesViewAccessible: function venuesViewAccessible() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.verifyViewIsCurrent();
    },


    /**
     * Opens Buildings view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     */
    buildingsViewAccessible: function buildingsViewAccessible(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.verifyViewIsCurrent();
    },


    /**
     * Opens Floors view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     */
    floorsViewAccessible: function floorsViewAccessible(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.verifyViewIsCurrent();
    },


    /**
     * Opens Start Survey view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     */
    startSurveyViewAccessible: function startSurveyViewAccessible(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();
        t.StartSurvey.verifyViewIsCurrent();
    },

    /**
     * Opens Survey Mode view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     */
    surveyModeViewAccessible: function surveyModeViewAccessible(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();
        t.StartSurvey.startSurvey();
        t.SurveyMode.verifyViewIsCurrent();
    },


    /**
     * Opens Settings view
     *
     * @targetApps Indoor Survey
     */
    settingsViewAccessible: function settingsViewAccessible() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.goToSettings();
        t.Settings.verifyViewIsCurrent();
    },


    /**
     * Opens Help web page
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.helpPageURL="http://help.apple.com/indoorsurvey/#/apda18f239ce"] - Help webpage URL
     */
    helpPageLoadingInBrowser: function helpPageLoadingInBrowser(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            helpPageURL: 'http://help.apple.com/indoorsurvey/#/apda18f239ce',
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToSettings();
        t.Settings.goToHelp();
        t.Settings.verifyHelpPageLoadedInSafariBrowser(args.helpPageURL);
    },


    /**
     * Opens Positioning Mode view
     *
     * @targetApps Indoor Survey
     */
    positioningModeViewAccessible: function positioningModeViewAccessible() {
        var t = survey.Tasks;

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Venues.goToSettings();
        t.Settings.goToPositioningMode();
        t.PositioningMode.verifyViewIsCurrent();
    },


    /**
     * Opens Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=4] - Number of points dropped in survey
     */
    surveysViewAccessible: function surveysViewAccessible(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 4,
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();
        t.Common.resetApp();
        t.Common.createSurvey(args);
        t.Venues.goToSurveys();
        t.Surveys.verifyViewIsCurrent();
    },


    /**
     * Discards survey during surveying
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=4] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveyCanBeDiscardedDuringSurveyProcess: function surveyCanBeDiscardedDuringSurveyProcess(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 4,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();

        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();
        t.StartSurvey.startSurvey();
        t.SurveyMode.zoomIn(args.zoomLevel);
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        t.SurveyMode.goBackDiscardingSurvey();
        t.StartSurvey.verifySurveysButtonIsDisabled();

        t.Common.goToVenues();
        t.Venues.verifySurveysButtonIsDisabled();
    },


    /**
     * Creates 1 survey
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=4] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveyCanBeCreated: function surveyCanBeCreated(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 4,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();

        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();
        t.StartSurvey.startSurvey();
        t.SurveyMode.zoomIn(args.zoomLevel);
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        args.datetime = t.SurveyMode.goBackSavingSurvey();

        t.StartSurvey.verifySurveysButtonIsEnabled();
        t.StartSurvey.goToSurveys();
        t.Surveys.verifySurveyExists(survey.SURVEYSTATUS.Pending, args);
    },


    /**
     * Searches for venues
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {array} [args.validSearchKeywords=["Amsterdam", "Airport", "Centro", "Store", "California"]] - List of existing venue names
     * @param {array} [args.invalidSearchKeywords=["SabracadabraInvalid", "InvalidSearchKeyword"]] - List of NOT existing venue names
     */
    venuesCanBeSearchedOnVenuesView: function venuesCanBeSearchedOnVenuesView(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            validSearchKeywords: [
                'Amsterdam',
                'Airport',
                'Centro',
                'Store',
                'California',
            ],
            invalidSearchKeywords: [
                'abracadabraInvalid',
                'InvalidSearchKeyword',
            ],
        });

        t.Common.ensureUserSignedIn();
        t.Common.goToVenues();

        args.validSearchKeywords.forEach(function(validKeyword) {
            t.Venues.search(validKeyword);
            t.Venues.verifySearchResultsContainsKeyword(validKeyword);
            t.Venues.closeSearchBar();
        });

        args.invalidSearchKeywords.forEach(function(invalidKeyword) {
            t.Venues.search(invalidKeyword);
            t.Venues.verifySearchResultEmpty();
            t.Venues.closeSearchBar();
        });
    },


    /**
     * Creates surveys and deletes them by swipe action on Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfSurveys=5] - Number of surveys to create
     * @param {number} [args.numberOfPoints=4] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
   surveyCanBeDeletedBySwipeAction: function surveyCanBeDeletedBySwipeAction(args) {
        var t = survey.Tasks;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfSurveys: 5,
            numberOfPoints: 4,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        for (var i = 0; i < args.numberOfSurveys; i += 1) {
            t.StartSurvey.startSurvey();
            t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
            t.SurveyMode.goBackSavingSurvey();
        }

        t.StartSurvey.goToSurveys();
        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Pending, args.numberOfSurveys);

        t.Surveys.deleteSurveyBySwipeActionByIndex(survey.SURVEYSTATUS.Pending, 0);
        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Pending, args.numberOfSurveys - 1);

        for (i = 0; i < args.numberOfSurveys - 1; i += 1) {
            t.Surveys.deleteSurveyBySwipeActionByIndex(survey.SURVEYSTATUS.Pending, 0);
        }

        t.StartSurvey.verifySurveysButtonIsDisabled();
    },

    /**
     * Creates surveys and deletes them as a batch on Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfSurveys=3] - Number of surveys to create
     * @param {number} [args.numberOfPoints=4] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
   surveysCanBeDeletedAsBatch: function surveysCanBeDeletedAsBatch(args) {
        var t = survey.Tasks;
        var surveys = [];
        var surveysToDelete, surveysToRemain;
        var dt, i;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfSurveys: 3,
            numberOfPoints: 4,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        for (i = 0; i < args.numberOfSurveys; i += 1) {
            t.StartSurvey.startSurvey();
            t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
            dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});
            surveys.unshift(UIAUtilities.override(args, {datetime: dt}));
        }

        surveysToDelete = surveys.slice(0, 2);
        surveysToRemain = surveys.slice(2);

        t.StartSurvey.goToSurveys();
        t.Surveys.switchToEditMode();

        surveysToDelete.forEach(function(surveyToDelete) {
            t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyToDelete);
        });

        t.Surveys.deleteSelectedSurveys();
        t.Surveys.quitEditMode();

        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Pending, surveysToRemain.length);
        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, surveysToDelete);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, surveysToRemain);
    },

    /**
     * Creates surveys and uploads them individually on Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=60] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveyCanBeUploaded: function surveyCanBeUploaded(args) {
        var t = survey.Tasks;
        var dt;
        var surveyInfo1, surveyInfo2;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 60,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();
        t.Surveys.uploadSurvey(surveyInfo1, {secToWaitFinish: 60});
        t.Surveys.uploadSurvey(surveyInfo2, {secToWaitFinish: 60});

        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Uploaded, [surveyInfo1, surveyInfo2]);
    },


    /**
     * Creates surveys and uploads subset of them as a batch on Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=30] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveysCanBeUploadedAsBatch: function surveysCanBeUploadedAsBatch(args) {
        var t = survey.Tasks;
        var dt;
        var surveyInfo1, surveyInfo2, surveyInfo3;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 30,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo3 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();

        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2, surveyInfo3]);

        t.Surveys.switchToEditMode();
        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo1);
        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo3);
        t.Surveys.uploadSurveys({secToWaitFinish: 60});
        t.Surveys.quitEditMode();

        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo3]);
        t.Surveys.verifySurveyExists(survey.SURVEYSTATUS.Pending, surveyInfo2);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Uploaded, [surveyInfo1, surveyInfo3]);
    },


    /**
     * Creates surveys and uploads them on Surveys view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=30] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveysCanBeUploadedByTappingUploadAllButton: function surveysCanBeUploadedByTappingUploadAllButton(args) {
        var surveyInfo1, surveyInfo2;
        var t = survey.Tasks;
        var dt;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 30,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();

        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);

        t.Surveys.uploadSurveys({secToWaitFinish: 60});

        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Uploaded, [surveyInfo1, surveyInfo2]);
    },


    /**
     * Creates surveys and uploads them one by one on "Survey on Map" view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=10] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveyCanBeUploadedFromSurveyOnMapView: function surveyCanBeUploadedFromSurveyOnMapView(args) {
        var surveyInfo1, surveyInfo2;
        var t = survey.Tasks;
        var dt;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 10,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();

        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);

        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo1);
        t.SurveyOnMap.uploadSurvey({secToWaitFinish: 60});
        t.SurveyOnMap.goBack();

        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo2);
        t.SurveyOnMap.uploadSurvey({secToWaitFinish: 60});
        t.SurveyOnMap.goBack();

        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Uploaded, [surveyInfo1, surveyInfo2]);
    },


    /**
     * Creates surveys and uploads them all using "Force Upload All Surveys" option on Settings view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=10] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveysCanBeUploadedUsingForceUploadOption: function surveysCanBeUploadedUsingForceUploadOption(args) {
        var surveyInfo1, surveyInfo2;
        var t = survey.Tasks;
        var dt;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 10,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();

        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);

        t.Common.goToSettings();

        t.Settings.forceUploadAllSurveys();
        t.Common.goToSurveys();

        t.Surveys.waitForUploadToFinish({secToWaitFinish: 60});
        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);
        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Uploaded, [surveyInfo1, surveyInfo2]);
    },


    /**
     * Creates surveys and discards them one by one on "Survey on Map" view
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {string} [args.venueName="AVF Demonstration Venue"] - Name of the Venue
     * @param {string} [args.buildingName="Building 1"] - Name of the Building
     * @param {string} [args.floorName="1st Floor"] - Name of the Floor
     * @param {number} [args.numberOfPoints=10] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    surveyCanBeDiscardedFromSurveyOnMapView: function surveyCanBeDiscardedFromSurveyOnMapView(args) {
        var surveyInfo1, surveyInfo2;
        var t = survey.Tasks;
        var dt;

        args = UIAUtilities.defaults(args, {
            venueName: 'AVF Demonstration Venue',
            buildingName: 'Building 1',
            floorName: '1st Floor',
            numberOfPoints: 10,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();
        t.Common.goToStartSurveyView(args);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();

        t.SurveyMode.zoomIn(args.zoomLevel);

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey();

        surveyInfo1 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        dt = t.SurveyMode.goBackSavingSurvey({waitForNextMinute: true});

        surveyInfo2 = UIAUtilities.override(args, {datetime: dt});

        t.StartSurvey.goToSurveys();

        t.Surveys.verifySurveysExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);

        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo1);
        t.SurveyOnMap.discardSurvey();
        t.SurveyOnMap.goBack();

        t.Surveys.tapOnSurvey(survey.SURVEYSTATUS.Pending, surveyInfo2);
        t.SurveyOnMap.discardSurvey();
        t.SurveyOnMap.goBack();

        t.Surveys.verifySurveysNotExist(survey.SURVEYSTATUS.Pending, [surveyInfo1, surveyInfo2]);

        t.Common.goToVenues();

        t.Venues.verifySurveysButtonIsDisabled();
    },


    /**
     * Creates one survey on each floor of every building available and upload them
     *
     * @targetApps Indoor Survey
     *
     * @param {object} args - Test arguments
     * @param {array} [args.venueNames=["Gatwick Airport", "Gatwick Airport", "Gatwick Airport", "Gatwick Airport"] - List of venue names
     * @param {number} [args.numberOfPoints=20] - Number of points dropped in survey
     * @param {number} [args.zoomLevel=2] - Number of times to zoom in
     */
    createSurveyOnEachVenuesFloorAndUploadThem: function createSurveyOnEachVenuesFloorAndUploadThem(args) {
        var t = survey.Tasks;
        var buildings, floors;
        var numberOfSurveysCreated = 0;

        args = UIAUtilities.defaults(args, {
            venueNames: ["Gatwick Airport", "Gatwick Airport", "Gatwick Airport", "Gatwick Airport"],
            numberOfPoints: 10,
            zoomLevel: 2,
        });

        t.Common.ensureUserSignedIn();
        t.Common.resetApp();

        args.venueNames.forEach(function(venueName) {
            t.Venues.selectVenueByName(venueName);

            buildings = t.Buildings.getListOfBuildingNames();

            buildings.forEach(function(building) {
                t.Buildings.selectBuildingByName(building);

                floors = t.Floors.getListOfFloorNames();

                floors.forEach(function(floor) {
                    t.Floors.selectFloorByName(floor);
                    t.StartSurvey.closeGetStartedDialogIfDisplayed();
                    t.StartSurvey.startSurvey();
                    t.SurveyMode.zoomIn(args.zoomLevel);
                    t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
                    t.SurveyMode.goBackSavingSurvey();
                    numberOfSurveysCreated += 1;
                    t.StartSurvey.goBack();
                });

                t.Floors.goBack();
            });

            t.Buildings.goBack();
        });

        t.Venues.goToSurveys();
        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Pending, numberOfSurveysCreated);

        t.Surveys.uploadSurveys({secToWaitFinish: 60});

        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Pending, 0);
        t.Surveys.verifyNumberOfSurveysWithStatus(survey.SURVEYSTATUS.Uploaded, numberOfSurveysCreated);

        t.Common.goToVenues();
    },

};
