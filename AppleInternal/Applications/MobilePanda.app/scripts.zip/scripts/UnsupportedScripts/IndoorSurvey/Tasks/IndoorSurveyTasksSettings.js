survey.Tasks.Settings = {

    get VIEW() {
        return survey.Views.Settings;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnDoneButton();
    },

    signOut: function signOut() {
        this.VIEW.tapOnSignOutMenuItem();
    },

    goToHelp: function goToHelp() {
        this.VIEW.tapOnHelpMenuItem();
    },

    /**
     * @param {boolean} newSwitchState - Use survey.SWITCH enum
     */
    setShowSurveyInstructions: function setShowSurveyInstructions(newSwitchState) {
        var isCurrentSwitchStateOn = this.VIEW.isShowSurveyInstructionsSwitchStateOn();

        if (typeof newSwitchState !== typeof survey.SWITCH.On) {
            throw new UIAError('Wrong switch state provided to the function!');
        }

        if ((newSwitchState === survey.SWITCH.On && !isCurrentSwitchStateOn) ||
            (newSwitchState === survey.SWITCH.Off && isCurrentSwitchStateOn) ) {

            this.VIEW.tapOnShowSurveyInstructionsSwitch();
        }
    },

    goToPositioningMode: function goToPositioningMode() {
        this.VIEW.tapOnPositioningModeMenuItem();
    },

    goToReportProblem: function goToReportProblem() {
        this.VIEW.tapOnReportProblemMenuItem();
    },

    goToInternalSettings: function goToInternalSettings() {
        this.VIEW.tapOnInternalSettingsMenuItem();
    },

    resetApp: function resetApp() {
        this.VIEW.tapOnResetAppMenuItem();
        this.VIEW.tapOnResetAppButtonInActionSheet();
    },

    forceUploadAllSurveys: function forceUploadAllSurveys() {
        this.VIEW.tapOnForceUploadMenuItem();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Settings"!'
        );
    },

    verifyHelpPageLoadedInSafariBrowser: function verifyHelpPageLoadedInSafariBrowser(helpPageURL) {
        var foregroundApp = UIATarget.localTarget().activeApp();
        var currentUrl = foregroundApp.inspect('Application').uiaxElement.valueForKey('kAXActiveURLAttribute').trim();

        if (typeof helpPageURL !== 'string') {
            throw new UIAError('Help webpage URL should be provided as a string!');
        }

        helpPageURL = helpPageURL.trim();

        UIAUtilities.assertEqual(helpPageURL, currentUrl,
            'Wrong Help Page URL detected!\n\tCurrent URL: %0\n\tExpected URL: %1'.format(currentUrl, helpPageURL)
        );
    },

    verifyAppleId: function verifyAppleId(appleId) {
        UIAUtilities.assertEqual(this.VIEW.getAppleId(), appleId.trim(),
            'AppleId used for sign in is different from the one displayed on Settings view'
        );
    },

    verifySignOutButtonEnabled: function verifySignOutButtonEnabled() {
        UIAUtilities.assert(this.VIEW.isSignOutMenuItemEnabled(),
            'Sign Out button is disabled!'
        );
    },
};
