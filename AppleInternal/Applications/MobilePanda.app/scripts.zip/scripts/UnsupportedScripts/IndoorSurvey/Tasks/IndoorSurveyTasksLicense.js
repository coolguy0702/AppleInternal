survey.Tasks.License = {

    get VIEW() {
        return survey.Views.License;
    },

    /** TASKS **/

    agree: function agree() {
        this.VIEW.tapOnAgreeButton();
    },

    agreeIfPresent: function agreeIfPresent() {
        if (survey.exists(this.VIEW.AGREE_BUTTON)) {
            this.agree();
        }
    },

    disagree: function disagree() {
        this.VIEW.tapOnDisagreeButton();
    },

    disagreeIfPresent: function disagreeIfPresent() {
        if (survey.exists(this.VIEW.DISAGREE_BUTTON)) {
            this.disagree();
        }
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "License Agreement"!'
        );
    },
};
