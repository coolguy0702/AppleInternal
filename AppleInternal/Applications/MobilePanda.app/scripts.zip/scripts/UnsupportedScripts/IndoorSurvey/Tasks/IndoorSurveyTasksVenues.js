survey.Tasks.Venues = {

    get VIEW() {
        return survey.Views.Venues;
    },

    /** TASKS **/
    goToSettings: function goToSettings() {
        this.VIEW.tapOnSettingsButton();
    },

    goToSurveys: function goToSurveys() {
        this.VIEW.tapOnSurveysButton();
    },

    /**
     * @param {string} venueName - Name of the venue
     */
    selectVenueByName: function selectVenueByName(venueName) {
        this.VIEW.tapOnVenueByName(venueName);
    },

    /**
     * @param {number} index - Index of the venue in the list (0-Based)
     */
    selectVenueByIndex: function selectVenueByIndex(index) {
        this.VIEW.tapOnVenueByIndex(index);
    },

    selectClosestVenue: function selectClosestVenue() {
        this.VIEW.tapOnClosestVenue();
    },

    /**
     * @param {string} venueName - Name of the venue
     */
    search: function search(venueName) {
        this.VIEW.enterVenueNameInSearchBar(venueName);
    },

    closeSearchBar: function closeSearchBar() {
        this.VIEW.tapOnCancelSearchButton();
    },


    /** VERIFICATION **/

    /**
     * @param {string} venueName - Name of the venue
     */
    verifySearchResultsContainsKeyword: function verifySearchResultsContainsKeyword(venueName) {
        var results = this.VIEW.getListOfSearchResults();
        var irrelevantResults = [];

        UIAUtilities.assert(results.length > 0,
            'Search result is empty for venue name "%0"'.format(venueName)
        );

        results.forEach(function(val, idx, arr) {
            if (val.indexOf(venueName) == -1) {
                irrelevantResults.push(val);
            }
        });

        UIAUtilities.assert(irrelevantResults.length === 0,
            'For venue name "%0" there are several irrelevant search results: [%1]'.format(venueName, irrelevantResults.join(', '))
        );
    },

    verifySearchResultEmpty: function verifySearchResultEmpty() {
        var results = this.VIEW.getListOfSearchResults();

        UIAUtilities.assert(results.length === 0,
            'Search result is not empty: [%0]'.format(results.join(', '))
        );
    },

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Venues"!'
        );
    },

    verifySurveysButtonIsDisabled: function verifySurveysButtonIsDisabled() {
        UIAUtilities.assert(!this.VIEW.isSurveysButtonEnabled(),
            '"Surveys" button is enabled!'
        );
    },

    verifySurveysButtonIsEnabled: function verifySurveysButtonIsEnabled() {
        UIAUtilities.assert(this.VIEW.isSurveysButtonEnabled(),
            '"Surveys" button is disabled!'
        );
    },
};
