survey.Tasks.Buildings = {

    get VIEW() {
        return survey.Views.Buildings;
    },

    /** TASKS **/

    /**
     * @param {string} buildingName - Name of the building
     */
    selectBuildingByName: function selectBuildingByName(buildingName) {
        this.VIEW.tapOnBuildingByName(buildingName);
    },

    /**
     * @param {number} index - Index of the building in the list
     */
    selectBuildingByIndex: function selectBuildingByIndex(index) {
        this.VIEW.tapOnBuildingByIndex(index);
    },

    goBack: function goBack() {
        this.VIEW.tapOnBackButton();
    },

    getListOfBuildingNames: function getListOfBuildingNames() {
        return this.VIEW.getListOfBuildingNames();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Buildings"!'
        );
    },
};
