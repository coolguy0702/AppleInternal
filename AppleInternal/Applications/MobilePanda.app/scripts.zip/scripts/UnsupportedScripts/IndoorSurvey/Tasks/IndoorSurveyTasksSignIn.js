survey.Tasks.SignIn = {

    get VIEW() {
        return survey.Views.SignIn;
    },

    /** TASKS **/

    /**
     * @param {string} appleId - Apple ID
     */
    enterAppleId: function enterAppleId(appleId) {
        this.VIEW.typeInAppleIdField(appleId);
    },

    /**
     * @param {string} password - Password
     */
    enterPassword: function enterPassword(password) {
        this.VIEW.typeInPasswordField(password);
    },

    recoverCredentials: function recoverCredentials() {
        this.VIEW.tapOnForgotButton();
    },

    clearSignInForm: function clearSignInForm() {
        this.enterAppleId("");
        this.enterPassword("");
    },

    signIn: function signIn() {
        var t = survey.Tasks;

        t.SignIn.enterAppleId(survey.sessionSettings.appleId);
        t.SignIn.enterPassword(survey.sessionSettings.password);

        survey.waitForViewToDisappear('controllerClass == "BGLoginViewController"', 5, function() {
            survey.Views.SignIn.tapOnSignInButton();
        });

        t.License.agreeIfPresent();

        survey.Utils.assertViewIsCurrent([survey.Views.Venues]);
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "SignIn"!'
        );
    },

    verifySignInButtonEnabled: function verifySignInButtonEnabled() {
        UIAUtilities.assert(this.VIEW.isSignInButtonEnabled(),
            'Sign In button disabled!'
        );
    },

    verifySignInButtonDisabled: function verifySignInButtonDisabled() {
        UIAUtilities.assert(!this.VIEW.isSignInButtonEnabled(),
            'Sign In button enabled!'
        );
    },

    /**
     * @param {string} alertTitle - Title of the alert dialog
     */
    verifyAlertForUnsuccessfulSignIn: function verifyAlertForUnsuccessfulSignIn(alertTitle) {
        var secondsToWaitForAlert = 10;
        var alertQuery = UIAQuery.alerts(alertTitle);
        var alertWaiter = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerClass == "UIAlertController" AND controllerTitle == "%0"'.format(alertTitle)
        );

        survey.handlingAlertsInline(alertQuery, function() {
            // Triggering alert by tapping Sign In button
            survey.Views.SignIn.tapOnSignInButton();

            // Waiting for alert to appear
            if (!alertWaiter.wait(secondsToWaitForAlert)) {
                 throw new UIAError("Alert '%0' did not appear after %1 seconds!".format(alertTitle, secondsToWaitForAlert));
            }

            // If waited alert appears then dismiss it
            survey.tap("OK");
        });
    },

};
