survey.Tasks.Surveys = {

    get VIEW() {
        return survey.Views.Surveys;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnCloseButton();
    },

    switchToEditMode: function switchToEditMode() {
        this.VIEW.tapOnEditButton();
    },

    quitEditMode: function quitEditMode() {
        this.VIEW.tapOnDoneButton();
    },

    /**
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    uploadSurvey: function uploadSurvey(surveyInfo, uploadOptions) {
        this.VIEW.tapOnUploadSurveyInlineButton(surveyInfo, uploadOptions);
    },

    /**
     * @param {number} index - Index of survey to upload
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    uploadSurveyByIndex: function uploadSurveyByIndex(index, uploadOptions) {
        this.VIEW.tapOnUploadSurveyInlineButtonByIndex(index, uploadOptions);
    },

    /**
     * @param {object} uploadOptions
     * @param {number} [uploadOptions.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [uploadOptions.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    uploadSurveys: function uploadSurveys(uploadOptions) {
        this.VIEW.tapOnUploadButtonOnToolbar(uploadOptions);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    deleteSurveyBySwipeAction: function deleteSurveyBySwipeAction(surveyStatus, surveyInfo) {
        surveyInfo.status = surveyStatus;
        this.VIEW.deleteSurveyBySwipeAction(surveyInfo);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {number} index - Index of the survey
     */
    deleteSurveyBySwipeActionByIndex: function deleteSurveyBySwipeActionByIndex(surveyStatus, index) {
        this.VIEW.deleteSurveyBySwipeActionByIndex(surveyStatus, index);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    tapOnSurvey: function tapOnSurvey(surveyStatus, surveyInfo) {
        surveyInfo.status = surveyStatus;
        this.VIEW.tapOnSurvey(surveyInfo);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {number} index - Index of survey
     */
    tapOnSurveyByIndex: function tapOnSurveyByIndex(surveyStatus, index) {
        this.VIEW.tapOnSurveyByIndex(surveyStatus, index);
    },

    deleteSelectedSurveys: function deleteSelectedSurveys() {
        this.VIEW.tapOnDeleteButton();
    },

    /**
     * @param {object} args
     * @param {number} [args.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    waitForUploadToFinish: function waitForUploadToFinish(args) {
        survey.Utils.waitForUploadToFinish(args);
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Surveys"!'
        );
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    verifySurveyExists: function verifySurveyExists(surveyStatus, surveyInfo) {
        this.verifySurveysExist(surveyStatus, [surveyInfo]);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {object} surveyInfo
     * @param {string} [surveyInfo.venueName] - Name of the Venue
     * @param {string} [surveyInfo.buildingName] - Name of the Building
     * @param {string} [surveyInfo.floorName] - Name of the Floor
     * @param {string} [surveyInfo.datetime] - Survey creation datetime
     */
    verifySurveyNotExists: function verifySurveyNotExists(surveyStatus, surveyInfo) {
        this.verifySurveysNotExist(surveyStatus, [surveyInfo]);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {array} listOfSurveys - Array of SurveyInfo objects
     */
    verifySurveysExist: function verifySurveysExist(surveyStatus, listOfSurveys) {
        this.verifySurveysExistence(surveyStatus, listOfSurveys, true);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {array} listOfSurveys - Array of SurveyInfo objects
     */
    verifySurveysNotExist: function verifySurveysNotExist(surveyStatus, listOfSurveys) {
        this.verifySurveysExistence(surveyStatus, listOfSurveys, false);
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {array} listOfSurveys - Array of SurveyInfo objects
     * @param {boolean} shouldExist - Should survey exist in order to pass verification?
     */
    verifySurveysExistence: function verifySurveysExistence(surveyStatus, listOfSurveys, shouldExist) {
        var surveysFound;
        var surveysNotMatched = [];
        var surveysAsString = '';
        var expected = shouldExist ? 'not found' : 'found';

        listOfSurveys.forEach(function (surveyInfo) {
            surveyInfo.status = surveyStatus;
        });

        surveysFound = this.VIEW.getFilteredSurveysList({status: surveyStatus});

        listOfSurveys.forEach(function (surveyInfo) {
            if (shouldExist !== survey.Views.Surveys.doesSurveyExistInList(surveyInfo, surveysFound)) {
                surveysNotMatched.push(surveyInfo);
            }
        });

        if (surveysNotMatched.length > 0) {
            surveysAsString = '\n List of surveys %0:'.format(expected);
            surveysNotMatched.forEach(function(s) {
                surveysAsString += '\n{\n\tstatus: %0 \n\tdatetime: %1 \n\tvenueName: %2 \n\tbuildingName: %3 \n\tfloorName: %4 \n}'.format(s.status, s.datetime, s.venueName, s.buildingName, s.floorName);
            });
        }

        UIAUtilities.assert(surveysNotMatched.length === 0, 'At least one survey %0 in "%1" section! %2'.format(expected, surveyStatus, surveysAsString));
    },

    /**
     * @param {string} surveyStatus - Enum survey.SURVEYSTATUS should be used
     * @param {number} expectedNumber - Expected number of surveys
     */
    verifyNumberOfSurveysWithStatus: function verifyNumberOfSurveysWithStatus(surveyStatus, expectedNumber) {
        var number = this.VIEW.getFilteredSurveysList({status: surveyStatus}).length;
        UIAUtilities.assert(number === expectedNumber, 'Expected %0 surveys in "%2" section, but found %1!'.format(expectedNumber, number, surveyStatus));
    },

};
