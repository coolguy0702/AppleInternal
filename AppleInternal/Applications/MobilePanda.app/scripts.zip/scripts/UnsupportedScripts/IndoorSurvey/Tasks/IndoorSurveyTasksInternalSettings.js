survey.Tasks.InternalSettings = {

    get VIEW() {
        return survey.Views.InternalSettings;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnBackButton();
    },

    /**
     * @param {boolean} newSwitchState - Use survey.SWITCH enum
     */
    setUploadTestMode: function setUploadTestMode(newSwitchState) {
        var isCurrentSwitchStateOn = this.VIEW.isUploadTestModeSwitchStateOn();

        if (typeof newSwitchState !== typeof survey.SWITCH.On) {
            throw new UIAError('Wrong switch state provided to the function!');
        }

        if ((newSwitchState === survey.SWITCH.On && !isCurrentSwitchStateOn) ||
            (newSwitchState === survey.SWITCH.Off && isCurrentSwitchStateOn)) {

            this.VIEW.tapOnUploadTestModeSwitch();
        }
    },

    /**
     * @param {boolean} newSwitchState - Use survey.SWITCH enum
     */
    setDSAuthentication: function setDSAuthentication(newSwitchState) {
        var isCurrentSwitchStateOn = this.VIEW.isDSAuthenticationSwitchStateOn();
        var t = survey.Tasks;

        if (typeof newSwitchState !== typeof survey.SWITCH.On) {
            throw new UIAError('Wrong switch state provided to the function!');
        }

        if ((newSwitchState === survey.SWITCH.On && !isCurrentSwitchStateOn) ||
            (newSwitchState === survey.SWITCH.Off && isCurrentSwitchStateOn)) {

            this.VIEW.tapOnDSAuthenticationSwitch();

            t.Common.quitApp();
            t.Common.launchApp();
        }
    },

    /**
     * @param {string} customUrl - URL of the server to point app to
     */
    pointAppToServer: function pointAppToServer(server, customUrl) {
        var t = survey.Tasks;

        if (server !== survey.SERVER.Custom && server === this.VIEW.getCurrentServer()) {
            return;
        }

        if (server === survey.SERVER.Custom && typeof customUrl !== 'string') {
            throw new UIAError('Custom server URL should be provided as a string!');
        }

        this.VIEW.tapOnServerButton();
        this.VIEW.tapOnServerButtonInActionSheet(server);

        if (server === survey.SERVER.Custom) {
            this.VIEW.typeInCustomPortalUrlField(customUrl);
        }

        t.Common.quitApp();
        t.Common.launchApp();
    },

    /**
     * @param {boolean} newSwitchState - Use survey.SWITCH enum
     */
    setProactiveSurveyAlerts: function setProactiveSurveyAlerts(newSwitchState) {
        var isCurrentSwitchStateOn = this.VIEW.isProactiveSurveyAlertsSwitchStateOn();

        if (typeof newSwitchState !== typeof survey.SWITCH.On) {
            throw new UIAError('Wrong switch state provided to the function!');
        }

        if ((newSwitchState === survey.SWITCH.On && !isCurrentSwitchStateOn) ||
            (newSwitchState === survey.SWITCH.Off && isCurrentSwitchStateOn)) {
            this.VIEW.tapOnProactiveSurveyAlertsSwitch();
        }
    },

    resetSettingsToDefaults: function resetSettingsToDefaults() {
        this.VIEW.tapOnResetToDefaults();
    },


    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Internal Settings"!'
        );
    },
};
