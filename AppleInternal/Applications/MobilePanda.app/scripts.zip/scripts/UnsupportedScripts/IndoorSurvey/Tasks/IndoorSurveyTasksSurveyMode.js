survey.Tasks.SurveyMode = {

    get VIEW() {
        return survey.Views.SurveyMode;
    },

    /** TASKS **/
    goBackDiscardingSurvey: function goBackDiscardingSurvey() {
        this.VIEW.goBackDiscardingSurvey();
    },

    /**
     * @param {object} args
     * @param {boolean} [args.waitForNextMinute=false] - Wait for the next minute before saving
     * @param {number} [args.secondsThreshold=55] - Second after which implicit wait for the next minute will be performed before saving
     */
    goBackSavingSurvey: function goBackSavingSurvey(args) {
        return this.VIEW.goBackSavingSurvey(args);
    },

    undoLastDroppedPoint: function undoLastDroppedPoint() {
        this.VIEW.tapOnUndoButton();
    },

    /**
     * Creates Survey polygon containing certain amount of points
     * No walk backward, allowed movements: left, straight, right.
     *
     * @param {number} numberOfPoints - Number of points survey should contain
     */
    createSurveyPolygon: function createSurveyPolygon(numberOfPoints) {
        var actions = [this.panMapUp, this.panMapLeft, this.panMapDown, this.panMapRight];
        var allowedActionIndices = [[0, 1, 3], [0, 1, 2], [1, 2, 3], [0, 3, 2]];
        var actionIdx = UIAUtilities.randomInt(0, 3);

        if (numberOfPoints < 0) {
            throw new UIAError('Cannot drop negative amount of points!');
        }

        for (var i = 0; i < numberOfPoints; i += 1) {
            // Perform map panning action
            actions[actionIdx]();

            // Drop point
            this.dropPoint();

            // Select next allowed action index
            actionIdx = UIAUtilities.randomItem(allowedActionIndices[actionIdx]);
        }
    },

    dropPoint: function dropPoint() {
        this.VIEW.tapOnDropPointButton();
    },

    panMapLeft: function panMapLeft() {
        survey.Views.SurveyMode.panLeft();
    },

    panMapRight: function panMapRight() {
        survey.Views.SurveyMode.panRight();
    },

    panMapUp: function panMapUp() {
        survey.Views.SurveyMode.panUp();
    },

    panMapDown: function panMapDown() {
        survey.Views.SurveyMode.panDown();
    },

    /**
     * @param {number} amount - Number of times to double tap on map to zoom in
     */
    zoomIn: function zoomIn(amount) {
        for (var i = 0; i < amount; i += 1) {
            this.VIEW.zoomIn();
        }
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Surveys"!'
        );
    },
};
