survey.Tasks.Common = {

    goToVenues: function goToVenues() {
        survey.getToVenues();
    },

    goToSettings: function goToSettings() {
        var t = survey.Tasks;

        t.Common.goToVenues();
        t.Venues.goToSettings();
    },

    goToInternalSettings: function goToInternalSettings() {
        var t = survey.Tasks;

        t.Common.goToSettings();
        t.Settings.goToInternalSettings();
    },

    ensureUserSignedIn: function ensureUserSignedIn() {
        var t = survey.Tasks;
        var v = survey.Views;
        var atSignInView;

        survey.launchApp();

        if (v.License.isCurrent()) {
            t.License.disagree();
        }

        atSignInView = v.SignIn.isCurrent();

        if (survey.sessionSettings.isValidSignIn && survey.sessionSettings.shouldReuseSession && !atSignInView) {
            return;
        }

        if (!atSignInView) {
            t.Common.goToSettings();

            if (v.Settings.isSignOutMenuItemEnabled()) {
                t.Settings.signOut();
            } else {
                t.Settings.goToInternalSettings();
                t.InternalSettings.setDSAuthentication(survey.SWITCH.On);
            }
        }

        t.SignIn.signIn();

        survey.Utils.assertViewIsCurrent([v.Venues]);

        survey.sessionSettings.isValidSignIn = true;
    },

    ensureUserSignedOut: function ensureUserSignedOut() {
        var t = survey.Tasks;
        var v = survey.Views;

        survey.launchApp();

        survey.Utils.invalidateSignIn();

        if (v.License.isCurrent()) {
            t.License.disagree();
            return;
        }

        if (v.SignIn.isCurrent()) {
            return;
        }

        t.Common.goToSettings();

        if (v.Settings.isSignOutMenuItemEnabled()) {
            t.Settings.signOut();
        } else {
            t.Settings.goToInternalSettings();
            t.InternalSettings.setDSAuthentication(survey.SWITCH.On);
        }

        survey.Utils.assertViewIsCurrent([v.SignIn]);
    },

    goToSurveys: function goToSurveys() {
        var t = survey.Tasks;

        t.Common.goToVenues();
        t.Venues.goToSurveys();
    },

    /**
     * @param {Object} args
     * @param {boolean} args.trustApp - Trust app before launch
     */
    launchApp: function launchApp(args) {
        survey.launchApp(args);
    },

    quitApp: function quitApp() {
        survey.quitApp();
    },

    /**
     * @param {object} args
     * @param {string} args.venueName - Name of the Venue
     * @param {string} args.buildingName - Name of the Building
     * @param {string} args.floorName - Name of the Floor
     */
    goToStartSurveyView: function goToStartSurveyView(args) {
        var t = survey.Tasks;

        t.Common.goToVenues();
        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
    },

    resetApp: function resetApp() {
        var t = survey.Tasks;

        t.Common.goToVenues();

        t.Venues.goToSettings();
        t.Settings.resetApp();

        t.Common.goToVenues();
    },

    /**
     * @param {object} args
     * @param {string} args.venueName - Name of the Venue
     * @param {string} args.buildingName - Name of the Building
     * @param {string} args.floorName - Name of the Floor
     * @param {number} args.numberOfPoints - Nubmer of points to drop in survey
     */
    createSurvey: function createSurvey(args) {
        var t = survey.Tasks;

        t.Common.goToVenues();

        t.Venues.selectVenueByName(args.venueName);
        t.Buildings.selectBuildingByName(args.buildingName);
        t.Floors.selectFloorByName(args.floorName);
        t.StartSurvey.closeGetStartedDialogIfDisplayed();
        t.StartSurvey.startSurvey();
        t.SurveyMode.createSurveyPolygon(args.numberOfPoints);
        t.SurveyMode.goBackSavingSurvey();

        t.Common.goToVenues();
    },

    /** VERIFICATION **/

    verifyAppIsRunning: function verifyAppIsRunning() {
        UIAUtilities.assert(survey.isRunning(),
            'Application is not running!'
        );
    },
};
