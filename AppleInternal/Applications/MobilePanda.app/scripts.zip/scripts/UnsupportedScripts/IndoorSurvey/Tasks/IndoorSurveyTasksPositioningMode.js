survey.Tasks.PositioningMode = {

    get VIEW() {
        return survey.Views.PositioningMode;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnCancelButton();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Positioning Mode"!'
        );
    },
};
