survey.Tasks.ReportProblem = {

    get VIEW() {
        return survey.Views.ReportProblem;
    },

    /** TASKS **/
    sendProblemReport: function sendProblemReport() {
        this.VIEW.tapOnSendButton();
    },

    goBackSavingDraft: function goBackSavingDraft() {
        this.VIEW.saveProblemReport();
    },

    goBackDeletingDraft: function goBackDeletingDraft() {
        this.VIEW.discardProblemReport();
    },

    /**
     * @param {array} emails - Array of emails
     */
    addRecipients: function addRecipients(emails) {
        this.VIEW.typeInTOField(this.VIEW._joinListItems(emails));
    },

    /**
     * @param {array} emails - Array of emails
     */
    addRecipientsInCCField: function addRecipientsInCCField(emails) {
        this.VIEW.typeInCCField(this.VIEW._joinListItems(emails));
    },

    /**
     * @param {array} emails - Array of emails
     */
    addRecipientsInBCCField: function addRecipientsInBCCField(emails) {
        this.VIEW.typeInBCCField(this.VIEW._joinListItems(emails));
    },

    /**
     * @param {string} subject - Email subject
     */
    addSubject: function addSubject(subject) {
        this.VIEW.typeInSubjectField(subject);
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Report a Problem"!'
        );
    },
};
