survey.Tasks.StartSurvey = {

    get VIEW() {
        return survey.Views.StartSurvey;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnBackButton();
    },

    startSurvey: function startSurvey() {
        this.VIEW.tapOnStartSurveyButton();
    },

    /**
     * @param {number} pageNumber - Number of the page on the dialog, numbering starts from 1
     */
    getToPageOnGetStartedDialog: function getToPageOnGetStartedDialog(pageNumber) {
        this.VIEW.getToPageOnGetStartedDialog(pageNumber);
    },

    goToSurveys: function goToSurveys() {
        this.VIEW.tapOnSurveysButton();
    },

    goToLastPageOnGetStartedDialog: function goToLastPageOnGetStartedDialog() {
        this.VIEW.getToLastPageOnGetStartedDialog();
    },

    tapOnGetStartedButtonOnDialog: function tapOnGetStartedButtonOnDialog() {
        this.VIEW.tapOnGetStartedButton();
    },

    closeGetStartedDialogIfDisplayed: function closeGetStartedDialogIfDisplayed() {
        if (this.VIEW.isGetStartedDialogDisplayed()) {
            this.goToLastPageOnGetStartedDialog();
            this.tapOnGetStartedButtonOnDialog();
        }
    },

    getCurrentDialogPageNumber: function getCurrentDialogPageNumber() {
        return this.VIEW.getCurrentPageOnGetStartedDialog();
    },

    getTotalNumberOfDialogPages: function getTotalNumberOfDialogPages() {
        return this.VIEW.getTotalPagesOnGetStartedDialog();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "StartSurvey"!'
        );
    },

    verifyGetStartedDialogDisplayed: function verifyGetStartedDialogDisplayed() {
        UIAUtilities.assert(this.VIEW.isGetStartedDialogDisplayed(),
            '"Get Started" dialog is not displayed!'
        );
    },

    verifyGetStartedDialogNotDisplayed: function verifyGetStartedDialogNotDisplayed() {
        UIAUtilities.assert(!this.VIEW.isGetStartedDialogDisplayed(),
            '"Get Started" dialog still displayed!'
        );
    },

    verifySurveysButtonIsDisabled: function verifySurveysButtonIsDisabled() {
        UIAUtilities.assert(!this.VIEW.isSurveysButtonEnabled(),
            '"Surveys" button is enabled!'
        );
    },

    verifySurveysButtonIsEnabled: function verifySurveysButtonIsEnabled() {
        UIAUtilities.assert(this.VIEW.isSurveysButtonEnabled(),
            '"Surveys" button is disabled!'
        );
    },

};
