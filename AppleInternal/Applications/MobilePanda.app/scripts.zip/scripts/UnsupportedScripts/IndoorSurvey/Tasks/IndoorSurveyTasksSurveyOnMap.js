survey.Tasks.SurveyOnMap = {

    get VIEW() {
        return survey.Views.SurveyOnMap;
    },

    /** TASKS **/
    goBack: function goBack() {
        this.VIEW.tapOnSurveysButton();
    },

    /**
     * @param {object} args
     * @param {number} [args.secToWaitStart=10] - Number of seconds to wait for upload to start
     * @param {number} [args.secToWaitFinish=60] - Number of seconds to wait for upload to finish
     */
    uploadSurvey: function uploadSurvey(args) {
        this.VIEW.uploadSurvey(args);
    },

    discardSurvey: function discardSurvey() {
        this.VIEW.discardSurvey();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Survey On Map"!'
        );
    },

};
