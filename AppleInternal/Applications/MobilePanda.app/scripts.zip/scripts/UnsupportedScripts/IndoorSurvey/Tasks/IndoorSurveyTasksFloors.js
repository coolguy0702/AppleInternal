survey.Tasks.Floors = {

    get VIEW() {
        return survey.Views.Floors;
    },

    /** TASKS **/

    /**
     * @param {string} floorName - Name of the floor
     */
    selectFloorByName: function selectFloorByName(floorName) {
        this.VIEW.tapOnFloorByName(floorName);
    },

   /**
     * @param {number} index - Index of the floor in the list
     */
    selectFloorByIndex: function selectFloorByIndex(index) {
        this.VIEW.tapOnFloorByIndex(index);
    },

    goBack: function goBack() {
        this.VIEW.tapOnBackButton();
    },

    getListOfFloorNames: function getListOfFloorNames() {
        return this.VIEW.getListOfFloorNames();
    },

    /** VERIFICATION **/

    verifyViewIsCurrent: function verifyViewIsCurrent() {
        UIAUtilities.assert(this.VIEW.isCurrent(),
            'Current view is not "Floors"!'
        );
    },
};
