load('DecUtility.js');
load('AppPrediction.js');


/**
 * Many tests for left-of-home spotlight and pull-down spotlight are nearly identical, so share the core test code between them here.
 *
 * @targetApps
 *
 * @param {SwipeType} swipeType - either left-of-home or pull-down
 */
var SharedAppPredictionTestCode = {
    validateZkwEventConversionFeedback: function validateZkwEventConversionFeedback(swipeType) {
        getToHomeScreen();
        var appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        setSyslogLevelToDebug('duetexpertd');

        var magicalMomentsAppName = 'Music';
        var magicalMomentsBundleId = getBundleId(magicalMomentsAppName);

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var allowedIndices = getAppLabelIndicesExcludingAppNames(predictedAppLabels,[magicalMomentsAppName]);

        evaluatedPredictedAppLabels = springboard.inspectAll(predictedAppLabels);
        var predictedBundleIds = evaluatedPredictedAppLabels.map(getAppName).map(appNameBundleIdMap.getBundleId);

        var chosenAppIndex = allowedIndices[0]; // first non-magical moments app
        var chosenAppName = getAppName(evaluatedPredictedAppLabels[chosenAppIndex]);
        var chosenBundleId = appNameBundleIdMap.getBundleId(chosenAppName); // first position app
        var rejectedBundleIds = evaluatedPredictedAppLabels.retainOnlyIndices(allowedIndices).filter(function(app) { return getAppName(app) !== chosenAppName; }).map(getAppName).map(appNameBundleIdMap.getBundleId);

        var oldFeedbackStats = getFeedbackStats();
        setSyslogReferenceDate(); // start monitoring syslog
        springboard.tap(predictedAppButtons.atIndex(chosenAppIndex));  // launch the app in the first position

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: true, itemSelected: chosenBundleId, minItemsShownCount: 4, queryString: '', spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('Engagement, sending feedback to client', {
            errorMessage: 'duetexpertd did not send conversion feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        target.delay(5); // wait for database to get synced to disk
        verifyFeedbackStatsUpdated(oldFeedbackStats, chosenBundleId, rejectedBundleIds, [magicalMomentsBundleId]);

        aggdFlush();
        var keysWithExpectedIncrement = [ Aggd.ssDecShownKey(swipeType), Aggd.ssDecConvertedKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorConvertedKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));
        cancelSyslogLevel('duetexpertd');
    },

    validateZkwEventAbandonmentFeedback: function validateZkwEventAbandonmentFeedback(swipeType) {
        getToHomeScreen();
        appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        setSyslogLevelToDebug('duetexpertd');

        var magicalMomentsAppName = 'Music';
        var magicalMomentsBundleId = appNameBundleIdMap.getBundleId(magicalMomentsAppName);

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var allowedIndices = getAppLabelIndicesExcludingAppNames(predictedAppLabels,[magicalMomentsAppName]);

        var evaluatedPredictedAppLabels = springboard.inspectAll(predictedAppLabels);

        var predictedBundleIds = evaluatedPredictedAppLabels.map(getAppName).map(appNameBundleIdMap.getBundleId);

        var rejectedBundleIds = evaluatedPredictedAppLabels.retainOnlyIndices(allowedIndices).map(getAppName).map(appNameBundleIdMap.getBundleId);
        var oldFeedbackStats = getFeedbackStats();
        setSyslogReferenceDate(); // start monitoring syslog
        getToHomeScreen(); // exit zkw without choosing any app

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: false, itemSelected: null, minItemsShownCount: 4, queryString: '', spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('Abandonment, sending feedback to clients', {
            errorMessage: 'duetexpertd did not send abandonment feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        target.delay(5); // wait for database to get synced to disk
        verifyFeedbackStatsUpdated(oldFeedbackStats, null, rejectedBundleIds, [magicalMomentsBundleId]);

        aggdFlush();
        var keysWithExpectedIncrement = [Aggd.ssDecShownKey(swipeType), Aggd.ssDecAbandonedKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorAbandonedKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));

        cancelSyslogLevel('duetexpertd');
    },

    validateZkwEventDiversionFeedback: function validateZkwEventDiversionFeedback(swipeType) {
        getToHomeScreen();
        var appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        setSyslogLevelToDebug('duetexpertd');

        var magicalMomentsAppName = 'Music';
        var magicalMomentsBundleId = appNameBundleIdMap.getBundleId(magicalMomentsAppName);

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var allowedIndices = getAppLabelIndicesExcludingAppNames(predictedAppLabels,[magicalMomentsAppName]);

        var evaluatedPredictedAppLabels = springboard.inspectAll(predictedAppLabels);
        var predictedBundleIds = evaluatedPredictedAppLabels.map(getAppName).map(appNameBundleIdMap.getBundleId);

        var rejectedBundleIds = evaluatedPredictedAppLabels.retainOnlyIndices(allowedIndices).map(getAppName).map(appNameBundleIdMap.getBundleId);

        var unpredictedAppNames = findAppsNotInSet(springboard.inspectAll(predictedAppLabels), [magicalMomentsBundleId], appNameBundleIdMap);
        var chosenAppName = unpredictedAppNames[0];
        var chosenBundleId = appNameBundleIdMap.getBundleId(chosenAppName);

        var oldFeedbackStats = getFeedbackStats();
        UIALogger.logMessage('searching unpredicted app ' + chosenAppName);
        springboard.search(chosenAppName); // manually search for the first unpredicted app in the list in spotlight
        setSyslogReferenceDate(); // start monitoring syslog

        springboard.tap(UIAQuery.staticTexts(chosenAppName).isVisible()); // launch the app we searched for

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: false, itemSelected: chosenBundleId, minItemsShownCount: 4, queryString: chosenAppName, spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('Diversion, sending feedback to clients', {  // even though this is a diversion to the app predictor, it as an abandonment to DEC
            errorMessage: 'duetexpertd did not send diversion feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        target.delay(5); // wait for database to get synced to disk
        verifyFeedbackStatsUpdated(oldFeedbackStats, chosenBundleId, rejectedBundleIds, [magicalMomentsBundleId]);

        aggdFlush();
        var keysWithExpectedIncrement = [Aggd.ssDecShownKey(swipeType), Aggd.ssDecDivertedKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorDivertedKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));

        cancelSyslogLevel('duetexpertd');
    },

    validateZkwEventPseudoconversionFeedback: function validateZkwEventPseudoconversionFeedback(swipeType) {
        getToHomeScreen();
        var appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        setSyslogLevelToDebug('duetexpertd');

        var magicalMomentsAppName = 'Music';
        var magicalMomentsBundleId = appNameBundleIdMap.getBundleId(magicalMomentsAppName);

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var allowedIndices = getAppLabelIndicesExcludingAppNames(predictedAppLabels,[magicalMomentsAppName]);

        var evaluatedPredictedAppLabels = springboard.inspectAll(predictedAppLabels);
        var predictedBundleIds = evaluatedPredictedAppLabels.map(getAppName).map(appNameBundleIdMap.getBundleId);

        var chosenAppIndex = allowedIndices[0]; // first non-magical moments app
        var chosenAppName = getAppName(evaluatedPredictedAppLabels[chosenAppIndex]);
        var chosenBundleId =appNameBundleIdMap. getBundleId(chosenAppName); // first position app

        var rejectedBundleIds = evaluatedPredictedAppLabels.retainOnlyIndices(allowedIndices).filter(function(app) { return getAppName(app) !== chosenAppName; }).map(getAppName).map(appNameBundleIdMap.getBundleId);

        var oldFeedbackStats = getFeedbackStats();
        setSyslogReferenceDate();
        springboard.search(chosenAppName);
        springboard.tap(UIAQuery.staticTexts(chosenAppName));

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: false, itemSelected: chosenBundleId, minItemsShownCount: 4, queryString: chosenAppName, spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('Diversion, sending feedback to clients', {  // pseudo-conversion is an app prediction concept.  DuetExpertCenter receives a diversion event from spotlight, and logs this as a conversion in aggd,
            //  then as a pseudo-conversion in AppPredictions
            errorMessage: 'duetexpertd did not send any feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        target.delay(5); // wait for database to get synced to disk
        verifyFeedbackStatsUpdated(oldFeedbackStats, chosenBundleId, rejectedBundleIds, [magicalMomentsBundleId]);

        aggdFlush();
        var keysWithExpectedIncrement = [Aggd.ssDecShownKey(swipeType), Aggd.ssDecPseudoconvertedKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorPseudoconvertedKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));

        cancelSyslogLevel('duetexpertd');
    },


    // WARNING:  this has not been functional for a while, and it has not been tested on recent changes applied to all tests.
    // TODO:  make this functional again, if possible (the headphone jack being in use in the CI lab complicates this.)
    // <rdar://problem/23220154> Re-enable "Conversion Other Expert Feedback" tests
    validateZkwEventConversionOtherExpertFeedback: function validateZkwEventConversionOtherExpertFeedback(swipeType) {
        // command line commands and arguments we will need
        var bundleId = 'com.apple.Music';
        var cdKnowledgeToolShellCmd = '/usr/local/bin/cdknowledgetool';
        var deleteCoreDuetEventsArgs = ['delete', '-stream', '/audio/outputRoute, /app/inFocus'];
        var insertHeadphoneEventArgs = ['record', '-stream', '/audio/outputRoute', '-minsago', '<placeholder>', '-duration', '55', '-integerValue', '1', '-metadata', '_DKAudioMetadataKey-portType:Headphones,_DKAudioMetadataKey-portName:Headphones,_DKAudioMetadataKey-identifier:"Wired\ Headphones"'];
        var insertAppLaunchEventArgs = ['record', '-stream', '/app/inFocus', '-minsago', '<placeholder>', '-duration', '55', '-stringValue', bundleId, '-metadata', '_DKApplicationMetadataKey-launchReason:com.apple.SpringBoard.transitionReason.homescreen'];
        var launchCtlCmd = '/bin/launchctl';
        var stopCoreDuetArgs = ['unload', '/System/Library/LaunchDaemons/com.apple.coreduetd.plist'];
        var startCoreDuetArgs = ['load', '/System/Library/LaunchDaemons/com.apple.coreduetd.plist'];
        var stopCoreRoutineArgs = ['unload', '/System/Library/LaunchDaemons/com.apple.routined.plist'];
        var startCoreRoutineArgs = ['load', '/System/Library/LaunchDaemons/com.apple.routined.plist'];
        var wedgerShellCmd = '/var/root/wedger';  // from git@gitlab.sd.apple.com:cboissiere/magicalmomentsqa-public.git
        var decToolCmd = '/usr/local/bin/dectool';
        var decToolSendFeatureDidChangeArgs = ['sendFeatureDidChange'];

        // clear duet database and model info
        target.performTask('/bin/sh',['-c', '"rm -f /var/mobile/Library/CoreDuet/Knowledge/knowledgeC.db*"']);
        exec(launchCtlCmd, stopCoreDuetArgs);
        target.delay(1);
        exec(launchCtlCmd, startCoreDuetArgs);
        target.delay(6);

        target.performTask('/bin/sh',['-c', '"rm -f /var/mobile/Library/Caches/com.apple.routined/*.archive"']);
        target.performTask('/bin/sh',['-c', '"rm -f /var/mobile/Library/Caches/com.apple.routined/*.db"']);
        exec(launchCtlCmd, stopCoreRoutineArgs);
        target.delay(1);
        exec(launchCtlCmd, startCoreRoutineArgs);
        target.delay(6);

        // clear existing MM training data
        exec(cdKnowledgeToolShellCmd, deleteCoreDuetEventsArgs);

        // insert headphone insertion and app launch events into the coreduet database so we can train on them
        var iterations = 10;
        var iterationSpacing = 3; // 3 min -- must be > 160 sec for magical moments not to combine it into the same event.
        var initialMinAgo = 5; // start at this time and work back every iterationSpacing minutes for iterations times.

        for (var i = initialMinAgo + iterations * iterationSpacing; i < iterations; i++) {
            insertHeadphoneEventArgs[4] = (initialMinAgo - i * iterationSpacing).toString(); // minsago
            insertAppLaunchEventArgs[4] = (initalMinAgo - i * iterationSpacing).toString(); // minsago
            exec(cdKnowledgeToolShellCmd, insertHeadphoneEventArgs);
            exec(cdKnowledgeToolShellCmd, insertAppLaunchEventArgs);
        }

        // bounce coreduetd in order to flush the events
        exec(launchCtlCmd, stopCoreDuetArgs);
        target.delay(1);
        exec(launchCtlCmd, stopCoreRoutineArgs);
        target.delay(6);

        exec(launchCtlCmd, startCoreDuetArgs);
        target.delay(1);
        exec(launchCtlCmd, startCoreRoutineArgs);
        target.delay(6);

        // train so that "Music" is predicted by magical moments on headphone plug-in
        var trainPredictionModelArgs = ['--train_prediction_model'];
        exec(wedgerShellCmd, trainPredictionModelArgs);

        // now that we've got a trained model, we're ready to start the test
        getToHomeScreen();
        var appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        setSyslogLevelToDebug('duetexpertd');

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);
        aggdFlush();

        // simulate headphone plug-in
        var simulateHeadphoneInsertionArgs = ['--realtime_audio_event', 'audio', '"Wired\ Headphones" output'];
        exec(wedgerShellCmd, simulateHeadphoneInsertionArgs);

        // force spotlight to query dec for predictions (should not be necessary after rdar://problem/22079761 hits)
        exec(decToolCmd, decToolSendFeatureDidChangeArgs);
        target.delay(10); // wait for spotlight to complete updating

        // go to zkw and see what predictions we've got

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var buttonForMatchingApp = findButtonForAppPredictionBundleId(bundleId, swipeType);

        // this section is a hacky workaround that should go away after this radar is resolved:
        // go back to home and swipe over again because we'll only get the prediction on the second swipe
        if (buttonForMatchingApp == null) {
            getToHomeScreen();
            launchSpotlight(swipeType);
            var predictedAppLabels = getZkwAppLabels(swipeType);
            var predictedAppButtons = getZkwAppButtons(swipeType);
            var buttonForMatchingApp = findButtonForAppPredictionBundleId(bundleId, swipeType);
        }

        assert(buttonForMatchingApp == null, 'Expected app with bundleId ' + bundleId + ' not found in predictions!')

        setSyslogReferenceDate();
        springboard.tap(buttonForMatchingApp);

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: true, itemSelected: chosenBundleId, minItemsShownCount: 4, queryString: chosenAppName, spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('sending feedback to clients', {  //
            //  then as a pseudo-conversion in AppPredictions
            errorMessage: 'duetexpertd did not send any feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        aggdFlush();
        var keysWithExpectedIncrement = [Aggd.ssDecShownKey(swipeType), Aggd.ssDecConvertedOtherExpertKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorConvertedOtherExpertKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));

        cancelSyslogLevel('duetexpertd');
    },

    validateZkwEventSearchAbandonedFeedback: function validateZkwEventSearchAbandonedFeedback(swipeType) {
        var appNameBundleIdMap = AppNameBundleIdMapping(); // side effect:  opens all the folders on springboard to scape the bundleids and app names

        getToHomeScreen();

        setSyslogLevelToDebug('duetexpertd');

        var magicalMomentsAppName = 'Music';
        var magicalMomentsBundleId = getBundleId(magicalMomentsAppName);

        var aggdKeys = Aggd.getKeyList();
        clearAggdStatsForKeys(aggdKeys);
        aggdFlush();
        assertKeysHaveValue(0, aggdKeys);

        launchSpotlight(swipeType);
        var predictedAppLabels = getZkwAppLabels(swipeType);
        var predictedAppButtons = getZkwAppButtons(swipeType);
        assertAppPredictionDisplaySane(predictedAppLabels, predictedAppButtons);

        var allowedIndices = getAppLabelIndicesExcludingAppNames(predictedAppLabels,[magicalMomentsAppName]);

        var evaluatedPredictedAppLabels = springboard.inspectAll(predictedAppLabels);
        var predictedBundleIds = evaluatedPredictedAppLabels.map(getAppName).map(appNameBundleIdMap.getBundleId);

        var rejectedBundleIds = evaluatedPredictedAppLabels.retainOnlyIndices(allowedIndices).map(getAppName).map(appNameBundleIdMap.getBundleId);

        var oldFeedbackStats = getFeedbackStats();
        setSyslogReferenceDate(); // start monitoring syslog

        searchString = 'Rolling Stones';
        UIALogger.logMessage('searching string ' + searchString);
        springboard.search(searchString);
        getToHomeScreen(); // exit zkw without choosing anything

        var feedbackData = getFeedbackDataFromSyslog();
        assertSyslogFeedbackDataIsValid(feedbackData, {engaged: false, itemSelected: null, minItemsShownCount: 4, queryString: searchString, spotlightType: swipeType } );

        UIALogger.logMessage('Waiting for feedback handling detection in syslog');
        waitForSyslog('Abandonment, sending feedback to clients', {
            errorMessage: 'duetexpertd did not send abandonment feedback to AppPrediction',
            processName: 'duetexpertd',
        });

        target.delay(5); // wait for database to get synced to disk
        verifyFeedbackStatsUpdated(oldFeedbackStats, null, rejectedBundleIds, [magicalMomentsBundleId]);

        aggdFlush();
        var keysWithExpectedIncrement = [Aggd.ssDecShownKey(swipeType), Aggd.ssDecSearchAbandonedKey(swipeType), Aggd.appPredictorPredictedKey(), Aggd.appPredictorAbandonedKey() ];
        assertKeysHaveValue(1, keysWithExpectedIncrement, 0, Aggd.allKeysExcept(keysWithExpectedIncrement));

        cancelSyslogLevel('duetexpertd');
    },
};


/**
 * @namespace AppPredictionTests
 */
var AppPredictionTests = {

    /**
     * Swipe left, click a predicted app and validate the event conversion feedback was received
     * from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validateLeftOfHomeZkwEventConversionFeedback: function validateLeftOfHomeZkwEventConversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventConversionFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, click a predicted app and validate the event conversion feedback was received
     * from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validatePullDownZkwEventConversionFeedback: function validatePullDownZkwEventConversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventConversionFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Swipe left, don't click any predicted app and validate the event abandonment feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validateLeftOfHomeZkwEventAbandonmentFeedback: function validateLeftOfHomeZkwEventAbandonmentFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventAbandonmentFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, don't click any predicted app and validate the event abandonment feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validatePullDownZkwEventAbandonmentFeedback: function validatePullDownZkwEventAbandonmentFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventAbandonmentFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Swipe left, search for a non-predicted app and validate the event diversion feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validateLeftOfHomeZkwEventDiversionFeedback: function validateLeftOfHomeZkwEventDiversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventDiversionFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, search for a non-predicted app and validate the event diversion feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validatePullDownZkwEventDiversionFeedback: function validatePullDownZkwEventDiversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventDiversionFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Swipe left, search for a predicted app and validate the event pseudo-conversion feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validateLeftOfHomeZkwEventPseudoconversionFeedback: function validateLeftOfHomeZkwEventPseudoconversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventPseudoconversionFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, search for a predicted app and validate the event pseudo-conversion feedback was
     * received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    validatePullDownZkwEventPseudoconversionFeedback: function validatePullDownZkwEventPseudoconversionFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventPseudoconversionFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Swipe left, and select a prediction made my Magical Moments, to validate that "other expert"
     * conversion feedback was received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    // Blocked by test automation lab devices having something inserted in the headphone jack
    // TODO:  see if we can code around it:  <rdar://problem/23220154> Re-enable "Conversion Other Expert Feedback" tests
    validateLeftOfHomeZkwEventConversionOtherExpertFeedback: function validateLeftOfHomeZkwEventConversionOtherExpertFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventConversionOtherExpertFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, and select a prediction made my Magical Moments, to validate "other expert"
     * conversion feedback was received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    // Blocked by test automation lab devices having something inserted in the headphone jack
    // TODO: see if we can code around it: <rdar://problem/23220154> Re-enable "Conversion Other Expert Feedback" tests
    validatePullDownZkwEventConversionOtherExpertFeedback: function validatePullDownZkwEventConversionOtherExpertFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventConversionOtherExpertFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Swipe left, type in a search term, and cancel the search.  Then check that "searchAbandoned"
     * feedback was received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    // Success blocked by <rdar://problem/23327791> searchAbandoned aggd key is not getting set
    // Success verified on an xcode-installed duetexpertd with the diff in the above radar
    validateLeftOfHomeZkwEventSearchAbandonedFeedback: function validateLeftOfHomeZkwEventSearchAbandonedFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventSearchAbandonedFeedback(SwipeType.LEFT_OF_HOME);
    },

    /**
     * Pull down, type in a search term, and cancel the search.  Then check that "searchAbandoned"
     * feedback was received from Spotlight.
     *
     * @param {object} args - no arguments
     */
    // Success blocked by <rdar://problem/23327791> searchAbandoned aggd key is not getting set
    // Succes verified on an xcode-installed duetexpertd with the diff in the above radar
    validatePullDownZkwEventSearchAbandonedFeedback: function validatePullDownZkwEventSearchAbandonedFeedback(args) {
        SharedAppPredictionTestCode.validateZkwEventSearchAbandonedFeedback(SwipeType.PULL_DOWN);
    },

    /**
     * Get day zero app predictions and make sure they are correct.
     */
    testDayZeroPredictions: function testDayZeroPredictions() {
        assertEqualJson(getDayZeroPredictions(4), [
            'com.apple.Music',
            'com.apple.news',
            'com.apple.mobilenotes',
            'com.apple.MobileSMS',
        ]);


    },

    /**
     * Compare the total scores and feedback inputs before and after giving
     * feedback. Accepted apps should have had both go up, and vice versa.
     * The feedback in question accepts stocks, and rejects mail.
     */
    testFeedbackRaisesAndLowersScores: function testFeedbackRaisesAndLowersScores() {
        var stocks = 'com.apple.stocks', mail = 'com.apple.mobilemail';

        // First get total scores and feedback input scores with a clean slate:
        cleanSlate();
        var preds = predictVerbose();
        var stocksBeforeFeedback = preds[stocks].inputs['_ATXScoreInputFeedback'];
        var mailBeforeFeedback = preds[mail].inputs['_ATXScoreInputFeedback'];
        var stocksBeforeTotal = preds[stocks].subscores.TotalScore;
        var mailBeforeTotal = preds[mail].subscores.TotalScore;

        // Then compare with what happens if you accept the stocks prediction, and reject mail:
        cleanSlate();
        Feedback.addFeedback(stocks, [mail]);
        preds = predictVerbose();
        var stocksAfterFeedback = preds[stocks].inputs['_ATXScoreInputFeedback'];
        var mailAfterFeedback = preds[mail].inputs['_ATXScoreInputFeedback'];
        var stocksAfterTotal = preds[stocks].subscores.TotalScore;
        var mailAfterTotal = preds[mail].subscores.TotalScore;

        assert(stocksBeforeFeedback < stocksAfterFeedback,
                            'stocksBeforeFeedback(%0) < stocksAfterFeedback(%1)'.format(stocksBeforeFeedback, stocksAfterFeedback));
        assert(mailBeforeFeedback > mailAfterFeedback,
                            'mailBeforeFeedback(%0) > mailAfterFeedback(%1)'.format(mailBeforeFeedback, mailAfterFeedback));

        assert(stocksBeforeTotal < stocksAfterTotal,
                            'stocksBeforeTotal(%0) < stocksAfterTotal(%1)'.format(stocksBeforeTotal, stocksAfterTotal));
        assert(mailBeforeTotal > mailAfterTotal,
                            'mailBeforeTotal(%0) > mailAfterTotal(%1)'.format(mailBeforeTotal, mailAfterTotal));
    },

    /**
     * A newly installed app should get promoted to the top 4 predictions, but a day or
     * two later, its score should have fallen a lot, and it should have a negligible
     * number of points for install recency.
     */
    testNewlyInstallAppPromotedToTopFour: function testNewlyInstallAppPromotedToTopFour() {
        var app = 'com.apple.stocks', now = Date.now();
        cleanSlate();
        AppInstallHistory.set(app, now); // Installed just now
        var scoreNow = predictVerbose()[app].subscores.TotalScore;

        var top4 = predictTopN(4);
        assert(top4.indexOf(app) > -1, app + ' should be in top 4: ' + JSON.stringify(top4));

        AppInstallHistory.set(app, now - days(1)); // Installed a day ago
        var scoreOneDayAgo = predictVerbose()[app].subscores.TotalScore;

        AppInstallHistory.set(app, now - days(7)); // Installed a day ago
        var scoreOneWeekAgo = predictVerbose()[app].subscores.TotalScore;

        // The total scores should fall as the installation date fades into the past.
        assert(scoreNow > scoreOneDayAgo,
                            'scoreNow(%0) > scoreOneDayAgo(%1)'.format(scoreNow, scoreOneDayAgo));
        assert(scoreOneDayAgo > scoreOneWeekAgo,
                            'scoreOneDayAgo(%0) > scoreOneWeekAgo(%1)'.format(scoreOneDayAgo, scoreOneWeekAgo));

        // After a week, the install age subscore should be negligible.
        var installAgeSubscore = predictVerbose()[app].subscores.SubScoreInstall;
        assert(installAgeSubscore < 0.0001, 'installAgeSubscore(%0) < 0.0001'.format(installAgeSubscore));
    },

    /**
     * Launching apps, and therefore increasing their recency, should raise both their
     * total score and the corresponding subscores.
     */
    testScoresRiseWithRecency: function testScoresRiseWithRecency() {
        var now = Date.now();
        var bundleId = 'com.apple.stocks';

        var scores;
        function resetScores() {
            scores = {total: [], launch: [], spotlight: []};
        }

        function springboardLaunch(daysAgo) {
            AppHistory.addLaunch(bundleId, false, now - days(daysAgo));
        }

        function spotlightLaunch(daysAgo) {
            AppHistory.addLaunch(bundleId, true, now - days(daysAgo));
        }

        function updateScores() {
            var result = predictVerbose()['com.apple.stocks'];
            scores.total.push(result.subscores.TotalScore);
            scores.launch.push(result.subscores.SubScoreLaunch);
            scores.spotlight.push(result.subscores.SubScoreSpotlight);
        }

        function assertAllRising(array) {
            var isRising = true;
            for (var i = 0; i < array.length - 1; i++) {
                if (array[i] > array[i+1]) {
                    isRising = false;
                    break;
                }
            }
            assert(isRising, 'Not all rising: ' + JSON.stringify(array));
        }

        function assertAllEqual(array) {
            var isEqual = array.length == 0 || array.every(function(x) {
                return x == array[0];
            });
            assert(isEqual, 'Not all equal: ' + JSON.stringify(array));
        }

        // Launching an app more recently from SpringBoard should increase the score,
        // and the SpringBoard launch recency component, but not the Spotlight one.
        AppHistory.clear(); resetScores();
        springboardLaunch(7); updateScores();
        springboardLaunch(4); updateScores();
        springboardLaunch(1); updateScores();
        assertAllRising(scores.total, 'SB launches: total scores should rise');
        assertAllRising(scores.launch, 'SB launches: launch scores should rise');
        assertAllEqual(scores.spotlight, 'SB launches: spotlight launch scores should stay same');

        // Launching from Spotlight should do the same, but by changing the Spotlight
        // component. These also count as regular launches.
        AppHistory.clear(); resetScores();
        spotlightLaunch(7); updateScores();
        spotlightLaunch(4); updateScores();
        spotlightLaunch(1); updateScores();
        assertAllRising(scores.total, 'SP launches: total scores should rise');
        assertAllRising(scores.launch, 'SP launches: launch scores should rise');
        assertAllRising(scores.spotlight, 'SP launches: spotlight launch scores should rise');

        // Finally, launching an app more recently from both of them should raise the total
        // score each time.
        AppHistory.clear(); resetScores();
        spotlightLaunch(7); updateScores();
        springboardLaunch(6); updateScores();
        spotlightLaunch(5); updateScores();
        springboardLaunch(4); updateScores();
        assertAllRising(scores.total, 'Mixed launches: total scores should rise');
    },

    /**
     * An app that has been launched is better than an app that has not -- even if that
     * app is a low-scoring thing that was only launched once, a year ago. Launches count.
     */
    launchedAppsBetterThanUnlaunchedApps: function launchedAppsBetterThanUnlaunchedApps() {
        var app = 'com.apple.calculator';
        cleanSlate();
        AppHistory.addLaunch(app, 0, Date.now() - days(400));
        var top4 = predictTopN(4);
        assertEqual(top4[0], app, 'Calculator should be on top: ' + JSON.stringify(top4));
    },

    /**
     * Launching an app a bunch of times should promote its rank / significantly increase
     * its score, and the score delta should increase monotonically with the number of
     * launches. The score delta associated with launching an app N times from Spotlight
     * should be greater than the delta associated with launching it N times from SpringBoard.
     */
    moreLaunchesBetter: function moreLaunchesBetter() {
        // This sends JS rather than using the built-in binding functions because it cuts
        // // out a whole lot of shell-out round trips and speeds up the test quite a bit.
        var now = Date.now();
        function launchesAtDaysAgo(fromSpotlight, daysAgoList) {
            args = [];
            for (var i = 0; i < daysAgoList.length; i++) {
                args.push(['com.apple.stocks', fromSpotlight, now - days(daysAgoList[i])]);
            }
            script = 'cleanSlate();' +
                'args.forEach(function(x) { AppHistory.addLaunch.apply(this, x); });' +
                'log(predictVerbose()["com.apple.stocks"].subscores.TotalScore);';
            return runDecToolJs(script, args);
        }

        var launched2SB = launchesAtDaysAgo(false, [6, 2]);
        var launched3SB = launchesAtDaysAgo(false, [6, 4, 2]);
        var launched6SB = launchesAtDaysAgo(false, [7, 6, 5, 4, 3, 2]);
        var launched2SP = launchesAtDaysAgo(true, [6, 2]);
        var launched3SP = launchesAtDaysAgo(true, [6, 4, 2]);
        var launched6SP = launchesAtDaysAgo(true, [7, 6, 5, 4, 3, 2]);

        // More launches are better, within the from-Spotlight and from-SpringBoard categories:
        assert(launched2SB < launched3SB, 'launched2SB(%0) < launched3SB(%1)'.format(launched2SB, launched3SB));
        assert(launched3SB < launched6SB, 'launched3SB(%0) < launched6SB(%1)'.format(launched3SB, launched6SB));
        assert(launched2SP < launched3SP, 'launched2SP(%0) < launched3SP(%1)'.format(launched2SP, launched3SP));
        assert(launched3SP < launched6SP, 'launched3SP(%0) < launched6SP(%1)'.format(launched3SP, launched6SP));
        // But of course launches from Spotlight are better than launches from Springboard:
        assert(launched2SB < launched2SP, 'launched2SB(%0) < launched2SP(%1)'.format(launched2SB, launched2SP));
        assert(launched3SB < launched3SP, 'launched3SB(%0) < launched3SP(%1)'.format(launched3SB, launched3SP));
        assert(launched6SB < launched6SP, 'launched6SB(%0) < launched6SP(%1)'.format(launched6SB, launched6SP));
    },
};
