load('UIATesting.js');
load('SpringBoard.js');
load('Suggestions.js');
load('UIAUtility.js');
load('AppNameBundleIdMapping.js')

UIAUtilities.assert(
    typeof AppPredictionTests === 'undefined',
    'AppPredictionTests has already been defined.'
);

function assert(expression, message, info) {
    return UIAUtilities.assert(expression, 'Assertion Failed: ' + message, info);
}

function assertEqual(expectedVal, actualVal, errorMessage, info) {
    return UIAUtilities.assertEqual(expectedVal, actualVal, 'Assertion Failed: ' + errorMessage, info);
}

// arguments are consecutive pairs of "value, array of keys expected to have value"
function assertKeysHaveValue() {
    var expected = {};
    var actual = {};
    var value = null;
    UIALogger.logMessage('argument count: ' + arguments.length + ' % 2 = ' + arguments.length % 2);
    assert(arguments.length > 0 && arguments.length % 2 === 0, 'Invalid number of arguments: ' + arguments.length);
    for (var i = 0; i < arguments.length; i++) {
        var argument = arguments[i];
        if (i % 2 == 0) { // argument is a value for the next list of keys
            assert(typeof argument === 'number' && argument % 1 === 0, 'Invalid argument -- expected integer: argument ' + i + ': ' + argument);
            value = argument;
        } else { // argument is a list of keys
            assert(argument instanceof Array, 'Invalid argument -- expected array: argument ' + i + ': ' + argument);
            for (var j = 0; j < argument.length; j++) {
                var key = argument[j];
                expected[key] = value;
                actual[key] = fetchAggdCountForKey(key);
            }
            value = null;  // we don't want to carry over previous values to the next set of keys if something's out of whack
        }
    }
    // log all expected and actual values
    var sortedKeys = Object.keys(expected).sort();
    sortedKeys.forEach(function(key) {
        if (expected.hasOwnProperty(key)) {
            UIALogger.logMessage('Key: ' + key + '   expected: ' + expected[key] + '   actual: ' + actual[key] + (expected[key] !== actual[key] ? ' *****ERROR*****' : '' ));
        }
    });
    // and then fail if something doesn't match
    sortedKeys.forEach(function(key) {
        if (expected.hasOwnProperty(key)) {
            assertEqual(expected[key], actual[key], 'Incorrect key value for ' + key);
        }
    });
}

function assertEqualJson(value1, value2, message, info) {
    var json1 = JSON.stringify(value1);
    var json2 = JSON.stringify(value2);
    assertEqual(json1, json2, '%0 != %1'.format(value1, value2), info);
}

function assertKeyHasValue(value, key) {
    UIALogger.logMessage('Checking if value of ' + key + ' is ' + value);
    assertEqual(value, fetchAggdCountForKey(key), 'AggD count for %0 was not %1'.format(key, value));
}

function assertAppPredictionDisplaySane(predictionLabels, predictionButtons, options) {
    options = UIAUtilities.defaults(options, {
        minPredictionCount:4
    });

    if (!predictionLabels) {
        throw new UIAError('ZKW App Prediction labels object is null!');
    }

    if (!predictionButtons) {
        throw new UIAError('ZKW App Prediction buttons object is null!');
    }

    var evaluatedPredictedAppLabels = springboard.inspectAll(predictionLabels);
    assert(evaluatedPredictedAppLabels.length > 0, 'No ZKW App Prediction labels shown!');
    assert(evaluatedPredictedAppLabels.length >= options.minPredictionCount, 'Only ' + evaluatedPredictedAppLabels.length + ' ZKW App Prediction labels shown!');

    var evaluatedPredictedAppButtons = springboard.inspectAll(predictionButtons);
    assert(evaluatedPredictedAppButtons.length > 0, 'No ZKW App Prediction buttons shown!');
    assert(evaluatedPredictedAppButtons.length >= options.minPredictionCount, 'Only ' + evaluatedPredictedAppButtons.length + ' ZKW App Prediction buttons shown!');

    assert(evaluatedPredictedAppLabels.length == evaluatedPredictedAppButtons.length, 'There are ' + evaluatedPredictedAppLabels.length + ' ZKW App Prediction labels showing and '
           + evaluatedPredictedAppButtons.length + ' buttons showing!');
}

function getAppName(app) {
    assert(app['name'] !== null, '"name" element not found on object: \n' + JSON.stringify(app,null,4));
    return app['name'];
}

function getAppLabelIndicesExcludingAppNames(apps, appNamesToExclude) {
    var exclusionMap = {};
    appNamesToExclude.forEach(function(element, index, array) { exclusionMap[element] = true; });

    var remainingIndices = [];
    var appArray = springboard.inspectAll(apps);
    for (i = 0; i < appArray.length; i++) {
        var appName = getAppName(appArray[i]);
        if (!exclusionMap.hasOwnProperty(appName)) {
            remainingIndices.push(i);
        }
    }
    return remainingIndices;
}

Array.prototype.retainOnlyIndices = function(indicesToRetain) {
    var map = {};
    indicesToRetain.forEach(function(element, index, array) { map[element] = true; });

    retainedItems = [];
    for (i = 0; i < this.length; i++) {
        if (map.hasOwnProperty(i)) {
            retainedItems.push(this[i]);
        }
    }
    return retainedItems;
}

//arguments are an array of app buttons, followed by an array of bundleids to exclude.  Returns the the app buttons that do not have one of the exluded bundleids.
// return value is an array of the indices of non-excluded buttons.
function getAppButtonsExcluding(apps, indicesToExclude) {
    var exclusionMap = {};
    indicesToExclude.forEach(function(element, index, array) { exclusionMap[element] = true; });

    selectedNames = [];
    for (i = 0; i < springboard.inspectAll(apps).length; i++) {
        if (!exclusionMap.hasOwnProperty(i)) {
            selectedNames.push(getAppName(apps[i]));
        }
    }
    return selectedNames;
}

function escapeForRegexp(string) {
    return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
}

function getFeedbackDataFromSyslog() {
    var rawFeedbackData;
    pollUntil(function() {
        rawFeedbackData = outputOf(readSyslog('duetexpertd', 'Received feedback'));
        return rawFeedbackData.length > 0;
    }, {attempts: 5, delay: 5, errorMessage: 'No "Received Feedback" message from spotlight!'});
    UIALogger.logMessage('Raw feedback data: ' + rawFeedbackData);

    var regexp = /Received feedback\s+Engaged=(\d+)\s+itemSelected=\((\S+)\)(?:.|\n)*?itemsShownCount.*?\{\s+2\s*=\s*(\d+);(?:.|\n)*?\}(?:.|\n)*?queryString\"\s*=\s*(\".*?\"|\S+?);(?:.|\n)*?spotlightType\"\s*=\s*(\d+);\s+\}/m;
    var match = regexp.exec(rawFeedbackData);
    assert(match !== null, 'Regex failed to match feedback from syslog and extract parameters');

    var feedbackData = {
        engaged : match[1] === '1' ? true : false,
        itemSelected : match[2],
        metadata : { itemsShownCount: parseInt(match[3]), queryString: match[4].replace(/(^"|"$)/g, ''), spotlightType: parseInt(match[5]) },
    };
    UIALogger.logMessage("Parsed feedback data: " + JSON.stringify(feedbackData, null, 4));
    return feedbackData;
}

function aggdFlush() {
    target.delay(2);
    var result = exec('/usr/local/bin/aggregatectl', ['--checkpoint']);
    target.delay(3);
    return result;
}

function fetchAggdCountForKey(key) {
    var result = exec('/usr/local/bin/aggregatectl', ['--scalarsWithPrefix', key]);
    var lines = result.stdout.split('\n');

    if (lines.length < 5) {
        throw new UIAError('Unexpected output from aggregatectl, expecting 5 lines, got:\n%0', result.stdout);
    }

    var linesWithoutHeaderAndFooter = lines.slice(2, -2);
    var regexp = new RegExp(escapeForRegexp(key) + '\\s*([0-9]+)\\s*$');
    var result = null;

    linesWithoutHeaderAndFooter.forEach(function(line) {
        var match = line.match(regexp);
        if (match) {
            result = parseInt(match[1]);
        }
    });

    if (result === null) {
        throw new UIAError('Unexpected output from aggregatectl, no line matching %0'.format(regexp.toString()));
    }

    return result;
}

function clearAggdStatsForKeys() {
    for (var i = 0; i < arguments.length; i++) {
        if (arguments[i] instanceof Array) {
            // argument is a list of keys
            for (var j = 0; j < arguments[i].length; j++) {
                clearAggdStatsForKey(arguments[i][j]);
            }
        } else {
            // argument is an individual key
            clearAggdStatsForKey(arguments[i]);
        }
    }
}

function clearAggdStatsForKey(key) {
    // Use --setScalar to 0 because if we use --clearScalar the key disappears but only for the current day.
    // This way we are guaranteed to read back a 0 with fetchAggdCountForKey if we run it immediately following this.
    var result = exec('/usr/local/bin/aggregatectl', ['--setScalar', key+':0']);
}

function getLeftOfHomeZkwAppLabels() {
    // Get the UI elments for predictions that contain the app name.  Valid as of Castlerock13C56.
    var predictedApps = UIAQuery.withValueForKey('Application','hint').below('SIRI SUGGESTIONS').above('NEARBY').isVisible(); // There should be a better way to do this
    return predictedApps;
}

function getLeftOfHomeZkwAppButtons() {
    // Get the UI elements for predictions that contain the user-tappable element needed to select a prediction.
    // This is same as getLeftOfHomeZkwAppLabels, as of Castlerock13C65, but hasn't always been this way, and may diverge again.
    var predictedAppButtons = getLeftOfHomeZkwAppLabels();
    return predictedAppButtons;
}

function getPullDownZkwAppLabels() {
    // Get the UI elments for predictions that contain the app name. Valid as of Castlerock13C56.
    var predictedApps = UIAQuery.withValueForKey('Application','hint').below('SIRI APP SUGGESTIONS').isVisible(); // There should be a better way to do this
    return predictedApps;
}

function getPullDownZkwAppButtons() {
    // Get the UI elements for predictions that contain the user-tappable element needed to select a prediction.
    // This is same as getLeftOfHomeZkwAppLabels, as of Castlerock13C65, but hasn't always been this way, and may diverge again.
    var predictedAppButtons = getPullDownZkwAppLabels();
    return predictedAppButtons;
}

function getZkwAppLabels(swipeType) {
    var predictedAppLabels;
    if (swipeType === SwipeType.LEFT_OF_HOME) {
        predictedAppLabels = getLeftOfHomeZkwAppLabels();
    } else {
        predictedAppLabels = getPullDownZkwAppLabels();
    }
    return predictedAppLabels;
}

function getZkwAppButtons(swipeType) {
    var predictedButtons;
    if (swipeType === SwipeType.LEFT_OF_HOME) {
        predictedButtons = getLeftOfHomeZkwAppButtons();
    } else {
        predictedButtons = getPullDownZkwAppButtons();
    }
    return predictedButtons;
}

function launchSpotlight(swipeType) {
    if (swipeType === SwipeType.LEFT_OF_HOME) {
        assert(getToZeroKeywordSearchForced(), 'Could not navigate to left-of-home zero keyword search!');
    } else {
        assert(getToPullDownZeroKeywordSearchForced(), 'Could not navigate to pull-down zero keyword search!');
    }
}

function findButtonForAppPredictionBundleId(bundleId, swipeType, appNameBundleIdMap) {
    // get the app name from the bundleId -- we need it to find the prediction
    var appName = appNameBundleIdMap.getName(bundleId);

    // Use the zkw app labels to get the index of the label with the app name
    var predictionLabels = getZkwAppLabels(swipeType);
    var predictionLabelArray = springboard.inspectAll(predictionLabels);
    var matchingIndex = predictionLabelArray.findIndex(function(item) { return getAppName(item) === appName });
    if (matchingIndex == -1) {
        return null;  // we don't throw an error here, even though we couldn't find the prediction, and
        //   leave the handling of this error to the caller
    }

    // Finally use the index to lookup the app
    var predictionButtons = getZkwAppButtons(swipeType);
    return predictionButtons.atIndex(matchingIndex);
}


function ensureMinimalZkwSiriSuggestionsDisplay() {
    var showLess = UIAQuery.query("Show Less").above('NEARBY');
    if (springboard.exists(showLess)) {
        springboard.tap(showLess);
    }
}

function ensureMaximalZkwSiriSuggestionsDisplay() {
    var showMore = UIAQuery.query("Show More").above('NEARBY');
    if (springboard.exists(showMore)) {
        springboard.tap(showMore);
    }
}

function ensureMinimalZkwNewsDisplay() {
    var showLess = UIAQuery.query("Show Less").below('NEARBY');
    if (springboard.exists(showLess)) {
        springboard.tap(showLess);
    }
}

function ensureMaximalZkwNewsDisplay() {
    var showMore = UIAQuery.query("Show More").below('NEARBY');
    if (springboard.exists(showMore)) {
        springboard.tap(showMore);
    }
}

function getToHomeScreen() {
    target.clickMenu();
    target.delay(3); // was 1, but we sometimes still detected this as a double click and went to app switcher instead of springboard
    target.clickMenu();
    target.delay(1);  // if we don't wait here, the next operation sometimes will not be detected
}

// find apps that are neither in the predictedAppArray or the list of exluded bundleids.  appNameBundleIdMap is passed in to enable looking up
//   bundleIds from app names and vice versa via cached app information.
function findAppsNotInSet(predictedAppArray, bundleIdExclusions, appNameBundleIdMap) {
    var exclusionMap = {};
    if (bundleIdExclusions){
        bundleIdExclusions.forEach(function(element, index, array) { exclusionMap[element] = true; });
    }

    var predictedAppNames = predictedAppArray.map(getAppName);
    var allAppNames = appNameBundleIdMap.getAllAppNames();
    var filteredAppNames = allAppNames.filter(function(appName) {
        if (predictedAppNames.indexOf(appName) != -1) return false;  // exclude predicted apps
        if (bundleIdExclusions.hasOwnProperty(appNameBundleIdMap.getBundleId(appName))) return false; //exclude apps with bundleids in the exclusion map
        return true; // app was not excluded
    });
    return filteredAppNames;
}

function aggdAppPredictionKey() {
    key = '';
    for (var i = 0; i < arguments.length; i++) {
        key += arguments[i];
        if (i < arguments.length - 1) {
            key += '.';
        }
    }
    return key;
}

/**
 * This is a more aggressive version of the function in SpringBoard.js that will actually attempt to restart all the relevant daemons if predicitons don't show up.
 *
 * Brings up zero keyword search if necessary
 *
 * @returns {boolean} true if zkw / left-of-home spotlight is up, and app predictions are being shown
 * (Pull-down spotlight is handled by getToSpotlight.)
 */
function getToZeroKeywordSearchForced(options) {
    options = UIAUtilities.defaults(options, {
    });

    UIALogger.logMessage("Navigating to left-of-home Zero Keyword Search view");

    // ensure that the first app prediction (which is at the top) is visible
    var firstPredictedApp = getLeftOfHomeZkwAppLabels();

    if (springboard.exists(firstPredictedApp.isVisible())) {
        return true;
    }

    springboard.launch();
    springboard.swipeFromLeftEdge(UIAQuery.application());

    // We may be on the intro screen that one sees the first time after an erase install, instead of normal spotlight.  If so, we need to press "continue"
    if (springboard.exists(UIAQuery.withPredicate("value BEGINSWITH 'You can search the web'").isVisible())) {
        // Tap and touch don't work on "Continue" below, but swipe does
        // <rdar://problem/22506386> tap and touch operations do not work on "Continue" in the introduction to Spotlight screen
        springboard.swipeDown(UIAQuery.withPredicate("value BEGINSWITH 'Continue'"));
    }

    // If the first predicted app is not visible AND we're not just in spotlight search (i.e. typing in a search term), then we need to scroll up to get to the first app
    if (!springboard.exists(firstPredictedApp.isVisible()) && !springboard.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
        springboard.scrollUpIfExists(firstPredictedApp);
    }

    // We may be in spotlight search instead of zkw.  If so, hit "cancel" to get back to zkw
    //  This may happen if there is a left-over search in spotlight, but may also happen as a result of scrolling to the first app prediction if it had not been visible
    //  This is different from the equivalent operation in pull-down spotlight.
    //  <rdar://problem/22501938> Cancel and "x" button behavior inconsistent between left-of-home and pull-down spotlight screens
    if (springboard.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
        springboard.tap(UIAQuery.CANCEL_BUTTON);
    }

    // Ie may be on the zkw screen, but with app predictions missing!
    // Since they can't be displayed for a while yet, wait a while to allow the phone to catch up.
    // App predictions won't be displayed even after waiting on the zkw screen, but at that point, we'll be able to get them by exiting and re-entering spotlight.
    // We may have do do this several times depending on how long it takes app predictions to be ready.
    // <rdar://problem/22483543> App Predictions do not appear during first zkw display after an erase install
    var i = 0;
    springboard.waitUntilPresent(firstPredictedApp.isVisible(), 10);
    while (i++ < 2 && !springboard.exists(firstPredictedApp.isVisible())) {
        // We're likeley in the state where we're in zkw spotlight, but no app predictions are showing, even after waiting for a while in zkw.
        // To work around this, go back to switchboard home once, and then swipe over to zkw again to get app predictions.
        var j = 0;
        while (j++ < 2 && !springboard.exists(firstPredictedApp.isVisible())) {
            target.clickMenu();
            target.delay(2);
            springboard.swipeFromLeftEdge(UIAQuery.application());
            // We may be on the intro screen that one sees the first time after an erase install, instead of normal spotlight.  If so, we need to press "continue"
            if (springboard.exists(UIAQuery.withPredicate("value BEGINSWITH 'You can search the web'").isVisible())) {
                // Tap and touch don't work on "Continue" below, but swipe does
                // <rdar://problem/22506386> tap and touch operations do not work on "Continue" in the introduction to Spotlight screen
                springboard.swipeDown(UIAQuery.withPredicate("value BEGINSWITH 'Continue'"));
            }
            springboard.waitUntilPresent(firstPredictedApp.isVisible(), 5); // there may be a delay in apps showing up even now
        }
        if (!springboard.exists(firstPredictedApp.isVisible())) {
            target.performTask('/usr/bin/killall', ['-9', '-v', 'duetexpertd', 'searchd', 'SpringBoard']);
            target.delay(30);
            setSyslogLevelToDebug('duetexpertd');
            springboard.launch();
            var unlocked = target.systemApp().unlock({}); // no passcode support currently
            if (typeof unlocked !== 'undefined' && !unlocked) {
                throw new UIAError('Could not unlock device');
            }
        }
    }
    return Boolean(springboard.exists(firstPredictedApp.isVisible()));
}
/**
 * This is a more aggressive version of the function in SpringBoard.js that will actually attempt to restart all the relevant daemons if predicitons don't show up.
 *
 * Brings up pull-down spotlight's zero keyword app predictions
 *
 * @returns {boolean} true if pull-down spotlight is up and
 *   app predictions are displayed
 *   (Left-of-home zkw is handled by getToZeroKeywordSearch.)
 */
function getToPullDownZeroKeywordSearchForced(options) {
    options = UIAUtilities.defaults(options, {
    });

    UIALogger.logMessage("Navigating to pull-down zero-keyword search");

    // ensure that the first app prediction (which is at the top) is visible
    // Unfortunately UIAQuery.tableViews('SPUISearchTableView').andThen(UIAQuery.withValueForKey('SearchUICollectionViewCell', 'className')) will also match on "nearby" maps
    var firstPredictedApp = getPullDownZkwAppLabels();

    if (springboard.exists(firstPredictedApp.isVisible())) {
        return true;
    }

    assert(springboard.getToSpotlight(), "Unable to navigate to pull-down spotlight!")

    // If the first predicted app is not visible AND we're not just in spotlight search (i.e. typing in a search term), then we need to scroll up to get to the first app
    //   probably can't happen in pull-down spotlight but may as well account for the possibility due to a future change
    if (!springboard.exists(firstPredictedApp.isVisible()) && !springboard.exists(UIAQuery.CANCEL_BUTTON.isVisible())) {
        springboard.scrollUpIfExists(firstPredictedApp);
    }

    // We may be in spotlight search instead of zkw.  If so, hit the "x" button in the search bar to get back to zkw
    // This may happen if there is a left-over search in spotlight, but may also happen as a result of scrolling to the first app prediction if it had not been visible
    // NOTE:  this is different from left-of-home zkw, where cancel just goes back to zkw search, and "x" only erases the text without going back to zkw.
    //        Here, "x" goes back to zkw, but cancel exits spotlight entirely.
    //        <rdar://problem/22501938> Cancel and "x" button behavior inconsistent between left-of-home and pull-down spotlight screens
    var clearTextButton = UIAQuery.withValueForKey('Clear text', 'label');
    if (springboard.exists(clearTextButton.isVisible())) {
        springboard.tap(clearTextButton);
    }

    // If this is shortly after powering up the phone (and/or the first time we use zkw after clicking "Continue" above, we may be on the zkw screen, but with app predictions missing!
    // Since they can't be displayed for a while yet, wait a while to allow the phone to catch up.
    // App predictions won't be displayed even after waiting on the zkw screen, but at that point, we'll be able to get them by exiting and re-entering spotlight.
    // We may have do do this several times depending on how long it takes app predictions to be ready.
    // <rdar://problem/22483543> App Predictions do not appear during first zkw display after an erase install
    var i = 0;
    springboard.waitUntilPresent(firstPredictedApp.isVisible(), 10);
    while (i++ < 2 && !springboard.exists(firstPredictedApp.isVisible())) {
        // We're likeley in the state where we're in zkw spotlight, but no app predictions are showing, even after waiting for a while in zkw.
        // To work around this, go back to switchboard home once, and then swipe over to zkw again to get app predictions.
        var j = 0;
        while (j++ < 2 && !springboard.exists(firstPredictedApp.isVisible())) {
            target.clickMenu();
            target.delay(2);
            springboard.dragDownInside(UIAQuery.application());
            springboard.waitUntilPresent(firstPredictedApp.isVisible(), 5); // there may be a delay in apps showing up even now
        }
        if (!springboard.exists(firstPredictedApp.isVisible())) {
            target.performTask('/usr/bin/killall', ['-9', '-v', 'duetexpertd', 'searchd', 'SpringBoard']);
            target.delay(30);
            setSyslogLevelToDebug('duetexpertd');
            springboard.launch();
            var unlocked = target.systemApp().unlock({}); // no passcode support currently
            if (typeof unlocked !== 'undefined' && !unlocked) {
                throw new UIAError('Could not unlock device');
            }
        }
    }
    return Boolean(springboard.exists(firstPredictedApp.isVisible()));
}

function getFeedbackStats() {
    //var feedbackToolCmd = '/usr/local/bin/atxFeedbackTool';
    var feedbackToolCmd = '/var/root/atxFeedbackTool';
    var toolOutput = exec(feedbackToolCmd, ['getPerAppFeedbackData'])['stderr'].split("\n");

    var confirmsRegexp = new RegExp('\\]\\s+(\\S+)\\s+confirms\\:\\s+(\\d+\\.\\d+)\\s*$');
    var rejectsRegexp = new RegExp('\\]\\s+(\\S+)\\s+rejects\\:\\s+(\\d+\\.\\d+)\\s*$');
    var statsByApp = {};

    toolOutput.forEach(function(line) {
        var matchConfirms = line.match(confirmsRegexp);
        if (matchConfirms) {
            if (!statsByApp[matchConfirms[1]]) {
                statsByApp[matchConfirms[1]] = {};
            }
            statsByApp[matchConfirms[1]]['confirms'] = parseFloat(matchConfirms[2]);
        } else {
            var matchRejects = line.match(rejectsRegexp);
            if (matchRejects) {
                statsByApp[matchRejects[1]]['rejects'] = parseFloat(matchRejects[2]);
            }
        }
    });
    return statsByApp;
}

function assertSyslogFeedbackDataIsValid(feedbackData, expectedValues) {
    assert(true,feedbackData.engaged == expectedValues.engaged, 'Invalid engaged value');
    assert(true,feedbackData.itemSelected === (expectedValues.itemSelected || 'null'), 'Invalid itemSelected value');
    assert(true,feedbackData.metadata.itemsShownCount >= expectedValues.minItemsShownCount, 'Invalid itemsShownCount value');
    assert(true,feedbackData.metadata.queryString === expectedValues.queryString, 'Invalid queryString value');
    assert(true,feedbackData.metadata.spotlightType === (expectedValues.spotlightType === SwipeType.LEFT_OF_HOME ? 1 : 2) , 'Invalid spotlightType value');
}

function verifyFeedbackStatsUpdated(oldStats, chosenBundleId, rejectedBundleIds, excludedBundleIds) {
    // excludedBundleIds will not be checked at all
    UIALogger.logMessage(" Comparing previous and current feedback values in the app prediction database: ");

    var exclusionMap = {};
    if (excludedBundleIds) {
        excludedBundleIds.forEach(function(element, index, array) { exclusionMap[element] = true; });
    }

    var appConfirmsDelta = {};
    var appRejectsDelta = {};

    var newStats = getFeedbackStats();
    for (var bundleId in oldStats) {
        var oldAppStats = oldStats[bundleId];
        var newAppStats = newStats[bundleId];
        appConfirmsDelta[bundleId] = newAppStats['confirms'] - oldAppStats['confirms'];
        appRejectsDelta[bundleId] = newAppStats['rejects'] - oldAppStats['rejects'];

        var confirmsMessage = appConfirmsDelta[bundleId] == 0 ? "no change (" + oldAppStats['confirms'] + ')' : oldAppStats['confirms'] + ' --> ' + newAppStats['confirms'];
        var rejectsMessage = appRejectsDelta[bundleId] == 0 ? "no change ("  + oldAppStats['rejects'] + ')': oldAppStats['rejects'] + ' --> ' + newAppStats['rejects'];
        UIALogger.logMessage(bundleId + ' confirms: ' + confirmsMessage);
        UIALogger.logMessage(bundleId + ' rejects: ' + rejectsMessage);
    }
    for (var bundleId in oldStats) {
        if (exclusionMap.hasOwnProperty(bundleId)) continue; //don't check excluded apps
        if (chosenBundleId === bundleId) {
            assert(true, appConfirmsDelta[bundleId] > 0 && Math.abs(appConfirmsDelta[bundleId]) <= 1, 'Chosen app ' + bundleId + ' "confirms" delta outside of expected range');
            assert(true, appRejectsDelta[bundleId] <= 0 && Math.abs(appRejectsDelta[bundleId]) < 1, 'Chosen app ' + bundleId + ' "rejects" delta outside of expected range');
        }
        else if (rejectedBundleIds.indexOf(bundleId) != -1) {
            assert(true, appConfirmsDelta[bundleId] <= 0 && Math.abs(appConfirmsDelta[bundleId]) < 1, 'Rejected app ' + bundleId + ' "confirms" delta outside of expected range');
            assert(true, appRejectsDelta[bundleId] > 0 && Math.abs(appRejectsDelta[bundleId]) <= 1, 'Rejected app ' + bundleId + ' "rejects" delta outside of expected range');
        }
        else {
            assert(true, appConfirmsDelta[bundleId] <= 0 && Math.abs(appConfirmsDelta[bundleId]) < 1, 'Non-displayed app ' + bundleId + ' "confirms" delta outside of expected range');
            assert(true, appRejectsDelta[bundleId] <= 0 && Math.abs(appRejectsDelta[bundleId]) < 1, 'Non-displayed app'  + bundleId + ' "rejects" delta outside of expected range');
        }
    }
}

function setDifference(a, b) {
    var mapOfA = {};
    b.forEach(function(element, index, array) { mapOfA[element] = true; });
    return a.filter(function(item) { return !mapOfA.hasOwnProperty(item); });
}

var Aggd = {
    Prefix : {
        DEC_PREDICTIONS : 'com.apple.duet.expertcenter.predictions',
        DEC_PREDICTED_ITEMS : 'com.apple.duet.expertcenter.predictedItems',
        DEC_APP_PREDICTION_EXPERT : 'com.apple.duet.expertcenter.AppPredictionExpert',
        DEC_PEOPLE_SUGGESTER : 'com.apple.duet.expertcenter.PeopleSuggester',
        DEC_DEEP_LINK_SUGGESTER : 'com.apple.duet.expertcenter.DeepLinkExpert',
    },

    DecExpert : {
        APP_PREDICTION_EXPERT : 'AppPredictionExpert',
        DEEP_LINK_EXPERT : 'DeepLinkExpert',
        PEOPLE_SUGGESTER : 'com.apple.PeopleSuggester.CategoryPeople',
        MAGICAL_MOMENTS : 'com.apple.MagicalMoments.CategoryApp',
    },

    DecCategory : {
        APP : 'CategoryApp',
        APP_DEEP_LINK : 'CategoryAppDeepLink',
        PEOPLE : 'CategoryPeople',
        ALL : 'CategoryAll',
        APP_ALL : 'CategoryAppAll',
        UNKNOWN : 'CategoryUnknown',
    },

    DecConsumerType : {
        SPOTLIGHT : 'ConsumerSpotlight',
        SPRINGBOARD : 'ConsumerSpringBoard',
        NOW_PLAYING : 'ConsumerNowPlaying',
        STARK : 'ConsumerTypeStark',
        PHONE : 'ConsumerTypePhone',
        ALL : 'ConsumerAll',
        UNKNOWN : 'ConsumerUnknown',
    },

    DecConsumerSubType : {
        LEFT_OF_HOME : 'ConsumerSpotlightLOH',
        PULL_DOWN : 'ConsumerSpotlightPulldown',
    },

    DecPredictionEventOutcome : {
        SHOWN : 'shown',
        CONVERTED : 'converted',
        CONVERTED_OTHER_EXPERT : 'convertedOtherExpert',
        PSEUDO_CONVERTED : 'pseudoconverted',
        QUERY : 'query',
        ABANDONED : 'abandoned',
        SEARCH_ABANDONED : 'searchAbandoned',
        DIVERTED : 'diverted',
    },

    AppAbTestGroup : {
        AB_ALL : 'ab.ALL',
    },

    AppPredictionEventOutcome : {
        PREDICTED : 'predictions',
        CONVERTED : 'converted',
        CONVERTED_OTHER_EXPERT : 'convertedOtherExpert',
        PSEUDO_CONVERTED : 'pseudoconverted',
        ABANDONED : 'abandoned',
        DIVERTED : 'diverted',
    },

    ssDecConsumerSubType : function(swipeType) { return swipeType === SwipeType.LEFT_OF_HOME ? Aggd.DecConsumerSubType.LEFT_OF_HOME : Aggd.DecConsumerSubType.PULL_DOWN; },

    //screen-specific DEC keys
    ssDecShownKey : function (swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.SHOWN, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecConvertedKey : function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.CONVERTED, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecAbandonedKey : function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.ABANDONED, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecSearchAbandonedKey : function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.SEARCH_ABANDONED, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecDivertedKey: function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.DIVERTED, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecPseudoconvertedKey : function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.PSEUDO_CONVERTED, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },
    ssDecConvertedOtherExpertKey : function(swipeType) { return aggdAppPredictionKey(Aggd.Prefix.DEC_PREDICTIONS, Aggd.DecPredictionEventOutcome.CONVERTED_OTHER_EXPERT, Aggd.DecExpert.APP_PREDICTION_EXPERT, Aggd.DecCategory.APP, Aggd.ssDecConsumerSubType(swipeType)); },


    //app-predictor expert keys
    appPredictorPredictedKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.PREDICTED); },
    appPredictorConvertedKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.CONVERTED); },
    appPredictorAbandonedKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.ABANDONED); },
    appPredictorDivertedKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.DIVERTED); },
    appPredictorPseudoconvertedKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.PSEUDO_CONVERTED); },
    appPredictorConvertedOtherExpertKey : function() { return aggdAppPredictionKey(Aggd.Prefix.DEC_APP_PREDICTION_EXPERT, Aggd.AppAbTestGroup.AB_ALL, Aggd.AppPredictionEventOutcome.CONVERTED_OTHER_EXPERT); },

    getKeyList : function() {
        return [Aggd.ssDecShownKey(SwipeType.LEFT_OF_HOME), Aggd.ssDecConvertedKey(SwipeType.LEFT_OF_HOME), Aggd.ssDecAbandonedKey(SwipeType.LEFT_OF_HOME), Aggd.ssDecSearchAbandonedKey(SwipeType.LEFT_OF_HOME),
                Aggd.ssDecDivertedKey(SwipeType.LEFT_OF_HOME), Aggd.ssDecPseudoconvertedKey(SwipeType.LEFT_OF_HOME), Aggd.ssDecConvertedOtherExpertKey(SwipeType.LEFT_OF_HOME),
                Aggd.ssDecShownKey(SwipeType.PULL_DOWN), Aggd.ssDecConvertedKey(SwipeType.PULL_DOWN), Aggd.ssDecAbandonedKey(SwipeType.PULL_DOWN), Aggd.ssDecSearchAbandonedKey(SwipeType.PULL_DOWN),
                Aggd.ssDecDivertedKey(SwipeType.PULL_DOWN), Aggd.ssDecPseudoconvertedKey(SwipeType.PULL_DOWN), Aggd.ssDecConvertedOtherExpertKey(SwipeType.PULL_DOWN),
                Aggd.appPredictorPredictedKey(), Aggd.appPredictorConvertedKey(), Aggd.appPredictorAbandonedKey(), Aggd.appPredictorDivertedKey(), Aggd.appPredictorPseudoconvertedKey(), Aggd.appPredictorConvertedOtherExpertKey()];
    },

    allKeysExcept : function(keysToExclude) {
        return setDifference(Aggd.getKeyList(), keysToExclude);
    },
};

var SwipeType = {
    LEFT_OF_HOME : 0,
    PULL_DOWN : 1,
};
