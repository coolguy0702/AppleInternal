/**
 * Tools for interacting with the App Prediction code in DuetExpertCenter via dectool.
 */

load('UIATesting.js');

/**
 * Run JavaScript code via "dectool js", with the "args" variable set to args.
 *
 * @param {string} js - code to run
 * @param {object} args - some JSON-compatible arguments object
 * @param {int} options.timeout - the timeout for the operation in seconds (default is 30)
 * @returns {object} any JSON logged by the script, parsed.
 */
function runDecToolJs(js, args, options) {
    options = options || {};
    var fulljs = 'var args = %0;\n%1;'.format(JSON.stringify(args || null), js);
    var tmpfile = UIAFile.open('/tmp/AppPrediction-dectool.js', 'w');
    tmpfile.write(fulljs);
    tmpfile.close();

    var result = target.performTask('/usr/local/bin/dectool', ['js', tmpfile.path], options.timeout || 20);
    if (result.exitCode) {
        throw new UIAError('dectool js error: ' + result.stderr);
    }
    return JSON.parse(result.stdout || null);
}

/** @namespace */
var AppHistory = {};

/**
 * Clear app launch history.
 */
AppHistory.clear = function() {
    runDecToolJs('AppHistory.clear()');
};

/**
 * Add launch to app history.
 * @param {string} bundleId - bundle id of app
 * @param {boolean} fromSpotlight - is this launch from Spotlight?
 * @param {string|number} date - date, as unix timestamp or RFC2822 or ICO 8601 datetime string.
 */
AppHistory.addLaunch = function(bundleId, fromSpotlight, date) {
    runDecToolJs('AppHistory.addLaunch(args[0], args[1], args[2])', [bundleId, fromSpotlight, date]);
};

/**
 * Start app history delta recording.
 */
AppHistory.startDeltaRecording = function() {
    runDecToolJs('AppHistory.startDeltaRecording()');
};

/**
 * Stop app history delta recording, and return deltas.
 * @return {array} array of [bundleId, reason, date, timezoneSecondsFromGMT] entries.
 */
AppHistory.stopDeltaRecording = function() {
    return runDecToolJs('log(AppHistory.stopDeltaRecording())');
};

/** @namespace */
var AppInstallHistory = {};

/**
 * Clear app install history.
 */
AppInstallHistory.clear = function() {
    runDecToolJs('AppInstallHistory.clear()');
};

/**
 * Set the install date for an app.
 * @param {string} bundleId - bundle id of app
 * @param {string|number} date - date, as unix timestamp or RFC2822 or ICO 8601 datetime string.
 */
AppInstallHistory.set = function(bundleId, date) {
    runDecToolJs('AppInstallHistory.set(args[0], args[1])', [bundleId, date]);
};

/**
 * Start app install history delta recording.
 */
AppInstallHistory.startDeltaRecording = function() {
    runDecToolJs('AppInstallHistory.startDeltaRecording()');
};

/**
 * Stop app install history delta recording, and return deltas.
 * @return {array} array of [bundleId, reason, date, timezoneSecondsFromGMT] entries.
 */
AppInstallHistory.stopDeltaRecording = function() {
    return runDecToolJs('log(AppInstallHistory.stopDeltaRecording())');
};

/** @namespace */
var Feedback = {};

/**
 * Clear feedback.
 */
Feedback.clear = function() {
    runDecToolJs('Feedback.clear()');
};

/**
 * Add feedback.
 * @param {string} launched - bundleId of app that was launched
 * @param {array.<string>} rejected - bundleIds of apps rejected, i.e. predicted but not launched
 */
Feedback.addFeedback = function(launched, rejected) {
    runDecToolJs('Feedback.addFeedback(args[0], args[1])', [launched, rejected]);
};

/**
 * Run app prediction for all apps.
 * @return {object} - the input and subscore dicts for each app. The value returned is a
 *     dict mapping bundleIds to {inputs: {...}, subscores: {...}} dictionaries. The
 *     inputs and subscores dicts are exactly as seen in the score interpreter.
 */
function predictVerbose() {
    return runDecToolJs('log(predictVerbose())');
}

/**
 * Clear app launch history, app install history, and feedback.
 */
function cleanSlate() {
    return runDecToolJs('cleanSlate()');
}

/**
 * Get the day zero predictions, i.e. the predictions for a fresh user with no history.
 * @param {number} n - number of top predictions to fetch
 * @return {array.<string>} top n bundle ids
 */
function getDayZeroPredictions(n) {
    return runDecToolJs('log(getDayZeroPredictions(args))', n);
}

/**
 * Get the top n predictions.
 * @param {number} n - number of top predictions to fetch
 * @return {array.<string>} top n bundle ids
 */
function predictTopN(n) {
    return runDecToolJs('log(predictTopN(args))', n);
}

/**
 * Get current app prediction asset version.
 * @return {number} asset version
 */
function getAssetVersion() {
    return runDecToolJs('log(assetVersion)');
}

/**
 * Return a time difference, in milliseconds, for n days.
 * @param {number} n - number of days
 * @return {number} equivalent number of milliseconds
 */
function days(n) {
    return n * 24 * 3600 * 1000;
}
