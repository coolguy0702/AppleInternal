function AppNameBundleIdMapping() {
    // TODO:  There should be a better way that is more robust and without side effects to get this mapping than scanning all the apps on springboard,
    //   but this at least works.
    
    var self = this;

    // This constructor has the side effect of navigating into each folder to allow us to scrape all the bundle ids for each app
    // It is only run once, at the beginning of test.
    var allApps = [];
    var topLevelApps = springboard.inspectAll(UIAQuery.query('SBIconView').withPredicate('bundleID != null'));
    var folders = springboard.inspectAll(UIAQuery.query('SBFolderIconView').withPredicate('label != "(null) folder"'));

    // This is a hack that assumes there are only two pages of springboard apps.  Should be valid for current CI testing, but there should be a more robust way to do this.
    // TODO:  How do I get the number of pages?  How do I get the page an app is on?

    getToHomeScreen();
    
    var currentPage = 0;
    folders.forEach(function(folder) {
        if(!springboard.inspect(UIAQuery.query(folder['name']).isVisible())) {
            if (currentPage === 0) {
                springboard.swipeFromRightEdge();
                currentPage = 1;
            } else if (currentPage === 1) {
                springboard.swipeFromLeftEdge();
                currentPage = 0;
            }
        }
        springboard.tap(folder['name']);
        var folderApps = springboard.inspectAll(UIAQuery.query('SBIconView').withPredicate('bundleID != null'));
        allApps = allApps.concat(folderApps);
        target.clickMenu(); // exit folder so we can get back to home and enter the next one
        target.delay(1);
    });
    self.installedApps = allApps;
    getToHomeScreen(); // not strictly necessary, but nicer to leave the phone at the home screen when done than possibly on some other 
    
    self.getName = function(bundleId) {
        var matchingApps = self.installedApps.filter(function(item) { return item['bundleID'] === bundleId; });
        assert(true, matchingApps.length > 0, 'No installed app found matching bundleId ' + bundleId);
        var appName = matchingApps[0]['name'];
        return appName;
    };

    self.getBundleId = function(appName) {
        var matchingApps = self.installedApps.filter(function(item) { return item['name'] === appName; });
        assert(true, matchingApps.length > 0, 'No installed app found matching appName ' + bundleId);
        var bundleId = matchingApps[0]['bundleID'];
        return bundleId;
    };
    
    self.getAllAppNames = function() {
       var appNames = self.installedApps.map(function(app) { return app['name']; });
       return appNames; 
    }
    
    // Get to page one of springboard (home screen)
    // TODO:  This duplicates the getToHomeScreen function in DECUtility -- nned to refactor
    self.getToHomeScreen = function() {
            target.clickMenu();
            target.delay(3);
            target.clickMenu();
            target.delay(1);
    }
    return self;
}


