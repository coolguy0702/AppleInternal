load('UIATesting.js');
load('CacheDelete.js');
load('SpringBoard.js');
load('iCloudTests.js');
load('Settings.js');
load('AVAssetDownloader.js');

if (typeof CacheDeleteTests !== 'undefined') {
    throw new UIAError("Namespace 'CacheDeleteTests' has already been defined.");
}

/**
 * @namespace CacheDeleteTests
 */

var CacheDeleteTests = {
    /**
     * Operations performed by this test:   
     *      STEP-1: Download app  from Appshack
     *      STEP-2: Download Assets using App
     *      STEP-3: Wait for assets to download
     *      STEP-4: Age Assets
     *      STEP-5: Wait for aging to complete
     *      STEP-6: Calculate time taken by CLI tool to refresh available purgeable space
     *      STEP-7: Navigate UI to get available assets and their sizes
     *      STEP-8: Use CLI tool to ask for space
     *      STEP-9: Use CLI tool to check change in purgeable space available
     *      STEP-10: Navigate to UI again to see how many assets were deleted and how much space was made available
     *
     * @targetApps CacheDeleteTool
     *
     * @param {object} args Test arguments
     * @param {string} [args.requestedSpace: '500000'] - Space to be requested by CacheDeleteTool
     * @param {string} [args.timeout: '120'] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.minSpaceAvailable: '10000'] - Minimum space that should be available for the first
     *                  time CacheDelete is run
     * @param {string} [args.service: 'com.apple.mobile.cache_delete_managed_assets'] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.appName: 'AVAssetDownloader'] - Name of the app as seen in the iPhone Storage pane in
     *                  Settings
     * @param {string} [args.views: ['General', 'iPhone Storage'] - Path to get to iPhone Storage pane in Settings
     *                 in form of a list
     * @param {string} [args.appServerURL] - URL to HTTP server that hosts AVAssetDowloader app
     * @param {string} [args.downloadDestination] - Destination on the device where app is downloaded from the server
     */
    hlsCacheDeleteTest: function hlsCacheDeleteTest(args) {
        args = UIAUtilities.defaults(args, {
            requestedSpace: '500000',
            timeout: '120',
            minSpaceAvailable: '10000',
            num_assets_to_download: 5,
            service: 'com.apple.mobile.cache_delete_managed_assets',
            appName:  'AVAssetDownloader',
            views: ['General', 'iPhone Storage'],
            appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa',
            trustDevName: 'iPhone Distribution: Apple, Inc. - PEP',
            serverURL: 'https://apptechqa.apple.com/Data/Automation/StorageSettings/Applications/AVAssetDownloader.ipa',
            downloadDestination: '/tmp/AVAssetDownloader.ipa',
        });

        CacheDeleteTests.installAssetDownloaderApp(args);

        CacheDeleteTests.generatePurgeableHLSData(args);

        purgeDetailsDict = CacheDeleteTests.purgeAndVerifyHLSData(args);

        return purgeDetailsDict;
    },

    /**
     * Downloads and installs AVAssetDownloader app
     *
     * @targetApps AVAssetDownloader
     *
     * @param {object} args Test arguments
     * @param {string} [args.appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa'] - Path to ipa for AVAssetDownloader app
     * @param {string} [args.trustDevName: 'iPhone Distribution: Apple, Inc. - PEP'] - Dev name for AVAssetDownloader app
     * @param {string} [args.serverURL] - URL to http server that hosting AVAssetDownloader app
     * @param {string} [args.downloadDestination] - Destination on the device where app is downloaded from the server
     *
     * Returns - None
     *
     */
    installAssetDownloaderApp: function installAssetDownloaderApp(args) {
        args = UIAUtilities.defaults(args, {
            appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa',
            trustDevName: 'iPhone Distribution: Apple, Inc. - PEP',
            serverURL: 'https://apptechqa.apple.com/Data/Automation/StorageSettings/Applications/AVAssetDownloader.ipa',
            downloadDestination: '/tmp/AVAssetDownloader.ipa',
        });
        UIALogger.logMessage('INSTALL APP');
        avAssetDownloaderApp.downloadAppFromServer(args);
        avAssetDownloaderApp.installApp(args);
    },

    /**
     * Downloads and ages purgeable HLS data using AVAssetdownloader app
     *
     * @targetApps AVAssetDownloader
     *
     * @param {object} args Test arguments
     * @param {string} [args.num_assets_to_download] - number of small assets to be downloaded from AVAssetDownloader app
     *
     * Returns - None
     *
     */
    generatePurgeableHLSData: function generatePurgeableHLSData(args) {
        args = UIAUtilities.defaults(args, {
            num_assets_to_download: 20,
        });

        UIALogger.logMessage('DOWNLOAD ASSETS');
        avAssetDownloaderApp.downloadSmallAsset({
            fromState: 'Downloading',
            toState: 'Success',
            timeout: 300,
            iconName: 'AVAssetDownloader',
            num_assets_to_download: args.num_assets_to_download,
        });

        UIALogger.logMessage('AGE ASSETS');
        avAssetDownloaderApp.ageAssets();
    },

    /**
     * Purge HLS data using CacheDeleteTest tool and verify the requested space was purged by comparing CLI and UI
     * data before and after purge.
     *
     * @targetApps CacheDelete
     *
     * @param {object} args Test arguments
     * @param {string} [args.requestedSpace: '500000'] - Space to be requested by CacheDeleteTool
     * @param {string} [args.timeout: '120'] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.minSpaceAvailable: '10000'] - Minimum space that should be available for the first
     *                  time CacheDelete is run
     * @param {string} [args.service: 'com.apple.mobile.cache_delete_managed_assets'] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.appName: 'AVAssetDownloader'] - Name of the app as seen in the iPhone Storage pane in
     *                  Settings
     * @param {string} [args.views: ['General', 'iPhone Storage']] - Path to get to iPhone Storage pane in Settings
     *                 in form of a list
     *
     * Returns - None
     *
     */
    purgeAndVerifyHLSData: function purgeAndVerifyHLSData(args) {
        args = UIAUtilities.defaults(args, {
            requestedSpace: '500000',
            timeout: '120',
            minSpaceAvailable: '10000',
            service: 'com.apple.mobile.cache_delete_managed_assets',
            appName:  'AVAssetDownloader',
            views: ['General', 'iPhone Storage'],
        });

        UIALogger.logMessage('CLI SPACE AVAILABLE BEFORE CALLING CacheDeleteTest');
        beforeCLIResultDict = cacheDeleteApp.cacheDeletePurgeableSpaceAvailable({
                timeout: args.timeout,
                space: args.minSpaceAvailable,
                service: args.service,
            });

        UIALogger.logMessage('UI DATA BEFORE CALLING CacheDeleteTest');
        beforeUIResultDict = cacheDeleteApp.getCacheDeleteUIDataForService({
                views: args.views,
                appName: args.appName,
            });

        UIALogger.logMessage('CLI VERIFICATION AFTER CALLING CacheDeleteTest');
        releaseMemoryResultDict = cacheDeleteApp.cacheDeleteVerification({
                memory: args.requestedSpace,
                service: args.service,
            });

        purgeTime = releaseMemoryResultDict.CACHE_DELETE_ELAPSED_TIME;
    
        UIALogger.logMessage('UI VERIFICATION AFTER CALLING CacheDeleteTest');
        afterUIResultDict = cacheDeleteApp.getCacheDeleteUIDataForService({
                views: args.views,
                appName: args.appName,
            });
        purgedSpace = cacheDeleteApp.compareUIResults(beforeUIResultDict, afterUIResultDict, args.requestedSpace, args.service);
        return {
            purgeTime: purgeTime,
            purgedSpace: purgedSpace,
        };
    },

    /**
     * Operations performed by this test:   
     *      STEP-1: Sign in to iCloud - DONE
     *      STEP-2: Turn on iCloud Library - DONE
     *      STEP-3: Wait for Sync to complete - DONE
     *              wait for /var/mobile/Media/PhotoData/cpl_download_finished_marker to be written to disk
     *      STEP-4: Purgeable space available as per CacheDeleteTest before purge
     *      STEP-5: UI Data before purge
     *      STEP-6: DiskSpace before purge
     *      STEP-7: Call CacheDeleteTool to ask for space and CLI verification using CacheDeleteTest DONE
     *      STEP-8: Get size of photos on disk after purge
     *      STEP-9: Compare to see if space was free'd up on Disk DONE
     *      STEP-10: Compare UI result to check requested space purged DONE
     *      STEP-11: Sign out of iCloud - DONE
     *
     * @targetApps CacheDeleteTool
     *
     * @param {object} args Test arguments
     * @param {object} [args.iCloudCredentials] - AppleID and password for logging in
     * @param {string} [args.iCloudCredentials.AppleID] - AppleID
     * @param {string} [args.iCloudCredentials.AppleIDPassword] - AppleID Password
     * @param {string} [args.syncCompleteFilePath] - Path to 'cpl_download_finished_marker' 
     *                  - file that is written to disk when photo data sync is complete
     * @param {number} [args.syncTimeoutInMinutes] - Timeout for photo data sync
     * @param {string} [args.requestedSpace: '50000000'] - Space to be requested by CacheDeleteTool
     * @param {string} [args.timeout: '300'] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.minSpaceAvailable: '50000000'] - Minimum space that should be available 
     *                  for the first time CacheDelete is run
     * @param {string} [args.service: 'com.apple.assetsd.cacheDelete'] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.appName:  'Photos'] - Name of the app as seen in the iPhone Storage 
     *                  pane in Settings
     * @param {object} [args.views: ['General', 'iPhone Storage']] - Path to get to iPhone Storage 
     *                 pane in Settings in form of a list
     * @param {string} [args.dirPath: '/var/mobile/Media/PhotoData/'] - Path to PhotoData directory
     * @param {bool}   [args.iCloudLogout: true] - Should iCloud be logged out after a cycle.
     */

    photosCacheDeleteTest: function photosCacheDeleteTest(args) {
        args = UIAUtilities.defaults(args, {
            iCloudCredentials: {
                AppleID: 'cachedeletetest1@icloud.com',
                AppleIDPassword: 'CacheDeleteTest123',
            },
            syncCompleteFilePath: '/var/mobile/Media/PhotoData/cpl_download_finished_marker',
            syncTimeoutInMinutes: 10,
            requestedSpace: '50000000',
            timeout: '300',
            minSpaceAvailable: '50000000',
            service: 'com.apple.assetsd.cacheDelete',
            appName:  'Photos',
            views: ['General', 'iPhone Storage'],
            dirPath: '/var/mobile/Media/PhotoData/',
            iCloudLogout: true,
        });

        CacheDeleteTests.generatePhotosData(args);
        
        purgeDetailsDict = CacheDeleteTests.purgeAndVerifyPhotosData(args);

        if (args.iCloudLogout) {
            UIALogger.logMessage('iCLOUD LOGOUT');
            iCloudTests.signOut(args.iCloudCredentials);
        }
        return purgeDetailsDict;
    },

    /**
     * Generates purgeable Photos data by iCloud Library sync.
     *
     * @targetApps Photos
     *
     * @param {object} args Test arguments
     * @param {object} [args.iCloudCredentials] - iCloud credentials with aged contents
     * @param {string} [args.syncCompleteFilePath] - Path to 'cpl_download_finished_marker' 
     *                  - file that is written to disk when photo data sync is complete
     * @param {number} [args.syncTimeoutInMinutes] - Timeout for photo data sync
     *
     * Returns - None
     *
     */
    generatePhotosData: function generatePhotosData(args) {
        args = UIAUtilities.defaults(args, {
            iCloudCredentials: {
                AppleID: 'cachedeletetest1@icloud.com',
                AppleIDPassword: 'CacheDeleteTest123',
            },
            syncCompleteFilePath: '/var/mobile/Media/PhotoData/cpl_download_finished_marker',
            syncTimeoutInMinutes: 10,
            requestedSpace: '500000',
            service: 'com.apple.assetsd.cacheDelete',
        });

        UIALogger.logMessage('iCLOUD LOGIN');
        iCloudTests.signIn(args.iCloudCredentials);

        UIALogger.logMessage('TURN ON iCLOUD PHOTO LIBRARY');
        settings.turnOniCloudPhotoLibrary(args.iCloudCredentials.AppleIDPassword);

        UIALogger.logMessage('TURN ON DOWNLOAD AND KEEP ORIGINALS');
        cacheDeleteApp.selectDownloadOriginalAndKeep();

        UIALogger.logMessage('WAITING FOR SYNC TO COMPLETE');
        cacheDeleteApp.waitForFileToExist(args);

        UIALogger.logMessage('TURN ON OPTIMIZE iPHONE STORAGE');
        cacheDeleteApp.selectOptimizeIphoneStorage();
    },

    /**
     * Generates purgeable Photos data by iCloud Library sync.
     *
     * @targetApps Photos
     *
     * @param {object} args Test arguments
     * @param {string} [args.requestedSpace: '50000000'] - Space to be requested by CacheDeleteTool
     * @param {string} [args.timeout: '300'] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.minSpaceAvailable: '50000000'] - Minimum space that should be available 
     *                  for the first time CacheDelete is run
     * @param {string} [args.service: 'com.apple.assetsd.cacheDelete'] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.appName:  'Photos'] - Name of the app as seen in the iPhone Storage 
     *                  pane in Settings
     * @param {object} [args.views: ['General', 'iPhone Storage']] - Path to get to iPhone Storage 
     *                 pane in Settings in form of a list
     * @param {string} [args.dirPath: '/var/mobile/Media/PhotoData/'] - Path to PhotoData directory
     * @param {bool}   [args.iCloudLogout: true] - Should iCloud be logged out after a cycle.
     *
     * Returns - None
     *
     */
    purgeAndVerifyPhotosData: function purgeAndVerifyPhotosData(args) {
        args = UIAUtilities.defaults(args, {
            requestedSpace: '500000',
            timeout: '300',
            minSpaceAvailable: '500000',
            service: 'com.apple.assetsd.cacheDelete',
            appName:  'Photos',
            views: ['General', 'iPhone Storage'],
            dirPath: '/var/mobile/Media/PhotoData/'
        });

        UIALogger.logMessage('CLI SPACE AVAILABLE BEFORE CALLING CacheDeleteTest');
        beforeCLIResultDict = cacheDeleteApp.cacheDeletePurgeableSpaceAvailable({
                timeout: args.timeout,
                space: args.minSpaceAvailable,
                service: args.service,
            });

        UIALogger.logMessage('UI DATA BEFORE CALLING CacheDeleteTest');
        beforeUIResultDict = cacheDeleteApp.getCacheDeleteUIDataForService({
                views: args.views,
                appName: args.appName,
            });
        
        UIALogger.logMessage('DISK SPACE BEFORE CALLING CacheDeleteTest');
        diskSpaceBefore = cacheDeleteApp.spaceOnDisk(args.dirPath);

        UIALogger.logMessage('CLI VERIFICATION AFTER CALLING CacheDeleteTest');
        releaseMemoryResultDict = cacheDeleteApp.cacheDeleteVerification({
                memory: args.requestedSpace,
                service: args.service,
            });
        purgeTime = releaseMemoryResultDict.CACHE_DELETE_ELAPSED_TIME;

        UIALogger.logMessage('DISK SPACE AFTER CALLING CacheDeleteTest');
        diskSpaceAfter = cacheDeleteApp.spaceOnDisk(args.dirPath);
        
        UIALogger.logMessage('DISK SPACE VERIFICATION AFTER CALLING CacheDeleteTest');
        cacheDeleteApp.compareDiskSpaceResults(diskSpaceBefore, diskSpaceAfter, args.requestedSpace);

        UIALogger.logMessage('UI VERIFICATION AFTER CALLING CacheDeleteTest');
        afterUIResultDict = cacheDeleteApp.getCacheDeleteUIDataForService({
                views: args.views,
                appName: args.appName,
            });
        purgedSpace = cacheDeleteApp.compareUIResults(beforeUIResultDict, afterUIResultDict, args.requestedSpace, args.service);
        return {
            purgeTime: purgeTime,
            purgedSpace: purgedSpace,
        };
    },

    /**
     * Cycler for CacheDeleteTest
     *
     * @targetApps CacheDeleteTool
     *
     * @param {object} args Test arguments
     * @param {number} [args.hlsArgs.repeat] - Number of times the cycler should run
     * @param {string} [args.hlsArgs.requestedSpace] - Space to be requested by CacheDeleteTool
     * @param {string} [args.hlsArgs.timeout] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.hlsArgs.minSpaceAvailable] - Minimum space that should be available for the first
     *                  time CacheDelete is run.
     * @param {string} [args.hlsArgs.service] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.hlsArgs.appName] - Name of the app as seen in the iPhone Storage pane in
     *                  Settings
     * @param {string} [args.hlsArgs.views] - Path to get to iPhone Storage pane in Settings
     * @param {object} [args.photosArgs.iCloudCredentials] - AppleID and password for logging in
     * @param {string} [args.photosArgs.iCloudCredentials.AppleID] - AppleID
     * @param {string} [args.photosArgs.iCloudCredentials.AppleIDPassword] - AppleID Password
     * @param {string} [args.photosArgs.syncCompleteFilePath] - Path to 'cpl_download_finished_marker' 
     *                  - file that is written to disk when photo data sync is complete
     * @param {number} [args.photosArgs.syncTimeoutInMinutes] - Timeout for photo data sync
     * @param {string} [args.photosArgs.requestedSpace] - Space to be requested by CacheDeleteTool
     * @param {string} [args.photosArgs.timeout] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.photosArgs.minSpaceAvailable] - Minimum space that should be available 
     *                  for the first time CacheDelete is run
     * @param {string} [args.photosArgs.service] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.photosArgs.appName] - Name of the app as seen in the iPhone Storage 
     *                  pane in Settings
     * @param {object} [args.photosArgs.views] - Path to get to iPhone Storage 
     *                 pane in Settings in form of a list
     * @param {string} [args.photosArgs.dirPath] - Path to PhotoData directory
     * @param {bool}   [args.photosArgs.iCloudLogout] - Should iCloud be logged out after a cycle.
     * @param {number} [args.repeat] - Number of cycles for the cycler
     */
    cycleCacheDeleteTest: function cycleCacheDeleteTest(args) {
        args = UIAUtilities.defaults(args, {
            hlsArgs: {
                requestedSpace: '50000000',
                timeout: '300',
                minSpaceAvailable: '50000000',
                num_assets_to_download: 5,
                service: 'com.apple.mobile.cache_delete_managed_assets',
                appName:  'AVAssetDownloader',
                views: ['General', 'iPhone Storage'],
                appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa',
                trustDevName: 'iPhone Distribution: Apple, Inc. - PEP',
                serverURL: 'https://apptechqa.apple.com/Data/Automation/StorageSettings/Applications/AVAssetDownloader.ipa',
                downloadDestination: '/tmp/AVAssetDownloader.ipa',
            },
            photosArgs: {
                iCloudCredentials: {
                    AppleID: 'cachedeletetest1@icloud.com',
                    AppleIDPassword: 'CacheDeleteTest123',
                },
                syncCompleteFilePath: '/var/mobile/Media/PhotoData/cpl_download_finished_marker',
                syncTimeoutInMinutes: 30,
                requestedSpace: '50000000',
                timeout: '600',
                minSpaceAvailable: '50000000',
                service: 'com.apple.assetsd.cacheDelete',
                appName:  'Photos',
                views: ['General', 'iPhone Storage'],
                dirPath: '/var/mobile/Media/PhotoData/',
                iCloudLogout: false,
            },
            repeat: 100,
        });

        var resultDict = {}
        var currentCycle = '';
        var cycleRequestedSpace = '';
        for (var i=1; i <= args.repeat; i++) {
            cacheDeleteApp.printResultDict(resultDict, i-1);
            try {
                UIALogger.logMessage('CYCLE #%0'.format(i));
                number = cacheDeleteApp.generateRandomNumber();
                UIALogger.logMessage('Random number: %0'.format(number))
                if (number % 2 == 0){
                    UIALogger.logMessage('HLS Data Test Cycle');
                    currentCycle = 'HLS';
                    cycleRequestedSpace = args.hlsArgs.requestedSpace;
                    purgeDetailsDict = CacheDeleteTests.hlsCacheDeleteTest(args.hlsArgs);
                } else {
                    UIALogger.logMessage('Photos Data Test Cycle');
                    currentCycle = 'Photos';
                    cycleRequestedSpace = args.photosArgs.requestedSpace;
                    purgeDetailsDict = CacheDeleteTests.photosCacheDeleteTest(args.photosArgs);
                }
            } catch(e) {
                UIALogger.logMessage('Exception: %0'.format(e.message));
                resultDict['Cycle%0: %1'.format(i, currentCycle)] = 'Fail: %0'.format(e.message);
                continue;
            }
            resultDict['Cycle%0: %1'.format(i, currentCycle)] = 'Passed. PurgeTime: %0 RequestedSpace: %1 PurgedSpace: %2'.format(purgeDetailsDict.purgeTime, cycleRequestedSpace, purgeDetailsDict.purgedSpace);
        }

        cacheDeleteApp.printResultDict(resultDict, args.repeat);

        UIALogger.logMessage('iCLOUD LOGOUT');
        iCloudTests.signOut(args.photosArgs.iCloudCredentials);
    },

    /**
     * Cycler for CacheDeleteTest customer scenario
     *
     * @targetApps CacheDeleteTool
     *
     * @param {object} args Test arguments
     * @param {number} [args.hlsArgs.repeat] - Number of times the cycler should run
     * @param {string} [args.hlsArgs.requestedSpace] - Space to be requested by CacheDeleteTool
     * @param {string} [args.hlsArgs.timeout] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.hlsArgs.minSpaceAvailable] - Minimum space that should be available for the first
     *                  time CacheDelete is run.
     * @param {string} [args.hlsArgs.service] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.hlsArgs.appName] - Name of the app as seen in the iPhone Storage pane in
     *                  Settings
     * @param {string} [args.hlsArgs.views] - Path to get to iPhone Storage pane in Settings
     * @param {object} [args.photosArgs.iCloudCredentials] - AppleID and password for logging in
     * @param {string} [args.photosArgs.iCloudCredentials.AppleID] - AppleID
     * @param {string} [args.photosArgs.iCloudCredentials.AppleIDPassword] - AppleID Password
     * @param {string} [args.photosArgs.syncCompleteFilePath] - Path to 'cpl_download_finished_marker'
     *                  - file that is written to disk when photo data sync is complete
     * @param {number} [args.photosArgs.syncTimeoutInMinutes] - Timeout for photo data sync
     * @param {string} [args.photosArgs.requestedSpace] - Space to be requested by CacheDeleteTool
     * @param {string} [args.photosArgs.timeout] - Timeout for CacheDeleteTool to purge space
     * @param {string} [args.photosArgs.minSpaceAvailable] - Minimum space that should be available
     *                  for the first time CacheDelete is run
     * @param {string} [args.photosArgs.service] - Service from which purgeable
     *                  space is asked
     * @param {string} [args.photosArgs.appName] - Name of the app as seen in the iPhone Storage
     *                  pane in Settings
     * @param {object} [args.photosArgs.views] - Path to get to iPhone Storage
     *                 pane in Settings in form of a list
     * @param {string} [args.photosArgs.dirPath] - Path to PhotoData directory
     * @param {bool}   [args.photosArgs.iCloudLogout] - Should iCloud be logged out after a cycle
     * @param {number} [args.repeat] - Number of cycles for the cycler
     * @param {string} [args.dirPathForMKFile] - Path where temporary files are to be created
     * @param {string} [args.dirPathForDiskSpace] - Path to query for disk space left on device
     * @param {number} [args.fileSizeMB] - File size for temporary files to be created
     */
    cacheDeleteCustomerScenario: function cacheDeleteCustomerScenario(args) {
        args = UIAUtilities.defaults(args, {
            hlsArgs: {
                requestedSpace: '50000000',
                timeout: '300',
                minSpaceAvailable: '50000000',
                num_assets_to_download: 50,
                service: 'com.apple.mobile.cache_delete_managed_assets',
                appName:  'AVAssetDownloader',
                views: ['General', 'iPhone Storage'],
                appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa',
                trustDevName: 'iPhone Distribution: Apple, Inc. - PEP',
                serverURL: 'https://apptechqa.apple.com/Data/Automation/StorageSettings/Applications/AVAssetDownloader.ipa',
                downloadDestination: '/tmp/AVAssetDownloader.ipa',
            },
            photosArgs: {
                iCloudCredentials: {
                    AppleID: 'cachedeletetest1@icloud.com',
                    AppleIDPassword: 'CacheDeleteTest123',
                },
                syncCompleteFilePath: '/var/mobile/Media/PhotoData/cpl_download_finished_marker',
                syncTimeoutInMinutes: 30,
                requestedSpace: '50000000',
                timeout: '600',
                minSpaceAvailable: '50000000',
                service: 'com.apple.assetsd.cacheDelete',
                appName:  'Photos',
                views: ['General', 'iPhone Storage'],
                dirPath: '/var/mobile/Media/PhotoData/',
                iCloudLogout: false,
            },
            repeat: 100,
            dirPathForMKFile: '/tmp/cachedeletefiles/',
            dirPathForDiskSpace: '/private/var',
            fileSizeMB: 50,
        });

    var resultDict = {}
    var purgeableSpaceLeftInMB = '';
    for (var i=1; i <= args.repeat; i++) {
        UIALogger.logMessage('CYCLE #%0'.format(i));
        cacheDeleteApp.printResultDict(resultDict, i-1);
        try {
            //Create Purgeable data
            CacheDeleteTests.installAssetDownloaderApp(args.hlsArgs);

            CacheDeleteTests.generatePurgeableHLSData(args.hlsArgs);

            CacheDeleteTests.generatePhotosData(args.photosArgs);

            // Check if purgeable space was created
            cacheDeleteApp.cacheDeletePurgeableSpaceAvailable({
                    timeout: args.hlsArgs.timeout,
                    space: args.hlsArgs.minSpaceAvailable,
                    service: args.hlsArgs.service,
                });

            cacheDeleteApp.cacheDeletePurgeableSpaceAvailable({
                    timeout: args.photosArgs.timeout,
                    space: args.photosArgs.minSpaceAvailable,
                    service: args.photosArgs.service,
                });

            //Fill up disk with mkfile data and verify the cycle passes
            purgeableSpaceLeftInMB = cacheDeleteApp.fillUpDisk(
                args.dirPathForDiskSpace, args.dirPathForMKFile, args.fileSizeMB
                );

            //Delete files created by mkfile, to restart the test
            cacheDeleteApp.deleteTmpFiles(args.dirPathForMKFile);
        }  catch(e) {
            //Delete files created by mkfile, to restart the test
            cacheDeleteApp.deleteTmpFiles(args.dirPathForMKFile);
            UIALogger.logMessage('Exception: %0'.format(e.message));
            resultDict['Cycle%0:'.format(i)] = 'Fail: %0'.format(e.message);
            continue;
        }
        resultDict['Cycle%0:'.format(i)] = 'Passed. Purgeable Space Left at the end: %0'.format(purgeableSpaceLeftInMB);
    }

    cacheDeleteApp.printResultDict(resultDict, args.repeat);
    },
};