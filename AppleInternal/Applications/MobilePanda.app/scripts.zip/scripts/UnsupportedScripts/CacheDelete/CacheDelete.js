load('SpringBoard.js');
load('Settings.js');

UIAUtilities.assert(
    typeof CacheDeleteApp === 'undefined',
    'CacheDelete has already been defined.'
);

/**
    @namespace
    @augments UIAApp
*/

var cacheDeleteApp = {}

UIAQuery.CacheDeleteApp = {
    
    /** 'Sign in to iCloud' table cell */
    ICLOUD_TABLE_CELL: 
        UIAQuery.tableCells().andThen(UIAQuery.beginsWith('Sign in to your iP'))
            .orElse(UIAQuery.staticTexts('Apple ID, iCloud, iTunes & App Store')),
    
    /** 'Download and keep original' table cell */
    DOWNLOAD_ORIGINAL_TABLE_CELL: 
        UIAQuery.tableCells().andThen(UIAQuery.beginsWith('Download and Keep Originals')),
    
    /** 'optimize storage space' table cell */
    OPTIMIZED_STORAGE_TABLE_CELL: 
        UIAQuery.tableCells().andThen(UIAQuery.beginsWith('Optimize iPhone Storage')),
}

/**
 * Utility function to convert size bytes to KB, MB or GB
 *
 * @param {string} size - Size in bytes
 *
 * Returns: {string} Size converted in KB, MB or GB
 */
cacheDeleteApp._bytesToSize = function(bytes){
    UIALogger.logMessage('Converting %0 bytes to KB, MB or GB'.format(bytes));
    var sizes = ['bytes', 'KB', 'MB', 'GB'];
    if (bytes == 0) return 'Zero KB';
    var i = parseFloat(Math.floor(Math.log(bytes) / Math.log(1000)));
    if (i == 0) { return (bytes / Math.pow(1000, i)) + ' ' + sizes[i]; }
    bytesInSize = (bytes / Math.pow(1000, i)).toFixed(1) + ' ' + sizes[i];
    UIALogger.logMessage('%0 bytes -> %1'.format(bytes, bytesInSize));
    return bytesInSize;
}

cacheDeleteApp._bytesToMB = function(bytes) {
    bytesInMB = parseInt(bytes / Math.pow(1000, 2));
    UIALogger.logMessage('%0 bytes -> %1 MB'.format(bytes, bytesInMB));
    return bytesInMB;
}

/**
 * Utility function to convert size in KB, MB or GB to bytes
 *
 * @param {string} size - Size in KB, MB or GB
 *
 * Returns: {string} Size converted in bytes
 */
cacheDeleteApp._sizeToBytes = function(size){
    var splitSize = size.split(' ');

    switch(splitSize[1]) {
        case 'KB':
            if (!isNaN(splitSize[0])){
                sizeInBytes = parseFloat(splitSize[0]) * 1000;
                break;
            } else {
                sizeInBytes = 0;
            }
        case 'MB':
            if (!isNaN(splitSize[0])){
                sizeInBytes = parseFloat(splitSize[0]) * Math.pow(1000, 2);
                break;
            } else {
                sizeInBytes = 0;
            }
        case 'GB':
            if (!isNaN(splitSize[0])){
                sizeInBytes = parseFloat(splitSize[0]) * Math.pow(1000, 3);
                break;
            } else {
                sizeInBytes = 0;
            }
        default:
            new UIAError('_sizeToBytes got a wrong case to process');
    }

    UIALogger.logMessage('Size to Bytes: %0 -> %1'.format(size, sizeInBytes));
    return sizeInBytes;
}

/**
 * Returns the result of CacheDeleteTest -i in form of a dictionary
 *
 * @param None
 *
 * Returns: {object} Dictionary with result of CacheDeleteTest -i in the form 
 *          of <service name> = purgeable space in bytes
 */
cacheDeleteApp.getCacheDeleteCLIData = function(){
    // For some reason the result is given out in stderr.
    UIALogger.logMessage('Querying CacheDelete CLI data...');
    var commandResult = target.performTask('/usr/local/bin/CacheDeleteTest', ['-i']).stderr;

    UIALogger.logMessage(commandResult);
    var splitCommandResultByOpeningBrace = commandResult.split('{')[1];
    var splitCommandResultByClosingBrace = splitCommandResultByOpeningBrace.split('}')[0];
    var splitCommandResultBySemiColon = splitCommandResultByClosingBrace.split(';');
    splitCommandResultBySemiColon.splice(-1,1);
    var returnDict = {};

    for (var index in splitCommandResultBySemiColon) {
        if (splitCommandResultBySemiColon[index] != undefined) {
            var splitCommandResultByEqualSign = splitCommandResultBySemiColon[index].split('=');
            purgeableSize = splitCommandResultByEqualSign[1];
            if (purgeableSize != 'NaN undefined'){
                returnDict[splitCommandResultByEqualSign[0].split('"').join('').trim()] = purgeableSize;
            }
        }
    }
    return returnDict;
}

/**
 * This method will delete purgaeable space using the CLI tool
 *
 * @param {object} options - argument dictionary
 * @param {string} options.memory - amount of memory to delete in bytes
 * @param {string} options.service - service identifier to delete memory
 *
 * Returns: {object} Result of CacheDeleteTest -d <memory to release> -n <service> in form of dict
 *          Details about result dict in processPurgeQueryResult method doc string
 */
cacheDeleteApp.cacheDeleteReleaseMemory = function (options) {
    var commandResult = target.performTask(
        '/usr/local/bin/CacheDeleteTest', ['-d', options.memory, '-n', options.service], 10
        );

    UIALogger.logMessage('Purge Query (stdout): %0'.format(commandResult.stdout));
    UIALogger.logMessage('Purge Query (stderr): %0'.format(commandResult.stderr));

    var processedPurgeQueryResult = this.processPurgeQueryResult(commandResult.stderr);
    return processedPurgeQueryResult;
}

/**
 * This method will keep checking for purgeable available space using the CLI tool
 *
 * @param {object} options - argument dictionary
 * @param {string} options.timeout - max amount of time to keep checking in seconds
 * @param {string} options.space -  amount of purgeable available space desired in bytes
 * @param {string} options.service - service identifier to check for available space
 *
 * Returns {object} Returns a dictionary with result from CacheDeleteTest -i
 *                  See docstring for getCacheDeleteCLIData for more info
 */
cacheDeleteApp.cacheDeletePurgeableSpaceAvailable = function(options) {
    time = 0;
    var start = new Date().getTime();
    
    while (time<options.timeout){
        cliResultDict = this.getCacheDeleteCLIData();
        UIALogger.logMessage('The purgeable space is '+cliResultDict[options.service]+'\n');
        UIALogger.logMessage('The purgeable space we are waiting for is '+options.space+'\n');
    
        if (parseFloat(cliResultDict[options.service])>parseFloat(options.space)){
            UIALogger.logMessage("Required purgeable size is met"+cliResultDict[options.service]);
            var end = new Date().getTime();
            var recordTime = end - start;
            var recordTimeSec = recordTime/1000;
            UIALogger.logMessage('Successful Execution time: ' + recordTimeSec+' seconds');
            return cliResultDict
        } else{
            target.delay(1);
            time=time+1;
            UIALogger.logMessage(
                "Waiting for purgeable available space for %0. New time %1".format(
                    options.service, time));
        }
    }
    
    throw new UIAError(
        "Available purgeable space never returned. Timed out after "+options.timeout+' seconds'
        );
}

/**
 * This method will validate purgaeable space was deleted using the CLI tool
 *
 * @param {object} options - argument dictionary
 * @param {string} options.memory - amount of memory to delete in bytes
 * @param {string} options.service - service identifier to delete memory
 *
 * Returns: {object} Result of CacheDeleteTest -d <memory to release> -n <service> in form of dict
 *          Details about result dict in processPurgeQueryResult method doc string
 */
cacheDeleteApp.cacheDeleteVerification = function(options) {
    cliResultDictBefore = this.getCacheDeleteCLIData();
    releaseMemoryResultDict = this.cacheDeleteReleaseMemory(options);
    target.delay(8);
    cliResultDictAfter = this.getCacheDeleteCLIData();
    
    UIALogger.logMessage(
        "Cached data available before deletion"+cliResultDictBefore[options.service]
        );
    UIALogger.logMessage(
        "Cached data available after deletion"+cliResultDictAfter[options.service]
        );
    
    cacheDeleted = parseFloat(cliResultDictBefore[options.service]) - 
                   parseFloat(cliResultDictAfter[options.service]);
    
    if(cacheDeleted < options.memory){
        throw new UIAError(
            "CacheDelete could not delete requested amount. Amount deleted: %0".format(
                cacheDeleted));
    } else {
        UIALogger.logMessage("%0 bytes were successfully deleted".format(cacheDeleted));
    }
    return releaseMemoryResultDict;
}

/**
 * This method will get the elements in the iPhone storage pane for given service
 *
 * @param {string} service - service identifier to delete memory
 *
 * Returns: A dictionary with following keys
 *              'appSize': Size of the app (Second tableCell)
 *              'dataSize': Size of data in the app (Third tableCell)
 *              'offloadAppElement': UIAQuery object for tableCell that Offloads the App
 *              'deleteAppElement': UIAQuery object for tableCell that Deletes the App
 *              'assetSizeArray': Array with all assetsTitles and assetSizes 
 *                                separated by a ':' Eg: ['Test:1 MB', 'Test1:2 MB']
 */
cacheDeleteApp.getServiceData = function(appName) {
    settings.tap(UIAQuery.tableCells().beginsWith(appName));

    if (!settings.exists(UIAQuery.navigationBars(appName))) {
        throw new UIAError('Not in %0 service pane'.format(appName));
    }
    
    var tableCells = UIAQuery.tableCells();
    var tableCellCount = settings.count(tableCells);
    
    UIALogger.logMessage('Number of tableCells: %0'.format(tableCellCount));

    var resultDict = {};
    var assetSizeArray = [];
    resultDict.tableCellCount = tableCellCount;

    //Working with the first three table cells. 
    //Replace with tableCellCount if need to parse all table cells comes up.
    for (var i = 1; i < tableCellCount; i++) {
        var tableCellLabel = settings.inspect(tableCells.atIndex(i)).label;
        switch(tableCellLabel) {
            case ('App Size'):
                UIALogger.logMessage('App Size: %0'.format(tableCellLabel));
                
                resultDict.appSize = this._sizeToBytes(
                    settings.inspect(
                        tableCells.atIndex(i).andThen(UIAQuery.staticTexts().last())
                    ).label);
                break;
            case ('Documents & Data'):
                UIALogger.logMessage(
                    'Size of Documents & Data: %0'.format(settings.inspect(
                        tableCells.atIndex(i).andThen(UIAQuery.staticTexts().last())).label
                    ));
                
                resultDict.dataSize = this._sizeToBytes(settings.inspect(
                    tableCells.atIndex(i).andThen(UIAQuery.staticTexts().last())).label
                    );
                break;
            case ('Photo Library'):
                UIALogger.logMessage('Photo Library: %0'.format(settings.inspect(
                        tableCells.atIndex(i).andThen(UIAQuery.staticTexts().last())).label
                    ));
                resultDict.photoLibrary = this._sizeToBytes(settings.inspect(
                    tableCells.atIndex(i).andThen(UIAQuery.staticTexts().last())).label
                    );
                break;
            // case ('Offload App'):
            //     UIALogger.logMessage('Offload App Element: %0'.format(
            //          tableCells.atIndex(i))
            //          );
            //     resultDict.offloadAppElement = tableCells.atIndex(i);
            //     break;
            // case ('Delete App'):
            //     UIALogger.logMessage('Delete App Element: %0'.format(
            //          tableCells.atIndex(i))
            //          );
            //     resultDict.deleteAppElement = tableCells.atIndex(i);
            //     break;
            // case ('Shared Photo Stream'):
            //     UIALogger.logMessage('Shared Photo Stream: %0'.format(
            //          tableCells.atIndex(i))
            //          );
            //     resultDict.sharedPhotoStream = tableCells.atIndex(i);
            //     break;
            // case (undefined):
            //     assetTitle = settings.inspect(
            //      tableCells.atIndex(i).andThen(UIAQuery.staticTexts('Title'))).label;
            //     assetSize = this._sizeToBytes(
            //          settings.inspect(tableCells.atIndex(i).andThen(
            //          UIAQuery.staticTexts('Size'))).label
            //          );
            //     UIALogger.logMessage('Asset Title: %0'.format(assetTitle));
            //     UIALogger.logMessage('Asset Size: %0'.format(assetSize))
            //     assetSizeArray.push(assetTitle + ':' + assetSize);
            //     break;
            default:
                UIALogger.logWarning('Unknown tableCell with label: %0'.format(tableCellLabel));
        }
    }

    resultDict.assetSizeArray = assetSizeArray;
    return resultDict;
}

/**
 * This method navigates to the service for which UI should be analyzed and calls 
 * the get service method.
 *
 * @param {object} options - argument dictionary
 * @param {object} options.views - array with path to iPhone Storage UI
 * @param {string} options.service - name of service to be analyzed
 *
 * Returns: A dictionary with following keys
 *              'appSize': Size of the app (Second tableCell)
 *              'dataSize': Size of data in the app (Third tableCell)
 *              'offloadAppElement': UIAQuery object for tableCell that Offloads the App
 *              'deleteAppElement': UIAQuery object for tableCell that Deletes the App
 *              'assetSizeArray': Array with all assetsTitles and assetSizes 
 *                                separated by a ':' Eg: ['Test:1 MB', 'Test1:2 MB']
 */
cacheDeleteApp.getCacheDeleteUIDataForService = function(options){
    if (!settings.navigateNavigationViews(options.views)) {
        throw new UIAError('Could not get to "iPhone Storage" view');
    }

    // Wait for appName to load
    serviceWaiter = UIAWaiter.waiter(options.appName);
    
    UIALogger.logMessage('Services Loaded');
    resultDict = this.getServiceData(options.appName);
    return resultDict;
}

/**
 * Utility function that processes the purge query result and returns all 
 * the data in form of a dictionary
 *
 * @targetApps SettingsApp
 *
 * @param {string} [queryString] - Result string returned by CacheDeleteTool
 *
 * Returns: A dictionary with following keys
 *              'CACHE_DELETE_AMOUNT_REPORTED': Total CacheDelete amount available
 *              'CACHE_DELETE_AMOUNT': Amount deleted
 *              'CACHE_DELETE_ELAPSED_TIME': Time taken by Cachedelete to purge requested space
 *              'CACHE_DELETE_FREESPACE_BEGIN': Free space before cachedelete was run
 *              'CACHE_DELETE_FREESPACE_END': Free space after cachedelete was run
 */
cacheDeleteApp.processPurgeQueryResult = function(queryString){
    splitNewLine = queryString.split('\n');
    var resultDict = {};
    
    for (var index in splitNewLine) {
        if(splitNewLine[index].includes('CACHE_DELETE_AMOUNT_REPORTED')){
            
            UIALogger.logMessage(
                'CACHE_DELETE_AMOUNT_REPORTED: %0)'.format(
                    splitNewLine[index].split('=')[1].trim()
                ));
            
            resultDict.CACHE_DELETE_AMOUNT_REPORTED = splitNewLine[index].split('=')[1].trim();
        } else if(splitNewLine[index].includes('CACHE_DELETE_AMOUNT')){
            
            UIALogger.logMessage(
                'CACHE_DELETE_AMOUNT: %0'.format(splitNewLine[index].split('=')[1].trim())
                );
            
            resultDict.CACHE_DELETE_AMOUNT = splitNewLine[index].split('=')[1].trim();
        } else if(splitNewLine[index].includes('CACHE_DELETE_ELAPSED_TIME')) {
            
            UIALogger.logMessage(
                'CACHE_DELETE_ELAPSED_TIME: %0'.format(
                    splitNewLine[index].split('=')[1].trim()
                    ));
            
            resultDict.CACHE_DELETE_ELAPSED_TIME = splitNewLine[index].split('=')[1].trim();
        } else if(splitNewLine[index].includes('CACHE_DELETE_FREESPACE_BEGIN')) {
            
            UIALogger.logMessage(
                'CACHE_DELETE_FREESPACE_BEGIN: %0'.format(
                    splitNewLine[index].split('=')[1].trim()
                    ));
            
            resultDict.CACHE_DELETE_FREESPACE_BEGIN = splitNewLine[index].split('=')[1].trim();
        } else if(splitNewLine[index].includes('CACHE_DELETE_FREESPACE_END')) {
            
            UIALogger.logMessage(
                'CACHE_DELETE_FREESPACE_END: %0'.format(
                    splitNewLine[index].split('=')[1].trim()
                    ));
            
            resultDict.CACHE_DELETE_FREESPACE_END = splitNewLine[index].split('=')[1].trim();
        }
    }
    return resultDict;
}

/**
 * Ask CacheDeleteTool for space for a service from Command Line
 *
 * @targetApps SettingsApp
 *
 * @param {object} options - Argument Dictionary
 * @param {string} [options.space] - Space to be requested
 * @param {string} [options.service] - Service from which space is to be requested
 *
 * Returns: A dictionary with following keys
 *              'CACHE_DELETE_AMOUNT_REPORTED': Total CacheDelete amount available
 *              'CACHE_DELETE_AMOUNT': Amount deleted
 *              'CACHE_DELETE_ELAPSED_TIME': Time taken by Cachedelete to purge requested space
 *              'CACHE_DELETE_FREESPACE_BEGIN': Free space before cachedelete was run
 *              'CACHE_DELETE_FREESPACE_END': Free space after cachedelete was run
 */
cacheDeleteApp.purgeCacheSpaceForService = function(options){
    UIALogger.logMessage('Purge %0 space from %1'.format(options.space, options.service));
    var purgeQueryResult = target.performTask(
        '/usr/local/bin/CacheDeleteTest', ['-d', options.space, '-n', options.service], 10
        );
    
    UIALogger.logMessage('Purge Query (stdout): %0'.format(purgeQueryResult.stdout));
    UIALogger.logMessage('Purge Query (stderr): %0'.format(purgeQueryResult.stderr));

    var processedPurgeQueryResult = this.processPurgeQueryResult(purgeQueryResult.stderr);
    return processedPurgeQueryResult;
}

/**
 * Utility to compare results from Settings UI before and after using CacheDeleteTool
 *
 * @targetApps SettingsApp
 *
 * @param {object} beforeDict - Dictionary with results from getCacheDeleteUIDataForService 
 *                              before using CacheDeleteTool
 * @param {object} afterDict - Dictionary with results from getCacheDeleteUIDataForService 
 *                             after using CacheDeleteTool
 * @param {string} requestedSpace - The space that was requested from CacheDeleteTool
 *
 * Returns {number} Difference between purgeable memory available before and after asking
 *                  memory from CacheDeleteTest
 */
cacheDeleteApp.compareUIResults = function(beforeDict, afterDict, requestedSpace, service){
    if (service == 'com.apple.assetsd.cacheDelete') {
        UIALogger.logMessage('UI for photos: Using photoLibrary instead of dataSize');
        purgedSpace = (beforeDict.photoLibrary - afterDict.photoLibrary);
        UIALogger.logMessage(
            'DataSize - before purge : %0 after purge : %1'.format(
                beforeDict.photoLibrary, afterDict.photoLibrary
        ));
    } else {
        UIALogger.logMessage('Not Photos UI: Using dataSize');
        purgedSpace = (beforeDict.dataSize - afterDict.dataSize);
        UIALogger.logMessage(
            'DataSize - before purge : %0 after purge : %1'.format(
                beforeDict.dataSize, afterDict.dataSize
        ));
    }

    UIALogger.logMessage('Requested Space: %0'.format(requestedSpace));
    UIALogger.logMessage('Amount Purged: %0'.format(purgedSpace));
    UIALogger.logMessage('Difference: %0'.format(purgedSpace - requestedSpace));
    
    UIAUtilities.assert(
        purgedSpace >= parseFloat(requestedSpace), 
        'UI: Could not free up requested amount of memory. PurgedSpace: %0'.format(purgedSpace)
        );
    
    UIALogger.logMessage('Atleast requested space made available');
    return purgedSpace;
}

/**
 * Utility to wait for iCloud data sync to complete. will be needed if waitForFileToExist
 * cannot do the job. 
 *
 * @param None
 *
 * Returns None
 */
cacheDeleteApp.waitForPhotoSync = function waitForPhotoSync() {
    cmd = "cplctl status | grep downloadQueue";
    var result = target.performTask('/bin/sh', ['-c', "%0".format(cmd)]);

    UIALogger.logMessage('stderr: %0'.format(result.stderr));
    UIALogger.logMessage('stdout: %0'.format(result.stdout));
}

/**
 * Utility to wait for iCloud data sync to complete. Waits for file 
 * '/var/mobile/Media/PhotoData/cpl_download_finished_marker' to be written to the disk.
 *
 * @param {object} args Test arguments
 * @param {string} [args.syncCompleteFilePath] - Path to 'cpl_download_finished_marker' 
 *                  - file that is written to disk when photo data sync is complete
 * @param {number} [syncTimeoutInMinutes] - Timeout for photo data sync
 *
 * Returns {bool} True when file exists. Throws UIAError if timeout reached
 */
cacheDeleteApp.waitForFileToExist = function waitForFileToExist(options) {
    UIAUtilities.assert(options.syncCompleteFilePath, 'Must specify filepath');

    if (!options.syncTimeoutInMinutes) {
        options.syncTimeoutInMinutes = 75;
    }

    var timeChecked = 0;
    while (timeChecked < options.syncTimeoutInMinutes && 
        !UIAFile.fileExists(options.syncCompleteFilePath)) {
        UIALogger.logMessage('Sync in progress after -> %0 minutes'.format(timeChecked));
        target.delay(60);
        timeChecked += 1;
    }

    if (!UIAFile.fileExists(options.syncCompleteFilePath)) {
        UIALogger.logMessage('Target file did not exist within timeout period');
    }
    return true;
}

/**
 * Utility to get space occupied by a directory on the disk using du command
 *
 * @param {string} [dirPath] - Path to the directory for which disk usage is 
 *                  to be reported
 *
 * Returns {number} number of bytes of memory occupied on the disk
 */
cacheDeleteApp.spaceOnDisk = function spaceOnDisk(dirPath) {
    UIAUtilities.assert(dirPath, 'Must specify directory path');

    UIALogger.logMessage('Checking disk space occupied by %0:'.format(dirPath));
    
    duResult = target.performTask('/usr/bin/du', ['-sxk', dirPath]);
    
    UIALogger.logMessage('stdout: %0'.format(duResult.stdout));
    UIALogger.logMessage('stderr: %0'.format(duResult.stderr));

    resultInBytes = parseFloat(duResult.stdout.split(' ')[0]) * 1000;
    UIALogger.logMessage(
        'Disk space occupied by %0 is %1 bytes'.format(dirPath, resultInBytes)
        );
    return resultInBytes;
}

/**
 * Utility to compare two disk space results given by spaceOnDisk()
 *
 * @param {number} [diskSpaceBefore] - disk space occupied before purge
 * @param {number} [diskSpaceAfter] - disk space occupied after purge
 * @param {number} [requestedSpace] - disk space requested to be purged
 *
 * Throws assertion error if requested amount of memory is not made available
 */
cacheDeleteApp.compareDiskSpaceResults = function compareDiskSpaceResults(diskSpaceBefore, 
                                                  diskSpaceAfter, requestedSpace) {
    purgedSpace = diskSpaceBefore - diskSpaceAfter;
    
    UIALogger.logMessage(
        'DiskSize - before purge : %0 after purge : %1'.format(diskSpaceBefore, diskSpaceAfter)
        );
    UIALogger.logMessage('Requested Space: %0'.format(requestedSpace));
    UIALogger.logMessage('Amount Purged: %0'.format(purgedSpace));
    UIALogger.logMessage('Difference: %0'.format(purgedSpace - requestedSpace));
    
    UIAUtilities.assert(
        purgedSpace >= requestedSpace, 
        'Could not free up requested amount of memory on Disk. PurgedSpace: %0'.format(purgedSpace)
        );
    
    UIALogger.logMessage('Atleast requested space made available');
}

/**
 * Method to select Download and Keep original option in iCloud Photos pane
 *
 * @param None
 *
 * Throws assertion error if cannot select Download and Keep Originals
 */
cacheDeleteApp.selectDownloadOriginalAndKeep = function selectDownloadOriginalAndKeep() {
    settings.navigateNavigationViews([{query: UIAQuery.CacheDeleteApp.ICLOUD_TABLE_CELL}]);

    if (settings.exists(UIAQuery.withPredicate("name BEGINSWITH 'Sign In'"))) {
        throw new UIAError(
            "Can't set Download and Keep Originals because we're not signed into iCloud!", 
            {identifier: 'Not signed into iCloud'}
            );
    }

    settings.navigateNavigationViews(
        [{query: UIAQuery.CacheDeleteApp.ICLOUD_TABLE_CELL}, 'iCloud', 'Photos']
        );

    if (!(settings.exists(UIAQuery.CacheDeleteApp.DOWNLOAD_ORIGINAL_TABLE_CELL))) {
        throw new UIAError(
            "Could not find the Download and Keep Originals tableCell", 
            {identifier: "Could not turn on Download and Keep Originals"}
            );
    }

    settings.tap(UIAQuery.CacheDeleteApp.DOWNLOAD_ORIGINAL_TABLE_CELL);
    settings.quit();
}

/**
 * Method to select Optimize iPhone Storage option in iCloud Photos pane
 *
 * @param None
 *
 * Throws assertion error if cannot select Optimize iPhone Storage
 */
cacheDeleteApp.selectOptimizeIphoneStorage = function selectOptimizeIphoneStorage() {
    settings.navigateNavigationViews([{query: UIAQuery.CacheDeleteApp.ICLOUD_TABLE_CELL}]);

    if (settings.exists(UIAQuery.withPredicate("name BEGINSWITH 'Sign In'"))) {
        throw new UIAError(
            "Can't set Optimize iPhone Storage because we're not signed into iCloud!", 
            {identifier: 'Not signed into iCloud'}
            );
    }

    settings.navigateNavigationViews(
        [{query: UIAQuery.CacheDeleteApp.ICLOUD_TABLE_CELL}, 'iCloud', 'Photos']
        );

    if (!(settings.exists(UIAQuery.CacheDeleteApp.OPTIMIZED_STORAGE_TABLE_CELL))) {
        throw new UIAError(
            "Could not find the Optimize iPhone Storage tableCell", 
            {identifier: "Could not turn on Optimize iPhone Storage"}
            );
    }

    settings.tap(UIAQuery.CacheDeleteApp.OPTIMIZED_STORAGE_TABLE_CELL);
    settings.quit();
}

/**
 * Utility function to generate a random number between 0 and 100
 *
 * @param None
 *
 * Returns {number} Random number between 0 and 100
 */
cacheDeleteApp.generateRandomNumber = function generateRandomNumber() {
    return Math.floor((Math.random()*100));
}

/**
 * Utility method to print the result dict after an iteration. The result is 
 * printed for each iteration
 *
 * @param {object} [resultDict] Result dict after an iteration
 * @param {number} [iteration] Iteration number
 */
cacheDeleteApp.printResultDict = function printResultDict(resultDict, iteration) {
    UIALogger.logMessage('Result Dict after iteration #%0'.format(iteration));
    
    for (var key in resultDict){
        UIALogger.logMessage(key +': ' + resultDict[key])
    }
}

/**
 * Utility method to find free space on disk for a given path
 *
 * @param {String} [dirPathForDiskSpace] Path to get free space for
 *
 * Return {Number} Free space at given path in MB
 */
cacheDeleteApp.spaceLeftOnDisk = function spaceLeftOnDisk(dirPathForDiskSpace) {
    UIAUtilities.assert(dirPathForDiskSpace, 'Must specify directory path');

    UIALogger.logMessage('Checking disk space left on path: %0:'.format(dirPathForDiskSpace));

    dfResult = target.performTask('/bin/df', ['-m', dirPathForDiskSpace]);

    UIALogger.logMessage('stdout: %0'.format(dfResult.stdout));
    UIALogger.logMessage('stderr: %0'.format(dfResult.stderr));

    resultInMB = dfResult.stdout.split('\n')[1].split(' ').filter(String)[3];

    UIALogger.logMessage(
        'Disk space free at %0 is %1 MB'.format(dirPathForDiskSpace, resultInMB)
        );
    return parseFloat(resultInMB);
}

/**
 * Utility method to that uses mkfile to write a file with given name and size to
 * given location
 *
 * @param {String} [dirPath] Path where to write file
 * @param {String} [fileName] Name of file to be written
 * @param {String} [fileSizeMB] Size of file to be written in MB
 *
 * Return {Bool} True if write operation was successful and vice versa
 */
cacheDeleteApp.writeFilesToDisk = function writeFilesToDisk(dirPath, fileName, fileSizeMB) {
    UIAUtilities.assert(dirPath, 'Must specify directory path');
    UIAUtilities.assert(fileName, 'Must specify file name');

    UIALogger.logMessage('Attempting to create file:%0 at:%1'.format(fileName, dirPath));

    mkFileResult = target.performTask(
        '/usr/sbin/mkfile', ['%0m'.format(fileSizeMB), '%0/%1'.format(dirPath, fileName)]
        );

    UIALogger.logMessage('stdout: %0'.format(mkFileResult.stdout));
    UIALogger.logMessage('stderr: %0'.format(mkFileResult.stderr));
    if (mkFileResult.stderr) {
        return false;
    }
    return true;
}

/**
 * Utility method to fill up disk space. File names are of form: file-<current time in seconds>
 *
 * @param {String} [dirPathForDiskSpace=/private/var/] Space left on device
 * @param {String} [dirPathForFileWrite] Path where temp files need to be written
 * @param {String} [fileSizeMB] Size of file to be written in MB
 *
 * Return {Number} [purgeableSpaceLeftInMB] At the end of write operation (when writing fails or
 *                      less than 150MB space is left on the disk), returns purgeable space left
 *
 * Throws UIAError if more than 200 MB reported by CacheDeleteTest tool but the write operation failed
 */
cacheDeleteApp.fillUpDisk = function fillUpDisk(dirPathForDiskSpace, dirPathForFileWrite, fileSizeMB) {
    if (UIAFile.fileExists(dirPathForFileWrite)) {
        UIALogger.logMessage('Target dir exists');
    } else {
        target.performTask('/bin/mkdir', [dirPathForFileWrite]);
    }

    while(this.spaceLeftOnDisk(dirPathForDiskSpace) > 150) {
        currentTime = new Date().getTime()/1000;
        fileName = 'file-%0'.format(parseInt(currentTime));
        if (!this.writeFilesToDisk(dirPathForFileWrite, fileName, fileSizeMB)) {
            break;
        }
    }

    cliResultDict = this.getCacheDeleteCLIData();
    purgeableSpaceLeftInMB = this._bytesToMB(cliResultDict.CACHE_DELETE_TOTAL_AVAILABLE);
    UIALogger.logMessage('Purgeable Space Left: %0 MB'.format(purgeableSpaceLeftInMB));
    if (purgeableSpaceLeftInMB > 200) {
        UIALogger.logMessage();
        throw new UIAError(
            "More than 200 MB reported by CacheDeleteTest tool but the write operation failed",
            {identifier: 'CacheDelete could not free up space and more than 200MB purgeable space available'}
            );
    }
    return purgeableSpaceLeftInMB;
}

/**
 * Utility method to delete temporary files that were created by fillUpDisk()
 *
 * @param {String} [dirPath] Path where temporary files are stored
 *
 * Return None
 */
cacheDeleteApp.deleteTmpFiles = function deleteTmpFiles(dirPath) {
    UIAUtilities.assert(dirPath, 'Must specify directory path');

    UIALogger.logMessage('Attempting to delete all files of form file* from /tmp');

    rmFileResult = target.performTask('/bin/rm', ['-r', dirPath]);

    UIALogger.logMessage('stdout: %0'.format(rmFileResult.stdout));
    UIALogger.logMessage('stderr: %0'.format(rmFileResult.stderr));
}