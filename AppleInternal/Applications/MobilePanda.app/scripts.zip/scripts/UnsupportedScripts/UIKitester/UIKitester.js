load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof uikitester === 'undefined',
    'uikitester has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common UIKitester queries */
UIAQuery.UIKitester = {
    
    /** Visible navigation bars. */
    VISIBLE_NAV_BARS: UIAQuery.navigationBars().isVisible().onScreen('CarPlay'),

    /** Done buttons. */
    DONE_NAV_BUTTON: UIAQuery.navigationBars().isVisible().onScreen('CarPlay').andThen(UIAQuery.buttons('Done')),

    /** Cancel Buttons. */
    CANCEL_NAV_BUTTON: UIAQuery.navigationBars().onScreen('CarPlay').isVisible().andThen(UIAQuery.buttons('Cancel')),

    /** Back Button. */

    /// FIXME: this is tapping the Tap-to-Radar button in Stark
    BACK_NAV_BUTTON: UIAQuery.navigationBars().onScreen('CarPlay').andThen(UIAQuery.buttons().atIndex(0)),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */ 
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to UIKitester */
UIStateDescription.UIKitester = {
    /** Home State - at the root menu */
    HOME:                  'UIKitester',

    /** Container VC State */
    CONTAINERS:            'Container View Controllers',

    /** Controls State */
    CONTROLS:              'Controls',

    /** UITableView State */
    UITABLEVIEW:           'UITableView',

    /** UICollectionView State */
    UICOLLECTIONVIEW:      'UICollectionView',

    /** UIAlertController State */
    UIALERTCONTROLLER:     'UIAlertController',

    /** Text Input State */
    TEXTINPUT:             'Text Input',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 *  Constants for possible states
 *
 *  @namespace
 */
// States = {

// /**  active */
//     ACTIVE: "Active",

// /**  unknown */
//     UNKNOWN: "Unknown",
// };

Labels = {};

/**
 * @namespace {UIAApp} uikitester
 */
var uikitester = target.appWithBundleID('com.apple.UIKitester');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and UIKitester for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
uikitester.currentUIState = function currentUIState() {

    // TODO: THIS SHOULD BE A ASSERT
    // UIKitester, on Stark, does not display a nav bar at its root menu. All other menus display a nav bar.
    var navBarCount = this.count(UIAQuery.UIKitester.VISIBLE_NAV_BARS);

    if (navBarCount > 1) {
        throw new UIAError('Unexpected number of navigation bars. Cannot determine UI state.');
    }

    if (navBarCount == 0) {
        return UIStateDescription.UIKitester.HOME;
    }

    var navigationBarInfo = this.inspect(UIAQuery.UIKitester.VISIBLE_NAV_BARS);

    if (navigationBarInfo === undefined) {
        return UIStateDescription.UIKitester.HOME;
    }

    return navigationBarInfo.identifier;
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets to a specified view in the UIKitester application.
 * 'viewName' should be a string with optional period-separated keys that match UIKitester's tree hierarchy.
 *
 * For example, "Container View Controllers.Tab Bar Controller"
 * will first navigate to the root menu, then tap the 'Container View Controllers'
 * cell, then the 'Tab Bar Controller' cell.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} viewName - Name of view/UI state.
 *
 * @returns none
 */
uikitester.getToViewPath = function getToViewPath(viewPath) {
    this.launch();

    var keys = viewPath.split('.');
    var lastKey = keys[keys.length - 1];
    var currentState = this.currentUIState();

    if (currentState === viewPath || currentState === lastKey) {
        return;
    }

    // UIKitester, on Stark, does not display a nav bar at its root menu. All other menus display a nav bar.
    var navBarCount = this.count(UIAQuery.UIKitester.VISIBLE_NAV_BARS);

    // Back out to the root, then select the requested item
    while (this.currentUIState() !== UIStateDescription.UIKitester.HOME) {
        this.delay(1);
        this.tap(UIAQuery.UIKitester.BACK_NAV_BUTTON);
    }
    
    if (viewPath === UIStateDescription.UIKitester.HOME) {
        return;
    }

    for (var i = 0; i < keys.length; i++) {
        this.delay(1);
        // We grab the parent element here to work around an issue with table cells in CarPlay:
        // <rdar://problem/25302446> [UIA2 + CarPlay] Enable scrollToVisible() for table cells
        this.scrollToVisible(UIAQuery.staticTexts(keys[i]).parent().onScreen('CarPlay'));
        this.tap(UIAQuery.staticTexts(keys[i]).isVisible().onScreen('CarPlay'));
    }
}

