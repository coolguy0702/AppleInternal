load('UIATesting.js');
load('UIKitester.js'); // load the library file

UIAUtilities.assert(
    typeof UIKitesterTests === 'undefined', 
    'UIKitesterTests has already been defined.'
);

/**
 * @namespace UIKitesterTests
 */
var UIKitesterTests = {

    /**
      * Scrolls up and down the main menu.
      *
      * @targetApps UIKitester
      * @overrideID Navigate Main Menu
      *
      * @param {object} args - Test arguments
      */
    navigateMainMenu: function navigateMainMenu(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.HOME);

        for (var i = 0; i < 2; i++) {
            uikitester.dragUpInside(UIAQuery.tableViews().isVisible().onScreen('CarPlay'));
        }

        for (var i = 0; i < 2; i++) {
            uikitester.dragDownInside(UIAQuery.tableViews().isVisible().onScreen('CarPlay'));
        }
    },

    /**
      * Scrolls the main menu using knob input.
      *
      * @targetApps UIKitester
      * @overrideID Knob Main Menu
      *
      * @param {object} args - Test arguments
      */
    knobMainMenu: function knobMainMenu(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.HOME);

        var knob = target.knob();

        var controls = UIAQuery.staticTexts('Controls').onScreen('CarPlay');

        // <rdar://problem/16062951> [UIA2 + CarPlay] UIAutomation needs to simulate Stark wheel events
        for (var i = 0; i < 3; i++) {
            knob.rotate(1);
        }

        for (var i = 0; i < 3; i++) {
            knob.rotate(-1);
        }
    },

    /**
      * Knobs to the home button, presses it, then relaunches the app again.
      *
      * @targetApps UIKitester
      * @overrideID Knob Home Button
      *
      * @param {object} args - Test arguments
      */
    knobHomeButton: function knobHomeButton(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.HOME);

        var knob = target.knob();

        // The delays here are not necessary for the test to pass,
        // they are solely for a human observer to be able to
        // gauge the effectiveness of animations and the focus engine.

        // <rdar://problem/16062951> [UIA2 + CarPlay] UIAutomation needs to simulate Stark wheel events
        target.delay(1);
        knob.rotate(-1);
        knob.rotate(-1);
        knob.rotate(-1); // Should reach Home Button
        target.delay(1);
        knob.pressSelect();
        target.delay(3);
        uikitester.launch();
        target.delay(1);
    },

    /**
      * Knobs into the tab bar controller, knobs around some tabs,
      * then knobs back out again.
      *
      * @targetApps UIKitester
      * @overrideID Knob Tab Bar
      *
      * @param {object} args - Test arguments
      */
    knobTabBar: function knobTabBar(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.HOME);

        var knob = target.knob();

        // The delays here are not necessary for the test to pass,
        // they are solely for a human observer to be able to
        // gauge the effectiveness of animations and the focus engine.

        // <rdar://problem/16062951> [UIA2 + CarPlay] UIAutomation needs to simulate Stark wheel events
        knob.rotate(1);
        knob.rotate(1); // 'Container View Controllers'
        knob.pressSelect();
        knob.rotate(1);
        knob.rotate(1);
        knob.rotate(1);
        knob.rotate(1); // 'Tab Bar Controller'
        knob.pressSelect();
        target.delay(1);
        knob.rotate(-1);
        knob.rotate(-1); // Back
        knob.pressSelect();
        target.delay(1);
        knob.rotate(-1);
        knob.rotate(-1);
        knob.rotate(-1);
        knob.rotate(-1); // Back
        knob.pressSelect();
        target.delay(1);
        knob.rotate(-1);
        knob.rotate(-1);
    },

    /**
      * A simple tab bar controller test. Navigates to the tab bar controller
      * and verifies that every tab is selectable.
      *
      * @targetApps UIKitester
      *
      * @param {object} args - Test arguments
      * @param {int} [args.tabCount=5] - Optional number of tabs to expect and navigate to in the tab bar
      */
    navigateTabBarController: function navigateTabBarController(args) {
        args = UIAUtilities.defaults(args, {
            tabCount: 5,            
        });

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTAINERS + ".Tab Bar Controller");

        UIAUtilities.assert(
            uikitester.count(UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons())) === args.tabCount,
            "Expected to see "+ args.tabCount +" tabs here."
        );

        for (var i = 0; i < args.tabCount; i++) {
            uikitester.tap(UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons().atIndex(i)));
        }

        for (var i = args.tabCount - 1; i >= 0; i--) {
            uikitester.tap(UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons().atIndex(i)));
        }
    },

    /**
      * A simple page view controller test. Navigates to the page view controller
      * and swipes between its contained view controllers.
      *
      * @targetApps UIKitester
      *
      * @param {object} args - Test arguments
      * @param {int} [args.swipeCount=1] - Optional number of swipes to perform in the page controller
      */
    navigatePageViewController: function navigatePageViewController(args) {
        args = UIAUtilities.defaults(args, {
            swipeCount: 1,            
        });

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTAINERS + ".Page View Controller");

        var scrollView = UIAQuery.scrollViews().isVisible().onScreen('CarPlay');

        for (var i = 0; i < args.swipeCount; i++) {
            uikitester.swipeLeft(scrollView);
        }

        for (var i = 0; i < args.swipeCount; i++) {
            uikitester.swipeRight(scrollView);
        }
    },

    /**
      * Navigates to the UIButton control page and taps every button therein.
      *
      * @targetApps UIKitester
      * @overrideID Press UIButtons
      *
      * @param {object} args - Test arguments
      */
    pressUIButtons: function pressUIButtons(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTROLS + ".Buttons");

        var buttons = UIAQuery.buttons().isVisible().onScreen('CarPlay');
        var buttonCount = uikitester.count(buttons);

        for (var i = 0; i < buttonCount; i++) {
            uikitester.tap(buttons.atIndex(i));
        }
    },
    
    /**
      * Navigates to the UIStepper control page and steps on it!
      *
      * @targetApps UIKitester
      * @overrideID Press Stepper
      *
      * @param {object} args - Test arguments
      */
    pressStepper: function pressStepper(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTROLS + ".Stepper");

        var buttons = UIAQuery.segmentedControls().isVisible().onScreen('CarPlay');
        var buttonCount = uikitester.count(buttons);

        for (var i = 0; i < buttonCount; i++) {
            uikitester.tap(buttons.atIndex(i));
        }
    },

    /**
      * Navigates to the UIPageControl control page.
      *
      * @targetApps UIKitester
      * @overrideID Visit UIPageControl
      *
      * @param {object} args - Test arguments
      */
    visitPageControl: function visitPageControl(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTROLS + ".Page Control");

        uikitester.waitUntilPresent(UIAQuery.pageIndicators().isVisible().onScreen('CarPlay'));
    },

    /**
      * Navigates to the UISegmentedControl control page and taps every segment therein.
      *
      * @targetApps UIKitester
      * @overrideID Press UISegmentedControl
      *
      * @param {object} args - Test arguments
      */
    pressSegmentedControl: function pressSegmentedControl(args) {
        args = UIAUtilities.defaults(args, {});

        uikitester.getToViewPath(UIStateDescription.UIKitester.CONTROLS + ".Segmented Control");

        var control = UIAQuery.segmentedControls().isVisible().onScreen('CarPlay');
        var buttons = control.andThen(UIAQuery.buttons());
        var buttonCount = uikitester.count(buttons);

        uikitester.tap(control.andThen(UIAQuery.buttons('One')));
        uikitester.tap(control.andThen(UIAQuery.buttons('Two')));
        uikitester.tap(control.andThen(UIAQuery.buttons('Three')));

        // When we finish enumerating buttons, the last segment should be selected
        uikitester.waitUntilPresent(UIAQuery.segmentedControls().isVisible().onScreen('CarPlay').andThen(UIAQuery.buttons('Three').isSelected()), 5);
    },

    /**
      * Navigates to the Text input control page and types a bunch of text!
      *
      * @targetApps UIKitester
      *
      * @param {object} args - Test arguments
      * @param {string} [args.testString="Hello UIKitester"] Optional text to type into each text field
      */
    testTextInput: function testTextInput(args) {
        args = UIAUtilities.defaults(args, {
            testString: "Hello UIKitester",
        });

        uikitester.getToViewPath(UIStateDescription.UIKitester.TEXTINPUT + ".Table and Search");

        // Search bar
        var element = UIAQuery.searchBars().isVisible().onScreen('CarPlay');

        uikitester.tap(element);
        uikitester.typeString(args.testString);

        // Text field
        element = UIAQuery.textFields().isVisible().onScreen('CarPlay');
        uikitester.tap(element);
        uikitester.typeString(args.testString);

        // Text View
        element = UIAQuery.textViews().isVisible().onScreen('CarPlay');
        uikitester.tap(element);
        uikitester.typeString(args.testString);
    },
}
