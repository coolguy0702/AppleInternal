load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAUtility.js');


UIAUtilities.assert(
    typeof oset === 'undefined',
    'Keyboard has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.Oset = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Predictive */
UIStateDescription.Oset = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/
var target = UIATarget.localTarget();



/**
 * @namespace {UIAApp} Keyboard
 */
 // LIKELY NOT NEEDED Predictive
//var safari = target.appWithBundleID('com.apple.mobilesafari');

var oset = target.appWithBundleID('com.apple.mobilenotes');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/*
 */

oset.osetpredictiveString = function predictiveString(expected){

    //Creates pcell array from collection view
    var pcellArray = [];
    for ( var i = 0; i<3; i++){
         var pcell = notes.inspect(UIAQuery.collectionViews().children().atIndex(i)).label
         
         if ( typeof pcell != 'undefined' ) {
            var pcellSplit = pcell.split(",");
            pcellArray.push(pcellSplit[0]);  
         }
    }
    
    UIALogger.logMessage("This is what the number is " + pcellArray.indexOf(expected));

   if(pcellArray.indexOf(expected) != -1){
       target.activeApp().tap(expected);
    } else {
      throw new Error('No canidate for ' + expected + ' available candiates ' + pcellArray);
    }  
}

