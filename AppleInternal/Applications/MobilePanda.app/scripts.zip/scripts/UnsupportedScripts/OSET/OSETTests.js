load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('UIAUtility.js');
load('OSET.js');

UIAUtilities.assert(
    typeof OSETTests === 'undefined', 
    'OSETTests has already been defined.'
);

/**
 * @namespace PredictiveTypingTests
 */
var OSETTests = {
  /**
   * OSET Test for Quicklook
   *
   * @targetApps MobileTimer
   *
   * @param {object} args - Test arguments
   */

  AddKeyboard: function AddKeyboard (args){
      args = UIAUtilities.defaults(args, {
            navigationViews: ["General", "Auto-Lock"],
            checkItem: "Never",
            validate: true,
        });

        var languages= ['English',
                        'Japanese',
                        'Japanese']; 
        var types = ['',
                     'Kana',
                     'Romaji'];

        var keyboards= ['en_US@hw=US;sw=QWERTY',
                        'ja_JP-Kana@sw=Kana;hw=US',
                        'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US'];

      /* add keyboards */

      for (var i = 0; i < languages.length; i++) {
         settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
      }

          UIALogger.logMessage('Japanese Keyboards are added');

  },//SettingsAddKeyboards

 /**
   * Japanese Kana Keyboard Test for Quicklook
   *
   * @targetApps MobileTimer
   *
   * @param {object} args - Test arguments
   */

   JapaneseKana: function JapaneseKana (args){

    var japaneseKanaKey1 = "た";
    var japaneseKanaKey1Verify = "と";
    var jkey1 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey1))


    var japaneseKanaKey2 = "あ";
    var japaneseKanaKey2Verify = "とう";
    var jkey2 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey2))


    var japaneseKanaKey3 = "か";
    var japaneseKanaKey3Verify = "とうき";
    var jkey3 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey3))


    var japaneseKanaKey4 = "や";
    var japaneseKanaKey4Verify = "とうきよ";
    var jkey4 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey4))


    var japaneseKanaKey5 = "゛";
    var japaneseKanaKey5Verify = "とうきょ";
    var jkey5 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey5))

    var japaneseKanaKey6 = "あ";
    var japaneseKanaKey6Verify = "とうきょう";
    var jkey6 = UIAQuery.keyboard().andThen(UIAQuery.keys(japaneseKanaKey6))

    var japaneseKanaCandidate = "東京";



    var languages= ['English',
                    'Japanese',
                    'Japanese']; 

    var keyboards= ['en_US@hw=US;sw=QWERTY',
                    'ja_JP-Kana@sw=Kana;hw=US',
                    'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US'];

    args = UIAUtilities.defaults(args, {
        title: '',
        body: '',
        folder: 'Notes',
        leaveOpenForEditing: true,
      });

      notes.createNote(
        ['',''],
        args
      );  

    //Switching Keyboards
      for (var i = 0; i < languages.length; i++) {
           var keyboardID = target.activeApp().getKeyboardID();
           UIALogger.logMessage('keyboardID ' + keyboardID);

          while (keyboards[i] != keyboardID) {
              target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
              keyboardID = target.activeApp().getKeyboardID()
           } //while

         switch (keyboards[i]) {
           
           case 'ja_JP-Kana@sw=Kana;hw=US': 

// Tap ‘た’ key 5 times => Verify ‘と’ as highlighted text in Notes.
              target.activeApp().tap(jkey1,{tapCount: 5});              
              var Kana1 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana1 = Kana1.localeCompare(japaneseKanaKey1Verify);
              if( compareKana1 == 0){
                  UIALogger.logPass(" Tap ‘た’ key 5 times -> Verify ‘と’.");
              }else{
                throw new Error('Japanese Kana String 1 verify failed.');
              }

// Tap ‘あ’ key 3 times  => Verify ‘う' as following above.
              target.activeApp().tap(jkey2,{tapCount: 3});              
              var Kana2 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana2 = Kana2.localeCompare(japaneseKanaKey2Verify);
              if( compareKana2 == 0){
                  UIALogger.logPass(" Tap ‘あ’ key 3 times -> Verify ‘う'.");
              }else{
                throw new Error('Japanese Kana String 2 verify failed.');
              }

// Tap ‘か’ key 2 times => Verify ‘き' as following above.
              target.activeApp().tap(jkey3,{tapCount: 2});              
              var Kana3 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana3 = Kana3.localeCompare(japaneseKanaKey3Verify);
              if( compareKana3 == 0){
                  UIALogger.logPass(" Tap ‘か’ key 2 times  -> Verify ‘き'.");
              }else{
                throw new Error('Japanese Kana String 3 verify failed.');
              }
// Tap ‘や’ key 3 times => Verify ‘よ’ as following above.
              target.activeApp().tap(jkey4,{tapCount: 3});              
              var Kana4 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana4 = Kana4.localeCompare(japaneseKanaKey4Verify);
              if( compareKana4 == 0){
                  UIALogger.logPass("Tap ‘や’ key 3 times => Verify ‘よ’.");
              }else{
                throw new Error('Japanese Kana String 4 verify failed.');
              }

// Tap ‘小’ key once => Verify ‘ょ’ replacing above ‘よ'
              target.activeApp().tap(jkey5); 
              var Kana5 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana5 = Kana4.localeCompare(japaneseKanaKey4Verify);
              if( compareKana5 == 0){
                  UIALogger.logPass("Tap ‘小’ key once => Verify ‘ょ’ replacing above ‘よ'.");
              }else{
                throw new Error('Japanese Kana String 5 verify failed.');
              }             

// Tap ‘あ’ key 3 times  => Verify ‘う' as following above.
              target.activeApp().tap(jkey6,{tapCount: 3});              
              var Kana6 = notes.inspect(UIAQuery.textViews()).value.trim()
              var compareKana6 = Kana4.localeCompare(japaneseKanaKey4Verify);
              if( compareKana6 == 0){
                  UIALogger.logPass("Tap ‘あ’ key 3 times  => Verify ‘う' as following above.");
              }else{
                throw new Error('Japanese Kana String 6 verify failed.');
              }             

// Tap the candidate ‘東京’
              oset.osetpredictiveString(japaneseKanaCandidate);

// Verify ‘東京’ is entered.
              var KanaCandidate = (notes.getNoteTextContent()).trim()
              var compareKanaCandidate = japaneseKanaCandidate.localeCompare(KanaCandidate)
              if( compareKanaCandidate == 0){
                UIALogger.logPass("Tapped ‘東京’and verified ‘東京’ is entered.");
              }else{
                //UIALogger.logPass("Log:Kana Candidate"+KanaCandidate+"JapaneseCandidate"+japaneseKanaCandidate);
                throw new Error('Japanese Kana Candidate: '+ KanaCandidate);
              }
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
   
              break; 
            }//switch
        }//for
   },// Kana

  /**
   * Japanese Romaji Keyboard Test for Quicklook
   *
   * @targetApps MobileTimer
   *
   * @param {object} args - Test arguments
   */

  JapaneseRomaji: function JapaneseRomaji (args){

    var japaneseRomajiString = "toukyou";
    var japaneseRomajiExpected = "とうきょう";
    var japaneseRomajiCandidate = "東京";

    var languages= ['English',
                    'Japanese',
                    'Japanese']; 

    var keyboards= ['en_US@hw=US;sw=QWERTY',
                    'ja_JP-Kana@sw=Kana;hw=US',
                    'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US'];

    //Create note
     args = UIAUtilities.defaults(args, {
        title: ' ',
        body: ' ',
        folder: 'Notes',
        leaveOpenForEditing: true,
      });

      notes.createNote(
        [' ', ' '],
        args
      );  

    //Switching Keyboards
      for (var i = 0; i < languages.length; i++) {
           var keyboardID = target.activeApp().getKeyboardID();
           UIALogger.logMessage('keyboardID ' + keyboardID);

          while (keyboards[i] != keyboardID) {
              target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
              keyboardID = target.activeApp().getKeyboardID()
          } //while

         switch (keyboards[i]) {
           
           case 'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US': 
//Type 'toukyou' => See 'とうきょう'
              target.activeApp().typeString(japaneseRomajiString);
              var romajiExpected = notes.inspect(UIAQuery.textViews()).value
              var compareRomajiString = japaneseRomajiExpected.localeCompare(romajiExpected);
              if( compareRomajiString == 0){
                  UIALogger.logPass(" Type 'toukyou' => See 'とうきょう'")
              }
            
//Tap the candidate '東京'
              oset.osetpredictiveString(japaneseRomajiCandidate);

//Verified '東京' is entered.
              //var romajiCandidate = notes.inspect(UIAQuery.textViews()).value
              var romajiCandidate = (notes.getNoteTextContent()).trim()
              var compareRomajiCandidate = japaneseRomajiCandidate.localeCompare(romajiCandidate);
              if( compareRomajiCandidate == 0){
                  UIALogger.logPass(" Tapped the candidate 東京 ");
              }else{
                  throw new Error('Japanese Romaji Candidate is wrong!');
              }
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              
              break; 

            }//switch
        }//for
   },// Romaji
} //OSETTests
