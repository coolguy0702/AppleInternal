load('UIATesting.js');
load('UIAApp.js');
load('UIAApp+Parsec.js')

if (typeof IMGQE_TextEditTests === 'undefined') {

    var IMGQE_TextEditTests = {

        //Test #1
        openAndClose: function openAndClose(args) {
            var textEdit = target.appWithBundleID('com.apple.TextEdit');
            textEdit.launch();
            textEdit.quit();
        },

        //Test #2
        openAndCloseWithScreenshot: function openAndCloseWithScreenshot(args) {
            var textEdit = target.appWithBundleID('com.apple.TextEdit');
            textEdit.launch();
            textEdit.captureParsecScreenshot('TextEdit open');
            textEdit.quit();
        },

        //Test #3a
        basicPerformance: function basicPerformance(args) {
            var expectedPerformance = args.secondsExpected*1000; 
            var d = new Date();
            var startTime = d.getTime();
            UIALogger.logDebug('Start time: ' + startTime);
            var textEdit = target.appWithBundleID('com.apple.TextEdit');
            textEdit.launch();           
            textEdit.quit();
            d = new Date();
            var endTime = d.getTime();
            UIALogger.logDebug('End time: ' + endTime);
            var openToClose = endTime - startTime;
            UIALogger.logDebug('Time from opening until closing: ' + openToClose);
            if(openToClose > expectedPerformance) {
                throw new UIAError("Performance is poor");
            }
        },

        //Test #3b
        basicPerformanceFailing: function basicPerformanceFailing(args) {
            var expectedPerformance = args.secondsExpected*1000;
            var d = new Date();
            var startTime = d.getTime();
            var textEdit = target.appWithBundleID('com.apple.TextEdit');
            textEdit.launch();
            textEdit.delay(10)           
            textEdit.quit();
            d = new Date();
            var endTime = d.getTime();
            var openToClose = endTime - startTime;
            UIALogger.logDebug('Time from opening until closing: ' + openToClose);
            if(openToClose > expectedPerformance) {
                throw new UIAError("Performance is poor");
            }            
        },

        //Test #4
        openingClosingMultiple: function openingClosingMultiple(args) {
            var d = new Date();
            var startTime = d.getTime();

            //TextEdit
            var textEdit = target.appWithBundleID('com.apple.TextEdit');
            textEdit.launch();         
            textEdit.quit();
            d = new Date();
            var endTime = d.getTime();
            var openToClose = endTime - startTime;
            UIALogger.logDebug('TextEdit - Time from opening until closing: ' + openToClose);

            //Photos
            d = new Date();
            startTime = d.getTime();
            var photos = target.appWithBundleID('com.apple.mobileslideshow');
            photos.launch();         
            photos.quit();
            d = new Date();
            endTime = d.getTime();
            openToClose = endTime - startTime;
            UIALogger.logDebug('Photos - Time from opening until closing: ' + openToClose);

            //Notes
            d = new Date();
            startTime = d.getTime();
            var notes = target.appWithBundleID('com.apple.mobilenotes');
            notes.launch();         
            notes.quit();
            d = new Date();
            endTime = d.getTime();
            openToClose = endTime - startTime;
            UIALogger.logDebug('Notes - Time from opening until closing: ' + openToClose);
        },

        //Test #5
        multipleIterations: function multipleIterations(args) {
            var numberOfIterations = args.numberOfIterations;
            UIALogger.logDebug('Argument provided: ' + numberOfIterations);
            for(var i = 0; i < numberOfIterations; i++) {
                var textEdit = target.appWithBundleID('com.apple.TextEdit');
                textEdit.launch();
                textEdit.quit();
            }         
        },

        //Test #6
        multipleIterationsForPerformance: function multipleIterationsForPerformance(args) {
            var numberOfIterations = args.numberOfIterations;
            var expectedPerformance = args.secondsExpected*1000;
            for(var i = 0; i < numberOfIterations; i++) {
                var d = new Date();
                var startTime = d.getTime();
                var textEdit = target.appWithBundleID('com.apple.TextEdit');
                textEdit.launch();           
                textEdit.quit();
                var endTime = d.getTime();
                var openToClose = endTime - startTime;
                UIALogger.logDebug('Time from opening until closing: ' + openToClose);
                if(openToClose > expectedPerformance) {
                    throw new UIAError("Performance is poor");
                }
            }        
        },

    }
}
