load("SpringBoard.js");
load("Camera.js");
load('Messages.js');
load('UIATesting.js');
load('Settings.js');

if (typeof IMGCamera !== 'undefined') {
    throw new UIAError("Namespace 'IMGCamera' has already been defined.");
}
/**
 * @namespace
 */

UIAQuery.IMGCamera = {
	/** Button for starting video capture */
	LIVE_PHOTO_PREVIEW: UIAQuery.images().beginsWith("Live Photo")
};


camera.forceQuit = function forceQuit() {
	if (camera.isActive()) {
		var quit_waiter = UIAWaiter.waiter('ApplicationStateChanged', {predicate: 'bundleID == "com.apple.camera" AND state == "Terminated"'});
		try {
			camera.quit();
		} catch (e) {
			UIALogger.logWarning('quit() failed, performing killall');
			target.performTask('/usr/bin/killall', ['Camera']);
			target.clickMenu();
		}
		quit_waiter.wait(10);
	}
};

var IMGCamera = {
	/**
	* Share last captured video/photo over iMessage
	*
	* @targetApps Camera, MobileSlideShow
	* 
	* @param {object} args - Test arguments
	* @param {string} [args.recipient=""] - (Optional) recipient for the video
	*/
	shareOverMessage: function(args) {
		args = UIAUtilities.defaults(args, {
			recipient: ""
		});
		
		camera.getToCameraRoll()

		cameraWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "UIActivityGroupViewController"'
		)
		camera.tap(UIAQuery.buttons("Share"))
		if (!cameraWaiter.wait(10)) {
			throw new UIAError('Share button did not appear.');
		}

		cameraWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'navigationItemTitle = "New Message"'
		)
		camera.tap(UIAQuery.tableCells("Message"))
		if (!cameraWaiter.wait(10)) {
			throw new UIAError('Message button did not appear');
		}
		
		var recipient = args.recipient === ""? target.phoneNumber(): args.recipient
		camera.enterMessageRecipients([recipient])
		camera.tap(UIAQuery.buttons("sendButton"))
		var messages = target.appWithBundleID('com.apple.MobileSMS');
	},
	/**
	 * Take a photo or video in locked mode and verify only one photo or video is visible in camera well
	 *
	 * @targetApps Camera, MobileSlideShow, Springboard
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.mode="photo"] - camera mode, "photo" or "video"
	 * @param {string} [args.cameraFacingMode="Back facing"] - camera facing mode, "Back facing" or "Front Facing"
	 * @param {string} [args.passcode="135790"] - passcode to set
	 * @param {int}    [args.duration=5] - duration if camera mode is video
	 */
	lockedModeCapture: function(args) {
		args = UIAUtilities.defaults(args, {
		    mode : 'photo',
			cameraFacingMode : 'Back facing',
			passcode : '135790',
			duration : 5
		});

		// setting passcode
        settings.setPasscode(args.passcode);

		try {
			// lock screen
			//var screenWaiter = UIAWaiter.withPredicate(
			//	'ViewDidAppear',
			//	'controllerClass = "_SBDummyRootVC"'
			//);
			while (!target.isLocked()) {
				target.systemApp().lock();
			}

			// click home button
			target.clickMenu();
			target.delay(1);
			//if (!screenWaiter.wait(10)) {
			//	throw new UIAError("UI doesn't show up after click the home button")
			//}

			// open camera
			var cameraWaiter = UIAWaiter.waiter('CameraIrisOpened');
			springboard.swipeFromRightEdge();
			if (!cameraWaiter.wait(10)) {
				throw new UIAError("Camera doesn't show up after swipe")
			}

			// change to correct camera mode
			var initialMode = camera.getCameraMode();
			if (initialMode === args.mode) {
				UIALogger.logMessage('Camera already in mode "' + args.mode + '"');
			}
			else {
				UIALogger.logMessage('Switching camera to "' + args.mode + '" mode');
				camera._changeCameraMode(args.mode);
			}

			// change to correct camera facing mode
			if (camera.hasFrontFacingCamera() && args.cameraFacingMode) {
				target.delay(1);
				camera.setCameraFacingMode(args.cameraFacingMode);
				target.delay(1);
			}

			// take one picture
			var captureWaiter = UIAWaiter.waiter("PhotoCaptured");
			if (UIAQuery.CAMERA_CAPTURE_BUTTON) {
				target.delay(2);
				if (args.mode === 'photo') {
					camera.tap(UIAQuery.CAMERA_CAPTURE_BUTTON);
					UIALogger.logMessage("Taking picture");
					captureWaiter.wait();
				}
				else if (args.mode === 'video') {
					camera.tap(UIAQuery.CAMERA_VIDEO_CAPTURE_BUTTON );
					UIALogger.logMessage("Capturing video");
					target.delay(args.duration);
					camera.tap(UIAQuery.CAMERA_VIDEO_CAPTURE_BUTTON );
				}
				target.delay(2)
			}
			else {
				throw new UIAError("Camera button doesn't show up")
			}

			// go to camera row
			var viewDisappearWaiter = UIAWaiter.withPredicate(
				"ViewDidDisappear",
				"controllerClass = 'CAMViewfinderViewController'"
			);
			UIALogger.logMessage("Waiting for CAMViewfinderViewController to disappear");
			camera.tap(UIAQuery.Camera.CAMERA_ROLL_BUTTON);
			if (!viewDisappearWaiter.wait(10)) {
				throw new UIAError("Timed out waiting for CAMViewfinderViewController");
			}
			UIALogger.logMessage("Done waiting");

			// verify only one photo is visible
			// if no photos are available, there will be no share button
			// if there are two or more photos, photo chooser will be visible
			if (!camera.exists(UIAQuery.buttons("Share"))) {
				throw new UIAError("No photos was taken")
			}
			if (camera.exists(UIAQuery.contains("Photo chooser"))) {
				throw new UIAError("More than one photos are visible when device was locked")
			}
			UIALogger.logMessage("Success!");
		} finally {
			 // disable passcode
			 target.systemApp().lock();
			 target.systemApp().unlock(args);
			 settings.disablePasscode(args.passcode);
		}
	},
	/**
	 * Take a photo or video in locked mode and verify only one photo or video is visible in camera well
	 *
	 * @targetApps Camera, MobileSlideShow, Springboard
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.orientation="Landscape"] - camera orientation, "Landscape" or "Portrait"
	 * @param {string} [args.cameraFacingMode="Back facing"] - camera facing mode, "Back facing" or "Front Facing"
	 */
	livePhotoPlayback: function(args) {
        args = UIAUtilities.defaults(args, {
            orientation: 'Landscape',
			irisOn: true,
			cameraFacingMode : 'Back facing'
		});
		// open camera
        camera.getToCamera();

		// check if live photo is supported
		if (!camera.supportsIris()) {
			UIALogger.logMessage("Device does not support live photo. Test case Pass");
            camera.forceQuit();
			return
		}

		// set device orientation
		if (args.orientation === 'Landscape') {
			target.setDeviceOrientation(UIADeviceOrientation.LANDSCAPE_RIGHT);
		} else {
			target.setDeviceOrientation(UIADeviceOrientation.PORTRAIT);
		}

		// take a live photo
		camera.setCameraOptions(args);
        camera.takePicture(args);

		// open camera roll and playback live photo
		camera.getToCameraRoll();
		if (target.hasCapability('SupportsForceTouch') == true) {
			camera.touchDownForPeekGesture(UIAQuery.IMGCamera.LIVE_PHOTO_PREVIEW);
			target.delay(5);
		} else {
			camera.touchAndHold(UIAQuery.IMGCamera.LIVE_PHOTO_PREVIEW, 5);
		}

		// quit camera app
		camera.forceQuit();
	}
};
