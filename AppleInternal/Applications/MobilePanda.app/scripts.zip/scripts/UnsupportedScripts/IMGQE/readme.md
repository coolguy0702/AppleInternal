App/Team/Project/Feature: IMGQE
Maintainer(s): Shane McQuillan
Maintainer(s) Email: smcquillan@apple.com
Maintainer(s) Team: IMGQE
Maintainer(s) Team Manger: Scott Schlieman
Maintainer(s) Team Manger Email: palace@apple.com


All IMGQE tests will go here.

--------------------
DIRECTORY STRUCTURE
--------------------

	IMGQE/<QETestArea>/...

	eg. IMGQE/iOS-FaceTime			<-- Contains iOS specific tests and suites
		IMGQE/FaceTime				<-- Contains cross platform FaceTime suites	
		IMGQE/Medusa				<-- Platform isn't needed here because Medusa is iOS only
		IMGQE/iOS-NetworkPlayback


Within your <QETestArea> directory you have free reign. We encourage creating sub-directories for logical groups of tests. This could be by sub-area, test engineer, etc.

------------
File naming
------------

Test .ptest files (Where the individual tests are defined):
	
	Tests_<Name>.ptest

	eg. Tests_iOS-AVConference.ptest
		Tests_PiP.ptest

Suite .ptest files:

	Suite_<TestArea>_<Release>_<TestType>.ptest

	eg. Suite_iOS-AVConference_Monarch_Presubmission.ptest
		Suite_AVConference_Monarch_Presubmission.ptest
		Suite_PiP_Boulder_Presubmission.ptest
		Suite_iOS-NetworkPlayback_Monarch_Functional-Leaks.ptest

Stored job .plist files:

	<TestArea>_<TestType>.plist

	eg. iOS-AVConference_Monarch_Presubmission.plist
		AVConference_Monarch_Presubmission.plist
		PiP_Boulder_Presubmission.plist
		iOS-NetworkPlayback_Monarch_Functional-Leaks.plist

In general there is a one-to-one relationship between suite ptest files and stored job plists.

-------------------------------
CATEGORY/ID NAMING CONVENTIONS
-------------------------------

Category:

This applies to individual tests, and suites.

	IMGQE_<QETestArea>

	eg. IMGQE_iOS-FaceTime
		IMGQE_FaceTime
		IMGQE_Medusa
		IMGQE_iOS-NetworkPlayback

Suite id:
	
	Suite_<TestArea>_<TestType>

	eg. Suite_iOS-AVConference_Monarch_Presubmission
		Suite_AVConference_Monarch_Presubmission
		Suite_PiP_Boulder_Presubmission
		Suite_iOS-NetworkPlayback_Monarch_Functional-Leaks

Test id:

This is at the testers descretion. This will show up as the test name in reports, so something descriptive is encouraged.

-------------------------
IMGQE Reporting Metadata
-------------------------

Reporting metadata is used to generate IMGQE test reports correctly, and to display results in the IMGQE test dashboard.

Structure:

    <key>CommonTestKeys</key>
    <dict>
        <key>Trump</key>
        <dict>
            <key>SWEGroup</key>
            <string>IMGQE</string>
            <key>QEArea</key>
            <string>Your QEArea here</string>
            <key>ReportingType</key>
            <string>Your ReportingType here</string>
            <key>ProductionLevel</key>
            <string>Your ProductionLevel here</string>
            <key>Release</key>
            <string>Your Release here</string>
        </dict>
    </dict>

This data belongs in your top-level suite, underneath your Category and ID:

	<plist version="1.0">
	    <array>
	        <dict>
	            <key>Category</key>
	            <string>Your Category here</string>
	            <key>ID</key>
	            <string>Your Suite here</string>
	            <key>CommonTestKeys</key>
	            <dict>
	                <key>Trump</key>
	                <dict>
	                    ...						<--- Metadata goes here
	                </dict>
	            </dict>
	            <key>Type</key>
	            <string>Suite</string>
	            <key>SuiteActions</key>
	            <array>
	            	...

SWEGroup:

This piece of metadata allows us to identify IMGQE's tests. The value is always:

	IMGQE

QEArea:

The high level area your test suites lives in.

	eg. iOS-FaceTime
		FaceTime
		Medusa
		iOS-NetworkPlayback

ReportingType:

The type of email report you want sent out for your test suite. It will also be used for IMGQE's weekly rollup.

	Possible values:
		
		Weekly
		Presubmission
		Other

ProductionLevel:

Provides a sandbox for your testing during the development phase.

	Possible values:

		Development
		Production

Release:

The release that you would like your test suite results to be categorized within.

	eg. Suite_iOS-AVConference_Monarch_Presubmission			Monarch
		Suite_AVConference_Gala_Presubmission					Gala
		Suite_PiP_Boulder_Presubmission							Boulder
		Suite_iOS-NetworkPlayback_Monarch_Functional-Leaks		Monarch


