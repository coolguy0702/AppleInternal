load('UIATesting.js');
load('Videos.js');

if (typeof PiPTests === 'undefined') {
    /**
     * @namespace PiPTests
     */
    var PiPTests = {
        /**
        * Choose a video, PiP the Video, then close the PiP window
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipThenClose: function pipThenClose(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipVideo(args);
            videos.pipClose(); 
        },

        /**
        * Choose a video, PiP the Video, then return to fullscreen in Videos.app
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipThenFullScreen: function pipThenFullSCreen(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipVideo(args);
            videos.pipFullScreen();
            videos.doneWithPlayback();
        },

        /**
        * Choose a video, PiP the Video, pause the video in the PiP window, then return to fullscreen in Videos.app
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipPauseThenFullScreen: function pipPauseThenFullSCreen(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipVideo(args);
            videos.pipPause();
            videos.pipFullScreen();
            videos.doneWithPlayback();
        },

        /**
        * Choose a video, PiP the Video, pause the video in the PiP window, then close the PiP window
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipPauseThenClose: function pipPauseThenClose(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipVideo(args);
            videos.pipPause();
            videos.pipClose();
        },

        /**
        * Choose a video, pause the video, PiP the Video, then close the PiP window
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipPausedVideoThenClose: function pipPausedVideoThenClose(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipPausedVideo(args);
            videos.pipClose();
        },

        /**
        * Choose a video, pause the video, PiP the Video, then return to Videos.app in fullscreen
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipPausedVideoThenFullScreen: function pipPausedVideoThenFullScreen(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipPausedVideo(args);
            videos.pipFullScreen();
        },

        /**
        * Choose a video, PiP the Video, Pause from the PiP window, then close the PiP window
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipVideoPlayPipThenClose: function pipVideoPlayPipThenPausePiPThenClose(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipVideo(args);
            videos.delay(args.duration);
            videos.pipPause();
            videos.pipClose();
        },

        /**
        * Choose a video, Pause the video, PiP the Video, play the PiP, then close the PiP window
        *
        * @param {object} args - Test arguments
        * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
        * @param {int} [args.duration=5] - Optional how long to play the video for
        */
        pipPausedVideoPlayPipThenFullScreen: function pipPausedVideoPlayPipThenFullScreen(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 10,
            })
            videos.pipPausedVideo(args);
            videos.pipPlay();
            videos.delay(args.duration);
            videos.pipFullScreen();
        },

        /**************************************************
        ** 
        **************************************************/
    }
}
