/**
 * Created by shiyu_dong on 8/23/16.
 */

load('UIATesting.js');
load("Podcasts.js");

if (typeof IMGPodcasts !== 'undefined') {
    throw new UIAError("Namespace 'IMGPodcasts' has already been defined.");
}
/**
 * @namespace
 */
UIAQuery.IMGPodCasts = {
    /** iPhone Audio Podcasts */
    IPHONE_AUDIO_PODCASTS: UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Audio Podcasts')),

    /** iPhone Video Podcasts */
    IPHONE_VIDEO_PODCASTS: UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Video Podcasts')),

    /** iPad Audio Podcasts */
    IPAD_AUDIO_PODCASTS: UIAQuery.contains('Audio Podcasts'),

    /** iPad Video Podcasts */
    IPAD_VIDEO_PODCASTS: UIAQuery.collectionViews('Video Podcasts'),

    /** iPhone First Podcast */
    IPHONE_FIRST_PODCAST: UIAQuery.collectionViews().andThen(UIAQuery.tableCells().first()),

    /** iPad First Podcast */
    IPAD_FIRST_PODCAST: UIAQuery.collectionViews('UICollectionView').last().children().andThen(UIAQuery.buttons().beginsWith("1, ").first()),

    /** 1st Recent Episode */
    RECENT_EPISODE: UIAQuery.tableCells().below(UIAQuery.contains('Recent Episodes')),

    /** Play static text */
    PLAY_TEXT: UIAQuery.staticTexts("Play"),

    /** Play button */
    PLAY_BUTTON: UIAQuery.buttons('Play'),
    /** Pause button */
    PAUSE_BUTTON: UIAQuery.buttons("Pause"),

    /** Start Listening Now button */
    START_LISTENING_BUTTON: UIAQuery.buttons('Start Listening Now'),

    /**  Browse button */
    BROWSE_BUTTON: UIAQuery.buttons('Browse'),

    /** Top Charts 'button' */
    TOP_CHARTS: UIAQuery.tableCells('Top Charts'),

    /** Retry button - sometimes the Store fails to load... */
    RETRY_BUTTON: UIAQuery.buttons('Retry')

};
var IMGPodcasts = {
    /**
     * play podcasts video
     *
     * @targetApps Podcasts
     *
     * @param {object} args - Test arguments
     * @param {int} [args.time=30] - (Optional) play time
     */
    playPodCastsVideo: function(args) {
        args = UIAUtilities.defaults(args, {
            time: 30
        });

        // launch podcasts
        podcasts.launch();

        // tap 'Start Listening Now' button, if it is there
        if (podcasts.exists(UIAQuery.IMGPodCasts.START_LISTENING_BUTTON.isVisible())) {
            podcasts.tap(UIAQuery.IMGPodCasts.START_LISTENING_BUTTON.isVisible());
        }
        target.delay(1);

        if (podcasts.exists(UIAQuery.IMGPodCasts.BROWSE_BUTTON.isVisible())) {
            podcasts.tap(UIAQuery.IMGPodCasts.BROWSE_BUTTON.isVisible());
        }
        podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.TOP_CHARTS, 15);

        // Sometimes the Store fails to load...
        if (podcasts.exists(UIAQuery.IMGPodCasts.RETRY_BUTTON.isVisible())) {
            podcasts.tap(UIAQuery.IMGPodCasts.RETRY_BUTTON.isVisible());
            target.delay(5);
        }

        // go to topcharts
        if (podcasts.exists(UIAQuery.IMGPodCasts.TOP_CHARTS.isVisible())) {
            podcasts.tap(UIAQuery.IMGPodCasts.TOP_CHARTS.isVisible());
        }

        //wait for view to load , UIA2 is too fast
        target.delay(1);
        if ((target.model() === 'iPhone' && !podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.IPHONE_AUDIO_PODCASTS, 10)) ||
            (target.model() === 'iPad' && !podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.IPAD_AUDIO_PODCASTS, 10))) {
            throw new UIAError("Error. Cannot open top charts");
        }
        UIALogger.logMessage("Opened top charts");

        // open top video (iPhone only)
        if (target.model() === 'iPhone') {
            podcasts.tap(UIAQuery.IMGPodCasts.IPHONE_VIDEO_PODCASTS);

            target.delay(5);
            podcasts.tap(UIAQuery.IMGPodCasts.IPHONE_FIRST_PODCAST);
        }
        else {
            podcasts.tap(UIAQuery.IMGPodCasts.IPAD_FIRST_PODCAST);
        }

        target.delay(5);
        if (podcasts.exists(UIAQuery.IMGPodCasts.RECENT_EPISODE.isVisible())) {
            podcasts.tap(UIAQuery.IMGPodCasts.RECENT_EPISODE);
        }
        podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.PLAY_TEXT, 10);
        podcasts.tap(UIAQuery.IMGPodCasts.PLAY_TEXT);

        if (!podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.PAUSE_BUTTON, 10)) {
            throw new UIAError("Episode did not play")
        }

        // play for [args.time] seconds
        target.delay(args.time);
        UIALogger.logMessage("Playing for 30 seconds");

        // pause
        podcasts.tap(UIAQuery.IMGPodCasts.PAUSE_BUTTON);
        target.delay(5);
        if (!podcasts.waitUntilPresent(UIAQuery.IMGPodCasts.PLAY_BUTTON, 10)) {
            throw new UIAError("Pause button did not appear")
        }

        // kill podcasts
        target.performTask('/usr/bin/killall', ['Podcasts'], 5);

        UIALogger.logMessage("Success!");
    }
};

