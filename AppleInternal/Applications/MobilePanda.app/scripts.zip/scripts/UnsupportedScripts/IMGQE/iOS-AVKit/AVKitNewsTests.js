load('AVKitNews.js');

if (typeof AVKitNews !== 'undefined') {
    throw new UIAError("Namespace 'AVKitNews' has already been defined.");
}
/**
 * @namespace AVKitNewsTests
 */

// TODO: Make sure that all tests have the deviceOrientation param AND the code to use it!

var AVKitNewsTests = {
    /**
     * Change Aspect Ratio - can't be verified via UIAutomation (only works in Full screen mode)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    changeAspectRatio: function changeAspectRatio(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.changeAspectRatio();
        avkitnews.captureParsecScreenshot("AspectRatioFullScreen");
        avkitnews.delay(2);
        // change to widescreen
        avkitnews.changeAspectRatio();
        avkitnews.captureParsecScreenshot("AspectRatioWideScreen");
        avkitnews.delay(2);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Controls always shown when entering Fullscreen if video is not playing
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsAlwaysShownWhenEnteringFullscreenWhileVideoIsPaused: function controlsAlwaysShownWhenEnteringFullscreenWhileVideoIsPaused(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.bringUpHud(); //Workaround for <rdar://problem/33457727>
        avkitnews.pause();
        avkitnews.enterFullScreen();
        avkitnews.delay(5);	// Delay until the controls would not normally be visible
        if (!avkitnews.exists(UIAQuery.AVKitNews.PLAY.isVisible())){
            throw new UIAError('The AVKit Controls are not visible while video is Paused when entering Fullscreen!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should not appear when entering Fullscreen if the video is playing
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsNotShownWhenEnteringFullscreenWhileVideoIsPlaying: function controlsNotShownWhenEnteringFullscreenWhileVideoIsPlaying(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);	// Give the video time to play for a bit
        if (!avkitnews.exists(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible())) {
            avkitnews.tapMediaView();
            if (avkitnews.waitUntilPresent(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible(), 3)) {
                avkitnews.tap(UIAQuery.AVKitNews.ENTER_FULLSCREEN)
            }
        } else {
            avkitnews.tap(UIAQuery.AVKitNews.ENTER_FULLSCREEN)
        }
        avkitnews.delay(.2);
        if ((avkitnews.exists(UIAQuery.AVKitNews.PLAY.isVisible())) && (avkitnews.isInFullScreen())){
            throw new UIAError('The AVKit Controls are visible while video is Playing when entering Fullscreen!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should always appear when exiting Fullscreen regardless of playback state
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsAlwaysShownWhenExitingFullscreen: function controlsAlwaysShownWhenExitingFullscreen(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        if (!avkitnews.exists(UIAQuery.AVKitNews.DONE.isVisible())) {
            if (avkitnews.isInFullScreen()) {
                avkitnews.tapMediaView();
                if (avkitnews.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 2)) {
                    avkitnews.tap(UIAQuery.AVKitNews.DONE)
                }
            }
        } else {
            avkitnews.tap(UIAQuery.AVKitNews.DONE)
        }
        avkitnews.delay(.2);
        if (!avkitnews.exists(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible())){
            throw new UIAError('The AVKit controls were not visible when exiting Fullscreen while the video was playing')
        }
        avkitnews.enterFullScreen();
        avkitnews.play();
        avkitnews.delay(3);
        avkitnews.pause();
        if (!avkitnews.exists(UIAQuery.AVKitNews.DONE.isVisible())) {
            if (avkitnews.isInFullScreen()) {
                avkitnews.tapMediaView();
                if (avkitnews.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 2)) {
                    avkitnews.tap(UIAQuery.AVKitNews.DONE)
                }
            }
        } else {
            avkitnews.tap(UIAQuery.AVKitNews.DONE)
        }
        avkitnews.delay(.2);
        if (!avkitnews.exists(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible())){
            throw new UIAError('The AVKit controls were not visible when exiting Fullscreen while the video was paused')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should always appear when the end of the file is reached
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    controlsShownAtEndOfFile: function controlsShownAtEndOfFile(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size === 'Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.delay(avkitnews.determineVideoLength() + 2);	// Add an extra 2 seconds just to make sure playback has ended
        if ( (!avkitnews.isPlaying()) && (!avkitnews.exists(UIAQuery.AVKitNews.PLAY.isVisible()))) {
            throw new UIAError('Playback has ended, but the AVKit Controls are not visible!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should disappear within 2 seconds of playback starting
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    controlsDisappearAfterPlaybackStarts: function controlsDisappearAfterPlaybackStarts(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size === 'Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.pause();
        avkitnews.delay(.5);
        avkitnews.play();
        avkitnews.delay(2);
        if (avkitnews.exists(UIAQuery.AVKitNews.PLAY.isVisible())) {
            throw new UIAError('AVKit Controls were visible 2 seconds after playback started!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should always be shown while the video is paused
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    controlsAlwaysShownWhileVideoIsPaused: function controlsAlwaysShownWhileVideoIsPaused(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size === 'Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.pause();
        if (avkitnews.isPlaying()) {
            throw new UIAError('AVKit player did not pause!')
        }
        avkitnews.delay(10);	// Delay until the controls would normally disappear
        if (!avkitnews.exists(UIAQuery.AVKitNews.PLAY.isVisible())) {
            throw new UIAError('The video is paused and the AVKit Controls are not visible!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Controls should always be shown when the Media Selection popover is present (iPad only)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    controlsAlwaysShownForMediaSelection: function controlsAlwaysShownForMediaSelection(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        if (args.size === 'Fullscreen') {
            avkitnews.enterFullScreen();
        }
        if (avkitnews.exists(UIAQuery.AVKitNews.MEDIA_SELECTION.isVisible())) {
            avkitnews.tap(UIAQuery.AVKitNews.MEDIA_SELECTION);
        } else {
            avkitnews.tapMediaView();
            if (avkitnews.waitUntilPresent(UIAQuery.AVKitNews.MEDIA_SELECTION), 1) {
                avkitnews.tap(UIAQuery.AVKitNews.MEDIA_SELECTION)
            } else {
                throw new UIAError('This video does not have media selection options.')
            }
        }
        if (!avkitnews.exists(UIAQuery.AVKitNews.PAUSE)){
            throw new UIAError('The Media Selection popover is visible but the AVKit Controls are not!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Switch between inline and fullscreen mode
     *
     * @param args.URL - The URL of the Article
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) - The orientation to run the test in
     *
     */
    fullScreenInlineControl: function fullScreenInlineControl(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.captureParsecScreenshot('NewsFullScreen');
        if (!avkitnews.isInFullScreen()) {
            throw new UIAError('AVKitPlayer should be in full screen mode but not');
        }
        avkitnews.exitFullScreen();
        avkitnews.dismissApplication();
    },

    /**
     * Puts a video Fullscreen then jumps backward the specified number of times.
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.jumps - How many times to jump backward
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) - The orientation to run the test in
     *
     */
    jumpBackward: function jumpBackward(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            jumps : 3,
            direction: 'Backward',
            position: '0.95',
            deviceOrientation: 'Portrait',
            state: 'Play'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.scrubCurrentPosition(args);
        if (args.state === 'Pause') {
            avkitnews.pause();
            avkitnews.bringUpHud();	//Workaround for <rdar://problem/33457727>
        } else {
            avkitnews.bringUpHud();
        }
        var startTime = avkitnews.getElapsedTime();
        avkitnews.jump(args);
        avkitnews.bringUpHud();	//Workaround for <rdar://problem/33457727>
        var endTime = avkitnews.getElapsedTime();
        startTime = avkitnews.decrementTime(args.jumps, startTime);
        if (!startTime >= endTime) {
            throw new UIAError('The end time was expected to be less than or equal to the start time - (# of jumps * 15 [seconds])');
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    //Note: This test case is very fragile. I had to jump through hoops to get the controls to appear long enough
    /**
     * Puts a video Fullscreen then jumps forward the specified number of times.
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.jumps - How many times to jump backward
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) - The orientation to run the test in
     */
    jumpForward: function jumpForward(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            jumps : 3,
            direction: 'Forward',
            deviceOrientation: 'Portrait',
            state: 'Play'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.pause();
        avkitnews.bringUpHud();
        var startTime = avkitnews.getElapsedTime();
        if (args.state === 'Play') {
            avkitnews.bringUpHud();
            avkitnews.play();
        }
        avkitnews.jump(args);
        avkitnews.bringUpHud();	//Workaround for <rdar://problem/33457727> [automation only] Controls not visible while video is paused
        avkitnews.pause();
        var endTime = avkitnews.getElapsedTime();
        startTime = avkitnews.incrementTime(args.jumps, startTime);
        if (!endTime >= startTime) {
            throw new UIAError('The end time was expected to be greater than or equal to the start time + (# of jumps * 15 [seconds])');
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Plays a video then pauses the video and verifies that the playback state is updated appropriately
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The device orientation to run the test
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    pauseVideo: function pauseVideo(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.pause();
        avkitnews.captureParsecScreenshot('NewsIsPaused');
        if (avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to paused state.')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Play a video
     *
     * @param args.URL - The URL to the Story
     * @param {string} args.deviceOrientation - The device orientation to run the test
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    playVideo: function playVideo(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(10);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Plays/Pauses a video inline and then fullscreen
     *
     * @param args.URL - The URL of the Article
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
     * @param {int} [args.length=5] - (Required) Duration of the play
     */
    playAndPauseVideo: function playAndPauseVideo(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            name: "Monster's University trailer",
            length: 5
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.captureParsecScreenshot('NewsIsPlayingInline');
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.delay(args.length);
        avkitnews.pause();
        avkitnews.captureParsecScreenshot('NewsIsPauseInline');
        if (avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to paused state.')
        }
        avkitnews.enterFullScreen();
        avkitnews.play();
        avkitnews.captureParsecScreenshot('NewsIsPlayingFullScreen');
        if (!avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to playing.')
        }
        avkitnews.delay(args.length);
        avkitnews.pause();
        avkitnews.captureParsecScreenshot('NewsIsPauseFullScreen');
        if (avkitnews.isPlaying()) {
            throw new UIAError('News UI did not change to paused state.')
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },
    
    // TODO: Ask Felix how to verify rotation
    /**
     * Rotate device
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    rotation: function rotation(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.delay(2);
        args.deviceOrientation = "Landscape";
        avkitnews.setDeviceOrientation(args);
        avkitnews.captureParsecScreenshot("Landscape");
        avkitnews.delay(2);
        args.deviceOrientation = "Portrait";
        avkitnews.setDeviceOrientation(args);
        avkitnews.captureParsecScreenshot("Portrait");
        avkitnews.delay(2);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Scrub media back and forth
     *
     * @param args.URL - The URL of the Article
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
     * @param {string} [args.begin="0.2"] - (Required) A double between 0 and 1 to set the lower volume level
     * @param {string} [args.end="0.8"] - (Required) A double between 0 and 1 to set the higher volume level
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     *
     * @targetApps AVKitPlayer
     */
    scrubBackAndForth: function scrubBackAndForth(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            begin: '0.2',
            end: '0.8',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        var options = {
            position: "0.5"
        };
        options.position = args.begin;
        avkitnews.scrubCurrentPosition(options);
        avkitnews.captureParsecScreenshot('NewsScrubbing1');
        // TODO: Bug in scrubbing API, second scrubbing always go back to 0
        options.position = args.begin;
        avkitnews.scrubCurrentPosition(options);
        avkitnews.captureParsecScreenshot('NewsScrubbing2');
        options.position = args.end;
        avkitnews.scrubCurrentPosition(options);
        avkitnews.captureParsecScreenshot('NewsScrubbing3');
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Scrub on the transport bar to a certain position
     * Note: This test will always fail because of "imprecise scrubbing" which prevents large jumps from working programmatically.
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     *
     * @targetApps AVKitPlayer
     */
    scrubToPosition: function scrubToPosition(args){
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            position: '0.5',
            size: 'Inline',
            allowImpreciseScrubbing: true
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.pause();
        avkitnews.bringUpHud();
        avkitnews.scrubCurrentPosition(args);
        avkitnews.assertValueForCurrentPosition(args);
        avkitnews.captureParsecScreenshot('AVKitPlayerScrub');
        avkitnews.dismissApplication();
    },

    /**
     * Select audio and subtitles
     *
     * @param args.URL - The URL of the Article
     * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
     * @param {int} [args.length=5] - (Required) Duration of the play
     * @param {string} [args.audio="French"] - The Audio Name [News doesn't normally use this]
     * @param {string} [args.subtitles="English"] - (Required) The Subtitles Name
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     *
     */
    selectAudioAndSubtitles: function selectAudioAndSubtitles(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            length: 5,
            subtitles: "Auto",
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.selectAudioAndSubtitles(args);
        avkitnews.play();
        avkitnews.delay(args.length);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Set the Mute state
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - Valid values are Portrait or Landscape
     * @param {string} args.mute - Valid values are ON or OFF. If you can hear sound, mute is OFF.
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    setMute: function setMute(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            mute: 'ON',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.setMuteState(args);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Sets the volume to the specified volumeLevel
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.volumeLevel - A double between 0 and 1 to set the volume level
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    setVolume: function setVolume(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline',
            volumeLevel: '0.5'
        });
        UIALogger.logWarning('This test currently fails due to <rdar://problem/33187672> setControl not setting volume to specified level');
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size === 'Fullscreen') {
            avkitnews.enterFullScreen();
        }
        avkitnews.pause();
        avkitnews.setVolume(args);
        avkitnews.assertValueForVolume(args);
        avkitnews.captureParsecScreenshot('NewsSetVolume');
        avkitnews.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is playing and controls are visible (Fullscreen only)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarVisibleWhilePlayingAndControlsAreVisible: function statusBarVisibleWhilePlayingAndControlsAreVisible(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.bringUpHud();
        if (avkitnews.inspect(UIAQuery.AVKitNews.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Status Bar should be hidden when Video is playing and controls are hidden (Fullscreen only)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarHiddenWhilePlayingAndControlsAreHidden: function statusBarHiddenWhilePlayingAndControlsAreHidden(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.delay(4);
        if (avkitnews.inspect(UIAQuery.AVKitNews.STATUS_BAR).isVisible == 1) {
            throw new UIAError('The Status Bar was not hidden!')
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is paused (Fullscreen only)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarVisibleWhilePaused: function statusBarVisibleWhilePaused(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.delay(1);
        avkitnews.bringUpHud();
        avkitnews.delay(2);
        avkitnews.pause();
        avkitnews.delay(4);
        if (avkitnews.inspect(UIAQuery.AVKitNews.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkitnews.dismissApplication();
    },

    /**
     * Status Bar should be hidden when Video is playing, controls are hidden and Volume is changed with hard buttons (Fullscreen only)
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarHiddenWhilePlayingAndControlsAreHiddenAndVolumeChangedViaButtons: function statusBarHiddenWhilePlayingAndControlsAreHiddenAndVolumeChangedViaButtons(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.delay(4);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitnews.inspect(UIAQuery.AVKitNews.STATUS_BAR).isVisible == 1) {
            throw new UIAError('The Status Bar was visible!')
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Toggle Mute ON then OFF
     *
     * @param args.URL - The URL of the Article
     * @param {string} args.deviceOrientation - The device orientation to run the test
     * @param {string} args.size - Valid values are Fullscreen or Inline.
     */
    toggleMuteOnThenOff: function toggleMuteOnThenOff(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait',
            size: 'Inline'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        if (args.size ==='Inline') {
            avkitnews.enterFullScreen();
        }
        args.mute = 'ON';
        avkitnews.setMuteState(args);
        avkitnews.play();
        avkitnews.delay(2);
        avkitnews.pause();
        args.mute = 'OFF';
        avkitnews.setMuteState(args);
        avkitnews.dismissApplication();
    },

    /**
     *	Validate Volume Control collapse behavior (iPhone only)
     *
     * @param args.URL - The URL of the Article
     */
    volumeControlCollapseBehavior: function volumeControlCollapseBehavior(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
            deviceOrientation: 'Portrait'
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        args.deviceOrientation = 'Portrait';
        avkitnews.pause();
        if (avkitnews.isPlaying()) {
            throw new UIAError('Video is not paused!')
        }
        avkitnews.delay(2);
        avkitnews.enterFullScreen();
        avkitnews.delay(.5);
        if ((avkitnews.inspect(UIAQuery.AVKitNews.MUTETOGGLE).isVisible == 1) &&
            (!avkitnews.exists(UIAQuery.AVKitNews.VOLUME))) {
            UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
        } else {
            throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
        }
        args.deviceOrientation = 'Landscape';
        avkitnews.setDeviceOrientation(args);
        avkitnews.delay(.5);
        if (!(avkitnews.inspect(UIAQuery.AVKitNews.MUTETOGGLE).isVisible == 1) &&
            (!avkitnews.inspect(UIAQuery.AVKitNews.VOLUME).isVisible == 1)) {
            throw new UIAError('The Volume Control is not in the expected state - expanded in Landscape Mode')
        } else {
            UIALogger.logMessage('The Volume Control is expanded in Landscape Mode')
        }
        args.deviceOrientation = 'Portrait';
        avkitnews.setDeviceOrientation(args);
        avkitnews.delay(.5);
        if (!(avkitnews.inspect(UIAQuery.AVKitNews.MUTETOGGLE).isVisible == 1) &&
            (!avkitnews.inspect(UIAQuery.AVKitNews.VOLUME).isVisible == 1)) {
            throw new UIAError('The Volume Control is not in the expected state expanded in Portrait Mode')
        } else {
            UIALogger.logMessage('The Volume Control is expanded in Portrait Mode')
        }
        avkitnews.play();
        avkitnews.delay(3);
        avkitnews.pause();
        if ((avkitnews.inspect(UIAQuery.AVKitNews.MUTETOGGLE).isVisible == 1) &&
            (!avkitnews.exists(UIAQuery.AVKitNews.VOLUME))) {
            UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
        } else {
            throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
        }
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Volume control should be visible in Fullscreen mode when the volume is changed with the hard buttons
     *
     * @param args.URL - The URL of the Article
     */
    volumeControlVisibleInFullscreenModeWhenVolumeChangedViaButtons: function volumeControlVisibleInFullscreenModeWhenVolumeChangedViaButtons(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.navigateToMedia(args);
        avkitnews.delay(5);
        avkitnews.enterFullScreen();
        avkitnews.delay(4);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitnews.inspect(UIAQuery.AVKitNews.VOLUME).isVisible == 0) {
            throw new UIAError('The Volume control was not visible!')
        }
        target.delay(2);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitnews.exists(UIAQuery.AVKitNews.PAUSE)) {
            throw new UIAError('Other controls besides Volume were visible!')
        }
        avkitnews.delay(2);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    },

    /**
     * Volume control should be visible in Inline mode when the volume is changed with the hard buttons if the other
     * controls are visible. Volume control should not be visible when the volume is changed with the hard buttons
     * while the other controls are not visible.
     *
     * @param args.URL - The URL of the Article
     */
    volumeControlBehaviorInInlineModeWhenVolumeChangedViaButtons: function volumeControlBehaviorInInInlineModeWhenVolumeChangedViaButtons(args) {
        args = UIAUtilities.defaults(args, {
            URL: 'https://apple.news/AU74onaXhQKO1DA42YY6BQQ',
        });
        avkitnews.setDeviceOrientation(args);
        avkitnews.playVideo(args);
        avkitnews.delay(5);
        avkitnews.pause();
        UIATarget.localTarget().clickVolumeUp();
        if ((avkitnews.exists(UIAQuery.AVKitNews.PAUSE.isVisible())) && (!avkitnews.exists(UIAQuery.AVKitNews.MUTETOGGLE))) {
            throw new UIAError('The Volume control was not visible!')
        }
        avkitnews.play();
        avkitnews.delay(4);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitnews.exists(UIAQuery.AVKitNews.PAUSE) && avkitnews.isPlaying()) {
            throw new UIAError('The video was playing but the controls were visible after a delay!')
        }
        UIATarget.localTarget().clickVolumeUp();
        if ((avkitnews.exists(UIAQuery.AVKitNews.MUTETOGGLE)) || (avkitnews.exists(UIAQuery.AVKitNews.VOLUME))) {
            throw new UIAError('The Mute Control or the Volume control was visible!')
        }
        avkitnews.delay(2);
        avkitnews.doneWithPlayback();
        avkitnews.dismissApplication();
    }
};
