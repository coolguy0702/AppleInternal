load('UIATesting.js');
load('UIAApp.js');
load('UIAApp+PiP.js');
load('SpringBoard.js');
load('AVKitPlayer.js');

UIAUtilities.assert( typeof AVKitPlayer === 'undefined', 'avkitplayer undefined' );
	/**
	 * @namespace AVKitPlayerTests
	 */

var AVKitPlayerTests = {
        /**
         * Plays a video then verifies that the playback state is updated appropriately
         *
         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        playVideo: function playVideo(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPlaying');
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Plays a video then pauses the video and verifies that the playback state is updated appropriately
         *
         * @param {string} args.contentType - The content type to play in fullscreen {"Audio", "Local"}
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        pauseVideo: function pauseVideo(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.pause();
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPaused');
            if (avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to paused state.')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Plays/Pauses a video inline and then fullscreen
         * rdar://tsc/15446981 AVKitPlayer - play/pause media
         *
         * @param {object} args - Test arguments
         * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @targetApps AVKitPlayer
         */
        playAndPauseMedia: function playAndPauseMedia(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                name: "Monster's University trailer",
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPlayingInline');
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.delay(args.length);
            avkitplayer.pause();
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPauseInline');
            if (avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to paused state.')
            }
            avkitplayer.enterFullScreen();
            avkitplayer.play();
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPlayingFullScreen');
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.delay(args.length);
            avkitplayer.pause();
            avkitplayer.captureParsecScreenshot('AVKitPlayerIsPauseFullScreen');
            if (avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to paused state.')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        //TODO: Verify when fixed - <rdar://problem/33457727> [automation only] Controls not visible while video is paused

        //Note: This test case is very fragile. I had to jump through hoops to get the controls to appear long enough
        /**
         * Puts a video Fullscreen then jumps forward the specified number of times.
         * Optional - scrub to a specified position before jumping
         * <rdar://tsc/15446989> Jump Forward/Backward
         *
         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {number} args.jumps - How many times to jump forward
         * @param {string} args.state - Valid values are Play or Pause
         * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
         *
         * @targetApps AVKitPlayer
         */
        jumpForward: function jumpForward(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                name: "Monster's University trailer",
                jumps: 3,
                direction: 'Forward',
                position: '0.0',
                deviceOrientation: 'Portrait',
                state: 'Play'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.scrubCurrentPosition(args);
            avkitplayer.bringUpHud();
            avkitplayer.pause();
            avkitplayer.bringUpHud();
            var startTime = avkitplayer.getElapsedTime();
            if (args.state === 'Play') {
                avkitplayer.play();
            }
            avkitplayer.jump(args);
            avkitplayer.bringUpHud();	//Workaround for <rdar://problem/33457727> [automation only] Controls not visible while video is paused
            avkitplayer.pause();
            var endTime = avkitplayer.getElapsedTime();
            startTime = avkitplayer.incrementTime(args.jumps, startTime);
            if (!endTime >= startTime) {
                throw new UIAError('The end time was expected to be greater than or equal to the start time + (# of jumps * 15 [seconds])');
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Puts a video Fullscreen, scrubs to the specified position then jumps backward the specified number of times.
         * <rdar://tsc/15446989> Jump Forward/Backward
         *
         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {number} args.jumps - How many times to jump backward
         * @param {string} args.state - Valid values are Play or Pause
         * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
         *
         * @targetApps AVKitPlayer
         */
        jumpBackward: function jumpBackward(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                name: "Monster's University trailer",
                jumps: 3,
                direction: 'Backward',
                position: '0.95',
                deviceOrientation: 'Portrait',
                state: 'Play'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('AVKitPlayer UI did not change to playing.')
            }
            avkitplayer.scrubCurrentPosition(args);
            if (args.state === 'Pause') {
                avkitplayer.pause();
                avkitplayer.bringUpHud();	//Workaround for <rdar://problem/33457727>
            } else {
                avkitplayer.bringUpHud();
            }
            var startTime = avkitplayer.getElapsedTime();
            avkitplayer.jump(args);
            avkitplayer.bringUpHud();	//Workaround for <rdar://problem/33457727>
            var endTime = avkitplayer.getElapsedTime();
            startTime = avkitplayer.decrementTime(args.jumps, startTime);
            if (!startTime >= endTime) {
                throw new UIAError('The end time was expected to be less than or equal to the start time - (# of jumps * 15 [seconds])');
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Scrub on the transport bar to a certain position
         * <rdar://tsc/15446994> Scrubbing
         *
         * Note: This test will always fail because of "imprecise scrubbing" which prevents large jumps from working programmatically.

         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        scrubToPosition: function scrubToPosition(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                deviceOrientation: 'Portrait',
                position: '0.5',
                size: 'Inline',
                allowImpreciseScrubbing: true
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.bringUpHud();
            avkitplayer.scrubCurrentPosition(args);
            avkitplayer.assertValueForCurrentPosition(args);
            avkitplayer.captureParsecScreenshot('AVKitPlayerScrub');
            avkitplayer.dismissApplication();
        },

        /**
         * Scrub media back and forth
         *
         * rdar://tsc/15446994 AVKitPlayer - Scrubbing
         * @param {object} args - Test arguments
         * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} [args.begin="0.2"] - (Required) A double between 0 and 1 to set the lower volume level
         * @param {string} [args.end="0.8"] - (Required) A double between 0 and 1 to set the higher volume level
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        scrubBackAndForth: function scrubBackAndForth(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                name: "Monster's University trailer",
                begin: '0.2',
                end: '0.8',
                size: 'Inline'
            });
            avkitplayer.navigateToMedia(args);
            avkitplayer.setDeviceOrientation(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            var options = {
                position: "0.5"
            };
            avkitplayer.scrubCurrentPosition(options);
            options.position = args.begin;
            avkitplayer.scrubCurrentPosition(options);
            avkitplayer.captureParsecScreenshot('AVKitPlayerScrubbing1');
            options.position = args.end;
            avkitplayer.scrubCurrentPosition(options);
            avkitplayer.captureParsecScreenshot('AVKitPlayerScrubbing2');
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Set the Mute state
         *
         * @param {string} args.contentType - Valid values are Audio or Local
         * @param {string} args.deviceOrientation - Valid values are Portrait or Landscape
         * @param {string} args.mute - Valid values are ON or OFF. If you can hear sound, mute is OFF.
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        setMute: function setMute(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                deviceOrientation: 'Portrait',
                mute: 'ON',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.setMuteState(args);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Toggle Mute ON then OFF
         * <rdar://tsc/15446990> Volume control
         *
         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        toggleMuteOnThenOff: function toggleMuteOnThenOff(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Local',
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullsceen') {
                avkitplayer.enterFullScreen();
            }
            args.mute = 'ON';
            avkitplayer.bringUpHud();
            avkitplayer.setMuteState(args);
            avkitplayer.play();
            avkitplayer.delay(2);
            avkitplayer.pause();
            args.mute = 'OFF';
            avkitplayer.bringUpHud();
            avkitplayer.setMuteState(args);
            avkitplayer.dismissApplication();
        },

        /**
         * Sets the volume to the specified volumeLevel
         * <rdar://tsc/15446990> Volume control
         *
         * @param {string} args.contentType - The content type to play {"Audio", "Local"}
         * @param {string} args.volumeLevel - A double between 0 and 1 to set the volume level
         * @param {string} args.deviceOrientation - The orientation to run the test in
         *
         * @targetApps AVKitPlayer
         */
        setVolume: function setVolume(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                contentType: 'Local',
                size: 'Fullscreen',
                volumeLevel: '0.5'
            });
            UIALogger.logWarning('This test currently fails due to <rdar://problem/33187672> setControl not setting volume to specified level');
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.pause();
            avkitplayer.setVolume(args);
            avkitplayer.assertValueForVolume(args);
            avkitplayer.captureParsecScreenshot('AVKitPlayerSetVolume');
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
                avkitplayer.exitFullScreen();
            }
            avkitplayer.dismissApplication();
        },

        /**
         *    Validate Volume Control collapse behavior (iPhone only)
         * <rdar://tsc/18470109> Volume control collapse behavior (iPhone only)
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         *
         * @targetApps AVKitPlayer
         */
        volumeControlCollapseBehavior: function volumeControlCollapseBehavior(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.navigateToMedia(args);
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video is not paused!')
            }
            avkitplayer.delay(2);
            avkitplayer.enterFullScreen();
            avkitplayer.delay(.5);
            if ((avkitplayer.inspect(UIAQuery.AVKitPlayer.MUTETOGGLE).isVisible == 1) &&
                (!avkitplayer.exists(UIAQuery.AVKitPlayer.VOLUME))) {
                UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
            } else {
                throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
            }
            args.deviceOrientation = 'Landscape';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(.5);
            if (!(avkitplayer.inspect(UIAQuery.AVKitPlayer.MUTETOGGLE).isVisible == 1) &&
                (!avkitplayer.inspect(UIAQuery.AVKitPlayer.VOLUME).isVisible == 1)) {
                throw new UIAError('The Volume Control is not in the expected state - expanded in Landscape Mode')
            } else {
                UIALogger.logMessage('The Volume Control is expanded in Landscape Mode')
            }
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(.5);
            if (!(avkitplayer.inspect(UIAQuery.AVKitPlayer.MUTETOGGLE).isVisible == 1) &&
                (!avkitplayer.inspect(UIAQuery.AVKitPlayer.VOLUME).isVisible == 1)) {
                throw new UIAError('The Volume Control is not in the expected state expanded in Portrait Mode')
            } else {
                UIALogger.logMessage('The Volume Control is expanded in Portrait Mode')
            }
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            if ((avkitplayer.inspect(UIAQuery.AVKitPlayer.MUTETOGGLE).isVisible == 1) &&
                (!avkitplayer.exists(UIAQuery.AVKitPlayer.VOLUME))) {
                UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
            } else {
                throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Volume control should be visible in Fullscreen mode when the volume is changed with the hard buttons
         * <rdar://tsc/18470108> Volume control visible when changing Volume with buttons when in Fullscreen mode
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         */
        volumeControlVisibleInFullscreenModeWhenVolumeChangedViaButtons: function volumeControlVisibleInFullscreenModeWhenVolumeChangedViaButtons(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer"
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.delay(4);
            UIATarget.localTarget().clickVolumeUp();
            if (avkitplayer.inspect(UIAQuery.AVKitPlayer.VOLUME).isVisible == 0) {
                throw new UIAError('The Volume control was not visible!')
            }
            target.delay(2);
            UIATarget.localTarget().clickVolumeUp();
            if (avkitplayer.exists(UIAQuery.AVKitPlayer.PAUSE)) {
                throw new UIAError('Other controls besides Volume were visible!')
            }
            avkitplayer.delay(2);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Volume control should be visible in Inline mode when the volume is changed with the hard buttons if the other
         * controls are visible. Volume control should not be visible when the volume is changed with the hard buttons
         * while the other controls are not visible.
         * <rdar://tsc/18470107> Volume control behavior when changing Volume with buttons when in Inline mode
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         */
        volumeControlBehaviorInInlineModeWhenVolumeChangedViaButtons: function volumeControlBehaviorInInInlineModeWhenVolumeChangedViaButtons(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer"
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.pause();
            UIATarget.localTarget().clickVolumeUp();
            if ((avkitplayer.exists(UIAQuery.AVKitPlayer.PAUSE.isVisible())) && (!avkitplayer.exists(UIAQuery.AVKitPlayer.MUTETOGGLE))) {
                throw new UIAError('The Volume control was not visible!')
            }
            avkitplayer.bringUpHud();
            avkitplayer.play();
            avkitplayer.delay(4);
            UIATarget.localTarget().clickVolumeUp();
            if (avkitplayer.exists(UIAQuery.AVKitPlayer.PAUSE) && avkitplayer.isPlaying()) {
                throw new UIAError('The video was playing but the controls were visible after a delay!')
            }
            UIATarget.localTarget().clickVolumeUp();
            if ((avkitplayer.exists(UIAQuery.AVKitPlayer.MUTETOGGLE)) || (avkitplayer.exists(UIAQuery.AVKitPlayer.VOLUME))) {
                throw new UIAError('The Mute Control or the Volume control was visible!')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Select audio and subtitles
         * rdar://tsc/15447000 AVKitPlayer - Subtitles
         *
         * @param {object} args - Test arguments
         * @param {string} [args.deviceOrientation="Portrait"] - (Required) The device orientation to run the test
         * @param {string} [args.name="Bip-Bop"] - (Required) The Media Name
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} [args.audio="French"] - (Required) The Audio Name
         * @param {string} [args.subtitles="English"] - (Required) The Subtitles Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        selectAudioAndSubtitles: function selectAudioAndSubtitles(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                name: 'Bip-Bop',
                length: 5,
                audio: "French",
                subtitles: "English",
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.selectAudioAndSubtitles(args);
            avkitplayer.play();
            avkitplayer.delay(args.length);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Switch between inline and fullscreen mode
         * rdar://tsc/15446991 AVKitPlayer - Fullscreen/Inline
         *
         * @param {object} args - Test arguments
         * @param {string} [args.deviceOrientation="Portrait"] - (Required) - The orientation to run the test in
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         *
         * @targetApps AVKitPlayer
         */
        fullScreenInlineControl: function fullScreenInlineControl(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                name: "Monster's University trailer"
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.captureParsecScreenshot('AVKitPlayerFullScreen');
            if (!avkitplayer.isInFullScreen()) {
                throw new UIAError('AVKitPlayer should be in full screen mode but not');
            }
            avkitplayer.exitFullScreen();
            avkitplayer.dismissApplication();
        },

        // TODO: Ask Felix how to verify rotation
        /**
         * Rotate device
         * rdar://tsc/15447001 AVKitPlayer - Rotation
         *
         * @param {object} args - Test arguments
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        rotation: function rotation(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(2);
            args.deviceOrientation = "Landscape";
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.captureParsecScreenshot("Landscape");
            avkitplayer.delay(2);
            args.deviceOrientation = "Portrait";
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.captureParsecScreenshot("Portrait");
            avkitplayer.delay(2);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Change Aspect Ratio - can't be verified via UIAutomation
         * rdar://tsc/15447010 AVKitPlayer - Aspect Ratio
         *
         * @param {object} args - Test arguments
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        changeAspectRatio: function changeAspectRatio(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.changeAspectRatio();
            avkitplayer.captureParsecScreenshot("AspectRatioFullScreen");
            avkitplayer.delay(2);
            // change to widescreen
            avkitplayer.changeAspectRatio();
            avkitplayer.captureParsecScreenshot("AspectRatioWideScreen");
            avkitplayer.delay(2);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        // NOTE: PiP returns to inline when returning even if invoked from full screen when using the Embedded Player
        /**
         * Choose a video, PiP the Video, then close the PiP window
         * <rdar://tsc/18470092> [Embedded Player] Play, PiP then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipThenClose: function pipThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.delay(.5);
            avkitplayer.closePip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipClose()) {
                throw new UIAError('Did not exit Pip or the video is playing!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, PiP the Video, then return
         * <rdar://tsc/18470091> [Embedded Player] Play, PiP then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipThenReturn: function pipThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.delay(.5);
            avkitplayer.returnFromPip();
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, PiP the Video, pause the video in the PiP window, return, then resume playing
         * <rdar://tsc/18607214> [Embedded Player] Play, PiP, Pause, Return, then Play
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         */
        pipPauseReturnThenPlay: function pipPauseReturnThenPlay(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Playback should be paused, but it is not!');
            }
            avkitplayer.returnFromPip();
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            avkitplayer.play();
            if (!avkitplayer.isPlaying()) {
                throw new UIAError('Playback did not resume after PiP!');
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, PiP the Video, Return, then pause
         * <rdar://tsc/18607216> [Embedded Player] Play, PiP, Return, then pause
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         */
        pipReturnThenPause: function pipReturnThenPause(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.delay(.5);
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Playback should be paused, but it is not!');
            }
            avkitplayer.returnFromPip();
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Playback did not pause after PiP!');
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, PiP the Video, pause the video in the PiP window, then close the PiP window
         * <rdar://tsc/18470090> [Embedded Player] Play, PiP, Pause then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         *
         * @targetApps AVKitPlayer
         */
        pipPauseThenClose: function pipPauseThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.delay(.5);
            avkitplayer.pausePip();
            avkitplayer.delay(.5);
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.delay(.5);
            avkitplayer.closePip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipClose()) {
                throw new UIAError('Did not exit PiP or the video is playing!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, PiP the Video, pause the video in the PiP window, then return
         * <rdar://tsc/18470091> [Embedded Player] Play, PiP then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipPauseThenReturn: function pipPauseThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.pausePip();
            avkitplayer.delay(.5);
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.returnFromPip();
            avkitplayer.delay(1);
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained!')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, pause the video, PiP the Video, then close the PiP window
         * <rdar://tsc/18470088> [Embedded Player] Pause, PiP then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         *
         * @targetApps AVKitPlayer
         */
        pausePipThenClose: function pausePipThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video is not paused!')
            }
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.delay(.5);
            avkitplayer.closePip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipClose()) {
                throw new UIAError('Did not exit PiP or the video is playing!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, pause the video, PiP the Video, then return
         * <rdar://tsc/18470093> [Embedded Player]Pause, PiP then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pausePipThenReturn: function pausePipThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video is not paused!')
            }
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.delay(.5);
            avkitplayer.returnFromPip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained!')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, pause the video, PiP the Video, play the PiP, then close the PiP window
         * <rdar://tsc/18470094> [Embedded Player] Pause, PiP, Play then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         *
         * @targetApps AVKitPlayer
         */
        pausePipPlayThenClose: function pausePipPlayThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video is not paused!')
            }
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.delay(.5);
            avkitplayer.playPip();
            if (!avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is not playing in the PiP window!')
            }
            avkitplayer.closePip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipClose()) {
                throw new UIAError('Did not exit PiP or the video is playing!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Choose a video, pause the video, PiP the Video, play the PiP, then return
         * <rdar://tsc/18470095> [Embedded Player] Pause, PiP, Play then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} [args.length=5] - (Required) Duration of the play
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pausePipPlayThenReturn: function pausePipPlayThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                size: 'Inline',
                deviceOrientation: 'Portrait',
                length: 5
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video is not paused!')
            }
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            if (avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is playing in the PiP window!')
            }
            avkitplayer.delay(.5);
            avkitplayer.playPip();
            if (!avkitplayer.isPipPlaying()) {
                throw new UIAError('Video is not playing in the PiP window!')
            }
            avkitplayer.returnFromPip();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            if (!avkitplayer.didPipReturn()) {
                throw new UIAError('Did not return from PiP or the play state was not retained!')
            }
            if (args.player === 'Fullscreen') {
                if (!avkitplayer.isInFullScreen()) {
                    throw new UIAError('PiP did not return to fullscreen in the Fullscreen Player')
                }
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Play a video, enter PiP mode via the Home button, then Close the PiP window
         * <rdar://tsc/18470096> [Full Screen Player] Play, PiP then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipViaHomeThenClose: function pipViaHomeThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            UIATarget.localTarget().clickMenu();
            avkitplayer.pausePip(); // Need to pause playback to bring up the PiP controls
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.closePip();
            // stupid workaround since I can't kill the app
            avkitplayer.launch();
            avkitplayer.doneWithPlayback()
        },

        /**
         * Play a video, enter PiP mode via the Home button, then Return
         * <rdar://tsc/18470097> [Full Screen Player] Play, PiP then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipViaHomeThenReturn: function pipViaHomeThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            UIATarget.localTarget().clickMenu();
            avkitplayer.pausePip(); // Need to pause playback to bring up the PiP controls
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.returnFromPip();
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Play a video, enter PiP mode via the Home button, pause the video, then Close the PiP window
         * <rdar://tsc/18470098> [Full Screen Player] Play, PiP, Pause then Close
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipViaHomePauseThenClose: function pipViaHomePauseThenClose(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            UIATarget.localTarget().clickMenu();
            target.delay(.5);
            avkitplayer.pausePip(); // Need to pause playback to bring up the PiP controls
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.closePip();
            var home_screen = target.activeApp();
            if (home_screen.exists(UIAQuery.contains('AVPlayerView'))) {
                throw new UIAError('AVKitPlayer was visible!')
            }
            // stupid workaround since I can't kill the app
            avkitplayer.launch();
            avkitplayer.doneWithPlayback();

        },

        /**
         * Play a video, enter PiP mode via the Home button, pause the video, then Return
         * <rdar://tsc/18470099> [Full Screen Player] Play, PiP, Pause then Return
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pipViaHomePauseThenReturn: function pipViaHomePauseThenReturn(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            UIATarget.localTarget().clickMenu();
            avkitplayer.pausePip(); // Need to pause playback to bring up the PiP controls
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            avkitplayer.returnFromPip();
            avkitplayer.bringUpHud();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('Video was playing after returning from paused PiP!')
            }
            // stupid workaround since I can't kill the app
            avkitplayer.launch();
            avkitplayer.doneWithPlayback();
        },

        /**
         * Play a video, pause the video, then enter PiP mode via the Home button
         * <rdar://tsc/18470125> [Full Screen Player] Play, Pause then PiP
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The device orientation to run the test
         * @param {string} args.player - Specify Fullscreen for Fullscreen Player. Otherwise Embedded Player will be used.
         *
         * @targetApps AVKitPlayer
         */
        pausePipViaHome: function pausePipViaHome(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            target.delay(2);
            avkitplayer.pause();
            UIATarget.localTarget().clickMenu();
            var home_screen = target.activeApp();
            if (home_screen.exists(UIAQuery.contains('AVPlayerView'))) {
                throw new UIAError('AVKitPlayer was visible!')
            }
            if (avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window should not be visible but it is!')
            }
        },

        /**
         * Controls should always be shown when the Media Selection popover is present (iPad only)
         * <rdar://tsc/18110934> Controls always shown while media selection popover is present (iPad only)
         *
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         *
         * @targetApps AVKitPlayer
         */
        controlsAlwaysShownForMediaSelection: function controlsAlwaysShownForMediaSelection(args) {
            args = UIAUtilities.defaults(args, {
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMediaWithAlternateLanguages(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            if (avkitplayer.exists(UIAQuery.AVKitPlayer.MEDIA_SELECTION.isVisible())) {
                avkitplayer.tap(UIAQuery.AVKitPlayer.MEDIA_SELECTION);
            } else {
                avkitplayer.tapMediaView();
                if (avkitplayer.waitUntilPresent(UIAQuery.AVKitPlayer.MEDIA_SELECTION), 1) {
                    avkitplayer.tap(UIAQuery.AVKitPlayer.MEDIA_SELECTION)
                } else {
                    throw new UIAError('This video does not have media selection options.')
                }
            }
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY)) {
                throw new UIAError('The Media Selection popover is visible but the AVKit Controls are not!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         *  Controls always shown for Audio content
         * <rdar://tsc/18110950> Controls always shown for Audio Content
         *
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        controlsAlwaysShownForAudioContent: function controlsAlwaysShownForAudioContent(args) {
            args = UIAUtilities.defaults(args, {
                contentType: 'Audio',
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToContent(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.play();
            avkitplayer.delay(5);	// Delay until the controls would not normally be visible
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.PAUSE.isVisible())) {
                throw new UIAError('The AVKit Controls are not visible for Audio Content!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should not be shown when the PiP window is visible
         * <rdar://tsc/18110957> Controls always hidden for PiP
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        controlsNotShownForPip: function controlsNotShownForPip(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(.5);
            avkitplayer.enterPip();
            avkitplayer.delay(.5);
            if (!avkitplayer.isPipVisble()) {
                throw new UIAError('The PiP window is not visible!')
            }
            if (avkitplayer.exists(UIAQuery.AVKitPlayer.PAUSE)) {
                throw new UIAError('The AVKit Controls are visible!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls always shown when entering Fullscreen if video is not playing
         * <rdar://tsc/18111018> Controls always appear when entering fullscreen while the video is not playing
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        controlsAlwaysShownWhenEnteringFullscreenWhileVideoIsPaused: function controlsAlwaysShownWhenEnteringFullscreenWhileVideoIsPaused(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.bringUpHud(); //Workaround for <rdar://problem/33457727>
            avkitplayer.pause();
            avkitplayer.enterFullScreen();
            avkitplayer.delay(5);	// Delay until the controls would not normally be visible
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY.isVisible())) {
                throw new UIAError('The AVKit Controls are not visible while video is Paused when entering Fullscreen!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should not appear when entering Fullscreen if the video is playing
         * <rdar://tsc/18110984> Controls do not appear when entering fullscreen while playing
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        controlsNotShownWhenEnteringFullscreenWhileVideoIsPlaying: function controlsNotShownWhenEnteringFullscreenWhileVideoIsPlaying(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.delay(5);	// Give the video time to play for a bit
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN.isVisible())) {
                avkitplayer.tapMediaView();
                if (avkitplayer.waitUntilPresent(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN.isVisible(), 3)) {
                    avkitplayer.tap(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN)
                }
            } else {
                avkitplayer.tap(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN)
            }
            avkitplayer.delay(.2);
            if ((avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY.isVisible())) && (avkitplayer.isInFullScreen())) {
                throw new UIAError('The AVKit Controls are visible while video is Playing when entering Fullscreen!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should always appear when exiting Fullscreen regardless of playback state
         * <rdar://tsc/18111019> Controls always appear when exiting fullscreen
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        controlsAlwaysShownWhenExitingFullscreen: function controlsAlwaysShownWhenExitingFullscreen(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.DONE.isVisible())) {
                if (avkitplayer.isInFullScreen()) {
                    avkitplayer.tapMediaView();
                    if (avkitplayer.waitUntilPresent(UIAQuery.AVKitPlayer.DONE.isVisible(), 2)) {
                        avkitplayer.tap(UIAQuery.AVKitPlayer.DONE)
                    }
                }
            } else {
                avkitplayer.tap(UIAQuery.AVKitPlayer.DONE)
            }
            avkitplayer.delay(.2);
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN.isVisible())) {
                throw new UIAError('The AVKit controls were not visible when exiting Fullscreen while the video was playing')
            }
            avkitplayer.enterFullScreen();
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.DONE.isVisible())) {
                if (avkitplayer.isInFullScreen()) {
                    avkitplayer.tapMediaView();
                    if (avkitplayer.waitUntilPresent(UIAQuery.AVKitPlayer.DONE.isVisible(), 2)) {
                        avkitplayer.tap(UIAQuery.AVKitPlayer.DONE)
                    }
                }
            } else {
                avkitplayer.tap(UIAQuery.AVKitPlayer.DONE)
            }
            avkitplayer.delay(.2);
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.ENTER_FULLSCREEN.isVisible())) {
                throw new UIAError('The AVKit controls were not visible when exiting Fullscreen while the video was paused')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should always appear when the end of the file is reached
         * <rdar://tsc/18111021> Controls appear when reaching the end of the file
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         * @param {int} args.length - Length of the movie in seconds
         */
        controlsShownAtEndOfFile: function controlsShownAtEndOfFile(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                size: 'Inline',
                length: 144
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.delay(args.length + 2);	// Add an extra 2 seconds just to make sure playback has ended
            if ((!avkitplayer.isPlaying()) && (!avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY.isVisible()))) {
                throw new UIAError('Playback has ended, but the AVKit Controls are not visible!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should disappear within 2 seconds of playback starting
         * <rdar://tsc/18111029> Controls disappear after starting playback
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        controlsDisappearAfterPlaybackStarts: function controlsDisappearAfterPlaybackStarts(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.pause();
            avkitplayer.delay(.5);
            avkitplayer.play();
            avkitplayer.delay(2);
            if (avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY.isVisible())) {
                throw new UIAError('AVKit Controls were visible 2 seconds after playback started!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Controls should always be shown while the video is paused
         * <rdar://tsc/18111039> Controls always shown while video is paused
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         * @param {string} args.size - Valid values are Fullscreen or Inline.
         */
        controlsAlwaysShownWhileVideoIsPaused: function controlsAlwaysShownWhileVideoIsPaused(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                size: 'Inline'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            if (args.size === 'Fullscreen') {
                avkitplayer.enterFullScreen();
            }
            avkitplayer.pause();
            if (avkitplayer.isPlaying()) {
                throw new UIAError('AVKit player did not pause!')
            }
            avkitplayer.delay(10);	// Delay until the controls would normally disappear
            if (!avkitplayer.exists(UIAQuery.AVKitPlayer.PLAY.isVisible())) {
                throw new UIAError('The video is paused and the AVKit Controls are not visible!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Status Bar should be visible when Video is playing and controls are visible (Fullscreen only)
         * <rdar://tsc/18470086> Status Bar visible when Video is Playing and Controls are visible
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        statusBarVisibleWhilePlayingAndControlsAreVisible: function statusBarVisibleWhilePlayingAndControlsAreVisible(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.bringUpHud();
            if (avkitplayer.inspect(UIAQuery.AVKitPlayer.STATUS_BAR).isVisible == 0) {
                throw new UIAError('The Status Bar was not visible!')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Status Bar should be hidden when Video is playing and controls are hidden (Fullscreen only)
         * <rdar://tsc/18470084> Status Bar hidden when Video is Playing and Controls are hidden
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        statusBarHiddenWhilePlayingAndControlsAreHidden: function statusBarHiddenWhilePlayingAndControlsAreHidden(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.delay(4);
            if (avkitplayer.inspect(UIAQuery.AVKitPlayer.STATUS_BAR).isVisible == 1) {
                throw new UIAError('The Status Bar was not hidden!')
            }
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Status Bar should be visible when Video is paused (Fullscreen only)
         * <rdar://tsc/18470085> Status Bar and controls visble when Video is Paused (Fullscreen only}
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        statusBarVisibleWhilePaused: function statusBarVisibleWhilePaused(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.delay(1);
            avkitplayer.bringUpHud();
            avkitplayer.delay(2);
            avkitplayer.pause();
            avkitplayer.delay(4);
            if (avkitplayer.inspect(UIAQuery.AVKitPlayer.STATUS_BAR).isVisible == 0) {
                throw new UIAError('The Status Bar was not visible!')
            }
            avkitplayer.dismissApplication();
        },

        /**
         * Status Bar should be hidden when Video is playing, controls are hidden and Volume is changed with hard buttons (Fullscreen only)
         * <rdar://tsc/18470087> Status Bar hidden when Video is Playing, Controls are hidden and Volume is changed via hard buttons
         *
         * @param {string} [args.name="Monster's University trailer"] - (Required) The Media Name
         * @param {string} args.deviceOrientation - The orientation to run the test in
         */
        statusBarHiddenWhilePlayingAndControlsAreHiddenAndVolumeChangedViaButtons: function statusBarHiddenWhilePlayingAndControlsAreHiddenAndVolumeChangedViaButtons(args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.enterFullScreen();
            avkitplayer.delay(4);
            UIATarget.localTarget().clickVolumeUp();
            if (avkitplayer.inspect(UIAQuery.AVKitPlayer.STATUS_BAR).isVisible == 1) {
                throw new UIAError('The Status Bar was visible!')
            }
            target.delay(2);
            avkitplayer.doneWithPlayback();
            avkitplayer.dismissApplication();
        },

        /**
         * Check the position of the controls in respect to the status bar
         */
        validateControlPosition: function (args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.deviceOrientation = 'Landscape';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(1);
            avkitplayer.controlsPositionedCorrectly(args);
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(1);
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.dismissApplication();
        },

        /**
         * Check the position of the controls in respect to the status bar after they have been hidden
         */
        validateControlPositionAfterHiding: function (args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.deviceOrientation = 'Landscape';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.dismissApplication();
        },

        /**
		 * Check the position of the controls when the status bar is double-height (iPad only)
         */
        validateControlPositionWithDoubleStatusBar: function (args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen',
                desiredState: 'Double'
            });
			avkitplayer.toggleStatusBarHeight(args);
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            args.statusBarState = args.desiredState;
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.deviceOrientation = 'Landscape';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.desiredState = 'Single';
            avkitplayer.toggleStatusBarHeight(args);
            avkitplayer.dismissApplication();
        },

        /**
		 * Check the position of the controls when the status bar is double-height AFTER they have been hidden (iPad only)
         */
        validateControlPositionWithDoubleStatusBarAfterHiding: function (args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen',
				desiredState: 'Double'
            });
            avkitplayer.toggleStatusBarHeight(args);
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            args.statusBarState = args.desiredState;
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.deviceOrientation = 'Landscape';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.play();
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            avkitplayer.play();
            args.deviceOrientation = 'Portrait';
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.controlsPositionedCorrectly(args);
            args.desiredState = 'Single';
            avkitplayer.toggleStatusBarHeight(args);
            avkitplayer.dismissApplication();

        },

        /**
         * Validate the presence of the expected controls in various states
         */
        validateExpectedControls: function (args) {
            args = UIAUtilities.defaults(args, {
                name: "Monster's University trailer",
                deviceOrientation: 'Portrait',
                player: 'Fullscreen'
            });
            var controlsExpected = [];
            if (target.model().includes('iPhone')) {
                controlsExpected = ['AIRPLAY', 'DONE', 'MUTE_TOGGLE', 'PLAY', 'SKIP_BACKWARD', 'SKIP_FORWARD',
                    'STATUS_BAR', 'TIME_ELAPSED', 'TIME_REMAINING', 'TRANSPORT_BAR'];
            } else {
                if (target.model().includes('iPad')) {
                    controlsExpected = ['AIRPLAY', 'DONE', 'MUTE_TOGGLE', 'PIP', 'PLAY', 'SKIP_BACKWARD',
                        'SKIP_FORWARD', 'STATUS_BAR', 'TIME_ELAPSED', 'TIME_REMAINING', 'TRANSPORT_BAR', 'VOLUME'];
                }
            }
            avkitplayer.setDeviceOrientation(args);
            avkitplayer.navigateToMedia(args);
            avkitplayer.delay(3);
            avkitplayer.pause();
            avkitplayer.checkForControls(controlsExpected);
        }
    };
