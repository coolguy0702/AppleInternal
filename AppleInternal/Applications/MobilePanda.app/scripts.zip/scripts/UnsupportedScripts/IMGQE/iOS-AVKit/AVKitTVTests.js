load('UIATesting.js');
load('UIAApp.js');
load('UIAApp+PiP.js');
load('SpringBoard.js');
load('AVKitTV.js');

UIAUtilities.assert( typeof AVKitTV === 'undefined', 'avkittv undefined' );
/**
 * @namespace AVKitTVTests
 */

var AVKitTVTests = {
    /**
     * Choose a video, pause the video, PiP the Video, play the PiP, then close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
     pausePipPlayThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        if (!avkittv.isPlaying()) {
            throw new UIAError('The video is not playing!')
        }
        target.delay(2);
        avkittv.pause();
        if (avkittv.isPlaying()) {
            throw new UIAError('The video is not paused!')
        }
        avkittv.enterPip();
        target.delay(.75);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        target.delay(2);
        avkittv.playPip();
        if (!avkittv.isPipPlaying()) {
            throw new UIAError('Video is not playing in the PiP window!')
        }
        avkittv.delay(1);
        springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.closePip();
        target.delay(1);
        if (!avkittv.didPipClose()) {
            throw new UIAError('Did not exit PiP or the video is visible!')
        }
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, play the PiP, then return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pausePipPlayThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.pause();
        if (avkittv.isPlaying()) {
            throw new UIAError('Video is not paused!')
        }
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        avkittv.delay(1);
        avkittv.playPip();
        if (!avkittv.isPipPlaying()) {
            throw new UIAError('Video is not playing in the PiP window!')
        }
        avkittv.returnFromPip();
        avkittv.delay(1);
        avkittv.bringUpHud();
        if (!avkittv.didPipReturn()) {
            throw new UIAError('Did not return from PiP or the play state was not retained!')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, then close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pausePipThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.pause();
        if (avkittv.isPlaying()) {
            throw new UIAError('Video is not paused!')
        }
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        avkittv.delay(1);
        avkittv.closePip();
        avkittv.delay(1);
        if (!avkittv.didPipClose()) {
            throw new UIAError('Did not exit PiP or the video is visible!')
        }
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, then return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pausePipThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.pause();
        if (avkittv.isPlaying()) {
            throw new UIAError('Video is not paused!')
        }
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        avkittv.delay(1);
        avkittv.returnFromPip();
        avkittv.delay(1);
        avkittv.bringUpHud();
        if (avkittv.exists(UIAQuery.AVKitTV.PIP)) {
            throw new UIAError('Did not return from PiP')
        }
        if (!avkittv.isPlaying()) {
            throw new UIAError('Playback should resume when returning from paused PiP')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Play a video, pause the video, then enter PiP mode via the Home button
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pausePipViaHome: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(.75);
        avkittv.pause();
        UIATarget.localTarget().clickMenu();
        var home_screen = target.activeApp();
        if (home_screen.exists(UIAQuery.contains(args.name))) {
            throw new UIAError('TV app is visible!')
        }
        if (avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is visible!')
        }
        // stupid workaround since I can't kill the app
        avkittv.forceQuit();
    },

    /**
     * Choose a video, PiP the Video, pause the video in the PiP window, then close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipPauseThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.enterPip();
        avkittv.delay(.75);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.delay(2);
        // springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.pausePip();
        avkittv.delay(.75);
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        avkittv.delay(2);
        springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.closePip();
        avkittv.delay(1);
        if (!avkittv.didPipClose()) {
            throw new UIAError('Did not exit PiP or the video is visible!')
        }
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, pause the video in the PiP window, then return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipPauseThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.pausePip();
        avkittv.delay(1);
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video is playing in the PiP window!')
        }
        avkittv.returnFromPip();
        avkittv.delay(1);
        if (avkittv.exists(UIAQuery.AVKitTV.PIP)) {
            throw new UIAError('Did not return from PiP')
        }
        if (!avkittv.isPlaying()) {
            throw new UIAError('Playback should resume when returning from paused PiP')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, Return, then pause
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipReturnThenPause: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.delay(1);
        if (avkittv.isPlaying()) {
            throw new UIAError('Playback should be paused, but it is not!');
        }
        avkittv.returnFromPip();
        avkittv.delay(1);
        avkittv.pause();
        if (!avkittv.didPipReturn()) {
            throw new UIAError('Did not return from PiP or the play state was not retained')
        }
        if (avkittv.isPlaying()) {
            throw new UIAError('Playback did not pause after PiP!');
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, then close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.enterPip();
        target.delay(.75);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.closePip();
        avkittv.delay(1);
        if (!avkittv.didPipClose()) {
            throw new UIAError('Did not exit Pip or the video is visible!')
        }
        avkittv.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, then return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(1);
        avkittv.enterPip();
        avkittv.delay(1);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.delay(1);
        avkittv.returnFromPip();
        avkittv.delay(1);
        avkittv.pause();
        if (!avkittv.didPipReturn()) {
            throw new UIAError('Did not return from PiP or the play state was not retained')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, pause the video, then Close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipViaHomePauseThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(1);
        UIATarget.localTarget().clickMenu();
        target.delay(.75);
        avkittv.pausePip(); // Need to pause playback to bring up the PiP controls
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.closePip();
        target.delay(.75);
        if (avkittv.isPipVisble()) {
            throw new UIAError('The PiP window did not close!')
        }
    },

    /**
     * Play a video, enter PiP mode via the Home button, pause the video, then Return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipViaHomePauseThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(1);
        UIATarget.localTarget().clickMenu();
        target.delay(.75);
        avkittv.pausePip(); // Need to pause playback to bring up the PiP controls
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        target.delay(2);
        springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.returnFromPip();
        avkittv.bringUpHud();
        if (avkittv.isPlaying()) {
            throw new UIAError('Video was playing after returning from paused PiP!')
        }
        // stupid workaround since I can't kill the app
        avkittv.quitAndLaunch();
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, then Close the PiP window
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pipViaHomeThenClose: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(1);
        UIATarget.localTarget().clickMenu();
        target.delay(1);
        avkittv.pausePip(); // Need to pause playback to bring up the PiP controls
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        avkittv.closePip();
        target.delay(1);
        if (avkittv.isPipVisble()) {
            throw new UIAError('The PiP window did not close!')
        }
    },

    /**
     * Play a video, enter PiP mode via the Home button, then Return
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     *
     * @targetApps AVKitTV
     */
    pipViaHomeThenReturn: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(1);
        UIATarget.localTarget().clickMenu();
        target.delay(2);
        springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.pausePip(); // Need to pause playback to bring up the PiP controls
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        springboard.tap(UIAQuery.contains('PIP')); // tap the PiP window to bring up the controls
        avkittv.returnFromPip();
        target.delay(2);
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Plays a video then verifies that the playback state is updated appropriately
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    playVideo: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.captureParsecScreenshot('AVKitTVIsPlaying');
        if (!avkittv.isPlaying()) {
            throw new UIAError('AVKitTV UI did not change to playing.')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Plays a video then pauses the video and verifies that the playback state is updated appropriately
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    pauseVideo: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        if (!avkittv.isPlaying()) {
            throw new UIAError('AVKitTV UI did not change to playing.')
        }
        target.delay(2);
        avkittv.pause();
        avkittv.captureParsecScreenshot('AVKitTVIsPaused');
        if (avkittv.isPlaying()) {
            throw new UIAError('AVKitTV UI did not change to paused state.')
        }
        avkittv.dismissApplication();
    },

    //Note: This test case is very fragile. I had to jump through hoops to get the controls to appear long enough
    /**
     * Scubs to the specified position (optional) then jumps forward the specified number of times.
     * Optional - scrub to a specified position before jumping
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     * @param {number} args.jumps - How many times to jump forward
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    jumpForward: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            jumps: 3,
            direction: 'Forward',
            position: '0.0',
            state: 'Play'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.scrubCurrentPosition(args);
        avkittv.pause();
        avkittv.bringUpHud();
        var startTime = avkittv.getElapsedTime();
        if (args.state === 'Play') {
            avkittv.play();
        }
        avkittv.jump(args);
        avkittv.bringUpHud();	//Workaround for <rdar://problem/33457727> [automation only] Controls not visible while video is paused
        avkittv.pause();
        var endTime = avkittv.getElapsedTime();
        startTime = avkittv.incrementTime(args.jumps, startTime);
        if (!endTime >= startTime) {
            throw new UIAError('The end time was expected to be greater than or equal to the start time + (# of jumps * 15 [seconds])');
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Scrubs to the specified position (optional) then jumps backward the specified number of times.
     * <rdar://tsc/15446989> Jump Forward/Backward
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     * @param {number} args.jumps - How many times to jump backward
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    jumpBackward: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            jumps: 3,
            direction: 'Backward',
            position: '0.0',
            state: 'Play'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.scrubCurrentPosition(args);
        if (args.state === 'Pause') {
            avkittv.pause();
            avkittv.bringUpHud();	//Workaround for <rdar://problem/33457727>
        } else {
            avkittv.bringUpHud();
        }
        var startTime = avkittv.getElapsedTime();
        avkittv.jump(args);
        avkittv.bringUpHud();	//Workaround for <rdar://problem/33457727>
        var endTime = avkittv.getElapsedTime();
        startTime = avkittv.decrementTime(args.jumps, startTime);
        if (!startTime >= endTime) {
            throw new UIAError('The end time was expected to be less than or equal to the start time - (# of jumps * 15 [seconds])');
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Scrub on the transport bar to a certain position
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    scrubToPosition: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            position: '0.5',
            allowImpreciseScrubbing: true
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.bringUpHud();
        avkittv.scrubCurrentPosition(args);
        avkittv.assertValueForCurrentPosition(args);
        avkittv.captureParsecScreenshot('AVKitTVScrub');
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Scrub media back and forth
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.begin="0.2" - (Required) A double between 0 and 1 to set the lower volume level
     * @param {string} args.end="0.8" - (Required) A double between 0 and 1 to set the higher volume level
     */
    scrubBackAndForth: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            begin: '0.2',
            end: '0.8'
        });
        avkittv.navigateToMedia(args);
        avkittv.setDeviceOrientation(args);
        var options = {
            position: "0.5"
        };
        avkittv.scrubCurrentPosition(options);
        options.position = args.begin;
        avkittv.scrubCurrentPosition(options);
        avkittv.captureParsecScreenshot('AVKitTVScrubbing1');
        options.position = args.end;
        avkittv.scrubCurrentPosition(options);
        avkittv.captureParsecScreenshot('AVKitTVScrubbing2');
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Sets the volume to the specified volumeLevel
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.volumeLevel - A double between 0 and 1 to set the volume level
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    setVolume: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            volumeLevel: '0.5'
        });
        UIALogger.logWarning('This test currently fails due to <rdar://problem/33187672> setControl not setting volume to specified level');
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.pause();
        avkittv.setVolume(args);
        avkittv.assertValueForVolume(args);
        avkittv.captureParsecScreenshot('AVKitTVSetVolume');
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    // TODO: Ask Felix how to verify rotation
    /**
     * Rotate device
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    rotation: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(2);
        args.deviceOrientation = "Landscape";
        avkittv.setDeviceOrientation(args);
        avkittv.captureParsecScreenshot("Landscape");
        avkittv.delay(2);
        args.deviceOrientation = "Portrait";
        avkittv.setDeviceOrientation(args);
        avkittv.captureParsecScreenshot("Portrait");
        avkittv.delay(2);
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Change Aspect Ratio - can't be verified via UIAutomation
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    changeAspectRatio: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.changeAspectRatio();
        avkittv.captureParsecScreenshot("AspectRatioFullScreen");
        avkittv.delay(2);
        // change to widescreen
        avkittv.changeAspectRatio();
        avkittv.captureParsecScreenshot("AspectRatioWideScreen");
        avkittv.delay(2);
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },


    /**
     * Controls should not be shown when the PiP window is visible
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    controlsNotShownForPip: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(.5);
        avkittv.enterPip();
        avkittv.delay(.5);
        if (!avkittv.isPipVisble()) {
            throw new UIAError('The PiP window is not visible!')
        }
        if (avkittv.exists(UIAQuery.AVKitTV.PAUSE)) {
            throw new UIAError('The AVKit Controls are visible!')
        }
        avkittv.dismissApplication();
    },

    /**
     * Controls should disappear within 2 seconds of playback starting
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    controlsDisappearAfterPlaybackStarts: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(2);
        avkittv.pause();
        avkittv.play();
        avkittv.delay(2);
        if (avkittv.exists(UIAQuery.AVKitTV.PLAY.isVisible())) {
            throw new UIAError('AVKit Controls were visible 2 seconds after playback started!')
        }
        target.delay(2);
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Controls should always be shown while the video is paused
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    controlsAlwaysShownWhileVideoIsPaused: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.pause();
        if (avkittv.isPlaying()) {
            throw new UIAError('AVKit player did not pause!')
        }
        avkittv.delay(10);	// Delay until the controls would normally disappear
        if (!avkittv.exists(UIAQuery.AVKitTV.PLAY.isVisible())) {
            throw new UIAError('The video is paused and the AVKit Controls are not visible!')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is playing and controls are visible
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    statusBarVisibleWhilePlayingAndControlsAreVisible: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        target.delay(2);
        avkittv.bringUpHud();
        if (avkittv.inspect(UIAQuery.AVKitTV.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Status Bar should be hidden when Video is playing and controls are hidden
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    statusBarHiddenWhilePlayingAndControlsAreHidden: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(4);
        if (avkittv.inspect(UIAQuery.AVKitTV.STATUS_BAR).isVisible == 1) {
            throw new UIAError('The Status Bar was not hidden!')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is paused
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     */
    statusBarVisibleWhilePaused: function statusBarVisibleWhilePaused(args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(2);
        avkittv.pause();
        avkittv.delay(4);
        if (avkittv.isPipPlaying()) {
            throw new UIAError('Video did not pause!')
        }
        if (avkittv.inspect(UIAQuery.AVKitTV.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Check the position of the controls in respect to the status bar
     */
    validateControlPosition: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.deviceOrientation = 'Landscape';
        avkittv.setDeviceOrientation(args);
        avkittv.delay(1);
        avkittv.controlsPositionedCorrectly(args);
        args.deviceOrientation = 'Portrait';
        avkittv.setDeviceOrientation(args);
        avkittv.delay(1);
        avkittv.controlsPositionedCorrectly(args);
        avkittv.doneWithPlayback();
        avkittv.dismissApplication();
    },

    /**
     * Check the position of the controls in respect to the status bar after they have been hidden
     */
    validateControlPositionAfterHiding: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.deviceOrientation = 'Landscape';
        avkittv.setDeviceOrientation(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        args.deviceOrientation = 'Portrait';
        avkittv.setDeviceOrientation(args);
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        avkittv.dismissApplication();
    },

    /**
     * Check the position of the controls when the status bar is double-height (iPad only)
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    validateControlPositionWithDoubleStatusBar: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            desiredState: 'Double'
        });
        avkittv.toggleStatusBarHeight(args);
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(3);
        avkittv.pause();
        args.statusBarState = args.desiredState;
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.deviceOrientation = 'Landscape';
        avkittv.setDeviceOrientation(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        args.deviceOrientation = 'Portrait';
        avkittv.setDeviceOrientation(args);
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.desiredState = 'Single';
        avkittv.toggleStatusBarHeight(args);
        avkittv.dismissApplication();
    },

    /**
     * Check the position of the controls when the status bar is double-height AFTER they have been hidden (iPad only)
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    validateControlPositionWithDoubleStatusBarAfterHiding: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait',
            desiredState: 'Double'
        });
        avkittv.toggleStatusBarHeight(args);
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(3);
        avkittv.pause();
        args.statusBarState = args.desiredState;
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.deviceOrientation = 'Landscape';
        avkittv.setDeviceOrientation(args);
        avkittv.play();
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        avkittv.play();
        args.deviceOrientation = 'Portrait';
        avkittv.setDeviceOrientation(args);
        avkittv.delay(3);
        avkittv.pause();
        avkittv.controlsPositionedCorrectly(args);
        args.desiredState = 'Single';
        avkittv.toggleStatusBarHeight(args);
        avkittv.dismissApplication();

    },

    /**
     * Validate the presence of the expected controls in various states
     *
     * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
     * @param {string} args.name: name of the media
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    validateExpectedControls: function (args) {
        args = UIAUtilities.defaults(args, {
            type: 'Home Videos',
            name: 'Captain_America',
            deviceOrientation: 'Portrait'
        });
        var controlsExpected = [];
        if (target.model().includes('iPhone')) {
            controlsExpected = ['AIRPLAY', 'DONE', 'PLAY', 'SKIP_BACKWARD', 'SKIP_FORWARD', 'STATUS_BAR', 
                'TIME_ELAPSED', 'TIME_REMAINING', 'TRANSPORT_BAR'];
        } else {
            if (target.model().includes('iPad')) {
                controlsExpected = ['AIRPLAY', 'DONE', 'PIP', 'PLAY', 'SKIP_BACKWARD', 'SKIP_FORWARD', 
                    'STATUS_BAR', 'TIME_ELAPSED', 'TIME_REMAINING', 'TRANSPORT_BAR', 'VOLUME'];
            }
        }
        avkittv.setDeviceOrientation(args);
        avkittv.navigateToMedia(args);
        avkittv.delay(3);
        avkittv.pause();
        avkittv.checkForControls(controlsExpected);
    }
};
