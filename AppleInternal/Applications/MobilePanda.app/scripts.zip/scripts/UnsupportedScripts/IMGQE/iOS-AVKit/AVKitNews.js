load('News.js');
load('SafariTests.js');
load('SpringBoard.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common AVKit queries */
UIAQuery.AVKitNews = {
    /** Fullscreen controls Done button */
    DONE: UIAQuery.buttons('Done'),

    /** Full screen button */
    ENTER_FULLSCREEN: UIAQuery.buttons('Full Screen'),

    /** Alternate Languages button */
    MEDIA_SELECTION: UIAQuery.buttons('Media selection'),

    /** Done button for Media Selection window */
    MEDIA_SELECTION_DONE: UIAQuery.buttons('right-nav-button'),

    /** Mute Toggle */
    MUTETOGGLE: UIAQuery.contains('Mute'),

    /** pause button */
    PAUSE: UIAQuery.buttons('Pause'),

    /** Play button */
    PLAY: UIAQuery.buttons('Play'),

    /** Video playback view. */
    PLAYBACK_VIEW: UIAQuery.contains('AVPlayerViewControllerContentView'),

    /** Fullscreen controls Rewind button */
    SKIP_BACKWARD: UIAQuery.buttons('Skip Backward'),

    /** Fullscreen controls Fast Forward button */
    SKIP_FORWARD: UIAQuery.buttons('Skip Forward'),

    /** Status Bar */
    STATUS_BAR: UIAQuery.contains('UIStatusBarWindow'),

    /** Time Elapsed control */
    TIME_ELAPSED: UIAQuery.contains('Time Elapsed'),

    /** Time Remaining control */
    TIME_REMAINING: UIAQuery.contains('Time Remaining'),

    /** Transport bar*/
    TRANSPORT_BAR: UIAQuery.sliders('Current position'),

    /** The UI Window */
    UI_WINDOW: UIAQuery.windows('UIWindow'),

    /** Volume slider*/
    VOLUME: UIAQuery.sliders('Volume'),

    /** Zoom button */
    ZOOM: UIAQuery.buttons('Zoom')
};

var avkitnews = news;

/**
 * Verifies the movie was scrubbed to the value specified.
 * @param {string} options.position - The position you are expecting playback to be at in a double (expressed as a string) ('0.5' for 50%)
 * @param {boolean} options.allowImpreciseScrubbing - Allow the test to pass if the position falls within +/- 10 seconds of the desired position
 *
 * @return {None} - throws if option.position is not equal to the current value of the transport bar
 */
avkitnews.assertValueForCurrentPosition = function assertValueForCurrentPosition(options) {
    if (!options.position) {
        throw new UIAError('Need to assert the current position is equal to something. Please specify the position we are comparing to.')
    } else {
        position = options.position
    }
    // The slider returns a string representation of the elapsed time, for example '1:30' for 1 minute and 30 seconds
    var currentPositionTimeString = this.inspect(UIAQuery.AVKitNews.TRANSPORT_BAR).value;
    var args = {
        type: 'seconds',
        timeString: currentPositionTimeString
    };
    var currentSeconds = this.convertTimeString(args); // Convert current position to seconds
    // To determine the percentage of playback, we need to get the total length of the video
    this.bringUpHud();
    args = {position: '0.0'};
    this.scrubCurrentPosition(args);
    var totalLength = this.inspect(UIAQuery.AVKitNews.TIME_REMAINING).label.slice(2);
    // Convert the total length to seconds
    args = {
        type: 'seconds',
        timeString: totalLength
    };
    var totalSeconds = this.convertTimeString(args);
    var expectedSeconds = totalSeconds * parseFloat(position);
    if (options.allowImpreciseScrubbing === true) {
        if ((currentSeconds < expectedSeconds - 10) || (currentSeconds > expectedSeconds + 10)) {
            throw new UIAError('The scrub position is outside of the acceptable range! Current Position: ' +
                this.convertSecondsToString(currentSeconds) + ' Expected Position: ' + this.convertSecondsToString(expectedSeconds))
        }
    } else {
        if (!(currentSeconds === expectedSeconds)) {
            throw new UIAError('The scrub position does not match the expected position! Current Position: ' +
                this.convertSecondsToString(currentSeconds) + ' Expected Position: ' + this.convertSecondsToString(expectedSeconds))
        }
    }
};

/*
 * Validate the state of the Mute button
 * @param {string} desiredState - Valid values are Mute or Unmute. If you can hear sound, the state is Mute.
 *
 * @return {None}
 */
avkitnews.assertValueForMute = function assertValueForMute(desiredState) {
    if (!desiredState) {
        throw new UIError('You need to specify the state you expect the button to be in')
    }
    var currentState = this.inspect(UIAQuery.AVKitNews.MUTETOGGLE).label;
    if (!currentState === desiredState) {
        throw new UIError('The desired state is "' + desiredState + '" but the current state is "' + currentState + '"')
    } else {
        UIALogger.logMessage('The Mute button is in the desired state!')
    }
};

/**
 * Compares the movie volume to the value specified.
 * @param {string} options.volumeLevel - The volumeLevel you are expecting the volume slider to be as a percentage. ex. 0%
 *
 * @return {None} - throws if options.volumeLevel is not equal to the current value of the volume slider
 */
avkitnews.assertValueForVolume = function assertValueForVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Need to assert the volume level is equal to something. Please specify the volume level we are comparing to.')
    }
    if (!this.exists(UIAQuery.AVKitNews.VOLUME.isVisible())) {
        this.tapMediaView();
        this.touchAndHold(UIAQuery.AVKitNews.MUTETOGGLE)
    }
    if (!this.waitUntilPresent(UIAQuery.AVKitNews.VOLUME.isVisible(), .2)) {
        throw new UIAError('The Volume slider should be visible, but it is not!')
    }
    var currentVolume = this.inspect(UIAQuery.AVKitNews.VOLUME).value;
    // allow some error on UI due to existing bug
    if (currentVolume > (parseFloat(options.volumeLevel) * 100 + 10).toString() + '%' ||
        currentVolume < (parseFloat(options.volumeLevel) * 100 - 10).toString() + '%') {
        throw new UIAError('The volume was expected to be at ' + (parseFloat(options.volumeLevel) * 100).toString() + '% but was at ' + currentVolume)
    }
};


/**
 * Bring up the HUD
 */
avkitnews.bringUpHud = function bringUpHud() {
    this.delay(1.5);
    this.tapMediaView();
    this.waitUntilPresent(UIAQuery.AVKitNews.MUTETOGGLE.isVisible(), .5);
};

avkitnews.changeAspectRatio = function changeAspectRatio() {
    this.doubleTap(UIAQuery.AVKitNews.PLAYBACK_VIEW)};


/**
 * Convert seconds to a time string
 * @param {int} seconds
 *
 */
avkitnews.convertSecondsToString = function convertSecondsToString(seconds) {
    // multiply by 1000 because Date() requires miliseconds
    var date = new Date(seconds * 1000);
    var hh = date.getUTCHours();
    var mm = date.getUTCMinutes();
    var ss = date.getSeconds();

    if (parseInt(ss) < 10) {
        ss = '0' + ss
    }
    var timeString = '';
    if (!hh === '0') {
        timeString = hh + ":" + mm + ":" + ss;
    } else {
        timeString = mm + ":" + ss;
    }
    return timeString
};

/**
 * Convert a time string to either seconds or a date object
 *
 * @param {string} options.type - Valid values are 'seconds' or 'date'
 * @param {string} options.timeString - the text string containing a time
 */
avkitnews.convertTimeString = function convertTimeString(options) {
    if ((!options.type === 'seconds') && (!options.type === 'date')) {
        throw new UIAError('options.type must be either "seconds" or "date"');
    }
    if (!options.timeString) {
        throw new UIAError('A time string must be provided');
    }
    if (options.timeString.indexOf(':') === -1) {
        throw new UIAError('The string provided is not a proper time string');
    }

    var parts = options.timeString.split(':');
    var minutes = seconds = hours = 0;

    switch(options.type) {
        case 'seconds':
            var total_seconds = 0;
            if (parts.length === 3) {
                hours = parts[0];
                minutes = parts[1];
                seconds = parts[2];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60) + (parseInt(hours, 10) * 60 * 60);
            } else {
                minutes = parts[0];
                seconds = parts[1];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60);
            }
            return total_seconds;
        case 'date':
            var date = new Date();
            if (parts.length === 3) {
                date.setHours(parts[0]);
                date.setMinutes(parts[1]);
                date.setSeconds(parts[2]);

            } else {
                date.setHours(0);
                date.setMinutes(parts[0]);
                date.setSeconds(parts[1]);
            }
            return date
    }
};

/**
 * Decrement the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to decrement
 *
 * @returns {object} elapsedTime - the new decremented time
 */
avkitnews.decrementTime = function decrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() - (jumpSeconds + 10));

    return elapsedTime
};

/**
 * Get the length of a Video
 *
 * @returns {int} - length of video
 */
avkitnews.determineVideoLength = function determineVideoLength() {
    // To determine the percentage of playback, we need to get the total length of the video
    avkitnews.bringUpHud();
    args = {position: '0.0'};
    avkitnews.scrubCurrentPosition(args);
    avkitnews.bringUpHud();
    var totalLength = this.inspect(UIAQuery.AVKitNews.TIME_REMAINING).label.slice(2);
    // Convert the total length to seconds
    args = {
        type: 'seconds',
        timeString: totalLength

    };
    return avkitnews.convertTimeString(args);
};

avkitnews.dismissApplication = function dismissApplication() {
    target.performTask('/usr/bin/killall', ['News'], 5);
};

/**
 * Either exit fullscreen or press the Pause button
 */
avkitnews.doneWithPlayback = function doneWithPlayback() {
    if (this.isInFullScreen()){
        this.tapMediaView();
        this.tap(UIAQuery.AVKitNews.DONE);
    } else {
        this.tapMediaView();
        this.tap(UIAQuery.AVKitNews.PAUSE);
    }
};

/**
 * Enter Fullscreen playback from inline playback
 *
 * @returns {None} - Throws an error if the UI is not in Fullscreen playback at the end of this method.
 */
avkitnews.enterFullScreen = function enterFullScreen() {
    if (!this.exists(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible())) {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible(), 1)) {
            this.tap(UIAQuery.AVKitNews.ENTER_FULLSCREEN)
        }
    } else {
        this.tap(UIAQuery.AVKitNews.ENTER_FULLSCREEN)
    }
    if (!this.isInFullScreen()) {
        throw new UIAError('Failed to enter fullscreen.')
    }
};

/**
 * Exit Fullscreen playback to inline playback. Playback should stop upon exiting fullscreen.
 *
 * @returns {None} - Throws an error if the UI is in Fullscreen playback or the video is playing at the end of this method.
 */
avkitnews.exitFullScreen = function exitFullScreen() {
    if (!this.exists(UIAQuery.AVKitNews.DONE.isVisible())) {
        if (this.isInFullScreen()) {
            this.tapMediaView();
            if (this.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 2)) {
                this.tap(UIAQuery.AVKitNews.DONE)
            }
        }
    } else {
        this.tap(UIAQuery.AVKitNews.DONE)
    }
    if (this.isInFullScreen()) {
        throw new UIAError('Failed to exit fullscreen.')
    }
    if (this.isPlaying()) {
        throw new UIAError('Video stilling playing after exiting fullscreen.')
    }
};

/**
 * Get the current elapsed time (text) and convert it to a date object
 *
 * @returns {object} - the elapsed time as a date object
 */
avkitnews.getElapsedTime = function getElapsedTime() {
    var elapsedTime = this.inspect(UIAQuery.AVKitNews.TIME_ELAPSED).label;
    var options = {
        type: 'date',
        timeString: elapsedTime
    };
    elapsedTime = this.convertTimeString(options);

    return elapsedTime
};

/**
 * Get the difference between 2 times
 * @param {object} options.time1 - the 1st time (should be the smaller time)
 * @param {object} options.time2 - the 2nd time (should be the larger time)
 *
 * @returns {object} - the difference between the 2 times
 */
avkitnews.getTimeDiff = function getTimeDiff(options) {
    if (!options.time1 && options.time2) {
        throw new UIAError('2 times must be provided')
    }
    var hours = date2.getHours() - date1.getHours();
    var minutes = date2.getMinutes() - date1.getMinutes();
    var seconds = date2.getSeconds() - date1.getSeconds();

    var diff = new Date();
    diff.setHours(hours);
    diff.setMinutes(minutes);
    diff.setSeconds(seconds);

    return diff
};

/**
 * Increment the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to increment
 *
 * @returns {object} elapsedTime - the new incremented time
 */
avkitnews.incrementTime = function incrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() + jumpSeconds);

    return elapsedTime
};

/**
 * Checks to see if the playback UI indicates that the video is in fullscreen.
 *
 * @returns {Boolean} True if the playback UI indicates that the video is in fullscreen, false otherwise.
 */
avkitnews.isInFullScreen = function isInFullScreen() {
    if (!this.exists(UIAQuery.AVKitNews.DONE.isVisible())) {
        this.tapMediaView();
    }
    return !!this.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 2);
};

/**
 * Checks to see if the playback UI indicates thtat the video is playing.
 *
 * @returns {Boolean} True if the playback UI indicates that the video is playing and false otherwise.
 */
avkitnews.isPlaying = function isPlaying() {
    if (this.exists(UIAQuery.AVKitNews.MUTETOGGLE.isVisible()) && this.exists(UIAQuery.AVKitNews.PLAY.isVisible())) {
        return false;
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitNews.MUTETOGGLE.isVisible(), 2)) {
            return !(this.exists(UIAQuery.AVKitNews.ENTER_FULLSCREEN.isVisible()) &&
                this.exists(UIAQuery.AVKitNews.PLAY.isVisible()));
        }
    }
};

/**
 * Jump X number of times in Y direction, i.e. Tap the specified "Jump" button the specified number of times
 * @param {number} options.jumps - how many times to press the button
 * @param {string} options.direction - Valid valids are 'Forward' and 'Backward'
 * @returns {None} - Throws if either option is empty or invalid
 */
avkitnews.jump = function jump(options) {
    if (!options.jumps) {
        throw new UIAError('Plese specify how many times to jump.');
    }
    if ((!options.direction === 'Forward') || (!options.direction ==='Backward')) {
        throw new UIAError('You must specify Forward or Backward for direction')
    }
    this.bringUpHud();
    if (!this.exists(UIAQuery.AVKitNews.SKIP_FORWARD.isVisible())) {
        throw new UIAError('Skip Forward not visible!')
    } else {
        for (i = 0; i < options.jumps; i++) {
            try {
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitNews.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitNews.SKIP_BACKWARD)
                }
            }
            catch (err) {
                this.bringUpHud();
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitNews.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitNews.SKIP_BACKWARD)
                }
            }
        }
    }
};

/**
 * Tap the play button.
 *
 * @returns {None}
 */
avkitnews.play = function play() {
    if (this.exists(UIAQuery.AVKitNews.PLAY.isVisible())) {
        this.tap(UIAQuery.AVKitNews.PLAY)
    } else if (!this.exists(UIAQuery.AVKitNews.PAUSE.isVisible())) {
        this.tapMediaView();
    }
    if (this.waitUntilPresent(UIAQuery.AVKitNews.PLAY.isVisible(), 2)) {
        this.tap(UIAQuery.AVKitNews.PLAY)
    }
};

/**
 * Scrubs the movie to the value specified.
 * @param {double} options.position - The position in the movie to scrub to
 *
 * @return {None}
 */
avkitnews.scrubCurrentPosition = function scrubCurrentPosition(options){
    if (!options.position) {
        throw new UIAError('Please specify the new position to scrub to.');
    }
    this.tapMediaView();
    if (this.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 1)) {
        this.setControl(UIAQuery.AVKitNews.TRANSPORT_BAR, parseFloat(options.position));
        }
};

/**
 * Tap the pause button. Note: The pause button is not visible for very long, so I just try to tap it
 * without checking to see if it is there. If that fails, i.e. tapping on the screen hid the control
 * instead of showing it, I try again. I try twice because it would regularly fail to
 * pause on the 'Pirates of the Caribbean' video.
 *
 * @returns {None}
 */
avkitnews.pause = function pause() {
    target.delay(2);
    this.tapMediaView();
    this.tap(UIAQuery.AVKitNews.PAUSE);
    if (this.isPlaying()) {
        throw new UIAError ('Video failed to pause when Pause was tapped');
    }
};


/**
 * Play a Video in News
 * @param args
 */
avkitnews.playVideo = function PlayVideo(args) {
    this.dismissApplication();
    var openAlert = UIAQuery.contains('Open this page');
    safari.handlingAlertsInline(openAlert, function() {
        this.enterURL(args.URL);
        this.tap(UIAQuery.buttons('Open'));
    });

    target.delay(1);
    var locationAlert = UIAQuery.contains('Allow "News" to access your location');
    if (this.exists(locationAlert)) {
        this.handlingAlertsInline(locationAlert, function () {
            this.tap(UIAQuery.buttons('Allow'));
        });
    }
    this.play();
};

/**
 * Selects audio and subtitles
 * @param {string} options.audio - The audio to choose
 * @param {string} options.subtitles - The subtitles to choose

 * @returns {None} - Throws if the media selection option specified does not exist.
 */
avkitnews.selectAudioAndSubtitles = function selectAudioAndSubtitles (options) {
    if (!options.subtitles) {
        throw new UIAError('No subtitles for me to select.');
    }
    this.tapMediaView();
    this.tap(UIAQuery.AVKitNews.MEDIA_SELECTION);
    if (options.audio) {
        if (this.scrollToVisibleIfExists(UIAQuery.contains(options.audio).above(UIAQuery.contains("SUBTITLES & CC")))) {
            this.tap(UIAQuery.contains(options.audio).above(UIAQuery.contains("SUBTITLES & CC")))
        } else {
            throw new UIAError('The audio you specified does not exist for this movie.')
        }
    }
    if (this.scrollToVisibleIfExists(UIAQuery.contains(options.subtitles).below(UIAQuery.contains("SUBTITLES & CC")))) {
        this.tap(UIAQuery.contains(options.subtitles).below(UIAQuery.contains("SUBTITLES & CC")))
    } else {
        throw new UIAError('The subtitles you specified does not exist for this movie.')
    }
    // iPhone has a 'Done' button but iPad has 'right-nav button'
    if (this.exists(UIAQuery.AVKitNews.DONE.isVisible())) {
        this.tap(UIAQuery.AVKitNews.DONE);
    } else {
        if (this.exists(UIAQuery.AVKitNews.MEDIA_SELECTION_DONE.isVisible())) {
            this.tap(UIAQuery.AVKitNews.MEDIA_SELECTION_DONE);
        }
    }
};

/**
 * Change orientation to Landscape or Portrait as defined by the test.
 * @param {string} options.deviceOrientation - The device orientation to change to
 *
 * @return {None}
 */
avkitnews.setDeviceOrientation = function setDeviceOrientation(options) {
    if (options.deviceOrientation === 'Landscape') {
        target.setDeviceOrientation(UIADeviceOrientation.LANDSCAPE_RIGHT);
    } else {
        target.setDeviceOrientation(UIADeviceOrientation.PORTRAIT);
    }
};

/**
 * Toggle Mute on or off
 * If you can hear sound, mute is OFF (and the label will read 'Mute'). When ON, the label reads 'Unmute'.
 *
 * @param {string} args.mute - Valid values are ON or OFF.
 *
 * @return {None}
 */
avkitnews.setMuteState = function setMuteState(args) {
    if (!args.mute) {
        throw new UIAError('Please specify the desired mute state');
    }
    if (!args.mute === 'ON' && !args.mute === 'OFF'){
        throw new UIAError("'ON' and 'OFF' are the only acceptable arguments")
    }
    /* Note: if mute is OFF, the label will read 'Mute'. If mute is ON, the labe will read 'Unmute' */
    var currentState = this.inspect(UIAQuery.AVKitNews.MUTETOGGLE).label;
    UIALogger.logMessage('The current state is: ' + currentState);
    switch(currentState) {
        case 'Mute':
            switch(args.mute){
                case 'ON':
                    if (this.isPlaying()) {
                        this.bringUpHud();
                    }
                    this.tap(UIAQuery.AVKitNews.MUTETOGGLE);
                    this.assertValueForMute('Unmute');
                    break;
                case 'OFF':
                    if (this.isPlaying()) {
                        this.bringUpHud();
                    }
                    this.assertValueForMute('Mute');
                    break; // Volume is already muted
            }
            break;
        case 'Unmute':
            switch(args.mute){
                case 'ON':
                    if (this.isPlaying()) {
                        this.bringUpHud();
                    }
                    this.assertValueForMute('Mute');
                    break; // Volume is already muted
                case 'OFF':
                    if (this.isPlaying()) {
                        this.bringUpHud();
                    }
                    this.tap(UIAQuery.AVKitNews.MUTETOGGLE);
                    this.assertValueForMute('Unmute');
                    break;
            }
            break;
        case 'Volume':
            throw new UIAError('Label reads "Volume". How did it get into that state?')
    }
};

/**
 * Sets the volume via the ui to the specified value.
 * @param {double} options.volumeLevel - The volume leve to set the volume to
 *
 * @return {None}
 */
avkitnews.setVolume = function setVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Please specify the volume level you wish to set the volume to.');
    }
    if (this.exists(UIAQuery.AVKitNews.MUTETOGGLE.isVisible())){
        this.touchAndHold(UIAQuery.AVKitNews.MUTETOGGLE, 1)
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitNews.DONE.isVisible(), 1)) {
            this.touchAndHold(UIAQuery.AVKitNews.MUTETOGGLE, 1);
            this.setControl(UIAQuery.AVKitNews.VOLUME, parseFloat(options.volumeLevel));
        }
    }
};

avkitnews.tapMediaView = function tapMediaView(){
    if (this.exists(UIAQuery.AVKitNews.PLAYBACK_VIEW)) {
        this.tap(UIAQuery.AVKitNews.PLAYBACK_VIEW);
    }
};
