load('UIATesting.js');
load('UIAApp.js');
load('SpringBoard.js');
load('Safari.js');

UIAQuery.AVKitSafari = {
    /** Fullscreen controls Done button */
    DONE: UIAQuery.buttons('Done'),

    /** Mute Toggle */
    MUTETOGGLE: UIAQuery.contains('Mute'),

    /** pause button */
    PAUSE: UIAQuery.buttons('Pause'),

    /** Picture in Picture button */
    PIP: UIAQuery.buttons('Picture In Picture'),

    /** Play button */
    PLAY: UIAQuery.buttons('Play'),

    /** Video playback view. */
    PLAYBACK_VIEW: UIAQuery.contains('Video'),

    /** Fullscreen controls Rewind button */
    SKIP_BACKWARD: UIAQuery.buttons('Skip Backward'),

    /** Fullscreen controls Fast Forward button */
    SKIP_FORWARD: UIAQuery.buttons('Skip Forward'),

    /** Status Bar */
    STATUS_BAR: UIAQuery.contains('UIStatusBarWindow'),

    /** Time Elapsed control */
    TIME_ELAPSED: UIAQuery.contains('Time Elapsed'),

    /** Time Remaining control */
    TIME_REMAINING: UIAQuery.contains('Time Remaining'),

    /** Image to press to start the trailer playing */
    TRAILER: UIAQuery.images().contains("Trailer").leftmost(),

    /** Transport bar*/
    TRANSPORT_BAR: UIAQuery.sliders('Current position'),

    /** The UI Window */
    UI_WINDOW: UIAQuery.windows('UIWindow'),

    /** Volume slider*/
    VOLUME: UIAQuery.sliders('Volume'),

    /** Zoom button */
    ZOOM: UIAQuery.buttons('Zoom')
};

var avkitsafari = safari;

/**
 * Verifies the movie was scrubbed to the value specified.
 * @param {string} options.position - The position you are expecting playback to be at in a double (expressed as a string) ('0.5' for 50%)
 * @param {boolean} options.allowImpreciseScrubbing - Allow the test to pass if the position falls within +/- 10 seconds of the desired position
 *
 * @return {None} - throws if option.position is not equal to the current value of the transport bar
 */
avkitsafari.assertValueForCurrentPosition = function assertValueForCurrentPosition(options) {
    if (!options.position) {
        throw new UIAError('Need to assert the current position is equal to something. Please specify the position we are comparing to.')
    } else {
        position = options.position
    }
    // The slider returns a string representation of the elapsed time, for example '1:30' for 1 minute and 30 seconds
    var currentPositionTimeString = this.inspect(UIAQuery.AVKitSafari.TRANSPORT_BAR).value;
    var args = {
        type: 'seconds',
        timeString: currentPositionTimeString
    };
    var currentSeconds = avkitsafari.convertTimeString(args); // Convert current position to seconds
    // To determine the percentage of playback, we need to get the total length of the video
    avkitsafari.bringUpHud();
    args = {position: '0.0'};
    avkitsafari.scrubCurrentPosition(args);
    var totalLength = this.inspect(UIAQuery.AVKitSafari.TIME_REMAINING).label.slice(2);
    // Convert the total length to seconds
    args = {
        type: 'seconds',
        timeString: totalLength
    };
    var totalSeconds = avkitsafari.convertTimeString(args);
    var expectedSeconds = totalSeconds * parseFloat(position);
    if (options.allowImpreciseScrubbing === true) {
        if ((currentSeconds < expectedSeconds - 10) || (currentSeconds > expectedSeconds + 10)) {
            throw new UIAError('The scrub position is outside of the acceptable range! Current Position: ' +
                avkitsafari.convertSecondsToString(currentSeconds) + ' Expected Position: ' + avkitsafari.convertSecondsToString(expectedSeconds))
        }
    } else {
        if (!(currentSeconds === expectedSeconds)) {
            throw new UIAError('The scrub position does not match the expected position! Current Position: ' +
                avkitsafari.convertSecondsToString(currentSeconds) + ' Expected Position: ' + avkitsafari.convertSecondsToString(expectedSeconds))
        }
    }
};

/*
 * Validate the state of the Mute button
 * @param {string} desiredState - Valid values are Mute or Unmute. If you can hear sound, the state is Mute.
 *
 * @return {None}
 */
avkitsafari.assertValueForMute = function assertValueForMute(desiredState) {
    if (!desiredState) {
        throw new UIError('You need to specify the state you expect the button to be in')
    }
    this.bringUpHud();
    var currentState = this.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).label;
    if (!currentState === desiredState) {
        throw new UIError('The desired state is "' + desiredState + '" but the current state is "' + currentState + '"')
    } else {
        UIALogger.logMessage('The Mute button is in the desired state!')
    }
};

/**
 * Compares the movie volume to the value specified.
 * @param {string} options.volumeLevel - The volumeLevel you are expecting the volume slider to be as a percentage. ex. 0%
 *
 * @return {None} - throws if options.volumeLevel is not equal to the current value of the volume slider
 */
avkitsafari.assertValueForVolume = function assertValueForVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Need to assert the volume level is equal to something. Please specify the volume level we are comparing to.')
    }
    if (!this.exists(UIAQuery.AVKitSafari.VOLUME.isVisible())) {
        this.tapMediaView();
        this.touchAndHold(UIAQuery.AVKitSafari.MUTETOGGLE)
    }
    if (!this.waitUntilPresent(UIAQuery.AVKitSafari.VOLUME.isVisible(), .2)) {
        throw new UIAError('The Volume slider should be visible, but it is not!')
    }
    var currentVolume = this.inspect(UIAQuery.AVKitSafari.VOLUME).value;
    // allow some error on UI due to existing bug
    if (currentVolume > (parseFloat(options.volumeLevel) * 100 + 10).toString() + '%' ||
        currentVolume < (parseFloat(options.volumeLevel) * 100 - 10).toString() + '%') {
        throw new UIAError('The volume was expected to be at ' + (parseFloat(options.volumeLevel) * 100).toString() + '% but was at ' + currentVolume)
    }
};

/**
 * Bring up the HUD
 */
avkitsafari.bringUpHud = function bringUpHud() {
    this.delay(1.5);
    this.tapMediaView();
    this.waitUntilPresent(UIAQuery.AVKitSafari.MUTETOGGLE.isVisible(), .5);
};

/**
 * Double tap the screen to change the aspect ratio. This cannot be verified via automation!
 */
avkitsafari.changeAspectRatio = function changeAspectRatio() {
    this.doubleTap(UIAQuery.AVKitSafari.PLAYBACK_VIEW)};

/**
 * Convert seconds to a time string
 * @param {int} seconds
 *
 */
avkitsafari.convertSecondsToString = function convertSecondsToString(seconds) {
    // multiply by 1000 because Date() requires miliseconds
    var date = new Date(seconds * 1000);
    var hh = date.getUTCHours();
    var mm = date.getUTCMinutes();
    var ss = date.getSeconds();

    if (parseInt(ss) < 10) {
        ss = '0' + ss
    }
    var timeString = '';
    if (!hh === '0') {
        timeString = hh + ":" + mm + ":" + ss;
    } else {
        timeString = mm + ":" + ss;
    }
    return timeString
};

/**
 * Convert a time string to either seconds or a date object
 *
 * @param {string} options.type - Valid values are 'seconds' or 'date'
 * @param {string} options.timeString - the text string containing a time
 */
avkitsafari.convertTimeString = function convertTimeString(options) {
    if ((!options.type === 'seconds') && (!options.type === 'date')) {
        throw new UIAError('options.type must be either "seconds" or "date"');
    }
    if (!options.timeString) {
        throw new UIAError('A time string must be provided');
    }
    if (options.timeString.indexOf(':') === -1) {
        throw new UIAError('The string provided is not a proper time string');
    }

    var parts = options.timeString.split(':');
    var minutes = seconds = hours = 0;

    switch(options.type) {
        case 'seconds':
            var total_seconds = 0;
            if (parts.length === 3) {
                hours = parts[0];
                minutes = parts[1];
                seconds = parts[2];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60) + (parseInt(hours, 10) * 60 * 60);
            } else {
                minutes = parts[0];
                seconds = parts[1];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60);
            }
            return total_seconds;
        case 'date':
            var date = new Date();
            if (parts.length === 3) {
                date.setHours(parts[0]);
                date.setMinutes(parts[1]);
                date.setSeconds(parts[2]);

            } else {
                date.setHours(0);
                date.setMinutes(parts[0]);
                date.setSeconds(parts[1]);
            }
            return date
    }
};

/**
 * Decrement the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to decrement
 *
 * @returns {object} elapsedTime - the new decremented time
 */
avkitsafari.decrementTime = function decrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() - (jumpSeconds + 10));

    return elapsedTime
};

/**
 * Kill the app
 */
avkitsafari.dismissApplication = function dismissApplication() {
    target.performTask('/usr/bin/killall', ['MobileSafari'], 5);
};

/**
 * Either taps the done button if in fullscreen, or taps the pause button if in inline controls
 *
 * @return {None}
 */
avkitsafari.doneWithPlayback = function doneWithPlayback() {
    if (this.isInFullScreen()){
        this.bringUpHud();
        this.tap(UIAQuery.AVKitSafari.DONE);
    } else {
        this.bringUpHud();
        this.tap(UIAQuery.AVKitSafari.PAUSE);
    }
};

/**
 * Tap the PiP button
 *
 * @returns {None}
 */
avkitsafari.enterPip = function enterPip() {
    UIALogger.logMessage('Entering PiP mode...');
    if (!this.exists(UIAQuery.AVKitSafari.PIP.isVisible())){
        this.tapMediaView();
    }
    this.tap(UIAQuery.AVKitSafari.PIP)
};

/**
 * Exit PiP mode
 *
 * @returns {None}
 */
avkitsafari.exitPip = function exitPip() {
    if (UIAQuery.SpringBoard.CLOSE_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.CLOSE_PIP);
    }
};

/**
 * Press Pause in PiP Window
 *
 * @returns {None}
 */
avkitsafari.pausePip = function pausePip() {
    if (UIAQuery.SpringBoard.PAUSE_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.PAUSE_PIP);
    }

};

/**
 * Press Play in PiP Window
 *
 * @returns {None}
 */
avkitsafari.playPip = function playPip() {
    if (springboard.exists(UIAQuery.SpringBoard.PLAY_PIP.isVisible())) {
        springboard.tap(UIAQuery.SpringBoard.PLAY_PIP);
    }
};

/**
 * Return from PiP mode
 *
 * @returns {None}
 */
avkitsafari.returnFromPip = function returnFromPip() {
    if (UIAQuery.SpringBoard.FULLSCREEN_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.FULLSCREEN_PIP);
    }
};

/**
 * Check to see if the UI indicates that PiP is playing
 *
 * @returns {boolean}  - True if the playback UI indicates that the video is playing and false otherwise.
 */
avkitsafari.isPipPlaying = function () {
    return !!springboard.exists(UIAQuery.SpringBoard.PAUSE_PIP);
};

/**
 * Check to see if the PiP window is Visible
 *
 * @returns {boolean}   - True if the PiP window is visible
 */
avkitsafari.isPipVisble = function () {
    return springboard.exists(UIAQuery.SpringBoard.CLOSE_PIP);
};

/**
 * Check to see if the PiP window closed; the trailer page should be visible
 *
 * @returns {boolean}   - True if PiP is closed and trailer page is visible
 */
avkitsafari.didPipClose = function () {
    return this.exists(UIAQuery.AVKitSafari.TRAILER);
};

/** Check to see if we returned from PiP; the video should still be fullscreen
 *
 * @returns {boolean}   - True if the video is fullscreen
 */
avkitsafari.didPipReturn = function () {
  return this.exists(UIAQuery.AVKitSafari.PIP);
};

/**
 * Get the current elapsed time (text) and convert it to a date object
 *
 * @returns {object} - the elapsed time as a date object
 */
avkitsafari.getElapsedTime = function getElapsedTime() {
    var elapsedTime = avkitsafari.inspect(UIAQuery.AVKitSafari.TIME_ELAPSED).label;
    var options = {
        type: 'date',
        timeString: elapsedTime
    };
    elapsedTime = avkitsafari.convertTimeString(options);

    return elapsedTime
};

/**
 * Get the difference between 2 times
 * @param {object} options.time1 - the 1st time (should be the smaller time)
 * @param {object} options.time2 - the 2nd time (should be the larger time)
 *
 * @returns {object} - the difference between the 2 times
 */
avkitsafari.getTimeDiff = function getTimeDiff(options) {
    if (!options.time1 && options.time2) {
        throw new UIAError('2 times must be provided')
    }
    var hours = date2.getHours() - date1.getHours();
    var minutes = date2.getMinutes() - date1.getMinutes();
    var seconds = date2.getSeconds() - date1.getSeconds();

    var diff = new Date();
    diff.setHours(hours);
    diff.setMinutes(minutes);
    diff.setSeconds(seconds);

    return diff
};

/**
 * Increment the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to increment
 *
 * @returns {object} elapsedTime - the new incremented time
 */
avkitsafari.incrementTime = function incrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() + jumpSeconds);

    return elapsedTime
};

/**
 * Checks to see if the playback UI indicates that the video is in fullscreen.
 *
 * @returns {boolean} True if the playback UI indicates that the video is in fullscreen, false otherwise.
 */
avkitsafari.isInFullScreen = function isInFullScreen() {
    if (!this.exists(UIAQuery.AVKitSafari.DONE.isVisible())) {
        this.tapMediaView();
    }
    return !!this.waitUntilPresent(UIAQuery.AVKitSafari.DONE.isVisible(), 2);
};

/**
 * Checks to see if the playback UI indicates that the video is playing.
 *
 * @returns {boolean} True if the playback UI indicates that the video is playing and false otherwise.
 */
avkitsafari.isPlaying = function isPlaying() {
    if (this.exists(UIAQuery.AVKitSafari.MUTETOGGLE.isVisible()) && this.exists(UIAQuery.AVKitSafari.PLAY.isVisible())) {
        return false;
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitSafari.MUTETOGGLE.isVisible(), 2)) {
            return !(this.exists(UIAQuery.AVKitSafari.DONE.isVisible()) &&
                this.exists(UIAQuery.AVKitSafari.PLAY.isVisible()));
        }
    }
};

/**
 * Jump X number of times in Y direction, i.e. Tap the specified "Jump" button the specified number of times
 * @param {number} options.jumps - how many times to press the button
 * @param {string} options.direction - Valid valids are 'Forward' and 'Backward'
 *
 * @returns {None} - Throws if either option is empty or invalid
 */
avkitsafari.jump = function jump(options) {
    if (!options.jumps) {
        throw new UIAError('Plese specify how many times to jump.');
    }
    if ((!options.direction === 'Forward') || (!options.direction ==='Backward')) {
        throw new UIAError('You must specify Forward or Backward for direction')
    }
    this.bringUpHud();
    if (!this.exists(UIAQuery.AVKitSafari.SKIP_FORWARD.isVisible())) {
        throw new UIAError('Skip Forward not visible!')
    } else {
        for (i = 0; i < options.jumps; i++) {
            try {
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitSafari.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitSafari.SKIP_BACKWARD)
                }
            }
            catch (err) {
                this.bringUpHud();
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitSafari.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitSafari.SKIP_BACKWARD)
                }
            }
        }
    }
};

/**
 * Tap the pause button. Note: The pause button is not visible for very long, so I just try to tap it
 * without checking to see if it is there. If that fails, i.e. tapping on the screen hid the control
 * instead of showing it, I try again. I try twice because it would regularly fail to
 * pause on the 'Pirates of the Caribbean' video.
 *
 * @returns {None}
 */
avkitsafari.pause = function pause() {
    this.bringUpHud();
    this.tap(UIAQuery.AVKitSafari.PAUSE);
    if (this.isPlaying()) {
        this.bringUpHud();
        this.tap(UIAQuery.AVKitSafari.PAUSE);
    }
};

/**
 * Tap the play button.
 *
 * @returns {None}
 */
avkitsafari.play = function play() {
    if (this.exists(UIAQuery.AVKitSafari.PLAY.isVisible())) {
        this.tap(UIAQuery.AVKitSafari.PLAY)
    } else if (!this.exists(UIAQuery.AVKitSafari.PAUSE.isVisible())) {
        this.tapMediaView();
    }
    if (this.waitUntilPresent(UIAQuery.AVKitSafari.PLAY.isVisible(), 2)) {
        this.tap(UIAQuery.AVKitSafari.PLAY)
    }
};

/**
 * Play the 1st trailer found for the given URL
 *
 * @param args.URL - where you want to go!
 */
avkitsafari.playTrailer = function playTrailer(args){
    args = UIAUtilities.defaults(args, {
        URL: "http://trailers.apple.com/trailers/disney/tangled/"
    });
    avkitsafari.dismissApplication();
    avkitsafari.enterURL(args.URL);
    avkitsafari.tap(UIAQuery.AVKitSafari.TRAILER);
};

/**
 * Scrubs the movie to the value specified.
 * @param {double} options.position - The position in the movie to scrub to
 *
 * @return {None}
 */
avkitsafari.scrubCurrentPosition = function scrubCurrentPosition(options){
    if (!options.position) {
        throw new UIAError('Please specify the new position to scrub to.');
    }
    if (this.exists(UIAQuery.AVKitSafari.TRANSPORT_BAR.isVisible())) {
        this.setControl(UIAQuery.AVKitSafari.TRANSPORT_BAR, parseFloat(options.position));
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitSafari.DONE.isVisible(), 1)) {
            this.setControl(UIAQuery.AVKitSafari.TRANSPORT_BAR, parseFloat(options.position));
        }
    }
};

/**
 * Change orientation to Landscape or Portrait as defined by the test.
 * @param {string} options.deviceOrientation - The device orientation to change to
 *
 * @return {None}
 */
avkitsafari.setDeviceOrientation = function setDeviceOrientation(options) {
    if (options.deviceOrientation === 'Landscape') {
        target.setDeviceOrientation(UIADeviceOrientation.LANDSCAPE_RIGHT);
    } else {
        target.setDeviceOrientation(UIADeviceOrientation.PORTRAIT);
    }
};

/**
 * Toggle Mute on or off
 * If you can hear sound, mute is OFF (and the label will read 'Mute'). When ON, the label reads 'Unmute'.
 *
 * @param {string} args.mute - Valid values are ON or OFF.
 *
 * @return {None}
 */
avkitsafari.setMuteState = function setMuteState(args) {
    if (!args.mute) {
        throw new UIAError('Please specify the desired mute state');
    }
    if (!args.mute === 'ON' && !args.mute === 'OFF'){
        throw new UIAError("'ON' and 'OFF' are the only acceptable arguments")
    }
    /* Note: if mute is OFF, the label will read 'Mute'. If mute is ON, the labe will read 'Unmute' */
    avkitsafari.bringUpHud();
    var currentState = this.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).label;
    UIALogger.logMessage('The current state is: ' + currentState);
    switch(currentState) {
        case 'Mute':
            switch(args.mute){
                case 'ON':
                    if (this.isPlaying()) {
                        avkitsafari.bringUpHud();
                    }
                    this.tap(UIAQuery.AVKitSafari.MUTETOGGLE);
                    this.assertValueForMute('Unmute');
                    break;
                case 'OFF':
                    if (this.isPlaying()) {
                        avkitsafari.bringUpHud();
                    }
                    this.assertValueForMute('Mute');
                    break; // Volume is already muted
            }
            break;
        case 'Unmute':
            switch(args.mute){
                case 'ON':
                    if (this.isPlaying()) {
                        avkitsafari.bringUpHud();
                    }
                    this.assertValueForMute('Mute');
                    break; // Volume is already muted
                case 'OFF':
                    if (this.isPlaying()) {
                        avkitsafari.bringUpHud();
                    }
                    this.tap(UIAQuery.AVKitSafari.MUTETOGGLE);
                    this.assertValueForMute('Unmute');
                    break;
            }
            break;
        case 'Volume':
            throw new UIAError('Label reads "Volume". How did it get into that state?')
    }
};

/**
 * Sets the volume via the ui to the specified value.
 * @param {double} options.volumeLevel - The volume leve to set the volume to
 *
 * @return {None}
 */
avkitsafari.setVolume = function setVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Please specify the volume level you wish to set the volume to.');
    }
    if (this.exists(UIAQuery.AVKitSafari.MUTETOGGLE.isVisible())){
        this.touchAndHold(UIAQuery.AVKitSafari.MUTETOGGLE, 1)
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitSafari.DONE.isVisible(), 1)) {
            this.touchAndHold(UIAQuery.AVKitSafari.MUTETOGGLE, 1);
            this.setControl(UIAQuery.AVKitSafari.VOLUME, parseFloat(options.volumeLevel));
        }
    }
};

avkitsafari.tapMediaView = function tapMediaView() {
    if (this.exists(UIAQuery.AVKitSafari.PLAYBACK_VIEW)) {
        this.tap(UIAQuery.AVKitSafari.PLAYBACK_VIEW);
    }
};