load('UIATesting.js');
load('UIAApp.js');
load('SpringBoard.js');


UIAQuery.AVKitTV = {
    /** Continue button */
    CONTINUE: UIAQuery.buttons("Continue"),
    /** Fullscreen controls Done button */
    DONE: UIAQuery.buttons('Done'),

    /** Home Videos cell */
    HOME_VIDEOS: UIAQuery.tableCells().contains('Home Videos'),

    /** Library button on iPad */
    LIBRARY: UIAQuery.buttons('Library'),

    /** Movies cell */
    MOVIES: UIAQuery.tableCells().contains('Movies'),

    /** Play button */
    PLAY: UIAQuery.buttons('Play'),

    /** Video playback view. */
    PLAYBACK_VIEW: UIAQuery.contains('UIViewControllerWrapperView'),

    /** pause button */
    PAUSE: UIAQuery.buttons('Pause'),

    /** Picture in Picture button */
    PIP: UIAQuery.buttons('Picture In Picture'),

    /** Status Bar */
    STATUS_BAR: UIAQuery.contains('UIStatusBar'),

    /** Transport bar*/
    TRANSPORT_BAR: UIAQuery.sliders('Current position'),

    /** TV Shows cell */
    TV_SHOWS: UIAQuery.tableCells().contains('TV Shows'),

    /** Video layer element */
    VIDEO_LAYER: UIAQuery.contains('MPVideoPlaybackBackgroundView'),

    /** Volume slider*/
    VOLUME: UIAQuery.sliders('Volume'),

    /** Watch Now button */
    WATCH_NOW: UIAQuery.buttons('Watch Now')
};

var avkittv = target.appWithBundleID('com.apple.tv');

avkittv.dismissApplication = function dismissApplication() {
    target.performTask('/usr/bin/killall', ['TV'], 5);
};

avkittv.forceQuit = function forceQuit() {
    if (this.isActive()) {
        var quit_waiter = UIAWaiter.waiter('ApplicationStateChanged', {predicate: 'bundleID == "com.apple.avkittv" AND state == "Terminated"'});
        try {
            this.quit();
        } catch (e) {
            UIALogger.logWarning('quit() failed, performing killall');
            target.performTask('/usr/bin/killall', ['TV']);
            target.clickMenu();
        }
        quit_waiter.wait(10);
    }
};

avkittv.quitAndLaunch = function quitAndLaunch() {
    // Stop Playback in a previous test failed to do so
    if (avkittv.isActive()) {
        if (this.exists(UIAQuery.AVKitTV.DONE.isVisible())) {
            this.tap(UIAQuery.AVKitTV.DONE)
        } else {
            if (this.exists(UIAQuery.AVKitTV.VIDEO_LAYER.isVisible())) {
                this.tap(UIAQuery.AVKitTV.VIDEO_LAYER);
                if (this.exists(UIAQuery.AVKitTV.DONE.isVisible())) {
                    this.tap(UIAQuery.AVKitTV.DONE)
                }
            }
        }
    }
    this.forceQuit();
    this.launch();
};

/**
 * Change orientation to Landscape or Portrait as defined by the test.
 * @param {string} options.deviceOrientation - The device orientation to change to
 *
 * @return {None}
 */
avkittv.setDeviceOrientation = function setDeviceOrientation(options) {
    if (options.deviceOrientation === 'Landscape') {
        target.setDeviceOrientation(UIADeviceOrientation.LANDSCAPE_RIGHT);
    } else {
        target.setDeviceOrientation(UIADeviceOrientation.PORTRAIT);
    }
};

avkittv.tapMediaView = function tapMediaView(){
    if (this.exists(UIAQuery.AVKitTV.PLAYBACK_VIEW)) {
        this.tap(UIAQuery.AVKitTV.PLAYBACK_VIEW);
    }
};

/**
 * Taps the done button
 *
 * @return {None}
 */
avkittv.doneWithPlayback = function doneWithPlayback() {
    this.bringUpHud();
    this.tap(UIAQuery.AVKitTV.DONE);
};

/**
 * Checks to see if the playback UI indicates that the video is playing.
 *
 * @returns {Boolean} True if the playback UI indicates that the video is playing and false otherwise.
 */
avkittv.isPlaying = function isPlaying() {
    if (this.exists(UIAQuery.AVKitTV.VOLUME.isVisible()) && this.exists(UIAQuery.AVKitTV.PLAY.isVisible())) {
        return false;
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitTV.VOLUME.isVisible(), 2)) {
            return !(this.exists(UIAQuery.AVKitTV.VOLUME.isVisible()) &&
                this.exists(UIAQuery.AVKitTV.PLAY.isVisible()));
        }
    }
};

/**
 * Tap the pause button. Note: The pause button is not visible for very long, so I just try to tap it
 * without checking to see if it is there. If that fails, i.e. tapping on the screen hid the control
 * instead of showing it, I try again. I try twice because it would regularly fail to
 * pause on the 'Pirates of the Caribbean' video.
 *
 * @returns {None}
 */
avkittv.pause = function pause() {
    this.bringUpHud();
    this.tap(UIAQuery.AVKitTV.PAUSE);
};

/**
 * Tap the play button.
 *
 * @returns {None}
 */
avkittv.play = function play() {
    if (this.exists(UIAQuery.AVKitTV.PLAY.isVisible())) {
        this.tap(UIAQuery.AVKitTV.PLAY)
    } else if (!this.exists(UIAQuery.AVKitTV.PAUSE.isVisible())) {
        this.tapMediaView();
    }
    if (this.waitUntilPresent(UIAQuery.AVKitTV.PLAY.isVisible(), 2)) {
        this.tap(UIAQuery.AVKitTV.PLAY)
    }
};


/**
 * Navigate to media of the specified type with the specified name and play it.
 *
 * @param {string} args.type: Valid types are 'TV Shows', 'Movies', and 'Home Videos'
 * @param {string} args.name: name of the media
 *
 * @return {None}
 */
avkittv.navigateToMedia = function (args) {
    this.quitAndLaunch();
    this.waitUntilReady();
    target.delay(2);
    if (this.exists(UIAQuery.AVKitTV.CONTINUE)) {
        this.tap(UIAQuery.AVKitTV.CONTINUE)
    }
    target.delay(1);
    this.tap(UIAQuery.AVKitTV.LIBRARY);
    target.delay(.5);
    // If there is more than one type of media, pick the correct one
    if ((this.exists(UIAQuery.AVKitTV.TV_SHOWS)) || (this.exists(UIAQuery.AVKitTV.MOVIES)) ||
        (this.exists(UIAQuery.AVKitTV.HOME_VIDEOS))) {
        switch (args.type) {
            case 'TV Shows':
                this.tap(UIAQuery.AVKitTV.TV_SHOWS);
                break;
            case 'Movies':
                this.tap(UIAQuery.AVKitTV.MOVIES);
                break;
            case 'Home Videos':
                this.tap(UIAQuery.AVKitTV.HOME_VIDEOS);
                break;
        }
    }
    target.delay(1);
    if (this.exists(UIAQuery.tableCells(args.name))) {
      this.tap(UIAQuery.tableCells(args.name))
    }
    target.delay(1);
    avkittv.tap(UIAQuery.AVKitTV.PLAY);
};

/**
 * Tap the PiP button
 *
 * @returns {None}
 */
avkittv.enterPip = function enterPip() {
    UIALogger.logMessage('Entering PiP mode...');
    if (!this.exists(UIAQuery.AVKitTV.PIP.isVisible())){
        this.tapMediaView();
    }
    this.tap(UIAQuery.AVKitTV.PIP)
};

/**
 * Exit PiP mode
 *
 * @returns {None}
 */
avkittv.closePip = function closePip() {
    if (UIAQuery.SpringBoard.CLOSE_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.CLOSE_PIP);
    }
};

/**
 * Press Pause in PiP Window
 *
 * @returns {None}
 */
avkittv.pausePip = function pausePip() {
    if (UIAQuery.SpringBoard.PAUSE_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.PAUSE_PIP);
    }

};

/**
 * Press Play in PiP Window
 *
 * @returns {None}
 */
avkittv.playPip = function playPip() {
    if (springboard.exists(UIAQuery.SpringBoard.PLAY_PIP.isVisible())) {
        springboard.tap(UIAQuery.SpringBoard.PLAY_PIP);
    }
};

/**
 * Return from PiP mode
 *
 * @returns {None}
 */
avkittv.returnFromPip = function returnFromPip() {
    if (UIAQuery.SpringBoard.FULLSCREEN_PIP.isVisible()){
        springboard.tap(UIAQuery.SpringBoard.FULLSCREEN_PIP);
    }
};

/**
 * Check to see if the UI indicates that PiP is playing
 *
 * @returns {boolean}  - True if the playback UI indicates that the video is playing and false otherwise.
 */
avkittv.isPipPlaying = function () {
    return !!springboard.exists(UIAQuery.SpringBoard.PAUSE_PIP);
};

/**
 * Check to see if the PiP window is Visible
 *
 * @returns {boolean}   - True if the PiP window is visible
 */
avkittv.isPipVisble = function () {
    return springboard.exists(UIAQuery.SpringBoard.CLOSE_PIP);
};

/**
 * Check to see if the PiP window closed; the video should not be visible
 * Note: this function is only valid if PiP was invoked via the PiP button, not via the Home button
 * @returns {boolean}   - True if PiP is closed and the video is not visible
 */
avkittv.didPipClose = function () {
    return !!((!this.isPipVisble()) && (this.exists(UIAQuery.AVKitTV.WATCH_NOW.isVisible())));
};

/** Check to see if we returned from PiP and the play state was retained
 *
 * @returns {boolean}   - True if the PiP control is visible and the play state was retained
 */
avkittv.didPipReturn = function () {
    var playState = this.isPlaying();
    return !!((this.exists(UIAQuery.AVKitTV.PIP)) && (this.isPlaying() === playState));
};

/**
 * Bring up the HUD
 */
avkittv.bringUpHud = function bringUpHud() {
    if (this.exists(UIAQuery.AVKitTV.VOLUME.isVisible())) {
        this.delay(3);
    }
    this.tapMediaView();
    this.waitUntilPresent(UIAQuery.AVKitTV.VOLUME.isVisible(), .5);
};

/**
 * Scrubs the movie to the value specified.
 * 
 * @param {double} options.position - The position in the movie to scrub to
 *
 * @return {None}
 */
avkittv.scrubCurrentPosition = function scrubCurrentPosition(options){
    if (!options.position) {
        throw new UIAError('Please specify the new position to scrub to.');
    }
    if (this.exists(UIAQuery.AVKitTV.TRANSPORT_BAR.isVisible())) {
        this.setControl(UIAQuery.AVKitTV.TRANSPORT_BAR, parseFloat(options.position));
    } else {
        this.tapMediaView();
        this.setControl(UIAQuery.AVKitTV.TRANSPORT_BAR, parseFloat(options.position));
    }
};

/**
 * Verifies the movie was scrubbed to the value specified.
 * 
 * @param {string} options.position - The position you are expecting playback to be at in a double (expressed as a string) ('0.5' for 50%)
 * @param {boolean} options.allowImpreciseScrubbing - Allow the test to pass if the position falls within +/- 10 seconds of the desired position
 *
 * @return {None} - throws if option.position is not equal to the current value of the transport bar
 */
avkittv.assertValueForCurrentPosition = function assertValueForCurrentPosition(options) {
    if (!options.position) {
        throw new UIAError('Need to assert the current position is equal to something. Please specify the position we are comparing to.')
    } else {
        position = options.position
    }
    // The slider returns a string representation of the elapsed time, for example '1:30' for 1 minute and 30 seconds
    var currentPositionTimeString = this.inspect(UIAQuery.AVKitTV.TRANSPORT_BAR).value;
    var args = {
        type: 'seconds',
        timeString: currentPositionTimeString
    };
    var currentSeconds = avkittv.convertTimeString(args); // Convert current position to seconds
    // To determine the percentage of playback, we need to get the total length of the video
    avkittv.bringUpHud();
    args = {position: '0.0'};
    avkittv.scrubCurrentPosition(args);
    var totalLength = this.inspect(UIAQuery.AVKitTV.TIME_REMAINING).label.slice(2);
    // Convert the total length to seconds
    args = {
        type: 'seconds',
        timeString: totalLength
    };
    var totalSeconds = avkittv.convertTimeString(args);
    var expectedSeconds = totalSeconds * parseFloat(position);
    if (options.allowImpreciseScrubbing === true) {
        if ((currentSeconds < expectedSeconds - 10) || (currentSeconds > expectedSeconds + 10)) {
            throw new UIAError('The scrub position is outside of the acceptable range! Current Position: ' +
                avkittv.convertSecondsToString(currentSeconds) + ' Expected Position: ' + avkittv.convertSecondsToString(expectedSeconds))
        }
    } else {
        if (!(currentSeconds === expectedSeconds)) {
            throw new UIAError('The scrub position does not match the expected position! Current Position: ' +
                avkittv.convertSecondsToString(currentSeconds) + ' Expected Position: ' + avkittv.convertSecondsToString(expectedSeconds))
        }
    }
};

/**
 * Sets the volume via the ui to the specified value.
 * 
 * @param {double} options.volumeLevel - The volume leve to set the volume to
 *
 * @return {None}
 */
avkittv.setVolume = function setVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Please specify the volume level you wish to set the volume to.');
    }
    if (this.exists(UIAQuery.AVKitTV.VOLUME.isVisible())){
        this.setControl(UIAQuery.AVKitTV.VOLUME, parseFloat(options.volumeLevel));
    } else {
        this.tapMediaView();
        if (this.waitUntilPresent(UIAQuery.AVKitTV.VOLUME.isVisible(), 1)) {
            this.setControl(UIAQuery.AVKitTV.VOLUME, parseFloat(options.volumeLevel));
        }
    }
};

/**
 * Compares the movie volume to the value specified.
 *
 * @param {string} options.volumeLevel - The volumeLevel you are expecting the volume slider to be as a percentage. ex. 0%
 *
 * @return {None} - throws if options.volumeLevel is not equal to the current value of the volume slider
 */
avkittv.assertValueForVolume = function assertValueForVolume(options){
    if (!options.volumeLevel) {
        throw new UIAError('Need to assert the volume level is equal to something. Please specify the volume level we are comparing to.')
    }
    if (!this.exists(UIAQuery.AVKitTV.VOLUME.isVisible())) {
        this.tapMediaView();
    }
    if (!this.waitUntilPresent(UIAQuery.AVKitTV.VOLUME.isVisible(), .2)) {
        throw new UIAError('The Volume slider should be visible, but it is not!')
    }
    var currentVolume = this.inspect(UIAQuery.AVKitTV.VOLUME).value;
    // allow some error on UI due to existing bug
    if (currentVolume > (parseFloat(options.volumeLevel) * 100 + 10).toString() + '%' ||
        currentVolume < (parseFloat(options.volumeLevel) * 100 - 10).toString() + '%') {
        throw new UIAError('The volume was expected to be at ' + (parseFloat(options.volumeLevel) * 100).toString() + '% but was at ' + currentVolume)
    }
};

avkittv.changeAspectRatio = function changeAspectRatio() {
    this.doubleTap(UIAQuery.AVKitTV.PLAYBACK_VIEW)
};

/**
 * Jump X number of times in Y direction, i.e. Tap the specified "Jump" button the specified number of times
 * @param {number} options.jumps - how many times to press the button
 * @param {string} options.direction - Valid valids are 'Forward' and 'Backward'
 * @returns {None} - Throws if either option is empty or invalid
 */
avkittv.jump = function jump(options) {
    if (!options.jumps) {
        throw new UIAError('Plese specify how many times to jump.');
    }
    if ((!options.direction === 'Forward') || (!options.direction ==='Backward')) {
        throw new UIAError('You must specify Forward or Backward for direction')
    }
    this.bringUpHud();
    if (!this.exists(UIAQuery.AVKitTV.SKIP_FORWARD.isVisible())) {
        throw new UIAError('Skip Forward not visible!')
    } else {
        for (i = 0; i < options.jumps; i++) {
            try {
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitTV.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitTV.SKIP_BACKWARD)
                }
            }
            catch (err) {
                this.bringUpHud();
                if (options.direction === 'Forward') {
                    this.tap(UIAQuery.AVKitTV.SKIP_FORWARD)
                } else {
                    this.tap(UIAQuery.AVKitTV.SKIP_BACKWARD)
                }
            }
        }
    }
};

/**
 * Convert a time string to either seconds or a date object
 *
 * @param {string} options.type - Valid values are 'seconds' or 'date'
 * @param {string} options.timeString - the text string containing a time
 */
avkittv.convertTimeString = function convertTimeString(options) {
    if ((!options.type === 'seconds') && (!options.type === 'date')) {
        throw new UIAError('options.type must be either "seconds" or "date"');
    }
    if (!options.timeString) {
        throw new UIAError('A time string must be provided');
    }
    if (options.timeString.indexOf(':') === -1) {
        throw new UIAError('The string provided is not a proper time string');
    }

    var parts = options.timeString.split(':');
    var minutes = seconds = hours = 0;

    switch(options.type) {
        case 'seconds':
            var total_seconds = 0;
            if (parts.length === 3) {
                hours = parts[0];
                minutes = parts[1];
                seconds = parts[2];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60) + (parseInt(hours, 10) * 60 * 60);
            } else {
                minutes = parts[0];
                seconds = parts[1];
                total_seconds = parseInt(seconds, 10) + (parseInt(minutes, 10) * 60);
            }
            return total_seconds;
        case 'date':
            var date = new Date();
            if (parts.length === 3) {
                date.setHours(parts[0]);
                date.setMinutes(parts[1]);
                date.setSeconds(parts[2]);

            } else {
                date.setHours(0);
                date.setMinutes(parts[0]);
                date.setSeconds(parts[1]);
            }
            return date
    }
};

/**
 * Convert seconds to a time string
 * @param {int} seconds
 *
 */
avkittv.convertSecondsToString = function convertSecondsToString(seconds) {
    // multiply by 1000 because Date() requires miliseconds
    var date = new Date(seconds * 1000);
    var hh = date.getUTCHours();
    var mm = date.getUTCMinutes();
    var ss = date.getSeconds();

    if (parseInt(ss) < 10) {
        ss = '0' + ss
    }
    var timeString = '';
    if (!hh === '0') {
        timeString = hh + ":" + mm + ":" + ss;
    } else {
        timeString = mm + ":" + ss;
    }
    return timeString
};

/**
 * Get the current elapsed time (text) and convert it to a date object
 *
 * @returns {object} - the elapsed time as a date object
 */
avkittv.getElapsedTime = function getElapsedTime() {
    var elapsedTime = this.inspect(UIAQuery.AVKitTV.TIME_ELAPSED).label;
    var options = {
        type: 'date',
        timeString: elapsedTime
    };
    elapsedTime = this.convertTimeString(options);

    return elapsedTime
};

/**
 * Get the difference between 2 times
 * @param {object} options.time1 - the 1st time (should be the smaller time)
 * @param {object} options.time2 - the 2nd time (should be the larger time)
 *
 * @returns {object} - the difference between the 2 times
 */
avkittv.getTimeDiff = function getTimeDiff(options) {
    if (!options.time1 && options.time2) {
        throw new UIAError('2 times must be provided')
    }
    var hours = date2.getHours() - date1.getHours();
    var minutes = date2.getMinutes() - date1.getMinutes();
    var seconds = date2.getSeconds() - date1.getSeconds();

    var diff = new Date();
    diff.setHours(hours);
    diff.setMinutes(minutes);
    diff.setSeconds(seconds);

    return diff
};

/**
 * Increment the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to increment
 *
 * @returns {object} elapsedTime - the new incremented time
 */
avkittv.incrementTime = function incrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() + jumpSeconds);

    return elapsedTime
};

/**
 * Decrement the end elapsed time by 15 seconds for each jump
 * @param {number} jumps - the number of jumps used
 * @param {object} elapsedTime - the date object to decrement
 *
 * @returns {object} elapsedTime - the new decremented time
 */
avkittv.decrementTime = function decrementTime(jumps, elapsedTime) {
    if (!jumps) {
        throw new UIAError('You must provide the number of jumps used')
    }
    if (!elapsedTime) {
        throw new UIAError('You must provide the time to increment')
    }
    var jumpSeconds = 0;
    for (i = 0; i < jumps; i++) {
        jumpSeconds += 15;
    }
    elapsedTime.setSeconds(elapsedTime.getSeconds() - (jumpSeconds + 10));

    return elapsedTime
};

/**
 * Check the position of the controls in respect to the status bar
 *
 * @param {string} args.statusBarState  - Valid values are 'Single' and 'Double'
 * @returns {boolean}   - True if the controls are where they are supposed to be, otherwise false
 */
avkittv.controlsPositionedCorrectly = function (args) {
    var expectedPosition = 0;

    if (args.statusBarState === 'Double') { // iPad only test
        expectedPosition = 26;
    } else {
        if ((target.deviceOrientation() === 1) || (target.deviceOrientation() === 2)) {  // Portrait
            if (target.mobileGestaltQuery("HWModelStr").includes('D22')) {
                expectedPosition = 50;
            } else {
                expectedPosition = 23;
            }
        } else {
            if ((target.deviceOrientation() === 3) || (target.deviceOrientation() === 4)) {  // Landscape
                if (target.mobileGestaltQuery("HWModelStr").includes('D22')) {
                    expectedPosition = 27;
                } else {
                    expectedPosition = 23;
                }
            }
        }
    }

    var var_list = [];
    var actualPositionDone = this.inspect(UIAQuery.AVKitTV.DONE).rect.y;
    var_list.push(actualPositionDone);

    if (this.exists(UIAQuery.AVKitTV.VOLUME)) {
        var actualPositionVolume = this.inspect(UIAQuery.AVKitTV.VOLUME).rect.y;
        var_list.push(actualPositionVolume);
    }
    if (this.exists(UIAQuery.AVKitTV.PIP)) {
        var actualPositionPip = this.inspect(UIAQuery.AVKitTV.PIP).rect.y;
        var_list.push(actualPositionPip);
    }
    for (var i = 0; i < var_list.length; i++) {
        if (var_list[i] !== expectedPosition) {
            UIALogger.logMessage('Expected the controls to be at y = ' + expectedPosition.toString() +
                ' but they are at y = ' + var_list[i].toString());
            throw new UIAError('A control was not in the expected position!')
        }
    }
};

/**
 * Toggle the status bar height
 *
 * @param {string} args.desiredState - Valid values are 'Single' and 'Double'
 */
avkittv.toggleStatusBarHeight = function (args) {
    settings.launch();
    settings.chooseSetting(['Internal Settings', 'Status Bar Overrides', 'In Call']);
    if (args.desiredState === 'Single') {
        settings.tap(UIAQuery.tableCells().contains('Default'))
    } else {
        settings.tap(UIAQuery.tableCells().contains('On'))
    }
};

/**
 * check for the presence of AVKit Controls
 *
 * @param {object} controlsExpected - The controls you expect to be present. Valid controls: The controls as defined in AVKitTV
 */
avkittv.checkForControls =  function (controlsExpected) {
    for (var i = 0; i < controlsExpected.length; i++) {
        switch (controlsExpected[i]) {
            case 'AIRPLAY':
                if (!this.exists(UIAQuery.AVKitTV.AIRPLAY.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'DONE':
                if (!this.exists(UIAQuery.AVKitTV.DONE.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'PAUSE':
                if (!this.exists(UIAQuery.AVKitTV.PAUSE.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'PIP':
                if (!this.exists(UIAQuery.AVKitTV.PIP.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'PLAY':
                UIALogger.logMessage('--------------------');
                UIALogger.logMessage('We are here');
                if (!this.exists(UIAQuery.AVKitTV.PLAY.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'SKIP_BACKWARD':
                if (!this.exists(UIAQuery.AVKitTV.SKIP_BACKWARD.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'SKIP_FORWARD':
                if (!this.exists(UIAQuery.AVKitTV.SKIP_FORWARD.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'STATUS_BAR':
                if (!this.exists(UIAQuery.AVKitTV.STATUS_BAR.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;
            case 'TIME_ELAPSED':
                if (!this.exists(UIAQuery.AVKitTV.TIME_ELAPSED.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'TIME_REMAINING':
                if (!this.exists(UIAQuery.AVKitTV.TIME_REMAINING.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'TRANSPORT_BAR':
                if (!this.exists(UIAQuery.AVKitTV.TRANSPORT_BAR.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;

            case 'VOLUME':
                if (!this.exists(UIAQuery.AVKitTV.VOLUME.isVisible())) {
                    throw new UIAError('The expected control "' + controlsExpected[i] + '" was not visible!')
                }
                break;
        }
    }
};
