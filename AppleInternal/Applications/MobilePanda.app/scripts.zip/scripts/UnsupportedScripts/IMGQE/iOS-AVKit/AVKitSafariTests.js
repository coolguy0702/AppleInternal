load('AVKitSafari.js');

UIAUtilities.assert( typeof AVKitSafari === 'undefined', 'avkitsafari undefined' );
/**
 * @namespace AVKitSafariTests
 */

var AVKitSafariTests = {

    /**
     * Plays a trailer then verifies that the playback state is updated appropriately
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    playTrailer: function playTrailer(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError ('The video is not playing!');
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Plays a trailer then pauses the video and verifies that the playback state is updated appropriately
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pauseTrailer: function pauseTrailer(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if (avkitsafari.isPlaying()) {
            throw new UIAError('The video is not paused!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Plays a trailer then jumps forward the specified number of times
     *
     * @param {string} args.URL - where you want to go!
     * @param {number} args.jumps - How many times to jump forward
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    jumpForward: function jumpForward(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            jumps: '3',
            direction: 'Forward',
            position: '0.0',
            deviceOrientation: 'Portrait',
            state: 'Play'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.scrubCurrentPosition(args);
        avkitsafari.play();
        var startTime = avkitsafari.getElapsedTime();
        if (args.state === 'Play') {
            avkitsafari.play();
        }
        avkitsafari.jump(args);
        var endTime = avkitsafari.getElapsedTime();
        startTime = avkitsafari.incrementTime(args.jumps, startTime);
        if (!endTime >= startTime) {
            throw new UIAError('The end time was expected to be greater than or equal to the start time + (# of jumps * 15 [seconds])');
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Plays a trailer then jumps backward the specified number of times
     *
     * @param {string} args.URL - where you want to go!
     * @param {number} args.jumps - How many times to jump forward
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.state - Valid values are Play or Pause
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    jumpBackward: function jumpBackward(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            jumps: '3',
            direction: 'Backward',
            position: '0.85',
            deviceOrientation: 'Portrait',
            state: 'Play'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.scrubCurrentPosition(args);
        avkitsafari.play();
        var startTime = avkitsafari.getElapsedTime();
        if (args.state === 'Play') {
            avkitsafari.play();
        }
        avkitsafari.jump(args);
        var endTime = avkitsafari.getElapsedTime();
        startTime = avkitsafari.incrementTime(args.jumps, startTime);
        if (!startTime >= endTime) {
            throw new UIAError('The end time was expected to be less than or equal to the start time + (# of jumps * 15 [seconds])');
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Scrub on the transport bar to a certain position
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     */
    scrubToPosition: function scrubToPosition (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait',
            position: '0.5',
            allowImpreciseScrubbing: true
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.scrubCurrentPosition(args);
        avkitsafari.assertValueForCurrentPosition(args);
        avkitsafari.dismissApplication();
    },

    /**
     * Scrub back and forth
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.position - A double (expressed as a string) between 0 and 1 to scrub to ('0.5' for 50%)
     * @param {string} [args.begin="0.2"] - (Required) A double between 0 and 1 to set the lower volume level
     * @param {string} [args.end="0.8"] - (Required) A double between 0 and 1 to set the higher volume level
     */
    scrubBackAndForth: function scrubBackAndForth(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait',
            begin: '0.2',
            end: '0.8'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        var options = {
            position: "0.5"
        };
        avkitsafari.scrubCurrentPosition(options);
        options.position = args.begin;
        avkitsafari.scrubCurrentPosition(options);
        avkitsafari.captureParsecScreenshot('AVKitPlayerScrubbing1');
        options.position = args.end;
        avkitsafari.scrubCurrentPosition(options);
        avkitsafari.captureParsecScreenshot('AVKitPlayerScrubbing2');
        avkitsafari.dismissApplication();
    },

    /**
     * Set the Mute state
     * 
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.mute - Valid values are ON or OFF. If you can hear sound, mute is OFF.
     */
    setMute: function setMute(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait',
            mute: 'ON'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.setMuteState();
        avkitsafari.dismissApplication();
    },

    /**
     * Toggle Mute ON then OFF
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The device orientation to run the test
     */
    toggleMuteOnThenOff: function toggleMuteOnThenOff(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        UIALogger.logWarning('Sometimes this test will fail due to rdar://problem/33457727 [automation only] Controls not visible while video is paused');
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause(); //I was having trouble with the controls not being visible long enough to inspect...
        args.mute = 'ON';
        avkitsafari.setMuteState(args);
        avkitsafari.delay(2);
        args.mute = 'OFF';
        avkitsafari.setMuteState(args);
        avkitsafari.dismissApplication();
    },

    /**
     * Set the Volume to the specified level
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     * @param {string} args.volumeLevel - A double between 0 and 1 to set the volume level
     */
    setVolume: function setVolume(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait',
            volumeLevel: '0.5'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.setVolume(args);
        avkitsafari.assertValueForVolume(args);
        avkitsafari.dismissApplication();
    },

    /**
     * Validate Volume control collapse behavior (iPhone only)
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    volumeControlCollapseBehavior: function volumeControlCollapseBehavior(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if (avkitsafari.isPlaying()) {
            throw new UIAError('The video is playing!')
        }
        if ((avkitsafari.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).isVisible == 1) &&
            (!avkitsafari.exists(UIAQuery.AVKitSafari.VOLUME))) {
            UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
        } else {
            throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
        }
        args.deviceOrientation = 'Landscape';
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.delay(.5);
        if (!(avkitsafari.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).isVisible == 1) &&
            (!avkitsafari.inspect(UIAQuery.AVKitSafari.VOLUME).isVisible == 1)) {
            throw new UIAError('The Volume Control is not in the expected state - expanded in Landscape Mode')
        } else {
            UIALogger.logMessage('The Volume Control is expanded in Landscape Mode')
        }
        args.deviceOrientation = 'Portrait';
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.delay(.5);
        if (!(avkitsafari.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).isVisible == 1) &&
            (!avkitsafari.inspect(UIAQuery.AVKitSafari.VOLUME).isVisible == 1)) {
            throw new UIAError('The Volume Control is not in the expected state expanded in Portrait Mode')
        } else {
            UIALogger.logMessage('The Volume Control is expanded in Portrait Mode')
        }
        avkitsafari.play();
        avkitsafari.delay(3);
        avkitsafari.pause();
        if ((avkitsafari.inspect(UIAQuery.AVKitSafari.MUTETOGGLE).isVisible == 1) &&
            (!avkitsafari.exists(UIAQuery.AVKitSafari.VOLUME))) {
            UIALogger.logMessage('The Volume Control is collapsed in Portrait Mode')
        } else {
            throw new UIAError('The Volume Control is not in the expected state - collapsed in Portrait Mode')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Volume control should be visible when the volume is changed with the hard buttons
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
     volumeControlVisibleWhenVolumeChangedViaButtons: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(2);
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.delay(4);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitsafari.inspect(UIAQuery.AVKitSafari.VOLUME).isVisible == 0) {
            throw new UIAError('The Volume control was not visible!')
        }
        target.delay(2);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitsafari.exists(UIAQuery.AVKitSafari.PAUSE)) {
            throw new UIAError('Other controls besides Volume were visible!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Rotate device
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    rotation: function rotation(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        args.deviceOrientation = 'Landscape';
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.captureParsecScreenshot('Landscape');
        avkitsafari.delay(.2);
        args.deviceOrientation = 'Portrait';
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.captureParsecScreenshot('Portrait');
        avkitsafari.dismissApplication();
    },

    /**
     * Change Aspect Ratio - can't be verified via UIAutomation
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    changeAspectRatio: function changeAspectRatio(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(1);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.changeAspectRatio();
        avkitsafari.captureParsecScreenshot('AspectRatioFullScreen');
        avkitsafari.changeAspectRatio();
        avkitsafari.captureParsecScreenshot('AspectRatioWideScreen');
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, then close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipThenClose: function pipThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.enterPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.exitPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, then return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipThenReturn: function pipThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.enterPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.returnFromPip();
        avkitsafari.delay(.5);
        avkitsafari.bringUpHud();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, pause the video in the PiP window, then close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipPauseThenClose: function pipPauseThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.enterPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.pausePip();
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.exitPip();
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, PiP the Video, pause the video in the PiP window, then return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipPauseThenReturn: function pipPauseThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (!avkitsafari.isPlaying()) {
            throw new UIAError('Video is not playing!')
        }
        avkitsafari.enterPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.pausePip();
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.returnFromPip();
        avkitsafari.bringUpHud();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, then close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pausePipThenClose: function pausePipThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if (avkitsafari.isPlaying()) {
            throw new UIAError('Video is playing!')
        }
        avkitsafari.enterPip();
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.exitPip();
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, then return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pausePipThenReturn: function pausePipThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if (avkitsafari.isPlaying()) {
            throw new UIAError('Video is playing!')
        }
        avkitsafari.enterPip();
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.returnFromPip();
        avkitsafari.delay(.5);
        avkitsafari.bringUpHud();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, play the PiP, then close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pausePipPlayThenClose: function pausePipPlayThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if (avkitsafari.isPlaying()) {
            throw new UIAError('Video is playing')
        }
        avkitsafari.enterPip();
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.playPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be playing, but it is not!')
        }
        avkitsafari.exitPip();
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Choose a video, pause the video, PiP the Video, play the PiP, then return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pausePipPlayThenReturn: function pausePipPlayThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        if(avkitsafari.isPlaying()) {
            throw new UIAError('Video is playing!')
        }
        avkitsafari.enterPip();
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.playPip();
        avkitsafari.delay(.5);
        if (!avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be playing, but it is not!')
        }
        avkitsafari.returnFromPip();
        avkitsafari.bringUpHud();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, then Close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipViaHomeThenClose: function pipViaHomeThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(1);
        UIATarget.localTarget().clickMenu();
        avkitsafari.delay(1);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.pausePip();
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.exitPip();
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, then Return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipViaHomeThenReturn: function pipViaHomeThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(1);
        UIATarget.localTarget().clickMenu();
        avkitsafari.delay(1);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.returnFromPip();
        avkitsafari.bringUpHud();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, pause the video, then Close the PiP window
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipViaHomePauseThenClose: function pipViaHomePauseThenClose(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(1);
        UIATarget.localTarget().clickMenu();
        avkitsafari.delay(1);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.pausePip();
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.exitPip();
        if (!avkitsafari.didPipClose()) {
            throw new UIAError('Did not exit PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Play a video, enter PiP mode via the Home button, pause the video, then Return
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pipViaHomePauseThenReturn: function pipViaHomePauseThenReturn(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(1);
        UIATarget.localTarget().clickMenu();
        avkitsafari.delay(1);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.pausePip();
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP should be paused, but it is not!')
        }
        avkitsafari.returnFromPip();
        if (!avkitsafari.didPipReturn()) {
            throw new UIAError('Did not return from PiP')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Play a video, pause the video, then enter PiP mode via the Home button
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    pausePipViaHome: function pausePipViaHome(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        UIATarget.localTarget().clickMenu();
        avkitsafari.delay(1);
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        avkitsafari.delay(.5);
        if (avkitsafari.isPipPlaying()) {
            throw new UIAError('PiP playback should be paused, but it is not!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Controls should not be shown when the PiP window is visible
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsNotShownForPip: function controlsNotShownForPip(args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        target.delay(2);
        avkitsafari.enterPip();
        if (!avkitsafari.isPipVisble()) {
            throw new UIAError('The PiP window is not visible')
        }
        if (avkitsafari.exists(UIAQuery.AVKitSafari.PAUSE)){
            throw new UIAError('The AVKit Controls are visible!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Controls should not appear when entering Fullscreen if the video is playing
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsNotShownWhenEnteringFullscreenWhileVideoIsPlaying: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        if ((avkitsafari.exists(UIAQuery.AVKitSafari.PLAY.isVisible())) && (avkitsafari.isInFullScreen())){
            throw new UIAError('The AVKit Controls are visible while video is playing when entering Fullscreen!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Controls should disappear within 2 seconds of playback starting
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsDisappearAfterPlaybackStarts: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.play();
        if (avkitsafari.exists(UIAQuery.AVKitSafari.PLAY.isVisible())) {
            throw new UIAError('AVKit Controls were visible 2 seconds after playback started!')
        }
        avkitsafari.dismissApplication();

    },

    /**
     * Controls should always be shown while the video is paused
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    controlsAlwaysShownWhileVideoIsPaused: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.delay(10);  // Delay until the controls would normally disappear
        if (!avkitsafari.exists(UIAQuery.AVKitSafari.PLAY.isVisible())) {
            throw new UIAError('The video is paused and the AVKit Controls are not visible!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is playing and controls are visible
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarVisibleWhilePlayingAndControlsAreVisible: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.bringUpHud();
        if (avkitsafari.inspect(UIAQuery.AVKitSafari.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Status Bar should be hidden when Video is playing and controls are hidden
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarHiddenWhilePlayingAndControlsAreHidden: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(4);
        if (avkitsafari.inspect(UIAQuery.AVKitSafari.STATUS_BAR).isVisible == 1) {
            throw new UIAError('The Status Bar was not hidden!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Status Bar should be visible when Video is paused
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarVisibleWhilePaused: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.pause();
        avkitsafari.delay(4);
        if (avkitsafari.inspect(UIAQuery.AVKitSafari.STATUS_BAR).isVisible == 0) {
            throw new UIAError('The Status Bar was not visible!')
        }
        avkitsafari.dismissApplication();
    },

    /**
     * Status Bar should be hidden when Video is playing, controls are hidden and Volume is changed with hard buttons
     *
     * @param {string} args.URL - where you want to go!
     * @param {string} args.deviceOrientation - The orientation to run the test in
     */
    statusBarHiddenWhilePlayingAndControlsAreHiddenAndVolumeChangedViaButtons: function (args) {
        args = UIAUtilities.defaults(args, {
            URL: "http://trailers.apple.com/trailers/wb/blade-runner-2049/",
            deviceOrientation: 'Portrait'
        });
        avkitsafari.setDeviceOrientation(args);
        avkitsafari.playTrailer(args);
        avkitsafari.delay(2);
        UIATarget.localTarget().clickVolumeUp();
        if (avkitsafari.inspect(UIAQuery.AVKitSafari.STATUS_BAR).isVisible == 1) {
            throw new UIAError('The Status Bar was visible!')
        }
        avkitsafari.dismissApplication();
    }
};
