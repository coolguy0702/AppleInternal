load('UIATesting.js');
load('Messages.js');

if (typeof IMGMessages !== 'undefined') {
    throw new UIAError("Namespace 'IMGMessages' has already been defined.");
}
/**
 * @namespace
 */

UIAQuery.IMGMessages = {
    /* Message from imgqetest */
    IMG_MESSAGE: UIAQuery.tableCells().contains('1 Video'),
    /* Message containing a video */
    IMG_VIDEO_MESSAGE_BUTTON: (UIAQuery.buttons().contains('video')),
    /* Back button (looks like <) */
    IMG_BACK_BUTTON: UIAQuery.buttons().first()
};
var IMGMessages = {
    /**
     * Play the video in a message
     *
     * @targetApps Messages
     */
    playVideoMessage: function playVideoMessages() {
        messages.launch();
        if (messages.exists(UIAQuery.IMGMessages.IMG_MESSAGE.isVisible())) {
            messages.tap(UIAQuery.IMGMessages.IMG_MESSAGE);
        } else {
            throw new UIAError('Unable to find a message containing a video');
        }
        target.delay(1);
        if (messages.exists(UIAQuery.IMGMessages.IMG_VIDEO_MESSAGE_BUTTON.isVisible())) {
            messages.tap(UIAQuery.IMGMessages.IMG_VIDEO_MESSAGE_BUTTON);
        } else {
            throw new UIAError('Message does not contain a video');
        }
        target.delay(10);
        messages.tap(UIAQuery.IMGMessages.IMG_BACK_BUTTON);
    },
    /**
    * Kill Messages
    *
    * @targetApps Messages
    */

    forceQuit: function forceQuit() {
      /* Bring Messages to the foreground */
      messages.launch();
      target.performTask('/usr/bin/killall', ['MobileSMS'], 5);
    }
};
