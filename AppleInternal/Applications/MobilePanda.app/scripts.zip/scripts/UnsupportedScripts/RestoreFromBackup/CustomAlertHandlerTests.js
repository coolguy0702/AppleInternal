load("UIATesting.js");
load("SpringBoard.js");
load("CustomAlertHandler.js");

UIAUtilities.assert(
    typeof CustomAlertHandlerTests === 'undefined',
    'CustomAlertHandlerTests has already been defined.'
);

var CustomAlertHandlerTests = {
    /**
     * Check for unexpected prompts.
     *
     * @param {object} args Test arguments
     * @param {number} [args.delay=60] - Number of seconds to wait for alerts.
     * @param {array} [args.unexpectedAlerts=["Sign", "Apple ID Verification"]] - Titles of unexpected alerts to match against.
     * @alertHandlers restoreAlertHandler
     */
    checkUnwantedAlerts: function checkUnwantedAlerts(args) {
        args = UIAUtilities.defaults(args, {
            delay: 60,
            unexpectedAlerts: ['Sign', 'Apple ID Verification'],
        });

        backUpRestoreUI.handleAlerts(args);
    },

    /**
     * Check for Store Alert and handle it on Springboard.
     *
     * @param {object} args Test arguments
     * @param {number} [args.delay=60] - Number of seconds to wait for alerts.
     * @param {string} [args.iTunesPassword=""] - iTunes Password to be entered in the alert.
     * @param {string} [args.unexpected_store_alerts="Sign In to iTunes Store"] - Title of unexpected alerts to match against.
     */
    handleStoreAlert: function handleStoreAlert(args) {
        args = UIAUtilities.defaults(args, {
            delay: 60,
            iTunesPassword:"",
            unexpected_store_alerts: "Sign In to iTunes Store",
        });

        backUpRestoreUI.handleStoreAlert(args);
    },
};
