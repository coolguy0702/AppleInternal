
load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");

/** @namespace */

UIStateDescription.BackUpRestoreUI = {
}

/**
 @namespace
 @augments UIAApp
 */
var backUpRestoreUI = target.activeApp();

/**
 * Create a handler that tracks unexpected alerts.
 * The unexpectedAlerts array contains strings against which alert titles will be matched.
 * In case of a match an error will be thrown.
 *
 * @param {array} unexpectedAlerts - Titles of unexpected alerts to match against.
 *
 * @returns {function()} Alert handler.
 *
 * @throws on failure to tap on alert or unexpected alert appeared.
 */
 var restoreAlertHandler = function(unexpectedAlerts) {
     var handler = function() {
        var app = target.activeApp();
        var alerts = [];

        // use while loop in case of several alerts sitting one above another
        while (app.exists(UIAQuery.alerts().isVisible())) {
            var title = app.inspect(UIAQuery.alerts()).name;
            var body = app.inspect(UIAQuery.alerts().andThen(UIAQuery.staticTexts()).last()).identifiers[0];
            UIALogger.logMessage('<%0> alert appeared: %1. Tapping it...'.format(title, body));

            for (var i = 0; i < unexpectedAlerts.length; i++) {
                if (title.toLowerCase().indexOf(unexpectedAlerts[i].toLowerCase()) > -1) {
                    alerts.push('%0 %1'.format(title, body));
                    break;
                }
            }

            target.delay(1); // allow alert to be captured in case of failure video.
            var hasButtons = app.inspect(UIAQuery.alerts().andThen(UIAQuery.buttons()));
            if (!hasButtons) {
                break;
            }
            var tapped = app.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Cancel'))) ||
                app.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('OK'))) ||
                // Decline Software Update Alert if appeared
                app.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Later'))) ||
                app.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons()));
            if (!tapped) {
                throw new UIAError('Cannot handle alert <%0>.'.format(title));
            }
        }

        if (alerts.length) {
            throw new UIAError(
                'Unexpected alert(s) appeared: %0'.format(alerts));
        }

        return true;
    }

    return handler;
 }

/**
 * Checks if alerts from unexpectedAlerts appeared.
 * Closes an alert silently if it is not matched by any of the unexpectedAlerts.
 * Otherwise, closes the alert and throws an error.
 *
 * @param {number} [args.delay=60] - Number of seconds to wait for alerts.
 * @param {array} [args.unexpectedAlerts=["Sign", "Apple ID Verification"]] - Titles of unexpected alerts to match against.
 */
backUpRestoreUI.handleAlerts = function handleAlerts(args) {
    UIALogger.logMessage('Checking for alert(s) during background restore: %0'.format(args.unexpectedAlerts.join(', ')));
    this.withAlertHandler(restoreAlertHandler(args.unexpectedAlerts), function() {
        target.delay(args.delay);
    })

    // In case we landed on a locked screen after handling SU alert
    target.activeApp().tapIfExists(UIAQuery.buttons().contains('Later'));
}

/**
 * Check for Store Alert and handle it on Springboard.
 *
 * @param {number} [args.delay=60] - Number of seconds to wait for alerts.
 * @param {string} [args.unexpected_store_alerts="Sign In to iTunes Store"] - Title of unexpected alerts to match against.
 * @param {string} [args.iTunesPassword=""] - iTunes Password to enter in the blank
 */
backUpRestoreUI.handleStoreAlert = function handleStoreAlert(args) {
    UIALogger.logMessage('Checking for password alert(s) during background restore: %0'.format(args.unexpected_store_alerts));
    var app = target.activeApp();
    var PASSWORD_TEXTFIELD = UIAQuery.secureTextFields('Password');
    alertQuery = UIAQuery.alerts(args.unexpected_store_alerts);
    var alertHandler = function() {
        if (app.exists(alertQuery)) {
            UIALogger.logMessage("Received '" + app.inspect(alertQuery).label + "' Alert");
            var password = app.inspect(UIAQuery.alerts().andThen(PASSWORD_TEXTFIELD));
            if (password) {
                app.enterText(PASSWORD_TEXTFIELD, args.iTunesPassword);
                app.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('OK')));
                if (app.waitUntilPresent(PASSWORD_TEXTFIELD, 15)) {
                    throw new UIAError('iTunes Alert appeared again!!!');
                }
                return true;
            }
            return false;
        }
        return true;
    }
    this.withAlertHandler(alertHandler, function() {
        target.delay(args.delay);
    })
}
