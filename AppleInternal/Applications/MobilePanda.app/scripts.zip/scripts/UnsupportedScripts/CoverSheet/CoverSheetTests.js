load('UIATesting.js');
load('CoverSheet.js');
load('SpringBoard+InCallServices.js');
load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");

UIAUtilities.assert(typeof CoverSheetTests === 'undefined', 'CoverSheetTests has already been defined.')

/** @namespace */

CoverSheetTests = {
    /**
     * Navigates through the notificaiton center UI 
     */
    navigateNotificationCenter: function navigateNotificationCenter() {
        if (!coversheet.getToNotifications()) {
            throw new UIAError("Did not get to notification center");
        }

        target.clickMenu();
    },
    /**
     * Navigates through the Widgets view UI
     */
    navigateWidgetsView: function navigateWidgetsView() {
        if (!coversheet.getToWidgets()) {
            throw new UIAError("Did not get to Widgets view");
        }

        target.clickMenu();
    },
    /**
     * Navigates through the Camera view UI
     */
    navigateCameraView: function navigateCameraView() {
        if (!coversheet.getToCamera()) {
            throw new UIAError("Did not get to Camera view");
        }

        target.clickMenu();
    },
    /**
     * Verify that a widget is enabled or disabled in the Today View
     * @param {object} args  Test arguments
     * @param {array} [args.widgets=["Up Next", "Siri App Suggestions", "Weather", "Maps destinations", "Tips"]] - Title of widget displayed in Today view
     * @param {boolean} [args.enabled=true] - Flag indicating whether the widget should be enabled.
     */
    verifyWidgetEnabledOrDisabled: function verifyWidgetEnabledOrDisabled(args) {
        var args = UIAUtilities.defaults(args, {
                widgets:[
                    "Up Next",
                    "Siri App Suggestions",
                    "Weather", 
                    "Maps destinations",  
                    "Tips",
                ],
                enabled : true,
        });
        
        for (var index in args.widgets) {
            UIAUtilities.assertEqual(args.enabled, coversheet.isWidgetEnabled(args.widgets[index]));
            UIALogger.logMessage(args.widgets[index]+' '+'Widget is enabled');
        }
    },
    /**
     * Launch camera from Coversheet and take a photo
     */
    takePhotoViaCoverSheet: function takePhotoViaCoverSheet() {
        var irisWaiter = UIAWaiter.waiter("CameraIrisOpened");

        coversheet.getToCamera();

        if (!irisWaiter.wait(10)) {
            throw new UIAError("Camera Iris open event not received");
        } else {
            UIALogger.logDebug("recv'd Camera Iris open event");
        }

        // Need further delay here to ensure tap works
        camera = target.appWithBundleID('com.apple.camera');
        camera.delay(5);
        
        // No named camera buttons visible in coversheet via UIA2
        // Therefore use hardware button to invoke button tap
        target.clickVolumeDown();
        // Return back to locked screen
        target.clickMenu();
    },
}