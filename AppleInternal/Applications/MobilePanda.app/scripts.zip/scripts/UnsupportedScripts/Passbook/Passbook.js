load('UIAApp.js');
load('UIAUtility.js');
load('Safari.js');
load('UIAApp+Message.js');
load('Messages.js');
load('Settings');

UIAUtilities.assert(
    typeof Passbook === 'undefined',
    'Passbook has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Passbook queries */
UIAQuery.Passbook = {
    // Common Elements
    ADD_PASS_HEADER_BAR: UIAQuery.navigationBars().above(UIAQuery.contains('PKPassGroupStackView')),
    PASSES_CONTAINER: UIAQuery.scrollViews('PKPassGroupStackView').children().atIndex(2).children(),
    MESSAGES_MOST_RECENT_PASS: UIAQuery.contains('TranscriptCollectionView').children().bottommost(),
    APPLE_PAY_PASS_SUMMARY: UIAQuery.contains('PKPassFooterView'),

    // Views
    PASS_COLLECTION_VIEW: UIAQuery.scrollViews('PKPassGroupStackView').above(UIAQuery.staticTexts('Wallet')),
    INDIVIDUAL_PASS_VIEW: UIAQuery.scrollViews('PKPassGroupStackView').children().atIndex(2).children().above(UIAQuery.MORE_INFO_BUTTON),
    PASS_MORE_INFO_VIEW: UIAQuery.tableViews().above(UIAQuery.contains('PKPassBucketView')),
    ADD_APPLE_PAY_HERO_VIEW: UIAQuery.contains('PKPaymentSetupView').parent().andThen(UIAQuery.contains('PKPaymentSetupIntroView')),
    ADD_APPLE_PAY_CAMERA_VIEW: UIAQuery.contains('PKPaymentCameraCaptureView').parent().andThen(UIAQuery.contains('PKCameraCaptureInstructionView')),
    ADD_APPLE_PAY_NAME_NUMBER_VIEW: UIAQuery.contains('PKPaymentCardManualEntryView').parent().andThen(UIAQuery.contains('Name')),
    ADD_APPLE_PAY_EXPIRATION_CVV_VIEW: UIAQuery.contains('PKPaymentCardSecondaryManualEntryView').parent().andThen(UIAQuery.contains('Expiration Date')),
    ADD_PEER_PAYMENT_WELCOME_VIEW: UIAQuery.navigationBars('PKPeerPaymentWelcomeView'),
    ADD_PEER_PAYMENT_ACTIVATION_VIEW: UIAQuery.navigationBars('PKPeerPaymentPassActivationView'),
    PEER_PAYMENT_PASS_MORE_INFO_VIEW: UIAQuery.contains('PKPassHeaderView').above(UIAQuery.contains('PKPassView')),
    CARD_TYPE_PICKER_VIEW: UIAQuery.navigationBars('PKPaymentSetupFlowPickerView'),
    APPLE_PAY_PREVIOUSLY_DELETED_CARD_VIEW: UIAQuery.navigationBars('PKPaymentCredentialProvisioningView').parent().andThen(UIAQuery.contains('Enter your security code for your')),
    TERMS_AND_CONDITIONS_VIEW: UIAQuery.navigationBars('Terms and Conditions'),
    ADD_APPLE_PAY_PREVIOUS_CARD_VIEW: UIAQuery.navigationBars('PKPaymentCredentialProvisioningView').parent().andThen(UIAQuery.contains('card information.')),
    ADD_APPLE_PAY_MULTIPLE_PREVIOUS_CARDS_VIEW: UIAQuery.contains('PKPaymentCredentialsView').parent().andThen(UIAQuery.contains('Add Cards')),
    ADD_APPLE_PAY_CARD_ON_FILE_VIEW: UIAQuery.contains('PKPaymentCredentialProvisioningView').parent().andThen(UIAQuery.staticTexts('Verify your card information on file with iTunes or App Store.')),

    // Buttons
    CONFIRM_ADD_FROM_DETAIL_VIEW_BUTTON: UIAQuery.buttons('Add'),
    NEXT_FROM_DETAIL_VIEW_BUTTON: UIAQuery.buttons('Next'),
    AUTOMATICALLY_SELECT_FROM_DETAIL_VIEW_BUTTON: UIAQuery.staticTexts('Automatically Select'),
    MORE_INFO_BUTTON: UIAQuery.MORE_INFO_BUTTON,
    REMOVE_PASS_BUTTON: UIAQuery.contains('Remove Pass'),
    SECONDARY_REMOVE_PASS_BUTTON: UIAQuery.buttons('Remove'),
    SHARE_PASS_BUTTON: UIAQuery.contains('Share Pass'),
    SHARE_SHEET_MESSAGE_BUTTON: UIAQuery.contains('Message'),
    PASS_INFO_VIEW_DONE_BUTTON: UIAQuery.buttons('Done'),
    APPLE_PAY_ADD_PAYMENT_CARD_BUTTON: UIAQuery.buttons('PKContinuousButton'),
    ICLOUD_SIGN_IN_BUTTON: UIAQuery.buttons('Sign In'),
    SAFARI_ALERT_CONFIRMATION_BUTTON: UIAQuery.buttons('Allow'),
    ADD_APPLE_PAY_HERO_CANCEL_BUTTON: UIAQuery.buttons('Cancel'),
    ADD_APPLE_PAY_HERO_NEXT_BUTTON: UIAQuery.buttons('Next'),
    ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    ADD_APPLE_PAY_CAMERA_MANUAL_ENTRY_BUTTON: UIAQuery.buttons('Enter Card Details Manually'),
    ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    ADD_APPLE_PAY_NAME_NUMBER_NEXT_BUTTON: UIAQuery.buttons('Next'),
    ADD_APPLE_PAY_EXPIRATION_CVV_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    ADD_APPLE_PAY_EXPIRATION_CVV_NEXT_BUTTON: UIAQuery.buttons('Next'),
    REMOVE_APPLE_PAY_CARD_BUTTON: UIAQuery.staticTexts('Remove Card'),
    ADD_PEER_PAYMENT_WELCOME_CANCEL_BUTTON: UIAQuery.buttons('Cancel'),
    ADD_PEER_PAYMENT_WELCOME_NEXT_BUTTON: UIAQuery.buttons('Continue'),
    ADD_PEER_PAYMENT_ACTIVATION_DONE_BUTTON: UIAQuery.buttons('Done'),
    CARD_TYPE_PICKER_CREDIT_OR_PREPAID: UIAQuery.staticTexts('Credit or Prepaid Card'),
    CARD_TYPE_PICKER_BANK_CARD: UIAQuery.staticTexts('Credit or Debit Card'),
    ADD_APPLE_PAY_PREVIOUS_CARD_ADD_OTHER_BUTTON: UIAQuery.buttons('Add a Different Card'),
    TERMS_AND_CONDITIONS_AGREE_BUTTON: UIAQuery.buttons('Agree'),
    TERMS_AND_CONDITIONS_DISAGREE_BUTTON: UIAQuery.buttons('Disagree'),

    // Text Fields
    ADD_APPLE_PAY_NAME_TEXT_FIELD: UIAQuery.textFields('Name'),
    ADD_APPLE_PAY_NUMBER_TEXT_FIELD: UIAQuery.textFields('Card Number').orElse(UIAQuery.textFields('Number')),
    ADD_APPLE_PAY_EXPIRATION_TEXT_FIELD: UIAQuery.staticTexts('Expiration Date').siblings().contains('UITextField'),
    ADD_APPLE_PAY_CVV_TEXT_FIELD: UIAQuery.staticTexts('Security Code').siblings().contains('UITextField'),

    // Picker Wheels
    ADD_APPLE_PAY_EXPIRATION_MONTH_PICKER_WHEEL: UIAQuery.pickerWheels().atIndex(0),
    ADD_APPLE_PAY_EXPIRATION_YEAR_PICKER_WHEEL: UIAQuery.pickerWheels().atIndex(1),

    // Switches
    AUTOMATIC_UPDATES_SWITCH: UIAQuery.switches('Automatic Updates'),
    SUGGEST_ON_LOCK_SCREEN_SWITCH: UIAQuery.switches('Suggest on Lock Screen'),

    // Labels
    PEER_PAYMENTS_ACTIVATION_LABEL: UIAQuery.contains('PKTableHeaderView').children().atIndex(1), //This contains a non-ascii character between Apple and Pay. <rdar://problem/30571542>
    PEER_PAYMENTS_BALANCE_LABEL: UIAQuery.contains('BALANCE').siblings().atIndex(3),

    // Alerts
    REMOVE_PASS_ALERT: UIAQuery.actionSheets().contains('Are you sure you want to remove this pass?'),
    APPLE_PAY_REQUIRES_ICLOUD_ALERT: UIAQuery.alerts().andThen('Apple Pay Requires iCloud'),  //This contains a non-ascii character between Apple and Pay. <rdar://problem/30571542>
    ICLOUD_PASSWORD_REQUIRED_ALERT: UIAQuery.alerts().andThen('Sign In to iCloud'),
    ALLOW_LOCATION_ALERT: UIAQuery.alerts().andThen('Allow "Wallet" to access your location while you use the app?'),
    COULD_NOT_ADD_CARD_ALERT: UIAQuery.alerts().andThen('Could Not Add Card')
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Passbook */
UIStateDescription.Passbook = {
    /** Pass Collection State */
    PASS_COLLECTION:            'pass collection',

    /** Individual Pass State */
    INDIVIDUAL_PASS:            'individual pass',

    /** Pass More Info State */
    MORE_INFO:                  'more info',

    /** Add Apple Pay Card Hero State */
    APPLE_PAY_HERO:             'apple pay hero',

    /** Add Apple Pay Card Camera State */
    APPLE_PAY_CAMERA:           'apple pay camera',

    /** Add Apple Pay Name Number State */
    APPLE_PAY_NAME_NUMBER:      'apple pay name number',

    /** Add Apple Pay Expiration CVV State */
    APPLE_PAY_EXPIRATION_CVV:   'apple pay expiration cvv',

    /** Add Peer Payment Welcome View */
    PEER_PAYMENT_WELCOME:       'peer payment welcome',

    /** Add Peer Payment Activation View */
    PEER_PAYMENT_ACTIVATION:    'peer payment activation',

    /** Peer Payment Pass More Info View */
    PEER_PAYMENT_MORE_INFO:     'peer payment more info',

    /** Add card picker for Transit Region */
    CARD_TYPE_PICKER:           'card type picker',

    /** Add Apple Pay Previous Cards State */
    APPLE_PAY_ADD_PREVIOUS_CARD: 'apple pay add previous card',

    /** Add Apple Pay Card on File State */
    APPLE_PAY_ADD_CARD_ON_FILE: 'apple pay add card on file',

    /** Add Apple Pay Multiple Previous Cards State */
    APPLE_PAY_ADD_MULTIPLE_PREVIOUS_CARDS: 'apple pay add multiple previous cards',

    /** Apple Pay Previously Deleted Cards State */
    APPLE_PAY_PREVIOUSLY_DELETED_CARD: 'apple pay previously deleted card displayed when returning to Hero screen',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/** Constants for translating desired month into Acceptable Wallet formatted month */
WALLET_MONTHS = ['01 - January',
                 '02 - February,',
                 '03 - March',
                 '04 - April',
                 '05 - May',
                 '06 - June',
                 '07 - July',
                 '08 - August',
                 '09 - September',
                 '10 - October',
                 '11 - November',
                 '12 - December'];

APPLE_PAY_STRING = 'Apple Pay' ; //This contains a non-ascii character between Apple and Pay. <rdar://problem/30571542>


/**
@namespace
@augments UIAApp
*/
var Passbook = target.appWithBundleID('com.apple.Passbook');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Passbook for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
Passbook.currentUIState = function currentUIState() {
    var snapshot = this.inspect(UIAQuery.application());

    if (snapshot.exists(UIAQuery.Passbook.PASS_MORE_INFO_VIEW)) {
        return UIStateDescription.Passbook.MORE_INFO;
    }
    if (snapshot.exists(UIAQuery.Passbook.INDIVIDUAL_PASS_VIEW)) {
        return UIStateDescription.Passbook.INDIVIDUAL_PASS;
    }
    if (snapshot.exists(UIAQuery.Passbook.PASS_COLLECTION_VIEW)) {
        return UIStateDescription.Passbook.PASS_COLLECTION;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_HERO;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_CAMERA;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_NAME_NUMBER;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_EXPIRATION_CVV;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_PEER_PAYMENT_WELCOME_VIEW)) {
        return UIStateDescription.Passbook.PEER_PAYMENT_WELCOME;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_PEER_PAYMENT_ACTIVATION_VIEW)) {
        return UIStateDescription.Passbook.PEER_PAYMENT_ACTIVATION;
    }
    if (snapshot.exists(UIAQuery.Passbook.PEER_PAYMENT_PASS_MORE_INFO_VIEW)) {
        return UIStateDescription.Passbook.PEER_PAYMENT_MORE_INFO;
    }

    // By this point, we don't know where we are.
    throw new UIAError('Unable to figure out current UI state. We don\'t know where we are. This isn\'t where we parked our car....');
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/
/**
 * Navigates to the expected view.
 *
 * This function is used to navigate to an expected view. It will first evaluate if it's
 * already at the correct view. If it's not, it will return to top level and attempt to
 * navigate to the correct view.
 *
 * Expected starting states: Works for any known Passbook UI state.
 *
 * @param {object} options
 * @param {string} options.viewName - The view to navigate to.
 * @param {string} options.groupingName - The group name of the pass to navigate to. If navigating to anything lower than pass collection,
 *                                        grouping name is required.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud password to attempt if sign into iCloud prompt appears.
 *
 * @throws If an unknown state was given or navigation failed.
 */
Passbook.getToView = function getToView(options) {
    options = UIAUtilities.defaults(options, {
        viewName: null,
        groupingName: '',
        iCloudPassword: 'iCloud1234'
    });

    Passbook.launch();

    if (Passbook.currentUIState() === options.viewName) {
        UIALogger.logMessage('No need to change views. Current view is the correct view.');
        return;
    }

    Passbook.getToPassCollection();

    switch (options.viewName) {
        case UIStateDescription.Passbook.PASS_COLLECTION:
            break;
        case UIStateDescription.Passbook.INDIVIDUAL_PASS:
            Passbook.tap(UIAQuery.contains(options.groupingName));
            UIALogger.logMessage('Waiting up to 5 seconds for Pass View to Load.');
            if (!Passbook.waitUntilPresent(UIAQuery.Passbook.MORE_INFO_BUTTON, 5)) {
                throw new UIAError('Pass view took more than 5 seconds to appear on screen.')
            }
            break;
        case UIStateDescription.Passbook.MORE_INFO:
            Passbook.tap(UIAQuery.contains(options.groupingName));
            UIALogger.logMessage('Waiting up to 5 seconds for Pass View to Load.');
            if (!Passbook.waitUntilPresent(UIAQuery.Passbook.MORE_INFO_BUTTON, 5)) {
                throw new UIAError('Pass view took more than 5 seconds to appear on screen.')
            }

            var waitForMoreInfoPageToAppear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPassGroupsViewController"');
            UIALogger.logMessage('Tapping on the More Info Button.');
            Passbook.tap(UIAQuery.Passbook.MORE_INFO_BUTTON);
            if (!waitForMoreInfoPageToAppear.wait(5)) {
                throw new UIAError('Pass info view took more than 5 seconds to appear on screen.')
            }

            break;
        case UIStateDescription.Passbook.APPLE_PAY_HERO:
            Passbook.registerForApplePay(options);
            break;
        default:
            throw new UIAError('View %0 is either an unknown view or an unsupported view for getToView. Could not navigate to it.'.format(options.viewName));
    }
    UIALogger.logMessage('Current view is now %0.'.format(options.viewName));
};


/**
 * Navigates to the Pass Collection view.
 *
 * This function is used to navigate to the Pass Collection view. It will first evaluate if it's
 * already at the correct view. If it's not, it will return to top level (Pass Collection).
 *
 * Expected starting states: Works for any known Passbook UI state.
 *
 * @throws If an unknown state was given or navigation failed.
 */
Passbook.getToPassCollection = function getToPassCollection() {
    this.launch();

    var currentView = this.currentUIState();

    switch (currentView) {
        case UIStateDescription.Passbook.PASS_COLLECTION:
            UIALogger.logMessage('No need to get to Pass Collection. Current view is already Pass Collection.');
            break;
        case UIStateDescription.Passbook.INDIVIDUAL_PASS:
            this.tap(UIAQuery.Passbook.PASSES_CONTAINER);
            break;
        case UIStateDescription.Passbook.MORE_INFO:
            this.tap(UIAQuery.Passbook.PASS_INFO_VIEW_DONE_BUTTON);
            this.tap(UIAQuery.Passbook.PASSES_CONTAINER);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_HERO:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_CAMERA:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_NAME_NUMBER:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_EXPIRATION_CVV:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            break;
        case UIStateDescription.Passbook.PEER_PAYMENT_WELCOME:
            this.tap(UIAQuery.Passbook.ADD_PEER_PAYMENT_WELCOME_CANCEL_BUTTON);
            break;
        case UIStateDescription.Passbook.PEER_PAYMENT_ACTIVATION:
            this.tap(UIAQuery.Passbook.ADD_PEER_PAYMENT_ACTIVATION_DONE_BUTTON);
            break;
        case UIStateDescription.Passbook.PEER_PAYMENT_MORE_INFO:
            this.tap(UIAQuery.Passbook.PASS_INFO_VIEW_DONE_BUTTON);
            this.tap(UIAQuery.Passbook.PASSES_CONTAINER);
            break;
        default:
            throw new UIAError('View %0 is an unknown view.  Unable to get to Pass Collection.'.format(currentView));
    }
    UIALogger.logMessage('Now at Pass Collection View.');
};


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
 * Adds a pass to the device using Safari.
 *
 * This function is used to add a pass to the device using Safari.
 *
 * @param {string} url - The URL of the pkpass to navigate to in Safari.
 *
 */
Passbook.addPassFromSafari = function addPassFromSafari(url) {
    // This function requires a URL of the pass to visit.
    if (!url) {
        throw new UIAError('URL was not given in addPassFromSafari function.')
    }
    UIALogger.logMessage('Launching Safari to add a pass to the device.');
    safari.launch();
    // Wait for for either Pass view or alert to Appear to warn about launching Pass.
    var waitForSafariAlert = UIAWaiter.withPredicate('Alert', 'title = "This website is trying to show you a Wallet pass. Do you want to allow this?"');
    safari.enterURL(url);

    if (!waitForSafariAlert.wait(10)) {
        if(safari.exists(UIAQuery.Passbook.ADD_PASS_HEADER_BAR)) {
            UIALogger.logMessage('Alert did not appear but Pass is present.');
        }
        else {
            throw new UIAError('Neither the Safari alert to confirm you want to view a Wallet pass nor a Pass view appeared after 10 seconds.');
        }
    }
    else {
        // Tap Allow
        safari.tap(UIAQuery.Passbook.SAFARI_ALERT_CONFIRMATION_BUTTON);
    }

    // Tap Add to add the pass.
    if (safari.exists(UIAQuery.Passbook.CONFIRM_ADD_FROM_DETAIL_VIEW_BUTTON)) {
        safari.tap(UIAQuery.Passbook.CONFIRM_ADD_FROM_DETAIL_VIEW_BUTTON);
    }
    else if (safari.exists(UIAQuery.Passbook.NEXT_FROM_DETAIL_VIEW_BUTTON)) {
        var waitForAutomaticallySelectView = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "UITableViewController"')
        safari.tap(UIAQuery.Passbook.NEXT_FROM_DETAIL_VIEW_BUTTON);
        if (!waitForAutomaticallySelectView.wait(5)) {
            throw new UIAError('Automatically Select Page did not show within 5 seconds.');
        }
        safari.tap(UIAQuery.Passbook.AUTOMATICALLY_SELECT_FROM_DETAIL_VIEW_BUTTON);
        safari.tap('Done');
    }
    else {
        throw new UIAError('Add or Next button could not be found.');
    }
};


/**
 * Removes a pass from the device using Wallet.
 *
 * This function is used to remove a pass from the device using Wallet.
 *
 * Expected starting states:
 *              Any
 *
 * @param {string} groupingName - The name of the group of passes to remove.
 *
 */
Passbook.removePass = function removePass(groupingName) {
    Passbook.getToView({viewName: UIStateDescription.Passbook.MORE_INFO, groupingName: groupingName});

    UIALogger.logMessage('Removing Pass: %0.'.format(groupingName));

    var waitForPassViewToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKNavigationController"');
    UIALogger.logMessage('Tapping on Remove Pass.');
    if (Passbook.exists(UIAQuery.Passbook.REMOVE_PASS_BUTTON)) {
        Passbook.tap(UIAQuery.Passbook.REMOVE_PASS_BUTTON);
    }
    else if (Passbook.exists(UIAQuery.Passbook.REMOVE_APPLE_PAY_CARD_BUTTON)) {
        Passbook.tap(UIAQuery.Passbook.REMOVE_APPLE_PAY_CARD_BUTTON)
    }
    else {
        throw new UIAError('Could not find a remove button.')
    }
    Passbook.handlingAlertsInline(UIAQuery.Passbook.REMOVE_PASS_ALERT, function () {
        Passbook.tap(UIAQuery.Passbook.SECONDARY_REMOVE_PASS_BUTTON)
    });
    if (!waitForPassViewToDisappear.wait(5)) {
        throw new UIAError('Pass Info View took more than 5 seconds to disappear.')
    }

    // Confirm Pass disappears.
    UIALogger.logMessage('Waiting up to 5 seconds for Pass to disappear.');
    if(!Passbook.waitUntilAbsent(UIAQuery.Passbook.PASSES_CONTAINER.contains(groupingName), 5)) {
        throw new UIAError('Pass took more than 5 seconds to disappear.')
    }
};


/**
 * Adds a pass to the device using Messages.
 *
 * This function is used to add a pass to the device using Messages.
 * This function works off of the assumption that the most recent message
 * contains a pass and that the pass received in the thread is the one to be added.
 *
 * @param {string} threadName - The name of the thread containing the pass.
 *
 */
Passbook.addPassFromMessages = function addPassFromMessages(threadName) {
    UIALogger.logMessage('Adding Pass from Messages.');
    UIALogger.logMessage('Launched Messages and getting to thread list.');
    messages.launch();
    messages.getToThreadList();

    UIALogger.logMessage('Tapping on Messages thread: %0'.format(threadName));
    var waitForThreadToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "CKTranscriptCollectionViewController"');
    messages.tap(threadName);
    if (!waitForThreadToAppear.wait(5)) {
        throw new UIAError('Messages thread took more than 5 seconds to appear on screen.');
    }

    UIALogger.logMessage('Tapping on bottom most received message.');
    var waitForPassDetailsToAppearInMessages = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKAddPassesCardStackViewController"');
    messages.tap(UIAQuery.Passbook.MESSAGES_MOST_RECENT_PASS);
    if (!waitForPassDetailsToAppearInMessages.wait(5)) {
        throw new UIAError('Pass Details failed to load after 5 seconds.');
    }

    UIALogger.logMessage('Tapping on Add.');
    var waitForPassDetailsToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKRemoteAddPassesViewController"');
    messages.tap(UIAQuery.Passbook.CONFIRM_ADD_FROM_DETAIL_VIEW_BUTTON);
    if (!waitForPassDetailsToDisappear.wait(5)) {
        throw new UIAError('Pass Details failed disappear after 5 seconds.');
    }
};

/**
 * Shares a pass using Messages.
 *
 * This function is used to share the pass to a device using Messages.
 *
 * @param {string} recipient - The address of the recipient receiving the pass.
 * @param {string} groupingName - The name of the group of passes to remove.
 *
 */
Passbook.sharePassViaMessages = function sharePassViaMessages(recipient, groupingName) {
    UIALogger.logMessage('Sharing %0 pass via Messages to %1.'.format(groupingName, recipient));

    Passbook.getToView({viewName: UIStateDescription.Passbook.MORE_INFO, groupingName: groupingName});

    var waitForShareSheetToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "UIActivityGroupViewController"');
    UIALogger.logMessage('Selecting Share Pass.');
    Passbook.tap(UIAQuery.Passbook.SHARE_PASS_BUTTON);
    if (!waitForShareSheetToAppear.wait(5)) {
        throw new UIAError('Share sheet took more than 5 seconds to appear.');
    }

    var waitForMessagesSheetToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "CKComposeRecipientSelectionController"');
    UIALogger.logMessage('Selecting Message in share sheet.');
    Passbook.tap(UIAQuery.Passbook.SHARE_SHEET_MESSAGE_BUTTON);
    if (!waitForMessagesSheetToAppear.wait(5)) {
        throw new UIAError('Message compose sheet took more than 5 seconds to appear.');
    }

    var sendOptions = {
        recipients: recipient
    };
    Passbook.sendMessage(sendOptions);

    // Dismiss the view and pass.
    var waitForPassInfoViewToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKBarcodePassDetailViewController"');
    UIALogger.logMessage('Dismissing Pass Info View.');
    Passbook.tap(UIAQuery.Passbook.PASS_INFO_VIEW_DONE_BUTTON);
    if (!waitForPassInfoViewToDisappear.wait(5)) {
        throw new UIAError('Pass Info View took more than 5 seconds to disappear.');
    }

    // Dismiss the view and pass.
    Passbook.tap(groupingName);
    if(!Passbook.waitUntilPresent(UIAQuery.Passbook.PASS_COLLECTION_VIEW, 5)) {
        throw new UIAError('Pass took more than 5 seconds to dismiss to Pass Collection View.');
    }
};

/**
 * Manually updates a pass.
 *
 * This function is used to manually update the pass using the pass detail view.
 *
 * @param {string} groupingName - The name of the group of passes to remove.
 *
 */
Passbook.updatePass = function updatePass(groupingName) {
    UIALogger.logMessage('Updating Pass: %0'.format(groupingName));

    Passbook.getToView({viewName: UIStateDescription.Passbook.MORE_INFO, groupingName: groupingName});

    Passbook.pullToRefresh();

    Passbook.getToPassCollection();
};


/**
 * Register for Apple Pay.
 *
 * This function is used to register the device for Apple Pay.
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The password of the iCloud account to log into.
 *
 */
Passbook.registerForApplePay = function registerForApplePay(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: 'iCloud1234'
    });

    this.getToPassCollection();

    if(!this.isApplePayPresent()) {
        throw UIAError('Apple Pay is not present.  Apple pay must be present in Wallet to register for Apple Pay.');
    }

    this.withAlertHandler(this.registerForApplePayAlertHandler, function() {
        if (options.expectedFailureString === '') {
            //Validate that we are currently in registration view.
            if (this === Passbook) {
                this.tap(UIAQuery.Passbook.APPLE_PAY_ADD_PAYMENT_CARD_BUTTON);
            }
            else {
                this.tap(UIAQuery.settings.APPLE_PAY_ADD_PAYMENT_CARD_BUTTON);
            }
            if (!this.waitUntilPresent(UIAQuery.navigationBars('PKPaymentSetupView'), 60)) {
                throw new UIAError('Wallet took more than 60 seconds for Add Payment Card view to appear.');
            }
        }
        else {
            this.tap(UIAQuery.Passbook.APPLE_PAY_ADD_PAYMENT_CARD_BUTTON);
        }
    });
};

/**
 * Adds a payment pass to the device.
 *
 * This function is used to add a payment pass to the device.
 *
 * The default card number, expiration, and CVV are test card information and are not indicative of any production test data.
 *
 * @param {object}   options - The options relating to the pass to be added.
 * @param {string}  [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string}  [options.iCloudPassword=''] - The iCloud Password used.
 * @param {string}  [options.name="First Last"] - The name of the card holder.
 * @param {string}  [options.cardNumber="5555111111111111"] - The number of the card.
 * @param {string}  [options.expirationMonth="1"] - The expiration month of the card.
 * @param {string}  [options.expirationYear="2025"] - The expiration year of the card.
 * @param {string}  [options.cvv="123"] - The cvv of the card.
 * @param {boolean} [options.activate=true] - If Yellow flow and activate card, set boolean to true
 * @param {boolean} [options.shouldAgreeToTermsAndConditions=true] - Whether agree or disagree should be tapped
 * @param {boolean} [options.inSetupAssistant=false] - Flow control for a setup assistant test. If true, certain checks will be skipped.
 *
 */
Passbook.addApplePayCardManualEntry = function addApplePayCardManualEntry(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: '',
        name: 'Dwight K. Schrute',
        cardNumber: '',
        expirationMonth: '',
        expirationYear: '',
        cvv: '',
        activate: true,
        shouldAgreeToTermsAndConditions: true,
        inSetupAssistant: false,
    });

    if (!options.inSetupAssistant) {
        // Register for Apple Pay first.
        this.registerForApplePay(options);
    }

    this.withAlertHandler(this.addApplePayPassAlertHandler.bind(null, options), function() {
        // If this provision request is triggered in setup assistant, no need to tap next.
        if (!options.inSetupAssistant) {
            // Set up waiter for the view to appear
            var waitForHeroScreenToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentSetupHeroViewController"');

            // Tap Hero next button
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_NEXT_BUTTON);

            // Wait for the view to disappear
            if (!waitForHeroScreenToDisappear.wait(10)) {
                throw new UIAError('Apple pay hero view took more than 10 seconds to disappear.');
            }
        }

        UIALogger.logMessage('Need to find out what screen we are on, multiple options after Hero Screen.');
        // Choose to add transit card or bank card, and wait for the card type picker to disappear.
        if (this.currentUIState() === UIStateDescription.Passbook.CARD_TYPE_PICKER) {
            var waitForCardTypePickerToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentSetupFlowPickerViewController"');
            // Japan displays Prepaid
            if (this.exists(UIAQuery.Passbook.CARD_TYPE_PICKER_CREDIT_OR_PREPAID)) {
                this.tap(UIAQuery.Passbook.CARD_TYPE_PICKER_CREDIT_OR_PREPAID);
            }
            // China displays Debit
            else if (this.exists(UIAQuery.Passbook.CARD_TYPE_PICKER_BANK_CARD)) {
                this.tap(UIAQuery.Passbook.CARD_TYPE_PICKER_BANK_CARD);
            }
            else{
                throw new UIAError('Unable to find a valid add credit card button on Card Type picker screen.');
            }
            if (!waitForCardTypePickerToDisappear.wait(10)) {
                throw new UIAError('Card type picker view took more than 10 seconds to disappear.');
            }
        }

        if (this.currentUIState() === UIStateDescription.Passbook.APPLE_PAY_ADD_PREVIOUS_CARD || this.currentUIState() === UIStateDescription.Passbook.APPLE_PAY_ADD_CARD_ON_FILE || this.currentUIState() === UIStateDescription.Passbook.APPLE_PAY_ADD_MULTIPLE_PREVIOUS_CARDS) {
            UIALogger.logMessage('Add Previous Card(s) Screen.');
            var waitForCameraViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPaymentCameraCaptureViewController"');
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_PREVIOUS_CARD_ADD_OTHER_BUTTON);
            if (!waitForCameraViewToAppear.wait(10)) {
                throw new UIAError('Camera View took more than 10 seconds to appear.');
            }
        }

        if (this.currentUIState() === UIStateDescription.Passbook.APPLE_PAY_CAMERA) {
            UIALogger.logMessage('Capture card with Camera Screen.');
            // Camera Screen
            var waitForNameNumberViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPaymentCardManualEntryViewController"');
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_MANUAL_ENTRY_BUTTON);
            if (!waitForNameNumberViewToAppear.wait(10)) {
                throw new UIAError('Name Number View took more than 10 seconds to appear.');
            }
        }
        else {
            throw new UIAError('Did not make it to the camera screen.');
        }

        // Name + Card Number Screen
        if (options.name !== '') {
            this.enterName(options);
        }
        this.enterCardNumber(options);

        //Krypton Debit card does not need exp/cvv
        if (options.cvv !== ''){
            var waitForExpirationCVVViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPaymentCardSecondaryManualEntryViewController"');
        }

        this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_NEXT_BUTTON);
        if (options.cvv !== ''){
            if (!waitForExpirationCVVViewToAppear.wait(60)) {
                throw new UIAError('Expiration CVV View took more than 60 seconds to appear.');
            }
            // Expiration + CVV screen
            // Terms and conditions

            this.enterExpirationDate(options);
            this.enterCVV(options);
        }

        // Handle Terms and Conditions
        var waitForSecondProvisioningViewToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentCardSecondaryManualEntryViewController"');
        this.agreeOrDisagreeToTermsAndConditions(options);

        // If the Terms and Conditions were disagreed to then return
        if (!options.shouldAgreeToTermsAndConditions) {
            return true;
        }

        // Handle Provisioning Result
        if (this === settings) {
            options.cardLastFour = this.getLastFourOfFPAN(options.cardNumber);
        }

        // For uiautomationscripts, otp activation is not currently supported
        if (!waitForSecondProvisioningViewToDisappear.wait(60 * 10)) {
            throw new UIAError('Activation screen did not disappear within 60 seconds');
        }
    });
};

/**
 * Adds a Peer Payment Pass to the device.
 *
 * This function is used to add a peer payment pass to the device.
 *
 * Expected starting states:
 *              Peer Payments Hero Screen
 *
 * @param {object} options - The options relating to the pass to be added.
 */
Passbook.addPeerPaymentsCard = function addPeerPaymentsCard(options) {
    var waitForActivationViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPeerPaymentPassActivationViewController"');
    this.tap(UIAQuery.Passbook.ADD_PEER_PAYMENT_WELCOME_NEXT_BUTTON);
    if (!waitForActivationViewToAppear.wait(5)) {
        throw new UIAError('Activation view did not appear within 5 seconds.');
    }

    if(!this.waitForPeerPaymentPassToBeActive(options)) {
        throw new UIAError('Pass was not active after timeout.')
    }

    this.tap(UIAQuery.Passbook.ADD_PEER_PAYMENT_ACTIVATION_DONE_BUTTON)
};


/**
 * Resets Wallet to a good state.
 *
 * This function is used to reset wallet to a good state regardless of it's current state.
 */

Passbook.resetWallet = function resetWallet() {
    this.quit();
    this.getToPassCollection();
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
 * Determines if Apple Pay option is present in Wallet.
 *
 * Expected starting states:
 *              Wallet Pass Collection View
 *
 * @returns {boolean} - True if Apple Pay is present. False if not.
 */
Passbook.isApplePayPresent = function isApplePayPresent() {
    return this.exists(UIAQuery.Passbook.APPLE_PAY_ADD_PAYMENT_CARD_BUTTON);
};


/**
 * Turn on Automatic Updates
 *
 * Expected starting states:
 *              Pass More Info View
 */
Passbook.turnOnAutomaticUpdates = function turnOnAutomaticUpdates() {
    var automaticUpdatesEnabled = this.valueOf(UIAQuery.Passbook.AUTOMATIC_UPDATES_SWITCH);
    if (automaticUpdatesEnabled === '0') {
        UIALogger.logMessage('Enabling Automatic Updates.');
        Passbook.tap(UIAQuery.Passbook.AUTOMATIC_UPDATES_SWITCH);
    }
    else {
        UIALogger.logMessage('Automatic Updates already enabled.');
    }
};


/**
 * Turn off Automatic Updates
 *
 * Expected starting states:
 *              Pass More Info View
 */
Passbook.turnOffAutomaticUpdates = function turnOffAutomaticUpdates() {
    var automaticUpdatesEnabled = this.valueOf(UIAQuery.Passbook.AUTOMATIC_UPDATES_SWITCH);
    if (automaticUpdatesEnabled === '1') {
        UIALogger.logMessage('Disabling Automatic Updates.');
        Passbook.tap(UIAQuery.Passbook.AUTOMATIC_UPDATES_SWITCH);
    }
    else {
        UIALogger.logMessage('Automatic Updates already disabled.');
    }
};


/**
 * Turn on Suggest on Lock Screen
 *
 * Expected starting states:
 *              Pass More Info View
 */
Passbook.turnOnSuggestOnLockScreen = function turnOnSuggestOnLockScreen() {
    var suggestOnLockScreenEnabled = this.valueOf(UIAQuery.Passbook.SUGGEST_ON_LOCK_SCREEN_SWITCH);
    if (suggestOnLockScreenEnabled === '0') {
        UIALogger.logMessage('Enabling Suggest on Lock Screen.');
        Passbook.tap(UIAQuery.Passbook.SUGGEST_ON_LOCK_SCREEN_SWITCH);
    }
    else {
        UIALogger.logMessage('Suggest on Lock Screen is already enabled.');
    }
};


/**
 * Turn off Suggest on Lock Screen
 *
 * Expected starting states:
 *              Pass More Info View
 */
Passbook.turnOffSuggestOnLockScreen = function turnOffSuggestOnLockScreen() {
    var suggestOnLockScreenEnabled = this.valueOf(UIAQuery.Passbook.SUGGEST_ON_LOCK_SCREEN_SWITCH);
    if (suggestOnLockScreenEnabled === '1') {
        UIALogger.logMessage('Disabling Suggest on Lock Screen.');
        Passbook.tap(UIAQuery.Passbook.SUGGEST_ON_LOCK_SCREEN_SWITCH);
    }
    else {
        UIALogger.logMessage('Suggest on Lock Screen is already disabled.');
    }
};


/**
 * Pull to Manually Refresh Pass
 *
 * Expected starting states:
 *              Pass More Info View
 */
Passbook.pullToRefresh = function pullToRefresh() {
    this.dragDownInside(UIAQuery.application());
};


/**
 * Get the current Peer Payments Card Balance
 *
 * Expected starting states:
 *              Peer Payments Card More Info
 *
 * @returns {number} - A number representing the current balance.
 */
Passbook.peerPaymentsBalance = function peerPaymentsBalance() {
    var peerPaymentsBalance = this.nameOf(UIAQuery.Passbook.PEER_PAYMENTS_BALANCE_LABEL);
    peerPaymentsBalance = peerPaymentsBalance.substring(1);

    UIALogger.logMessage('Current Peer Payments Balance is %0'.format(peerPaymentsBalance));
    return Number(peerPaymentsBalance);
};


/**
 * The brightness slider is not necessarily indicative of the actual display brightness.
 * Until <rdar://problem/30292392> is fixed, this command uses a command line tool to analyze brightness.
 *
 *
 * Expected starting states:
 *              Any
 *
 * @returns {number} - Value between 0 and 1 representing current display brightness.
 */
Passbook.screenBrightness = function screenBrightness() {
    var brightnessResult = target.performTask('/usr/local/bin/setbright', [], 20);
    var brightness = brightnessResult.stdout;
    brightness = brightness.split(' ')[1];
    brightness = brightness.trim('\n');

    UIALogger.logMessage('Current Brightness is %0'.format(brightness));
    return Number(brightness);
};


/**
 * Enters the name of a card into the name field.
 *
 * This function is used to enter the name into the name field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.name=DEFAULT_CREDIT_CARD_NAME] - The name of the card holder.
 *
 */
Passbook.enterName = function enterName(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: '',
        name: 'Dwight K. Schrute',
    });
    // TODO: Check to validate correct screen
    // Enter Name.
    this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_TEXT_FIELD);
    this.typeString(options.name);
};


/**
 * Checks for Terms and Conditions sheet and taps on agree or disagree based on what is passed in
 *
 * This function is used to tap either agree/disagree on Terms and Conditions
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {boolean} [options.shouldAgreeToTermsAndConditions=true] - Whether agree or disagree should be tapped
 * @param {boolean} [options.termsAndConditionsExpected=true] - Whether we expect terms and conditions or not
 * @param {string} [options.cvv=''] - The cvv of the card.
 *
 */
Passbook.agreeOrDisagreeToTermsAndConditions = function agreeOrDisagreeToTermsAndConditions(options) {
    options = UIAUtilities.defaults(options, {
        shouldAgreeToTermsAndConditions: true,
        termsAndConditionsExpected: true,
        cvv: '',
    });

    // Check if we expect Terms and Conditions
    if (options.termsAndConditionsExpected){
        // Wait for terms to appear
        var timeToWaitForTermsAndConditionsView = 60;
        var waitForTermsAndConditionsViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'navigationItemTitle = "Terms and Conditions"');
        if (options.cvv !== '') {
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_NEXT_BUTTON);
        }
        if (!waitForTermsAndConditionsViewToAppear.wait(timeToWaitForTermsAndConditionsView)) {
            throw new UIAError('Terms and Conditions view took more than %0 seconds to appear.'.format(timeToWaitForTermsAndConditionsView));
        }

        else if (options.shouldAgreeToTermsAndConditions) {
            // Agree to Terms and Conditions
            UIALogger.logMessage('Tapping Agree in Terms and Conditions.');
            this.tap(UIAQuery.Passbook.TERMS_AND_CONDITIONS_AGREE_BUTTON);
        } else if (!options.shouldAgreeToTermsAndConditions) {
            // Disagree to Terms and Conditions
            UIALogger.logMessage('Tapping Disagree in Terms and Conditions.');
            this.tap(UIAQuery.Passbook.TERMS_AND_CONDITIONS_DISAGREE_BUTTON);
        }
    }
    else {
        this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_NEXT_BUTTON);
    }
};

/**
 * Enters the card number into the number field.
 *
 * This function is used to enter the card number into the card number field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=''] - The iCloud Password used.
 * @param {string} [options.cardNumber="5555111111111121"] - The card number.
 *
 */
Passbook.enterCardNumber = function enterCardNumber(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: '',
        cardNumber: '5555111111111121',
    });
    // Enter Card Number.
    this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NUMBER_TEXT_FIELD);
    this.typeString(options.cardNumber);
};


/**
 * Enters the expiration date into the expiration date field.
 *
 * This function is used to enter the card number into the card number field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.expirationMonth=DEFAULT_CREDIT_CARD_MONTH] - The expiration month of the card.
 * @param {string} [options.expirationYear=DEFAULT_CREDIT_CARD_YEAR] - The expiration year of the card.
 *
 */
Passbook.enterExpirationDate = function enterExpirationDate(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: '',
        expirationMonth: '',
        expirationYear: '',
    });

    // Enter Expiration Date
    this.setPickerValues(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_MONTH_PICKER_WHEEL, [WALLET_MONTHS[options.expirationMonth - 1]]);
    this.setPickerValues(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_YEAR_PICKER_WHEEL, [options.expirationYear]);
};


/**
 * Enters the cvv into the cvv field.
 *
 * This function is used to enter cvv into the cvv field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=''] - The iCloud Password used.
 * @param {string} [options.cvv=''] - The cvv of the card.
 *
 */
Passbook.enterCVV = function enterCVV(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: '',
        cvv: '',
    });

    // Enter CVV
    this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CVV_TEXT_FIELD);
    this.typeString(options.cvv);
};


/**
 * Get Apple Pay Pass Status
 *
 * Expected starting states:
 *              Individual Pass View
 *
 * @returns {string} - One of ['active', 'personalizing', 'busy', 'terminated', 'unknown']
 *
 * @throws If device is not in Individual Pass state before starting.
 */
Passbook.getApplePayPassStatus = function getApplePayPassStatus(passName) {
    var currentUIState = this.currentUIState();
    if (currentUIState !== UIStateDescription.Passbook.INDIVIDUAL_PASS) {
        throw new UIAError('Device is not in the correct UI state to query for Apple Pay pass state. Device needs to be in Individual Pass view. Current View is: %0'.format(currentUIState))
    }

    // Make sure the element shows before querying for content.
    var snapshot = this.inspect(UIAQuery.application());
    if (snapshot.exists(UIAQuery.Passbook.APPLE_PAY_PASS_SUMMARY)) {
        if (snapshot.exists(UIAQuery.contains('ready for Apple'))) {
            return 'active';
        }
        if (snapshot.exists(UIAQuery.contains('is being activated'))) {
            return 'personalizing';
        }
        if (snapshot.exists(UIAQuery.contains('when updates are complete'))) {
            return 'busy';
        }
        if (snapshot.exists(UIAQuery.contains('terminated'))) {
            return 'terminated';
        }

        UIALogger.logWarning('Unknown Apple Pay Pass State found.');
        //TODO: Figure out a way to determine unknown pass state given that pass states appear in entirely different UI elements.
        return 'unknown';
    }
    else {
        UIALogger.logWarning('Pass Summary was not on screen.');
        return 'unknown';
    }
};


/**
 * Waits for an Apple Pay Pass to be active.
 *
 * Expected starting states:
 *              Individual Pass View
 *
 * @param {object} options - The options relating to waiting for the pass to be active.
 * @param {number} options.timeout - The maximum number of seconds to wait for.
 * @param {number} options.pollTime - The amount of seconds between polls for status.
 * @returns {boolean} True if the pass is now active, false if it's not.
 */
Passbook.waitForApplePayPassToBeActive = function waitForApplePayPassToBeActive(options) {
    options = UIAUtilities.defaults(options, {
        timeout: 120,
        pollTime: 1,
        passName: 'MasterCard Rewards Card'
    });

    var timeout = (new Date().getTime() / 1000) + options.timeout;
    do {
        var currentPassState = this.getApplePayPassStatus(options.passName);
        switch (currentPassState) {
            case 'active':
                UIALogger.logMessage('Pass is now active.');
                return true;
            default:
                UIALogger.logMessage('Pass is not active. Current Pass State: %0'.format(currentPassState));
        }
        this.delay(options.pollTime)
    }
    while ((new Date().getTime() / 1000) < timeout);

    UIALogger.logMessage('Pass was not active after %0 seconds.'.format(options.timeout));
    return false;
};


/**
 * Waits for a Peer Payment pass to be active.
 *
 * Expected starting states:
 *              Add Peer Payment Activation View
 *
 * @param {object} options - The options relating to waiting for the pass to be active.
 * @param {number} [options.timeout=120] - The maximum number of seconds to wait for.
 * @param {number} [options.pollTime=1] - The amount of seconds between polls for status.
 * @returns {boolean} True if the pass is now active, false if it's not.
 */
Passbook.waitForPeerPaymentPassToBeActive = function waitForPeerPaymentPassToBeActive(options) {
    options = UIAUtilities.defaults(options, {
        timeout: 120,
        pollTime: 1
    });

    var timeout = (new Date().getTime() / 1000) + options.timeout;
    do {
        var currentPassState = this.nameOf(UIAQuery.Passbook.PEER_PAYMENTS_ACTIVATION_LABEL);

        if (currentPassState.includes('Activated')) {
            UIALogger.logMessage('Pass is now active.');
            return true;
        }
        else {
            UIALogger.logMessage('Pass is not active. Current Pass State: %0'.format(currentPassState));

        }
        this.delay(options.pollTime)
    }
    while ((new Date().getTime() / 1000) < timeout);

    UIALogger.logMessage('Pass was not active after %0 seconds.'.format(options.timeout));
    return false;
};


/**
 * Handle any alerts we receive while registering for Apple Pay.
 *
 * Expected starting states:
 *              Any
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud password to attempt if sign into iCloud prompt appears.
 * @returns {boolean} - Returns true of the alert was handled correctly, False if it wasn't.
 */
Passbook.registerForApplePayAlertHandler = function registerForApplePayAlertHandler(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: 'iCloud1234'
    });
    var app = target.activeApp();
    UIALogger.logMessage('In REGISTER FOR APPLE PAY ALERT HANDLER.');
    if (app.exists(UIAQuery.Passbook.ICLOUD_PASSWORD_REQUIRED_ALERT)) {
        // Type iCloud Password
        app.typeString(options.iCloudPassword);
        app.tap('OK');
        return true;
    }
    else if (options.expectedFailureString) {
        if (options.expectedFailureString === 'Apple Pay Requires iCloud') {
            if (app.exists(UIAQuery.Passbook.ICLOUD_PASSWORD_REQUIRED_ALERT)) {
                // Make sure it links to iCloud Settings correctly.
                var waitForSignInPageToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "AAUISignInViewController"');
                if (!app.waitUntilPresent(UIAQuery.Passbook.ICLOUD_SIGN_IN_BUTTON, 5)) {
                    throw new UIAError('iCloud Settings button took more than 5 seconds to appear.');
                }
                app.tap(UIAQuery.Passbook.ICLOUD_SIGN_IN_BUTTON);
                if (!waitForSignInPageToAppear.wait(5)) {
                    throw new UIAError('iCloud Settings did not open within 5 seconds.');
                }
                return true
            }
            else {
                throw new UIAError('Registration Alert did not match expected.')
            }
        }
        else {
            throw new UIAError('Expected Failure String is not currently supported.')
        }
    }
    return false
};


/**
 * Handle any alerts we receive while adding an Apple Pay Pass.
 *
 * Expected starting states:
 *              Any
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud password to attempt if sign into iCloud prompt appears.
 * @returns {boolean} - Returns true of the alert was handled correctly, False if it wasn't.
 */
Passbook.addApplePayPassAlertHandler = function addApplePayPassAlertHandler(options) {
    options = UIAUtilities.defaults(options, {
        expectedFailureString: '',
        iCloudPassword: 'iCloud1234'
    });
    var app = target.activeApp();
    UIALogger.logMessage('In ADD APPLE PAY PASS ALERT HANDLER.');
    if (app.exists(UIAQuery.Passbook.ICLOUD_PASSWORD_REQUIRED_ALERT)) {
        // Type iCloud Password
        app.typeString(options.iCloudPassword);
        app.tap('OK');
        return true;
    }
    else if (app.exists(UIAQuery.Passbook.ALLOW_LOCATION_ALERT)) {
        app.tap('Allow');
    }
    else if (app.exists(UIAQuery.Passbook.COULD_NOT_ADD_CARD_ALERT)) {
        if (options.expectedFailureString !== 'Could Not Add Card') {
            throw new UIAError('Unexpected Apple Pay Error: Could Not Add Card.');
        }
        else {
            return true
        }
    }
    return false
};