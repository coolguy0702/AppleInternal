load('Passbook.js');
load('SetupTests.js');
load('Settings+Passbook.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Wallet & Apple Pay queries */
// Using "setup" instead of "Setup" to avoid overwriting the one already defined in Setup.js
/*
UIAQuery.setup = {
    // Views
    ADD_APPLE_PAY_SETUP_ASSISTANT_HERO_VIEW: UIAQuery.navigationBars('PKPaymentSetupAssistantRegistrationView'),
};
*/

// Need to override the UIStateDescription for the Apple Pay Hero screen in Setup.js
// This is because our currentUIState() runs before Setup.js. The function we are overriding in order to run our logic-
// is kicked off once the first Apple Pay screen is encountered. So we need to teach Setup.js about the new UIStateDescription for that view.
//UIStateDescription.Setup["APPLE_PAY_DESC"] = UIStateDescription.Passbook.APPLE_PAY_HERO;


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/


/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Passbook for possible values.
 * The default Setup.js currentUIState function is stored before overwriting it
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
setup.defaultSetupAssistantCurrentUIState = setup.currentUIState;
setup.applePayCurrentUIState = function applePayCurrentUIState() {

    // Try Passbook Current UI State
    var snapshot = this.inspect(UIAQuery.application());

    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_CARD_ON_FILE_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_ADD_CARD_ON_FILE;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_PREVIOUS_CARD_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_ADD_PREVIOUS_CARD;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_MULTIPLE_PREVIOUS_CARDS_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_ADD_MULTIPLE_PREVIOUS_CARDS;
    }
    if (snapshot.exists(UIAQuery.Passbook.APPLE_PAY_PREVIOUSLY_DELETED_CARD_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_PREVIOUSLY_DELETED_CARD;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_CAMERA;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_NAME_NUMBER;
    }
    if (snapshot.exists(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_EXPIRATION_CVV;
    }
    if (snapshot.exists(UIAQuery.Passbook.CARD_TYPE_PICKER_VIEW)) {
        return UIStateDescription.Passbook.CARD_TYPE_PICKER;
    }
    if (snapshot.exists(UIAQuery.Passbook.TERMS_AND_CONDITIONS_VIEW)) {
        return UIStateDescription.Passbook.TERMS_AND_CONDITIONS;
    }

    // By this point, we don't know where we are.
    UIALogger.logMessage('Unable to figure out current Apple Pay UI state.');
    UIALogger.logMessage('Running default setup assistant currentUIState');

    // Run the currentUIState from Setup.js to identify what Setup Assitant screen we're on
    return setup.defaultSetupAssistantCurrentUIState();
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/
/**
 * Navigates to the Pass Collection view.
 *
 * This function is used to navigate to the Pass Collection view. It will first evaluate if it's
 * already at the correct view. If it's not, it will return to top level (Pass Collection).
 *
 * Expected starting states: Works for any known Passbook UI state.
 *
 * @throws If an unknssCollection;own state was given or navigation failed.
 */
setup.getToPassCollection = Passbook.getToPassCollection;


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

setup.setupAddApplePayCardManualEntry = function setupAddApplePayCardManualEntry(options) {
    // Set the new current UI State function to the Apple Pay one
    setup.currentUIState = setup.applePayCurrentUIState;

    // Run the add card function
    setup.addApplePayCardManualEntry(options);

    // Revert back to setup's default currentUIState function
    setup.currentUIState = setup.defaultSetupAssistantCurrentUIState;
};

/**
 * Adds a payment pass to the device.
 *
 * This function is used to add a payment pass to the device.
 *
 * The default card number, expiration, and CVV are test card information and are not indicative of any production test data.
 *
 * @param {object}   options - The options relating to the pass to be added.
 * @param {string}  [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string}  [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string}  [options.name="First Last"] - The name of the card holder.
 * @param {string}  [options.cardNumber="5555111111111111"] - The number of the card.
 * @param {string}  [options.expirationMonth="1"] - The expiration month of the card.
 * @param {string}  [options.expirationYear="2025"] - The expiration year of the card.
 * @param {string}  [options.cvv="123"] - The cvv of the card.
 * @param {string}  [options.color="Green"] - Expected Provisioning flow, Green, Yellow, Red, or Empty String.
 * @param {string}  [options.verificationOption="Email"] - The Verification Option to be used. 'Email' is only currently supported option.
 * @param {string}  [options.verificationCode="11111"] - The verification code to be used.
 * @param {boolean} [options.activate=true] - If Yellow flow and activate card, set boolean to true
 * @param {boolean} [options.alsoAddToWatch=false] - True or False if you are also adding the card to a paired watch, if it exists.
 * @param {boolean} [options.shouldAgreeToTermsAndConditions=true] - Whether agree or disagree should be tapped
 * @param {boolean} [options.useCardOnFile=false] - If Card On File flow is used this is set to true
 * @param {boolean} [options.useAutomaticSelection=true] - If the Automatic Selection view appears, should the pass be configured to automatically select.
 * @param {boolean} [options.setMockServerResponse=true] - If true, mock server response will be set
 * @param {string}  [options.MockServerController=""] - A MockServerController UUID if needed for the test.
 * @param {boolean} [options.provisionDuringDCIFlow=false] - If true, this provision request is triggered during transit DCI provision, should skip register/hero screen, also, should go back to DCI provision UI instead of individual pass UI after provision.
 *
 */
setup.addApplePayCardManualEntry = Passbook.addApplePayCardManualEntry;

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
 * Enters the cvv into the cvv field.
 *
 * This function is used to enter cvv into the cvv field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.cvv=DEFAULT_CREDIT_CARD_CVV] - The cvv of the card.
 *
 */
setup.enterCVV = Passbook.enterCVV;

/**
 * Enters the name of a card into the name field.
 *
 * This function is used to enter the name into the name field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.name=DEFAULT_CREDIT_CARD_NAME] - The name of the card holder.
 *
 */
setup.enterName = Passbook.enterName;

/**
 * Enters the card number into the number field.
 *
 * This function is used to enter the card number into the card number field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.cardNumber="5555111111111121"] - The card number.
 *
 */
setup.enterCardNumber = Passbook.enterCardNumber;

/**
 * Enters the expiration date into the expiration date field.
 *
 * This function is used to enter the card number into the card number field during provisioning.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud Password used.
 * @param {string} [options.expirationMonth=DEFAULT_CREDIT_CARD_MONTH] - The expiration month of the card.
 * @param {string} [options.expirationYear=DEFAULT_CREDIT_CARD_YEAR] - The expiration year of the card.
 *
 */
setup.enterExpirationDate = Passbook.enterExpirationDate;

/**
 * Handles Terms and Conditions sheet and taps on agree or disagree based on what is passed in
 *
 * This function is used to handle the Terms and Conditions sheet and tap either agree/disagree
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {boolean} [options.shouldAgreeToTermsAndConditions=true] - Whether agree or disagree should be tapped
 * @param {boolean} [options.termsAndConditionsExpected=true] - Whether we expect terms and conditions or not
 *
 */
setup.agreeOrDisagreeToTermsAndConditions = Passbook.agreeOrDisagreeToTermsAndConditions;

/*******************************************************************************/
/*                                                                             */
/*   Mark: Alert Handlers                                                      */
/*                                                                             */
/*      Handlers for when alerts appear on the screen.                         */
/*      E.g. registerForApplePayAlertHandler, enteriCloudPasswordWhenRequested */
/*                                                                             */
/*******************************************************************************/
/**
 * Handle any alerts we receive while adding an Apple Pay Pass.
 *
 * Expected starting states:
 *              Any
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword=DEFAULT_ICLOUD_PASSWORD] - The iCloud password to attempt if sign into iCloud prompt appears.
 * @returns {boolean} - Returns true of the alert was handled correctly, False if it wasn't.
 */
setup.addApplePayPassAlertHandler = Passbook.addApplePayPassAlertHandler;