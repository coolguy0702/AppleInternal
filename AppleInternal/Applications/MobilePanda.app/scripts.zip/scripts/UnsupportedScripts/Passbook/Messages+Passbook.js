load('Messages.js');
load('Passbook.js');
load('UIAApp+Message.js');
load('UIAApp+Passbook.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

// Navigation Bars
UIAQuery.Messages.CONVERSATION_THREAD_TITLE = UIAQuery.navigationBars('Messages').andThen(UIAQuery.staticTexts());

// Views
UIAQuery.Messages.APPSTORE.APPLE_PAY_BASIC_VIEW = UIAQuery.contains('PKPeerPaymentMessagesAmountStepperView');
UIAQuery.Messages.APPSTORE.APPLE_PAY_FULL_VIEW = UIAQuery.contains('PKPeerPaymentMessagesNumberPadView');

// Buttons
UIAQuery.Messages.APPSTORE.APPLE_PAY_BUTTON = UIAQuery.collectionViews('appSelectionBrowserIdentifier').andThen(UIAQuery.contains(APPLE_PAY_STRING));
UIAQuery.Messages.APPSTORE.APPLE_PAY_DECREMENT_AMOUNT_BUTTON = UIAQuery.buttons('stepperDecrementAmount');
UIAQuery.Messages.APPSTORE.APPLE_PAY_INCREMENT_AMOUNT_BUTTON = UIAQuery.buttons('stepperIncrementAmount');
UIAQuery.Messages.APPSTORE.APPLE_PAY_SHOW_KEYPAD_BUTTON = UIAQuery.staticTexts('Show Keypad');
UIAQuery.Messages.APPSTORE.APPLE_PAY_KEYPAD_DELETE_BUTTON = UIAQuery.buttons('numberPadDelete');
UIAQuery.Messages.APPSTORE.APPLE_PAY_PAY_BUTTON = UIAQuery.buttons('Pay');
UIAQuery.Messages.APPSTORE.APPLE_PAY_REQUEST_BUTTON = UIAQuery.buttons('Request');

// Labels
UIAQuery.Messages.APPSTORE.APPLE_PAY_STEPPER_AMOUNT_LABEL = UIAQuery.contains('PKPeerPaymentMessagesAmountStepperView').children().atIndex(1).children().atIndex(0);


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [state]                                                      */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/**
 * Get to a thread in Messages
 *
 * This function will attempt to get to a particular thread in messages.
 *
 * Expected starting states:
 *              Messages thread or thread list
 *
 * TODO: This thread should eventually handle multiple recipients and be moved to the messages file.
 * TODO: Support iPad once Peer Payments are supported.
 *
 * @param {object} options - The options for getting to a particular thread.
 * @param {string} [options.recipient] - The recipient of the thread.
 */
messages.getToThread = function getToThread(options) {
    options = UIAUtilities.defaults(options, {
        recipient: ''
    });

    if (options.recipient === '') {
        throw new UIAError('Recipient was not defined. Recipient must be defined to navigate to a thread.')
    }
    // Check that we're already in the thread, and if so, stay.
    var currentState = messages.currentUIState();

    if (currentState === UIStateDescription.Messages.CONVERSATION) {
        UIALogger.logMessage('Already in Conversation.');
        var currentRecipient = messages.nameOf(UIAQuery.Messages.CONVERSATION_THREAD_TITLE);
        if (currentRecipient === options.recipient) {
            return
        }
    }

    // Otherwise get to thread list
    messages.getToThreadList();

    // Check for thread in list,
    if (!messages.tapIfExists(options.recipient)) {
        messages.getToComposeUI();
        this.enterMessageRecipients([options.recipient]);
    }

    UIALogger.logMessage('Now in conversation thread view.');
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Tasks                                                               */
/*                                                                             */
/*      A high-level goal we are trying to accomplish.                         */
/*      Comprised of multiple Action functions and do not assume state         */
/*                                                                             */
/*******************************************************************************/

/**
 * Send a Peer Payment
 *
 * This function will send a peer payment to a recipient using messages.
 *
 * Expected starting states:
 *              Messages thread or thread list
 *
 * TODO: Support iPad once Peer Payments are supported.
 *
 * @param {object} options - The options for sending the peer payment.
 * @param {string} [options.recipient] - The recipient of the peer payment.
 * @param {string} [options.amount=1] - The amount of the payment to send.
 * @param {string} [options.method='stepper'] - The method to use when entering the payment amount (stepper or keypad).
 * @param {string} [options.primaryPaymentMethod='SURF'] - The primary payment method to use when sending the peer payment.
 * @param {string} [options.secondaryPaymentMethod=''] - The secondary payment method to use when sending the peer payment.
 * @param {string} [options.passcode='111111'] - The passcode used to authenticate when sending the peer payment.
 */
messages.sendPeerPayment = function sendPeerPayment(options) {
    options = UIAUtilities.defaults(options, {
        recipient: '',
        amount: 1,
        method: 'stepper',
        primaryPaymentMethod: 'SURF',
        secondaryPaymentMethod: '',
        passcode: '111111'

    });
    messages.getToThread(options);
    messages.openApplePayApp();
    messages.enterPaymentAmount(options);

    var waitForApplePayAppToDismiss = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "CKPresentationControllerRootViewController"');
    var waitForPaymentPayloadToLoad = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPeerPaymentMessagesContentRenderBubbleViewController"');

    messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_PAY_BUTTON);

    if (!waitForApplePayAppToDismiss.wait(5)) {
        throw new UIAError('Apple Pay App did not dismiss within 5 seconds.');
    }

    if (!waitForPaymentPayloadToLoad.wait(5)) {
        throw new UIAError('Apple Pay Payload did not appear within 5 seconds.')
    }

    // TODO: Add unique identifier to payment
    messages.tap(UIAQuery.Messages.SEND_BUTTON);
    // TODO: Validate Item has been sent on sender device.

    var paymentSheetOptions = {
        'passcode': options.passcode,
        'cardName': options.primaryPaymentMethod
    };

    messages.completeInAppTransaction(paymentSheetOptions);

};


/**
 * Send a Peer Payment
 *
 * This function will request a peer payment from a recipient using messages.
 *
 * Expected starting states:
 *              Messages thread or thread list
 *
 * TODO: Support iPad once Peer Payments are supported.
 *
 * @param {object} options - The options for requesting the peer payment.
 * @param {string} [options.recipient] - The recipient of the peer payment request.
 * @param {string} [options.amount=1] - The amount of the payment to request.
 * @param {string} [options.method='stepper'] - The method to use when entering the payment amount (stepper or keypad).
 */
messages.requestPeerPayment = function requestPeerPayment(options) {
    options = UIAUtilities.defaults(options, {
        recipient: '',
        amount: 1,
        method: 'stepper'
    });
    messages.getToThread(options);
    messages.openApplePayApp();
    messages.enterPaymentAmount(options);

    var waitForApplePayAppToDismiss = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "CKPresentationControllerRootViewController"');
    var waitForPaymentPayloadToLoad = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPeerPaymentMessagesContentRenderBubbleViewController"');

    messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_REQUEST_BUTTON);

    if (!waitForApplePayAppToDismiss.wait(5)) {
        throw new UIAError('Apple Pay App did not dismiss within 5 seconds.');
    }

    if (!waitForPaymentPayloadToLoad.wait(5)) {
        throw new UIAError('Apple Pay Payload did not appear within 5 seconds.')
    }

    // TODO: Add unique identifier to request
    messages.tap(UIAQuery.Messages.SEND_BUTTON);
    // TODO: Validate Item has been request on sender device.
};


/**
 * Complete a Requested Peer Payment
 *
 * This function will complete a previously requested peer payment.
 *
 * Expected starting states:
 *              Messages thread containing the peer payment request
 *
 * This function is not currently implemented.
 */
messages.completeRequestedPeerPayment = function completeRequestedPeerPayment() {
    throw new UIAError('Not currently Implemented.')
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Open the Apple Pay Messages App
 *
 * This function will open the Apple Pay Messages App.
 *
 * TODO: Support iPad once Peer Payments are supported.
 *
 * Expected starting states:
 *              Messages thread
 */
messages.openApplePayApp = function openApplePayApp() {
    if (messages.exists(UIAQuery.Messages.APPSTORE.APPLE_PAY_FULL_VIEW)) {
        UIALogger.logMessage('Already in Apple Pay Full View.');
        return
    }

    if (messages.exists(UIAQuery.Messages.APPSTORE.APPLE_PAY_BASIC_VIEW)) {
        UIALogger.logMessage('Already in Apple Pay Basic View.');
        return
    }

    if (!UIAQuery.Messages.APPSTORE_BUTTON) {
        throw new UIAError('Unable to find App Store Button.');
    }
    var appStoreSelected = messages.inspectElementKey(UIAQuery.Messages.APPSTORE_BUTTON, 'isSelected');
    var waitForApplePayAppToLoad = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPeerPaymentMessagesContentAmountEntryViewController"');
    if (!appStoreSelected && !messages.exists(UIAQuery.Messages.APPSTORE.APPLE_PAY_BUTTON)) {
        UIALogger.logMessage('Tapping AppStore button to open app store.');
        if (this.waitUntilPresent(UIAQuery.Messages.APPSTORE_BUTTON)) {
            this.tap(UIAQuery.Messages.APPSTORE_BUTTON);
        }

        UIALogger.logMessage('Waiting for app store to open.');
        if (!this.waitUntilPresent(UIAQuery.Messages.APPSTORE.MAIN_VIEW, 5)) {
            throw new UIAError('App store did not load within 5 seconds.');
        }
    }

    messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_BUTTON);

    if (!waitForApplePayAppToLoad.wait(5)) {
        throw new UIAError('Apple Pay App did not load within 5 seconds.')
    }

    UIALogger.logMessage('Now in Apple Pay View.');
};


/**
 * Get Peer Payment Status
 *
 * This function will get the current status of a peer payment.
 *
 * Expected starting states:
 *              Messages thread containing the peer payment.
 *
 * This function is not currently implemented.
 */
messages.getPeerPaymentStatus = function getPeerPaymentStatus() {
    throw new UIAError('Not currently Implemented.')
};


/**
 * Get Peer Payment Amount
 *
 * This function will get the amount of a peer payment.
 *
 * Expected starting states:
 *              Messages thread containing the peer payment.
 *
 * This function is not currently implemented.
 */
messages.getPeerPaymentAmount = function getPeerPaymentAmount() {
    throw new UIAError('Not currently Implemented.')
};


/**
 * Enter Payment Amount
 *
 * This function will enter the payment amount into the messages app using the desired method (stepper or keypad).
 *
 * Expected starting states:
 *              Apple Pay Messages App
 *
 * TODO: Support iPad once Peer Payments are supported.
 *
 * @param {object} options - The options for entering the payment amount.
 * @param {string} [options.amount=1] - The amount of the payment to enter.
 * @param {string} [options.method='stepper'] - The method to use when entering the payment amount (stepper or keypad).
 */
messages.enterPaymentAmount = function selectPaymentAmount(options) {
    options = UIAUtilities.defaults(options, {
        amount: 1,
        method: 'stepper' // stepper or keypad
    });

    if (options.method === 'stepper') {
        // TODO: Check for decimal points and throw not supported error

        // Tap increment if not enough
        while (messages.getStepperAmount() < options.amount) {
            messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_INCREMENT_AMOUNT_BUTTON);
        }

        // Tap decrement if too much
        while (messages.getStepperAmount() > options.amount) {
            messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_DECREMENT_AMOUNT_BUTTON);
        }
        UIALogger.logMessage('Stepper is now set to %0.'.format(options.amount));
    }
    else if (options.method === 'keypad') {
        // If in basic view, Keypad needs to be shown.
        if (!messages.exists(UIAQuery.Messages.APPSTORE.APPLE_PAY_FULL_VIEW)) {
            messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_SHOW_KEYPAD_BUTTON);

            // Wait for the keyboard to load.
            messages.waitForIdle();
        }

        // Clear keypad
        while (messages.getStepperAmount() !== 0) {
            messages.tap(UIAQuery.Messages.APPSTORE.APPLE_PAY_KEYPAD_DELETE_BUTTON);
        }

        // Enter amount
        var stringAmount = options.amount.toString();
        for (var characterIndex = 0, length = stringAmount.length;  characterIndex < length; characterIndex++) {
            messages.tap(UIAQuery.buttons(stringAmount[characterIndex]));
        }
        UIALogger.logMessage('Keypad is now set to %0.'.format(options.amount));
    }
    else {
        throw new UIAError('%0 is not a valid payment entry method.'.format(options.method))
    }
};


/**
 * Get Stepper Amount
 *
 * This function will get the current amount of the stepper in the Apple Pay Messages App.
 *
 * Expected starting states:
 *              Apple Pay Messages App
 *
 * TODO: Support iPad once Peer Payments are supported.
 */
messages.getStepperAmount = function getStepperAmount() {
    var stepperAmount = messages.nameOf(UIAQuery.Messages.APPSTORE.APPLE_PAY_STEPPER_AMOUNT_LABEL);
    stepperAmount = stepperAmount.substring(1);

    UIALogger.logMessage('Current payment amount is %0'.format(stepperAmount));
    return Number(stepperAmount);
};
