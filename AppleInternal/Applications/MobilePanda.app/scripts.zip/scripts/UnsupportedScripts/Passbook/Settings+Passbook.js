load('Passbook.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Wallet & Apple Pay queries */
UIAQuery.settings = {
    // Views
    PASS_COLLECTION_VIEW: UIAQuery.navigationBars('Wallet & Apple Pay'),  //This contains a NBSP character between Apple and Pay. <rdar://problem/30571542>
    PASS_MORE_INFO_VIEW: UIAQuery.contains('PKPassHeaderView').parent(),
    ADD_APPLE_PAY_HERO_VIEW: UIAQuery.contains('PKPaymentSetupView').parent().andThen(UIAQuery.contains('PKPaymentSetupIntroView')),
    ADD_APPLE_PAY_CAMERA_VIEW: UIAQuery.contains('PKPaymentCameraCaptureView').parent().andThen(UIAQuery.contains('PKCameraCaptureInstructionView')),
    ADD_APPLE_PAY_NAME_NUMBER_VIEW: UIAQuery.contains('PKPaymentCardManualEntryView').parent().andThen(UIAQuery.contains('Name')),
    ADD_APPLE_PAY_EXPIRATION_CVV_VIEW: UIAQuery.contains('PKPaymentCardSecondaryManualEntryView').parent().andThen(UIAQuery.contains('Expiration Date')),

    // Buttons
    REMOVE_PASS_BUTTON: UIAQuery.contains('Remove Pass'),
    SECONDARY_REMOVE_PASS_BUTTON: UIAQuery.buttons('Remove'),
    APPLE_PAY_ADD_PAYMENT_CARD_BUTTON: UIAQuery.staticTexts('Add Credit or Debit Card'),
    ICLOUD_SIGN_IN_BUTTON: UIAQuery.buttons('Sign In'),
    ADD_APPLE_PAY_HERO_CANCEL_BUTTON: UIAQuery.buttons('Cancel'),
    ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    ADD_APPLE_PAY_EXPIRATION_CVV_CANCEL_BUTTON: UIAQuery.buttons('Back'),
    REMOVE_APPLE_PAY_CARD_BUTTON: UIAQuery.staticTexts('Remove Card'),

    // Switches
    PEER_PAYMENTS_SWITCH: UIAQuery.switches('Apple Pay Cash'),  // This contains a non-ascii character between Apple and Pay. <rdar://problem/30571542>

    // Activity Indicators
    PEER_PAYMENTS_ACTIVITY_INDICATOR: UIAQuery.activityIndicators('In progress'),

    // Alerts
    REMOVE_PASS_ALERT: UIAQuery.actionSheets().contains('Are you sure you want to remove this pass?'),
    TURN_OFF_PEER_PAYMENTS_ALERT: UIAQuery.alerts('Turn off Apple Pay Cash')  // This contains a non-ascii character between Apple and Pay. <rdar://problem/30571542>
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/


/**
* Return description of current UI state.  See UIStateDescription constants defined in Passbook for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
settings.currentUIState = function currentUIState() {
    var snapshot = this.inspect(UIAQuery.application());

    if (snapshot.exists(UIAQuery.settings.ADD_APPLE_PAY_HERO_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_HERO;
    }
    if (snapshot.exists(UIAQuery.settings.ADD_APPLE_PAY_CAMERA_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_CAMERA;
    }
    if (snapshot.exists(UIAQuery.settings.ADD_APPLE_PAY_NAME_NUMBER_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_NAME_NUMBER;
    }
    if (snapshot.exists(UIAQuery.settings.ADD_APPLE_PAY_EXPIRATION_CVV_VIEW)) {
        return UIStateDescription.Passbook.APPLE_PAY_EXPIRATION_CVV;
    }
    if (snapshot.exists(UIAQuery.settings.PASS_MORE_INFO_VIEW)) {
        return UIStateDescription.Passbook.MORE_INFO;
    }
    if (snapshot.exists(UIAQuery.settings.PASS_COLLECTION_VIEW)) {
        return UIStateDescription.Passbook.PASS_COLLECTION;
    }

    return 'unknown'
};


/**
 * Navigates to the Pass Collection view.
 *
 * This function is used to navigate to the Pass Collection view. It will first evaluate if it's
 * already at the correct view. If it's not, it will return to top level (Pass Collection).
 *
 * Expected starting states: Works for any known Settings or Wallet & Apple Pay state.
 *
 * @throws If an unknown state was given or navigation failed.
 */
settings.getToPassCollection = function getToPassCollection() {
    this.launch();

    var currentView = this.currentUIState();

    switch (currentView) {
        case UIStateDescription.Passbook.APPLE_PAY_EXPIRATION_CVV:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_EXPIRATION_CVV_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_NAME_NUMBER:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_NAME_NUMBER_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_CAMERA:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_CAMERA_CANCEL_BUTTON);
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        case UIStateDescription.Passbook.APPLE_PAY_HERO:
            this.tap(UIAQuery.Passbook.ADD_APPLE_PAY_HERO_CANCEL_BUTTON);
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        case UIStateDescription.Passbook.MORE_INFO:
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        case UIStateDescription.Passbook.PASS_COLLECTION:
            UIALogger.logMessage('No need to get to Pass Collection. Current view is already Pass Collection.');
            break;
        case 'unknown':
            this.quit();
            this.navigateNavigationViews(['Wallet & Apple Pay']);
            break;
        default:
            throw new UIAError('View %0 is an unknown view.  Unable to get to Pass Collection.'.format(currentView));
    }
    UIALogger.logMessage('Now at Pass Collection View.');
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
 * Register for Apple Pay.
 *
 * This function is used to register the device for Apple Pay. This function is extended from Passbook.js
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The password of the iCloud account to log into.
 *
 */
settings.registerForApplePay = Passbook.registerForApplePay;


/**
 * Adds a payment pass to the device.
 *
 * This function is used to add a payment pass to the device. This function is extended from Passbook.js
 *
 * The default card number, expiration, and CVV are test card information and are not indicative of any production test data.
 *
 * @param {object} options - The options relating to the pass to be added.
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud Password used.
 * @param {string} [options.name="ApplePay Testing"] - The name of the card holder.
 * @param {string} [options.number="5555111111111111"] - The number of the card.
 * @param {string} [options.expirationMonth="1"] - The expiration month of the card.
 * @param {string} [options.expirationYear="2020"] - The expiration year of the card.
 * @param {string} [options.cvv="123"] - The cvv of the card.
 *
 */
settings.addApplePayCard = Passbook.addApplePayCard;

/**
 * Adds a Peer Payment Pass to the device.
 *
 * This function is used to add a peer payment pass to the device. This function is extended from Passbook.js
 *
 * Expected starting states:
 *              Peer Payments Hero Screen
 */
settings.addPeerPaymentsCard = Passbook.addPeerPaymentsCard;


/**
 * Removes a pass from the device using Wallet.
 *
 * This function is used to remove a pass from the device using Wallet.
 *
 * Expected starting states:
 *              Any
 *
 * @param {string} passName - The name of the Apple Pay pass to remove.
 *
 */
settings.removePass = function removePass(passName) {
    this.getToPassCollection();

    UIALogger.logMessage('Removing Pass: %0.'.format(passName));

    this.tap(UIAQuery.contains(passName));

    var waitForPassViewToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentPassDetailViewController"');
    UIALogger.logMessage('Tapping on Remove Pass.');
    if (this.exists(UIAQuery.Passbook.REMOVE_PASS_BUTTON)) {
        this.tap(UIAQuery.Passbook.REMOVE_PASS_BUTTON);
    }
    else if (this.exists(UIAQuery.Passbook.REMOVE_APPLE_PAY_CARD_BUTTON)) {
        this.tap(UIAQuery.Passbook.REMOVE_APPLE_PAY_CARD_BUTTON);
    }
    else {
        throw new UIAError('Could not find a remove button.')
    }
    this.handlingAlertsInline(UIAQuery.Passbook.REMOVE_PASS_ALERT, function () {
        this.tap(UIAQuery.Passbook.SECONDARY_REMOVE_PASS_BUTTON);
    });
    if (!waitForPassViewToDisappear.wait(5)) {
        throw new UIAError('Pass Info View took more than 5 seconds to disappear.')
    }

    // Confirm Pass disappears.
    UIALogger.logMessage('Waiting up to 5 seconds for Pass to disappear.');
    if(!this.waitUntilAbsent(UIAQuery.contains(passName), 5)) {
        throw new UIAError('Pass took more than 5 seconds to disappear.');
    }
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
 * Determines if Apple Pay option is present in Settings.
 *
 * Expected starting states:
 *              Settings Pass Collection View
 *
 * @returns {boolean} - True if Apple Pay is present. False if not.
 */
settings.isApplePayPresent = function isApplePayPresent() {
    return this.exists(UIAQuery.settings.APPLE_PAY_ADD_PAYMENT_CARD_BUTTON);
};


/**
 * Enables Peer Payments in Settings.
 *
 * Expected starting states:
 *              Settings Pass Collection View
 */
settings.enablePeerPayments = function enablePeerPayments() {
    var PeerPaymentsEnabled = this.valueOf(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
    if (PeerPaymentsEnabled === '0') {
        UIALogger.logMessage('Enabling Peer Payments.');
        this.tap(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
        // Either the toggle will disappear or a prompt to add will appear.
        if (!this.waitUntilPresent(UIAQuery.settings.PEER_PAYMENTS_ACTIVITY_INDICATOR, 5)) {
            throw new UIAError('Progress indicator did not appear within 5 seconds to enabling toggle.')
        }
        UIALogger.logMessage('Activity Indicator is present. Waiting up to 60 seconds for Card to be added successfully or for Welcome view to appear.');
        if (!this.waitUntilPresent(UIAQuery.settings.PEER_PAYMENTS_SWITCH.orElse(UIAQuery.Passbook.ADD_PEER_PAYMENT_WELCOME_VIEW), 60)) {
            throw new UIAError('Niether Peer Payments Switch or welcome view appeared within 60 seconds.')
        }

        UIALogger.logMessage('Waiting 2 seconds to make sure that the Welcome view does not appear.');
        if (this.waitUntilPresent(UIAQuery.Passbook.ADD_PEER_PAYMENT_WELCOME_VIEW)) {
            this.addPeerPaymentsCard();
        }

        // Make sure the toggle is turned on.
        PeerPaymentsEnabled = settings.valueOf(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
        if (PeerPaymentsEnabled === '1') {
            UIALogger.logMessage('Peer Payments successfully enabled.');
        }
        else {
            throw new UIAError('Peer Payments switch was still turned off after attempting to enable.')
        }
    }
    else {
        UIALogger.logMessage('Peer Payments is already enabled.');
    }
};


/**
 * Disables Peer Payments in Settings.
 *
 * Expected starting states:
 *              Settings Pass Collection View
 */
settings.disablePeerPayments = function disablePeerPayments() {
    var PeerPaymentsDisabled = settings.valueOf(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
    if (PeerPaymentsDisabled === '1') {
        UIALogger.logMessage('Disabling Peer Payments.');
        settings.handlingAlertsInline(UIAQuery.settings.TURN_OFF_PEER_PAYMENTS_ALERT, function() {
            settings.tap(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
            settings.tap('OK');

            // After turning toggle off, a spinner appears.  Wait for Spinner to turn into a toggle.
            UIALogger.logMessage('Waiting up to 5 seconds for progress spinner to appear.');
            if(!this.waitUntilAbsent(UIAQuery.settings.PEER_PAYMENTS_SWITCH, 5)) {
                throw new UIAError('Progress spinner took more than 5 seconds to appear after disabling Apple Pay Cash.');
            }
            // Confirm Toggle completes.
            UIALogger.logMessage('Waiting up to 20 seconds for Toggle to come back turned off.');
            if(!this.waitUntilPresent(UIAQuery.settings.PEER_PAYMENTS_SWITCH, 20)) {
                throw new UIAError('Peer Payments Switch took more than 20 seconds to come back after disabling Apple Pay Cash.');
            }

            // Make sure the toggle is turned off.
            PeerPaymentsDisabled = settings.valueOf(UIAQuery.settings.PEER_PAYMENTS_SWITCH);
            if (PeerPaymentsDisabled === '0') {
                UIALogger.logMessage('Peer Payments successfully disabled.');
            }
            else {
                throw new UIAError('Peer Payments switch was still turned on after attempting to disable.')
            }
        });
    }
    else {
        UIALogger.logMessage('Peer Payments is already disabled.');
    }
};


/**
 * Get Apple Pay Pass Status
 *
 * Expected starting states:
 *              Pass More Info View
 *
 * @returns {string} - One of ['active', 'personalizing', 'busy', 'terminated', 'unknown']
 *
 * @throws If device is not in Individual Pass state before starting.
 */
settings.getApplePayPassStatus = function getApplePayPassStatus(passName) {
    var currentUIState = this.currentUIState();
    if (currentUIState !== UIStateDescription.Passbook.PASS_COLLECTION) {
        throw new UIAError('Device is not in the correct UI state to query for Apple Pay pass state. Device needs to be in Pass Collection view. Current View is: %0'.format(currentUIState))
    }

    // Make sure the element shows before querying for content.
    var snapshot = this.inspect(UIAQuery.application());
    if (snapshot.exists(UIAQuery.contains(passName))) {
        if (snapshot.exists(UIAQuery.contains(passName).siblings().contains('ends with'))) {
            return 'active';
        }
        if (snapshot.exists(UIAQuery.contains(passName).siblings().contains('Activating'))) {
            return 'personalizing';
        }
        if (snapshot.exists(UIAQuery.contains('Unavailable'))) {
            return 'terminated';
        }

        UIALogger.logWarning('Unknown Apple Pay Pass State found.');
        return 'unknown';
    }
    else {
        UIALogger.logWarning('Pass was not on screen.');
        return 'unknown';
    }
};


/**
 * Waits for an Apple Pay Pass to be active. This function is extended from Passbook.js
 *
 * Expected starting states:
 *              Individual Pass View
 *
 * @param {object} options - The options relating to waiting for the pass to be active.
 * @param {number} options.timeout - The maximum number of seconds to wait for.
 * @param {number} options.pollTime - The amount of seconds between polls for status.
 * @param {passName} options.passName - The name of the pass to wait to be active.
 * @returns {boolean} True if the pass is now active, false if it's not.
 */
settings.waitForApplePayPassToBeActive = Passbook.waitForApplePayPassToBeActive;


/**
 * Waits for a Peer Payment pass to be active. This function is extended from Passbook.js
 *
 * Expected starting states:
 *              Add Peer Payment Activation View
 *
 * @param {object} options - The options relating to waiting for the pass to be active.
 * @param {number} [options.timeout=120] - The maximum number of seconds to wait for.
 * @param {number} [options.pollTime=1] - The amount of seconds between polls for status.
 * @returns {boolean} True if the pass is now active, false if it's not.
 */
settings.waitForPeerPaymentPassToBeActive = Passbook.waitForPeerPaymentPassToBeActive;


/**
 * Handle any alerts we receive while registering for Apple Pay. This handler is extended from Passbook.js
 *
 * Expected starting states:
 *              Any
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud password to attempt if sign into iCloud prompt appears.
 * @returns {boolean} - Returns true of the alert was handled correctly, False if it wasn't.
 */
settings.registerForApplePayAlertHandler = Passbook.registerForApplePayAlertHandler;


/**
 * Handle any alerts we receive while adding an Apple Pay Pass. This handler is extended from Passbook.js
 *
 * Expected starting states:
 *              Any
 *
 * @param {object} options
 * @param {string} [options.expectedFailureString=""] - A failure string if failure is expected.
 * @param {string} [options.iCloudPassword="iCloud1234"] - The iCloud password to attempt if sign into iCloud prompt appears.
 * @returns {boolean} - Returns true of the alert was handled correctly, False if it wasn't.
 */
settings.addApplePayPassAlertHandler = Passbook.addApplePayPassAlertHandler;
