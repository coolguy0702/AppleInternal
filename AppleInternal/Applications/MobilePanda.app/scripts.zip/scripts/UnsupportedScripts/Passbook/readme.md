App/Project/Feature: Passbook
Maintainer(s): Evan Smith
Maintainer(s) Email: evan_smith@apple.com
Maintainer(s) Team: Apple Pay Automation Team Apple_Pay_Automation_Team@group.apple.com
Maintainer(s) Team Manger: Kyle Diebolt
Maintainer(s) Team Manger Email: kdiebolt@apple.com
This app is used for managing loyalty cards, boarding passes, and payment cards.