load('UIAApp.js');
load('UIAUtility.js');

UIAUtilities.assert(
    typeof Syndrome === 'undefined',
    'Syndrome has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/
/** Constants for common Syndrome queries */
UIAQuery.Syndrome = {
    // Views
    OSLO_MENU_VIEW: UIAQuery.navigationBars('Syndrome'),
    PAYMENT_WIZARD_AMOUNT_VIEW: UIAQuery.navigationBars('Amount'),
    PAYMENT_WIZARD_SUPPORTED_CARDS_VIEW: UIAQuery.navigationBars('Supported Cards'),
    PAYMENT_WIZARD_SUMMARY_VIEW: UIAQuery.navigationBars('Supported Cards'),

    // Tabs
    OSLO_MENU_TAB_BUTTON: UIAQuery.buttons('Oslo'),

    // Buttons
    PAYMENT_WIZARD_MENU_BUTTON: UIAQuery.staticTexts('Payment Wizard'),
    PAYMENT_WIZARD_AMOUNT_NEXT_BUTTON: UIAQuery.buttons('Next'),
    PAYMENT_WIZARD_SUPPORTED_CARDS_NEXT_BUTTON: UIAQuery.buttons('Next'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/
/** Constants for possible UI state names specific to Syndrome */
UIStateDescription.Syndrome = {
    OSLO_MENU:                          'oslo menu',
    PAYMENT_WIZARD_AMOUNT:              'wizard amount',
    PAYMENT_WIZARD_SUPPORTED_CARDS:     'wizard supported cards',
    PAYMENT_WIZARD_SUMMARY:             'wizard summary'
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
@namespace
@augments UIAApp
*/
var Syndrome = target.appWithBundleID('com.apple.syndrome');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Syndrome for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
Syndrome.currentUIState = function currentUIState() {
    var snapshot = this.inspect(UIAQuery.application());

    if (snapshot.exists(UIAQuery.Syndrome.OSLO_MENU_VIEW)) {
        return UIStateDescription.Syndrome.OSLO_MENU;
    }
    if (snapshot.exists(UIAQuery.Syndrome.PAYMENT_WIZARD_AMOUNT_VIEW)) {
        return UIStateDescription.Syndrome.PAYMENT_WIZARD_AMOUNT;
    }
    if (snapshot.exists(UIAQuery.Syndrome.PAYMENT_WIZARD_SUPPORTED_CARDS_VIEW)) {
        return UIStateDescription.Syndrome.PAYMENT_WIZARD_SUPPORTED_CARDS;
    }
    if (snapshot.exists(UIAQuery.Syndrome.PAYMENT_WIZARD_SUMMARY_VIEW)) {
        return UIStateDescription.Syndrome.PAYMENT_WIZARD_SUMMARY;
    }

    // By this point, we don't know where we are.
    throw new UIAError('Unable to figure out current UI state. We don\'t know where we are. This isn\'t where we parked our car....');
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/
/**
 * Navigates to the Oslo Menu View.
 *
 * This function is used to navigate to the Oslo Menu view. It will first evaluate if it's
 * already at the correct view. If it's not, it will return to top level (Oslo Menu).
 *
 * Expected starting states: Works for any known Syndrome UI state.
 *
 * @throws If an unknown state was given or navigation failed.
 */
Syndrome.getToOsloMenu = function getToOsloMenu() {
    this.launch();

    var currentView = this.currentUIState();

    switch (currentView) {
        case UIStateDescription.Syndrome.OSLO_MENU:
            UIALogger.logMessage('No need to get to Oslo Menu. Current view is already Oslo Menu.');
            break;
        default:
            this.tap(UIAQuery.Syndrome.OSLO_MENU_TAB_BUTTON)
    }
    UIALogger.logMessage('Now at Oslo Menu View.');
};


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
 * Sets up an InApp Transaction
 *
 * This function is used to start up Syndrome's Payment Wizard and Initialize an
 * InApp transaction using the arguments supplied in options.
 *
 * Expected starting states: Oslo Menu
 *
 * @param {object} options - The options relating transaction to set up.
 * @param {string} [options.amount="1000"] - The amount of the transaction to set up excluding decimal points (1000 == $10.00).
 */
Syndrome.setupInAppTransaction = function setupInAppTransaction(options) {
    options = UIAUtilities.defaults(options, {
        amount: '1000', // $10.00, exclude decimal points
    });
    this.getToOsloMenu();

    var waitForAmountViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "SYNChooseAmountViewController"')
    this.tap(UIAQuery.Syndrome.PAYMENT_WIZARD_MENU_BUTTON);
    if (!waitForAmountViewToAppear.wait(5)) {
        throw new UIAError('Amount View did not appear within 5 seconds.')
    }
    var waitForSupportedCardsViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "SYNChoosePNOViewControllerTableViewController"')
    this.typeString(options.amount);
    this.tap(UIAQuery.Syndrome.PAYMENT_WIZARD_AMOUNT_NEXT_BUTTON);
    if (!waitForSupportedCardsViewToAppear.wait(5)) {
        throw new UIAError('Supported Cards View did not appear within 5 seconds.')
    }
    var waitForSummaryViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "SYNChargeSummaryTableViewController"')
    this.tap(UIAQuery.Syndrome.PAYMENT_WIZARD_SUPPORTED_CARDS_NEXT_BUTTON);
    if (!waitForSummaryViewToAppear.wait(5)) {
        throw new UIAError('Summary View did not appear within 5 seconds.')
    }
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
