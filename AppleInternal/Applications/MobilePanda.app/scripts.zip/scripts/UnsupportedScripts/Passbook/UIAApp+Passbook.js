load('Passbook.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

//Common Queries for UIAApp+Passbook
//Views
UIAQuery.Passbook.PAYMENT_SHEET_VIEW = UIAQuery.navigationBars('PKPaymentAuthorizationServiceView');
UIAQuery.Passbook.SELECT_CARD_VIEW = UIAQuery.navigationBars('Choose Card');

//Buttons
UIAQuery.Passbook.BUY_WITH_APPLE_PAY_BUTTON = UIAQuery.buttons('Buy with Apple Pay');
UIAQuery.Passbook.DISMISS_PAYMENT_SHEET_BUTTON = UIAQuery.buttons('Cancel');
UIAQuery.Passbook.PAY_WITH_PASSCODE_BUTTON = UIAQuery.buttons('Pay with Passcode');
UIAQuery.Passbook.SELECT_PAYMENT_CARD_BUTTON = UIAQuery.images('CARD').parent();
UIAQuery.Passbook.BACK_TO_PAYMENT_SHEET_BUTTON = UIAQuery.buttons('Back');


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/
/**
 * Complete an InApp transaction
 *
 * This function will open a payment sheet from the "Buy With Apple Pay" option, select the payment card
 * and then complete transaction by paying with passcode.
 *
 * Expected starting states:
 *              A screen with a "Buy with Apple Pay" button on it or a payment sheet already up.
 *
 * @param {object} options - The options for completing an InApp transaction.
 * @param {string} [options.passcode="111111"] - The passcode of the device to authenticate with.
 * @param {string} [options.cardName="MasterCard Rewards Card"] - The card to complete the transaction with.
 */
UIAApp.prototype.completeInAppTransaction = function completeInAppTransaction(options) {
    options = UIAUtilities.defaults(options, {
        passcode: '111111',
        cardName: 'MasterCard Rewards Card'
    });
    this.waitForIdle();

    if (!this.exists(UIAQuery.Passbook.PAYMENT_SHEET_VIEW)) {
        this.openPaymentSheet();
    }

    if (!this.exists(UIAQuery.contains(options.cardName))) {
        this.selectPaymentCard(options);
    }

    var waitForPasscodeViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PasscodeRemoteViewController"');
    if (!this.waitUntilPresent(UIAQuery.Passbook.PAY_WITH_PASSCODE_BUTTON, 5)) {
        throw new UIAError('Pay with Passcode button took more than 5 seconds to appear.');
    }
    this.tap(UIAQuery.Passbook.PAY_WITH_PASSCODE_BUTTON);

    if (!waitForPasscodeViewToAppear.wait(5)) {
        throw new UIAError('Passcode View did not appear within 5 seconds.');
    }
    var waitForDoneEvent = UIAWaiter.withPredicate('announcement', 'Done');
    var waitForPasscodeViewToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PasscodeRemoteViewController"');
    var waitForPaymentSheetToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentAuthorizationServiceViewController"');
    this.payWithPasscode(options);
    if (!waitForPasscodeViewToDisappear.wait(5)) {
        throw new UIAError('Passcode View did not disappear within 5 seconds.');
    }
    if (!waitForDoneEvent.wait(20)) {
        throw new UIAError('Did not receive Done stating successful transaction within 20 seconds.');
    }
    if (!waitForPaymentSheetToDisappear.wait(5)) {
        throw new UIAError('Payment Sheet did not dismiss within 5 seconds of receiving Done alert.');
    }
};
/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
 * Open Payment Sheet
 *
 * This function will open a payment sheet by tapping "Buy with Apple Pay"
 *
 * Expected starting states:
 *              A screen with a "Buy with Apple Pay" button on it
 */
UIAApp.prototype.openPaymentSheet = function openPaymentSheet() {
    if (this.exists(UIAQuery.Passbook.BUY_WITH_APPLE_PAY_BUTTON)) {
        var waitForPaymentSheetToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPaymentAuthorizationServiceViewController"');

        this.tap(UIAQuery.Passbook.BUY_WITH_APPLE_PAY_BUTTON);

        if (!waitForPaymentSheetToAppear.wait(5)) {
            throw new UIAError('Payment sheet did not come up within 5 seconds.');
        }
    }
    else {
        throw new UIAError('Could not find button to Buy with Apple Pay.');
    }
};


/**
 * Pay with Passcode
 *
 * This function will enter the passcode onto the Passcode entry screen when attempting to pay.
 *
 * Expected starting states:
 *              Pay With Passcode Screen
 *
 * @param {object} options - The options relating to paying with Passcode.
 * @param {string} [options.passcode="111111"] - The passcode of the device to authenticate with.
 */
UIAApp.prototype.payWithPasscode = function payWithPasscode(options) {
    options = UIAUtilities.defaults(options, {
        passcode: '111111'
    });

    for (var letterIndex = 0, length = options.passcode.length;  letterIndex < length; letterIndex++) {
        this.tap(UIAQuery.buttons(options.passcode[letterIndex]));
    }
};


/**
 * Select Payment Card
 *
 * This function will open the menu to select a payment card and select the requested card.
 *
 * Expected starting states:
 *              Apple Pay Payment Sheet
 *
 * @param {object} options - The options relating to selecting a payment card.
 * @param {string} [options.cardName="MasterCard Rewards Card"] - The card to select.
 */
UIAApp.prototype.selectPaymentCard = function selectPaymentCard(options) {
    options = UIAUtilities.defaults(options, {
        cardName: 'Mast1erCard Rewards Card'
    });
    var waitForPaymentCardSelectionViewToAppear = UIAWaiter.withPredicate('ViewDidAppear', 'navigationItemTitle = "Choose Card"');
    this.tap(UIAQuery.Passbook.SELECT_PAYMENT_CARD_BUTTON);
    if (!waitForPaymentCardSelectionViewToAppear.wait(5)) {
        throw new UIAError('Card selection screen failed to appear within 5 seconds.');
    }
    this.tap(UIAQuery.contains(options.cardName));
    var waitForPaymentCardSelectionViewToDisappear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass = "PKPaymentAuthorizationServiceViewController"');
    this.tap(UIAQuery.Passbook.BACK_TO_PAYMENT_SHEET_BUTTON);
    if (!waitForPaymentCardSelectionViewToDisappear.wait(5)) {
        throw new UIAError('Payment sheet did not return within 5 seconds.');
    }
};

/**
 * Dismiss Payment sheet
 *
 * This function will dismiss the payment sheet and return back to the app.
 *
 * Expected starting states:
 *              Apple Pay Payment Sheet
 */
UIAApp.prototype.dismissPaymentSheet = function dismissPaymentSheet() {
    var waitForPaymentSheetToDisappear = UIAWaiter.withPredicate('ViewDidDisappear', 'controllerClass = "PKPaymentAuthorizationServiceViewController"');
    this.tap(UIAQuery.Passbook.DISMISS_PAYMENT_SHEET_BUTTON);
    if (!waitForPaymentSheetToDisappear.wait(5)) {
        throw new UIAError('Payment sheet did not dismiss within 5 seconds.');
    }
};
