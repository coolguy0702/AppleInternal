The UnsupportedScripts folder is found at UIAutomationScripts/scripts/UnsupportedScripts and is for scripts that meet any of the following criteria:
	- Have no active maintainer
	- Have a maintainer(s) but the scripts do not follow one or more of the UIA2 Standards and Style Guidelines. See UIA2 Style Guide
	- Support platforms other than iPhone and iPad
		e.g. Watch
	- Are in transition: scripts have a maintainer(s) but a few changes need to be made before moving them out of the UnsupportedScripts folder

How to contribute to this folder?
	1) Create a subfolder for the app/project/feature you are automating and put your changes within.
		- Please note, only .js, .ptest, readme.txt, or readme.md files can be added. All other types will be rejected.
	2) Add a README file. This file should be formatted as follows:
		App/Project/Feature: <insert name>
		Maintainer(s): <insert maintainer(s)>
		Maintainer(s) Email: <insert maintainer(s) email>
		Maintainer(s) Team: <insert name of team maintaining these scripts. This CANNOT be the TestAutomation team unless formally agreed upon.>
		Maintainer(s) Team Manger: <insert name of manager>
		Maintainer(s) Team Manger Email: <insert email of manager>
		<Any other information you believe is relevant. Perhaps:
			- App/Project/Feature description
			- If the app is not first party, installation instructions
		>

		e.g.
		App/Project/Feature: ParadiseRiffSynthesizer
		Maintainer(s): Axl Rose
		Maintainer(s) Email: arose@apple.com
		Maintainer(s) Team: Guns N' Roses
		Maintainer(s) Team Manger: Slash
		Maintainer(s) Team Manger Email: slash@apple.com
		Scripts for ParadiseRiffSynthesizer app.

What does it mean if a person/team is listed as the maintainer?
This means any future bug fix radars for these scripts will be sent to that person/team. Any updates/enhancements to these scripts should be okayed with maintainer(s).

What does it mean if no person/team is listed as the maintainer?
Updates/Changes to the scripts are unrestricted. Scripts may be removed or edited in backwards incompatible ways with no notice.

What files CANNOT go into this folder?
Only .js, .ptest, readme.txt, or readme.md files are allowed in the UIAutomationScripts repository. All other file types will be rejected.
