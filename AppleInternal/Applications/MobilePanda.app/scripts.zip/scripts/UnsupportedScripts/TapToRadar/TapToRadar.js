load('UIAApp.js');

UIAUtilities.assert(
    typeof tapToRadar === 'undefined',
    'tapToRadar undefined'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      TapToRadar specific queries that will be made frequently               */
/*                                                                             */
/*******************************************************************************/

UIAQuery.TapToRadar = {
    COMPOSE_RADAR_BUTTON:            UIAQuery.buttons('Compose'),
    COMPONENT_SEARCHBAR:             UIAQuery.searchBars().contains('Search for more components'),

    CLOSE_RADAR_BUTTON:              UIAQuery.buttons('Close'), 
    SEND_RADAR_BUTTON:               UIAQuery.buttons('Send'), 

    SETTINGS_BUTTON:                 UIAQuery.buttons('Settings'),
    SIGNIN_BUTTON:                   UIAQuery.buttons('Sign in to Tap-to-Radar'),
    PASSWORD_TEXTFIELD:              UIAQuery.secureTextFields(),
    DONE_SIGNIN_BUTTON:              UIAQuery.buttons('Done'), 

    RETURN_NEW_RADAR_BUTTON:         UIAQuery.buttons('New Problem'),
    RETURN_NEW_DRAFT_RADAR_BUTTON:   UIAQuery.buttons('Tap-to-Radar'),

    DELETE_RADAR_BUTTON:             UIAQuery.buttons('Delete'),     
    SAVE_RADAR_BUTTON:               UIAQuery.buttons('Save'),
    CONTINUE_BUTTON:                 UIAQuery.buttons('Continue'),
    NOT_NOW_BUTTON:                  UIAQuery.buttons('Not Now'),

    TOP_LEVEL_TITLE:                 UIAQuery.navigationBars().contains('Tap-to-Radar'), 
    NEW_RADAR_TITLE:                 UIAQuery.contains('New Problem'),
    ATTACHMENTS:                     UIAQuery.staticTexts('Attachments'),
    GATHERING_ATTACHMENTS:           UIAQuery.staticTexts('Gathering Attachments...'),

    CANCEL_BUTTON:                   UIAQuery.buttons('Cancel'), 
    DELETE_DRAFT_RADAR:              UIAQuery.tableCells().andThen(UIAQuery.buttons('Delete')),
    CLASSIFICATION_BUTTON:           UIAQuery.staticTexts('Classification'),
    REPRODUCIBILITY_BUTTON:          UIAQuery.staticTexts().contains('Reproducib'),

    CLASSIFICATION_TITLE:            UIAQuery.navigationBars().contains('Classification'),
    REPRODUCIBILITY_TITLE:           UIAQuery.navigationBars().contains('Reproducible'),

    SHORTCUTS_POPUP_TITLE:           UIAQuery.staticTexts('Tap-to-Radar Shortcuts'),
    WHATS_NEW_POPUP_TITLE:           UIAQuery.staticTexts().contains("s New"),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

UIStateDescription.TapToRadar = {
    TOP_LEVEL:                         'top level',
    NEW_PROBLEM:                       'new problem',
    NEW_PROBLEM_DETAIL:                'new problem detail',
    NEW_DRAFT_PROBLEM_DETAIL:          'new draft problem detail',
    COMPONENT_LIST:                    'component list',
    CLASSIFICATION_LIST:               'classification list',
    REPRODUCIBILITY_LIST:              'reproducibility list',
    SETTING:                           'settings',
    LOGIN:                             'login',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 *   @namespace tapToRadar
 */
var tapToRadar = target.appWithBundleID('com.apple.TapToRadar');


/* Actions available after creating a radar */
tapToRadar.ACTIONS = {  
   NO_ACTION:                        'NoAction',
   SEND:                             'Send',
   SAVE_AS_DRAFT:                    'SaveAsDraft',
};

tapToRadar.CONSTANTS = {
   GATHERING_ATTACHMENTS_TIMEOUT:    360,
   SWIPE_DELETE_APPEAR:              5,
   ATTACHMENTS_IDX:                  3,  
   POPUP_TIMEOUT:                    15,
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription
 * constants defined in TapToRadar for possible values.
 * *
 * @returns {string} Description of current UI state from a list of
 *           possible constants contained in UIStateDescription.
 */
 tapToRadar.getCurrentUIState = function getCurrentUIState() {
    if (this.exists(UIAQuery.TapToRadar.TOP_LEVEL_TITLE)) {
    	return UIStateDescription.TapToRadar.TOP_LEVEL;
    }

    if (this.exists((UIAQuery.TapToRadar.COMPONENT_SEARCHBAR) &&
    		(UIAQuery.TapToRadar.CANCEL_BUTTON) && 
    		  (UIAQuery.TapToRadar.CONTINUE_BUTTON)
    	)) {
    	return UIStateDescription.TapToRadar.NEW_PROBLEM;
    }

    if (this.exists(UIAQuery.TapToRadar.RETURN_NEW_RADAR_BUTTON && 
            UIAQuery.TapToRadar.COMPONENT_SEARCHBAR
        )) {
        return UIStateDescription.TapToRadar.COMPONENT_LIST;
    }

    if (this.exists(UIAQuery.TapToRadar.RETURN_NEW_RADAR_BUTTON && 
            UIAQuery.TapToRadar.CLASSIFICATION_TITLE
    	)) {
    	return UIStateDescription.TapToRadar.CLASSIFICATION_LIST;
    }

    if (this.exists(UIAQuery.TapToRadar.RETURN_NEW_RADAR_BUTTON && 
            UIAQuery.TapToRadar.REPRODUCIBILITY_TITLE
    	)) {
    	return UIStateDescription.TapToRadar.REPRODUCIBILITY_LIST;
    }

    if (this.exists(UIAQuery.TapToRadar.NEW_RADAR_TITLE && 
        (UIAQuery.TapToRadar.RETURN_NEW_DRAFT_RADAR_BUTTON)
        )) {
        return UIStateDescription.TapToRadar.NEW_DRAFT_PROBLEM_DETAIL;
    }

    if (this.exists(UIAQuery.TapToRadar.NEW_RADAR_TITLE && 
        (UIAQuery.TapToRadar.CLOSE_RADAR_BUTTON && UIAQuery.TapToRadar.SEND_RADAR_BUTTON)
    	)) {
    	return UIStateDescription.TapToRadar.NEW_PROBLEM_DETAIL;
    }

    if (this.exists(UIAQuery.TapToRadar.SETTINGS_BUTTON)) {
    	return UIStateDescription.TapToRadar.SETTING;
    }

    if (this.exists(UIAQuery.TapToRadar.PASSWORD_TEXTFIELD)) {
    	return UIStateDescription.TapToRadar.LOGIN;
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Go to the top level UI state
 *
 */
tapToRadar.goToTopLevelView = function goToTopLevelView() {
    var maxDepth = 5;
    var currentState = this.getCurrentUIState();
    var startState = currentState;

    for (var i = 0; i < maxDepth; i++) {
    	currentState = this.getCurrentUIState();

        var waiter = UIAWaiter.waiter('ViewDidAppear');
        switch (currentState) {

            case UIStateDescription.TapToRadar.TOP_LEVEL:
                return;

            case UIStateDescription.TapToRadar.NEW_PROBLEM:
                this.tap(UIAQuery.TapToRadar.CANCEL_BUTTON);
                break;

            case UIStateDescription.TapToRadar.NEW_DRAFT_PROBLEM_DETAIL:
                this.tap(UIAQuery.TapToRadar.RETURN_NEW_DRAFT_RADAR_BUTTON);
                break;

            case UIStateDescription.TapToRadar.NEW_PROBLEM_DETAIL:
                this.tap(UIAQuery.TapToRadar.CLOSE_BUTTON);
                this.tap(UIAQuery.TapToRadar.DELETE_BUTTON);
                break;

            case UIStateDescription.TapToRadar.COMPONENT_LIST:
            case UIStateDescription.TapToRadar.CLASSIFICATION_LIST:
            case UIStateDescription.TapToRadar.REPRODUCIBILITY_LIST:
                this.tap(UIAQuery.TapToRadar.RETURN_NEW_RADAR_BUTTON);
                break;

            case UIStateDescription.TapToRadar.SETTINGS:
                this.tap(UIAQuery.TapToRadar.DONE_BUTTON);
                break;

            case UIStateDescription.TapToRadar.LOGIN:
                this.tap(UIAQuery.TapToRadar.CANCEL_BUTTON);             
                this.tap(UIAQuery.DONE_BUTTON);               
                break;

            default:
                throw new UIAError('Current UI State unexpected: %0'.format(currentState));

        }
        waiter.wait(2);
    }

    throw new UIAError('Could not get to top level from %0 UI'.format(startState));
}


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - createRadar          */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Create a new Radar
 *
 * @param {object} args - Argument dictionary
 * @param {string} args.component - Component to use in new radar
 * @param {string} args.classification - Classification to use in new radar
 * @param {string} args.reproducibility - Reproducibility to use in new radar
 * @param {string} args.title - Title to use in new radar
 * @param {string} args.description - Description to perform after create
 * @param {string} args.action - action to perform after create
 */
tapToRadar.createRadar = function createRadar(args) {
    this.launch();

    this.handlePopups();

    this.goToTopLevelView();

    var waiter = UIAWaiter.withPredicate(
        'ViewDidAppear', 
        'controllerClass = "Tap_to_Radar.DevicesAndCategoriesViewController" AND navigationItemTitle = "New Problem"'
    );
    this.tap(UIAQuery.TapToRadar.COMPOSE_RADAR_BUTTON);
    waiter.wait(5.0);

    this.setComponent(args.component);

    /* Wait here until the Attachments are generated */
    this.waitUntilPresent(UIAQuery.TapToRadar.ATTACHMENTS,tapToRadar.CONSTANTS.GATHERING_ATTACHMENTS_TIMEOUT);

    this.setClassification(args.classification);
    this.setReproducibility(args.reproducibility);

    this.setTitle(args.title);
    this.setDescription(args.description);

    if (args.action == tapToRadar.ACTIONS.SEND) {
    	this.tap(UIAQuery.TapToRadar.SEND_RADAR_BUTTON);
    }
    else if (args.action == tapToRadar.ACTIONS.SAVE_AS_DRAFT) {
        this.tap(UIAQuery.TapToRadar.CLOSE_RADAR_BUTTON);
        this.tap(UIAQuery.TapToRadar.SAVE_RADAR_BUTTON); 
    }
    else if (args.action == tapToRadar.ACTIONS.NO_ACTION) {
    	return;
    }
    else {
        throw new UIAError('Unknown action %0'.format(args.action));
    }
}

 /**
 * Delete a draft radar given its title.
 *
 * @param {object} args - Argument dictionary
 * @param {string} args.title - Title of draft radar to delete
 */
tapToRadar.deleteDraftRadar = function deleteDraftRadar(args) {
    this.launch();

    this.handlePopups();

    this.goToTopLevelView();

    var draftQuery = UIAQuery.staticTexts(args.title);
    this.assertExists(draftQuery,
        'Radar titled: %0 not found in drafts list.'.format(args.title));

    this.swipeLeft(UIAQuery.staticTexts(args.title));
    this.waitUntilPresent(UIAQuery.TapToRadar.DELETE_DRAFT_RADAR,tapToRadar.CONSTANTS.SWIPE_DELETE_APPEAR);
    this.tapIfExists(UIAQuery.TapToRadar.DELETE_RADAR_BUTTON);
}

 /**
 * Validate radar exists as a draft.
 *
 * @param {object} args - Argument dictionary
 * @param {string} args.component - Expected component of draft radar
 * @param {string} args.classification - Expected classification of draft radar
 * @param {string} args.reproducibility - Expected reproducibility of draft radar
 * @param {string} args.title - Expected title of draft radar 
 */
tapToRadar.validateDraftRadarCreated = function validateDraftRadarCreated(args) {
    this.goToTopLevelView();

    // Validate Radar with expected title exists as draft

    var draftQuery = UIAQuery.staticTexts(args.title);
    this.assertExists(draftQuery,
    	    'Radar titled: %0 not found in drafts list.'.format(args.title));

    // Go to Radar detail view and check each Radar field is as expected

    this.tap(draftQuery);

    this.assertExists(UIAQuery.staticTexts(args.component),
    	    'Radar titled: %0 component mismatch.'.format(args.title));

    this.assertExists(UIAQuery.staticTexts(args.classification),
    	    'Radar titled: %0 classification mismatch.'.format(args.classification));

    this.assertExists(UIAQuery.staticTexts(args.reproducibility),
    	    'Radar titled: %0 reproducibility mismatch.'.format(args.reproducibility));
}

 /**
 * Validate radar attachment(s) exist.
 *
 * @param {object} args - Argument dictionary
 * @param {string} args.title - Expected title of draft radar 
 */
tapToRadar.validateDraftRadarAttachmentsCreated = function validateDraftRadarAttachmentsCreated(args) {
    this.goToTopLevelView();

    // Validate Radar with expected title exists as draft

    var draftQuery = UIAQuery.staticTexts(args.title);
    this.assertExists(draftQuery,
    	    'Radar titled: %0 not found in drafts list.'.format(args.title));

    // Go to Radar detail view and check Radar attachments exist

    this.tap(args.title)
    
    this.tap(UIAQuery.tableCells().atIndex(tapToRadar.CONSTANTS.ATTACHMENTS_IDX));
    this.assertExists((UIAQuery.images('Paperclip')));

    // Return to know draft radar state
    this.tap(UIAQuery.TapToRadar.RETURN_NEW_RADAR_BUTTON);
    this.tap(UIAQuery.TapToRadar.RETURN_NEW_DRAFT_RADAR_BUTTON);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - getNoteCount                     */
/*      Other helper functions. E.g. - getNoteTextContent                      */
/*                                                                             */
/*******************************************************************************/

/**
 * Set the radar component.
 * Note: Assumes device is in component list view.
 *
 * @param {string} component - Component to use in the new radar
 */
tapToRadar.setComponent = function setComponent(component) {
    UIALogger.logMessage('In set component: %0:'.format(component));

    // rdar://problem/39789905
    var componentQuery = UIAQuery.tableViews('UITableView').last().andThen(UIAQuery.staticTexts(component));
    this.scrollToVisible(componentQuery);
    this.tapIfExists(componentQuery);
    this.tapIfExists(UIAQuery.TapToRadar.CONTINUE_BUTTON);
}

/**
 * Set the radar classification.
 * Note: Assumes device is in New Problem view.
 *
 * @param {string} classification - Classification to use for new radar
 */
tapToRadar.setClassification = function setClassification(classification) {
    UIALogger.logMessage('In set classification: %0:'.format(classification));

    this.tap(UIAQuery.TapToRadar.CLASSIFICATION_BUTTON);
    this.tap(classification);   
}

/**
 * Set the radar reproducibility.
 * Note: Assumes device is in New Problem view.
 *
 * @param {string} reproducibility - Reproducibility to use for new radar
 */
tapToRadar.setReproducibility = function setReproducibility(reproducibility) {
    UIALogger.logMessage('In set repro: %0:'.format(reproducibility));

    this.tap(UIAQuery.TapToRadar.REPRODUCIBILITY_BUTTON);
    this.tap(reproducibility);
}

/**
 * Set the radar title.
 * Note: Assumes device is in New Problem view.
 *
 * @param {string} title - Title to use for new radar
 */
tapToRadar.setTitle = function setTitle(title) {
    this.enterText(UIAQuery.tableCells().atIndex(this.count(UIAQuery.tableCells()) - 2).andThen(UIAQuery.textViews().last()), title, {'clearTextBeforeTyping': false});
}

/**
 * Set the radar description.
 * Note: Assumes device is in New Problem view.
 *
 * @param {string} description - Description to use for new radar
 */
tapToRadar.setDescription = function setDescription(description) {
    // rdar://problem/39720834
    this.drag(UIAQuery.tableViews('UITableView').last(), {fromOffset: {x: 0.5, y: 0.4}, toOffset: {x: 0.5, y: 0.2}});
    this.enterText(UIAQuery.tableCells().atIndex(this.count(UIAQuery.tableCells()) - 1).andThen(UIAQuery.textViews().last()), description, {'clearTextBeforeTyping': false});
}

/**
 * Get number of radars on the list
 * 
 * @returns {integer} - The number of radars on the list
 */
tapToRadar.getNumberOfRadars = function getNumberOfRadars() {
    this.launch();
    this.goToTopLevelView();
    var numberOfRadars = this.count(UIAQuery.tableCells());
    UIALogger.logMessage('Number of radars on the list: %0'.format(numberOfRadars));
    return numberOfRadars;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/* Handle all popups that happen when app is launched */
tapToRadar.handlePopups = function handlePopups() {
    if (this.waitUntilPresent(UIAQuery.TapToRadar.SHORTCUTS_POPUP_TITLE, tapToRadar.CONSTANTS.POPUP_TIMEOUT)) {
        UIALogger.logMessage('"Siri Shortcuts" splash screen detected. Trying to dismiss it...');
        this.tap(UIAQuery.TapToRadar.NOT_NOW_BUTTON);
        // Wait until splash screen is dismissed
        if (this.exists(UIAQuery.TapToRadar.SHORTCUTS_POPUP_TITLE)) {
            UIAUtilities.assert(
                (this.waitUntilAbsent(UIAQuery.TapToRadar.SHORTCUTS_POPUP_TITLE, tapToRadar.CONSTANTS.POPUP_TIMEOUT)),
                'Failed to dismiss "Siri Shortcuts" splash screen in %0 seconds'.format(tapToRadar.CONSTANTS.POPUP_TIMEOUT)
            );
        }
        UIALogger.logMessage('"Siri Shortcuts" splash screen dismissed successfully');
    }
    
    if (this.waitUntilPresent(UIAQuery.TapToRadar.WHATS_NEW_POPUP_TITLE, tapToRadar.CONSTANTS.POPUP_TIMEOUT)) {
        UIALogger.logMessage('"Whats New" splash screen detected. Trying to dismiss it...');
        this.tap(UIAQuery.TapToRadar.CONTINUE_BUTTON);
        // Wait until splash screen is dismissed
        if (this.exists(UIAQuery.TapToRadar.WHATS_NEW_POPUP_TITLE)) {
            UIAUtilities.assert(
                (this.waitUntilAbsent(UIAQuery.TapToRadar.WHATS_NEW_POPUP_TITLE, tapToRadar.CONSTANTS.POPUP_TIMEOUT)),
                'Failed to dismiss "Whats New" splash screen in %0 seconds'.format(tapToRadar.CONSTANTS.POPUP_TIMEOUT)
            );
        }
        UIALogger.logMessage('"Whats New" splash screen dismissed successfully');
    }
}


