load('UIATesting.js');
load('TapToRadar.js');

UIAUtilities.assert(
    typeof TapToRadarTests === 'undefined',
    'TapToRadarTests undefined'
);

/**
 * Default TapToRadar testing arguments. 
 */
var TEST_ARG_DEFAULTS = {
    TITLE:           'Title for a Test Radar about Accessibility',
    DESCRIPTION:     'Here is a description for the test Radar about Accessibility',
    COMPONENT:       'Accessibility',
    CLASSIFICATION:  'Security',
    REPRODUCIBILITY: 'Always',
    ACTION:           tapToRadar.ACTIONS.SAVE_AS_DRAFT,
};


/**
 * @namespace TapToRadarTests
 */
var TapToRadarTests = {
    /**
     * Create a new Radar
     * 
     * @targetApps TapToRadar
     *
     * @param {object} args - Tests arguments
     * @param {string} [args.title="Title for a Test Radar about Accessibility"] - Title of test Radar
     * @param {string} [args.description="Here is a description for the test Radar about Accessibility"] - Description of test Radar
     * @param {string} [args.component="Accessibility"] - Component of test Radar
     * @param {string} [args.classification="Security"] - Classification of test Radar
     * @param {string} [args.reproducibility="Always"] - Reproducibility of test Radar
     * @param {string} [args.action="SaveAsDraft"] - Action to take after create operation
     */
    createRadar: function createRadar(args) {
        args = UIAUtilities.defaults(args, {
            title: TEST_ARG_DEFAULTS.TITLE,
            description: TEST_ARG_DEFAULTS.DESCRIPTION,
            component: TEST_ARG_DEFAULTS.COMPONENT,
            classification: TEST_ARG_DEFAULTS.CLASSIFICATION,
            reproducibility: TEST_ARG_DEFAULTS.REPRODUCIBILITY,
            action: TEST_ARG_DEFAULTS.ACTION,
        });

        tapToRadar.createRadar(args);

        tapToRadar.validateDraftRadarCreated(args);

        tapToRadar.validateDraftRadarAttachmentsCreated(args);
    },

    /**
     * Delete a new Radar given its title
     *
     * @targetApps TapToRadar
     *
     * @param {object} args - Tests arguments
     * @param {string} [args.title="Title for a Test Radar about Accessibility"] - Title of test Radar to delete
     */
    deleteDraftRadar: function deleteDraftRadar(args) {
        args = UIAUtilities.defaults(args, {
            title: TEST_ARG_DEFAULTS.TITLE,
        });
        var initialNumber = tapToRadar.getNumberOfRadars();
        tapToRadar.deleteDraftRadar(args);
        var currentNumber = tapToRadar.getNumberOfRadars();
        UIAUtilities.assert(
            ((initialNumber - currentNumber) === 1),
            'Final number of radars is incorrect: expected "%0", actual "%1"'.format((initialNumber - 1), (currentNumber))
        );
    },

}
