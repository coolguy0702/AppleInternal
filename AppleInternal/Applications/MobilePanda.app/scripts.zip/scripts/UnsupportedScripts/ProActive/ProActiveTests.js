load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('UIAUtility.js');
load('Predict.js');
load('OSET.js');
load('International.js');
load('Notes+International.js');
load('Clock.js');
load('Contacts.js');
load('ProActive.js');

UIAUtilities.assert(
    typeof ProActiveTests === 'undefined', 
    'ProActiveTests has already been defined.'
);

/**
 * @namespace PredictiveTypingTests
 */
 var ProActiveTests = {
        /**
         * Add a new contact to the addressbook
         *
         * @targetApps Contacts
         *
         * @param {object} args - Test arguments
         * @param {string} [args.firstName="TestFirstName"] - Required first name of new contact
         * @param {string} [args.lastName=null] - Optional last name of new contact
         * @param {string} [args.company=null] - Optional company of the new contact
         * @param {string} [args.phone=null] - Optional Phone number of the contact
         * @param {string} [args.email=null] - Optional Email of the contact
         * @param {string} [args.url=null] - Optional URL of the contact
         */
         AddContact: function AddContact(args) {
         	    args = UIAUtilities.defaults(args, {
		                firstName: "TestFirstName",
		                lastName: null,
		                company: null,
		                phone: null,
		                email: null,
		                url: null,
            	});

            	var firstName = ['James', 
            					     // 'Jess',
            					     // 'Brent',
            					     // 'Sarika',
            					     // 'Jeff',
            					     'Ben'
                                ];

            	var phone = ['(213) 456-7891',
            				    // '(213) 456-7892',
            				    // '(213) 456-7893',
            				    // '(213) 456-7894',
            				    // '(213) 456-7895',
            				    '(213) 456-7896'
                            ];

               var email = ['james@icloud.com', 
                            // 'jess@icloud.com',
                            // 'brent@icloud.com',
                            // 'sarika@icloud.com',
                            // 'jeff@icloud.com',
                            'ben@icloud.com'
                            ];


            	/* add a contact */
            	for(var i=0; i<firstName.length; i++){
            		contacts.addNewContact({firstName: firstName[i],phone:phone[i], email: email[i]});
            	}

         },

         /**
          * Selecting contact for My Info
          *
          * @param {array} noteContents - Array of strings to be
          *                     typed into the note.
          * @param {object} options - Options dictionary
          *
          */


         BMyInfo: function MyInfo(args){

            var settings = target.appWithBundleID("com.apple.Preferences");
            settings.launch();
            settings.tap("Contacts");
            settings.tap("My Info");
            settings.tap("Ben");

         },

         /**
          * Create a note
          *
          * @param {array} noteContents - Array of strings to be
          *                     typed into the note.
          * @param {object} options - Options dictionary
          * @param {string} options.folder - Folder name where note will be created
          * @param {string} options.leaveOpenForEditing - If set, note will not
          *                  be validated after creation but rather will be
          *                  left open for editing.
          */


         CreateNote: function CreateNote(args){
                /* create note */
               var args = UIAUtilities.defaults(args, {
                 title: ' ',
                 body: ' ',
                 folder: 'Notes',
                 leaveOpenForEditing: true,
               });

               notes.createNote(
                 [' ', ' '],
                 args
               );  
         },


          /**
           * ProActive Notes Test
           *
           * @param {object} args - Test arguments
           * @param {string} [args.statement="Give James a call on "] - Required statement  
           * @param {string} [args.expectedString="James, (213) 456-7891"] - Required expectedstring
           */

          ProActiveNotesTest: function ProActiveNotesTest(args){
               var args = UIAUtilities.defaults(args, {
                          statement: "Give James a call on ",
                          expectedString: "James, (213) 456-7891",

               });

            // if(target.activeApp != target.appWithBundleID("com.apple.mobilenotes")){
            //     notes.createNote(
            //        [' ', ' '],
            //        args
            //      ); 

            //      if (!this.exists(UIAQuery.keyboard().isVisible())) {
            //           this.tap(UIAQuery.Notes.NOTE_TEXT_CONTENT);
            //       } 

            //   target.activeApp().typeString(args.statement);
            //   UIATarget.localTarget().delay(3);
            //   ProActive.compareProActiveCell(args.expectedString);
            //   key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
            //   target.activeApp().tap(key);
            //   UIATarget.localTarget().delay(2);

            // }else{

              target.activeApp().typeString(args.statement);
              UIATarget.localTarget().delay(3);
              ProActive.compareProActiveCell(args.expectedString);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              UIATarget.localTarget().delay(2);
            //}
            
          },
   };

