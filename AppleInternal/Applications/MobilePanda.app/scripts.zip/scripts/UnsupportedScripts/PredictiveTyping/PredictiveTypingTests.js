load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('UIAUtility.js');
load('Predict.js');

UIAUtilities.assert(
    typeof PredictiveTypingTests === 'undefined', 
    'PredictiveTypingTests has already been defined.'
);


/**
 * @namespace PredictiveTypingTests
 */
 var PredictiveTypingTests = {
    /**
      * Navigate to each specified Predict view (used for App History search).
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string[]} [args.views=["Alarm", "Timer"]] - The Predict views to navigate to.
      */

    PredictiveTypingTest: function PredictiveTypingTest (args){ 
    args = UIAUtilities.defaults(args, {
            navigationViews: ["General", "Auto-Lock"],
            checkItem: "Never",
            validate: true,
        });

        var languages= ['English',
                        'German (Germany)',
                        'Italian',
                        'Spanish (Spain)',
                        'French',
                        'Portuguese (Portugal)',
                        'Thai']; 
        var types = ['',
                     '',
                     '',
                     '',
                     '',
                     '',
                     ''];

        var keyboards= ['en_US@hw=US;sw=QWERTY',
                        'de_DE@hw=German;sw=QWERTZ-German',
                        'it_IT@hw=Italian - Pro;sw=QWERTY',
                        'es_ES@hw=Spanish - ISO;sw=QWERTY-Spanish',
                        'fr_FR@hw=French;sw=AZERTY-French',
                        'pt_PT@hw=Portuguese;sw=QWERTY',
                        'th_TH@hw=Thai;sw=Thai'];

        //English
        var english1= "Can you get me a glass of water ?";
        var english2= "You need to go to work .";
        var eng1 = english1.split(" ");
        var eng2 = english2.split(" ");

        //German
        var german1= "Wie spät ist es ?";
        var german2= "Ich bin gleich zurück .";
        var ger1 = german1.split(" ");
        var ger2 = german2.split(" ");


        //Italian
        var italian1= "Sono in ritardo ."
        var italian2= "Vieni con noi ?";
        var ita1 = italian1.split(" ");
        var ita2 = italian2.split(" ");

        //Spanish
        var spanish1= "Busca a los niños en el colegio .";
        //Get well soon
        var spanish2= "No hablo español muy bien .";
        //I don't speak Spanish very well.
        var spa1 = spanish1.split(" ");
        var spa2 = spanish2.split(" ");

        //French
        var french1= "Quand est-ce que tu arrives ce soir ?";
        var french2= "Qu'est-ce que tu veux manger ?";
        var fre1 = french1.split(" ");
        var fre2 = french2.split(" ");

        //Portguguese
        var portuguese1= "Tem um bom dia .";
        //Have a nice day
        var portuguese2= "Você fala inglês ?";
        //Do you speak English
        var por1 = portuguese1.split(" ");
        var por2 = portuguese2.split(" ");

        //Thai
        var thai1= 'ทำอะไร';
        var thai2= 'สวัสดี';
        var tha1 = thai1.split(" ");
        var tha2 = thai2.split(" ");


    /* add keyboards */

    for (var i = 0; i < languages.length; i++) {
         settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
    }

    /* create note */

      args = UIAUtilities.defaults(args, {
        title: ' ',
        body: ' ',
        folder: 'Notes',
        leaveOpenForEditing: true,
      });

      notes.createNote(
        [' ', ' '],
        args
      );  

    UIALogger.logMessage('Checkpoint1');

    /* switch to first keyboard*/ 
    for (var i = 0; i < languages.length; i++) {
         var keyboardID = target.activeApp().getKeyboardID();
         UIALogger.logMessage('keyboardID ' + keyboardID);

          while (keyboards[i] != keyboardID) {
              target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
              keyboardID = target.activeApp().getKeyboardID()
           } //while

         switch (keyboards[i]) {
           
           case 'en_US@hw=US;sw=QWERTY': 
              target.activeApp().typeString("Predictive Typing for English: ");
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(eng1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(2);

              predictive.predictiveArray(eng2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              //Needs Compare

              break;

            case 'de_DE@hw=German;sw=QWERTZ-German':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);


              predictive.predictiveArray(ger1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(ger2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

            case 'it_IT@hw=Italian - Pro;sw=QWERTY':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(ita1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(ita2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

            case 'es_ES@hw=Spanish - ISO;sw=QWERTY-Spanish':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(spa1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(spa2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

            case 'fr_FR@hw=French;sw=AZERTY-French':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(fre1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(fre2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

            case 'pt_PT@hw=Portuguese;sw=QWERTY':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(por1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(por2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

            case 'th_TH@hw=Thai;sw=Thai':
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              predictive.predictiveArray(tha1);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              UIATarget.localTarget().delay(1);

              predictive.predictiveArray(tha2);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);

              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              break;

          }//switchKeyboard
          UIALogger.logPass(">>>>>>>>>>>>>>>>>>>>>>Pass Test: " + languages[i] + ' ' + keyboardID);
      }//for
 }, //english typing test

     /**
      * Navigate to each specified Predict view (used for App History search).
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string[]} [args.views=["Alarm", "Timer"]] - The Predict views to navigate to.
      */


    SpellingCorrection: function SpellingCorrection (args){ 

      var englishSpelling= "You cna use it if yuo thimk it could be good for waht we are doign";
      var englishExpected= "You can use it if you think it could be good for what we are doing";
      var frenchSpelling= "Apres qeu la motr ait paur l'inhumani .";
      var frenchExpected= "Après que la mort ait paur l'inhumain.";

      var languages= ['English',
                      'French']; 

      var keyboards= ['en_US@hw=US;sw=QWERTY',
                      'fr_FR@hw=French;sw=AZERTY-French'];



      for (var i = 0; i < languages.length; i++) {
          var keyboardID = target.activeApp().getKeyboardID();
          UIALogger.logMessage('keyboardID ' + keyboardID);

          while (keyboards[i] != keyboardID) {
              target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
              keyboardID = target.activeApp().getKeyboardID()
           } //while

         switch (keyboards[i]) {
           
           case 'en_US@hw=US;sw=QWERTY': 
              target.activeApp().typeString("Spelling Correction for English and French: ");
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              target.activeApp().typeString(englishSpelling);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              var n = englishSpelling.localeCompare(englishExpected);
                if ( n == 0){
                  UIALogger.logPass(">>>>>>>>>>>>>>>>>>>>>>Pass Test: English Spelling Correction")
                }
              break;   

            case 'fr_FR@hw=French;sw=AZERTY-French':
              target.activeApp().typeString(frenchSpelling);
              key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
              target.activeApp().tap(key);
              var n = frenchSpelling.localeCompare(frenchExpected);
                if ( n == 0){
                  UIALogger.logPass(">>>>>>>>>>>>>>>>>>>>>>Pass Test: French Spelling Correction")
                }
              break;   

            }//switch
        }//for
    },//SpellingCorrection

    /**
      * Navigate to each specified Predict view (used for App History search).
      *

      * @param {object} args - Test arguments
      * @param {string} [args.testcontext="Beijing is the capital of "] - The Predict views to navigate to.
      * @param {string} [args.expectedCandidate="China"] - The Predict views to navigate to.
      * @param {string[]} [args.unexpected=[]] - The Predict views to navigate to.
      */
    MontrealTesting: function MontrealTesting (args){
        args = UIAUtilities.defaults(args, {
          testcontext: 'Beijing is the capital of ',
          expectedCandidate: '',
          unexpected: [],
        });

        var languages= ['English']; 
        var types = [''];

        var keyboards= ['en_US@hw=US;sw=QWERTY'];

        // these should all be args
        // var testcontext = 'Beijing is the capital of ';
        // var expectedCandidate= 'China';
        // var unexpects = [];

        //var numIssues = 0;


    /* add keyboards */

    for (var i = 0; i < languages.length; i++) {
         settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
    }

    /* create note */

      args = UIAUtilities.defaults(args, {
        title: ' ',
        body: ' ',
        folder: 'Notes',
        leaveOpenForEditing: true,
      });

      notes.createNote(
        [' ', ' '],
        args
      );  

    /* switch to first keyboard*/ 
    for (var i = 0; i < languages.length; i++) {
         var keyboardID = target.activeApp().getKeyboardID();
         UIALogger.logMessage('keyboardID ' + keyboardID);

          while (keyboards[i] != keyboardID) {
              target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
              keyboardID = target.activeApp().getKeyboardID()
           } //while

         switch (keyboards[i]) {
           
           case 'en_US@hw=US;sw=QWERTY': 
             

                    target.activeApp().typeString(args.testcontext,null,false); 
                    UIATarget.localTarget().delay(2);
                    predictive.comparePredictiveCell(args.expectedCandidate,null,false);
                    //key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
                    //target.activeApp().tap(key);
                    UIATarget.localTarget().delay(2);

          }//switchKeyboard


      }//for
  }, //english typing test
} //iveTypingTest
