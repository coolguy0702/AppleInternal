load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAUtility.js');


UIAUtilities.assert(
    typeof predictive === 'undefined',
    'Keyboard has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.Predictive = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Predictive */
UIStateDescription.Predictive = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/
var PUNCTUATION = ['?','.',',','!'];
var target = UIATarget.localTarget();



/**
 * @namespace {UIAApp} Keyboard
 */
 // LIKELY NOT NEEDED Predictive
//var safari = target.appWithBundleID('com.apple.mobilesafari');

var predictive = target.appWithBundleID('com.apple.mobilenotes');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/*
 */
predictive.predictiveTyping = function predictive() {

}

predictive.predictiveString = function predictiveString(expected){
  	//UIALogger.logMessage('Going to type: ' + expected); 
    var pcellArray = [];
    for ( var i = 1; i<4; i++){
          var pcell = notes.inspect(UIAQuery.query("Typing Predictions").children().atIndex(i))
         if( pcell != null){
             var pcellLabel = pcell.label;
         //var pcell = notes.inspect(UIAQuery.query("Typing Predictions").children().atIndex(i)).label
            if ( typeof pcellLabel != undefined ) {
              UIALogger.logMessage("String  : "+pcellLabel+", length : "+pcellLabel.length);
              pcellArray.push(pcellLabel);
            }
         }
    }//for

    UIALogger.logMessage('Going to type: ' + pcellArray);
    
    //compare eng1[i] with pcell[]
    UIALogger.logMessage('Candidates: ' + pcellArray);

    if(pcellArray.indexOf(expected) != -1){
        target.activeApp().tap(expected);
    } else if ( expected.indexOf(" ") != -1 ) {
        target.activeApp().tap(expected);
        target.activeApp().typeString(" ");
    } else {
        var havePunctuation = false;
        for(var i=0; i<PUNCTUATION.length; i++){
            if(expected.indexOf(PUNCTUATION[i]) != -1){
                havePunctuation = true;
                break;
            }
        }
        //if (havePunctuation) {
        //    target.activeApp().typeString(expected);
        //} else {
        //    throw new Error('No canidate for' + expected + ' available candiates ' + pcellArray);
        //} 
    } 
}

predictive.comparePredictiveCell = function comparePredictiveCell(inputString){

var pcellArray = [];
    for ( var i = 1; i<4; i++){
          var pcell = notes.inspect(UIAQuery.query("Typing Predictions").children().atIndex(i))
         if( pcell != null){
             var pcellLabel = pcell.label;
            if ( typeof pcellLabel != undefined ) {
              UIALogger.logMessage("String  : "+pcellLabel+", length : "+pcellLabel.length);
              pcellArray.push(pcellLabel);
            }
         }
    }//for

    UIALogger.logMessage ("**************Expected is: " + inputString);
    UIALogger.logMessage ("**************index: " + pcellArray.indexOf(inputString));

    if(pcellArray.indexOf(inputString) != -1){
            
            target.activeApp().tap(inputString);

       } else if (inputString.indexOf(" ") != -1 ) {
            target.activeApp().tap(inputString);
            target.activeApp().typeString(" ");
          } else {

           throw new UIAError ("Could not find inputString candidate");
     }

}//comparePredictiveCell

predictive.predictiveArray = function predictiveArray(inputString){

      UIALogger.logMessage('Predictive Typing Test for ' + inputString);

      for(var i=0; i<inputString.length; i++){
      UIALogger.logMessage("word to type '" + inputString[i] + "' " + inputString[i].length);
        
          if( inputString[i].length ==4){
              target.activeApp().typeString(inputString[i].substring(0, 3));

          } else if( inputString[i].length == 1) {
             target.activeApp().typeString(inputString[i][0]);
             target.activeApp().typeString(" ");


          } else if( inputString[i].length == 2) {
              target.activeApp().typeString(inputString[i][0]);

          } else if (inputString[i].length >=5){
              target.activeApp().typeString(inputString[i][0]);
              target.activeApp().typeString(inputString[i][1]);
              target.activeApp().typeString(inputString[i][2]);
              target.activeApp().typeString(inputString[i][3]);

          } else if( inputString[i].length == 3) {
              target.activeApp().typeString(inputString[i][0]);
              target.activeApp().typeString(inputString[i][1]);
          }

          UIATarget.localTarget().delay(1);
          UIALogger.logMessage('Calling Predictive Array function');
          predictive.predictiveString(inputString[i]);

      }//for
}
