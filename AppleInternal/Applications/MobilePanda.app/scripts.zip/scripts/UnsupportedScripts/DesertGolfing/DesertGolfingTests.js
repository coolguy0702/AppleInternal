load('UIATesting.js');
load('DesertGolfing.js');
load('SpringBoard.js');

if (typeof DesertGolfingTest === 'undefined') {
    /**
     * @namespace
     */
     var DesertGolfingTest = {
         /**
          * Test executes a golf swing.
          *
          * @targetApps DesertGolfing
          * @note Default test (no arguments) shoots only between 0° and 90°
          *
          * @param {object} args - Test arguments
          * @param {number} [args.shots=10] - Number of shots to take
          * @param {number} [args.lowAngle=0] - Lowest angle the bot will shoot from
          * @param {number} [args.highAngle=90] - Highest angle the bot will shoot from
          */
          takeShot: function takeShot(args) {
              args = UIAUtilities.defaults(args, {
                  shots: 10,
                  lowAngle: 0,
                  highAngle: 90,
              });

              golf.launch();
              try{
                  // Eventually support angle variance
                  golf.shoot(shots);
              } finally {
                  UIALogger.logMessage(
                      "Do your best, one shot at a time and then move on. Remember that golf is just a game.");
              }
          },

          /**
           * Test goes back and up.
           *
           * @targetApps DesertGolfing
           * @note Default test (no arguments) does something i dunno
           */
           backAndUp: function backAndUp() {
               golf.launch();
               golf.backAndUp();
           }
     }
}
