load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof golf === 'undefined',
    "Desert Golf has already been defined"
);

/**
 * @namespace {UIAApp} golf
 */
var golf = target.appWithBundleID('com.captain-games.desertgolf');

golf.smallBack = function smallBack() {
    golf.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.5}, toOffset:{x:0.51, y:0.49}, duration:2});
}

golf.straightUp = function straightUp() {
    golf.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.5}, toOffset:{x:0.49, y:0.9}, duration:2});
}

golf.randomForward = function randomForward() {
    // Eventually modify the (Math.random()*0.5)+0.5 stuff to
    //  support true degree/radial based constraints
    golf.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.5}, toOffset:{x:Math.random()*0.5, y:(Math.random()*0.5)+0.5}, duration:2});
}

golf.random = function random() {
    golf.drag(UIAQuery.application(), {fromOffset:{x:0.5, y:0.5}, toOffset:{x:Math.random(), y:Math.random()}, duration:2});
}

golf.shoot = function shoot(shots) {
    UIALogger.logMessage("Taking " + shots + " shots");
    for (var i = 0; i < shots; i++) {
        UIALogger.logMessage("Shot #" + i);
        golf.randomForward();
    }
}

golf.backAndUp = function backAndUp() {
    UIALogger.logMessage("Short shot back");
    golf.smallBack();
    target.delay(2);
    UIALogger.logMessage("Big shot up");
    golf.straightUp();
}
