App/Project/Feature: Parsec

Maintainer(s): Azhar Sikander

Maintainer(s) Email: asikander@apple.com

Maintainer(s) Team: Parsec

Maintainer(s) Team Manger: Nicolas Melo

Maintainer(s) Team Manger Email: melo@apple.com

Scripts for Parsec app.


For more information on how to use these scripts. see [Parsec Feedback Tests Help](https://stash.sd.apple.com/projects/DAA/repos/coreautomationextras/browse/Parsec/Events_Suite/Help.md)