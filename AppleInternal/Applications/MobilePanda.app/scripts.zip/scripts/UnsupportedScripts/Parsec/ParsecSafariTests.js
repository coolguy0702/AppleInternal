/**
 * Created by asikander on 4/6/16.
 */
load("SafariTests.js");

/**
 * Search and Interact with Parsec results;
 *
 * @targetApps MobileSafari
 *
 * @param {object} args Test arguments

 * @param {string}          [args.searchString] - The String you want to search for
 * @param {int}     [args.delay] - delay between keystrokes when typing the search string
 * @param {string}     [args.manageAppState] - a comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 * @param {array}           [args.actions] - The list of user interactions you want to perform.
 *                                each action has three attributes name, resultCategory, resultPredicate
 *                               (e.g name = tap, resultCategory = Google Search, resultPredicate = Lahore
 *                               Supported action names = ['tap']
 */

SafariTests.SearchInteractParsecResult = function (args) {
    args = UIAUtilities.defaults(args, {
        searchString: 'Lahore',
        delay: 0.3,
        actions: [],
        manageAppState: '',
    });

    try {
        safari.manageAppState(args.manageAppState)

        safari.getToURLEntryUI();

        safari.parsecSearchInteract(args)

    } catch (e) {
        throw e;
    }

    return UIATestResult.PASS;
}