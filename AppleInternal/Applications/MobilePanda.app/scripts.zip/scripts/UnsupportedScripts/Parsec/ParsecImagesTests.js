/**
 * Created by asikander on 8/27/16.
 */

load("UIATesting.js");
load("ParsecImages.js");

var ParsecImagesTests = {};

/**
 * Search and Interact with Parsec results
 *
 * @targetApps Messages
 *
 * @param {object} args Test arguments

 * @param {string} [args.searchString=''] - The String you want to search for
 * @param {int} [args.delay=0.3] - delay between keystrokes when typing the search string
 * @param {string} [args.manageAppState="quit"] - a comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 * @param {array} [args.actions=[]] - The list of user interactions you want to perform.
 *                                each action has three attributes name, resultCategory, resultPredicate
 *                               (e.g name = tap, resultCategory = Google Search, resultPredicate = Lahore
 *                               Supported action names = ['tap']
 */
ParsecImagesTests.SearchInteractParsecResult = function (args) {
    args = UIAUtilities.defaults(args, {
        searchString: '',
        delay: 0.3,
        actions: [],
        manageAppState: 'quit',
    });

    messages.manageAppState(args.manageAppState);

    messages.parsecSearchInteract(args);
}