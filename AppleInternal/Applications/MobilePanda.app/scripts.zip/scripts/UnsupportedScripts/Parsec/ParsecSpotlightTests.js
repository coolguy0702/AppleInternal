/**
 * Created by asikander on 7/28/16.
 */
load("UIATesting.js");
load('SpringBoard.js');

var ParsecSpotlightTests = {};

/**
 * Search and Interact with Parsec results
 *
 * @targetApps springboard
 *
 * @param {object} args Test arguments

 * @param {string} [args.searchString="Starbucks"] - The String you want to search for
 * @param {int} [args.delay=0.3] - delay between keystrokes when typing the search string
 * @param {string} [args.manageAppState='quit'] - a comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 * @param {array} [args.actions=[]] - The list of user interactions you want to perform.
 *  (see [UIAApp.parsecSearchInteract]{@link UIAApp#parsecSearchInteract} for more details on available actions)
 *
 * @param {boolean}  [args.dismissSplashScreen=true] - flag to indicate whether or not dismiss Spotlight First Time Experience (FTE) splash
 * @param {boolean}  [options.requiresEnterKey=true] - Spotlight requires enter to continue search with typed text.
 *                                                     set to false if want to manually trigger the search via Search btn, of suggestion
 */
ParsecSpotlightTests.SearchInteractParsecResult = function (args) {
    args = UIAUtilities.defaults(args, {
        searchString: 'Starbucks',
        delay: 0.3,
        actions: [],
        manageAppState: 'quit',
        dismissSplashScreen: true,
        requiresEnterKey: true,

    });

    springboard.manageAppState(args.manageAppState);

    springboard.parsecSearchInteract(args);
}