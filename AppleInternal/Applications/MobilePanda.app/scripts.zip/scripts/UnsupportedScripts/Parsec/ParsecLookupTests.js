/**
 * Created by asikander on 7/28/16.
 */
load('UIATesting.js');
load('ParsecLookup.js');

var ParsecLookupTests = {};

/**
 * Search and Interact with Parsec results
 *
 * @targetApps Notes
 *
 * @param {object} args Test arguments

 * @param {string} [args.searchString='Starbucks'] - The String you want to search for
 * @param {int} [args.delay=0.3] - delay between keystrokes when typing the search string
 * @param {string} [args.manageAppState='quit'] - a comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 * @param {boolean}  [args.disableWelcomeScreen=false] - flag to disable welcome screen using defaults write
 * @param {array} [args.actions=[]] - The list of user interactions you want to perform.
 *                                each action has three attributes name, resultCategory, resultPredicate
 *                               (e.g name = tap, resultCategory = Google Search, resultPredicate = Lahore
 *                               Supported action names = ['tap']
 * @param {boolean}  [args.deleteNoteAfterTest=false] - flag to delete note after the test
 */
ParsecLookupTests.SearchInteractParsecResult = function (args) {
    args = UIAUtilities.defaults(args, {
        searchString: 'Starbucks',
        delay: 0.3,
        actions: [],
        manageAppState: 'quit',
        disableWelcomeScreen: false,
        deleteNoteAfterTest: false
    });

    notes.manageAppState(args.manageAppState);

    var totalNotesBeforeTest = null;
    try {
        totalNotesBeforeTest = notes.getFolderNoteCount();
    } catch (e) {
        UIALogger.logWarning('Unable to capture current notes count.');
    }

    notes.parsecSearchInteract(args);

    if (args.deleteNoteAfterTest) {
        // Post test step.. To avoid cluttering iCloud Notes account
        try {
            var totalNotesAfterTest = notes.getFolderNoteCount();
            if (totalNotesBeforeTest != null && totalNotesAfterTest > totalNotesBeforeTest) {
                UIALogger.logMessage('Deleting the new note just created...');
                notes.deleteNotes();
            }
        } catch(e) {
            UIALogger.logWarning('Unable to delete the note at the end of test');
        }
    }
}