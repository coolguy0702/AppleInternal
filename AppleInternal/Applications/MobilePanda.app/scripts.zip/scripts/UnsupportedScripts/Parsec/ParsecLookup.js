/**
 * Created by asikander on 8/4/16.
 */
load("Notes.js");

/**
 * Perform Lookup on text in a note
 *
 * @targetApps Notes
 *
 * @param {string} [searchString="Starbucks"] - The String you want to Lookup
 * @param {Object} [options] - other options
 * @param {boolean}  [options.disableWelcomeScreen=false] - flag to disable welcome screen using defaults write (Note: Lookup/LookupHints Only)
 */
notes.parsecLookup = function parsecLookup(searchString, options) {

    options = UIAUtilities.defaults(options, {
        disableWelcomeScreen: false
    });

    // uses flag disableWelcomeScreen to determine whether to disable it or not.
    disableLookupWelcomeScreen(options);

    this.createNote([searchString]);
    this.getToTopNoteInFolder();
    this.ccpActions(['Look Up']);

    // We will have intro screen that one sees the first time after an erase install.  If so, we need to press "continue"
    var continueButton = UIAQuery.buttons("Continue").isVisible();
    var welcomeMessageText = UIAQuery.withPredicate("value contains 'Look Up now shows suggestions from'").isVisible();

    if (!options.disableWelcomeScreen && this.waitUntilPresent(welcomeMessageText.orElse(continueButton), 10)) {
        this.tap(continueButton);
    }

    //Wait a bit for results to load
    var isSearchResultAppeared = this.waitUntilPresent(UIAQuery.Notes.LOOKUP_RESULTS_VIEW, 20);
    var errorMsg = 'Lookup results not shown.';
    UIAUtilities.assertEqual(isSearchResultAppeared, true, errorMsg, {identifier: errorMsg});
}