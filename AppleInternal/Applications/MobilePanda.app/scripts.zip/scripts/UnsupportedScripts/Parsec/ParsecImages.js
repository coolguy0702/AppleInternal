/**
 * Created by asikander on 8/27/16.
 */
load("UIAApp+Parsec.js");
load("Messages.js");

UIAQuery.Messages.HASHTAGIMAGES = {
    /** Find Images and Videos Button in #images app */
    FIND_IMAGES_BUTTON: UIAQuery.buttons('Find images'),

    /** Clear text button in search field in #images app */
    CLEAR_TEXT_BUTTON: UIAQuery.buttons('Clear text'),

    /** search field in #images app */
    SEARCH_FIELD: UIAQuery.searchBars('Find images'),

    /** Cancel button in #images app */
    CANCEL_BUTTON: UIAQuery.buttons('Cancel'),

    /** #images app main view */
    STS_MAIN_VIEW: UIAQuery.query('STSRootView').andThen('STSPickerView'),

    /** #images app search view */
    STS_SEARCH_VIEW: UIAQuery.query('STSRootView').andThen('STSSearchBrowserRootView'),

    /** #images app search results view */
    STS_SEARCH_RESULTS_VIEW: UIAQuery.query('STSRootView').andThen('STSSearchBrowserRootView').andThen('STSPickerView'),

    /** #images fulll screen view*/
    STS_EXPANDED_VIEW: UIAQuery.query('CKPresentationControllerWindow').andThen('UINavigationTransitionView').andThen('STSRootView').andThen('STSPickerView'),
}

/**
 *  Launch a #images app in Messages
 *
 * @targetApps Messages
 *
 * @param {string} [searchString=''] - text to search for images
 *
 * @param {object} options Test arguments
 *
 * @param {string} [options.appName='#images'] - app name to launch
 *
 * @param {string} [options.textToFindMessage=''] - text to find and open an existing message
 *
 * @param {array} [options.recipients=['MY_PHONE_NUMBER']] - New Message Only; an array of recipients or account IDs to send the message to <br>
 *                Default: MY_PHONE_NUMBER; phone number of the device if exists
 *
 **/
messages.launchParsecImages = function launchParsecImages(searchString, options) {
    options = UIAUtilities.defaults(options, {
        appName: '#images',
        textToFindMessage: '',
        recipients: ['MY_PHONE_NUMBER'],
    });

    UIALogger.logMessage('Attemping to launch Message app %0'.format(options.appName))
    this.launchAppStoreApp(options);

    if (searchString) {
        this.searchImages(searchString);
    }
}

/**
 *  Search images in #images app in Messages
 *
 * @targetApps Messages
 *
 * @param {string} [searchString] - text to search for
 *
 * @Note assumes that app is already launched
 **/
messages.searchImages = function searchImages(searchString) {
    if (!searchString) {
        throw new UIAError('Please provide a search String');
    }

    UIALogger.logMessage('Tapping button [Find Images]');
    this.tap(UIAQuery.Messages.HASHTAGIMAGES.FIND_IMAGES_BUTTON.isVisible());

    UIALogger.logMessage('Waiting for #Images search view to appear');
    if (!this.waitUntilPresent(UIAQuery.Messages.HASHTAGIMAGES.STS_SEARCH_VIEW)) {
        throw new UIAError('#Images search view did not appear');
    }

    UIALogger.logMessage('Searching for text %0'.format(searchString));
    this.enterText(UIAQuery.Messages.HASHTAGIMAGES.SEARCH_FIELD.isVisible(), searchString);
}