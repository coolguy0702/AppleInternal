/**
 * Created by asikander on 8/23/16.
 */
load("UIAApp+Parsec.js");

/**
 * determines query for user action based on the currentUserAction. internally calls target app specific function
 *
 * @param {object} [currentUserAction={}] - The user action for which you want to determine a query</br>
 *                each action has following attributes: name, resultCategory, resultPredicate, resultIndex, textUIAQuery, waitSecs, headerButton
 *                For more info see [Parsec Feedback Test help]{@link https://stash.sd.apple.com/projects/DAA/repos/coreautomationextras/browse/Parsec/Events_Suite/Help.md}
 * @param {object} [targetApp=null] - The target app;
 *
 * @param {object} [widget=''] - Whether target is a widget. added for widgets in todays view;
 *
 * @note it uses app specific [UIAApp.determineSearchResultQuery]{@link UIAApp#determineSearchResultQuery} if need query for a parsec search result in the target app.
 */
var determineTargetQuery = function(currentUserAction, targetApp, widget) {
    if (!currentUserAction) {
        currentUserAction = {};
    }

    if (!targetApp) {
        targetApp = null;
    }

    if (!widget) {
        widget = '';
    }

    if (currentUserAction.query) {
        var query = UIAQuery.query(currentUserAction.query);
        return query;
    }

    if (currentUserAction.predicate) {
        var query = UIAQuery.withPredicate(currentUserAction.predicate);
        return query;
    }

    if (currentUserAction.textUIAQuery) {
        // eval input UIAQuery string to a UIAQuery object
        var query = eval(currentUserAction.textUIAQuery);
        return query;
    }

    // get a header button by any identifier and category
    if (currentUserAction.resultCategory && currentUserAction.headerButton) {
        UIALogger.logMessage(
            'Getting cateogory [%0] header button [%1]: %1'
            .format(currentUserAction.resultCategory, currentUserAction.headerButton)
        );

        var headerRow = UIAQuery.Parsec.SEARCH_RESULTS_SECTION;
        var headerItems = UIAQuery.query('%0'.format(currentUserAction.resultCategory)).siblings();
        var headerButton = UIAQuery.withPredicate("any identifiers contains '%0'".format(currentUserAction.headerButton));

        return headerRow.andThen(headerItems.andThen(headerButton));
    }

    var args = [];

    if (currentUserAction.resultPredicate) {
        args['searchPredicate'] = currentUserAction.resultPredicate;
    }

    if (currentUserAction.resultIndex) {
        args['resultIndex'] = currentUserAction.resultIndex;
    }

    if (widget) {
        args['widget'] = widget;
    }

    var searchQuery = '';
    if (currentUserAction.resultCategory) {
        if (typeof(currentUserAction.resultCategory) === "string") {
            args['searchCategory'] = currentUserAction.resultCategory;
            // determine UIASearchQuery for the target result.  Note: Each Client should have this func implemented
            searchQuery = targetApp.determineSearchResultQuery(args);
        } else {
            args['searchCategory'] = currentUserAction.resultCategory[0];
            searchQuery = targetApp.determineSearchResultQuery(args);
            for (var i=1; i < currentUserAction.resultCategory.length; i++) {
                args['searchCategory'] = currentUserAction.resultCategory[i];
                searchQuery = searchQuery.orElse(targetApp.determineSearchResultQuery(args));
            }
        }

    } else {
        searchQuery = targetApp.determineSearchResultQuery(args);
    }

    // If action button, update the query
    if (currentUserAction.actionButton) {
        var btn = UIAQuery.buttons().contains(currentUserAction.actionButton);
        searchQuery = searchQuery.parent().andThen(btn).orElse(searchQuery.andThen(btn));
    }

    return searchQuery;
}

/**
 * Find a result and interact with it. Note: each client should have func determineSearchResultQuery
 *
 * @param {string} [options.searchString="Apple"] - The String you want to search for
 * @param {int} [options.delay=0.3] - delay between keystrokes when typing the search string
 * @param {boolean} [options.dismissSplashScreen=true] - flag to indicate whether or not dismiss Spotlight First Time Experience (FTE) splash
 * @param {boolean}  [options.disableWelcomeScreen=false] - flag to disable welcome screen using defaults write (Note: Lookup/LookupHints Only)
 * @param {string} [options.widget=""] - Widget name if targetting a widget on today's view
 * @param {Object[]} [options.actions=[]] - The list of user interactions you want to perform.</br>
 *                e.g {name: "tap", resultCategory: "Google Search", resultPredicate: "name == 'Lahore'"}</br>
 *                For more info see [Parsec Feedback Test help]{@link https://stash.sd.apple.com/projects/DAA/repos/coreautomationextras/browse/Parsec/Events_Suite/Help.md}
 * @param {null|string} options.actions[].name - action name. See supported actions in the link above
 * @param {null|string} options.actions[].waitSecs - No. of secs to wait for an item by the specified criteria
 * @param {null|string} options.actions[].predicate - any NSPredicate to find an item
 * @param {null|string} options.actions[].textUIAQuery - any valid UIAQuery that will be evaluated on the fly
 * @param {null|string} options.actions[].resultCategory - result/header button category name
 * @param {null|string} options.actions[].headerButton - any button identifier to find a button in result/widget header e-g Show More, Show Less etc
 * @param {null|string} options.actions[].resultIndex - result index w/ specially keys 'first' and 'last'
 * @param {null|string} options.actions[].resultPredicate - any NSPredicate to find A search result
 * @param {null|string} options.actions[].actionButton - Name of the action button on the search result e-g Directions
 * @param {null|string} options.actions[].alertTitle - alert name to handle manually
 * @param {null|string} options.actions[].alertButton - alert button to engage the alert specified by alertTitle
 * @param {null|string} options.actions[].alertInput - input text to type in first textfield in the alert
 * @param {null|string} options.actions[].searchText - perform parsec search
 * @param {null|string} options.actions[].textUserAction - user action to perform but will be eval'ed
 * @param {null|string} options.actions[].ScrollToVisible - scroll to visible element specified by query
 * @param {null|string} options.actions[].query - use the text as is as UIAQuery. puts in UIAQuery.query()
 * @param {boolean}  [options.requiresEnterKey=true] - Spotlight requires enter to continue search with typed text.
 *                                                     set to false if want to manually trigger the search via Search btn, of suggestion
 *
 */
UIAApp.prototype.parsecSearchInteract = function(options) {
    var options = UIAUtilities.defaults(options, {
        searchString: 'Apple',
        delay: 0.3,
        actions: [],
        dismissSplashScreen: true,
        widget: '',
        disableWelcomeScreen: false,
        requiresEnterKey: true,

    });

    // perform parsec search on the client
    this.parsecSearch(options.searchString, options);

    // perfrom user interactions on based on the actions specified in test.
    // action keys: name, [, predicate, (resultCategory, resultPredicate [,actionButton])]
    var defaultWaitSecs = 10;

    var noQueryActions= [Parsec.USERACTION.Delay, Parsec.USERACTION.KeyboardGo, Parsec.USERACTION.HomeButton];

    for (var i=0; i < options.actions.length; i++) {
        UIALogger.logDebug("Action to perform: %0".format(options.actions[i].name));

        var currentUserAction = options.actions[i];
        var userActionName = currentUserAction.name.toLowerCase();

        if (!currentUserAction.waitSecs) {
            currentUserAction.waitSecs = defaultWaitSecs;
        }

        var userQuery = '';
        // dont determine query for non query based actions
        if (!noQueryActions.includes(userActionName)) {
            userQuery = determineTargetQuery(currentUserAction, this, options.widget);
            this.waitUntilPresent(userQuery, currentUserAction.waitSecs);
        }

        if (userActionName === Parsec.USERACTION.Tap) {
            if (currentUserAction.alertTitle) {
                this.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.contains(currentUserAction.alertTitle)), function(){
                    this.tap(userQuery);
                    if (currentUserAction.alertInput) {
                        this.waitUntilPresent(UIAQuery.PROMPT_CONTAINER.andThen(UIAQuery.textFields()));
                        this.tap(UIAQuery.PROMPT_CONTAINER.andThen(UIAQuery.textFields()));
                        this.typeString(currentUserAction.alertInput);
                    }
                    this.tap(UIAQuery.PROMPT_CONTAINER.andThen(UIAQuery.buttons().contains(currentUserAction.alertButton)));
                });
            } else {
                this.tap(userQuery);
            }

        } else if (userActionName === Parsec.USERACTION.KeyboardGo) {
            var queryButtonGo = UIAQuery.keyboard().andThen(UIAQuery.buttons('Go'));
            this.tap(queryButtonGo);

        } else if (userActionName === Parsec.USERACTION.HomeButton) {
            target.clickMenu();

        } else if (userActionName === Parsec.USERACTION.Peek) {
            try {
                this.touchDownForPeekGesture(userQuery);
                this.waitUntilPresent(UIAQuery.ORB_PEEK_VIEW.isVisible(), currentUserAction.waitSecs);
                this.releaseTouches();
            } catch (err) {
                this.releaseTouches();
                UIALogger.logError('Failed to perform peek action.');
                throw err;
            }
        } else if (userActionName === Parsec.USERACTION.Pop) {
            this.touchForPopGesture(userQuery);

        } else if (userActionName === Parsec.USERACTION.Wait) {
            this.waitUntilPresent(userQuery, currentUserAction.waitSecs);

        } else if (userActionName === Parsec.USERACTION.Delay) {
            target.delay(currentUserAction.waitSecs);

        } else if (userActionName === Parsec.USERACTION.ScrollUp) {
            var j = 0;
            while (!this.exists(userQuery.isVisible()) && j< 3) {
                this.dragDownInside(UIAQuery.application());
                j += 1;
            }
        } else if (userActionName === Parsec.USERACTION.ScrollDown) {
            var k = 0;
            while (!this.exists(userQuery.isVisible()) && k < 3) {
                this.dragUpInside(UIAQuery.application());
                k += 1;
            }
        } else if (userActionName === Parsec.USERACTION.SwipeLeft) {
            this.swipeLeft(userQuery);
        } else if (userActionName === Parsec.USERACTION.Search) {
            this.parsecSearch(currentUserAction.searchText, options);
        } else if (userActionName === Parsec.USERACTION.ScrollToVisible) {
            this.scrollToVisible(userQuery);
        } else if (userActionName === Parsec.USERACTION.EvalAction) {
            eval(currentUserAction.textUserAction);
        } else if (userActionName === Parsec.USERACTION.PerformTask) {
            var task_args = currentUserAction.textUserAction.split(' ');
            // first element is command so pop that from args
            var cmd = task_args.shift();
            var taskOut = target.performTask(cmd, task_args, currentUserAction.waitSecs);
            target.delay(currentUserAction.waitSecs);
            UIALogger.logDebug(taskOut.exitCode);
            UIALogger.logDebug(taskOut.stdout);
            UIALogger.logDebug(taskOut.stderr);
        }

    }
}

/**
 * Manage applicate state by running any combination of deactivate, reactivate, quit
 *
 * @param {string}     appStatesToSim - an ordered (L to R) comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 */
UIAApp.prototype.manageAppState = function(appStatesToSim) {
    UIALogger.logMessage("ManageAppState.........");

    if (!appStatesToSim) {
        appStatesToSim = '';
    }

    var listAppStatesToSim = appStatesToSim.toLowerCase().split(',');

    for (var i = 0; i < listAppStatesToSim.length; i++) {

        var requestedAction = listAppStatesToSim[i].trim();
        UIALogger.logMessage("%0 app %1".format(Parsec.APPSATE.Reactivate.toUpperCase(), this.name().toUpperCase()));

        if (requestedAction === Parsec.APPSATE.Deactivate) {
            if (this.name() === 'SpringBoard') {
                target.clickMenu();
            } else {
                this.deactivate();
            }

        } else if (requestedAction === Parsec.APPSATE.Reactivate) {
            this.reactivate();

        } else if (requestedAction === Parsec.APPSATE.Quit && this.state() > UIAAppState.TERMINATED) {
            try{
                if (this.name() === 'SpringBoard') {
                    target.clickMenu();
                    target.delay(2);
                } else {
                    this.quit();
                }
            } catch(e) {
                UIALogger.logDebug("Error quitting app: "+ e.message);
                UIALogger.logDebug("Using CLI to kill the app: "+ this.name());
                var result = target.performTask('/bin/kill', ['-9', this.pid()])
                UIALogger.logDebug(JSON.stringify(result))
                target.delay(0.5);
            }
        }
    }
}

/**
 * Uses defaults write to disable the Lookup's welcome screen...
 *
 * @param {object} [options] - arguments
 * @param {object} [options.disableWelcomeScreen] - flag whether to disable the screen using defaults write
 *
 */
var disableLookupWelcomeScreen = function(options){
    options = UIAUtilities.defaults(options, {
        disableWelcomeScreen: false,
    });

    if (options.disableWelcomeScreen) {

        UIALogger.logWarning("Disabling welcome screen using defaults write....");

        var cmd_path = "mobile_install lookup com.apple.datadetectors.DDActionsService | grep \"HOME =*\" | tr -d '=\";' | tr -s ' '| cut -f3 -d' '";
        var result = target.performTask('/bin/sh', ['-c', "%0".format(cmd_path)]);
        UIALogger.logDebug(JSON.stringify(result));

        var cmd_write= "/usr/bin/defaults write %0/Library/Preferences/com.apple.datadetectors.DDActionsService.plist LookUpShowFirstTime.acknowledged -bool true".format(result.stdout.trim());
        result = target.performTask('/bin/sh', ['-c', "%0".format(cmd_write)]);
        UIALogger.logDebug(JSON.stringify(result));

        result = target.performTask('/usr/bin/killall', ['cfprefsd']);
        UIALogger.logDebug(JSON.stringify(result));

        result = target.performTask('/usr/bin/killall', ['DDActionsService']);
        UIALogger.logDebug(JSON.stringify(result));
    }
}