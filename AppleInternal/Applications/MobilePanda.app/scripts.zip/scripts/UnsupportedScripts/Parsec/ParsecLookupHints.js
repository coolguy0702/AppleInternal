/**
 * Created by asikander on 8/24/16.
 */
load("UIAApp+Parsec.js");
load("Mail.js");


 /**
 * Open specified email in Mail, and perform engage lookup hints (the underlined text such as an artist name, movie or maps)
 *
 * @targetApps MobileMail
 *
 * @param {string} [searchString=""] - The String you want to Lookup
 * @param {object} args - arguments for mail app
 * @param {string} [args.search=null] - String to search for e-g Parsec Lookup Hints Tests
 * @param {string} [args.account=null] - Address or account description
 * @param {string} [args.folder="Inbox"] - Folder in which to search
 * @param {bool}   [args.shouldOpenEmail=true] - Whether email should be opened
 * @param {bool}   [args.emailIndex=0] - the index of the email to be selected if no search criteria are specified.
 * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
 * @param {boolean}  [args.disableWelcomeScreen=false] - flag to disable welcome screen using defaults write (Note: Lookup/LookupHints Only)
 */
mail.parsecLookupHint = function parsecLookupHint(searchString, args) {

    args = UIAUtilities.defaults(args, {
        search: null,
        account: null,
        folder: 'Inbox',
        shouldOpenEmail: true,
        timeout: 60,
        disableWelcomeScreen: false,
        emailIndex : 0
    });

    // uses flag disableWelcomeScreen to determine whether to disable it or not.
    disableLookupWelcomeScreen(args);

    UIALogger.logMessage('Attempting to open email ... ');
    mail.openAnEmail(args);

    var lookupHintQuery = UIAQuery.links(searchString).isVisible();

    // this is required to perform actions such as peek / pop
    if (!searchString) {
        return;
    }

    UIALogger.logMessage('Checking lookup hint [%0] exists and visible.'.format(searchString));
    //workaround for <rdar://problem/28001286> fail to scroll in Mail
    for (var i = 1; i < 4; ++i) {
        if (this.waitUntilPresent(lookupHintQuery)) {
            break;
        }
        this.dragUpInside(UIAQuery.application());
    }

    if (!this.exists(lookupHintQuery)) {
        throw new UIAError('Could not find lookup hint with text "%0"'.format(searchString), {identifier:'Could not find visible lookup hint'});
    }

    UIALogger.logMessage('Attempting to tap lookup hint %0'.format(searchString));
    this.tap(lookupHintQuery);

    //a card or result sheet view
    var searchResultsViewQuery = UIAQuery.query('UITransitionView').andThen(UIAQuery.query('AXRemoteElement').andThen(UIAQuery.query('UITableView').orElse('SearchUITableView')));
    searchResultsViewQuery = UIAQuery.navigationBars(searchString).orElse(searchResultsViewQuery);

    if (!this.waitUntilPresent(searchResultsViewQuery, 10)) {
        UIALogger.logMessage('We might have intro screen that one sees the first time after an erase install.  If so, we need to press [continue]');
        var continueButton = UIAQuery.buttons('Continue').isVisible();
        var welcomeMessageText = UIAQuery.withPredicate("value contains 'Look Up now shows suggestions from'").isVisible();

        if (!args.disableWelcomeScreen && this.waitUntilPresent(welcomeMessageText.orElse(continueButton), 5)) {
            this.tap(continueButton);
        }

        if (!this.waitUntilPresent(searchResultsViewQuery, 10)) {
            throw new UIAError('Search result not loaded for query %0.'.format(searchString), {identifier:'Search result not shown'});
        }
    }
}