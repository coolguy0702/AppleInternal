/**
 * Created by asikander on 8/29/16.
 */
load("UIATesting.js");
load('SpringBoard.js');

var ParsecNewsTests = {};

/**
 * Search and Interact with Parsec results
 *
 * @targetApps springboard
 *
 * @param {object} args Test arguments

 * @param {string} [args.searchString=""] - The String you want to search for
 * @param {int} [args.delay=0.3] - delay between keystrokes when typing the search string
 * @param {string} [args.manageAppState='quit'] - a comma saparated list of actions to update app state.
 *                              (e.g 'deactivate', 'deactivate quit')
 * @param {array} [args.actions=[]] - The list of user interactions you want to perform.
 *  (see [UIAApp.parsecSearchInteract]{@link UIAApp#parsecSearchInteract} for more details on available actions)
 *
 * @param {boolean}  [args.dismissSplashScreen=true] - flag to indicate whether or not dismiss Spotlight First Time Experience (FTE) splash
 *
 * @param {string}  [args.deviceRegion="Canada"] - desired Device region. Default to Canada as we provide news for Canada.
 * @param {string}  [args.widget="NEWS"] - Widget you want to test.
 *
 */
ParsecNewsTests.SearchInteractParsecResult = function (args) {
    args = UIAUtilities.defaults(args, {
        searchString: '',
        delay: 0.3,
        actions: [],
        manageAppState: 'quit',
        dismissSplashScreen: true,
        deviceRegion: 'Canada',
        widget: 'NEWS',
    });

    springboard.manageAppState(args.manageAppState);

    springboard.parsecSearchInteract(args);
}