load('Phone.js');

/**
 *  Verifies if the given recent call is present in the Recents Tab of Phone App
 *  @param {object} options
 *  @param {string} options.recentCall - Name of the person or number to call
 **/
phone.verifyCallInRecents = function verifyCallInRecents(options) {
    phone.getToRecentsView();

    // If recentCall is not present, throw an error
    if (!options.recentCall) {
        throw new UIAError("Recent call is not mentioned for verification");
    }

    var app = target.activeApp();
    var recentCallCount = phone.count(UIAQuery.query('UITableViewCellAccessibilityElement'));
    if (recentCallCount < 1 && !(app.inspect(UIAQuery.tableCells().beginsWith(options.recentCall)).name.contains(options.recentCall))) {
        throw new UIAError("The Recents tab does not have the number " + options.recentCall + " called")
    }

    target.delay(3);
}