load('UIATesting.js');
load('iCloudPhone.js');
load('Settings.js');

if (typeof iCloudPhoneTests === 'undefined') {
    /**
     * @namespace
     */
    var iCloudPhoneTests = {
        /**
         *  Verifies if the given recent call is present in the Recents Tab of Phone App
         *
         * @eligibleResource deviceClass == 'iPhone'
         * @targetApps MobilePhone
         *
         * @param {object} args - Test arguments
         * @param {string} [args.phoneNumber] - Phone Number to verify in Recents Tab
         **/
        verifyCallInRecents: function verifyCallInRecents(args) {
            args = UIAUtilities.defaults(args, {
                recentCall: '4089619343',
            });
            phone.verifyCallInRecents(args);
        },
    }
}