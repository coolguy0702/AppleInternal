App/Project/Feature: PhoneClearRecentTab
Maintainer(s): Reema Israni
Maintainer(s) Email: risrani@apple.com
Maintainer(s) Team: iCloud Performance team
Maintainer(s) Team Manger: Sagar Khanvilkar
Maintainer(s) Team Manger Email: khanvilkar@apple.com
Script to verify if a phone number / contact name is present in the Phone App's Recent Call History