load('UIATesting.js');
load('KingsRoad.js');
load('SpringBoard.js');

if (typeof KingsRoadTests === 'undefined') {
    /**
     * @namespace
     */
    var KingsRoadTests = {
        /**
         * Test runs a Story Mode level repeatedly to achieve mastery
         *
         * @targetApps KingsRoad
         *
         * @param {object} args Test arguments
         * @param {string} [args.mode="Story Mode"] - The mode to use in the village
         * @param {number} [args.level=1] - The level number we should run
         * @param {string} [args.difficulty="Normal"] - The difficulty we'll use
         * @param {number} [args.repetitions=10] - How many times to run the level
         */
        masterStoryLevel: function masterStoryLevel(args) {
            var args = UIAUtilities.defaults(args, {
                mode: 'Story Mode',
                level: 1,
                difficulty: 'Normal',
                repetitions: 10,
            });

            kingsroad.launch();

            // Get past B.S. starting menu and popups

            UIALogger.logMessage("Starting %0 repetitions of '%1' level %2".format(args.repetitions, args.mode, args.level));

            for (var i = 1; i <= args.repetitions; i++) {
                UIALogger.logMessage("Run %0/%1 for '%2' level %3".format(i, args.repetitions, args.mode, args.level));
                kingsroad.navigateVillage(args);
                kingsroad.playStoryLevel(args);
            }
        },
    }
}
