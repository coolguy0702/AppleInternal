load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof kingsroad === 'undefined',
    "KingsRoad has already been defined"
);

/**
 * @namespace {UIAApp} kingsroad
 */
var kingsroad = target.appWithBundleID("com.rumbleentertainment.kingsroad");

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.KingsRoad = {
    /**
     * Village item locations
     */
    IN_VILLAGE: {
        STORY_MODE: {x:0.95, y:0.24},
    },

    /**
     * Story Mode item locations
     */
    IN_STORY: {
        PLAY_MAP: {x:0.35, y:0.55},
    },

    /**
     * In Level item locations
     */
    IN_LEVEL: {
        AUTO: {x:0.95, y:0.7},
        END_LEVEL: {x:0.5, y:0.75},
        RECEIVE_GEMS: {x:0.5, y:0.5},
        RETURN_TO_TOWN: {x:0.5, y:0.9},
    },
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to KingsRoad */
UIStateDescription.KingsRoad = {
    /** Main menu */
    MAIN_MENU:              'Main Menu',

    /** Play menu */
    PLAY_MENU:              'Play',

    /** Practice menu */
    PRACTICE_MENU:          'Practice',

    /** Party menu */
    PARTY_MENU:             'Party',

    /** Choosing a hero menu */
    CHOOSE_HERO:            'Choose',

    /** In-game screen */
    IN_GAME:                'N/A',

    /** Shopping screen */
    IN_SHOP:                'Shop',

    /** Post-game screen */
    POST_GAME:              'VICTORY' || 'DEFEAT',
};

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tap-Wrapper                                                             */
/*                                                                                 */
/*      A wrapper for tap, since we can't just pass in an offset dict without      */
/*      also passing in a UIAQuery, but it will never change...                    */
/*                                                                                 */
/***********************************************************************************/
kingsroad._tap = function(offset) {
    kingsroad.tap(UIAQuery.application(), {offset});
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

// GAME BEHAVIORS

/**
 * In game behavior: Select level from Story Mode map
 *
 * Expected starting states: IN_VILLAGE
 *
 * @param {object} options - Options dictionary
 * @param {boolean} options.leftTeam - Determines our orientation
 *                      (true means we face right, false means face left)
 */
kingsroad.inStoryMode_selectLevel = function(options) {

    kingsroad.drag(UIAQuery.application(), {fromOffset:{x:0.1, y:0.9}, toOffset:{x:0.9, y:0.1}, duration:0.5});

    this.delay(2);

    x_offset = 0.1;
    y_offset = 0.5;

    /**
    ** This is special, since the Story Mode map has the levels randomly higher
    **   or lower in random intervals like so:
    **
    **       L1      L3  L4      L6   ...
    **           L2          L5
    **
    **/
    switch (options.level) {
        case 2:
            y_offset = 0.6;
            break;
        case 5:
            y_offset = 0.6;
            break;
        case 7:
            y_offset = 0.6;
            break;
        case 8:
            y_offset = 0.6;
            break;
        default:
            break;
    }

    x_offset += (options.level - 1) * 0.08

    kingsroad._tap({x:x_offset, y:y_offset});

    this.delay(2);

    y_offset = 0.5;

    switch (options.difficulty) {
        case 'Normal':
            x_offset = 0.25;
            break;
        case 'Heroic':
            x_offset = 0.5;
            break;
        case 'Champion':
            x_offset = 0.75;
            break;
        default:
            x_offset = 0.25;
            break;
    }

    kingsroad._tap({x:x_offset, y:y_offset});

    this.delay(1);

    kingsroad._tap(UIAQuery.KingsRoad.IN_STORY.PLAY_MAP);

    this.delay(8);
}

/**
 * In game behavior: Activate Auto mode in a level
 *
 * Expected starting states: In Level
 *
 */
kingsroad.inLevel_enableAutoMode = function() {
    kingsroad._tap(UIAQuery.KingsRoad.IN_LEVEL.AUTO);
}

/**
 * In game behavior: Exit a level after completion
 *
 * Expected starting states: In Level
 *
 */
kingsroad.inLevel_endLevelInstance = function() {
    kingsroad._tap(UIAQuery.KingsRoad.IN_LEVEL.END_LEVEL);
    this.delay(4);
    kingsroad._tap(UIAQuery.KingsRoad.IN_LEVEL.RECEIVE_GEMS);
    this.delay(3);
    kingsroad._tap(UIAQuery.KingsRoad.IN_LEVEL.RETURN_TO_TOWN);
    this.delay(8);

}

/**
 * In game behavior: Navigate the village
 *
 * Expected starting states: In village
 *
 * @param {object} args - Argument dictionary
 */
kingsroad.navigateVillage = function(args) {
    args = UIAUtilities.defaults(args, {
        mode: "Story Mode",
        level: 1,
    });

    UIALogger.logMessage("Selecting villager that corresponds to mode: %0!".format(args.mode));

    switch (args.mode) {
        case "Story Mode":
            kingsroad._tap(UIAQuery.KingsRoad.IN_VILLAGE.STORY_MODE);
            break;
    }

    this.delay(4);
}

/**
 * In game behavior: Play the game!
 *
 * Expected starting states: In Game
 *
 * @param {object} args - Argument dictionary
 */
kingsroad.playStoryLevel = function(args) {
    args = UIAUtilities.defaults(args, {
        level: 1,
        timeout: 70,
    });

    UIALogger.logMessage("Selecting story level %0!".format(args.level));

    kingsroad.inStoryMode_selectLevel(args);

    UIALogger.logMessage("Starting level %0!".format(args.level));

    kingsroad.inLevel_enableAutoMode();

    // Wait to complete the level (will take longer the higher we go)
    timeout = args.timeout + args.level * 25
    if (args.level == 4) {
        timeout += 30
    }
    this.delay(timeout);

    kingsroad.inLevel_endLevelInstance();
}
