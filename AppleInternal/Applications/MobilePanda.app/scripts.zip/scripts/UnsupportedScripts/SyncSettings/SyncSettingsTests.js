load('UIATesting.js');
load('Settings.js');
load('Settings+FaceTime.js');
load('Settings+Keychain.js');
load('Settings+Accounts.js');
load('SyncSettings+Accounts.js');
load('SpringBoard.js');

if (typeof SyncSettingsTests === 'undefined') {
    /**
     * @namespace
     */
    var SyncSettingsTests = {
        /**
         * Creates new iCloud account.
         *
         * @overrideID Create New iCloud Account
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleID="PERSISTEDAPPLEID"] - Apple ID.  Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         * @param {string}      [args.accountOptions.birthday="April/1/1984"] - Birthday for age verification.
         * @param {string}      [args.accountOptions.firstName="John"] - First name.
         * @param {string}      [args.accountOptions.lastName="Galt"] - Last name.
         * @param {array}       [args.accountOptions.answer="['Apple', 'Sam', 'Venice']"] - Security answers
         * @param {bool}        [args.emailUpdates=false] - Optional Whether to opt for email updates.
         * @param {bool}        [args.runTest=false] - Optional Whether to run this test or not as we can max out the number of burns if run by mistake.
         */
        createNewiCloudAccount: function createNewiCloudAccount(args) {
            args = UIAUtilities.defaults(args, {
                 AppleID : 'PERSISTEDAPPLEID',
                 AppleIDPassword : 'PERSISTEDAPPLEIDPASSWORD',
                 emailUpdates: false,
                 runTest: false,
                 
                 // Account options
                 accountOptions: {
                 birthday:     'April/1/1984',
                 firstName:    'John',
                 lastName:     'Galt',
                 answer: ['Apple', 'Sam', 'Venice'],
                },
            });
        
            settings.launch();
            try {
                settings.createNewiCloud(args.AppleID, args.AppleIDPassword, args);
            } finally {
                settings.returnToTopLevel();
            }
        
        },
    }
}
