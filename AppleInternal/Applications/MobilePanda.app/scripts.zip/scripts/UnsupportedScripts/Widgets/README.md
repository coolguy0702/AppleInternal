Feature: Today view Widget tests
Maintainer(s): Chad Etzel
Maintainer(s) Email: cetzel@apple.com
Maintainer(s) Team: Proactive Siri
Maintainer(s) Team Manger: Colin Morris
Maintainer(s) Team Manger Email: colinmorris@apple.com
Scripts for Widget tests