load('UIATesting.js');
load('SpringBoard.js'); // load the library file

UIAUtilities.assert(
    typeof WidgetTests === 'undefined',
    'WidgetTests has already been defined.'
);


/**
 * @namespace WidgetTests
 */
var WidgetTests = {

    /**
     * Tests the Siri App Suggestions widget
     *
     * @targetApps SpringBoard
     *
     */
    testAppSuggestions: function testAppSuggestions(args) {
        args = UIAUtilities.defaults(args, {
        });

        var widgetName = 'Siri App Suggestions';
        var WIDGET_NAME_CAPS = 'SIRI APP SUGGESTIONS';

        springboard.getToWidgets();
        springboard.removeAllWidgetsExcept([widgetName]);

        UIAUtilities.assert(
            springboard.inspect(UIAQuery.query(WIDGET_NAME_CAPS)).isVisible,
            'App Suggestions widget is not visible.'
        );

        // check for 4 buttons in Compact mode
        springboard.widgetSetDisplayMode(widgetName, false);

        UIAUtilities.assertEqual(
            springboard.count(UIAQuery.query(WIDGET_NAME_CAPS).parent().parent().parent().andThen('_NCWidgetViewControllerView').andThen(UIAQuery.buttons())),
            4,
            'App Suggestions should show 4 buttons in Compact mode.'
        );


        // check for 8 buttons in Expanded mode
        springboard.widgetSetDisplayMode(widgetName, true);

        UIAUtilities.assertEqual(
            springboard.count(UIAQuery.query(WIDGET_NAME_CAPS).parent().parent().parent().andThen('_NCWidgetViewControllerView').andThen(UIAQuery.buttons())),
            8,
            'App Suggestions should show 8 buttons in Expanded3 mode.'
        );

        // check layout
        springboard.widgetSetDisplayMode(widgetName, false);

        var containerViewQuery = UIAQuery.query(WIDGET_NAME_CAPS).parent().parent().parent().andThen('_NCWidgetViewControllerView');
        var containerRect = springboard.inspect(containerViewQuery).rect;

        var buttonsQuery = containerViewQuery.andThen(UIAQuery.buttons())
        var firstButton = buttonsQuery.first()
        var lastButton = buttonsQuery.last()

        var firstButtonRect = springboard.inspect(firstButton).rect;
        var lastButtonRect = springboard.inspect(lastButton).rect;

        // check left margin > 0
        UIAUtilities.assert(
            firstButtonRect.x > containerRect.x,
            'Left margin should be greater than 0'
        );

        // check right margin > 0
        UIAUtilities.assert(
            containerRect.x + containerRect.width > lastButtonRect.x + lastButtonRect.width,
            'Right margin should be greater than 0'
        );

        // check left margin === right margin
        UIAUtilities.assertEqual(
            firstButtonRect.x - containerRect.x,
            (containerRect.x + containerRect.width) - (lastButtonRect.x + lastButtonRect.width),
            'Left and Right margins should be the same'
        );

        var topMargin = firstButtonRect.y - containerRect.y;
        var bottomMargin = (containerRect.y + containerRect.height) - (firstButtonRect.y + firstButtonRect.height);

        // check top margin > 0
        UIAUtilities.assert(
            topMargin > 0,
            'Top margin should be greater than 0'
        );

        // check bottom margin > 0
        UIAUtilities.assert(
            bottomMargin > 0,
            'Bottom margin should be greater than 0'
        );

        // check top and bottom margins are "the same" (within a few pixel tolerance b/c of label baseline)
        var tolerance = 5;
        UIAUtilities.assert(
            Math.abs(topMargin - bottomMargin) < tolerance,
            'Top and bottom margins should be equal'
        );

        // check button alignments

        // check top alignments
        for (var i = 1; i < 4; i++) {
            var rect = springboard.inspect(buttonsQuery.atIndex(i)).rect;

            // check top alignment
            UIAUtilities.assertEqual(
                firstButtonRect.y,
                rect.y,
                'Button ' + i + ' top alignment should match'
            );
        }

        // check spacing between buttons is equal and > 0
        var spacings = [];
        for (var i = 0; i < 3; i++) {
            var rect1 = springboard.inspect(buttonsQuery.atIndex(i)).rect;
            var rect2 = springboard.inspect(buttonsQuery.atIndex(i+1)).rect;
            var space = rect2.x - (rect1.x + rect1.width);
            spacings.push(space);
        }

        UIAUtilities.assert(
            spacings[0] === spacings[1] && spacings[1] === spacings[2] && spacings[0] > 0,
            'Button spacings should be equal.'
        );


        // test alignment for Expanded mode with 8 buttons
        springboard.widgetSetDisplayMode(widgetName, true);

        var button1Rect = springboard.inspect(buttonsQuery.atIndex(0)).rect;
        var button2Rect = springboard.inspect(buttonsQuery.atIndex(1)).rect;
        var button3Rect = springboard.inspect(buttonsQuery.atIndex(2)).rect;
        var button4Rect = springboard.inspect(buttonsQuery.atIndex(3)).rect;
        var button5Rect = springboard.inspect(buttonsQuery.atIndex(4)).rect;
        var button6Rect = springboard.inspect(buttonsQuery.atIndex(5)).rect;
        var button7Rect = springboard.inspect(buttonsQuery.atIndex(6)).rect;
        var button8Rect = springboard.inspect(buttonsQuery.atIndex(7)).rect;

        // test top alignment of 2nd row buttons
        UIAUtilities.assert(
            button5Rect.y === button6Rect.y && button6Rect.y === button7Rect.y && button7Rect.y === button8Rect.y,
            'Second row buttons should be top aligned.'
        );

        // test left alignment of icons between rows
        UIAUtilities.assertEqual(
            button1Rect.x,
            button5Rect.x,
            'Buttons 1 and 5 should be left aligned.'
        );
        UIAUtilities.assertEqual(
            button2Rect.x,
            button6Rect.x,
            'Buttons 2 and 6 should be left aligned.'
        );
        UIAUtilities.assertEqual(
            button3Rect.x,
            button7Rect.x,
            'Buttons 3 and 7 should be left aligned.'
        );
        UIAUtilities.assertEqual(
            button4Rect.x,
            button8Rect.x,
            'Buttons 4 and 8 should be left aligned.'
        );

        // update containerRect now that it is Expanded
        containerRect = springboard.inspect(containerViewQuery).rect;

        // recalculate bottomMargin
        bottomMargin = (containerRect.y + containerRect.height) - (button5Rect.y + button5Rect.height);

        // test that bottomMargin is still > 0
        UIAUtilities.assert(
            bottomMargin > 0,
            'Bottom margin should be greater than 0, even when Expanded'
        );

        // test that top and bottom margin are still equal within the tolerance
        UIAUtilities.assert(
            Math.abs(topMargin - bottomMargin) < tolerance,
            'Top and bottom margins should be equal, even when Expanded'
        );

        // TODO: write a test that launches an app and assert that it launched

    },

};
