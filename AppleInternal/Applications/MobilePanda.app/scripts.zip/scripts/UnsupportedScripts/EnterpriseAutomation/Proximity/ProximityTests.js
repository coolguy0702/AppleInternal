load('UIAUtility.js');
load('UIATarget.js');
load('UIATesting.js');
load('Proximity.js');

var ProximityTests = {
    
    /**
     * Begin Proximity Card -- start proximity process
     *
     * @param {object} args - Test arguments
     *
     */
    beginProximityCard: function beginProximityCard(args) {
        proximity.beginProximityCard(args);
    }
    
}
