load('UIAUtility.js');
load('UIAApp.js');
load('UIATesting.js');
load('ProximityTests.js');

var proximity = target.systemApp();

/**
 * Begin Proximity Card -- start proximity process
 *
 * @param {object} args - Test arguments
 *
 */
proximity.beginProximityCard = function beginProximityCard(args) {
    // Check to see if the card already is present by the time this script runs
    var hasProximityCard = target.activeApp().exists(UIAQuery.staticTexts().contains("Set up new"));
    
    // If it's not present, let's what
    if (hasProximityCard == false) {
        var waiter = UIAWaiter.waiter(
                                      "ViewDidAppear", {
                                      predicate: "controllerClass = 'iOSSetupMainController'",
                                      }
                                      );
        var timeout = 30;
        UIALogger.logMessage("Waiting for proximity setup card for %0 seconds...".format(timeout));
        hasProximityCard = waiter.wait(timeout);
    }
    
    if (hasProximityCard) {
        UIALogger.logMessage("Proximity setup card is present");
        UIALogger.logMessage("Tapping \"Continue\" on proximity setup card...");

        // Random delay otherwise for some reason we will not tap the button
        target.delay(2)
        target.activeApp().tap(UIAQuery.buttons().contains("Continue"));
//        target.delay(10)
//        target.activeApp().tap(UIAQuery.buttons().contains("Authenticate Manually"));
    } else {
        throw new UIAError("Proximity setup card never became active");
    }
};
