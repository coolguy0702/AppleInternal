load('UIAUtility.js');
load('UIAApp.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('Asam.js');

var AsamTests = {

    /**
     * Launch Managed ASAM -- test enabling and escaping managed ASAM
     *
     * @param {object} args - Test arguments
     *
     */
    managedAutonomousSingleAppMode: function managedAutonomousSingleAppMode(args) {
        asam.managedAutonomousSingleAppMode();
    },

    /**
     * Exit Managed ASAM -- ensure in ASAM after reboot then exit ASAM
     *
     * @param {object} args - Test arguments
     *
     */
    managedAutonomousSingleAppModeExit: function managedAutonomousSingleAppModeExit(args) {
        asam.managedAutonomousSingleAppModeExit();
    },

}
