load('UIAUtility.js');
load('UIAApp.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('AsamTests.js');

var asam = target.appWithBundleID('com.example.apple-samplecode.AutonomousSingleAppModeApp');

/**
 * Launches managed ASAM app and enables ASAM. Then attempts to escape managed ASAM by pressing home button and volume.
 *
 */
asam.managedAutonomousSingleAppMode = function managedAutonomousSingleAppMode() {
    this.launch();
    this.setControl(UIAQuery.switches(), true);
    target.delay(4);
    target.clickMenu();
    target.clickMenu();
    target.clickMenu();
    this.tap("Single App Mode")
    target.clickVolumeUp();
    target.clickMenu();
    this.tap("Single App Mode")
    target.clickVolumeDown();
    target.clickMenu();
    this.tap("Single App Mode")

}

/**
 * Ensure in ASAM after reboot then exists managed ASAM app.
 *
 */
asam.managedAutonomousSingleAppModeExit = function managedAutonomousSingleAppModeExit() {
    target.delay(4);
    target.clickMenu();
    target.clickMenu();
    target.clickMenu();
    this.tap("Single App Mode")
    target.clickVolumeUp();
    target.clickMenu();
    this.tap("Single App Mode")
    target.clickVolumeDown();
    target.clickMenu();
    this.tap("Single App Mode")
    this.setControl(UIAQuery.switches(), false);
    target.clickMenu();
    target.delay(4);
    this.launch();
    this.setControl(UIAQuery.switches(), true);
    target.delay(4);
    target.clickMenu();
    target.clickMenu();
    this.tap("Single App Mode")
    target.clickVolumeDown();
    target.clickMenu();
    this.tap("Single App Mode")
    this.setControl(UIAQuery.switches(), false);
    target.clickMenu();
}
