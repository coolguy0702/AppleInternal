load('UIAUtility.js');
load('UIATesting.js');
load('SingleSignOn.js');

var SingleSignOnTests = {
    
    /**
     * Enables Single Sign On cert based authentication for Ping app
     *
     * @param {object} args - Test arguments
     * @param {number}[args.timeout=30] - Max time to wait for SSO authentication
     * @param {string}[args.url="http://dc03.ads.apple.com/negotiate/"] - SSO URL
     */
    verifySingleSignOnPing: function verifySingleSignOnPing(args) {
        args = UIAUtilities.defaults(args, {
                                     url: "http://dc03.ads.apple.com/negotiate/",
                                     timeout: 30
                                     });
        singleSignOnPing.verifySingleSignOnPing(args);
    },
    
    /**
     * Enables Single Sign On cert based authentication for Safari app
     *
     * @param {object} args - Test arguments
     * @param {string}[args.url="http://dc03.ads.apple.com/negotiate/"] - SSO URL
     */
    verifySingleSignOnSafari: function verifySingleSignOnSafari(args) {
        args = UIAUtilities.defaults(args, {
                                     url: "http://dc03.ads.apple.com/negotiate/",
                                     });
        safari.verifySingleSignOnSafari(args.url);
    },
}
