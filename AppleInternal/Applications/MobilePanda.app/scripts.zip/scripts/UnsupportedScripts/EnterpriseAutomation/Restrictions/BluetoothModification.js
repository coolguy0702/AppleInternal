load('UIAUtility.js');
load('UIAApp.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('BluetoothModificationTests.js');
load('Settings.js');

/**
 * Enable or Disable Bluetooth in Settings -- enables or disables bluetooth in Settings
 *
 * @param {object} args - Test arguments
 * @param {boolean} [args.enable=true] - Whether to enable bluetooth or not
 */
settings.enableBluetooth = function enableBluetooth(args) {
    args = UIAUtilities.defaults(args, {
         enable: true,
    });
    this.launch();
    this.chooseSetting(['Bluetooth']);
    this.setControl(UIAQuery.switches("Bluetooth"), args.enable);
};
