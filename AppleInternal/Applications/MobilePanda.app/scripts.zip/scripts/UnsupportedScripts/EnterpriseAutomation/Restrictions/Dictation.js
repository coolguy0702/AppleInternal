load('UIAUtility.js');
load('UIAApp.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('DictationTests.js');
load('Settings.js');
load('Safari.js')

/**
 * Launches managed Settings app and verifies dictation is disabled.
 *
 */

settings.allowDictation = function allowDictation() {
    this.launch();
    this.chooseSetting(['General', 'Keyboard'])
    if (this.exists(UIAQuery.tableViews().andThen(UIAQuery.tableCells('Enable Dictation')))){
        throw new UIAError('Dictation is appearing in Settings');
    }
    else
        UIALogger.logMessage('Dictation is removed in Settings');
}

/**
 * Launches managed Safari app and verifies dictation is disabled on keyboard.
 *
 */

safari.allowDictationKeyboard = function allowDictationKeyboard() {
    this.launch()
    if(this.exists(UIAQuery.query("Cancel"))){
        this.tap("Cancel");
    }
    this.tap("UIAccessibilityElement")
    var keyboard = UIAQuery.keyboard()
    if (this.exists(UIAQuery.keyboard())){
        if (this.exists(UIAQuery.buttons('dictation').isVisible())){
            throw new UIAError('Dictation is appearing on keyboard');
        }
        else
            UIALogger.logMessage('Dictation is removed on keyboard');
    }
    else
        UIALogger.logMessage('Keyboard is not pulling up');
}
