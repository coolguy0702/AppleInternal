load('UIATesting.js');
load('SpringBoard.js');
load('Safari.js');

/**
 * Web Clip -- launches web clip and navigates to site in Safari
 *
 * @param {object} args - Test arguments
 * @param {string}[args.label="Apple"] - title of webclip on springboard
 * @param {string}[args.url=["https://developer.apple.com/"]] - url of webclip to navigate to in Safari
  * @param {boolean}[args.isRemovable=true] - check if webclip is allowed to be removed by the user or not
 *
 */

springboard.verifyWebClip = function verifyWebClip(args) {
    args = UIAUtilities.defaults(args, {
        label: "Apple",
        url: "https://developer.apple.com/",
        isRemovable: true,
    })
    this.launch()
    this.search(args.label)
    this.tap(args.label)
    this.delay(10)
    safari.assertActiveURL(args.url)
  }
