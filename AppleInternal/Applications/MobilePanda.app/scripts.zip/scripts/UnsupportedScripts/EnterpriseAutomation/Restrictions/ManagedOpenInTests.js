load('UIAUtility.js');
load('UIATarget.js');
load('UIATesting.js');
load('ManagedOpenIn.js');

var ManagedOpenInTests = {
    
    /**
     * Managed Domains -- ensure opening documents from a managed or unmanaged URL in Safari displays the correct apps in the share sheet from the More view and share view
     *
     * @param {object} args - Test arguments
     * @param {string}[args.url="https://www.apple.com/business/docs/iOS_Security_Guide.pdf"] - domain of URL
     * @param {array}[args.appsPresentInMore=[]] - apps that should appear under More due to managed open in policies
     * @param {array}[args.appsAbsentInMore=[]] - apps that should not appear under More due to managed open in policies
     * @param {array}[args.appsPresentInShare=["Mail"]] - apps that should appear on share sheet from share view due to managed open in policies
     * @param {array}[args.appsAbsentInShare=["Message", "Reminders", "Notes", "Twitter", "Facebook"]] - apps that should not appear on share sheet from share view due to managed open in policies
     * @param {boolean} [args.launchApps=false] - Whether to launch apps on share sheet or not
     *
     */
    verifyManagedDomains: function verifyManagedDomains(args) {
        args = UIAUtilities.defaults(args, {
            url:'https://www.apple.com/business/docs/iOS_Security_Guide.pdf',
            appsPresentInMore: [],
            appsAbsentInMore: [],
            appsPresentInShare: ['Mail'],
            appsAbsentInShare: ['Message', 'Reminders', 'Notes', 'Twitter', 'Facebook'],
            launchApps: false
        });
        safari.verifyManagedDomains(args);
    },

    /**
     * Managed Open In -- ensure opening documents from a managed or unmanaged app displays the correct apps in share sheet for the TreesGrowUp app
     *
     * @param {object} args - Test arguments
     * @param {string}[args.filename="C42E9C1F-6F72-47FD-A6F1-7885FA7E687A/Treesgrowup.app/treesgrowup.png"] - filename
     * @param {array}[args.appsPresentInShare=["Mail", "Content"]] - apps that should appear on share sheet from share view due to managed open in policies
     * @param {array}[args.appsAbsentInShare=["Message", "Reminders", "Notes", "Twitter", "Facebook", "Adobe"]] - apps that should not appear on share sheet from share view due to managed open in policies
     * @param {boolean} [args.launchApps=false] - Whether to launch apps on share sheet or not
     *
     */
    verifyManagedOpenInApps: function verifyManagedOpenInApps(args) {
        args = UIAUtilities.defaults(args, {
             filename:'C42E9C1F-6F72-47FD-A6F1-7885FA7E687A/Treesgrowup.app/treesgrowup.png',
             appsPresentInShare: ['Mail', 'Content'],
             appsAbsentInShare: ['Message', 'Reminders', 'Notes', 'Twitter', 'Facebook', 'Adobe'],
             launchApps: false
             }
        );
        treesGrowUp.verifyManagedOpenInApps(args);
    }
};
