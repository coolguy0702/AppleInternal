load('UIAUtility.js');
load('UIAApp.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');

var verifyAppIsAbsent = target.systemApp();

/**
 * Verifies apps do not exist on springboard.
 *
 * @param {array} appNames - array of app names to be verified
 * @throws UIAError if any app from the array is present on springboard
 */

    verifyAppIsAbsent.verifyAppIsAbsentOnSb = function verifyAppIsAbsentOnSb(appNames) {
        springboard.launch();
        var appInSpringboard = false;
        var appsInSB = "";
        for (var index = 0; index < appNames.length; index++){
            var appName = appNames[index];
            if (springboard.exists(springboard.iconQuery({name:appName}))) {
                UIALogger.logMessage('Found %0 icon on springboard'.format(appName))
                appsInSB += appName + ',';
                appInSpringboard = true;
            };
        };
        if(appInSpringboard) {
            throw new UIAError('Found %0 icon(s) on springboard'.format(appsInSB));
        };
    };
