load('UIAUtility.js');
load('UIAApp.js');
load('UIATarget.js');
load('SpringBoard.js');
load('Settings.js');

/**
 * Method to unenroll in Settings
 *
 * @param {object} mdmConfig - Test arguments
 * @param {string} [mdmConfig.Name] - MDM Server name
 * @param {int} [mdmConfig.timeDelay] - amount of time to wait for unenrollment
 * @param {boolean} [mdmConfig.mdmRemovable=false] - is the device able to remove MDM profile
 */

UIAQuery.Profiles = {
    PROFILE_VIEW : UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().withPredicate("name CONTAINS 'Profile' OR name CONTAINS 'Device Management'")),
}

settings.unenrollSettings = function unenrollSettings(mdmConfig) {
    mdmConfig = UIAUtilities.defaults(mdmConfig, {
        Name: "Workspace Services",
        timeDelay: 30,
        mdmProfileRemovable: true
    });
    this.navigateNavigationViews(["General", {'query': UIAQuery.Profiles.PROFILE_VIEW}]);
    var mdmProfile = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('MOBILE DEVICE MANAGEMENT'));
    if(!this.exists(mdmProfile)) {
        throw new UIAError("MDM Profile is not installed on the device. Nothing to unenroll")
    }
    this.tap(mdmConfig.Name);
    if (!mdmConfig.mdmProfileRemovable) {
        if (this.exists(UIAQuery.query("Remove Management"))) {
            throw new UIAError("Remove management should not be possible")
        }
        else {
            return UIALogger.logMessage("Test Passes");
        }
    }
    this.tap("Remove Management");
    this.tap("destructive-button");
    var counter = 0
    keepGoing = true
    while (keepGoing) {
        if (!this.exists(UIAQuery.query("Removing Profile"))){
            UIALogger.logMessage("Removing profile no longer appears. Let's proceed.")
            keepGoing = false
        }
        target.delay(1)
        UIALogger.logMessage('Waiting for removing profile to complete')
        counter = counter + 1
        if (counter >= mdmConfig.timeDelay){
            throw new UIAError("Timed out. Removing profile did not complete before specified time.")
            keepGoing = false
        }
    }
    if (!this.exists(UIAQuery.query("General"))){
        throw new UIAError("We should now be able to navigate back in Settings. Are we even still in Settings? FAIL!")
    }
    this.navigateNavigationViews(["General", {'query': UIAQuery.Profiles.PROFILE_VIEW}]);
    var mdmProfile = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('MOBILE DEVICE MANAGEMENT'));
    if(this.exists(mdmProfile)) {
        throw new UIAError("MDM Profile is not installed on the device. Nothing to unenroll")
    } else {
        UIALogger.logMessage("Successfully unenrolled")
    }
}
