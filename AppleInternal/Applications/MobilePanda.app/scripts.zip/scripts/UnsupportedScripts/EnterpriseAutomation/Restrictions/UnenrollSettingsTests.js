load('UIAUtility.js');
load('UIATesting.js');
load('UnenrollSettings.js');

UIAUtilities.assert(typeof UnenrollSettingsTests === 'undefined', 'Unenrolling in Settings has already been defined.');

var UnenrollSettingsTests = {
    
    /**
     * Method to unenroll in Settings
     *
     * @param {object} options - Test arguments
     * @param {string} [options.Name="Workspace Services"] - MDM Server name
     * @param {int} [options.timeDelay=30] - amount of time to wait for unenrollment
     * @param {boolean} [options.mdmRemovable=false] - is the device able to remove MDM profile
     */
    unenrollSettings: function unenrollSettings(options) {
        options = UIAUtilities.defaults(options, {
            Name: "Workspace Services",
            timeDelay: 30,
            mdmProfileRemovable: false
        });
        settings.unenrollSettings(options);
    }
}
