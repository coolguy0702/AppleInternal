load('UIAUtility.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('Settings.js');
load('BluetoothModification.js');

var BluetoothModificationTests = {
    
    /**
     * Enable or Disable Bluetooth in Settings -- enables or disables bluetooth in Settings
     *
     * @param {object} args - Test arguments
     * @param {boolean} [args.enable=true] - Whether to enable bluetooth or not
     */
    enableBluetooth: function enableBluetooth(args) {
        args = UIAUtilities.defaults(args, {
             enable: true,
        });
        settings.enableBluetooth(args);
    }
    
}
