load('UIATesting.js');
load('ContentFilter.js');

var ContentFilterTests = {
    
    /**
     * Content Filter -- ensure web content filter profile restricts specific sites
     *
     * @param {object} args - Test arguments
     * @param {array}[args.deniedUrls=["https://microsoft.com","https://facebook.com"]] - urls that should not be reachable
     * @param {array}[args.allowedUrls=["https://apple.com"]] - urls that should be reachable
     *
     */
    verifyContentFilter: function verifyContentFilter(args) {
        args = UIAUtilities.defaults(args, {
            deniedUrls: ['https://microsoft.com', 'https://facebook.com'],
            allowedUrls: ['https://apple.com'],
        });
        safari.verifyContentFilter(args);
    }
}
