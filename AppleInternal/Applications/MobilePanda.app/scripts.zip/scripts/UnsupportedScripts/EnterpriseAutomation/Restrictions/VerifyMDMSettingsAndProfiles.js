load('UIAUtility.js');
load('UIAApp.js');
load('UIATarget.js');
load('SpringBoard.js');
load('Settings.js');

/**
 * Method verifies the Mdm settings on the device by matching the expected settings name
 *
 * @param {object} mdmConfig - Test arguments
 * @param {string} [mdmConfig.Name] - MDM Server name
 * @param {array} [mdmConfig.Details] - MDM Profile names
 */

UIAQuery.Profiles = {
    PROFILE_VIEW : UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().withPredicate("name CONTAINS 'Profile' OR name CONTAINS 'Device Management'")),
}

settings.verifyMdmPolicies = function verifyMdmPolicies(mdmConfig) {
    mdmConfig = UIAUtilities.defaults(mdmConfig, {
        Name: "Workspace Services",
        Details: ["Device Management", "Wi-Fi", "Identity Certificate", "ManagedDomains", "Network Usage Rules", "Notifications", "Home Screen Layout", "Single Sign On", "Font", "Device Root"],
    });
    successfulMdmPolicies = ""
    missingMdmPolicies = ""
    failTest = false
    this.navigateNavigationViews(["General", {'query': UIAQuery.Profiles.PROFILE_VIEW}]);
    var mdmProfile = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('MOBILE DEVICE MANAGEMENT'));
    if(!this.exists(mdmProfile)) {
        throw new UIAError("MDM Profile is not installed on the device")
    }
    this.tap(mdmConfig.Name)
    this.tap(UIAQuery.staticTexts().withPredicate('name == "More Details"'));
    for(name of mdmConfig.Details) {
        if(!this.exists(UIAQuery.staticTexts().withPredicate('name contains "%0"'.format(name)))) {
            missingMdmPolicies = missingMdmPolicies += name + ', '
            UIALogger.logMessage('Did not find the following MDM policies: %0'.format(name))
            failTest = true
        }
        else {
            successfulMdmPolicies = successfulMdmPolicies += name + ', '
            UIALogger.logMessage('Found the following MDM policies: %0'.format(name))
        }
    }
    this.tap(UIAQuery.buttons('Profile'));
    settings.tap('back-nav-button');
    UIALogger.logMessage('***Succesfully found the following MDM policies***: %0'.format(successfulMdmPolicies))
    UIALogger.logMessage('***Did not find the following MDM policies***: %0'.format(missingMdmPolicies))
    if (failTest) {
        throw new UIAError('***ERROR: Following MDM policies are not found***: %0"'.format(missingMdmPolicies));
    }
}

/**
 * Method verifies the Mdm restrictions on the device by matching the expected restriction name
 *
 * @param {object} mdmConfig - Test arguments
 * @param {string} [mdmConfig.Name] - MDM Server name
 * @param {array} [mdmConfig.Restrictions] - MDM Restriction names
 */
settings.verifyMdmRestrictions = function verifyMdmRestrictions(mdmConfig) {
    mdmConfig = UIAUtilities.defaults(mdmConfig, {
        Name: "Workspace Services",
        Restrictions: ["Handoff not allowed", "Cookie policy enforced", "Whitelisted applications", "Wi-Fi whitelisting", "Wallpaper modification", "iBooks Store not allowed", "Adding or removing fingerprints not allowed", "Today view on lock screen not allowed", "iMessage not allowed", "Apple Music service not allowed", "Erase content and settings not allowed", "VPN creation not allowed", "iCloud backup not allowed", "Updating certificate trust database not allowed", "Podcasts not allowed", "Safari fraud warning enforced", "AirDrop not allowed", "Siri not allowed", "Bluetooth modification not allowed", "Notifications view on lock screen not allowed", "Control Center on lock screen not allowed", "iCloud Photo Library not allowed", "Changing app cellular data usage not allowed", "Touch ID unlock not allowed", "Passbook not allowed", "News not allowed"],
    });
    successfulRestrictions = ""
    missingRestrictions = ""
    failTest = false
    this.navigateNavigationViews(['General', {'query': UIAQuery.Profiles.PROFILE_VIEW}]);
    var mdmProfile = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('MOBILE DEVICE MANAGEMENT'));
    if(!this.exists(mdmProfile)) {
        throw new UIAError('MDM Profile is not installed on the device')
    }
    this.tap(mdmConfig.Name)
    this.tap(UIAQuery.staticTexts().withPredicate('name == "Restrictions"'));
    for(name of mdmConfig.Restrictions) {
        if (!this.exists(UIAQuery.staticTexts().withPredicate('name contains "%0"'.format(name)))) {
            missingRestrictions = missingRestrictions += name + ', '
            UIALogger.logMessage('Did not find the following restriction: %0'.format(name))
            failTest = true
        }
        else{
            successfulRestrictions = successfulRestrictions += name + ', '
            UIALogger.logMessage('Found the following restrictions: %0'.format(name))
        }
    }
    this.tap(UIAQuery.buttons('Profile'));
    settings.tap('back-nav-button');
    UIALogger.logMessage('***Succesfully found the following restrictions***: %0'.format(successfulRestrictions))
    UIALogger.logMessage('***Did not find the following restrictions***: %0'.format(missingRestrictions))
    if (failTest) {
        throw new UIAError('***ERROR: Following restrictions are not found***: %0"'.format(missingRestrictions));
    }
}

/**
 * Method verifies the configuration profile names in settings
 *
 * @param {object} options - Test arguments
 * @param {string} [options.Profiles] - Configuration Profile names
 */
settings.verifyConfigurationProfiles = function verifyConfigurationProfiles(options) {
    options = UIAUtilities.defaults(options, {
        Profiles: ["Restrictions", "Passcode", "FontProfile"],
    });
    successfulProfiles = ""
    missingProfiles = ""
    failTest = false
    this.navigateNavigationViews(["General", {'query': UIAQuery.Profiles.PROFILE_VIEW}]);
    var configProfiles = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('CONFIGURATION PROFILES'));
    if(!this.exists(configProfiles)) {
        throw new UIAError("Configuration Profiles are not installed on the device")
    }
    for(name of options.Profiles) {
        UIALogger.logMessage("Locating %0 Profile".format(name));
        if(!this.exists(UIAQuery.tableCells().withPredicate('name == "%0"'.format(name)))) {
            missingProfiles = missingProfiles += name + ', '
            UIALogger.logMessage('Did not find the following configuration profile: %0'.format(name))
            failTest = true
        }
        else {
            successfulProfiles = successfulProfiles += name + ', '
            UIALogger.logMessage('Found the following configuration profiles: %0'.format(name))
        }
    }
    UIALogger.logMessage('***Succesfully found the following configuration profiles***: %0'.format(successfulProfiles))
    UIALogger.logMessage('***Did not find the following configuration profiles***: %0'.format(missingProfiles))
    if (failTest) {
        throw new UIAError('***ERROR: Following configuration profiles are not found***: %0"'.format(missingProfiles));
    }
}
