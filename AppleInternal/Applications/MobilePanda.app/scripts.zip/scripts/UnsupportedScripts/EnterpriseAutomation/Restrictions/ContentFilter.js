load('UIATesting.js');
load('Safari.js');

/**
 * Content Filter -- ensure web content filter profile restricts specific sites
 *
 * @param {object} args - Test arguments
 * @param {array}[args.deniedUrls=["https://microsoft.com","https://facebook.com"]] - urls that should not be reachable
 * @param {array}[args.allowedUrls=["https://apple.com"]] - urls that should be reachable
 *
 */

safari.verifyContentFilter = function verifyContentFilter(args) {
    args = UIAUtilities.defaults(args, {
        deniedUrls: ['https://microsoft.com', 'https://facebook.com'],
        allowedUrls: ['https://apple.com'],
    });
    this.launch()
    if(this.exists(UIAQuery.query("Cancel"))){
        this.tap("Cancel");
    }
    for (index = 0; index < args.deniedUrls.length; index++) {
        var deniedUrl = args.deniedUrls[index]
        this.loadURL(deniedUrl)
        target.delay(5)
        if (this.exists('because it is restricted.')){
            UIALogger.logMessage('Successfully blocked the URL: %0'.format(deniedUrl))
        }
        else
            throw new UIAError('Browsed to a denied URL: %0'.format(deniedUrl))
    }
    for (index = 0; index < args.allowedUrls.length; index++) {
        var allowedUrl = args.allowedUrls[index]
        this.launch()
        this.loadURL(allowedUrl)
        this.delay(5)
        if (!this.exists('because it is restricted.')){
            UIALogger.logMessage('Successfully loaded the URL: %0'.format(allowedUrl))
        }
        else
            throw new UIAError('Failed to browse to an allowed URL: %0'.format(allowedUrl))
    }
}
