load('UIAUtility.js');
load('UIAApp.js');
load('UIATarget.js');
load('Safari.js');

var singleSignOnPing = target.appWithBundleID('com.apple.dr.ADSPing');

/**
 * Enables Single Sign On cert based authentication for Ping app
 *
 * @param {object} args - Test arguments
 * @param {number}[args.timeout=30] - Max time to wait for SSO authentication
 * @param {string}[url="http://dc03.ads.apple.com/negotiate/"] - SSO URL
 */
singleSignOnPing.verifySingleSignOnPing = function verifySingleSignOnPing(args) {
    args = UIAUtilities.defaults(args, {
        url: "http://dc03.ads.apple.com/negotiate/",
        timeout: 30
    });
    this.launch();
    this.tap(args.url);
    this.tap('Ping');
    if (!this.waitUntilPresent(UIAQuery.textViews().bottommost().withPredicate('value contains "Received response status 200"'), args.timeout)) {
        throw new UIAError('Something went wrong. Event did not appear.');
    }
    else{
        UIALogger.logPass("SSO cert based auth worked for Ping")
    }
    this.tap("Log Out");
}

/**
 * Enables Single Sign On cert based authentication for Safari app
 *
 * @param {object} args - Test arguments
 * @param {string}[args.url="http://dc03.ads.apple.com/negotiate/"] - SSO URL
 */
safari.verifySingleSignOnSafari = function verifySingleSignOnSafari(url) {
    safari.loadURL(url)
    if (safari.exists(UIAQuery.staticTexts('http negotiate'))==1){
        UIALogger.logPass("SSO cert based auth worked for Safari")
    }
    else{
        throw new UIAError('SSO cert based auth failed for Safari')
    }
}
