load('UIAUtility.js');
load('UIAApp.js');
load('UIATesting.js');
load('Safari.js');

var treesGrowUp = target.appWithBundleID('com.iosframeworksqa.Treesgrowup');

/**
 * Managed Domains -- ensure opening documents from a managed or unmanaged URL in Safari displays the correct apps in the share sheet from the More view and share view
 *
 * @param {object} args - Test arguments
 * @param {string}[args.url="https://www.apple.com/business/docs/iOS_Security_Guide.pdf"] - domain of URL
 * @param {array}[args.appsPresentInMore=[]] - apps that should appear under More due to managed open in policies
 * @param {array}[args.appsAbsentInMore=[]] - apps that should not appear under More due to managed open in policies
 * @param {array}[args.appsPresentInShare=["Mail"]] - apps that should appear on share sheet from share view due to managed open in policies
 * @param {array}[args.appsAbsentInShare=["Message", "Reminders", "Notes", "Twitter", "Facebook"]] - apps that should not appear on share sheet from share view due to managed open in policies
 * @param {boolean} [args.launchApps=false] - Whether to launch apps on share sheet or not
 *
 */
safari.verifyManagedDomains = function verifyManagedDomains(args) {
    args = UIAUtilities.defaults(args, {
        url:'https://www.apple.com/business/docs/iOS_Security_Guide.pdf',
        appsPresentInMore: [],
        appsAbsentInMore: [],
        appsPresentInShare: ['Mail'],
        appsAbsentInShare: ['Message', 'Reminders', 'Notes', 'Twitter', 'Facebook'],
        launchApps: false
        }
    );
    this.launch();
    if(this.exists(UIAQuery.query("Cancel"))){
        this.tap("Cancel");
    }
    this.loadURL(args.url);
    //Calls functions to verify apps on share sheet from More view
    this.delay(5)
    if (args.appsPresentInMore.length!==0 && args.appsAbsentInMore.length!==0){
        var moreButton = UIAQuery.buttons().withPredicate('name contains[c] "More"');
        if(!this.exists(moreButton))
            this.tap("UIPDFPageView");
        this.tap("More…");
        this.verifyAppsPresentOnShareSheet = verifyAppsPresentOnShareSheet(this, args.appsPresentInShare, args.launchApps)
        this.verifyAppsNotPresentOnShareSheet = verifyAppsNotPresentOnShareSheet(this, args.appsAbsentInShare)
        this.tap("Cancel");
    }
    //Call function to verify apps on share sheet from Share view
    this.tap("Share");
    var appsNotInShareSheet = verifyAppsPresentOnShareSheet(this, args.appsPresentInShare, args.launchApps)
    var appsInShareSheet = verifyAppsNotPresentOnShareSheet(this, args.appsAbsentInShare)
    if(this.exists(UIAQuery.query("Cancel"))){
        this.tap("Cancel");
    }
    else{
        this.tap(UIAQuery.contains("PopoverDismissRegion"));
    }
    var results = resultsShareSheet(appsNotInShareSheet, appsInShareSheet, args.appsPresentInShare, args.appsAbsentInShare)
};

/**
 * Managed Open In -- ensure opening documents from a managed or unmanaged app displays the correct apps in share sheet for the TreesGrowUp app
 *
 * @param {object} args - Test arguments
 * @param {string}[args.filename="C42E9C1F-6F72-47FD-A6F1-7885FA7E687A/Treesgrowup.app/treesgrowup.png"] - filename
 * @param {array}[args.appsPresentInShare=["Mail", "Content"]] - apps that should appear on share sheet from share view due to managed open in policies
 * @param {array}[args.appsAbsentInShare=["Message", "Reminders", "Notes", "Twitter", "Facebook", "Adobe"]] - apps that should not appear on share sheet from share view due to managed open in policies
 * @param {boolean} [args.launchApps=false] - Whether to launch apps on share sheet or not
 *
 */
treesGrowUp.verifyManagedOpenInApps = function verifyManagedOpenInApps(args) {
    args = UIAUtilities.defaults(args, {
         filename:'C42E9C1F-6F72-47FD-A6F1-7885FA7E687A/Treesgrowup.app/treesgrowup.png',
         appsPresentInShare: ['Mail', 'Content'],
         appsAbsentInShare: ['Message', 'Reminders', 'Notes', 'Twitter', 'Facebook', 'Adobe'],
         launchApps: false
         }
     );
    this.launch();
    this.tap("right-nav-button");
    if(!(this.exists(UIAQuery.staticTexts("What do you want to do ?"))))
       this.tap("file:///private/var/containers/Bundle/Application/"+args.filename);
    //Call function to verify apps on share sheet from Share view
    this.tap("Open in QuickLook");
    this.tap("QLOverlayDefaultActionButtonAccessibilityIdentifier");
    if(!(this.exists(UIAQuery.query('ActivityListView'))))
        this.tap("QLOverlayDefaultActionButtonAccessibilityIdentifier");
    target.delay(5)
    var appsNotInShareSheet = verifyAppsPresentOnShareSheet(this, args.appsPresentInShare, args.launchApps)
    var appsInShareSheet = verifyAppsNotPresentOnShareSheet(this, args.appsAbsentInShare, args.launchApps)
    var cancelButton = UIAQuery.buttons().withPredicate('name contains[c] "Cancel"');
    if(this.exists(cancelButton)){
        this.tap("Cancel");;
    }
    this.tap("QLOverlayDoneButtonAccessibilityIdentifier");
    this.tap("right-nav-button");
    var results = resultsShareSheet(appsNotInShareSheet, appsInShareSheet, args.appsPresentInShare, args.appsAbsentInShare)
};

/**
 * Verify apps present on share sheet -- ensure apps that should appear on the share sheet do appear
 *
 * @param {object} args - Test arguments
 * @param {array}[appNames=[]] - names of the apps that should appear on the share sheet
 * @returns {string} - list of apps that have incorrectly not displayed
 *
 */
verifyAppsPresentOnShareSheet = function verifyAppsPresentOnShareSheet(app, appNames, launchApps){
    var appsNotInShareSheet = "";
    var appsNotPresent = false;
    for (var index = 0; index < appNames.length; index++){
        var appName = appNames[index];
        if (app.exists(UIAQuery.query('UICollectionViewCellAccessibilityElement').andThen(UIAQuery.contains(appName)))){
            UIALogger.logMessage('Found %0 icon on share sheet'.format(appName));
        }
        else{
            appsNotInShareSheet += appName + ',';
            appsNotPresent = true;
        }
        if (launchApps){
            this.tap(appName)
            target.clickMenu()
            this.launch()
        }
    }
    return appsNotInShareSheet
};

/**
 * Verify apps absent on share sheet -- ensure apps that should be absent on the share sheet
 *
 * @param {object} args - Test arguments
 * @param {array}[appNames=[]] - names of the apps that should be absent on the share sheet
 * @returns {string} - list of apps that have incorrectly displayed
 *
 */
verifyAppsNotPresentOnShareSheet = function verifyAppsNotPresentOnShareSheet(app, appNames){
    var appsInShareSheet = "";
    var appsPresent = false;
    for (var index = 0; index < appNames.length; index++){
        var appName = appNames[index];
        if (!app.exists(UIAQuery.query('UICollectionViewCellAccessibilityElement').andThen(UIAQuery.contains(appName)))){
            UIALogger.logMessage('Successfully did not find %0 icon on share sheet'.format(appName));
        }
        else{
            appsInShareSheet += appName + ',';
            appsPresent = true
        }
    };
    return appsInShareSheet
};

/**
 * Results of share sheet test -- reveal results
 *
 * @param {object} args - Test arguments
 *
 */
resultsShareSheet = function resultsShareSheet(appsNotInShareSheet, appsInShareSheet, appsPresentInShare, appsAbsentInShare){
    if (appsNotInShareSheet || appsInShareSheet){
        throw new UIAError('***FAILED*** Failed to find %0 icon(s) on share sheet and incorrectly found %1'.format(appsNotInShareSheet, appsInShareSheet));
    } else {
        UIALogger.logMessage('***Successfully*** found %0 icon(s) and did not find %1'.format(appsPresentInShare, appsAbsentInShare))
    }
}
