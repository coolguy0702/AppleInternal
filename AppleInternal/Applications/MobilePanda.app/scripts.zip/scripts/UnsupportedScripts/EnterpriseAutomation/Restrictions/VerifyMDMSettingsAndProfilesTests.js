load('UIAUtility.js');
load('UIATesting.js');
load('VerifyMDMSettingsAndProfiles.js');

UIAUtilities.assert(typeof VerifyMDMSettingsAndProfilesTests === 'undefined', 'VerifyProfiles has already been defined.');

var VerifyMDMSettingsAndProfilesTests = {
    
    /**
     * Method to verify Mdm policies installed by MDM on iOS Device
     *
     * @param {object} options - Test arguments
     * @param {string} [options.Name="Workspace Services"] - MDM Server name
     * @param {Detail[]} [options.Details=["Device Management", "Wi-Fi", "Identity Certificate", "ManagedDomains", "Network Usage Rules", "Notifications", "Home Screen Layout", "Single Sign On", "Font", "Device Root"]] - MDM Profile names
     */
    verifyMdmPolicies: function verifyMdmPolicies(options) {
        options = UIAUtilities.defaults(options, {
            Name: "Workspace Services",
            Details: ["Device Management", "Wi-Fi", "Identity Certificate", "ManagedDomains", "Network Usage Rules", "Notifications", "Home Screen Layout", "Single Sign On", "Font", "Device Root"],
        });
        settings.verifyMdmPolicies(options);
    },
    
    /**
     * Method to verify Mdm restrictions on iOS Device
     *
     * @param {object} options - Test arguments
     * @param {string} [options.Name="Workspace Services"] - MDM Server name
     * @param {Restriction[]} [options.Restrictions=["Handoff not allowed", "Cookie policy enforced", "Whitelisted applications", "Wi-Fi whitelisting", "Wallpaper modification", "iBooks Store not allowed", "Adding or removing fingerprints not allowed", "Today view on lock screen not allowed", "iMessage not allowed", "Apple Music service not allowed", "Erase content and settings not allowed", "VPN creation not allowed", "iCloud backup not allowed", "Updating certificate trust database not allowed", "Podcasts not allowed", "Safari fraud warning enforced", "AirDrop not allowed", "Siri not allowed", "Bluetooth modification not allowed", "Notifications view on lock screen not allowed", "Control Center on lock screen not allowed", "iCloud Photo Library not allowed", "Changing app cellular data usage not allowed", "Touch ID unlock not allowed", "Passbook not allowed", "News not allowed"]] - MDM Profile names
     */
    verifyMdmRestrictions: function verifyMdmRestrictions(options) {
        options = UIAUtilities.defaults(options, {
            Name: "Workspace Services",
            Restrictions: ["Handoff not allowed", "Cookie policy enforced", "Whitelisted applications", "Wi-Fi whitelisting", "Wallpaper modification", "iBooks Store not allowed", "Adding or removing fingerprints not allowed", "Today view on lock screen not allowed", "iMessage not allowed", "Apple Music service not allowed", "Erase content and settings not allowed", "VPN creation not allowed", "iCloud backup not allowed", "Updating certificate trust database not allowed", "Podcasts not allowed", "Safari fraud warning enforced", "AirDrop not allowed", "Siri not allowed", "Bluetooth modification not allowed", "Notifications view on lock screen not allowed", "Control Center on lock screen not allowed", "iCloud Photo Library not allowed", "Changing app cellular data usage not allowed", "Touch ID unlock not allowed", "Passbook not allowed", "News not allowed"],
        });
        settings.verifyMdmRestrictions(options);
    },

    /**
     * Method to verify Configuration profiles on iOS Device
     *
     * @param {object} options - Test arguments
     * @param {Profile[]} [options.Profiles=["Restrictions", "Passcode", "FontProfile"]] - MDM Profile names
     */
    verifyConfigurationProfiles: function verifyConfigurationProfiles(options) {
        options = UIAUtilities.defaults(options, {
            Profiles: ["Restrictions", "Passcode", "FontProfile"],
        });
        settings.verifyConfigurationProfiles(options);
    },
};
