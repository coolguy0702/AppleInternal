load('UIAUtility.js');
load('UIAApp.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('WiFiWhitelistingTests.js');
load('Settings.js');

/**
 * Wi-Fi Whitelisting -- verify forceWiFiWhitelisting restriction is enforced in Wi-Fi Settings
 *
 * @param {object} args - Test arguments
 * @param {array}[args.ssids=["LIlyCat 5GHz","LIlyCat"]] - whitelisted SSIDs to appear under Wi-Fi Settings
 *
 */
settings.forceWiFiWhitelisting = function forceWiFiWhitelisting(args) {
    args = UIAUtilities.defaults(args, {
        ssids: ['LIlyCat 5GHz', 'LIlyCat']
    });
    this.launch();
    this.chooseSetting(['Wi-Fi'])
    this.delay(10)
    var cellCount = this.count(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "Wi-Fi"')).siblings());
    var ssidCount = args.ssids.length
    if (cellCount > (ssidCount+2)) {
        throw new UIAError('More SSIDs appear than what is whitelisted')
    }
    if (!this.exists(UIAQuery.staticTexts().withPredicate('name contains "configured by your organization"'))){
        throw new UIAError('Settings does not say that Wi-Fi is configured by the organization.')
    }
    else
        for (var index=0; index < ssidCount; index++) {
            var ssid = args.ssids[index];
            if (this.exists(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "%0"'.format(ssid))))) {
                UIALogger.logMessage('Found whitelisted Wi-Fi SSID: %0'.format(ssid));
            }
            else
                throw new UIAError('Did not find whitelisted SSID: %0'.format(ssid))
        };
};
