load('UIAUtility.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('Settings.js');
load('Dictation.js');

var DictationTests = {

    /**
     * Launch Settings -- check for dictation
     *
     * @param {object} args - Test arguments
     *
     */
    allowDictation: function allowDictation(args) {
        settings.allowDictation();
    },

 /**
     * Launch Safari -- ensure dictation does not appear on keyboard
     *
     * @param {object} args - Test arguments
     *
     */
    allowDictationKeyboard: function allowDictationKeyboard(args) {
        safari.allowDictationKeyboard();
    },

}
