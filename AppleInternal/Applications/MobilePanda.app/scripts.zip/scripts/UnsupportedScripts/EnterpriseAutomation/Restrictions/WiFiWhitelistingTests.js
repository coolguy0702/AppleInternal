load('UIAUtility.js');
load('Setup.js');
load('UIATarget.js');
load('SpringBoard.js');
load('UIATesting.js');
load('Settings.js');
load('WiFiWhitelisting.js');

var WiFiWhitelistingTests = {
    
    /**
     * Wi-Fi Whitelisting -- verify forceWiFiWhitelisting restriction is enforced in Wi-Fi Settings
     *
     * @param {object} args - Test arguments
     * @param {array}[args.ssids=["LIlyCat 5GHz","LIlyCat"]] - whitelisted SSIDs to appear under Wi-Fi Settings
     *
     */
    forceWiFiWhitelisting: function forceWiFiWhitelisting(args) {
        args = UIAUtilities.defaults(args, {
            ssids: ['LIlyCat 5GHz', 'LIlyCat']
        })
        settings.forceWiFiWhitelisting(args)
    }
}
