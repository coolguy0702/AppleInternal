load('UIAUtility.js');
load('UIAApp.js');
load('UIATarget.js');
load('UIATesting.js');
load('SpringBoard.js');
load('VerifyAppIsAbsent.js');

UIAUtilities.assert(  typeof verifyAppIsAbsentTests === 'undefined',
                    'verifyAppIsAbsentTests has already been defined.'
                    );

var verifyAppIsAbsentTests = {
    
    /**
     * Verify Apps Removed -- confirm 1st party apps are removed from springboard with restrictions
     *
     * @param {object} args - Test arguments
     * @param {array} [args.appNames=["Safari","News","Camera","Podcasts","FaceTime"]] - apps to be removed from springboard
     */
    verifyAppIsAbsentOnSb: function verifyAppIsAbsentOnSb(args) {
        args = UIAUtilities.defaults(args, {
                                     appNames:['Safari','News','Camera','Podcasts','FaceTime'],
                                     });
        verifyAppIsAbsent.verifyAppIsAbsentOnSb(args.appNames);
    },
};
