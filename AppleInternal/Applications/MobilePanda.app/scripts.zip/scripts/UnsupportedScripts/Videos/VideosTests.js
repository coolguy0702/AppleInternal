load('UIATesting.js');
load('Videos.js');

if (typeof VideosTests === 'undefined') {
    /**
     * @namespace VideosTests
     */
    var VideosTests = {
        /**
          * Play a video
          *
          * @targetApps Videos, mediaserverd
          *
          * @param {object} args - Test arguments
          * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
          * @param {int} [args.duration=5] - Optional how long to play the video for
          */
        playVideo: function playVideo(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 5,
            });
            videos.playVideo(args);
         },

         /**
          * Play and scrub a video
          *
          * @targetApps Videos, mediaserverd
          *
          * @param {object} args - Test arguments
          * @param {string} [args.videoName="Nasa DRM"] - Required name of the video to play
          * @param {int} [args.duration=5] - Optional how long to play the video for
          */
        playAndScrubVideo: function playAndScrubVideo(args) {
            args = UIAUtilities.defaults(args, {
                videoName: 'Nasa DRM',
                duration: 5,
            });
            videos.playAndScrubVideo(args);
         },

        /**************************************************
        **
        **************************************************/
    };
}
