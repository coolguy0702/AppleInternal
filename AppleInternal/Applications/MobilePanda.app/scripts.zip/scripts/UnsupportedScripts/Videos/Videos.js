load('UIAApp.js');
load('UIAApp+PiP.js');
load('SpringBoard.js');


if (typeof Videos === 'undefined') {

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for common Videos queries */
    UIAQuery.Videos = {

        /** Video controls displayed */
        CONTROLS:               UIAQuery.query('MPVideoPlaybackOverlayView').isVisible(),

        /** 'PlayButton' button */
        PLAY:                   UIAQuery.buttons('Play'),

        /** 'Pause' button */
        PAUSE:                  UIAQuery.buttons('Pause'),

        /** 'Done' button */
        DONE:                   UIAQuery.buttons('Done'),

        /**
        * 'Back' button
        * The 'Store' button has a "back-nav-button" identifier even though it's not a back nav button
        * This is a workaround so we don't tap 'Store' when we're trying to go back in the navigation hierarchy
        * <rdar://problem/23906353>
        */
        BACK:                   UIAQuery.withPredicate('any identifiers contains "back-nav-button" and not any identifiers contains[c] "store"'),

        /** 'Activate PiP' */
        PIP:                    UIAQuery.buttons('Picture In Picture'),

        /** Tap the now playing PiP video **/
        PIPVIDEO:               'PGLayerHostView',

        /** 'Movies View' */
        MOVIES_VIEW:            UIAQuery.navigationBars('Movies').andThen(UIAQuery.buttons('Edit')).isVisible(),

        /** 'Back Nav Button' */
        BACK_TO_MOVIES:         UIAQuery.buttons('back-nav-button'),

        /** Tap the now playing video **/
        VIDEO:                  'Video',

        /** Time Slider **/
        TIME_SLIDER:            UIAQuery.sliders('TrackPosition'),

        /** Subtitles/CC/ and other Audio Languages **/
        SUBTITLES_MENU:         UIAQuery.buttons('Alternate track'),

        /** Movies button in tab bar or segmented control **/
        MOVIES_BUTTON:          UIAQuery.buttons('Movies'),

    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: UI State Constants                                                  */
    /*                                                                             */
    /*      A dictionary of strings describing the possible UI states of the app   */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for possible UI state names specific to Videos */
    UIStateDescription.Videos = {
        /** Movies Tab */
        MOVIES:                     'movies',

        /** TV Shows Tab */
        TV_SHOWS:                   'TV shows',

        /** Home Videos Tab */
        HOME_VIDEOS:                'home videos',

        /** Music Videos Tab */
        MUSIC_VIDEOS:               'music videos',

        /** Rentals Tab */
        RENTALS:                    'rentals',

        /** Shared Tab */
        SHARED:                     'shared',

        /** Movie info */
        MOVIE_INFO:                 'movie info',

        /** Now Playing */
        NOW_PLAYING:                'now playing',

    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/


    /**
        @namespace
        @augments UIAApp
    */
    var videos = target.appWithBundleID('com.apple.videos');


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get The Current UI State                                            */
    /*                                                                             */
    /*      A function to determine which UIState the app is currently in          */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Videos for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
     */
    videos.currentUIState = function currentUIState() {
        throw new UIAError('Not yet implemented.');
    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get To [page] functions                                             */
    /*                                                                             */
    /*      Helper functions for navigating to different pages within the app      */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Get to the list of videos
     */
    videos.getToMoviesView = function getToMoviesView() {
        this.launch();

        if (this.exists(UIAQuery.Videos.VIDEO)) {
            this.doneWithPlayback();
        }

        this.tapIfExists(UIAQuery.Videos.MOVIES_BUTTON);
        this.tapIfExists(UIAQuery.Videos.BACK);
        this.pipClose();

        UIAUtilities.assert(
            !this.exists(UIAQuery.contains('No Content')),
            'No video content available'
        );

        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Videos.MOVIES_VIEW, 2),
            'Did not successfully navigate to Movies View'
        );
    };


    /***********************************************************************************/
    /*                                                                                 */
    /*   Mark: Tasks                                                                   */
    /*                                                                                 */
    /*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
    /*      These will be comprised of multiple Action functions                       */
    /*                                                                                 */
    /***********************************************************************************/

    /**
     * Play a video
     *
     * @param {object} options
     * @param {string} options.videoName - the name of the video to play
     * @param {int} options.duration - how long to play the long for
     * @param {scrubToPosition} - The position to scrub the video to

     */

    videos.playVideo = function playVideo(options) {
        options = UIAUtilities.defaults(options, {
            videoName: 'Nasa DRM',
            duration: 5,
            scrubToPosition: null,
        });

        this.getToMoviesView();
        this.selectAndPlayVideo(options.videoName);
        var startTime = this.getCurrentTime();

        if (options.scrubToPosition) {
            // <rdar://problem/27906583> Play And Scrub Video: tapping pause button fails due to vannishing video controls
            this.delay(1);
            this.pauseVideo();
            this.scrubVideo(options.scrubToPosition);
            this.interactWithVideoHUDControl(function() {
                this.tap(UIAQuery.Videos.PLAY);
            });
        }

        this.delay(options.duration);
        this.pauseVideo();
        this.verifyTimeElapsed(startTime);
        this.interactWithVideoHUDControl(function () {
            this.tap(UIAQuery.Videos.DONE);
        });
    };

    /**
     * Play and scrub a video
     *
     * @param {object} options
     * @param {string} options.videoName - the name of the video to play
     * @param {number} options.duration - how long to play the video after scrubbing
     * @param {number} options.endpoint - where to scrub to
     */
    videos.playAndScrubVideo = function playAndScrubVideo(options) {
        options = UIAUtilities.defaults(options, {
            videoName: 'Nasa DRM',
            duration: 5,
            scrubToPosition: 0.9,
        });

        this.playVideo(options);
    };

    /**
     * Enter the Picture in Picture Player
     *
     * @param {object} options
     * @param {string} options.videoName - the name of the video to play
     * @param {int} options.duration - how long to play in the Picture in Picture window for

     */
    videos.pipVideo = function pipVideo(options){
        if (!options.videoName) {
            throw new UIAError('No video name specified');
        }
        if (!options.duration) {
            options.duration = 7;
        }

        this.getToMoviesView();
        this.tap(UIAQuery.tableCells().contains(options.videoName));
        //Wait for the Extras to load so that the PiP button does not move when we try to Tap it.
        var stateChangedEvent = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerClass == MPUExtrasFeatureContainerViewController'
        );

        if (this.waitUntilPresent(UIAQuery.Videos.PLAY.isVisible(), 1)) {
            this.tap(UIAQuery.Videos.PLAY);
            UIALogger.logDebug('Just tapped play.');
        }

        if (!stateChangedEvent.wait(3)) {
            UIALogger.logWarning('Never got the ViewDidAppear event for entering playback.  This may indicate an error.');
        }

        this.performPip();
        this.delay(options.duration);
        this.verifySuccessfullyEnteredPip();
    };

    /**
     * Pause the Now Playing video and enter the Picture in Picture Player
     *
     * @param {object} options
     * @param {string} options.videoName - the name of the video to play
     * @param {int} options.duration - how long to play in the Picture in Picture window for

     */
    videos.pipPausedVideo = function pipPausedVideo(options){
        if (!options.videoName) {
            throw new UIAError('No video name specified');
        }
        if (!options.duration) {
            options.duration = 7;
        }

        this.getToMoviesView();
        this.tap(UIAQuery.tableCells().contains(options.videoName));
        //Wait for the Extras to load so that the PiP button does not move when we try to Tap it.
        var stateChangedEvent = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass == MPUExtrasFeatureContainerViewController')
        if (this.waitUntilPresent(UIAQuery.Videos.PLAY.isVisible(), 1)) {
            this.tap(UIAQuery.Videos.PLAY);
            UIALogger.logDebug('Just tapped play.');
        }

        if (!stateChangedEvent.wait(3)) {
            UIALogger.logWarning('Never got the ViewDidAppear event for entering plyabck.  This may indicate an error.');
        }
        this.pauseVideo();
        this.performPip();
        this.delay(options.duration);
        this.verifySuccessfullyEnteredPip();
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Actions                                                             */
    /*                                                                             */
    /*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
    /*      Other helper functions. E.g. - returnCleanedNumber                     */
    /*                                                                             */
    /*******************************************************************************/

    /**
    * Tap the Picture in Picture button to create a Picture in Picture window for the current playing video
    *
    * @returns {None}
    */
    videos.performPip = function performPip() {
        if (!videos.exists(UIAQuery.Videos.PIP.isVisible())) {
            UIALogger.logDebug('Tapping Video to display Playback UI');
            this.tap(UIAQuery.Videos.VIDEO);
        }

        if (this.waitUntilPresent(UIAQuery.Videos.PIP.isVisible(), 3)) {
            UIALogger.logDebug('Tapping the PiP button');
            this.tap(UIAQuery.Videos.PIP);
        }
    };

    /**
    * Close the Picture in Picture window
    *
    * @returns {None} - throws an error if the PiP window is still around
    */
    videos.pipClose = function pipClose() {
        if (!springboard.exists(UIAQuery.SpringBoard.CLOSE_PIP.isVisible()) && springboard.exists(UIAQuery.Videos.PIPVIDEO)) {
            UIALogger.logDebug('Tapping PiP\'d Video to display PiP Playback UI');
            springboard.tap(UIAQuery.Videos.PIPVIDEO);
        }
        this.closePip(2);
        this.delay(1);
        this.verifySuccessfullyClosedPiP();
    };

    /**
    * Tap the fullscreen button to take the Picture in Picture window back to the originating app and go full screen
    *
    * @returns {None} - throws an error if the fullcreen playback UI does not exist
    */
    videos.pipFullScreen = function pipFullScreen() {
        if (!springboard.exists(UIAQuery.SpringBoard.FULLSCREEN_PIP.isVisible())) {
            UIALogger.logDebug('Tapping PiP\'d Video to display PiP Playback UI');
            springboard.tap(UIAQuery.Videos.PIPVIDEO);
        }
        this.fullScreenPip(2);
        this.delay(1);
        videos.verifySuccessfulReturnFromPip();
    };

    /**
    * Tap the pause button in the Picture in Picture window to pause playback in the smaller video player
    *
    * @returns {None} - throws an error if the pause button does not change to the play button
    */
    videos.pipPause = function pipPause() {
        if (!springboard.exists(UIAQuery.SpringBoard.PAUSE_PIP.isVisible())) {
            UIALogger.logDebug('Tapping PiP\'d Video to display PiP Playback UI');
            springboard.tap(UIAQuery.Videos.PIPVIDEO);
        }
        this.pausePip(2);
    };

    /**
    * Tap the play button in the Picture in Picture window to start/restart playback in the smaller video player
    *
    * @returns {None} - throws an error if the play button does not change to the pause button
    */
    videos.pipPlay = function pipPlay() {
        if (!springboard.exists(UIAQuery.SpringBoard.PLAY_PIP.isVisible())) {
            UIALogger.logDebug('Tapping PiP\'d Video to display PiP Playback UI');
            springboard.tap(UIAQuery.Videos.PIPVIDEO);
        }
        this.playPip(2);
    };

    /**
    * Choose a video from a collection and tap play to start playback
    *
    * @param {number} videoName - name of the video

    * @returns {None} - throws if video cannot be found
    */
    videos.selectAndPlayVideo = function selectAndPlayVideo(videoName) {
        this.tap(UIAQuery.tableCells().contains(videoName)),
        this.waitUntilPresent(UIAQuery.Videos.PLAY.isVisible(), 1);
        UIALogger.logDebug('Playing the video.');
        this.tap(UIAQuery.Videos.PLAY);
        this.waitUntilPresent(UIAQuery.Videos.PAUSE, 3);
    };

    /**
    * Tap the pause button in the playback UI to pause video playback
    *
    * @returns {None}
    */
    videos.pauseVideo = function pauseVideo() {
        // <rdar://problem/27906583> Play And Scrub Video: tapping pause button fails due to vanishing video controls
        videos.interactWithVideoHUDControl(function() {
            this.tap(UIAQuery.Videos.PAUSE);
        });
    };

    /**
    * Tap the Done button in the playback UI to end video playback
    *
    * @returns {None}
    */
    videos.doneWithPlayback = function doneWithPlayback() {
        if (!this.exists(UIAQuery.Videos.DONE.isVisible())) {
            this.tap(UIAQuery.Videos.VIDEO);
        }
        if (this.waitUntilPresent(UIAQuery.Videos.DONE.isVisible(), 3)) {
            var waiter = UIAWaiter.withPredicate(
                'ViewDidDisappear',
                'controllerClass = "VideosPlaybackViewController"'
            );
            UIALogger.logDebug('Tapping the done button.');
            this.tap(UIAQuery.Videos.DONE);
            waiter.wait(3);
        }
    };

    /**
    * Scrub the video by dragging the track position slider
    *
    * @param {number} scrubToPosition - the position to scrub to as a proportion
    *                                   of the total time. Must be between 0 and 1.
    * @returns {None} - throws an error if video is not playing, input is invalid, or
    *                   did not scrub to desired value
    */
    videos.scrubVideo = function scrubVideo(scrubToPosition) {
        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Videos.VIDEO, 3),
            'Cannot scrub because video is not playing'
        );

        UIAUtilities.assert(
            scrubToPosition >= 0 && scrubToPosition <= 1,
            'Cannot scrub to desired position. Value must be between 0 and 1.'
        );

        if (!this.exists(UIAQuery.Videos.CONTROLS)) {
            this.tap(UIAQuery.Videos.VIDEO);
        }

        if (this.waitUntilPresent(UIAQuery.Videos.CONTROLS, 3)) {
            // setControl doesn't work well with sliders, so calculate
            // position of control and explicitly drag it instead
            // <rdar://problem/23586753>

            var sliderInfo = this.inspect(UIAQuery.Videos.TIME_SLIDER);

            // the width of the rect that holds the slider
            var rectWidth = sliderInfo.rect.width;

            // there is an approximately 47-point offset from the start of rect to the
            // start of the slider and from the end of the slider to the end of the rect
            var offset = 47;

            // the slider is smaller than the rect
            var sliderWidth = sliderInfo.rect.width - 2*offset;

            // the current position (in points) of the thumb relative to the left edge of the rect
            var startPoint = sliderInfo.hitpoint.x - sliderInfo.rect.x;

            // the current position (as a proportion of the rect width) of the thumb
            // relative to the start of rect
            var startProportion = startPoint / rectWidth;

            // the current position of the thumb as a percentage of the slider width
            var startPercentage = (startPoint - offset) / sliderWidth * 100;

            // the end position (in points) relative to the start of rect
            var endPoint = (scrubToPosition * sliderWidth) + offset;

            // the end position (as a proportion of the rect width) relative to the start of rect
            var endProportion = endPoint / rectWidth;

            // the end position as a percentage of the slider width
            var endPercentage = scrubToPosition * 100;
            UIALogger.logDebug('Scrubbing from %0% to %1%.'.format(startPercentage, endPercentage));

            // Note: when using this.drag, the 'fromOffset' point is relative to the Query's hitpoint,
            // while the 'toOffset' point is relative to the Query's rect starting position
            this.drag(UIAQuery.Videos.TIME_SLIDER, {toOffset: {x: endProportion, y:0.5}});

            // verify that the slider made it to the desired position
            sliderInfo = this.inspect(UIAQuery.Videos.TIME_SLIDER);
            var newProportion = (sliderInfo.hitpoint.x - sliderInfo.rect.x) / rectWidth;
            UIALogger.logDebug('Tried to scrub to position: %0. Actual position: %1'.format(endProportion, newProportion));

            // add 10% fudge factor because points may be slightly off due to offsets and drag inaccuracies
            var fudge = 0.10;
            UIAUtilities.assert(
                newProportion + fudge >= endProportion,
                'Slider did not move to desired position.'
            );
        }
    };

    /**
    * call a function in a displayed video's controls. These controls can be finicky,
    * so tapping is surrounded by a try catch that ensures controls are made visible
    *
    * @param {function} body - The function body to execute with the video present
    *
    * @returns {None}
    */
    videos.interactWithVideoHUDControl = function interactWithVideoHUDControl(body) {
        // There are two possible states: controls up or controls down.
        // There is a race condition as the controls could be transitioning from
        // one state to the other while we attempt to perform some action on them.
        // In order to make this test more reliable, we will force the HUD to
        // appear before interacting with elements to force the HUD to be up for
        // the maximum amount of time possible. This means we may have to dismiss
        // the HUD first before making it appear—since it could be stale.
        body = body.bind(this);

        var hiddenWaiter = UIAWaiter.withPredicate(
            'Announcement',
            'announcement = "Controls hidden"'
        );

        UIALogger.logDebug('Attempting to spawn the video HUD with max uptime. May tap "%0" twice to dismiss and spawn HUD.'.format(UIAQuery.Videos.VIDEO));

        this.tap(UIAQuery.Videos.VIDEO);

        if (hiddenWaiter.wait(1)) {
            var shownWaiter = UIAWaiter.withPredicate(
                'Announcement',
                'announcement = "Controls shown"'
            );

            this.tap(UIAQuery.Videos.VIDEO);
            shownWaiter.wait(1);
        }

        return body();
    };


    /************************************
    * Functions for verification
    *************************************/
    /**
    * Verifies that we successfully returned from the Picture in Picture window to full screen video playback
    *
    * @returns {None} - throws an error if the time slider, the pause or play button, and the done button do not exist
    */
    videos.verifySuccessfulReturnFromPip = function verifySuccessfulReturnFromPip() {
        if ( !(videos.exists(UIAQuery.Videos.TIME_SLIDER) &&
        (videos.exists(UIAQuery.Videos.PAUSE) || videos.exists(UIAQuery.Videos.PLAY)) &&
        videos.exists(UIAQuery.Videos.DONE)) ) {
            throw new UIAError('We failed to return to full screen from the PiP window. This is a problem.');
        }
    };

    /**
    * Verifies that we successfully returned from the Picture in Picture window to full screen video playback
    *
    * @returns {None} - throws an error if the Picture in Picture cancel button, full screen button, and play or pause button exist
    */
    videos.verifySuccessfullyClosedPiP = function verifySuccessfullyClosedPiP() {
        this.successfullyClosedPip();
    };

    /**
    * Verifies that we successfully returned from the Picture in Picture window to full screen video playback
    *
    * @returns {None} - throws an error if the Picture in Picture cancel button, full screen button, and play or pause button do not exist
    */
    videos.verifySuccessfullyEnteredPip = function verifySuccessfullyEnteredPip() {
        this.successfullyEnteredPip();
    };

    /**
    * Verifies that the time has elapsed since the given startTime
    *
    * @param {string} startTime - the time that the video started playing
    * @returns {None} - throws an error if the start time and end time are the same
    */
    videos.verifyTimeElapsed = function verifyTimeElapsed(startTime) {
        UIAUtilities.assert(
            startTime,
            'Must provide a start time when calling verifyTimeElapsed'
        );

        var endTime = this.getCurrentTime();

        UIAUtilities.assert(
            startTime !== endTime,
            "Video track progress didn't change. Start time and end time are both %0".format(startTime)
        );
    };

    /**
    * Gets the track position of the currently playing video.
    *
    * Expected starting states:
    *              Full-screen player and on-screen controls are visible
    *
    * @returns {string} - current track position
    */
    videos.getCurrentTime = function getCurrentTime() {
        var currentTime = this.interactWithVideoHUDControl(function() {
            if (!this.exists(UIAQuery.Videos.TIME_SLIDER)) {
                throw new UIAError('TrackPosition element does not exist.');
            }

            var inspection = this.inspect(UIAQuery.Videos.TIME_SLIDER);
            if (!inspection) {
                throw new UIAError('Failed to inspect TrackPosition element.');
            }

            if (!inspection.value) {
                UIALogger.logDebug(help(inspection));
                throw new UIAError('value attribute for TrackPosition inspection failed.');
            }

            return inspection.value;
        });
        UIALogger.logMessage('Current time is %0'.format(currentTime));
        return currentTime;
    };
}
