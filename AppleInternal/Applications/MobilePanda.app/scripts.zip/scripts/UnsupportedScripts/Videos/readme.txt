App/Project/Feature: Videos App
Maintainer(s): Jack Diaz
Maintainer(s) Email: jack_diaz@apple.com
Maintainer(s) Team: Test Engineering Productivity
Maintainer(s) Team Manger: Steve Pai
Maintainer(s) Team Manger Email: steve_pai@apple.com

These scripts include: Scripts to automate the Videos app. We have moved them out of the supported area because this app is no longer part of the OS. We did not want to break anyone who relies on these tests so we kept them in here. There should be no expectation that these tests function for newer versions of the OS.