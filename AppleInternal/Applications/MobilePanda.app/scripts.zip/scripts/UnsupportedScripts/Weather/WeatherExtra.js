load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');

weather.getToTodayWidget = function getToTodayWidget() {
    if (target.model() === 'iPad') {
        var waiter = UIAWaiter.withPredicate('ViewDidAppear', 'controllerClass == "WALockscreenWidgetViewController"'
         );
        springboard.getToWidgets();
        if (!waiter.wait(10)) {
            throw new UIAError('iPad Today Weather not visible');
        }
    } else {
        springboard.scrollToWidget("Weather");
    }
}
