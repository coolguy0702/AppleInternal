load('UIAApp.js');
load('UIATesting.js');
load('SpringBoard.js');
load('Weather.js');
load('WeatherExtra.js');


if (typeof WeatherExtraTests !== 'undefined') {
    throw new UIAError("Namespace 'WeatherTests' has already been defined.");
}


var WeatherExtraTests = {
    
    /**
     * View the Weather widget in Today View
     *
     * @targetApps MobileWeather SpringBoard
     *
     */
getToTodayViewWeather: function getToTodayViewWeather(args) {
    //default arguments
    args = UIAUtilities.defaults(args, {
                                 });
    
    weather.getToTodayWidget();
}
    
}
