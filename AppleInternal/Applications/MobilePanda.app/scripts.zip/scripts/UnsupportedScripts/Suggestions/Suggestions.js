load('UIATesting.js');
load('Mail.js');
load('Settings.js');

// System date at the begining of the test.
// This is used when reading the syslog to ignore any messages before the `syslogReferenceDate`.
var syslogReferenceDate = null;
var SYSLOG_REFERENCE_DATE_PATH = '/usr/local/etc/scripterUIA/suggestions_syslog_refdate.js';

if (UIAFile.fileExists(SYSLOG_REFERENCE_DATE_PATH)) {
    var file = UIAFile.open(SYSLOG_REFERENCE_DATE_PATH, 'r');
    syslogReferenceDate = file.read();
    UIALogger.logDebug('syslogReferenceDate set to "%0"'.format(syslogReferenceDate));
    file.close();
}


function setSyslogReferenceDate() {
    syslogReferenceDate = firstLineFrom(outputOf(exec('/bin/date', ['+%b %d %T'])));
    var file = UIAFile.open(SYSLOG_REFERENCE_DATE_PATH, 'w');
    file.write(syslogReferenceDate);
    file.close();
}

function exec(cmd, args, options) {
    options = options || {};
    UIALogger.logDebug('Executing %0 %1'.format(cmd, args.join(' ')));

    var result = target.performTask(cmd, args, options.timeout || 20);

    UIALogger.logDebug(JSON.stringify(result, null, 2));

    // TODO: vojta: use result.exitCode <rdar://problem/22218193> target.performTask returns exitCode as signal
    var exitCode = result.signal;

    if (exitCode !== 0) {
        throw new UIAError('Command %0 exited with %1.\n%2'.format(cmd, exitCode, result.stderr));
    }

    if (result.timedOut) {
        throw new UIAError('Command %0 timed out'.format(cmd));
    }

    return result;
}

function addIcloudAccountFromCLI(username, password) {
    exec('/usr/local/bin/appleAccountSetupTool', [username, password], {timeout: 20});
    exec('/usr/local/bin/accounts_tool', ['listAccounts']);

    // Kill Mail app. Otherwise when adding an account with appleAccountSetupTool,
    // Mail often does not notice the new account.
    var result = target.performTask('/usr/bin/killall', ['-9', 'MobileMail']);
    UIALogger.logDebug(result);
}


function writeToFile(path, content) {
    exec('/bin/bash', ['-c', 'echo -e "%0" > %1'.format(content, path)]);
}

function forceEmailHarvest(completionPredicate, options) {
    pollUntil(function() {
        var result = completionPredicate();
        if (!result) {
            exec('/usr/local/bin/suggest_tool', ['harvest']);
        }
        return result;
    }, options);
}

// TODO: vojta: use mail.composeAndSendEmail() once it gets fixed;-)
function composeAndSendEmail(options) {
    mail.launch();
    mail.getToMailboxesPage();
    mail.tap('All Inboxes');
    mail.tap('Compose');
    mail.typeString(options.recipient);
    mail.typeString('\n'); // Press enter to dismiss the autocomplete view.
    mail.tap('Cc/Bcc, From:');
    mail.tap('fromField');
    mail.setControl(UIAQuery.pickerWheels(), options.sender);
    mail.tap('subjectField');
    mail.typeString(options.subject);
    mail.tap('Message body');
    mail.typeString(options.text);
    mail.tap(UIAQuery.buttons('right-nav-button').isVisible()); // Send
}

// TODO: vojta: remove once mail.currentUIState() does not throw.
function mailCurrentUIState() {
    try {
        return mail.currentUIState();
    } catch (e) {
        return UIStateDescription.UNKNOWN;
    }
}

function mailGoToAccountsPage() {
    mail.launch();

    if (mailCurrentUIState() === UIStateDescription.MAIL_COMPOSITION) {
        mail.tap(UIAQuery.Mail.CANCEL_BUTTON);
        mail.tap('Delete Draft');
    }
    if (mailCurrentUIState() === UIStateDescription.Mail.EMAIL_CONTENT) {
        mail.tap(UIAQuery.BACK_NAV_BUTTON);
    }
    if (mailCurrentUIState() === UIStateDescription.Mail.MAIL_FOLDER_VIEW) {
        mail.tap(UIAQuery.BACK_NAV_BUTTON);
    }
    if (mailCurrentUIState() === UIStateDescription.Mail.MAIL_FOLDER_VIEW) {
        mail.tap(UIAQuery.BACK_NAV_BUTTON);
    }
    if (mailCurrentUIState() === UIStateDescription.UNKNOWN) {
        mail.tap(UIAQuery.BACK_NAV_BUTTON);
    }
}

function deleteAllExistingMessagesIncludingSentAndTrash() {
    // `mail` is defined in `Mail.js`
    mail.launch();
    mail.getToMailboxesPage();

    var accounts = UIAQuery.tableCells().below(UIAQuery.query("ACCOUNTS"));
    for (var i = 0; i < mail.count(accounts); i++) {
        clearAccountInboxAndSentAndTrash(accounts.atIndex(i));
    }
}

function clearAccountInboxAndSentAndTrash(account) {
    mail.tap(account);
    clearMailbox('Inbox');
    clearMailbox('Sent', {ignoreIfNotExist: true});
    clearMailbox('Trash', {buttonLabel: 'Delete All'});
    mail.tap(UIAQuery.BACK_NAV_BUTTON);
}

function clearMailbox(mailbox, options) {
    options = options || {};

    var buttonLabel = options.buttonLabel || 'Trash All';

    if (!mail.exists(mailbox)) {
        if (options.ignoreIfNotExist) {
            return;
        }
        throw new UIAError('Can not clear mailbox "%0". It does not exist!'.format(mailbox));
    }

    mail.tap(mailbox);
    if (!mail.exists(UIAQuery.query('No Mail'))) {
        mail.tap('Edit');
        mail.tap(buttonLabel);
        mail.tap(UIAQuery.buttons(buttonLabel).isVisible());

        // <rdar://problem/22429486> UIA2 UIAApp.tap(UIAQuery.BACK_NAV_BUTTON) did not tap the button
        // When deleting, it might take some time for the UI to show up, wait for it.
        mail.waitUntilPresent(UIAQuery.BACK_NAV_BUTTON.isVisible());
    }

    mail.tap(UIAQuery.BACK_NAV_BUTTON);
}

function addIcloudMailAccount(options) {
    settings.createEmail({
        type: settings.accountType.iCloud,
        address: options.address,
        password: options.password,
        throwIfAccountAlreadyAdded: false,
        syncOptions: {}
    });
}

function removeIcloudMailAccount(account) {
    if (!settings.navigateNavigationViews(['Mail, Contacts, Calendars'])) {
        throw new UIAError('Could not get to "Mail, Contacts, Calendars" view');
    }

    var accounts = UIAQuery.tableViews().andThen('ACCOUNTS');
    if (settings.waitUntilPresent(accounts, 0.5)) {
        UIALogger.logMessage('Looking for account %0'.format(account));
        var accountQuery = UIAQuery.tableViews().andThen(account);
        if (settings.exists(accountQuery)) {
            settings.tap(accountQuery);
            settings.tap(UIAQuery.tableViews().andThen('Sign Out'));
            settings.tap(UIAQuery.buttons('Delete from My iPhone'));
            target.delay(10.0);
        } else {
            UIALogger.logMessage('Account %0 was not already present.'.format(account));
        }
    } else {
        throw new UIAError('Could not locate accounts table');
    }
}

function pollUntil(action, options) {
    var attempts = options.attempts;

    while (attempts > 0 && !action()) {
        target.delay(options.delay);
        attempts--;
    }

    if (attempts === 0) {
        throw new UIAError('%0 in %1 secs.'.format(options.errorMessage, options.attempts * options.delay));
    }
}

function outputOf(taskResult) {
    if (typeof taskResult !== 'object' || typeof taskResult.stdout !== 'string') {
        throw new UIAError('Invalid result given.');
    }

    return taskResult.stdout;
}

function firstLineFrom(output) {
    if (output === '' || output === '\n') {
        throw new UIAError('Empty output. Can not take first line.');
    }

    return output.split('\n')[0];
}

function linesFrom(output) {
    if (!output) {
        return [];
    }

    return output.split('\n').slice(0, -1);
}

function countLines(output) {
    return output.split('\n').length - 1;
}

function setSyslogLevelToDebug(processName) {
    if (!processName) {
        processName = 'suggestd';
    }
    exec('/usr/bin/syslog', ['-c', processName, '-d']);
}

function cancelSyslogLevel(processName) {
    if (!processName) {
        processName = 'suggestd';
    }
    exec('/usr/bin/syslog', ['-c', processName, 'off']);
}

// This is still used by AppPrediction tests which need to match multiline strings.
// TODO: vojta: fix the grep syslog to match multiline strings
function readSyslog(processName, regexp) {
    if (!syslogReferenceDate) {
        throw new UIAError('syslogReferenceDate must be set before calling readSyslog');
    }

    return exec('/usr/bin/syslog', [
        '-k', 'Sender', processName,
        '-k', 'Message', 'Req', regexp,
        '-k', 'Time', 'ge', syslogReferenceDate
    ]);
}


// Instead of using `syslog`, we grep the log file because `syslog` only returns
// the log entries from the memory buffer (past 256) and thus we can miss messages.
// <rdar://problem/23207568> Improve UIA tests: read /var/log/system.log
var SYSLOG_PATH = '/var/log/system.log';
var SYSLOG_LINE_REGEXP = /^(.*) iPhone (.*)\[\d+\]/;
function readSyslogWithGrep(processName, regexp) {
    if (!syslogReferenceDate) {
        throw new UIAError('syslogReferenceDate must be set before calling readSyslog');
    }

    var syslogReferenceDateObj = new Date(syslogReferenceDate);
    return linesFrom(outputOf(exec('/usr/bin/grep', ['-E', regexp, SYSLOG_PATH]))).filter(function(line) {
        match = line.match(SYSLOG_LINE_REGEXP);
        if (!match) {
            UIALogger.logWarning('Unexpected output from syslog:\n' + line);
            return false;
        }

        return (match[2] === processName) && (new Date(match[1]) > syslogReferenceDateObj);
    });
}

function waitForSyslog(regexp, options) {
    if (!options.processName) {
        options.processName = 'suggestd';
    }
    pollUntil(function() {
        return readSyslogWithGrep(options.processName, regexp).length > 0;
    }, {attempts: 5, delay: 5, errorMessage: options.errorMessage});
}

function waitForHarvest(subject) {
    UIALogger.logMessage('Waiting for the message to arrive in the inbox.');
    if (!mail.waitUntilPresent(UIAQuery.contains(subject), 30)) {
        throw new UIAError('Mail has not received the message in 30secs.');
    }

    // The following relies on logging added post-Monarch.
//    UIALogger.logMessage('Waiting for Spotlight to send the message to suggestd.');
//    waitForSyslog('Received [0-9]+ items from com.apple.mobilemail', {
//        errorMessage: 'suggestd has not received any message'
//    });

    UIALogger.logMessage('Waiting for suggestd to harvest.');
    waitForSyslog('Cleared out both work queues', {
        errorMessage: 'suggestd has not harvested'
    });

}

function waitForVisible(query, seconds, msg) {
    pollUntil(
        function() { return target.activeApp().exists(query.isVisible()); },
        { attempts: seconds, delay: 1, errorMessage: msg }
    );
}

function searchSpotlightFoundInMail(term) {
    UIALogger.logMessage('Searching Spotlight for FOUND IN MAIL results; term: %0.'.format(term));
    springboard.launch();
    springboard.search(term, null);
    var sectionNames = UIAQuery.Parsec.SEARCH_RESULTS_SECTION_NAMES;
    return UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().below("FOUND IN MAIL").above('UITableViewSectionElement'));
}
