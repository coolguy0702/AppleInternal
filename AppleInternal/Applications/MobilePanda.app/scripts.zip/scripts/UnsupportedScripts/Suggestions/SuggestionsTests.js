load('UIATesting.js');
load('Calendar.js');
load('Contacts.js');
load('Mail.js');
load('Suggestions.js');
load('SpringBoard.js');


UIAUtilities.assert(
    typeof SuggestionsTests === 'undefined',
    'SuggestionsTests has already been defined.'
);


/**
 * @namespace SuggestionsTests
 */
var SuggestionsTests = {

    /**
      * Remove all accounts.
      *
      * When adding accounts with `appleAccountSetupTool`, it adds an account even if it's already
      * there. Thus it's better to remove all accounts first to assure the environment we want.
      *
      * @param {object} args - No arguments
      */
    removeAllAccounts: function removeAllAccounts(args) {
        var result = exec('/usr/local/bin/accounts_tool', ['listAccounts']);
        var output = result.stdout;
        if (output === 'No accounts.\n') {
            UIALogger.logMessage('No account to be removed.');
            return;
        }

        output.split('\n').forEach(function(line) {
            if (line.length > 0 && line.charAt(0) !== ' ') {
                var parts = line.split(' ');
                var accountId = parts[2];
                UIALogger.logMessage('Removing %0 (%1)'.format(parts[1], accountId));
                exec('/usr/local/bin/accounts_tool', ['deleteAccount', accountId], {timeout: 20});
            }
        });
    },

    /**
      * Setup the default iCloud account, assigned to this device.
      * Read the credentials from `springboard.appleID` and `springboard.appleIDPassword`.
      *
      * @param {object} args - No arguments
      */
    setupDefaultIcloudAccount: function setupDefaultIcloudAccount(args) {
        var defaultICloudEmail = springboard.appleID;
        var defaultICloudPassword = springboard.appleIDPassword;

        if (defaultICloudEmail === 'jsmith.purple@gmail.com') {
            throw new UIAError('Default iCloud account not configured. If you are running locally, make sure you run "Add Default Icloud Account" first.');
        }
        UIALogger.logMessage('Using default iCload account %0.'.format(defaultICloudEmail));
        addIcloudAccountFromCLI(defaultICloudEmail, defaultICloudPassword);
    },

    /**
      * Setup iCloud account.
      *
      * @param {object} args - Test arguments
      * @param {string} [args.email="vojta.apple2@icloud.com"] - Required iCloud email address.
      * @param {string} [args.password="cayennE22"] - Required iCloud password.
      */
    setupIcloudAccount: function setupIcloudAccount(args) {
        args = UIAUtilities.defaults(args, {
            email: 'vojta.apple2@icloud.com',
            password: 'cayennE22'
        });

        addIcloudAccountFromCLI(args.email, args.password);
    },


    /**
      * Delete all existing emails, for all accounts, in Inbox, Sent, Trash mailboxes.
      *
      * @param {object} args - No arguments
      */
    deleteAllExistingEmails: function deleteAllExistingEmails(args) {
        deleteAllExistingMessagesIncludingSentAndTrash();
    },

    /**
      * Reset all Suggestions state and set syslog reference date.
      *
      * @param {object} args - No arguments
      */
    resetSuggestions: function resetSuggestions(args) {
        exec('/usr/local/bin/suggest_tool', ['reset'], {timeout: 30});
        exec('/usr/local/bin/suggest_tool', ['setLogLevel', '7']);
        setSyslogLevelToDebug('suggestd');

        // Can't figure out how to clear syslog so we will check only messages since the reference
        // date to avoid reading old logs that happened before this test.
        setSyslogReferenceDate();

        // Enable debug logs for Spotlight code (both in MobileMail and searchd).
        exec('/usr/bin/defaults', ['write', '-g', 'CSLogDetailedActivity', '-bool', 'YES']);
        // Redirect the Spotlight logs into system.log.
        exec('/usr/bin/defaults', ['write', '-g', 'CSLogToConsole', '-bool', 'YES']);

        // Not using `exec`: don't wanna fail if non-zero exit code (the processes might be not-runnning).
        var result = target.performTask('/usr/bin/killall', ['-9', 'MobileMail', 'searchd']);
        UIALogger.logDebug(result);
    },

    /**
      * Wait for MobileMail to receive a message.
      *
      * @targetApps MobileMail
      *
      * @param {object} args - Test arguments
      * @param {string} [args.messageSubject="Testing message"] - Subject of the message to wait for.
      */
    waitForMessageToArriveInInbox: function waitForMessageToArriveInInbox(args) {
        args = UIAUtilities.defaults(args, {
            messageSubject: 'Testing message'
        });

        mail.launch();

        UIALogger.logMessage('Waiting for the message to arrive in the inbox.');
        pollUntil(function() {
            if (mail.exists(UIAQuery.contains(args.messageSubject).isVisible())) {
                return true;
            }
            // Manually force sync.
            mail.dragDownInside('MailMessagesTableView');
            return false
        }, {errorMessage: 'Mail has not received the message', attempts: 6, delay: 5});
    },

    /**
      * Basic cycle test: Mail -> Spotlight -> Suggestions
      *
      * Wait for suggestd receiving an item from Spotlight (syslog) and harvest.
      * Assert the pseudo contact is shown in Contacts.
      *
      * @param {object} args - Test arguments
      * @param {string} [args.senderEmail="vojta.apple2@icloud.com"] - Email to verify "Found in Mail" contact.
      * @param {string} [args.senderPseudoPhoneNumber="(408) 123-1234"] - Phone number to verify "Found in Mail" contact.
      */
    harvestContact: function harvestContact(args) {
        args = UIAUtilities.defaults(args, {
            senderEmail: 'vojta.apple2@icloud.com',
            senderPseudoPhoneNumber: '(408) 123-1234'
        });

        UIALogger.logMessage('Waiting for Spotlight to send the message to suggestd.');
        waitForSyslog('Received [0-9]+ items from com.apple.mobilemail', {
            errorMessage: 'suggestd has not received any message'
        });

        UIALogger.logMessage('Waiting for suggestd to harvest.');
        // TODO: vojta: better to watch for "0 remaining", if we can test on internal build.
        waitForSyslog('Processed [0-9]+ items from high priority queue', {
            errorMessage: 'suggestd has not harvested'
        });

        // Let's open Contacts and make sure the "found in mail" contact can be found.
        // `contacts` is defined in `Contacts.js`.
        contacts.launch();
        contacts.search('Tester'); // Search and click the first result.

        contacts.assertVisible(
            UIAQuery.query('phone (found in Mail)'),
            'Phone (found in Mail) label not displayed.'
        );

        contacts.assertVisible(
            UIAQuery.query(args.senderPseudoPhoneNumber),
            'Phone detail not displayed.'
        );

        contacts.assertVisible(
            UIAQuery.query(args.senderEmail),
            'Email detail not displayed.'
        );
    },

    /**
      * Basic cycle test: Mail -> Spotlight -> Suggestions -> Calendar
      *
      * @targetApps MobileMail, MobileCal
      */
    harvestFoundInMailEvent: function harvestFoundInMailEvent(args) {

        /* TODO: if we had an on-device IMAP server, it might be straightforward
         * to simulate sending a new email instead of adding an account that
         * already has the email present.
         */

        var CREDENTIALS1 = {address: 'sg.testautomation1@icloud.com', password: 'iU4wloya'};
        var CREDENTIALS2 = {address: 'sg.testautomation2@icloud.com', password: '7HVcE187'};
        var COUNT_SOLUNA_EMAILS = 'SELECT "email:", COUNT(*) FROM entity WHERE entityType = 5 AND author LIKE "%Soluna%"';
        var CALENDAR_EVENT_TITLE = 'Reservation: 272 Soluna Cafe & Lounge';
        var CALENDAR_EVENT_DATE1 = new Date('December 8, 2015 19:00');
        var CALENDAR_EVENT_DATE2 = new Date('December 8, 2015 19:15');
        var CALENDAR_NAME = 'SUGGESTIONS TEST AUTOMATION';

        removeIcloudMailAccount(CREDENTIALS1.address);
        removeIcloudMailAccount(CREDENTIALS2.address);

        // Clear preexisting curated events
        UIALogger.logMessage('Trying to delete calendar.');
        try {
            calendar.deleteCalendar('iCloud', CALENDAR_NAME);
        } catch (e) {}
        UIALogger.logMessage('Adding calendar.');
        calendar.addCalendar('iCloud', CALENDAR_NAME, {});

        // Set the default calendar to the one we just created.
        settings.chooseSetting( ['Mail, Contacts, Calendars', 'Default Calendar', CALENDAR_NAME] );

        // Clear out the Suggestions database.
        resetSuggestions();

        // Add the first mail account, which should lead to harvesting of the event confirmation
        addIcloudMailAccount(CREDENTIALS1);

        // Navigate to the email of interest in the newly-added account
        mail.verifyEmailExists({
            subject: 'Your Reservation Confirmation for 272 Soluna Cafe & Lounge',
            account: CREDENTIALS1.address,
            folder: 'Inbox',
            timeout: 60,
        });

        UIALogger.logMessage('Waiting for confirmation email harvesting to complete.');
        forceEmailHarvest(function() {
            queryOutput = outputOf(exec('/usr/local/bin/suggest_tool', [ 'runQueryOnEntities', COUNT_SOLUNA_EMAILS ]));
            return queryOutput.indexOf("email:  |  1  |") > -1;
        }, {attempts: 10, delay: 3, errorMessage: 'Failed to locate exactly one email entity in db.'});

        // Search for the event in the calendar and confirm it.  (Confirmation is necessary in order
        // to enable the "edit" view for the purpose of event validation.)
        calendar.searchForEvent(CALENDAR_EVENT_TITLE, CALENDAR_EVENT_DATE1);
        calendar.tap(UIAQuery.buttons('Add To Calendar'));

        // Locate the event in the calendar
        calendar.verifyEventExists(CALENDAR_EVENT_TITLE, CALENDAR_EVENT_DATE1,
            { StartDate: CALENDAR_EVENT_DATE1, },
            {});

        // Add the second mail account, which should lead to harvesting of an update email
        addIcloudMailAccount(CREDENTIALS2);

        // Navigate to the email of interest in the newly-added account
        mail.verifyEmailExists({
            subject: 'Your 272 Soluna Cafe & Lounge Reservation Change',
            account: CREDENTIALS2.address,
            folder: 'Inbox',
            timeout: 60,
        });

        UIALogger.logMessage('Waiting for mail harvesting to complete.');
        forceEmailHarvest(function() {
            queryOutput = outputOf(exec('/usr/local/bin/suggest_tool', [ 'runQueryOnEntities', COUNT_SOLUNA_EMAILS ]));
            return queryOutput.indexOf("email:  |  2  |") > -1;
        }, {attempts: 10, delay: 3, errorMessage: 'Failed to locate exactly two email entities in db.'});

        // The preexisting event should no longer be present at the original time, because we
        // updated it.
        var foundPreexistingEvent = true;
        try {
            calendar.verifyEventExists(CALENDAR_EVENT_TITLE, CALENDAR_EVENT_DATE1,
                { StartDate: CALENDAR_EVENT_DATE1, }, {});
        } catch (e) {
            if (e instanceof UIAError) {
                foundPreexistingEvent = false;
            }
        }
        if (foundPreexistingEvent) {
            throw new UIAError('Preexisting event was not correctly updated.');
        }

        // Locate the updated event in the calendar
        calendar.verifyEventExists(CALENDAR_EVENT_TITLE, CALENDAR_EVENT_DATE2,
            { StartDate: CALENDAR_EVENT_DATE2, },
            {});
    },

    /**
      * Basic cycle test: Mail -> Spotlight -> Suggestions -> Spotlight
      *
      * @targetApps MobileMail, Spotlight
      *
      * @param {object} args - Test arguments
      * @param {string} [args.iCloudEmail1="cayenne.test01@icloud.com"] - Required iCloud email address which the email will be sent to.
      * @param {string} [args.iCloudPassword1="Cayenne01"] - Required iCloud password.
      * @param {string} [args.iCloudEmail2="cayenne.test02@icloud.com"] - Required iCloud email address which the email will be sent from.
      * @param {string} [args.iCloudPassword2="Cayenne02"] - Required iCloud password.
      */
    harvestContactToSpotlight: function(args) {
        args = UIAUtilities.defaults(args, {
            iCloudEmail1: 'cayenne.test01@icloud.com',
            iCloudPassword1: 'Cayenne01',
            iCloudEmail2: 'cayenne.test02@icloud.com',
            iCloudPassword2: 'Cayenne02'
        });

        // Set up two iCloud accounts.
        addIcloudMailAccount({address: args.iCloudEmail1, password: args.iCloudPassword1});
        addIcloudMailAccount({address: args.iCloudEmail2, password: args.iCloudPassword2});

        // Clean up any cruft from previous runs.
        deleteAllExistingMessagesIncludingSentAndTrash();
        resetSuggestions();

        var foundInMail;

        // PART 1: Pseudo contact with detail from single messsage.
        // Checkpoint syslog.
        setSyslogReferenceDate();
        composeAndSendEmail({
            sender: args.iCloudEmail2,
            recipient: args.iCloudEmail1,
            subject: 'Spotlight Test 1',
            text: 'Hello,\nHave a nice day.\n--\nJoe Cayenne\n(408) 555-1234'
        });
        waitForHarvest('Spotlight Test 1');
        // Search in Spotlight.
        foundInMail = searchSpotlightFoundInMail('Cayenne');
        // Results seem to come in asynchronously or something, so we wait for them.
        waitForVisible(foundInMail, 3, 'No FOUND IN MAIL results');
        // Go to the detail and assert correct phone number was dissected.
        springboard.tap(foundInMail);
        waitForVisible(UIAQuery.query('phone (found in Mail)'), 3, 'FOUND IN MAIL Detail label not visible');
        waitForVisible(UIAQuery.query('(408) 555-1234'), 3, 'FOUND IN MAIL Detail phone number not visible');

        // PART 2: Pseudo contact with details from multiple messsages.
        // Checkpoint syslog.
        setSyslogReferenceDate();
        composeAndSendEmail({
            sender: args.iCloudEmail2,
            recipient: args.iCloudEmail1,
            subject: 'Spotlight Test 2',
          text: 'Hey,\nCheck out my new number.\n--\nJoe Cayenne\n(408) 555-4321'
        });
        waitForHarvest('Spotlight Test 2');
        // Search in Spotlight.
        foundInMail = searchSpotlightFoundInMail('Cayenne');
        // Results seem to come in asynchronously or something, so we wait for them.
        waitForVisible(foundInMail, 3, 'No FOUND IN MAIL results');
        // Go to the detail and assert correct phone number was dissected.
        springboard.tap(foundInMail);
        waitForVisible(UIAQuery.query('phone (found in Mail)'), 3, 'FOUND IN MAIL Detail label not visible');
        waitForVisible(UIAQuery.query('(408) 555-1234'), 3, 'FOUND IN MAIL Detail phone number not visible (original)');
        waitForVisible(UIAQuery.query('(408) 555-4321'), 3, 'FOUND IN MAIL Detail phone number not visible (updated)');

        // PART 3: Rejected pseudo contact.
        waitForVisible(UIAQuery.query('Ignore Contact'), 3, 'Ignore Contact option not visible');
        contacts.tap('Ignore Contact');
        contacts.tap('Ignore');
        // Search in Spotlight.
        foundInMail = searchSpotlightFoundInMail('Cayenne');
        // TODO vyrros: Because of the asyncronous thing, need a better way to be sure results won't pop in later.
        UIAUtilities.assert(!springboard.exists(foundInMail.isVisible()), 'Some FOUND IN MAIL results after rejecting contact');
    },

};
