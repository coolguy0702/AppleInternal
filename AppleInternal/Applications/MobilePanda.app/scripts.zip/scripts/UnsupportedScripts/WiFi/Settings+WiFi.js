load("UIAApp.js")
load("SpringBoard.js")

if (typeof settings === 'undefined') {
    /**
        @namespace
        @augments UIAApp
    */
    var settings = target.appWithBundleID('com.apple.Preferences');
}

settings.launch()
/**
 * Join a WiFi network
 * @param {String} network - Name of the network to join
 * @param {String} password - password(if any) of the secured network to join
 * @param {String} hidden - hidden or broadcast (future profile support)
 * @param {String} Security - WEP, WPA, WPA2, WPA Enterprise, WPA2 Enterprise, None
 * @param {String} username - used for enterprise.
 * @param {String} isWapi - Used to differentiate CH/A devices
 */

settings.joinWiFiNetwork = function joinWiFiNetwork(network, password, networktype, security, username, isWapi) {
    this.returnToTopLevel()
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    target.delay(12)
    if(networktype == "hidden"){
       this.tap("Other…")
       this.typeString(network);
       if (security == "None"){
            UIALogger.logMessage("Hidden Open network");
        }
        else if (security == "WEP"){
            UIALogger.logMessage("Hidden WEP network");
            this.tap("None");
            this.tap("WEP");
            this.tap("back-nav-button");
            this.tap("Password");
            this.typeString(password);
        }
        else if (security == "WPA"){
            UIALogger.logMessage("Hidden WPA network");
            this.tap("None");
            this.tap("WPA");
            this.tap("back-nav-button");
            this.tap("Password");
            this.typeString(password);
        }
        else if (security == "WPA2"){
            UIALogger.logMessage("Hidden WPA2 network");
            this.tap("None");
            this.tap("WPA2");
            this.tap("back-nav-button");
            this.tap("Password");
            this.typeString(password);
        }
        else if (security == "WPA Enterprise"){
            UIALogger.logMessage("Hidden WPA enterprise network");
            this.tap("None");
            this.tap("WPA Enterprise");
            this.tap("back-nav-button");
            this.typeString(username);
            settings.tap("return");
            this.typeString(password);
        }
        else if (security == "WPA2 Enterprise"){
            UIALogger.logMessage("Hidden WPA enterprise network");
            this.tap("None");
            this.tap("WPA2 Enterprise");
            this.tap("back-nav-button");
            this.typeString(username);
            settings.tap("return");
            this.typeString(password);
        }
        else {
            throw new UIAError("Unknown security type");
        }
        this.tap("Join");
    }
    else {
        if (typeof(password) == "undefined" || password == ""){
             UIALogger.logMessage("No password provided");
             this.tap(network)
        }
        else {
            if (typeof(username) =="undefined" || username == ""){
                this.tap(network)
                this.tap("Password");
                this.typeString(password);
                this.tap("Join")
            }
            else {
                this.tap(network)
                this.typeString(username);
                this.tap(UIAQuery.secureTextFields("Password").atIndex(2));
                this.typeString(password);
                target.delay(1)
                this.tap("Join")

            }
        }
    }

    var alertsHandled = []
    var postJoinHandler = function() {
        var app = target.activeApp();
        if (app.exists(UIAQuery.contains("Incorrect")) || app.exists(UIAQuery.contains("Unable to join"))) {
            UIALogger.logMessage("Tapping Dismiss...");
            app.tap(UIAQuery.alerts().andThen('cancel-button'));
            alertsHandled.push("Dismissed alert");
            return true;
        }
        else if (app.exists(UIAQuery.contains("Could not scan for wireless networks"))) {
            UIALogger.logMessage("Tapping Dismiss...");
            app.tap(UIAQuery.alerts().andThen('cancel-button'));
        }
        return false;
    };

    this.withAlertHandler(postJoinHandler, function() {
        for (var i=0; i < 10; i++) {
            UIALogger.logMessage("Waiting for alerts...");
            target.delay(8);
            var length = alertsHandled.length;
            if (UIAAlertManager.handleAlerts()) {
                if (alertsHandled.length !== length) {
                    UIALogger.logMessage("Handled alert: %0".format( alertsHandled[alertsHandled.length-1] ));
                    this.tap("Cancel");
                    throw new UIAError("Incorrect Password. Failed to join Network.");
                    break;
                } else {
                    UIALogger.logMessage("Handled alert but not one we were looking for");
                    this.returnToTopLevel();
                }
            } else {
                if (springboard.exists(UIAQuery.contains("Wi-Fi bars")) || springboard.exists(UIAQuery.contains("WLAN bars"))){
                    UIALogger.logMessage("Successfully joined the network");
                    break;
                }
                else {
                    UIALogger.logMessage("No alert handled");
                    if (this.exists(UIAQuery.contains("Certificate"))) {
                        UIALogger.logMessage("Tapping Trust...");
                        this.tap("Trust");
                    }
                }
            }
        }
    });
    if (springboard.exists(UIAQuery.contains("Wi-Fi bars")) || springboard.exists(UIAQuery.contains("WLAN bars"))){
        UIALogger.logMessage("Successfully joined the network");
    }
    else {
        throw new UIAError("Failed to join Network.");
    }
}

settings.joinWiFiNetworkProfile = function joinWiFiNetworkProfile(network, rootcert, networktype, security, username, isWapi) {
    
this.returnToTopLevel()
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    target.delay(12)
    
    if (networktype == 'WAPI enterprise') {
            UIALogger.logMessage("WAPI enterprise");
            this.tap(network);
            this.tap("Root Certificate");
            target.delay(1);
            this.tap(rootcert);
            target.delay(1);
            this.tap("back-nav-button");
            target.delay(1);
            this.tap("WAPI Identity");
            target.delay(1);
            this.tap(username);
            target.delay(1);
            this.tap("back-nav-button");
            target.delay(1);
            this.tap("Join");
        }
    else if (networktype == 'enterprise') {
            UIALogger.logMessage("enterprise");
            this.tap("Root Certificate");
            target.delay(1);
            this.tap(rootcert);
            target.delay(1);
            this.tap("back-nav-button");
            target.delay(1);
            this.tap("Identity");
            target.delay(1);
            this.tap(username);
            target.delay(1);
            this.tap("back-nav-button");
            target.delay(1);
            this.tap("Join");
         }
    
    
    //tien
    var alertsHandled = []
    var postJoinHandler = function() {
        var app = target.activeApp();
        if (app.exists(UIAQuery.contains("Incorrect")) || app.exists(UIAQuery.contains("Unable to join"))) {
            UIALogger.logMessage("Tapping Dismiss...");
            app.tap(UIAQuery.alerts().andThen('cancel-button'));
            alertsHandled.push("Dismissed alert");
            return true;
        }
        else if (app.exists(UIAQuery.contains("Could not scan for wireless networks"))) {
            UIALogger.logMessage("Tapping Dismiss...");
            app.tap(UIAQuery.alerts().andThen('cancel-button'));
        }
        return false;
    };

    this.withAlertHandler(postJoinHandler, function() {
        for (var i=0; i < 10; i++) {
            UIALogger.logMessage("Waiting for alerts...");
            target.delay(8);
            var length = alertsHandled.length;
            if (UIAAlertManager.handleAlerts()) {
                if (alertsHandled.length !== length) {
                    UIALogger.logMessage("Handled alert: %0".format( alertsHandled[alertsHandled.length-1] ));
                    this.tap("Cancel");
                    throw new UIAError("Incorrect Password. Failed to join Network.");
                    break;
                } else {
                    UIALogger.logMessage("Handled alert but not one we were looking for");
                    this.returnToTopLevel();
                }
            } else {
                if (springboard.exists(UIAQuery.contains("Wi-Fi bars")) || springboard.exists(UIAQuery.contains("WLAN bars"))){
                    UIALogger.logMessage("Successfully joined the network");
                    break;
                }
                else {
                    UIALogger.logMessage("No alert handled");
                    if (this.exists(UIAQuery.contains("Certificate"))) {
                        UIALogger.logMessage("Tapping Trust...");
                        this.tap("Trust");
                    }
                }
            }
        }
    });
    if (springboard.exists(UIAQuery.contains("Wi-Fi bars")) || springboard.exists(UIAQuery.contains("WLAN bars"))){
        UIALogger.logMessage("Successfully joined the network");
    }
    else {
        throw new UIAError("Failed to join Network.");
    }
}

settings.installProfile = function installProfile(profileName) {
//TO BE IMPLEMENTED
}


settings.deleteProfile = function deleteProfile(profileName) {
    this.returnToTopLevel()
    this.tap("General");
    target.delay(2);
    if (settings.exists(UIAQuery.contains('Profiles'))){
        this.tap("Profiles");
    }
    else if (settings.exists(UIAQuery.contains('Profile'))){
        this.tap("Profile")
    }
    target.delay(2);
    
    this.tap(profileName);
    println (profileName);

    var app = target.activeApp();
    app.handlingAlertsInline(UIAQuery.alerts().andThen('Delete'), function() {
        app.tap("Delete Profile");
        app.tap(UIAQuery.PROMPT_CONTAINER.andThen(UIAQuery.buttons('Delete'))); 
    });

    // var noticeAlertQuery = UIAQuery.alerts().andThen(UIAQuery.contains('Are you sure'));
    // app.handlingAlertsInline(noticeAlertQuery, function() {
    //     app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Delete')));
    // });
    
}

settings.forgetWiFiNetwork = function forgetWiFiNetwork(ssid,isWapi) {
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }

    this.tap(UIAQuery.buttons().contains(ssid));
    this.tap("Forget This Network");
    target.delay(2)
    
    //forget alert handler
    var alertsHandled = []
    var postForgetHandler = function() {
        var app = target.activeApp();
        target.delay(1)
        if (app.exists(UIAQuery.contains("Forget"))) {
            UIALogger.logMessage("Forget pop up shows up...");
            app.tap(UIAQuery.alerts().andThen('default-button'));
            alertsHandled.push("Forget network");
            return true;
        }
        else{
            throw new UIAError("Forget Popup did not show up");
        }
        return false;
    };

    this.withAlertHandler(postForgetHandler, function() {
        
        if (UIAAlertManager.handleAlerts()) {
            if (alertsHandled) {
                UIALogger.logMessage("Forget alert handeled: %0".format( alertsHandled[alertsHandled.length-1] ));
                UIALogger.logMessage("Successfully forget the network");
                flag = 1
                this.returnToTopLevel()
            } 
            
        } else {
                UIALogger.logMessage("No alert handled");
    }
        
    });

}




/**
 * Read the value of current ipaddress (when open up the info menu from the associated wifi network)
 * @param {String} ssid - name of the associated wifi network
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.currentIp = function currentIp(ssid,isWapi) {
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    this.tap(UIAQuery.buttons().contains(ssid));
    var wifiAddr = UIAQuery.contains('Address');
    var wifiIpAddress = settings.inspect(UIAQuery.textFields('IP Address'));
    println (wifiIpAddress.value);
    return wifiIpAddress;
}


/**
 * Read the value of current subnet (when open up the info menu from the associated wifi network)
 * @param {String} ssid - name of the associated wifi network
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.currentMask = function currentMask(ssid,isWapi) {
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    this.tap(UIAQuery.buttons().contains(ssid));
    //var wifiMask = UIAQuery.contains('Mask');
    var wifiIpMask = settings.inspect(UIAQuery.textFields('Subnet Mask'));
    println (wifiIpMask.value);
    return wifiIpMask;
}


/**
 * Read the value of current Router (when open up the info menu from the associated wifi network)
 * @param {String} ssid - name of the associated wifi network
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.currentRouter = function currentRouter(ssid,isWapi) {
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    this.tap(UIAQuery.buttons().contains(ssid));
    //var wifiRouter = UIAQuery.contains('Router');
    var wifiIpRouter = settings.inspect(UIAQuery.textFields('Router'));
    println (wifiIpRouter.value);
    return wifiIpRouter;
}


/**
 * Read the WiFi MAC address under General-About  
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.readWiFiMac = function readWiFiMac(isWapi) {
    settings.launch()
    this.returnToTopLevel()
    this.tap("General");
    target.delay(2)
    this.tap("About");

    //var wifiAddrQuery = UIAQuery.contains('Wi-Fi Address');
    //var wifiAddress = settings.inspect(wifiAddrQuery.siblings().last()).label;
    if(isWapi == "True" || isWapi == 1){
        var wifiAddress = settings.inspect(UIAQuery.tableCells('WLAN Address')).value
    }
    else {
        var wifiAddress = settings.inspect(UIAQuery.tableCells('Wi-Fi Address')).value
    }
    //var wifiAddress = settings.inspect(UIAQuery.tableCells('Wi-Fi Address')).value
    println (wifiAddress);
    return wifiAddress;
}

/**
 * Read the status of WiFi under Settings (expected value: associated-ssid, Not Connected, Off)
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.verifyWiFiConnected = function verifyWiFiConnected(isWapi) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        var status = settings.inspect(UIAQuery.tableCells('WLAN')).value
    }
    else {
        var status = settings.inspect(UIAQuery.tableCells('Wi-Fi')).value
    }
    //var status = settings.inspect(UIAQuery.tableCells('Wi-Fi')).value
    println (status)
    return status;

}

/**
 * Check to see an ssid shows up in preference scan list
 * @param {String} ssid - ssid to check for in list
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.verifyAPinScanList = function verifyAPinScanList(ssid,isWapi) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    target.delay(5)
    var scanresult = settings.exists(UIAQuery.staticTexts(ssid))
    println (scanresult)
    return scanresult
}


/**
 * Check to see if a recommendation shows up under more information for a current network
 * @param {String} network - Name of the current network.
 * @param {String} recommendation - Expected Health monitor recommendation for the network type
 * @param {String} sub recommendation - Expected recommendation for the network type shown under the network name
 * @param {String} isWapi - Used to differentiate CH/A devices
 */
settings.verifyHealthMonitorRecommendation = function verifyHealthMonitorRecommendation(ssid,recommendation,subrecommendation,isWapi) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
    }
    else {
        this.tap("Wi-Fi");
    }
    if (settings.exists(UIAQuery.tableCells().contains(ssid).andThen(UIAQuery.staticTexts(subrecommendation)))){
        UIALogger.logMessage("The sub recommendation under the current network does exist");
    }
    else{
        UIALogger.logMessage("The sub recommendation under the current network does not exist");
        throw new UIAError("The sub recommendation under the current network does not exist");
    }
    this.tap(UIAQuery.tableCells().contains(ssid));
    if (settings.exists(UIAQuery.tableCells().andThen(UIAQuery.staticTexts(recommendation)))){
        var recommendationResult = settings.inspect(UIAQuery.tableCells().andThen(UIAQuery.staticTexts(recommendation))).label
        UIALogger.logMessage("The recommendation does exist");
        println (recommendationResult)
        return recommendationResult;
    }
    else{
        UIALogger.logMessage("The recommendation does not exist");
        throw new UIAError("The recommendation does not exist");
        
        
    }
    return false;
    
}

/**
 * Changes the state of WiFi
 * @param {Bool} state - Put WiFi in this state. 1 or 0
 * @param {String} isWapi - Used to differentiate CH/A devices
 */

settings.changeWiFiState = function changeWiFiState(state, isWapi) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    if(isWapi == "True" || isWapi == 1){
        this.tap("WLAN");
        this.setControl(UIAQuery.switches("WLAN"), state);
    }
    else {
        this.tap("Wi-Fi");
        this.setControl(UIAQuery.switches("Wi-Fi"), state);
    }
}

/**
 * Changes the state of Airplane Mode
 * @param {Bool} state - Put Airplane Mode in this state. 1 or 0
 */

settings.changeAirplaneModeState = function changeAirplaneModeState(state) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    this.setControl(UIAQuery.switches("Airplane Mode"), state);
}

/**
 * Changes the state of Personal Hotspot (tethering)
 * @param {Bool} state - Put PH in this state. 1 or 0
 */

settings.changePersonalHotspotState = function changePersonalHotspotState(state) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    this.tap("Personal Hotspot");
    var phTapHandler = function() {
        var app = target.activeApp();
        if (app.exists(UIAQuery.contains("is Off")) || UIAQuery.contains("are Off")) {
            UIALogger.logMessage("Tapping Turn on ...");
            app.tap(UIAQuery.alerts().andThen(UIAQuery.contains('Turn on')));
            return true;
        }
    }
    this.withAlertHandler(phTapHandler, function() {
        this.setControl(UIAQuery.switches("Personal Hotspot"), state);
    });
}

/**
 * Changes the password of Personal Hotspot (tethering)
 * @param {String} password - Password to be used for PH
 */

settings.changePersonalHotspotPassword = function changePersonalHotspotPassword(password) {
    var waiter = UIAWaiter.withPredicate('ApplicationStateChanged', "bundleID = 'com.apple.Preferences' && state = 'Suspended'");
    springboard.launch();
    waiter.wait(3);
    settings.launch();
    this.returnToTopLevel()
    this.tap("Personal Hotspot");
    this.tap("Wi-Fi Password");
    this.tap("Clear text");
    this.typeString(password);
    this.tap("Done");
}


/**
 * Connect to captive network (Open system)
 * @param {String} password - To be implemented
 */

settings.setCaptivePassword = function setCaptivePassword() {

    this.tap("Wi-Fi")
    var websheet = target.appWithBundleID("com.apple.WebSheet");
    /*websheet.tap(UIAQuery.secureTextFields("").atIndex(9223372036854775807));
    websheet.typeString(password)*/
    this.delay(8)
    websheet.tap("LOGIN");
    this.delay(2)
    websheet.tap("Done")
    this.delay(1)
    this.returnToTopLevel()
}

