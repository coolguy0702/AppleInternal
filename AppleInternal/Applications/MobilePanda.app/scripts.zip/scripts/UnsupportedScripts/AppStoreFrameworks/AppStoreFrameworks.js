load('UIATesting.js');
load('UIAUtility.js');
load('UIAApp.js');
load('SpringBoard.js');
load('SpringBoardTests.js');
load('AppStoreFrameworksAppListConstants.js')

UIAUtilities.assert(
    typeof ASFramework === 'undefined',
    'ASFramework has already been defined.'
);

/**
 * @namespace ASFramework
 */
var ASFramework = {};

/**
 * Get the list of apps from its name
 */
ASFramework.appsForListName = function appsForListName(listName) {
    if (listName == 'Common30') {
        return CURATED30_APPS;
    } else if (listName == 'Big2002') {
        return BIG2002_APPS;
    } else {
        UIAUtilities.assert(false, 'App list \'' + listName + '\' does not exist.');
    }
}

/**
 * Handle all alerts by using "cancel" or "default" actions on each, until no more exist
 * You must use this inside a 'app.handlingAlertsInline()' function
 * @param {object} app - The UIAApp that the alerts will be in.
 */
ASFramework.clearAlerts = function clearAlerts(app) {
    while (app.waitUntilPresent(UIAQuery.alerts(), 3)) {
        UIALogger.logMessage('\n\n');

        try {
            UIALogger.logMessage('alert label: ' + app.inspectElementKey(UIAQuery.alerts(), 'label'));
        } catch (e) {
            UIALogger.logMessage('no alert label found\n');
        }

        var success = false;

        try {
            UIALogger.logMessage('\ncancel button: ' + app.inspectElementKey(UIAQuery.alerts().andThen(UIAQuery.buttons(UIAQuery.CANCEL_BUTTON)), 'label'));
        } catch (e) {
            UIALogger.logMessage('did not find cancel button label: ' + e.toString());
        }

        try {
            app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons(UIAQuery.CANCEL_BUTTON)));
            success = true;
        } catch (e) {
            UIALogger.logMessage('could not tap cancel button: ' + e.toString());
            success = false;
        }

        if (success) {
            continue;
        }

        try {
            app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons(UIAQuery.DEFAULT_BUTTON)));
        } catch (e) {
            UIALogger.logMessage('count not tap default button: ' + e.toString());
        }

        UIALogger.logMessage('\n\n');
    }
}

/**
 * Authenticate with a given username and password
 *
 * @param {object} args - Test arguments
 * @param {string} username - The username to log in with
 * @param {string} password - The password to log in with
 */
ASFramework.authenticate = function authenticate(username, password) {
    let authResponse = target.performTask('/usr/local/bin/asclient', ['authenticate', username, password], 60);
    UIALogger.logMessage(JSON.stringify(authResponse, null, 4));
}

/**
 * Change the password settings to never ask when downloading free apps
 * Operates on the currently logged-in account
 *
 * @param {object} args - Test arguments
 * @param {string} password - The password of the current account
 */
ASFramework.disableFreePassword = function disableFreePassword(password) {
    let pwResponse = target.performTask('/usr/local/bin/asclient', ['pwsettings', '--free', 'never', '--password', password], 60);
    UIALogger.logMessage(JSON.stringify(pwResponse, null, 4));
}

/**
 * Install the apps described by an array of AppInfo objects
 *
 * @param {object} apps - The array of AppInfo objects to install
 */
ASFramework.installApps = function installApps(apps) {
    ASFramework.installApps(apps, '0');
}

/**
 * Install the apps described by an array of AppInfo objects
 *
 * @param {object} apps - The array of AppInfo objects to install
 * @param {object} downgradeOffset - The number of versions back the apps will be installed at
 * @param {object} processesToMonitor - Array of the names of the processes to gather memory stats about
 */
 ASFramework.installApps = function installApps(apps, downgradeOffset, processesToMonitor) {
     let batchSize = 20;
     let batches = [];
     for (let i = 0; i < apps.length; i += batchSize) {
         batches.push(apps.slice(i, i + batchSize));
     }

     var memoryStats = {};
     let batchNum = 0;

     for (batch of batches) {
         springboard.handlingAlertsInline(UIAQuery.alerts(), function() {
             let installResponse = target.performTask('/usr/local/bin/asclient', ['bulkPurchase'].concat(batch.map(function(appInfo) { return appInfo.adamId.toString() })).concat(['--batchSize', batchSize.toString(), '--downgradeOffset', downgradeOffset, '--memoryStats'].concat(processesToMonitor)), 60 * batchSize * 3);
             UIALogger.logMessage('\n\n\n' + JSON.stringify(installResponse, null, 4));

             UIAUtilities.assert(!installResponse.timedOut, 'Installing apps timed out.');
             UIAUtilities.assert(installResponse.stdout.length > 0, 'Error: No output when installing apps.');

             let lines = installResponse.stdout.split('\n');
             let statsRegex = /([\w\.]+) Min: (\d+)K Max: (\d+)K Average: (\d+)K/;

             for (var i = lines.indexOf('Memory Stats') + 1; i < lines.length; i++) {
                 let matched = lines[i].match(statsRegex);

                 if (matched == null || matched.length < 2) {
                     continue;
                 }

                 let processName = matched[1];
                 let batchMinMemory = parseInt(matched[2]);
                 let batchMaxMemory = parseInt(matched[3]);
                 let batchAvgMemory = parseInt(matched[4]);

                 if (!memoryStats.hasOwnProperty(processName)) {
                     var processStats = {
                         'MinMemory': batchMinMemory,
                         'MaxMemory': batchMaxMemory,
                         'AvgMemories': [batchAvgMemory]
                     };
                     memoryStats[processName] = processStats;
                 } else {
                     var processStats = memoryStats[processName];

                     if (batchMinMemory < processStats['MinMemory']) {
                         processStats['MinMemory'] = batchMinMemory;
                     }

                     if (batchMaxMemory > processStats['MaxMemory']) {
                         processStats['MaxMemory'] = batchMaxMemory;
                     }

                     processStats['AvgMemories'].push(batchAvgMemory);
                 }
             }

             ASFramework.clearAlerts(springboard);
         });

         batchNum++;
     }

     var memoryStatsResult = {};
     for (processName of Object.keys(memoryStats)) {
         processStats = memoryStats[processName];
         let avgMemories = processStats['AvgMemories'];
         let avgMemory = avgMemories.reduce(function(a, b) { return a + b; }, 0) / avgMemories.length;

         memoryStatsResult[processName] = {
             'Min': processStats['MinMemory'],
             'Max': processStats['MaxMemory'],
             'Avg': avgMemory
         };
     }

     for (processName of processesToMonitor) {
         if (!memoryStatsResult.hasOwnProperty(processName)) {
             memoryStatsResult[processName] = 'Not Found'
         }
     }

     UIALogger.logTAResults({
         'Memory Stats': memoryStatsResult
     });
 }

/**
 * Verify that a list of apps can be launched
 *
 * @param {object} apps - The array of AppInfo objects to verify
 */
ASFramework.verifyAppsLaunch = function verifyAppsLaunch(apps) {
    let bundleIdLinePrefix = 'BundleID: ';
    var results = {};
    var allSuccessful = true;

    springboard.handlingAlertsInline(UIAQuery.alerts(), function() {
        for (let appInfo of apps) {
            let bundleId = appInfo.bundleId;

            let launchOutput = target.performTask('/usr/local/bin/LaunchApp', [bundleId], 30);
            target.performTask('/bin/sleep', ['5'], 7); // UIAutomation needs this pause or it sometimes has errors finding the app
            if (launchOutput.stdout.startsWith('Launched')) {
                results[bundleId] = 'Launched';
            } else {
                results[bundleId] = 'Failed Launch';
                allSuccessful = false;
                UIALogger.logError('%0 failed to launch, output: %1'.format(bundleId, launchOutput));
            }

            ASFramework.clearAlerts(springboard);
        }
    });

    UIALogger.logTAResults({ 'App Launch Results': results });

    UIAUtilities.assert(allSuccessful, 'One or more apps failed to launch. See logs.');
}

/**
 * Verify that the list of apps has the expected files (receipt and metadata)
 *
 * @param {object} apps - The array of AppInfo objects to verify
 */
ASFramework.verifyAppsFiles = function verifyAppsFiles(apps) {
    var results = {};
    var allSuccessful = true;

    for (let bundleId of apps.map(function(appInfo) { return appInfo.bundleId })) {
        results[bundleId] = {};

        let ascVerifyResult = target.performTask('/usr/local/bin/asclient', ['verify', bundleId], 30 * 1);
        if (ascVerifyResult.stderr.length > 0) {
            UIALogger.logError('Error when verifying %0 files: %1'.format(bundleId, ascVerifyResult.stderr));
            results[bundleId] = 'Error: %0'.format(ascVerifyResult.stderr);
            allSuccessful = false;
        } else if (ascVerifyResult.stdout.trim().endsWith('All verified')) {
            UIALogger.logMessage('%0 files verified: %1'.format(bundleId, ascVerifyResult.stdout));
            results[bundleId] = 'Verified';
        } else {
            UIALogger.logError('%0 files not verified: %1'.format(bundleId, ascVerifyResult.stdout));
            results[bundleId] = 'Not verified: %0'.format(ascVerifyResult.stdout);
            allSuccessful = false;
        }
    }

    UIALogger.logTAResults({ 'App Verification Results': results });

    UIAUtilities.assert(allSuccessful, 'One or more apps had invalid files. See logs.');
}

/**
 * Refresh update statuses and begin a manual "Update All"
 */
ASFramework.manualUpdateApps = function manualUpdateApps() {
    let initialUpdateReloadOutput = target.performTask('/usr/local/bin/asclient', ['updates', 'reload'], 60 * 5);
    UIALogger.logMessage('Initial update reload output: \n%0'.format(initialUpdateReloadOutput.stdout));

    target.performTask('/usr/local/bin/asclient', ['updates', 'updateAll'], 60 * 30);
    target.performTask('/bin/sleep', ['10'], 7);
    var jobOutput = '';
    do {
        jobTaskResult = target.performTask('/usr/local/bin/asclient', ['jobs', 'list'], 5);
        if ((jobTaskResult.stderr.length > 0) || (jobTaskResult.stdout.length < 1)) {
            break;
        }
        jobOutput = jobTaskResult.stdout;
        UIALogger.logMessage('jobs: \n%0'.format(jobOutput));
        target.performTask('/bin/sleep', ['10'], 10);
    } while (!jobOutput.trim().startsWith('No Jobs'))

    let finalUpdateReloadOutput = target.performTask('/usr/local/bin/asclient', ['updates', 'reload'], 60 * 5);
    UIALogger.logMessage('Final update reload output: \n%0'.format(finalUpdateReloadOutput.stdout));
    let updatesAvailable = !finalUpdateReloadOutput.stdout.trim().startsWith('Available Updates count: [0]');
    UIAUtilities.assert(!updatesAvailable, 'Updates still available after asclient update. See logs.');
}

/**
 * Refresh update statuses in the background and force a kickoff of background updates
 */
ASFramework.backgroundUpdateApps = function backgroundUpdateApps() {
    target.performTask('/usr/local/bin/asclient', ['updates', 'reloadBackground'], 60 * 5);
}

/**
 * Removes all user-installed (non-system) apps
 */
ASFramework.removeUserApps = function removeUserApps() {
    target.performTask('/usr/local/bin/asclient', ['remove', 'allUser'], 60 * 5);
}
