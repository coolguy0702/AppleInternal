load('UIATesting.js');
load('UIAUtility.js')
load('AppStoreFrameworks.js')

UIAUtilities.assert(
    typeof ASFrameworkTests === 'undefined',
    'ASFrameworkTests has already been defined.'
);

/**
 * @namespace ASFrameworkTests
 */
var ASFrameworkTests = {};

/**
 * Authenticate with a given username and password
 *
 * @param {object} args - Test arguments
 * @param {string} [args.Username] - The username to log in with
 * @param {string} [args.Password] - The password to log in with
 */
ASFrameworkTests.authenticate = function authenticate(args) {
    ASFramework.authenticate(args.Username, args.Password);
}

/**
 * Change the password settings to never ask when downloading free apps
 * Operates on the currently logged-in account
 *
 * @param {object} args - Test arguments
 * @param {string} [args.Password] - The password of the current account
 */
ASFrameworkTests.disableFreePassword = function disableFreePassword(args) {
    ASFramework.disableFreePassword(args.Password);
}

/**
 * Install curated list of apps for smoke tests and benchmarks
 * @param {object} args - Test arguments
 * @param {string} [args.AppList] - The name of the app list to install. Choices are "Common30" or "Big2002"
 * @param {string} [args.DowngradeOffset] - The number of versions back the apps will be installed at
 * @param {object} [args.ProcessesToMonitor] - Array of the names of the processes to gather memory stats about
 */
ASFrameworkTests.installApps = function installApps(args) {
    ASFramework.installApps(ASFramework.appsForListName(args.AppList), args.DowngradeOffset, args.ProcessesToMonitor);
}

/**
 * Verify that a list of apps can be launched
 * @param {object} args - Test arguments
 * @param {string} [args.AppList] - The name of the app list to verify. Choices are "Common30" or "Big2002"
 */
ASFrameworkTests.verifyAppsLaunch = function verifyAppsLaunch(args) {
    ASFramework.verifyAppsLaunch(ASFramework.appsForListName(args.AppList));
}

/**
 * Verify that a list of apps has the expected files (receipt and metadata)
 * @param {object} args - Test arguments
 * @param {string} [args.AppList] - The name of the app list to verify. Choices are "Common30" or "Big2002"
 */
ASFrameworkTests.verifyAppsFiles = function verifyAppsFiles(args) {
    ASFramework.verifyAppsFiles(ASFramework.appsForListName(args.AppList));
}

/**
 * Refresh update statuses and begin a manual "Update All"
 */
ASFrameworkTests.manualUpdateApps = function manualUpdateApps() {
    ASFramework.manualUpdateApps();
}

/**
 * Refresh update statuses in the background and force a kickoff of background updates
 */
ASFrameworkTests.backgroundUpdateApps = function backgroundUpdateApps() {
    ASFramework.backgroundUpdateApps();
}

/**
 * Removes all user-installed (non-system) apps
 */
ASFrameworkTests.removeUserApps = function removeUserApps() {
    ASFramework.removeUserApps();
}
