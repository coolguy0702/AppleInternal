load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');
load('iCloudTestUtilities.js');


if (typeof tellagraf !== 'undefined') throw new UIAError('Tellagraf has already been loaded!', {identifier:'UIA module already loaded'});

/** @namespace */
UIAQuery.Tellagraf = {

    LOGIN_CONTAINER: UIAQuery.query('Login Controller'),
    POST_VIEW_CONTAINER: UIAQuery.query('Post View Controller'),

    CREATE_ACCOUNT_BUTTON: UIAQuery.query('CreateAccountButton'),
    PROFILE_PHOTO_BUTTON : UIAQuery.query('profilePhotoButton'),

    POST_ICON_BUTTON : UIAQuery.query('PostIcon'),
    /* Post Status screen */
    POST_BUTTON: UIAQuery.buttons('Post'),
    STATUS_TEXT: UIAQuery.staticTexts('Write something'),

    get EDIT_FULL_NAME () { return this.LOGIN_CONTAINER.andThen(UIAQuery.textFields().isVisible().topmost()); },


    BIRTHDATE: UIAQuery.query('UIDatePicker'),
    FULLNAME:  UIAQuery.textFields('UITextField'),
    MALE_GENDER: UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Male')),
    FEMALE_GENDER: UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Female')),

    /** NavigationBar */
    NAVIGATION_BAR: UIAQuery.navigationBars(),

    Alerts: {
        CONFIRM_DELETE:                 UIAQuery.contains('Confirm Delete'),
        NO_ICLOUD:                      UIAQuery.contains('No iCloud'),
        UNTRUSTED_APP:                  UIAQuery.contains('Untrusted App Developer'),

        OK_BUTTON:                      UIAQuery.alerts().andThen(UIAQuery.withPredicate("name ==[c] 'OK'")),
        TRUST_BUTTON:                   UIAQuery.alerts().andThen(UIAQuery.query('Trust')),
    },
};



/**
    @namespace
    @augments UIAApp
*/
var tellagraf = target.appWithBundleID('com.apple.cloudkit.Tellagraf');
tellagraf.NO_CLOUD_STR = 'No Cloud';
tellagraf.MONTHS      = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', ];
tellagraf.DAY_OF_WEEK = [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', ];

/**
 * Create a new user signUp
 * @param {string} FullName         - Users Full Name
 * @param {date}   BirthDate        - Users date of birth
 * @param {String} Gender           - Gender for user (male/female)
 * @param {object} EventOptions     - Other options for the subsequent events
 */
tellagraf.signUp = function signUp(FullName, BirthDate, Gender, EventOptions) {
    this._buildToTestEnvironment('SignUp', false);

    FullName = this._cleanedString(FullName);
    BirthDate = this._cleanedDate(BirthDate);
    Gender = this._cleanedString(Gender);
    EventOptions = (EventOptions === undefined) ? {} : EventOptions;

    var view = UIAQuery.collectionViews();
    if (view && view.isVisible() && view.topmost()) {
        //view = this.inspect(view.topmost())
        UIALogger.logMessage('Found %0 collection views to evaluate '.format(this.count(view)));
    }
    view = UIAQuery.tableViews()
    if (view && view.isVisible()) {
        //view = this.inspect(view)
        UIALogger.logMessage('Found %0 table views to evaluate'.format(this.count(view)))
    }
    view = UIAQuery.buttons('UIButton')
    if (view) {
        UIALogger.logMessage('Found %0 Buttons'.format(this.count(view)))

        view = UIAQuery.query('CreateAccountButton')
        UIALogger.logMessage('Inspecting: %0'.format(this.inspect(view)))
    }

    this._enterTextAndDismiss(UIAQuery.Tellagraf.FULLNAME, FullName)
    this._setDayPicker(UIAQuery.Tellagraf.BIRTHDATE, BirthDate)

    this.tap(UIAQuery.Tellagraf.CREATE_ACCOUNT_BUTTON)
}

/**
 * Set a new status message.
 *
 * @param {string} Message         - New Message to type
 * @param {object} EventOptions     - Other options for the subsequent events
 */
tellagraf.setStatus = function setStatus (Message, EventOptions) {
    this._buildToTestEnvironment('setStatus', false);
    Message = this._cleanedString(Message);

    var view = UIAQuery.buttons();
    if (view) {
        UIALogger.logMessage('Inspecting PostIcon button %0'.format(this.inspect(view)))
        view = UIAQuery.buttons().atIndex(0)
        this.tap(view)
    }

    // Now in the Post View Screen
    view = UIAQuery.Tellagraf.POST_VIEW_CONTAINER;
    if (view && view.isVisible() && view.topmost()) {
        UIALogger.logMessage('Found view %0 to evaluate '.format(this.inspect(view)));
    }

    view = UIAQuery.query('UITextView')
    if (view){
         this.enterText(view, String(Message));
    }

    view = UIAQuery.Tellagraf.POST_BUTTON;
    if (view) {
        this.tap(view)
    } else {
        this.tap(UIAQuery.CANCEL_BUTTON)
    }
}

/**
 * View the current status of the user
 *
 * @param {string} FullName         - Users Full Name
 * @param {object} EventOptions     - Other options for the subsequent events
 */
tellagraf.viewStatus = function viewStatus (FullName, EventOptions) {
    FullName = this._cleanedString(FullName);
    var view = UIAQuery.query('MKMapView');

    view = UIAQuery.query(FullName);
    this.tap(view);

    if (UIAQuery.VISIBLE_POPOVERS) {
        view = UIAQuery.popovers();
        this.tap(view);
    }

    view = UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Settings'));
    this.tap(view);
    this.tap(UIAQuery.buttons('Back'));
}

/**
 * Throws a UIError exception after logging the problem in the log
 *
 * @param {string} errorMessage - the message to indicate the problem
 * @param {string} errorIdentifier - location of the error
 */
tellagraf._throwException = function _throwException(errorMessage, errorIdentifier) {
    errorMessage = String(errorMessage);
    errorIdentifier = (errorIdentifier === undefined) ? errorMessage : String(errorIdentifier);
    UIALogger.logError(errorMessage);
    throw new UIAError(errorMessage, {identifier: errorIdentifier});
}

/**
 * force quit the Tellagraf app
 */
tellagraf._quitApp = function _quitApp() {
    try {
        UIALogger.logMessage('Killing Tellagraf');
        springboard.quitApp(this);
    } catch(e) {
        UIALogger.logError(e.message);
        UIALogger.logMessage('Killing app using killall');
        iCloudTestUtilities._systemRun('/usr/bin/killall Tellagraf');
    }
}

/**
 * Launch the Tellagraf app, first trying the local launchApp (if available) then by Springboard if not
 */
tellagraf._launchApp = function _launchApp() {
    UIALogger.logMessage('Launching Tellagraf (with NSZombieEnabled=YES)');
    var command = iCloudTestUtilities._systemRun( '/usr/local/bin/launchApp -unlock %0 -env NSZombieEnabled=YES'.format(this.bundleID()) );
    UIALogger.logMessage( command.stdout );

    if (command.stdout.match(/^Failed\ to\ launch/)) {
        UIALogger.logMessage('Looks like launching app by command-line failed; attempting to launch using Springboard instead!');
        UIALogger.logMessage("If you are seeing 'FBSOpenApplicationErrorDomain Code=3', this is probably because we are attempting to launch an un-trusted app for the first time (we need to first trust the app by UI, see <rdar://problem/18258234>)");
        this.launch();

    } else if (command.stderr.match(/No such file or directory/)) {
        UIALogger.logMessage('Looks like launchApp is missing; attempting to launch using Springboard instead!');
        this.launch();
    }

    if (target.activeApp() != this) this._throwException('Tellagraf failed to launch!');
    this.launch();    // No-op
    this.returnToTopLevel();
}

/**
 * Validate the ptest arguments all got converted to values before continuing the test.
 */
tellagraf._validatePtestArgs = function _validatePtestArgs(args) {
    // Make sure the arguments were properly resolved by checking for $$ at the beginning of the string
    var matchingPattern = /^\$\$/;
    UIALogger.logMessage('Validating test arguments');
    for (var i = 0; i < args.length; i++) {
        UIALogger.logMessage('Checking argument: ' + args[i]);
        if (typeof args[i] == 'string' && args[i].match(matchingPattern)) {
            this._throwException('Found an unresolved argument variable: ' + args[i]);
        }
    }
}

/**
 * Reset the device environment to run for the test.
 * start (or restart) the Tellagraf app if needed
 * Verify the Tellagraf app is connected to the correct iCloud Env
 */
tellagraf._buildToTestEnvironment = function _buildToTestEnvironment(testName, restartAppFirst) {
    // Ensure that Tellagraf is the frontmost app.  Quit and restart if specified
    if ( iCloudTestUtilities._toBool(restartAppFirst) ) {
        this._quitApp();
        this._launchApp();
    } else if (target.activeApp() != this) {
        this._launchApp();
    }

    if (this.inspect(UIAQuery.Tellagraf.NAVIGATION_BAR).name.search(this.NO_CLOUD_STR) != -1) {
        this._throwException("Navigation Bar title contains the substring '%0'; we are currently not signed in to iCloud!".format(this.NO_CLOUD_STR), 'Not signed in to iCloud');
    }
}

/**
 * Enter text into a text field (query) via the keyboard, and dismiss.
 */
tellagraf._enterTextAndDismiss = function _enterTextAndDismiss(query, text) {
    this.enterText(query, String(text));

    var keyboard = UIAQuery.keyboard();
    if (this.exists(keyboard)) {
        UIALogger.logMessage('Dismissing keyboard');
        this.tap(keyboard.andThen(UIAQuery.buttons('Done').orElse(UIAQuery.buttons('Return')).orElse(UIAQuery.buttons('Search'))));
    }
}

/**
 * Set a date on a date picker UI component
 */
tellagraf._setDayPicker = function _setDayPicker(PickerQuery, TargetDate) {
    var year = String( TargetDate.getFullYear() );
    var month = this.MONTHS[TargetDate.getMonth()];
    var dayOfMonth = String( TargetDate.getDate() );
    this.setPickerValues(PickerQuery, [month, dayOfMonth, year]);
}

/**
 * Verify a parameter date string can be (and is) correctly converted to a date
 */
tellagraf._cleanedDate = function _cleanedDate(dateString) {
    dateString = this._cleanedString(dateString);
    // This is for parsing RepeatEndDates; Calendar.js interprets UNDEFINED as 'don't change the current value' and NULL as 'explicitly set value to null'
    if (dateString === undefined || dateString === null || dateString.match(/^never$/i)) return null;

    var date = new Date(dateString);
    return isNaN(date) ? undefined : date;
}

/**
 * Verify a parameter bool string (of true) is correctly converted to a bool
 */
tellagraf._cleanedBool = function _cleanedBool(boolString) {
    return (typeof boolString == 'string') ? boolString.match(/^true$/i) :
           (typeof boolString == 'number' ) ? (boolString != 0) :
           (typeof boolString == 'boolean' ) ? boolString : undefined;
}

/**
 *  Verify a parameter string of type string is correctly a string.
 */
tellagraf._cleanedString =  function _cleanedString(string) {
    return string ? String(string) : undefined;
}
