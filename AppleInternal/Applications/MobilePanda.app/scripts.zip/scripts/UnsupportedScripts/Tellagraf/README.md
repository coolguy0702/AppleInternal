Project: Tellagraf testing application for CloudKit
Maintainer(s): Thomas Jones-Low, Mike Hanna
Maintainer(s) email: tjoneslow@apple.com, mhanna@apple.com
Maintainer(s) team: iCloud CloudKit Build
Maintainer team manager: Chris Edstrom
Maintainer team manager email: cedstrom@apple.com
Description: 
This project is designed to be part of the end-to-end (client to server) testing of the iCloud CloudKit project. Mike Hanna, a member of the iCloud QA team, maintains the Tellagraf app used by this testing system (radars to iCloud Tellagraf | All). Thomas Jones-Low, a member of the iCloud CloudKit build team, maintains and updates the UIAutomation scripts to drive the overall testing effort. 