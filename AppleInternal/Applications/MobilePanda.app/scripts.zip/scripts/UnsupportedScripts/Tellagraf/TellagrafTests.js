load('UIATesting.js');
load('SpringBoard.js');
load('Tellagraf.js');

if (typeof TellagrafTestUtilities !== 'undefined') throw new UIAError('TellagrafTestUtilities has already been loaded!', {identifier:'UIA module already loaded'});
if (typeof TellagrafTest !== 'undefined') throw new UIAError('TellagrafTest has already been loaded!', {identifier:'UIA module already loaded'});

var TellagrafTestUtilities = {
    defaultTestArgs: function defaultTestArgs(args, customDefaults) {
        // First override with custom defaults if available
        if (typeof customDefaults == 'object') args = UIAUtilities.defaults(args, customDefaults);

        return UIAUtilities.defaults(args, {
            FullName:       'Thomas Jones-Low',
            BirthDate:      '1/1/1960',
            Gender:         'Male',
            Message:        'Tellagraf Status Message'
        });
    },
};

var TellagrafTests = {

    /**
     * Initial user signup for Tellagraf service
     *
     *
     * @param {object}      args Test arguments
     * @param {string}      [args.FullName='Fred Smith']               - Full Name to sign up for the service
     * @param {date}        [args.BirthDate='1/1/1960']           - User date of birth
     * @param {string}      [args.Gender='Male']                   - User gender
     */
    signUp: function signUp(args) {
        args = TellagrafTestUtilities.defaultTestArgs(args);
        tellagraf.signUp(args.FullName, args.BirthDate, args.Gender, args );
    },

    /**
     * Set a new status message for the user
     *
     * @param {object}      args - Test Arguments
     * @param {string}      [args.Message='Tellagraf Status Message']   - New status message for Tellagraf user friends.
     */
    setStatus: function setStatus(args) {
        args = TellagrafTestUtilities.defaultTestArgs(args);
        tellagraf.setStatus(args.Message, args);
    },

    /**
     * View the current user's status
     *
     * @param {string}      [args.FullName='Fred Smith']               - Full Name to sign up for the service
     * @param {object}      args - Test Arguments
     */
    viewStatus: function viewStatus(args) {
        args = TellagrafTestUtilities.defaultTestArgs(args);
        tellagraf.viewStatus(args.FullName, args);
    },
}
