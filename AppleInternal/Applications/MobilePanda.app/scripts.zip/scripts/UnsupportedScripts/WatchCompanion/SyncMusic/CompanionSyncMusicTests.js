load('UIATesting.js');
load('AppleWatch+Music.js');
load('SpringBoardTests.js');

UIAUtilities.assert(
    typeof CompanionSyncMusicTests === 'undefined',
    'CompanionSyncMusicTests has already been defined.'
);

/** @namespace */
var CompanionSyncMusicTests = {

    /**
     * Enables music track-sync by selecting music playlist to sync over to gizmo.
     *
     * @targetApps Bridge
     *
     * @param {object} args Test arguments
     * @param {string}  [args.playlistName=""] - name of the playlist to sync
     *
     * @note assumes the device already has that playlist.
     * @error Error if we fail to select the playlist.
     */
    turnOnMusicSync: function turnOnMusicSync(args) {
        args = UIAUtilities.defaults(args, {
            playlistName: '',
        }, true);

        appleWatch.turnOnMusicSync(args.playlistName);
    },

    /**
     * Changes the music storage limits on the gizmo.
     *
     * @targetApps Bridge
     *
     * @param {object} args Test arguments
     * @param {string}  [args.limitType="Storage"] - limit type ("Storage", "Songs")
     * @param {string}  [args.limitAmount="1.0 GB"] - limit amount ("100 MB", "500 MB", "1.0 GB", "2.0 GB")
     *                                                             ("15 Songs", "50 Songs", "125 Songs", "250 Songs")
     *
     * @error Error if we fail to set the storage limit.
     */
    changeMusicStorageLimits: function changeMusicStorageLimits(args) {
        args = UIAUtilities.defaults(args, {
            limitType: 'Storage',
            limitAmount: '1.0 GB'
        }, true);

        appleWatch.changeMusicStorageLimits(args.limitType, args.limitAmount);
    },

}
