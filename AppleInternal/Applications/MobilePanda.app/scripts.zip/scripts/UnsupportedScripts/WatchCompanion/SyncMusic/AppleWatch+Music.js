load('UIAApp.js');
load('UIAApp+Parsec.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('AppleWatch.js');


/** Constants for common template queries */
UIAQuery.AppleWatch.Music = {
	MUSIC_TABLE_CELL: UIAQuery.tableCells('Music'),

	MUSIC_NAVIGATION_BAR: UIAQuery.navigationBars('Music'),

	SYNCED_PLAYLIST_TABLE_CELL: UIAQuery.tableCells().andThen(UIAQuery.contains('Synced')),

	PLAYLIST_LIMIT_TABLE_CELL: UIAQuery.tableCells().andThen(UIAQuery.contains('Limit')),
}


/**
 * Enables music track-sync by selecting music playlist to sync over to gizmo.
 *
 * @targetApps AppleWatch
 *
 * @param {string} playlistName Name of the playlist to sync.
  *
 * @note Assumes the device already has that playlist.
 * @error Error if the playlist could not be selected.
 */
appleWatch.turnOnMusicSync = function turnOnMusicSync(playlistName) {
	appleWatch.getToMusic();

	if (!this.waitUntilPresent(UIAQuery.AppleWatch.Music.SYNCED_PLAYLIST_TABLE_CELL))
		throw new UIAError('"Synced Playlist" table cell did not appear.');

	this.tap(UIAQuery.AppleWatch.Music.SYNCED_PLAYLIST_TABLE_CELL);

	var playlistQuery = UIAQuery.tableCells().andThen(UIAQuery.query(playlistName))

	if (!this.waitUntilPresent(playlistQuery))
		throw new UIAError('"%0" did not appear.'.format(playlistName));

	this.tap(playlistQuery);

	this.delay(2);  // let the state settle -- if we don't do this, the changing labels can confuse scripter

	if (!this.waitUntilPresent(UIAQuery.tableCells().andThen(UIAQuery.contains(playlistName).siblings().contains('Sync'))))
		throw new UIAError('Could not select playlist %0 to sync.'.format(playlistName));

	UIALogger.logMessage("Selected playlist %0 to sync.".format(playlistName));
}

/**
 * Changes the music storage limits on the gizmo.
 *
 * @targetApps AppleWatch
 *
 * @param {string} limitType
 * @param {string} limitAmount
 **/
appleWatch.changeMusicStorageLimits = function changeMusicStorageLimits(limitType, limitAmount) {
    appleWatch.getToMusic();

    if (!this.waitUntilPresent(UIAQuery.AppleWatch.Music.PLAYLIST_LIMIT_TABLE_CELL))
		throw new UIAError('"Playlist Limit" table cell did not appear.');

	if (!this.tapIfExists(UIAQuery.AppleWatch.Music.PLAYLIST_LIMIT_TABLE_CELL))
		throw new UIAError('Could not tap the "Playlist Limit" table cell.');

	var typeQuery = UIAQuery.tableCells().andThen(UIAQuery.contains(limitType));

	if (!this.waitUntilPresent(typeQuery))
	   throw new UIAError('"%0" did not appear.'.format(limitType))

	this.tap(typeQuery);

	var amtQuery = UIAQuery.tableCells().andThen(UIAQuery.contains(limitAmount));

	if (!this.waitUntilPresent(amtQuery))
	   throw new UIAError('"%0" did not appear.'.format(limitAmount));

	this.tap(amtQuery);

	UIALogger.logMessage("Selected playlist limit %0 of type %0.".format(limitAmount, limitType));
}

/**
 * 
 * Opens the Watch app, selects 'My Watch', and selects the 'Music' table cell.
 *
 * @targetApps AppleWatch
 *
 * @error Error if the Music table cell does not appear.
 **/
appleWatch.getToMusic = function getToMusic() {
	appleWatch.launch();

	if (!this.waitUntilPresent(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON))
		throw new UIAError('"My Watch" button is not visible; did the Watch app launch?');

	if (!this.tapIfExists(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON))
		throw new UIAError('Could not tap "My Watch" button.');

	if (!this.waitUntilPresent(UIAQuery.AppleWatch.Music.MUSIC_TABLE_CELL))
		throw new UIAError('"Music" table cell did not appear.');

	if (!this.scrollToVisibleIfExists(UIAQuery.AppleWatch.Music.MUSIC_TABLE_CELL))
		throw new UIAError('Could not scroll to the "Music" table cell.');

	if (!this.tapIfExists(UIAQuery.AppleWatch.Music.MUSIC_TABLE_CELL))
			throw new UIAError('Could not tap the "Music" table cell.');

	if (!this.waitUntilPresent(UIAQuery.AppleWatch.Music.MUSIC_NAVIGATION_BAR)) {
		// if the Music cell ended up behind the navigation bar, the cell wasn't actually tapped
		// scroll to the 'Photos' cell since that will offset the Music cell enough.
		// see rdar://problem/23794658.
		this.scrollToVisible(UIAQuery.tableCells('Photos'));
		this.tap(UIAQuery.AppleWatch.Music.MUSIC_TABLE_CELL);
		if (!this.waitUntilPresent(UIAQuery.AppleWatch.Music.MUSIC_NAVIGATION_BAR))
			throw new UIAError('"Music" navigation bar did not appear.');
	}
}