App/Project/Feature: WatchCompanion
Maintainer(s): Sebastien Ceurty
Maintainer(s) Email: sceurty@apple.com
Maintainer(s) Team: PEP Automation Team
Maintainer(s) Team Manager: Keith Preston
Maintainer(s) Team Manager Email: kpreston@apple.com
This folder only contains UI automation scripts for the Watch Companion (i.e.paired iPhone). It is used by Notification test suites that live in the restricted Watch Automation Git repositories.