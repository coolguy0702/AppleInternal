load('UIATesting.js');
load('CalendarTests.js');
load('SpringBoardTests.js');

UIAUtilities.assert(
    typeof CompanionSyncCalendarTests === 'undefined',
    'CompanionSyncCalendarTests has already been defined.'
);

/** @namespace */
var CompanionSyncCalendarTests = {

    /**
     * Enters Airplane Mode, adds multiple events to the calendar, then exits Airplane Mode.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments (same as addMultiplesOfEvent test)
     * @param {number}      [args.Count=3]                   - Number of events to create
     * @param {string}      [args.TitlePrefix=""]            - Prefix for event titles
     *     (Complete title: "TitlePrefix_event number_random integer")
     * @param {DateString}  [args.StartDate=""]              - StartDate of event
     * @param {DateString}  [args.EndDate=""]                - EndDate of event
     * @param {string}      [args.Location=""]               - Location of event
     * @param {string}      [args.CalendarName=""]           - Calendar to save this event under
     * @param {string}      [args.CalendarGroup=""]          - Calendar group to save this event under
     * @param {bool}        [args.AllDay=false]              - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                 - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]          - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]               - List of invitees to add to event (Not available in all calendars)
     * @param {string}      [args.Alert=""]                  - Alert for event
     * @param {enum}        [args.ShowAs=""]                 - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]             - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                    - Event URL
     * @param {string}      [args.Notes=""]                  - Event notes
     * @param {bool}        [args.SkipVerification=false]    - Adds event without verifying
     */
    addEventsAirplaneMode: function addEventsAirplaneMode(args) {

        // Enter Airplane Mode
        SpringBoardTests.toggleControlCenterOptions({buttons:['Airplane Mode'], roundtrip: false});

        try {
            CalendarTests.addMultiplesOfEvent(args);
        } catch (e) {
            UIALogger.logError('An error occurred while trying to add events');
            throw e;
        } finally {
            // Exit Airplane Mode
            SpringBoardTests.toggleControlCenterOptions({buttons:['Airplane Mode'], roundtrip: false});
        }

    },
}