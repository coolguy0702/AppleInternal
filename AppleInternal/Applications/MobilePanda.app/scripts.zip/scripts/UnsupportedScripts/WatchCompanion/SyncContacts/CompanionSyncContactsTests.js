load('UIATesting.js');
load('Contacts.js');
load('SpringBoardTests.js');

UIAUtilities.assert(
    typeof CompanionSyncContactsTests === 'undefined',
    'CompanionSyncContactsTests has already been defined.'
);

/** @namespace */
var CompanionSyncContactsTests = {

    /**
     * Adds multiple contacts to the address book.
     *
     * @targetApps Contacts
     *
     * @param {object} args Test arguments
     * @param {number}  [args.count=3] - Number of contacts to create
     * @param {string}  [args.firstnamePrefix=""] - prefix for contact firstname
     *     (Complete firstname: "firstnamePrefix_contact number_random integer")
     * @param {string}  [args.lastName=null] - Optional last name of new contact
     * @param {string}  [args.company=null] - Optional company of new contact
     * @param {string}  [args.phone=null] - Optional Phone number of contact
     * @param {string}  [args.email=null] - Optional Email of contact
     * @param {string}  [args.url=null] - Optional URL of contact
     */
    addContacts: function addContacts(args) {
        args = UIAUtilities.defaults(args, {
            count: 2,
            firstnamePrefix: '',
            lastName: null,
            company: null,
            phone: null,
            email: null,
            url: null,
        });

        // Launch app here until rdar://problem/23031807 is fixed
        contacts.launch();
        contacts.getToMainScreen();

        for (i = 0; i < args.count; i++) {
            randomID = UIAUtilities.randomInt(0, 10000);
            addNewContactOptions = args;
            addNewContactOptions.firstName = '%0_%1_%2'.format(args.firstnamePrefix, i, randomID);
            UIALogger.logDebug('*** SEB *** addNewContactOptions: %0'.format(addNewContactOptions));
            contacts.addNewContact(addNewContactOptions);
        }
    },


    /**
     * Enters Airplane Mode, adds multiple contacts to the address book, then exits Airplane Mode.
     *
     * @targetApps Contacts
     *
     * @param {object} args Test arguments (same as addContacts test)
     * @param {number}  [args.count=3] - Number of contacts to create
     * @param {string}  [args.firstnamePrefix=""] - prefix for contact firstname
     *     (Complete firstname: "firstnamePrefix_contact number_random integer")
     * @param {string}  [args.lastName=null] - Optional last name of new contact
     * @param {string}  [args.company=null] - Optional company of new contact
     * @param {string}  [args.phone=null] - Optional Phone number of contact
     * @param {string}  [args.email=null] - Optional Email of contact
     * @param {string}  [args.url=null] - Optional URL of contact
     */
    addContactsAirplaneMode: function addContactsAirplaneMode(args) {

        // Enter Airplane Mode
        SpringBoardTests.toggleControlCenterOptions({buttons:['Airplane Mode'], roundtrip: false});

        try {
            CompanionSyncContactsTests.addContacts(args);
        } catch (e) {
            UIALogger.logError('An error occurred while trying to add contacts');
            throw e;
        } finally {
            // Exit Airplane Mode
            SpringBoardTests.toggleControlCenterOptions({buttons:['Airplane Mode'], roundtrip: false});
        }
    },

}