
load("UIAUtility.js");
load("UIAApp.js");
load("UIAApp+Message.js");
load("SpringBoard.js");
load("Messages.js");
load("Calendar.js");
load("Mail.js");


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

notifications = {};
notifications.TYPE = {
    MESSAGES: 'messages',
    CALENDAR: 'calendar',
    MAIL:     'mail',
    ANY:      'any',
};
notifications.MAIL_APP_SUB_VIEW = {
    ICLOUD:   'iCloud',
    VIP:      'VIP',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Tasks                                                               */
/*                                                                             */
/*      A high-level goal we are trying to accomplish.                         */
/*      Comprised of multiple Action functions and do not assume state         */
/*                                                                             */
/*******************************************************************************/

/**
 * Verifies that the expected number of notifications occur on the watch companion.
 *
 * @param {integer}   expectedCount - Number of expected notifications
 * @param {string}    semaphoreUUID - Semaphore UUID used by main test thread
 * (WatchAutomationAdditions/Tests/RunNotificationsTests.py) to stop UI test thread
 * @param {boolean}   locked  - Whether the device is locked
 * @param {object}    options - Dictionary for additional options
 * @param {integer}   [options.testTimeout=3600] - In seconds. The verification times out after an hour by default
 * @param {string}    [options.notificationType="any"] - Type of notifications to expect [Not implemented yet]
 *
 * @throws If device is unlocked and receives no notifications.
 */
springboard.verifyIncomingNotifications = function verifyIncomingNotifications(expectedCount, semaphoreUUID, locked, options) {
    options = UIAUtilities.defaults(options, {
        notificationType: notifications.TYPE.ANY,
        testTimeout:      60*60, // One hour

    });
    var fileMarkingTestEnd = '/tmp/%0'.format(semaphoreUUID);
    var startTimeInSec = new Date().getTime()/1000;
    var currentTimeInSec = startTimeInSec;
    var announcements = [];
    var waiterEvent = 'Announcement';
    var waiterTimeout = 10;
    var waiterFunction = function waiterFunction(event, dt) {
        UIALogger.logDebug('Received event: %0 after %1 second(s)'.format(JSON.stringify(event), dt));
        announcements.push(event.announcement);
        UIALogger.logDebug('Announcement received: %0. Current announcement count: %1'.format(event.announcement, announcements.length));
    };

    while (announcements.length < expectedCount && (currentTimeInSec - startTimeInSec < options.testTimeout)) {

        var announcementWaiter = UIAWaiter.waiter(waiterEvent);
        announcementWaiter.wait(waiterTimeout, waiterFunction);

        if (UIAFile.fileExists(fileMarkingTestEnd)) {
            target.performTask('/bin/rm', [fileMarkingTestEnd]);
            UIALogger.logMessage('Found file telling script to stop listening');
            break;
        }

        currentTimeInSec = new Date().getTime()/1000;
    }

    if (locked) {
        if (announcements.length > 0) {
            UIALogger.logWarning('Companion received some notification(s). This is just a warning. Product failures are identified by post-processing the device syslogs. Announcements received: %0, Announcement count: %1'.format(announcements, announcements.length));     
        }

    } else {
        if (announcements.length == 0) {
            throw new Error('Companion missed all notification(s)! Something is really wrong.');
        } else if (announcements.length < expectedCount) {
                UIALogger.logWarning('Companion missed some notification(s). This is just a warning. Product failures are identified by post-processing the device syslogs. Announcements received: %0, Announcement count: %1'.format(announcements, announcements.length));     
        } else {
            UIALogger.logMessage('Companion received all notifications while unlocked. Announcements: %0, Announcement count: %1'.format(announcements, announcements.length));
        }
    }
}


/**
 * Sends a bunch of random messages (text/MMS) to the given recipient
 * This function should really live in the Messages library instead:
 * rdar://problem/22409453 ER: Implement sendRandomMessages()
 *
 * @param {object} options - Options struct
 * @param {string} [options.recipient="18025551234"] - Recipient of messages
 * @param {integer} [options.count=5] - Numbers of messages to send
 * @param {integer} [options.waitTime=5] - Number of seconds to wait between messages
 *
 * @throws If three of the messages in a row fail to send
 */
messages.sendRandomMessages = function sendRandomMessages(options) {
    var options = UIAUtilities.defaults(options, {
        recipient: "18025551234",
        count: 5,
        waitTime: 5,
    });

    var successCount = 0;
    var tryCount = 0;
    var consecutiveFails = 0;

    messages.getToThreadList();
    messages.getToComposeUI();
    messages.enterMessageRecipients([options.recipient]);

    while (successCount < options.count) {
        try {
            tryCount++;
            var text = _generateRandomText(tryCount);
            messages._sendQuickMessage(text);
            target.delay(options.waitTime);
            successCount++;
            consecutiveFails = 0;
        } catch (e) {
            UIALogger.logError(e);
            consecutiveFails++;
            if (consecutiveFails >= 3) {
                UIALogger.logError("Failed 3 times in a row, throwing failure exception");
                throw e;
            }
        }
    }

    UIALogger.logMessage("Done with all messages!");
}

/**
 * Sends a bunch of random mails to the given recipient
 * This function should really live in the Email library instead:
 * rdar://problem/22409700 ER: Implement sendRandomEmail()
 *
 * @param {object} options - Options struct
 * @param {string} [options.recipient="jsmith_purple@gmail.com"] - Recipient of mails
 * @param {integer} [options.count=5] - Numbers of mails to send
 * @param {integer} [options.waitTime=5] - Number of seconds to wait between mails
 *
 * @throws If three of the mails in a row fail to send
 */
mail.sendRandomMails = function sendRandomMails(options) {
    var options = UIAUtilities.defaults(options, {
        recipient: "jsmith_purple@gmail.com",
        count: 5,
        waitTime: 5,
    });

    var successCount = 0;
    var tryCount = 0;
    var consecutiveFails = 0;

    mail.getToEmailFolder();

    while (successCount < options.count) {
        try {
            tryCount++;
            var text = _generateRandomText(tryCount);
            mail.tap(UIAQuery.Mail.COMPOSE_BUTTON);
            mail.composeEmail([options.recipient], {subject: tryCount, body: text});
            target.delay(options.waitTime);
            successCount++;
            consecutiveFails = 0;
        } catch (e) {
            UIALogger.logError(e);
            consecutiveFails++;
            if (consecutiveFails >= 3) {
                UIALogger.logError("Failed 3 times in a row, throwing failure exception");
                throw e;
            }
        }
    }

    UIALogger.logMessage("Done with all mails!");
}

/**
 * Sends a bunch of random calendar invites to the given recipient
 *
 * @param {object} options - Options struct
 * @param {string} [options.recipient="jsmith_purple@gmail.com"] - Recipient of calendar invites
 * @param {integer} [options.count=5] - Numbers of calendar invites to send
 * @param {integer} [options.waitTime=5] - Number of seconds to wait between calendar invites
 *
 * @throws If three of the calendar invites in a row fail to send
 */
calendar.sendRandomCalendarInvites = function sendRandomCalendarInvites(options) {
    var options = UIAUtilities.defaults(options, {
        recipient: "jsmith_purple@gmail.com",
        count: 5,
        waitTime: 5,
    });

    var successCount = 0;
    var tryCount = 0;
    var consecutiveFails = 0;

    var eventOptions = {
        CalendarGroup: "iCloud",
        CalendarName: "Calendar 2",
        Invitees: [options.recipient],
    };

    calendar.launch();

    while (successCount < options.count) {
        try {
            tryCount++;
            var text = _generateRandomText(tryCount);
            var title = "Beer Bash " + tryCount;
            calendar.addEvent(title, null, null, eventOptions);
            target.delay(options.waitTime);
            successCount++;
            consecutiveFails = 0;
        } catch (e) {
            UIALogger.logError(e);
            consecutiveFails++;
            if (consecutiveFails >= 3) {
                UIALogger.logError("Failed 3 times in a row, throwing failure exception");
                throw e;
            }
        }
    }

    UIALogger.logMessage("Done with all calendar invites!");
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other helper functions                                              */
/*                                                                             */
/*******************************************************************************/

function _generateRandomText(iteration) {
    var str = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue \
               mi in nisi tincidunt, non mollis enim hendrerit. Proin condimentum \
               ultricies tempus. Suspendisse maximus urna eu tellus pulvinar condimentum. \
               Maecenas aliquet, ante et efficitur pharetra, libero purus vehicula purus, \
               nec ultricies diam orci at arcu. Quisque auctor, arcu id dapibus egestas, \
               lectus odio suscipit mi, eu elementum purus turpis vel elit. Cras mattis \
               tortor nec semper sagittis. Cras arcu dui, aliquam quis lectus eu, bibendum \
               feugiat quam. Vivamus mauris felis, posuere non mi sit amet, ultricies maximus felis. \
               Morbi dictum nibh a dignissim elementum. Maecenas nulla turpis, ullamcorper a bibendum sed, \
               sagittis a turpis. Duis vel laoreet sapien. Proin eget ullamcorper tellus. Aliquam posuere \
               cursus mi quis luctus. Nunc non viverra dui, sed pretium eros.";
    var text = str.slice(0, Math.random() * str.length)
    
    // Use the iteration number as prefix and suffix
    return '%0 %1 %0'.format(iteration, text)
}


messages._sendQuickMessage = function _sendQuickMessage(text) {
    messages.enterMessageText(text);
    target.delay(1); // Send button is not always immediately active
    this.tap(UIAQuery.MESSAGE_SEND_BUTTON);
}
