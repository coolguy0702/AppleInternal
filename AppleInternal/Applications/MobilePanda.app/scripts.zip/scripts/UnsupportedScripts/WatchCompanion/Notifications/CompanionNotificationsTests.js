
load('UIATesting.js');
load('UIASemaphore.js');
load('CompanionNotifications.js');
load('Settings.js');

UIAUtilities.assert(typeof CompanionNotificationsTests === 'undefined', 'CompanionNotificationsTests has already been defined.')

/** @namespace */

var CompanionNotificationsTests = {

    /**
     * Turns on banner notifications for the given notification type
     *
     * @targetApps Preferences
     *
     * @param {object} args Test arguments
     * @param {string} [args.notificationType="any"] - The notification type to turn banners on for
     * @param {string} [args.notificationMailAppSubView="iCloud"] - The Mail app sub-view to turn banners on for if multiple accounts exist (e.g. "iCloud" or "VIP")
     */
    prepareForNotifications: function prepareForNotifications(args) {
        args = UIAUtilities.defaults(args, {
            notificationType: notifications.TYPE.ANY,
            notificationMailAppSubView: notifications.MAIL_APP_SUB_VIEW.ICLOUD,
        });

        switch (args.notificationType.toLowerCase()) {
            case notifications.TYPE.MESSAGES:
                settings.setNotification('Messages', 'Banners', true);
                settings.chooseCheckmarkedItem(['Notifications', 'Messages', 'Repeat Alerts'], 'Never');
                break;
            case notifications.TYPE.CALENDAR:
                // settings.setNotification("Calendar", "Banners", true);
                break;
            case notifications.TYPE.MAIL:
                // Sometimes, we must navigate to a sub-view when there are multiple 'accounts' (e.g. 'iCloud' and 'VIP' lead to two table cells)
                try {
                    settings.setNotification('Mail', 'Banners', true);
                } catch (e) {
                    UIALogger.logMessage('Failures are expected when there is more than one "account". The latter causes Mail notification settings to have multiple table cells (e.g. "iCloud", "VIP")');
                    // Try again, using the sub-view argument this time
                    UIALogger.logMessage('Navigating to sub-view to set Mail notification settings for account %0'.format(args.notificationMailAppSubView));
                    settings.setNotification('Mail', 'Banners', true, [args.notificationMailAppSubView]);
                }
                break;
            case notifications.TYPE.ANY:
                args.notificationType = notifications.TYPE.MESSAGES;
                prepareForNotifications(args);
                args.notificationType = notifications.TYPE.CALENDAR;
                prepareForNotifications(args);
                args.notificationType = notifications.TYPE.MAIL;
                prepareForNotifications(args);
                break;
            default:
                UIALogger.logWarning('Invalid type passed in: %0'.format(args.notificationType));
                break;
        }
    },

    /**
     * Sends many quick notification triggers (messages, mails, invites)
     *
     * @targetApps MobileSMS, Calendar, MobileMail
     *
     * @param {object} args Test arguments
     * @param {string} [args.notificationType="messages"] - The notification type to send
     * @param {integer} [args.count=5] - The notification count
     * @param {string} [args.semaphoreUUID=null] - The semaphore UUID that should be locked
     * @param {string} [args.sendingAccount="salty_small@icloud.com"] - The account sending notifications. Used to lock a unique semaphore
     * @param {string} [args.recipient="jsmith_purple@gmail.com"] - The account to send notifications to. Can be a phone number for Messages
     */
    sendNotificationsToRecipient: function sendNotificationsToRecipient(args) {
        args = UIAUtilities.defaults(args, {
            notificationType: notifications.TYPE.MESSAGES,
            count: 5,
            semaphoreUUID: null,
            sendingAccount: 'salty_small@icloud.com',
            recipient: 'jsmith_purple@gmail.com',
        });

        UIALogger.logMessage("Unlocking sender's semaphore in preparation first...");
        var senderSemaphoreUUID = '%0-%1'.format(args.semaphoreUUID, args.sendingAccount);

        // Do not throw an exception if the lock was already unlocked. Useful during unit-testing (rdar://problem/22242289)
        semaphoreOptions = {};
        semaphoreOptions.throwOnFail = false;
        UIASemaphore.unlock(senderSemaphoreUUID, semaphoreOptions);

        // Wait for Companion to be in the proper lock state before sending
        UIALogger.logMessage('Waiting for Companion to be in the expected lock state for the test before sending');
        var receiverSemaphoreUUID = 'CompanionReadyToReceive-%0'.format(args.semaphoreUUID);
        UIASemaphore.pollForLocked(receiverSemaphoreUUID)
        UIALogger.logMessage('Companion notified us it was in the expected lock state for the test. We can start sending');

        sendOptions = {
            recipient: args.recipient,
            count: args.count,
        };
        try {
            switch (args.notificationType) {
                case notifications.TYPE.MESSAGES:
                    messages.sendRandomMessages(sendOptions);
                    break;
                case notifications.TYPE.CALENDAR:
                    calendar.sendRandomCalendarInvites(sendOptions);
                    break;
                case notifications.TYPE.MAIL:
                    mail.sendRandomMails(sendOptions);
                    break;
                default:
                    UIALogger.logWarning('Invalid type passed in: %0'.format(args.notificationType));
                    break;
            }
        } catch (e) {
            // Lock semaphore
            UIASemaphore.lock(senderSemaphoreUUID);
            throw e;
        }

        // Lock semaphore
        UIASemaphore.lock(senderSemaphoreUUID);
    },

    /**
     * Verifies that the expected number of notifications occur on the watch companion
     *
     * @param {object}  args Test arguments
     * @param {integer} [args.expectedCount=10] - Number of expected notifications
     * @param {string}  [args.semaphoreUUID=null] - Semaphore UUID used by 
     main test thread (in RunNotificationsTests.py) to stop UI test thread
     * @param {string}  [args.notificationType="any"] - Type of notifications to expect [Not implemented yet]
     * @param {integer}  [args.testTimeout=3600] - In seconds. The verification times out after an hour by default
     * @param {boolean} [args.locked=true] - Whether to lock the device at the beginning of the test
     * @param {integer}  [args.postLockUnlockDelay=30] - In seconds. Delay between entering desired lock state and asking sender(s) to start sending
     */
    verifyIncomingNotifications: function verifyIncomingNotifications(args) {
        args = UIAUtilities.defaults(args, {
            expectedCount:       10,
            semaphoreUUID:       null,
            notificationType:    notifications.TYPE.ANY,
            testTimeout:         60*60, // One hour
            locked:              true,
            postLockUnlockDelay: 30,
        });

        UIALogger.logMessage("Entering test's desired lock state");
        if (args.locked) {
            springboard.lock();
        } else {
            springboard.unlock();
        }

        // Allow tests to wait between entering the locked/unlocked state and asking the sender(s) to start sending
        target.delay(args.postLockUnlockDelay);

        // Notify the sender(s) Companion is in the proper lock state for the test
        UIALogger.logMessage('Notifying the sender(s) Companion is in the proper lock state for the test');
        var receiverSemaphoreUUID = 'CompanionReadyToReceive-%0'.format(args.semaphoreUUID);
        UIASemaphore.lock(receiverSemaphoreUUID);

        springboard.verifyIncomingNotifications(args.expectedCount, args.semaphoreUUID, args.locked, args);

        UIASemaphore.unlock(receiverSemaphoreUUID);
    },


};
