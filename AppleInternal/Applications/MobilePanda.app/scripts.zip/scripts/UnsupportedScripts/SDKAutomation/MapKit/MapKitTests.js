load('UIATesting.js');
load('MapKit.js');
load('SpringBoard.js');

if (typeof MapKitTests === 'undefined') {
    /**
     * @namespace MapKitTests
     */
    var MapKitTests = {


        /**
          * authorizeUrl
          * Run MKPlatformValidator with no arguments to probe for "first run" open URL alert. If the alert appears,
          * click "Open" button and proceed to the next test
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          *
          * @alertHandlers springboard.standardAlertHandler
          */

        authorizeUrl: function authorizeUrl(args) {
            mapkit.authorizeMapkitPlatformValidatorURL();
        },

        /**
          * pushToWatch
          * Support function used from PepperUIAutomation to install MKPlatformValidator-watchOS app to watch
          *
          * @targetApps Bridge
          *
          * @alertHandlers springboard.standardAlertHandler
          */

        pushToWatch: function pushToWatch() {
            mapkit.pushMapkitPlatformValidatorToWatch();
        },


        /**
          * directionCheck
          * Gets directions for the given start and end location. Then verify route is loaded.
          * It does not navigate to given end location.
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="directionCheck"] - directionCheck test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          * @param {string} [args.TestTimeout="120"] - Test timeout in seconds
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        directionCheck: function directionCheck(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'DirectionCheck',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid',
                  TestTimeout: 120
              });

            // Uniquify the directory

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));

            return mapkit.executeTestCase(args, function() {

              return true;

             });
        },

        /**
          * locationSearch
          * Verifies MKLocalSearchRequest
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="locationSearch"] - locationSearch test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */
          locationSearch: function locationSearch(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'LocationSearch',
                  LogFileDir: '/tmp/runlogs',
                  SearchTerm: 'Starbucks',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function () {
                    if (!mapkit.exists(UIAQuery.query("MKNewAnnotationContainerView").children().contains(args.SearchTerm))) {
                        throw new UIAError('Search term not found in MapView %0'.format(args.SearchTerm));
                    }
            });
        },

        /**
          * userLocation
          * Verifies interaction of location manager and MKPinAnnotationView
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="userLocation"] - userLocation test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */
        userLocation: function userLocation(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'UserLocation',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here
                 // 2do: figure out how the log files are related to this run. Probably need to
                 // build a logs directory for each run with a name chosen by execute testcase.

                 return true;
             });
        },


        /**
          * polyLineChk
          * checks polyline rendering
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="polyLineChk"] - polyLineChk test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        polyLineChk: function polyLineChk(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'PolyLineChk',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here

                 return true;
             });
        },


        /**
          * tileOverlay
          * verifies the rendering of a bitmap tile overlay
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="tileOverlay"] - tileOverlay test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="HybridFlyover"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        tileOverlay: function tileOverlay(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'TileOverlay',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'HybridFlyover'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here

                 return true;
             });
        },


        /**
          * customAnnotation
          * Verifies the appearance of a custom annotation
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="customAnnotation"] - customAnnotation test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        customAnnotation: function customAnnotation(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'CustomAnnotation',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here

                 return true;
             });
        },


        /**
          * snapShotter
          * Verify that MKsnapShotter creates a bitmap given a MKCamera and MKMapView
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="snapShotter"] - snapShotter test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        snapShotter: function snapShotter(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'SnapShotter',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here

                 return true;
             });
        },

        /**
          * launchMapsApp
          * Verify that the maps app launches with expected initial settings
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="launchMapsApp"] - launchMapsApp test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          * @param {string} [args.DirectionsType="Driving"] - Type of directions desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        launchMapsApp: function launchMapsApp(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'LaunchMapsApp',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid',
                  DirectionsType: 'Driving'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                 // Check log files or other validation here

                 return true;
             });
        },
        /**
          * pinDragCheck
          * Verify user pin drag
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="pinDragCheck"] - pinDragCheck test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        pinDragCheck: function pinDragCheck(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'PinDragCheck',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                return true;
             });
        },
        /**
          * polygonCheck
          * Verify polygon overlay
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="polygonCheck"] - polygonCheck test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        polygonCheck: function polygonCheck(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'PolygonCheck',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                return true;
             });
        },
        /**
          * circleCheck
          * Verify rendering of circle overlays
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="circleCheck"] - circleCheck test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="HybridFlyover"] - Type of map desired
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        circleCheck: function circleCheck(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'CircleCheck',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'HybridFlyover'
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {

                return true;
             });
        },

        /**
          * searchAutocomplete
          * Verify search autocomplete
          *
          * @targetApps MKPlatformValidator
          *
          * @param {object} args - Test arguments
          * @param {string} [args.TestCase="searchAutocomplete"] - searchAutocomplete test case
          * @param {string} [args.LogFileDir="/tmp/runlogs"] - Place to put the log files produced by the test case
          * @param {string} [args.MapType="Hybrid"] - Type of map desired
          * @param {string} [args.QueryFragment="Eiffel"] - Query used for generating the list of suggested results
          * @param {string} [args.InAutomation="1"] - Signal to the app that we are running in automation
          *
          * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapKitAlertHandler
          */

        searchAutocomplete: function searchAutocomplete(args) {
            args = UIAUtilities.defaults(args, {
                  URLTestField: 'SearchAutocomplete',
                  LogFileDir: '/tmp/runlogs',
                  MapType:    'Hybrid',
                  QueryFragment: 'Eiffel',
                  InAutomation: '1',
              });

            args.LogFileDir = mapkit.buildLogDirName(args);
            UIALogger.logDebug("logfiledir: %0".format(args));
            return mapkit.executeTestCase(args, function() {
                // verify presence of a pin annotation on the map, representing the
                // first search result that matches the query fragment input
                return target.activeApp().exists(UIAQuery.contains(args.QueryFragment));
             });
        },
    };
}
