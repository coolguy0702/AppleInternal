load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('AppleWatch.js');

function globStringToRegex(str) {
    return preg_quote(str).replace(/\\\*/g, '.*').replace(/\\\?/g, '.') /*, 'g') */ ;
}

function preg_quote(str, delimiter) {
    // http://kevin.vanzonneveld.net
    // +   original by: booeyOH
    // +   improved by: Ates Goral (http://magnetiq.com)
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Onno Marsman
    // +   improved by: Brett Zamir (http://brett-zamir.me)
    // *     example 1: preg_quote("$40");
    // *     returns 1: '\$40'
    // *     example 2: preg_quote("*RRRING* Hello?");
    // *     returns 2: '\*RRRING\* Hello\?'
    // *     example 3: preg_quote("\\.+*?[^]$(){}=!<>|:");
    // *     returns 3: '\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!\<\>\|\:'
    return (str + '').replace(new RegExp('[.\\\\+*?\\[\\^\\]$(){}=!<>|:\\' + (delimiter || '') + '-]', 'g'), '\\$&');
}

if (typeof MapKit === 'undefined') {

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    Alerts = {
        AUTHORIZE_URL_SCHEME: UIAQuery.alerts('Open in "MKPlatformValidator-IOS"'),
        MKPV_ALERT: UIAQuery.alerts().contains('info:'),
        CHECKPOINT: UIAQuery.alerts().contains('info:').andThen(UIAQuery.staticTexts().contains('Checkpoint')),
        COMPLETED: UIAQuery.alerts().contains('info:').andThen(UIAQuery.staticTexts().contains('Completed')),
        TIMED_OUT: UIAQuery.alerts().contains('info:').andThen(UIAQuery.staticTexts().contains('Test timed out')),
        MANUAL_PIN_MOVE: UIAQuery.alerts().contains('Move Pin').andThen(UIAQuery.staticTexts().contains('manual')),
        LOCATION_MANAGER: UIAQuery.alerts().contains('MKPlatformValidator-IOS'),
        SELECT_DIRECTIONS_MODE: UIAQuery.alerts().contains('Select Direction Type'),
        LAUNCH_MAPS: UIAQuery.alerts().contains('Launch Maps'),
        MOVE_PIN: UIAQuery.alerts().contains('Move Pin'),
        SEARCH_AUTOCOMPLETE: UIAQuery.alerts().contains('Enter query fragment'),
    };

    Buttons = {
        OPEN: UIAQuery.alerts().andThen(UIAQuery.buttons('Open')),
        OK: UIAQuery.alerts().andThen(UIAQuery.buttons('OK')),
        MAPS_BACK: UIAQuery.buttons().contains('MKPlatformValidator-IOS'),
        ALLOW: UIAQuery.alerts().andThen(UIAQuery.buttons(LocStrings.LOCATION_ALLOW)),
    };

    DirectionsMode = {
        'Driving': UIAQuery.query('TransportTypePicker').andThen(UIAQuery.buttons()).atIndex(0),
        'Walking': UIAQuery.query('TransportTypePicker').andThen(UIAQuery.buttons()).atIndex(1),
        'Transit': UIAQuery.query('TransportTypePicker').andThen(UIAQuery.buttons()).atIndex(2),
        'Default': UIAQuery.query('TransportTypePicker').andThen(UIAQuery.buttons()).atIndex(3),
    };

    Markers = {
        DROPPED_PIN_MARKER: UIAQuery.query("MKNewAnnotationContainerView").andThen(UIAQuery.query("Map pin")),
    };

    State = {
        DEFAULT: 0,
        PIN_DRAG: 1,
        LAUNCHING_MAPS: 2,
        FINISHED: 3,
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/

    var MK_BUNDLE_ID = 'com.apple.MKPlatformValidator-IOS';
    var MAPS_BUNDLE_ID = 'com.apple.Maps';
    var STAGING_DIRECTORY = '/tmp/MKPVrunlogs';
    var MAPKIT_WATCH_APP_NAME = 'MKPlatformValidator-watchOS';
    var MAPKIT_IOS_APP_NAME = 'MKPlatformValidator-IOS';
    var SHOW_WATCH_APP_SUBSTRING = 'Watch';

    /**
        @namespace
        @augments UIAApp
    */

    var mapkit = target.appWithBundleID(MK_BUNDLE_ID);
    var maps = target.appWithBundleID(MAPS_BUNDLE_ID);

    mapkit.getContainerDir = function getContainerDir(appname) {
        var command = performTask('/usr/local/bin/mobile_install', ["lookup", appname]);
        var lines = (command.stdout + command.stderr).match(/^.*((\r\n|\n|\r)|$)/gm);
        var line = null;

        for (var i = 0; i < lines.length; i++) {
            if (lines[i].match(/\sHOME/)) {
                substrs = lines[i].split(/^\s*HOME\s=\s/);
                dirname = substrs[substrs.length - 1].replace(/;\n$/, '');
                dirname = dirname.replace(/(^")|("$)/g, '');
                return dirname;
            }
        }

        return 'Not Found';
    };

    var ContainerDir = mapkit.getContainerDir(MK_BUNDLE_ID);

    mapkit.buildLogDirName = function buildLogDirName(args) {
        var now = new Date();

        // Uniquify the directory

        var datestring = [
            [('0' + now.getDate()).slice(-2),
                ('0' + (now.getMonth() + 1)).slice(-2),
                now.getFullYear()
            ].join('_'), [('0' + now.getHours()).slice(-2),
                ('0' + now.getMinutes()).slice(-2),
                ('0' + now.getSeconds()).slice(-2)
            ].join("_")
        ].join("_");

        var logdirname = [args.LogFileDir, [args.TestCase, datestring].join("_")].join("/");

        return logdirname;
    };

    /****************************************************************
     *
     * Opens the first file in the list that matches the regular expression.
     *
     */

    mapkit.openWildcard = function openWildcard(dirname, wildcard) {
        dirname = [ContainerDir, dirname].join('/');

        var command = performTask('/bin/ls', ["-A", dirname]);
        var candidates = (command.stdout + command.stderr).match(/^.*((\r\n|\n|\r)|$)/gm);

        wildcard = globStringToRegex(wildcard); // Replaces all instances of '*' with the regex .* (any number of any character)
        // wildcard = wildcard.replace(/?/\.+/g); // Replaces all instances of '?' with the regex .+ (one instance of any character)
        // wildcard = wildcard.replace(/\./\\\./g);  // Replaces all instances of '.' with the regex \. (dot is not part of the regex, just the filename)
        // wildcard = wildcard.replace(/$/\//);
        // wildcard = wildcard.replace(/^/\//);
        UIALogger.logDebug("wildcard: [%0]".format(wildcard));
        var re = new RegExp(wildcard); // We need to see if this is what we want. We would
        // like to be able to say things like 'fiilename*'
        // without having to say 'filename.* to indicate any character

        UIALogger.logDebug("logdir: [%0]".format(dirname));
        UIALogger.logDebug("files: %0".format(candidates));

        for (var idx in candidates) {
            var candidate = candidates[idx];
            candidate = candidate.replace(/\n/, '');

            UIALogger.logDebug("candidate: %0".format(candidate));
            if (candidate.match(re)) {
                UIALogger.logDebug("files: %0 matches".format(candidate));
                var objf = UIAFile.open(dirname + "/" + candidate, 'r');
                var obj_str = objf.read();
                return obj_str;
            }
        }

        return wildcard + ' Not Found';
    };

    mapkit.stageLogFiles = function stageLogFiles(baseDirectory, fileMask) {
        performTask('/bin/mkdir', ["-p", STAGING_DIRECTORY]);
        var fullPath = ContainerDir + baseDirectory;
        var sourceFile = [fullPath, fileMask].join('/');
        UIALogger.logMessage( "Copying LogFileType:%0".format(fileMask) + " to STAGING_DIRECTORY:%0".format(STAGING_DIRECTORY));
        performTask('/bin/bash', ['-c', 'cp ' + sourceFile + ' ' + STAGING_DIRECTORY]);
    };

    mapkit.copyInvocationLogs = function copyInvocationLogs(dirName) {
        mapkit.stageLogFiles(dirName, 'invocation*');
    };

    mapkit.copyStatusLog = function copyStatusLog(dirName) {
        mapkit.stageLogFiles(dirName, 'statusView.log');
    };

    mapkit.buildURL = function buildURL(args) {
        var urlstr = 'MKPlatformValidator://';

        // Build the URL -- 2Do: put this in a function

        var argstr = '';
        if (Object.keys(args).length > 0) {
            var first = true;
            var keyset = Object.keys(args);
            for (var idx in keyset) {
                thiskey = keyset[idx];
                if (thiskey === 'TestCase') continue;
                if (thiskey === 'URLTestField') {
                    argstr = args.URLTestField + argstr;
                } else {
                    if (first) {
                        argstr += '?';
                        first = false;
                    } else {
                        argstr += '&';
                    }
                    argstr += thiskey;
                    argstr += '=';
                    argstr += encodeURIComponent(args[thiskey]);
                }
            }
            urlstr += argstr;
        }
        return urlstr;
    };

    /**
     * Launches the app with the given URL and options
     *
     * @param {string} url Url to open launch the maps app with
     * @param {object} options An options dictionary
     * @param {boolean} [options.commandArgs=[]] Any additional arguments for LaunchApp
     */
    mapkit.launchWithURL = function launchWithURL(url, options) {
        options = UIAUtilities.defaults(options, {
            commandArgs: [],
        });

        UIALogger.logMessage('In launch with url = "%0" options="%1"'.format(url, options));
        var launchAppArgs = ["-url", url];
        launchAppArgs.push.apply(launchAppArgs, options.commandArgs);
        UIALogger.logMessage('In launch with launchappargs=%0'.format(launchAppArgs));
        var shellResponse = performTask("/usr/local/bin/LaunchApp", launchAppArgs, 15);

        UIALogger.logMessage('App Crash Handler');
        UIALogger.logMessage('MKPV is Active: %0'.format(mapkit.isActive()));
        var waiter = UIAWaiter.withPredicate(
            "ApplicationStateChanged",
            "bundleID == \"com.apple.MKPlatformValidator-IOS\" AND state = \"Terminated\""
        );
        if (waiter.wait(10)) {
             shellResponse = performTask("/usr/local/bin/LaunchApp", launchAppArgs, 15);
        }

        if (shellResponse.stdout.includes("Unable to open URL")) {
            throw new UIAError("Unable to open URL %0. Please ensure the app is installed on the device.".format(url));
        }
        if (shellResponse.stdout) {
            UIALogger.logMessage("LaunchApp stdout: %0".format(shellResponse.stdout));
        }
        if (shellResponse.stderr) {
            UIALogger.logMessage("LaunchApp stderr: %0".format(shellResponse.stderr));
        }
        if (shellResponse.signal) {
            UIALogger.logMessage("LaunchApp signal: %0".format(shellResponse.signal));
        }
        if (shellResponse.exitCode !== 0) {
            UIALogger.logMessage("LaunchApp exitCode: %0".format(shellResponse.exitCode));
        }
        // The first time we will get an alert that has to be satisfied.
        // Later it won't occur, but if it doesn't we need to handle it
        mapkit.waitUntilReady();
    };

    mapkit.getMessageFromAlert = function getMessageFromAlert(app) {

        if (app.exists(Alerts.CHECKPOINT)) {
            return app.inspect(Alerts.CHECKPOINT).name;
        } else if (app.exists(Alerts.COMPLETED)) {
            return app.inspect(Alerts.COMPLETED).name;
        } else if (app.exists(Alerts.TIMED_OUT)) {
            return app.inspect(Alerts.TIMED_OUT).name;
        } else {
            throw new UIAError('Unrecognized Alert text');
        }
    };

    mapkit.improveMapKitAlertHandler = function improveMapKitAlertHandler() {
        UIALogger.logMessage('improveMapKitAlertHandler: Start');
        var app = target.activeApp();
        UIALogger.logMessage("app name: %0".format(app.name()));

        if (app.exists(Alerts.MKPV_ALERT)) {
            mapkit.processCheckpointAlert(app);
        } else if (app.exists(Alerts.LOCATION_MANAGER)) {
            UIALogger.logMessage('App requesting access from CLLocationManager');
            return app.tapIfExists(Buttons.ALLOW);
        } else if (app.exists(Alerts.SELECT_DIRECTIONS_MODE)) {
            UIALogger.logMessage('Setting directions mode');
            return app.tapIfExists(UIAQuery.query(this.args.DirectionsType));
        } else if (app.exists(Alerts.LAUNCH_MAPS)) {
            UIALogger.logMessage('Launching the maps app');
            this.state = State.LAUNCHING_MAPS;
            // have the state machine tap the OK button
            return true;
        } else if (app.exists(Alerts.MOVE_PIN)) {
            UIALogger.logMessage('Moving annotation pin');
            if (this.exists(Alerts.MANUAL_PIN_MOVE)) {
                this.state = State.PIN_DRAG;
            }
        } else if (app.exists(Alerts.SEARCH_AUTOCOMPLETE)) {
            UIALogger.logMessage('Accepting defaults in search autocomplete');
        } else {
            // let the base alert handler deal with this one
            return false;
        }
        return app.tapIfExists(Buttons.OK);
    };

    mapkit.verifyRouteMode = function verifyRouteMode() {
        var modeButton = DirectionsMode[this.args.DirectionsType];

        if (maps.inspect(modeButton).isSelected) {
            UIALogger.logPass('Expected Route Mode "%0" selected'.format(this.args.DirectionsType));
        } else {
            throw new UIAError('Expected Route Mode "%0" not selected'.format(this.args.DirectionsType));
        }
    };

    mapkit.processCheckpointAlert = function processCheckpointAlert(app) {
        var alert = app.inspect(Alerts.MKPV_ALERT);

        var alertMessage = this.getMessageFromAlert(app);

        if (alert && alertMessage) {
            UIALogger.logMessage('Checkpoint alert Received title: %0'.format(alert.label));
            UIALogger.logMessage('Checkpoint alert Received message: %0'.format(alertMessage));

            var messageType = alertMessage.match(/^(Checkpoint|Completed|Test timed out)/g);
            if (messageType.length === 0) {
                UIALogger.logInfo('Unrecognized checkpoint message: %0'.format(alertMessage));
                return false;
            }
            var status;

            // current alert message format is
            // for Checkpoints:
            // "Checkpoint 1 (Checkpoint Description): [Success|Fail]"
            // for test completion:
            // "Completed: Test Name, status [PASS|FAIL]"
            switch (messageType[0]) {
                case 'Checkpoint':
                    var checkpointName = alertMessage.match(/^Checkpoint [0-9]*/g)[0];
                    var checkpointDescription = alertMessage.match(/\(([^\)]+)\)/g); // reg-ex for text within parenthesis
                    status = alertMessage.match(/(Success|Fail)$/g)[0];
                    if (status === 'Fail') {
                        this.lastError = checkpointName + ' failed : ' + checkpointDescription;
                        UIALogger.logFail(this.lastError);
                    } else {
                        UIALogger.logPass(checkpointName + ' passed : ' + checkpointDescription);
                    }
                    break;
                case 'Completed':
                    UIALogger.logMessage(alertMessage);
                    status = alertMessage.match(/(PASS|FAIL)$/g)[0];
                    UIALogger.logMessage('Completed alert found. %0'.format(status));
                    if (status === 'FAIL') {
                        app.tapIfExists(Buttons.OK);
                        throw new UIAError('Test failed. %0'.format(this.lastError ? this.lastError : ''));
                    }
                    this.state = State.COMPLETED;
                    break;
                case 'Test timed out':
                    UIALogger.logFail(alertMessage);
                    this.lastError = alertMessage;
                    break;
                default:
                    UIALogger.logMessage('Unrecognized message type: ' + messageType);
                    break;
            }
        }
    };
    /**
     * executes the test case according to the specifications in the dictionary <args>.
     * Calls validateAlerts to determine that the test case succeded.
     * is optionally passed a function returning boolean which performs any additional validator required
     * for example examining log files after the run completes.
     *
     * @param {object} options An options dictionary
     * @param {function} [options.commandArgs=[]] Any additional arguments for LaunchApp
     *
     * @alertHandlers springboard.standardAlertHandler, mapkit.improveMapsAlertHandler
     */

    mapkit.executeTestCase = function executeTestCase(args, customValidation) {
        this.args = args;
        this.customValidation = customValidation;
        this.withAlertHandler(this.improveMapKitAlertHandler, this.launchAndCleanUp);
    };

    mapkit.launchAndCleanUp = function launchAndCleanUp() {

        try {
            UIALogger.logMessage('launchAndCleanUp Start');

            if (mapkit.isActive())
            {
              UIALogger.logMessage('MKPV Active in Foreground: Reuse the same');
            }
            else {
              UIALogger.logMessage('killing the MKPV process');
              performTask('/usr/bin/killall', ['MKPlatformValidator-IOS']);
            }

            this.launchWithURL(this.buildURL(this.args), '{}');
            this.state = State.DEFAULT;
            var startTime = new Date();

            while (this.state !== State.COMPLETED) {

                var endTime = new Date();
                // give the UIA2 script ten seconds more than we give the app to process timeout related alerts
                if ((endTime - startTime) / 1000 > (this.args.TestTimeout + 10)) {
                    throw new UIAError('Test did not complete before timout value of %0 seconds'.format(this.args.TestTimeout));
                }

                switch (this.state) {
                    case State.PIN_DRAG:
                        UIALogger.logMessage('start of manual pin drag');
                        if (!this.exists(Markers.DROPPED_PIN_MARKER)) {
                            throw new UIAError('unable to find annotation pin');
                        }
                        var options = {
                            holdDuration: 2,
                            toQuery: UIAQuery.application(),
                            toOffset: {
                                x: 0.5,
                                y: 0.9
                            }
                        };
                        // why do we need to call drag twice? pending radar for this issue.
                        this.drag(Markers.DROPPED_PIN_MARKER, options);
                        this.drag(Markers.DROPPED_PIN_MARKER, options);
                        this.state = State.DEFAULT;
                        break;
                    case State.LAUNCHING_MAPS:
                        UIALogger.logMessage('launching Maps');
                        maps.waitToBecomeActive(120, function() {
                            mapkit.tapIfExists(Buttons.OK);
                        });
                        maps.waitUntilReady();
                        // wait inside the maps app for an additional 10 seconds
                        maps.delay(10);
                        this.verifyRouteMode();
                        // tap the "back" button in maps to return to MKPV
                        mapkit.waitToBecomeActive(120, function() {
                            if (!maps.exists(Buttons.MAPS_BACK)) {
                                UIALogger.logMessage(tree());
                                throw new UIAError('Unable to find back button in Maps');
                            }
                            maps.tap(Buttons.MAPS_BACK);
                        });
                        // target.activeApp() should by now be MKPlatformValidator, but older hardware takes
                        // time to update the value. Wait here a bit before proceeding. rdar://problem/27928807
                        now = new Date().getTime();
                        while(new Date().getTime() < now + 2000){ /* do nothing */ }

                        this.state = State.DEFAULT;
                        break;
                    case State.DEFAULT:
                        UIALogger.logMessage('default Handler');
                        var waiter = UIAWaiter.withPredicate(
                            'ViewDidAppear',
                            'controllerClass = "UIAlertController"'
                        );
                        if (!waiter.wait(0.5)) {
                            mapkit.handlingAlertsInline(UIAQuery.alerts(), function() {
                                this.improveMapKitAlertHandler();
                            });
                        }
                        break;
                    case State.COMPLETED:
                        break;
                    default:
                        throw new UIAError('Unexpected state: %0'.format(this.state));
                }
            }
        } finally {
            UIALogger.logMessage('Copying Custom MKPV Logs');
            this.copyStatusLog(this.args.LogFileDir);
            this.copyInvocationLogs(this.args.LogFileDir);
        }

        if (this.customValidation) {
            this.customValidation();
        }
    };

    /**
     *  Launching the app via URL for the first time (MKPlatformValidator://) requires the user to
     *  accept an alert. This is a bit unreliable - sometimes the alert does not appear
     *  and the app does not launch. To help our chances, retry the launch a few times until we see the alert.
     */
    mapkit.authorizeMapkitPlatformValidatorURL = function authorizeMapkitPlatformValidatorURL() {

        var i = 1;
        this.withAlertHandler(function() {
                target.activeApp().tapIfExists(Buttons.OPEN);
                return true;
            },
            function() {
                this.handlingAlertsInline(Alerts.AUTHORIZE_URL_SCHEME, function() {
                    UIALogger.logMessage("launching app with no arguments, attempt %0".format(i++));
                    this.launchWithURL(this.buildURL({}), '{}');
                    target.activeApp().tapIfExists(Buttons.OPEN);
                    UIALogger.logMessage("URL authorization complete");
                });
            });
    };

    mapkit.pushMapkitPlatformValidatorToWatch = function pushMapkitPlatformValidatorToWatch() {

        appleWatch.launch();
        appleWatch.getToMyWatchRootView();
        if (appleWatch.exists(UIAQuery.staticTexts(MAPKIT_WATCH_APP_NAME))) {
            appleWatch.tap(UIAQuery.staticTexts(MAPKIT_WATCH_APP_NAME));
        } else {
            throw new UIAError('%0 app is not installed, or no watch is paired'.format(MAPKIT_WATCH_APP_NAME));
        }

        var showAppSwitch = appleWatch.inspect(UIAQuery.switches().contains(SHOW_WATCH_APP_SUBSTRING));
        if (showAppSwitch !== undefined && showAppSwitch !== null) {
            if (showAppSwitch.value !== 1) {
                appleWatch.tap(UIAQuery.switches().contains(SHOW_WATCH_APP_SUBSTRING));
            }
        } else {
            throw new UIAError('expecting %0'.format(SHOW_WATCH_APP_SUBSTRING));
        }
    };
}
