App/Project/Feature: MapKit
Maintainer(s): Chris Paulse, Tarun Phaugat, Kyle Burg
Maintainer(s) Email: tphaugat@apple.com, cpaulse@apple.com, kburg@apple.com
Maintainer(s) Team: Maps Eval
Maintainer(s) Team Manger: Wali Sultani
Maintainer(s) Team Manger Email: asultani@apple.com
Scripts for automating MapKit framework's test app - "MKPlatformValidator"
