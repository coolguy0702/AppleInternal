load('UIAApp.js');
load('SpringBoard.js');
load('CoreAutomation.js');
load('PowerPerfSettings.js');
load('Settings+Accounts.js');
load('UIATesting.js');

/*jshint strict:false, unused:true, eqnull:true, sub:true, -W008 */

UIAUtilities.assert(
  typeof PodcastsQA === 'undefined',
  'Podcasts has already been defined.'
);



/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App-specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/


/** Constants for common Podcasts queries */
UIAQuery.Podcasts = {

	// TAB BAR
	LISTEN_NOW_TAB:	UIAQuery.buttons('Listen Now'),
	LIBRARY_TAB: 	UIAQuery.buttons('Library'),
	BROWSE_TAB:		UIAQuery.buttons('Browse'),
	SEARCH_TAB: 	UIAQuery.buttons('Search'),

	// LISTEN NOW
	LISTEN_NOW_VIEW:	UIAQuery.navigationBars('Listen Now'),
	LISTEN_NOW_LOCKUP:	UIAQuery.query("PodcastsUI.LargeLockupCollectionViewCell")/*.isVisible()*/,
	// LIBRARY 
	LIBRARY_VIEW:  		UIAQuery.query('UILabel').andThen('Library'),
	SHOWS_CELL: 			UIAQuery.tableCells().andThen(UIAQuery.query('Shows')),
	EPISODES_CELL: 			UIAQuery.tableCells().andThen(UIAQuery.query('Episodes')),
	DOWNLOADED_CELL: 		UIAQuery.tableCells().andThen(UIAQuery.query('Downloaded')),
	ADD_PODCAST_BUTTON : 	UIAQuery.contains('Add a Podcast by URL'),
	// LIBRARY SUB VIEWS
	LIBRARY_EDIT: 			UIAQuery.buttons("Done").isVisible(),
	SHOWS:					UIAQuery.collectionViews().andThen(UIAQuery.query('Shows')),
	DOWNLOADED_EPISODES: 	UIAQuery.collectionViews().andThen(UIAQuery.query('Downloaded Episodes')),
	RECENTLY_UPDATED: 		UIAQuery.tableCells().andThen(UIAQuery.query('Recently Updated')),
	CONTAINER_EPISODE_CELL : UIAQuery.query('PodcastsUI.EpisodeView'),
	CONTAINER_EPISODE_WITH_BEST : UIAQuery.query('PodcastsUI.EpisodeView').above(UIAQuery.query('Best of the' +
        ' Podcast')), // Get episodes from podcast container that are in the library
	STATION_EPISODE_CELL   : UIAQuery.tableCells().contains(', '),
	PODCAST_CONTAINER	   : UIAQuery.tableCells(),
    PODCAST_DETAILS_NAV_BAR: UIAQuery.navigationBars(),
    CONTAINER_QUICKPLAY:	 UIAQuery.query("PodcastsUI.QuickPlayView").andThen(UIAQuery.buttons("Play")),
    

	// BROWSE
	BROWSE_VIEW:	 UIAQuery.navigationBars('Browse'),
	FEATURED_LOCKUP: UIAQuery.tableCells().andThen(
					 	UIAQuery.query('PodcastsUI.EditorialCardCollectionViewCell')),
	FEATURED_CELL:   UIAQuery.tableCells().andThen(UIAQuery.query('Featured')),
	TOP_CHARTS_CELL: UIAQuery.tableCells().andThen(UIAQuery.query('Top Charts')),
	FEATURED_PROVIDERS_CELL: UIAQuery.tableCells().andThen(UIAQuery.query('Featured Providers')),
	ALL_CATEGORIES_CELL: 	 UIAQuery.tableCells().andThen(UIAQuery.query('All Categories')),
	// BROWSE SUBVIEWS
	FEATURED:		UIAQuery.query('PodcastsUI.TitleHeaderView').andThen(
						UIAQuery.query('Featured')),
	NEW_NOTEWORTHY: UIAQuery.query('PodcastsUI.TitleHeaderView').andThen(
						UIAQuery.query('New & Noteworthy')),
	TOP_CHARTS: 	UIAQuery.query('PodcastsUI.TitleHeaderView').andThen(
						UIAQuery.query('Top Charts')),
	ALL_CATEGORIES: UIAQuery.query('PodcastsUI.TitleHeaderView').andThen(
						UIAQuery.query('Categories')),
	FEATURED_PROVIDERS: UIAQuery.query('PodcastsUI.TitleHeaderView').andThen(
							UIAQuery.query('Featured Providers')),
	CATEGORIES_BUTTON:	UIAQuery.navigationBars().andThen(UIAQuery.buttons(
							'All Categories')),
	CATEGORIES_PAGE_NAVBAR : UIAQuery.navigationBars('Categories'),

	// SEARCH
	SEARCH: 		UIAQuery.query('PodcastsUI.SearchHeaderView'),
	SEARCH_FIELD:	UIAQuery.query("UITextField"),

	// NOW PLAYING
	NOW_PLAYING:	UIAQuery.query("NowPlayingScreen"),
	TRACK_POSITION: UIAQuery.query("NowPlayingUI.NowPlayingControlsHeader").andThen(
						UIAQuery.query('Track position')),
	DISMISS_BUTTON: UIAQuery.buttons('Dismiss Now Playing Screen'),
	REW15_BUTTON: 	UIAQuery.buttons('15 seconds rewind'),
	FF15_BUTTON: 	UIAQuery.buttons('15 seconds fast forward'),
	// Must be specific here due to QuickPlay button, which can still be seen behind NP
	PLAY_BUTTON: 	UIAQuery.query(
						"NowPlayingUI.NowPlayingTransportControlStackView").andThen(
						UIAQuery.buttons('Play')),
	PAUSE_BUTTON: 	UIAQuery.query(
						"NowPlayingUI.NowPlayingTransportControlStackView").andThen(
						UIAQuery.buttons('Pause')),
	VOLUME_SLIDER: 	UIAQuery.sliders('Volume'),
	SPEED_BUTTON: 	UIAQuery.buttons('Playback speed'),
	AIRPLAY_BUTTON: UIAQuery.buttons('Playback  Destination'),
	MORE_BUTTON: 	UIAQuery.query("NowPlayingUI.NowPlayingControlsHeader").andThen(
						UIAQuery.buttons('More')), /* simple buttons() query may not work */
						
	// LOCKSCREEN AND CONTROL CENTER
	LS_PLAY_BUTTON:		UIAQuery.query('MediaControlsTransportStackView').isVisible().andThen(UIAQuery.buttons('Play')),
 	LS_FFBUTTON: 		UIAQuery.query("MediaControlsTransportStackView").isVisible().andThen(UIAQuery.buttons('Fast Forward')),
 	LS_REWINDBUTTON: 	UIAQuery.query("MediaControlsTransportStackView").isVisible().andThen(UIAQuery.buttons('Rewind')),
  	LS_PAUSE_BUTTON: 	UIAQuery.query("MediaControlsTransportStackView").isVisible().andThen(UIAQuery.buttons("Pause")),

	// Control Center references
	CONTROL_CENTER      : UIAQuery.query('CCUIControlCenterPagePlatterView'),
	CONTROL_CENTER_PLAY : UIAQuery.query('Play'),
	// Have to set the pause button value to Play for now due to <rdar://problem/26146258> Pause and Play Button in
	// Control Center Are Both Called "Play"
	CONTROL_CENTER_PAUSE : UIAQuery.query('Pause'),
	CONTROL_CENTER_15FF  : UIAQuery.query('Fast Forward'),
	CONTROL_CENTER_15RW  : UIAQuery.query('Rewind'),
	CONTROL_CENTER_VOLUME : UIAQuery.sliders('Volume'),

    // Welcome splash screen
    PRIVACY_ALERT_START_BUTTON : UIAQuery.buttons('Start Listening Now'),
    PRIVACY_ALERT_HEADER       : UIAQuery.query('Welcome to Podcasts'),

    // TIGRIS TODO - do these still apply?
	SHARE_BUTTON:			UIAQuery.buttons("Share"),
	FULLSCREEN_VID:			UIAQuery.buttons('Full Screen video'),
	PIP_BUTTON:  			UIAQuery.buttons('Picture in picture'),
	SLEEP_TIMER_BUTTON:		UIAQuery.buttons().contains('Sleep timer'),
	SLEEP_OFF:				UIAQuery.buttons('Off'),
	SLEEP_IN_5 :  			UIAQuery.buttons('In 5 Minutes'),
	SLEEP_IN_10:			UIAQuery.buttons('In 10 Minutes'),
	SLEEP_IN_15:			UIAQuery.buttons('In 15 Minutes'),
	SLEEP_IN_30:			UIAQuery.buttons('In 30 Minutes'),
	SLEEP_IN_45:			UIAQuery.buttons('In 45 Minutes'),
	SLEEP_IN_1_HOUR:		UIAQuery.buttons('In One Hour'),
	SLEEP_AT_END:			UIAQuery.buttons('When Current Episode Ends'),
	PIP_WINDOW:				UIAQuery.windows('Picture in Picture').orElse(UIAQuery.contains('PIPUIView')).orElse(
							UIAQuery.query('PIP-SBInteractionPassThroughView')),
	// todo
	DISMISS_POPUP:			UIAQuery.query('dismiss popup'),

	 // MINI PLAYER BUTTONS
	MINIPLAYER_MINI:	UIAQuery.query('MiniPlayer'),
	PLAY_BUTTON_MINI:	UIAQuery.query('MiniPlayer').andThen(UIAQuery.buttons('Play')),
    PAUSE_BUTTON_MINI:  UIAQuery.query('MiniPlayer').andThen(UIAQuery.buttons('Pause')),
    FF15_BUTTON_MINI:	UIAQuery.query('MiniPlayer').andThen(UIAQuery.buttons('15 seconds fast forward')),
    TRACK_TITLE_MINI:   UIAQuery.query("NowPlayingSongTitleBar"),
	ARTWORK_MINI:		UIAQuery.query('MiniPlayer').andThen(UIAQuery.query('Album Artwork')),

	// BUTTONS
	DONE_BUTTON:	UIAQuery.buttons('Done'),

	// PODCAST ITEMS
    PODCAST_ACTION_MENU 	  :	UIAQuery.query("More"),
    	// WAS: UIAQuery.query('Artwork').siblings().andThen(UIAQuery.buttons('More')),
	PODCAST_ACTION_PLAY_NEXT  : UIAQuery.buttons('Play Next'),
	PODCAST_ACTION_PLAY_LATER : UIAQuery.buttons('Play Later'),
	PODCAST_ACTION_SHARE      : UIAQuery.buttons('Share'),
	PODCAST_ACTION_SETTINGS   : UIAQuery.buttons('Settings'),
    PODCAST_SETTINGS_WINDOW   : UIAQuery.navigationBars('Settings'),
	DELETE_BUTTON_IN_SHOWS    : UIAQuery.buttons('UIRemoveControlMinus'),

	/* Podcast settings */
    PODCAST_SETTINGS_ORDER        : UIAQuery.staticTexts('Episode Order'),
    PODCAST_SETTINGS_REFRESH      : UIAQuery.staticTexts('Refresh Every'),
    PODCAST_SETTINGS_LIMIT        : UIAQuery.staticTexts('Limit Episodes'),
    PODCAST_SETTINGS_DOWNLOAD     : UIAQuery.staticTexts('Download Episodes'),
    PODCAST_SETTINGS_DELETE       : UIAQuery.staticTexts('Delete Played Episodes'),
    PODCAST_SETTINGS_SUBSCRIBED   : UIAQuery.switches('Subscribed'),
    PODCAST_SETTINGS_NOTIFICATIONS: UIAQuery.switches('Notifications'),
	PODCAST_SETTINGS_SEQ_ORDER    : UIAQuery.staticTexts('Play in Sequential Order').parent(),
	PODCAST_SETTINGS_REC_FIRST    : UIAQuery.staticTexts('Play Most Recent First').parent(),
	PODCAST_SETTINGS_KEEP_RECENT  : UIAQuery.staticTexts('Only Keep the Most Recent Episodes').parent(),
	PODCAST_SETTINGS_CUSTOM       : UIAQuery.staticTexts('Custom Settings').parent(),
	/* Podcast Settings Navbars */
    PODCAST_SETTINGS_PLAY_NAVBAR : UIAQuery.navigationBars('Episode Order'),
    PODCAST_SETTINGS_REFRESH_NAVBAR : UIAQuery.navigationBars('Refresh Every'),
    PODCAST_SETTINGS_LIMIT_NAVBAR : UIAQuery.navigationBars('Limit Episodes'),
    PODCAST_SETTINGS_DOWNLOAD_NAVBAR : UIAQuery.navigationBars('Download Episodes'),
    PODCAST_SETTINGS_DELETE_NAVBAR : UIAQuery.navigationBars('Delete Played Episodes'),

	// STORE BUTTONS
	SUBSCRIBE: 		UIAQuery.buttons('SUBSCRIBE'),
	SUBSCRIBED: 	UIAQuery.query("PodcastsUI.LibraryStatusLabel").andThen(
						UIAQuery.query("Subscribed")),
	PURCHASE_BUTTON: UIAQuery.buttons("PurchaseButton"), /* tigris delete?*/

	// PRE-TIGRIS REMOVE ------------------------------------------------------------------------------

	// ------------------------- ALL OF THIS IS PRE-TIGRIS ------------------------
	// NAV BAR
	EDIT_NAVBAR: 			UIAQuery.navigationBars().andThen(UIAQuery.buttons('Edit')),
	BACK_NAVBAR: 			UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back')),
		/* Settings Subview */
	SETINGS_NAVBAR:			UIAQuery.navigationBars().andThen(UIAQuery.buttons('Settings')),
		/* Station Settings subview iPhone*/
	STATION_SETINGS_NAVBAR:	UIAQuery.navigationBars().andThen(UIAQuery.buttons('Station Settings')),
	STATION_SETTINGS_MAIN: UIAQuery.query('Settings'),

	// Welcome is shown when there are no podcasts
	WELCOME_NAVBAR:		UIAQuery.navigationBars().andThen(UIAQuery.buttons(
							'Welcome to Podcasts')),
	BACK_NAV_BUTTON : UIAQuery.query('back-nav-button'),
	// Store podcast container - 'Podcasts' is back button in nav bar
	// Podcast providers have their own pages - each has name in nav bar title

	// WHEN NO PODCASTS ARE IN DATABASE - regression test
	NO_PODCASTS_IMAGE : UIAQuery.images('NoPodcastsImage'),

	// LIBRARY SUBVIEWS
	PODCAST_DETAILS : 	UIAQuery.navigationBars().andThen(
							UIAQuery.buttons("My Podcasts")).orElse(
							UIAQuery.navigationBars("MTPodcastDetailView")), // iPad
	PODCAST_SHARE : 	UIAQuery.buttons('Share'),
	PLAYED_TO_BE_DELETED :  UIAQuery.query('Played Episodes to be Deleted'),
	PODCAST_MORE : 			UIAQuery.buttons('More'), // was 'More' ... more button in podcast container
		/* Segmented controls */
	PODCASTS_SEGMENT_UNPLAYED    : UIAQuery.segmentedControls().children().contains('Unplayed'),
	PODCASTS_SEGMENT_MY_EPISODES : UIAQuery.segmentedControls().children().contains('My Episodes'),
	PODCASTS_SEGMENT_FEED        : UIAQuery.segmentedControls().children().contains('Feed'),
	PODCASTS_SEGMENT_SAVED       : UIAQuery.segmentedControls().children().contains('Saved'),

	/** 'Cancel' button */
	CANCEL: 			UIAQuery.buttons("Cancel"),
	// used for currentUI
	UPNEXT:			UIAQuery.query('UINavigationItemView').andThen(UIAQuery.query("Up Next")),

	// STORE
	/** iPad All Categories */
	ALL_CATEGORIES_POPOVER: UIAQuery.buttons("All Categories"),
	SEARCH_POPOVER:			UIAQuery.popovers().andThen(UIAQuery.navigationBars("Suggestions")),

	TOP_CHARTS_AUDIO_CONTROL: UIAQuery.segmentedControls().children('Audio Podcasts'),
	TOP_CHARTS_VIDEO_CONTROL: UIAQuery.segmentedControls().children('Video Podcasts'),

	// DOWNLOAD ERROR ALERT
	DOWNLOAD_ERROR_ALERT: UIAQuery.alerts().contains('Unable to Download Podcast'),

	// CANCEL DOWNLOAD BUTTON
	CANCEL_DOWNLOADS: UIAQuery.buttons().contains('Cancel All'),

	// SUBSCRIBE ERROR ALERTS
	SUBSCRIBE_ERROR_ALERT : UIAQuery.alerts('Unable to Subscribe'),
	NOT_CONNECTED_ALERT : UIAQuery.alerts('Your Device Is Not Connected to the Internet'),
	AIRPLANE_MODE_ALERT : UIAQuery.alerts('Turn Off Airplane Mode or Use Wi-Fi to Access Data'),

	// ALERT BUTTONS
	ADD_PODCAST_ALERT : UIAQuery.alerts('Add a Podcast by URL...'),

	// SEARCH on STORE
	SUBSCRIBE_ALERT:  	UIAQuery.alerts().andThen(UIAQuery.query("Subscribe")),

	// Download bar for Phones
	PHONE_DOWNLOAD_BAR: UIAQuery.tableCells().contains("Downloading").andThen(UIAQuery.contains("Episode")),

	// SHEETS
	CANCEL_BUTTON_SHEET:		UIAQuery.actionSheets().andThen(UIAQuery.buttons("Cancel")),
	ADD_STATION_BUTTON_SHEET:	UIAQuery.actionSheets().andThen(UIAQuery.buttons("Add Station")),

	// Mini - clean up for Tigris
	// GENERAL PLAYBACK CONTROLS

    /* Available on iPad Only */

    // UP NEXT
    	/* iPad only */
    UPNEXT_DONE_BUTTON:		UIAQuery.navigationBars("Up Next").andThen(UIAQuery.buttons('Done')),
	UPNEXT_NAV_BAR : 		UIAQuery.navigationBars('Up Next'),
	UPNEXT_HEADERS:			UIAQuery.query('UITableViewSectionElement'),
    /* to do */

	// CarPlay Queries
	CAR_PLAY_UNPLAYED     : UIAQuery.query('Unplayed').onScreen('CarPlay'),
	CAR_PLAY_LIBRARY  	  : UIAQuery.query('My Podcasts').onScreen('CarPlay'),
	CAR_PLAY_MY_STATIONS  : UIAQuery.query('My Stations').onScreen('CarPlay'),
	CAR_PLAY_TOP_CHARTS   : UIAQuery.query('Top Charts').onScreen('CarPlay'),
	CAR_PLAY_NOW_PLAYING  : UIAQuery.buttons('Now Playing').onScreen('CarPlay'),
	// No other identifiers on CarPlay for these buttons <rdar://problem/24507267> CarPlay Items on the Podcasts Now
	// Playing Screen Do Not Have Unique Identifiers
	CAR_PLAY_PLAY         : UIAQuery.buttons().onScreen('CarPlay').atIndex(4),
	CAR_PLAY_PAUSE        : UIAQuery.buttons().onScreen('CarPlay').atIndex(4),
	CAR_PLAY_FF15         : UIAQuery.buttons().onScreen('CarPlay').atIndex(5),
	CAR_PLAY_REW15        : UIAQuery.buttons().onScreen('CarPlay').atIndex(3),
	CAR_PLAY_BACK		  : UIAQuery.buttons('Back').onScreen('CarPlay'),

	// Episode Cell Buttons
	// Download progress is Download when paused and downloading when not so searching for ownload
	DOWNLOAD_PROGRESS : UIAQuery.buttons().contains('ownload'),
	
	//SIRI
	OPEN_PODCASTS : 		 UIAQuery.buttons('Open Podcasts'),
	PAUSE_CONFIRMED : 		 UIAQuery.query('playMedia#paused'),
	PLAY_CONFIRMED_BY_KIND : UIAQuery.query('playMedia#nowPlayingByType').orElse(
							     UIAQuery.query('playMedia#nowPlayingEpisodesByPodcast')),
	PLAY_CONFIRMED_GENERAL : UIAQuery.query('playMedia#resume'),
	SIRI_MESSAGE : 			 UIAQuery.query('SiriUIContentLabel'),
	SIRI_SUGGESTION : 		 UIAQuery.query('SiriUISuggestionsView'),

	// SHARING
	MESSAGE_BODY :  UIAQuery.contains('messageBodyField'),
	FACEBOOK_BODY : UIAQuery.contains('Message').orElse(UIAQuery.contains('Tweet')),
	TWEET_BODY : 	UIAQuery.textViews('Tweet'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Podcasts */
UIStateDescription.Podcasts = {
	// Tabs are Nav Bar Names
	// ToDoTigris:  there are no navbar names?
	LISTEN_NOW:			'Listen Now',
	LIBRARY:       		'Library',
	BROWSE:            	'Browse',
	SEARCH:            	'Search',
	DOWNLOADS:			'Downloads',
	SETTINGS:			'Settings',  /*ToDoTigris: change*/
	NOW_PLAYING:        'Now Playing',
	// SUB-VIEWS
	SHOWS:				'Shows',
	SHOWS_SETTINGS:		'Show Settings',
	DOWNLOADED_EPISODES:'Downloaded Episodes',
	RECENTLY_UPDATED:	'Recently Updated',
	LIBRARY_EDIT:		'My Podcasts Edit',
	FEATURED:      		'Featured',
	TOP_CHARTS:      	'Top Charts',
	ALL_CATEGORIES:		'All Categories',
	FEATURED_PROVIDERS:	'Featured Providers',

	// LIBRARY Subviews
	PODCAST_DETAILS:		'Podcast Details',

	/** 'No Podcasts' Text */
	NO_PODCASTS:             'You have no podcasts.',
	/** 'New and Noteworthy' Text */
	NEW_NOTEWORTHY:          'New & Noteworthy',
	/** NOTE: this may not be correct */
	TOP_AUDIO_PODCASTS:      'Top Audio Podcasts',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Podcasts-specific UI Constants                                */
/*                                                                             */
/*      																	   */
/*                                                                             */
/*******************************************************************************/

//* Tabs Strings */
TABS = {
  LISTEN_NOW:	'Listen Now',
  LIBRARY:		'Library',
  BROWSE:		'Browse',
  SEARCH:		'Search',
  DOWNLOADS:	'Downloads',
  // PRE-TIGRIS
  UNPLAYED:		'Unplayed',
  FEATURED:		'Featured',
  TOP_CHARTS:	'Top Charts',
};

/** Store Category Strings */
// Keeping this list for now
STORE_CATEGORIES = {
  ALL:		'All Categories',
 ARTS:		'Arts',
 BIZ:		'Business',
 COMEDY:	'Comedy',
 EDU:	 	'Education',
 GAMES:	  	'Games & Hobbies',
 GOV:	 	'Government & Organizations',
 HEALTH:	'Health',
 KIDS:		'Kids & Family',
 MUSIC:	  	'Music',
 NEWS:		'News & Politics',
 RELIGION:	'Religion & Spirituality',
 SCIENCE:	'Science & Medicine',
 SOCIETY:	'Society & Culture',
 SPORTS:	'Sports & Recreation',
 TECH:		'Technology',
 TV:		'TV & Film',
};

var STORE_CATEGORIES_ARRAY = [
	'All Categories',
	'Arts',
	'Business',
	'Comedy',
	'Education',
	'Games & Hobbies',
	'Government & Organizations',
	'Health',
	'Kids & Family',
	'Music',
	'News & Politics',
	'Religion & Spirituality',
	'Science & Medicine',
	'Society & Culture',
	'Sports & Recreation',
	'Technology',
	'TV & Film'
];

/** Other UI Constants
	Used in more than one View
	Podcast names vary, so the entire query can't be constant */
UI_OTHER = {
	MORE:		'more…',
	TRACK_ACTIONS:  'track actions', // NOT IMPLEMENTED YET in accessibility

};

var PODCAST_URLS = {
	Serial : 'http://feeds.serialpodcast.org/serialpodcast',
	This_American_Life : 'http://feed.thisamericanlife.org/talpodcast',
	Car_Talk : 'http://www.npr.org/templates/rss/podcast.php?id=510208',
	TEDTalks_video : 'http://feeds.feedburner.com/TEDTalks_video', // True name is TED Talks Daily
	Planet_Money   : 'http://www.npr.org/templates/rss/podcast.php?id=510289',
	Fresh_Air      : 'http://www.npr.org/rss/podcast.php?id=381444908',
	Start_Cooking  : 'http://feeds2.feedburner.com/KathyMaistersStartCookingVideoCast',
	Grammar_Girl   : 'http://www.qdnow.com/grammar.xml',
	Look_Like_a_Local : 'feed://looklikealocal.libsyn.com/rss',
	The_Dirtbag_Diaries : 'http://thedirtbag.libsyn.com/rss',
	Dan_Carlin : 'http://feeds.feedburner.com/dancarlin/history?format=xml',
	The_Cracked_Podcast : 'feed://rss.earwolf.com/the-cracked-podcast',
	The_Flop_House : 'feed://www.flophousepodcast.com/feed/',
	Apple_Keynotes : 'http://podcasts.apple.com/apple_keynotes/apple_keynotes.xml',
	Colonial_Williamsburg_Enhanced : 'http://feeds.history.org/CWEnhancedPodcasts', // UI name Colonial Williamsburg History Podcasts - Image Enhanced
};

/* exported PODCAST_SHARED_URLS */
var PODCAST_SHARED_URLS = {
	Serial : 'https://itunes.apple.com/us/podcast/serial/id917918570?mt=2',
    This_American_Life : 'https://itunes.apple.com/us/podcast/this-american-life/id201671138?mt=2',
    Car_Talk           : 'https://itunes.apple.com/us/podcast/car-talk/id253191823?mt=2',
    TEDTalks_video     : 'https://itunes.apple.com/us/podcast/tedtalks-video/id160892972?mt=2', // True name is
    // TEDTalks (video)
    Planet_Money       : 'https://itunes.apple.com/us/podcast/planet-money/id290783428?mt=2',
    Fresh_Air          : 'https://itunes.apple.com/us/podcast/fresh-air/id214089682?mt=2',
	Hello_Internet     : 'https://itunes.apple.com/us/podcast/hello-internet/id811377230?mt=2',
};

/* exported TO_AVOID */
var TO_AVOID = [
	'Serial',
	'This American Life',
	'Hello Internet',
	'Fresh Air',
];

var VALID_PLAYSTATES = [
		'Unplayed',
		'Partially played',
		'Played',
		'Now playing',
];

// Arrays to be used to change app settings in the Settings app
var SETTINGS_NAV_ARRAYS = {
	notifications : ['Podcasts', 'Notifications'],
	refresh       : ['Podcasts', 'Refresh Every'],
	limit         : ['Podcasts', 'Limit Episodes'],
	download      : ['Podcasts', 'Download Episodes'],
};

// Valid phrases to use for refresh settings
var VALID_REFRESH_SETTINGS = [
	'1 Hour',
	'6 Hours',
	'Day',
	'Week',
	'Manually',
	'Default (1 Hour)',
	'Default (6 Hours)',
	'Default (Day)',
	'Default (Week)',
	'Default (Manually)'
];

// Valid phrases to be used to set the episode limit setting
var VALID_LIMIT_SETTINGS = [
	'Off',
	'Most Recent',
	'2 Most Recent',
	'3 Most Recent',
	'5 Most Recent',
	'10 Most Recent',
	'1 Day',
	'1 Week',
	'2 Weeks',
	'1 Month',
	'Default (Off)',
	'Default (Most Recent)',
	'Default (2 Most Recent)',
	'Default (3 Most Recent)',
	'Default (5 Most Recent)',
	'Default (10 Most Recent)',
	'Default (1 Day)',
	'Default (1 Week)',
	'Default (2 Weeks)',
	'Default (1 Month)'
];

// Valid phrases to set the download setting
var VALID_DOWNLOAD_SETTINGS = [
	'Off',
	'Only New',
	'All Unplayed',
	'Default (Off)',
	'Default (Only New)',
	'Default (All Unplayed)'
];

// Valid phrases to set delete played episodes setting
var VALID_DELETE_PLAYED_SETTINGS = [
	'On',
	'Off',
	'Default (On)',
	'Default (Off)'
];

// Valid options to choose for alert type
var VALID_ALERT_TYPES = [
	'None',
	'Banners',
	'Alerts',
];

//ALert handler for download errors
DOWNLOAD_ERROR_HANDLER = function () {
	if (springboard.exists(UIAQuery.Podcasts.DOWNLOAD_ERROR_ALERT)) {
		throw new UIAError ('Failed to download an episode due to download error');
	} else {
		return false;
	}
};

// Global Station Name for iCloud Tests
CLOUD_SYNC_STATION_NAME = 'Cloud Sync Test Station';

// Base File Path for Screenshots
var SCREENSHOT_DIRECTORY_FILE_PATH = '/var/mobile/Library/Logs/Testing/';

/**
	@namespace
	@augments UIAApp
*/
var podcasts = target.appWithBundleID('com.apple.podcasts');

/** Default wait time to load store pages */
var WAIT_TIME = 125; // Podcasts times out at 120

var iPad = false;
if (UIATarget.localTarget().model() === 'iPad') {
  iPad = true;
}

 /*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state. See Podcasts UIStateDescription constants
* for possible values. Any criteria for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Podcasts UIStateDescription.
*
* @param {string} tab - the tab
* @param {Object} options - options dictionary
* @returns {boolean} false if we cannot figure out the UI State
*/
podcasts.currentUIState = function currentUIState(options) {
	options = UIAUtilities.defaults(options, {
    	tab: null,
    });
	UIALogger.logMessage('NAV: currentUIState(), with tab: %0'.format(options.tab));
	var currentTab = options.tab; // null or whatever was passed in

    // Check Now Playing Sheet first because tabs will show up as selected
    if (this.exists(UIAQuery.Podcasts.NOW_PLAYING)) {
    	return UIStateDescription.Podcasts.NOW_PLAYING;
    }
    if (!currentTab) {
		// If no tab passed in, get Current Tab to improve query speed below
		if (iPad) {
			//BUG: <rdar://problem/30899519> Tigris iPad Tab Bar has two items selected in UIA2 - should only have one
			currentTab = this.nameOf(UIAQuery.query('UIStackView').children().isSelected());
		} else {
			currentTab = this.nameOf(UIAQuery.query('UITabBar').children().isSelected());
	   }
	   UIALogger.logMessage('Got the current tab instead: %0'.format(currentTab));
	}
	// Walk thru the tabs and return which view we're in
	if (currentTab === TABS.LISTEN_NOW) {
		if(this.exists(UIAQuery.Podcasts.LISTEN_NOW_VIEW)) {
			return UIStateDescription.Podcasts.LISTEN_NOW;
		 }
	} else if (currentTab === TABS.LIBRARY) {
		if (this.exists(UIAQuery.Podcasts.LIBRARY_VIEW)) {
			 return UIStateDescription.Podcasts.LIBRARY;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.SHOWS)) {
		  	return UIStateDescription.Podcasts.SHOWS;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.DOWNLOADED_EPISODES)) {
		  	return UIStateDescription.Podcasts.DOWNLOADED_EPISODES;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.RECENTLY_UPDATED)) {
		  	return UIStateDescription.Podcasts.RECENTLY_UPDATED;
		} else if (this.exists(UIAQuery.Podcasts.LIBRARY_VIEW) && this.exists(UIAQuery.Podcasts.LIBRARY_EDIT)) {
			// Library view query above is same in edit view
			 return UIStateDescription.Podcasts.LIBRARY_EDIT;
		}
	} else if (currentTab === TABS.BROWSE) {
		// These will fail if not visible, scrolled to the top
		if (this.exists(UIAQuery.Podcasts.BROWSE_VIEW)) {
			return UIStateDescription.Podcasts.BROWSE;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.FEATURED)) {
		  	return UIStateDescription.Podcasts.FEATURED;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.TOP_CHARTS)) {
		  	return UIStateDescription.Podcasts.TOP_CHARTS;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.ALL_CATEGORIES)) {
		  	return UIStateDescription.Podcasts.ALL_CATEGORIES;
		} else if (this.exists(UIAQuery.Podcasts.BACK_NAVBAR) && this.exists(UIAQuery.Podcasts.FEATURED_PROVIDERS)) {
		  	return UIStateDescription.Podcasts.FEATURED_PROVIDERS;
		}
	} else if (currentTab === TABS.SEARCH) {
		if (this.exists(UIAQuery.Podcasts.SEARCH)) {
			return UIStateDescription.Podcasts.SEARCH;
		}
	} else {
		// All Other Views Not Under a Tab
		UIALogger.logMessage('No Tab was matched. No view was matched.');
	}

  // COULD NOT DETERMINE STATE if we arrived here
	UIALogger.logMessage('•••ERROR: Could not determine current UI state.');
    return false;
};


/**
* Safely Navigates to requested tab and verifies it loaded.
*  Will get rid of any modal or alert that blocks tab visibility
*    By default will get to the top level of requested tab and then verify it loaded.
*    By default, any view with store content will wait for that content to load.
* Expected starting states: Works for any UI state.
*	App should be launched already.
*
* @param {string} tab - Tab name. Comes from a list of
*               possible constants contained in TABS.
* @param {object} options
* @param {boolean} options.getToTopLevel - gets to top level of desired tab
* @param {boolean} options.noPodcasts - if true, no podcasts
*										or episodes should be present
* @param {int} options.waitToLoadTime - number of seconds to wait for (store) UI to load
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state or if verify fails.
*/
podcasts.getToTab = function getToTab(tab, options) {
    options = UIAUtilities.defaults(options, {
    	getToTopLevel:	true,
        noPodcasts:		false,
        waitToLoadTime:	WAIT_TIME
    });
    UIAUtilities.assert(
  		typeof tab !== undefined,
  		"•ERROR: getToTab called with undefined tab name"
	);
	UIALogger.logMessage('NAV: getToTab(): %0'.format(tab));
	// Wait until present THEN tap - new UI may slowly load the new empty state
	if (this.waitUntilPresent(UIAQuery.buttons(tab).isVisible(), 10)) {
    	this.tap(UIAQuery.buttons(tab));
		UIALogger.logMessage("Tapped on tab.  Was visible.");
	} else {
		UIALogger.logMessage("Tab NOT visible, clearing the way...");
		this.exitModalsAndPopovers();

		// TAP the tab - verbose, but allows for special cases
		switch (tab) {
			case TABS.LISTEN_NOW:
				this.tap(UIAQuery.Podcasts.LISTEN_NOW_TAB);
				break;
			case TABS.LIBRARY:
				this.tap(UIAQuery.Podcasts.LIBRARY_TAB);
				break;
			case TABS.BROWSE:
				this.tap(UIAQuery.Podcasts.BROWSE_TAB);
				this.delay(2); // cheat a bit and let store page load
				break;
			case TABS.SEARCH:
				this.tap(UIAQuery.Podcasts.SEARCH_TAB);
				break;
			default:
				throw new UIAError('Could not get to unknown tab: \'%0\'.'.format(tab));
		}
	}

	// Get to and verify the top level UI of the tab
	if (options.getToTopLevel) {
		this.delay(1);
    	this.getToTopLevelCurrentTab(tab, options);
    }
};

/**
* Navigation function to get to the top level of the currently active tab
* Taps and then verifies.  Tapping a current tab is the easiest way to get to its top level
* Do not call directly - use getToTab(), which checks for alerts, then taps, then calls this.
* getToTab has already verified that we are indeed on the intended tab
* Expected starting states: must already be on the tab to which you want to get to the top level
*     No alerts or sheets can be visible. (again, best to just call getToTab()).
*
* @param {string} tab - the tab
* @param {Object} options - options dictionary
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state.
*/
podcasts.getToTopLevelCurrentTab = function getToTopLevelCurrentTab(tab, options) {
	UIALogger.logMessage('NAV: getToTopLevelCurrentTab %0'.format(tab));
     UIAUtilities.assert(
  		typeof tab !== undefined,
  		"•ERROR: getToTab called with undefined tab name"
	);
	options = UIAUtilities.defaults(options, {
		noPodcasts:		false,
		waitToLoadTime:	WAIT_TIME
    });
    currentStateOptions = {tab: tab}; // set to tab that was passed in
	var expectedState	= "";
   	var currentState	= "";
   	// var counter = 1;

    podcasts.waitForAnimations(); // for safety!

	podcasts.tap(UIAQuery.buttons(tab));
	// Set Expected State and HANDLE SPECIAL CASES after the tap...
    switch (tab) {
    	case TABS.LISTEN_NOW:
    		if (options.noPodcasts) {
    			UIALogger.logWarning(
    				"•WARN: we currently do nothing for checking empty library.");
    		} else {
				UIALogger.logMessage('iPad: Waiting for Listen Now store lockups to load...');
				this.waitUntilPresent(UIAQuery.Podcasts.LISTEN_NOW_LOCKUP, WAIT_TIME);
			}
			// may fail later if we don't scroll to top
			podcasts.swipeDownUntilVisible(UIAQuery.Podcasts.LISTEN_NOW_VIEW);
        	expectedState = UIStateDescription.Podcasts.LISTEN_NOW;
        	break;
    	case TABS.LIBRARY:
  			// May be in Edit mode even after we back out
			podcasts.tapIfExists(UIAQuery.Podcasts.LIBRARY_EDIT);
    		expectedState = UIStateDescription.Podcasts.LIBRARY;
			break;
        case TABS.BROWSE:
        	// Wait for store page to load!
			UIALogger.logMessage('Waiting for Browse to load...');
			this.waitUntilPresent(UIAQuery.Podcasts.FEATURED_LOCKUP, WAIT_TIME);
        	expectedState = UIStateDescription.Podcasts.BROWSE;
            break;
		case TABS.SEARCH:
			if (iPad) {
				podcasts.tapIfExists(UIAQuery.Podcasts.LIBRARY_EDIT); // Done button. if searching already
			} else {
				podcasts.tapIfExists(UIAQuery.buttons("SearchCancel")); // phone has no done button
			}
        	expectedState = UIStateDescription.Podcasts.SEARCH;
         	break;
        default:
            throw new UIAError("•••FAIL: getToTopLevelCurrentTab(). Unknown tab: %0".format(tab));
    }

    // Get the new state and verify
    currentState = this.currentUIState(currentStateOptions);
    if (currentState !== expectedState) {
    	throw new UIAError(
    		"•••FAIL: getToTopLevelCurrentTab(). Current state: %0 does not equal expected: %1".format(
    		currentState, expectedState
    	));
    } else {
    	UIALogger.logMessage('NAV Success: At the top level of: %0'.format(tab));
    }
    return true;
};


/**
 *  Attempts to open full-screen Now Playing view
 *	   by tapping on mini-player
 *
 * Expected starting state: Mini-player must be visible
 * 		Should have already played at least once before
 *
 * @throws if starting state is wrong or full-screen doesn't open
 * @returns None
 */
podcasts.getToNowPlaying = function getToNowPlaying() {
	UIALogger.logMessage("NAV: getToNowPlaying");
	// Already in Now Playing full-screen?
	if (this.exists((UIAQuery.Podcasts.NOW_PLAYING.isVisible())) ) {
		UIALogger.logMessage("• Already In Now Playing full screen.");
		if (this.waitUntilPresent(UIAQuery.buttons("Got It"), 1)) {
			UIALogger.logMessage('Select Got It Button that was showing');
			remote.tap(UIAQuery.buttons('Got It'));
			remote.delay(2);
		}
		return;
	}
	// If not already in NP, then clear the way for safe tap
	this.exitModalsAndPopovers();
	// Check for mini-player
	UIAUtilities.assert(
  		this.exists(UIAQuery.Podcasts.MINIPLAYER_MINI.isVisible()),
  		"***FAIL:  Mini-player must be present, but could not be found or is not visible"
	);
	// TAP
	this.tap(UIAQuery.Podcasts.MINIPLAYER_MINI);
	this.waitUntilPresent(UIAQuery.Podcasts.NOW_PLAYING.isVisible(), 5);
	// VERIFY
	UIAUtilities.assert(
  		this.exists(UIAQuery.Podcasts.NOW_PLAYING),
  		"***FAIL:  Mini-player was found and tapped, but Now Playing full-screen could not be found."
	);
	UIALogger.logMessage("• In Now Playing full screen.");
};

/**
 * Navigates in to full screen and verifies it has reached it. Not currently throwing an error due to
 * <rdar://problem/26841730> AX: Voice Over Views All Controls as Still Visible in Fullscreen Video
 *
 * Expected Starting State: Video episode already in Now Playing
 *
 * @throws if full screen video not reached
 */
podcasts.getToFullScreenVideo = function getToFullScreenVideo() {
	UIALogger.logMessage('NAV: getToFullScreenVideo');

	this.getToNowPlaying();

	if (!iPad) {
		target.setDeviceOrientation(3);
	} else {
		this.tap(UIAQuery.Podcasts.FULLSCREEN_VID);
		// Here is where verification would take place once "<rdar://problem/26841730> AX: Voice Over Views All Controls
		// as Still Visible in Fullscreen Video" is resolved
	}
};

/**
 *  Attempts to find then open a podcast in My Podcasts
 *
 * Expected starting state: any
 *
 * @throws if starting state is wrong or full-screen doesn't open
 * @returns true or false
 */
podcasts.getToPodcastDetails = function getToPodcastDetails(podcastName) {
	UIAUtilities.assert(
		typeof podcastName !== undefined,
		'getToPodcastDetails() called with no podcast container name.'
	);
	var alreadyInDetails = false;
	UIALogger.logMessage("NAV: getToPodcastDetails: %0".format(podcastName));
	// Check if we're already there
	if (this.exists(UIAQuery.query("PodcastsUI.DynamicTypeLabel").andThen(UIAQuery.contains(podcastName)))) {
		if (this.exists("PodcastsUI.PodcastDetailView") || this.exists("PodcastsUI.QuickPlayView")) {
			UIALogger.logMessage('Already in podcast details of %0'.format(podcastName));
			alreadyInDetails = true;
		}
	}
	if (!alreadyInDetails) {
        // Nav to My Podcasts
        this.getToTab(TABS.LIBRARY);
        this.tap(UIAQuery.Podcasts.SHOWS_CELL);
        // Wait for podcast to appear
        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_CONTAINER.contains(podcastName), 30),
            'Podcast of the name %0 did not appear'.format(podcastName)
        );

        this.tap(UIAQuery.Podcasts.PODCAST_CONTAINER.contains(podcastName));
        this.waitUntilPresent(UIAQuery.Podcasts.CONTAINER_EPISODE_CELL);
        UIAUtilities.assert(
           this.exists("PodcastsUI.PodcastDetailView") || this.exists("PodcastsUI.QuickPlayView"),
            'Did not make it to container of %0'.format(podcastName)
        );
        UIALogger.logMessage('Success: In Podcasts details for %0'.format(podcastName));
    }
};


/**
 * Get to and load an Individual Store Category Page
 *
 * Expected starting state:  Must already be in Top Charts on Browse tab
 * @param {string} categoryName
 *
 * @returns {boolean} success or fail
 *
 * @throws If verify fails
 */
podcasts.getToStoreCategoryPage = function getToStoreCategoryPage(categoryName) {
	UIALogger.logMessage("NAV MENU: getToStoreCategoryPage");

	UIAUtilities.assert(
  		(typeof categoryName !== 'undefined'),
  		"•ERROR: getToStoreCategoryPage(): Must pass in a category. Category: %0".format(categoryName)
	);

	// Wait for categories button.  Needed for very first tap on tab.
	// The button name could be any of the category names
	this.waitUntilReady();
	if (!this.waitUntilPresent(UIAQuery.navigationBars().andThen(UIAQuery.buttons().atIndex(1).isVisible()), 10)) {
		UIALogger.logWarning("•• WARN: Categories button is NOT VISIBLE.  Continuing on...");
	}
	// Tap on Categories button (could be any name)
	podcasts.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons().atIndex(1)));
	// Wait for the Categories nav bar to appear and for app to be ready
	this.waitUntilReady();
	if (iPad) {
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.DISMISS_POPUP, 10),
			'Categories popover did not open after 10 seconds'
		);
	} else {
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.CATEGORIES_PAGE_NAVBAR, 10),
			'Categories popover did not open after 10 seconds'
		);
	}

	// TAP on individual category
	if (iPad) {
		var currentCat = podcasts.inspect(UIAQuery.tableCells().isSelected().children()).name;
		// BUG: <rdar://problem/31017415> UIA2 cannot find first item in popover
		UIALogger.logWarning("•• WARN: WORKAROUND for iPad <rdar://problem/31017415>.");
		// Workaround:
		if (currentCat === categoryName) {
			UIALogger.logWarning("Category is already selected.");
			// tap the category
			podcasts.tap(UIAQuery.tableCells().isSelected());
		} else {
			podcasts.tap(categoryName);
		}
	} else {
		podcasts.tap(categoryName);
	}
	this.waitUntilReady();
	// Verify page loaded
	if (podcasts.waitUntilPresent(UIAQuery.beginsWith("5,"), WAIT_TIME) ) {
			UIALogger.logMessage("•PASS: %0 page loaded.".format(categoryName));
			var cellName = podcasts.inspectElementKey(UIAQuery.beginsWith("5,"), 'label');
			UIALogger.logMessage("Cell Name: %0.".format(cellName));
	} else {
		throw new UIAError("•••FAIL: Did not load category page %0.".format(categoryName));
	}

	// VERIFY
	curCategoryButton =  podcasts.inspect(UIAQuery.navigationBars().andThen(UIAQuery.buttons().atIndex(1))).label;
	UIAUtilities.assert(
		curCategoryButton === categoryName,
		'••• FAIL: current category %0 did not match expected: %1'.format(
			curCategoryButton, categoryName)
	);
	UIALogger.logMessage("• PASS: category name matched expected");
};

/**
 * Get to the Featured page, which is a subview of Browse
 *
 * Expected starting state:  Any
 *
 * @returns {boolean} success or fail
 *
 * @throws If verify fails
 */
podcasts.getToFeatured = function getToFeatured() {
	UIALogger.logMessage("NAV: getToFeatured");
	this.getToTab(TABS.BROWSE);
	UIAUtilities.assert(
	    this.waitUntilPresent(UIAQuery.Podcasts.FEATURED_CELL, 120),
        'Featured button did not appear after 120 seconds'
    );

	this.tap(UIAQuery.Podcasts.FEATURED_CELL);
	// Wait for items on Featured to load
    UIAUtilities.assert(
        this.waitUntilPresent(UIAQuery.navigationBars('Featured'), 120),
        'Featured page did not load after 120 seconds'
    );
    UIAUtilities.assert(
        this.waitUntilPresent(UIAQuery.query('New & Noteworthy'), 30),
        'New & Noteworthy did not load after an additional 30 seconds'
    );
    UIALogger.logMessage('Success: Featured page did load.');
};

/**
 * Dismiss any sheet, modal, etc., that prevents app from
 *    tapping on any tab
 *	Does not tap on back button to back out of any views.
 *	Will dismiss Now Playing sheet
 *	We do NOT want to get to the top level of a tab here,
 *	Use getToTabTopLevel() for drilling all the way out.
 *
 * @returns none
 *
 */
podcasts.exitModalsAndPopovers = function exitModalsAndPopovers() {
	 UIALogger.logMessage("NAV:  exitModalsAndPopovers()");

	// TIGRIS TODO - Determine where best to place this test for sheets with Cancel
	// 1 - Check for sheets or popovers
	podcasts.dismissPopovers();
	if (podcasts.tapIfExists(UIAQuery.query("Cancel")) ||
		podcasts.tapIfExists(UIAQuery.query("dismiss popup"))) {
		UIALogger.logMessage("Sheet or popover detected. Tapping Cancel or out...");
	}

	// 2 - Old, needs updating.  Check for popovers and other sheets
	if (iPad) {
		// This is for all popovers on iPad
		if (podcasts.exists(UIAQuery.VISIBLE_POPOVERS)) {
			UIALogger.logMessage("Visible popover detected on iPad - tapping out...");
			// Search Suggestions is also a popover, so clear it first
			if (podcasts.exists(UIAQuery.keyboard())) {
				UIALogger.logMessage("Keyboard detected in popover.  Dismissing...");
				// leave any text for now
				this.dismissKeyboard();
			}
			podcasts.tap(UIAQuery.query("dismiss popup"));
		}
		//this also works: podcasts.exists(UIAQuery.query("_UIAlertControllerView"))
	} else {
		if (podcasts.exists(UIAQuery.Podcasts.CANCEL_BUTTON_SHEET)) {
			UIALogger.logMessage("Action sheet detected.  Tapping cancel...");
			podcasts.tap(UIAQuery.Podcasts.CANCEL_BUTTON_SHEET);
		}
	}
	// 3 - check for Now Playing full-screen
	if (this.exists(UIAQuery.Podcasts.NOW_PLAYING)) {
		if (this.tapIfExists(UIAQuery.buttons("Got It"))) {
			UIALogger.logWarning("First time in Now Playing. 'Got It' button detected.  Tapping on it...");
		}
		UIALogger.logWarning("Now Playing sheet is visible.  Tapping Dismiss...");
    	this.tapIfExists(UIAQuery.Podcasts.DISMISS_BUTTON);
    }
	// 4 - check for My Podcasts->Settings subviews and Station Settings subviews
		// TIGRIS remove?  These are no longer modal.  can remove (handled in getToTopLevel)
	if (!iPad) {
		if (podcasts.exists(UIAQuery.Podcasts.SETINGS_NAVBAR)) {
			UIALogger.logMessage("Settings sub-view detected.  Tapping Back/Settings...");
			podcasts.tap(UIAQuery.Podcasts.BACK_NAVBAR);
		}
		// check for Station Settings subviews
		// Tigris remove
		if (podcasts.exists(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR)) {
			UIALogger.logMessage("Station Settings sub-view detected.  Tapping Station Settings...");
			podcasts.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
		}
	}
	// 5 - Edit mode or any Done button
	if (podcasts.tapIfExists(UIAQuery.Podcasts.DONE_BUTTON)) {
		UIALogger.logMessage("Settings modal or Done button detected.  Tapping Done...");
	}

	// EPISODE DETAILS VIEW??

	// 6 - check for Search keyboard
	// Tigris remove: likely don't need this.
		// the only keyboard is in Search, and Cancel dismisses it
	if (podcasts.exists(UIAQuery.keyboard())) {
		UIALogger.logMessage("Keyboard detected.  Dismissing...");
		podcasts.tapIfExists(UIAQuery.query("Cancel"));
	}
	// First launch ever or first after account state change shows Welcome Screen 
	// Our first test suite dismisses this, but just in case we're running in isolation:
	if (this.tapIfExists('Start Listening Now')) {
		UIALogger.logMessage("Welcome Screen detected. Start Listening Now button was tapped.");
	}
};

/**
 * Drills in to a podcast container and fails the test if it fails to do so after the number of attempts has been
 * met. Not to be used for drilling in to Stations.
 *
 * Expected starting state: My Podcasts
 *
 * @param {string} podcast - Name of the podcast container to drill in to
 * @param {Object} options - options dictionary
 * @param {num} [options.attempts=2] - Number of time to try to drill in to the podcast container
 *
 * @throws If container cannot be drilled in to after the number of attempts specified
 */
podcasts.drillIntoPodcastContainer = function drillIntoPodcastContainer(podcast, options) {
	UIALogger.logMessage('FUNCTION: drillIntoPodcastContainer');
	options = UIAUtilities.defaults(options, {
		attempts : 2
	});

	this.logStartingOptions(options, 'podcast = "%0"'.format(podcast));

	this.scrollEpisodeCellToVisible(podcast);

	var count = 0;
	var success = false;
	while (count < options.attempts && !success) {
		this.tap(UIAQuery.tableCells().contains(podcast));
		count++;
		success = true;
		try {
			UIAUtilities.assert(
				this.waitUntilPresent(UIAQuery.images().contains(podcast).isVisible()),
				'Art of Podcast did not appear indicating container was not drilled in to'.format(podcast)
			);
		} catch (err) {
			if (count === options.attempts) {
				UIALogger.logError('Failed to tap in to %0 after 2 attempts'.format(podcast));
				throw err;
			} else {
				UIALogger.logError('Failed to tap in to %0. Error: %1'.format(podcast, err.message));
				success = false;
			}
		}
	}
};

/**
 * Attempts to swipe left on a table cell and only fails if it cannot do it after the number of attempts specified
 *
 * @param {string} cell - Title of tableCell to be swiped
 * @param {string} button - Name of the button that should appear when the cell is swiped on
 * @param {Object} options - option dictionary
 * @param {num} [options.attempts=2] - Number of times to attempt to swipe left to reveal the button
 *
 * @throws If button does not appear after trying to swipe on the cell after options.attempts times
 */
podcasts.swipeLeftOnTableCell = function swipeLeftOnTableCell(cell, button, options) {
	options = UIAUtilities.defaults(options, {
		attempts : 2
	});
	UIALogger.logMessage('FUNCTION: swipeLeftOnTableCell');
	this.logStartingOptions(options, 'cell = "%0", button = "%1"'.format(cell, button));

	this.scrollEpisodeCellToVisible(cell);

	var count = 0;
	var success = false;
	var swipeAttempt = function() {
			this.swipeLeft(UIAQuery.tableCells().contains(cell), {duration:0.1});
	};
	while (count < options.attempts && !success) {
		this.withAnimationTimeout(0, swipeAttempt());
		count++;
		success = true;
		try {
			UIAUtilities.assert(
				this.waitUntilPresent(UIAQuery.buttons(button)),
				'Button did not appear after swipe'
			);
		} catch (err) {
			if (count === options.attempts) {
				UIALogger.logWarning('Button %0 did not appear after %1 attempts'.format(button, options.attempts));
				throw err;
			} else {
				UIALogger.logError('Button %0 did not appear. Error: %1'.format(button, err.message));
				success = false;
				this.delay(0.5);
			}
		}
	}
};


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These comprise multiple Action functions     			                   */
/*                                                                                 */
/***********************************************************************************/


/***********************************************************************************/
/*   Mark: High-level Tests
/*                                                                                 */
/***********************************************************************************/

/**
 * Performs the playback tests on the passed in podcasts title in CarPlay.
 * Delays in the code below are mostly due to rdar://problem/24507547
 *
 * @param {string} podcastTitle - Title of podcast to use for testing
 */
podcasts.carPlayPlaybackTests = function carPlayPlaybackTests(podcastTitle) {
	UIALogger.logMessage('FUNCTION carPlayPlaybackTests with podcastTitle %0'.format(podcastTitle));

	springboard.tap(UIAQuery.Podcasts.CAR_PLAY_LIBRARY);
	springboard.delay(1);
	springboard.tap(UIAQuery.query(podcastTitle).onScreen('CarPlay'));
	springboard.delay(2);
	var episodeTitle = springboard.inspectElementKey(UIAQuery.tableCells().children().onScreen('CarPlay'), 'label');
	springboard.tap(episodeTitle);

	springboard.delay(2);
	this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Playing_%0.png'.format(podcastTitle));
	UIAUtilities.assert(
		springboard.waitUntilPresent(UIAQuery.query('MCDTitleView').onScreen('CarPlay'), 5),
		'Now Playing never came up on CarPlay'
	);

	springboard.assertExists(
		UIAQuery.query('MCDTitleView').children().onScreen('CarPlay').andThen(UIAQuery.staticTexts(episodeTitle)),
		'Incorrect episode playing'
	);

	this.waitForPlayback(15);
	// Let it play for 5 seconds
	springboard.delay(5);

	// Pause playback and verify
	springboard.tap(UIAQuery.Podcasts.CAR_PLAY_PAUSE);
	this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Tapping_Pause.png');
	this.verifyNotPlaying();

	// Tap on 15 second skip buttons and verify functionality
	var startingTime = Math.round(CAMMediaRemote.getNowPlayingElapsedTime());
	springboard.tap(UIAQuery.Podcasts.CAR_PLAY_FF15);
	springboard.delay(.5);
	var skipTime = Math.round(CAMMediaRemote.getNowPlayingElapsedTime());
	UIALogger.logMessage('startingTime = %0, skipTime = %1'.format(startingTime, skipTime));
	UIAUtilities.assertEqual(
		startingTime + 15,
		skipTime,
		'Playback did not skip ahead 15 seconds'
	);
	springboard.tap(UIAQuery.Podcasts.CAR_PLAY_REW15);
	springboard.delay(.5);
	skipTime = Math.round(CAMMediaRemote.getNowPlayingElapsedTime());
	UIALogger.logMessage('startingTime = %0, skipTime = %1'.format(startingTime, skipTime));
	UIAUtilities.assertEqual(
		startingTime,
		skipTime,
		'Playback did not skip back 15 seconds'
	);

	// Get back to top level to make sure Now Playing item was added to top level list
	while(springboard.exists(UIAQuery.Podcasts.BACK_NAV_BUTTON.onScreen('CarPlay'))) {
		springboard.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.onScreen('CarPlay'));
		springboard.delay(1);
	}

	// Add navigation to Unplayed tab with top level item now only existing there
	springboard.tap(UIAQuery.Podcasts.CAR_PLAY_UNPLAYED);

	this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_Top_Level_After_Playing_%0.png'.format(podcastTitle));
	// Verify the Now Playing item exists at the top level
	springboard.assertExists(
		UIAQuery.tableCells().children().contains('Resume: %0'.format(podcastTitle)).onScreen('CarPlay'),
		'Now Playing item at top level does not exist'
	);

	// Verify the episode information listed is correct in the Now Playing item
	springboard.assertExists(
		UIAQuery.tableCells().children().contains(episodeTitle).onScreen('CarPlay'),
		'No or incorrect episode information listed in top level Now Playing item'
	);

	// Tap on the Now Playing item and verify user is taken to Now Playing and play back resumes
	springboard.tap(UIAQuery.tableCells().children().contains('Resume').onScreen('CarPlay'));
	springboard.delay(1);
	this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_Tapping_On_Resume_Item.png');
	UIAUtilities.assert(
		springboard.waitUntilPresent(UIAQuery.query('MCDTitleView').onScreen('CarPlay'), 5),
		'Now Playing never came up on CarPlay after tapping Resume at top level'
	);
	this.waitForPlayback(15);

	// Commented out below as it does not currently function. rdar://problem/24506465
	//UIAUtilities.assert(
	//	springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_PAUSE),
	//	5,
	//	'Pause button never came up on CarPlay after tapping Resume at top level'
	//);
	//this.tap(UIAQuery.Podcasts.CAR_PLAY_PAUSE);

	// Replacement for the above to pause playback so it does not play on continuously. No verification because it
	// is simply for clean up
	this.tap('Pause');

	// Get back to top level
	while(springboard.exists(UIAQuery.Podcasts.BACK_NAV_BUTTON.onScreen('CarPlay'))) {
		springboard.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.onScreen('CarPlay'));
		springboard.delay(1);
	}
};


/**
 * Performs the CarPlay quicklook test. Unless being run as part of a larger suite needs to be connected to a
 * CarPlay simulator manually. Most delays below are due to rdar://problem/24507547
 *
 * @param options - options dictionary
 * @param {string} [options.carPlayAudioPodcast] - Title of audio podcast to use for testing
 * @param {string} [options.carPlayAudioURL] - URL of the audio podcast
 * @param {string} [options.carPlayVideoPodcasts] - Title of video podcast to use for testing
 * @param {string} [options.carPlayVideoURL] - URL of video podcast
 */
podcasts.quicklookCarPlay = function quicklookCarPlay(options) {
	options = UIAUtilities.defaults(options, {
		carPlayAudioPodcast: 'Planet Money',
		carPlayAudioURL: PODCAST_URLS.Planet_Money,
		carPlayVideoPodcast: 'Start Cooking',
		carPlayVideoURL: PODCAST_URLS.Start_Cooking,
	});

	UIALogger.logMessage('FUNCTION: quicklookCarPlay');
	this.logStartingOptions(options);

	try {
		if (springboard.waitUntilPresent(UIAQuery.staticTexts('CarPlay'), 30)) {
			UIALogger.logMessage('CarPlay splash screen appeared');
			springboard.waitUntilAbsent(UIAQuery.staticTexts('CarPlay'), 30);
		} else {
			UIALogger.logMessage('CarPlay splash screen never appeared');
		}

		this.launch();

		// Commenting out per <rdar://problem/27174726> Comment Out Clear Now Playing from CarPlay Test to Work Around 26697274
		// To work around <rdar://problem/26697274> Automation: Though Connected to CarPlay, Test Indicated There Was no CarPlay Screen
		//this.clearNowPlaying();

		// Subscribe to test podcasts and let downloads complete
		this.subscribeViaPlusSignToURL(
			options.carPlayAudioURL,
			options.carPlayAudioPodcast,
			{verify: false, needToNav: true});

		this.tapIfExists(UIAQuery.Podcasts.DONE_BUTTON);

		this.subscribeViaPlusSignToURL(
			options.carPlayVideoURL,
			options.carPlayVideoPodcast,
			{verify: false, needToNav: false});

		this.waitForDownloadsToComplete(5);

		this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Test_Podcasts_Subscribed.png');
		// Create station for CarPlay test
		var stationCreated = true;
		try {
			this.createStation('Car Play Test', {includeAll: true});
		} catch (err) {
			UIALogger.logError('CarPlay Quicklook failed to create station with error: %0'.format(err));
			stationCreated = false;
		}
		this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Station_Created.png');

		// Get total count of podcasts without generating the full list
		var podcastCount = this.count(UIAQuery.tableCells().contains('unplayed episode'));

		// Get all the episode data so the number of unplayed episodes is known
		var episodeData = this.getAllEpisodeDataFromAllContainers();

		// Quit podcasts so it can be launched from CarPlay
		this.quitOrKillApp({errorDetail:'Could not quit Podcasts before attempting to launch on CarPlay'});

		// Launch podcasts from CarPlay. Try catch to work around frequent automation failures to launch CarPlay.
		// <rdar://problem/24569805> Automation: podcasts.launch({usingCarPlay:true} Fails to Find the Icon
		try {
			this.launch({usingCarPlay: true});
		} catch (err) {
			UIALogger.logError('Failed to launch usingCarPlay error: %0'.format(err.message));
			UIALogger.logTAResults({usingCarPlayError: err.message});
			try {
				UIALogger.logMessage('Attempting to launch by tapping on icon');
				springboard.tap(UIAQuery.query('Podcasts').onScreen('CarPlay'));
			} catch (e) {
				UIALogger.logError('Failure to tap on CarPlay to launch error: %0'.format(e.message));
				UIALogger.logMessage('Trying to simply launch the app on the phone');
				this.launch();
			}
		}
		this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Launch_Attempt.png');

		// Work around for <rdar://problem/21989729> CarPlay: Now Playing Does Not Dismiss When Playback Completes
		// by waiting for back button in Now Playing to appear and tapping on it is it does. Otherwise continues on
		// with verification as usual
		if (springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_BACK, 5)) {
			springboard.tap(UIAQuery.Podcasts.CAR_PLAY_BACK);
			springboard.delay(1);
		}

		// Wait for Unplayed to appear to verify it launched
		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_UNPLAYED, 15),
			'Podcasts did not launch on CarPlay');

		this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Unplayed_Tab_Found.png');

		// Define and verify base elements of CarPlay. Verify stations separately depending on successful creation of
		// station earlier in the test
		var carPlayBase = {
			Unplayed_Tab: UIAQuery.Podcasts.CAR_PLAY_UNPLAYED,
			LIBRARY_Tab: UIAQuery.Podcasts.CAR_PLAY_LIBRARY,
			Top_Charts_Tab: UIAQuery.Podcasts.CAR_PLAY_TOP_CHARTS,
		};
		var carPlayKeys = Object.keys(carPlayBase);
		for (var i = 0; i < carPlayKeys.length; i++) {
			springboard.assertExists(
				carPlayBase[carPlayKeys[i]],
				'Base element %0 not found on CarPlay screen'.format(carPlayKeys[i]));
		}
		// Verifying station separately because it may or may not exist
		if (stationCreated) {
			springboard.assertExists(
				UIAQuery.Podcasts.CAR_PLAY_MY_STATIONS,
				'No My Stations tab found on the CarPlay screen');
		}

		UIALogger.logMessage('Verified all base elements');

		// Generate count of unplayed episodes to verify the unplayed count
		var unplayedCount = 0;
		for (var l = 0; l < episodeData.length; l++) {
			if (
				episodeData[l].playState !== 'Played') {
				unplayedCount++;
				UIALogger.logMessage('%0 is unplayed and 1 was added to unplayedCount'.format(episodeData[l].title));
			}
		}
		UIALogger.logMessage('unplayedCount = %0'.format(unplayedCount));

		// Tap in to Unplayed and verify count of episodes
		springboard.tap(UIAQuery.Podcasts.CAR_PLAY_UNPLAYED);
		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_UNPLAYED.isSelected(), 5),
			'Unplayed did not open after 5 seconds on CarPlay');
		springboard.delay(1);
		UIAUtilities.assertEqual(
			springboard.count(UIAQuery.tableCells().onScreen('CarPlay')),
			unplayedCount,
			'Number of episodes on the unplayed tab does not match the number of unplayed episodes on the device');
		springboard.delay(3); // Work around rdar://problem/21987153

		// Tap in to My Podcasts and verify number of podcasts matches what is expected
		springboard.tap(UIAQuery.Podcasts.CAR_PLAY_LIBRARY);
		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_LIBRARY.isSelected(), 5),
			'My Podcasts did not open after 5 seconds on CarPlay');
		springboard.delay(1);
		UIAUtilities.assertEqual(
			springboard.count(UIAQuery.tableCells().onScreen('CarPlay')),
			podcastCount,
			'Number of podcasts in My Podcasts on CarPlay does not match the number on the device'
		);

		// Tap in to Top Charts and check that it loads after 90 seconds
		springboard.tap(UIAQuery.Podcasts.CAR_PLAY_TOP_CHARTS);
		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.CAR_PLAY_TOP_CHARTS.isSelected(), 90),
			'Top Charts did not load after 90 seconds'
		);
		springboard.delay(10);
		this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_After_Top_Charts_Loaded.png');
		// Make sure 50 podcasts are listed in Top Charts
		UIAUtilities.assertEqual(
			50,
			springboard.count(UIAQuery.tableCells().onScreen('CarPlay')),
			'50 Podcasts were not displayed on the Top Charts page in CarPlay'
		);

		UIALogger.logMessage('Starting CarPlay tests with audio podcast');
		this.carPlayPlaybackTests(options.carPlayAudioPodcast);

		UIALogger.logMessage('Starting CarPlay tests with video podcast');
		this.carPlayPlaybackTests(options.carPlayVideoPodcast);
	} catch (e) {
		try {
			this.takeScreenShot(UIAScreenIdentifier.CAR_PLAY, 'CarPlay_Screen_At_Failure.png');
		} catch (error) {
			UIALogger.logError(error);
		}
		throw e;
	}
};


/**
 * Quicklook test of playback controls on the lock screen and in control center
 *
 * Expected UI State: Any
 *
 * @param {{}} options - Options dictionary
 * @param {string[]} options.podcastURLs - Array of podcast URLs index matched to options.podcastTitles
 * @param {string[]} options.podcastTitles - Array of podcast titles index matched to options.podcastURLs
 * @param {bool} options.lockScreenTest - If true, runs a lock screen quicklook, if false, runs Control Center
 * 		quicklook
 *
 * Updated for Tigris
 *
 * @throws if playback fails to start
 * @returns none
 */
podcasts.quicklookLockScreenAndControlCenterPlayback = function quicklookLockScreenAndControlCenterPlayback(options) {
	options = UIAUtilities.defaults(options, {
		podcastURLs     : [PODCAST_URLS.Fresh_Air, PODCAST_URLS.TEDTalks_video],
		podcastTitles   : ['Fresh Air', 'TED Talks Daily'],
		lockScreenTest : true,
	});

	UIALogger.logMessage('***TEST***: quicklookLockScreenAndControlCenterPlayback');
	this.logStartingOptions(options);

	this.quitOrKillApp();

	this.launch();
	for (var i = 0; i < options.podcastURLs.length; i++) {
		this.subscribeViaPlusSignToURL(options.podcastURLs[i], options.podcastTitles[i]);

		this.waitForDownloadsToComplete();

		var episodePlayed = this.tapToPlayEpisodeInMyPodcasts(options.podcastTitles[i]);

		this.waitForPlayback(15);

		if (options.lockScreenTest) {
			var waiter = UIAWaiter.waiter('PidStatusChanged');
			// Lock screen
			target.clickLock();

			if (!waiter.wait()) {
				throw new UIAError('Screen never locked');
			}
			UIAUtilities.assert(CAMMediaRemote.isMediaPlaying(), 'Playback stopped after locking screen');
			// Wake up device
			target.clickLock();
			UIALogger.logMessage('Starting lock screen playback tests');
			this.lockScreenAndControlCenterSharedTests(episodePlayed, true);
		} else {
			// Start control center tests
			springboard.unlock();
			target.clickMenu();
			
			// TEMP workaround for springboard failing to get to CC
			springboard.swipeFromBottomEdge();
			springboard.waitUntilPresent(UIAQuery.query('Media Controls'), 20);
			
			// this is failing temporary workaround above
			/* *****************************************************************
			springboard.getToControlCenter();
			// Swipe to get to playback controls and try several times in case swipe fails. Log errors on each
			// failure to bring up playback controls. If still not at playback controls after 3 attempts, throw
			// error without catching
			var loops = 0;
			var atPlayback = false;
			var attempts = 3;
			while (!atPlayback && loops < attempts) {
				if (!springboard.exists(UIAQuery.query('MPUControlCenterMediaControlsView'))) {
					springboard.swipeLeft(UIAQuery.Podcasts.CONTROL_CENTER);
					try {
						UIAUtilities.assert(
							springboard.waitUntilPresent(UIAQuery.query('MPUControlCenterMediaControlsView')),
							'Playback controls did not appear after swiping'
						);
					} catch (err) {
						if (loops < attempts - 1) {
							UIALogger.logError(err.message);
							loops++;
						} else {
							throw err;
						}
					}
				}

				atPlayback = springboard.exists(UIAQuery.query('MPUControlCenterMediaControlsView'));
			}
			*************************************************** */
			
			UIALogger.logMessage('Reached control center playback controls');
			springboard.waitUntilReady();
			target.delay(3);  // Video playback is supposed to stop when app is backgrounded
							  //    this is easy way to let it stop, and we'll start it up again in CC below

			if (!CAMMediaRemote.isMediaPlaying()) {
				// note: video should be stopped by now, so play it from CC
				UIALogger.logMessage('Nothing already playing, tapping play to start test in correct state');
				springboard.waitUntilReady();
				springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PLAY);
				springboard.delay(1);
				// Added try catch to try to work around <rdar://problem/27887053> REG: After Hitting Play in Control
				// Center Playback Sometimes Pauses per <rdar://problem/27969184> Work Around Control Center Play State
				// Problem
				try {
					UIAUtilities.assert(
						CAMMediaRemote.isMediaPlaying(),
						'Playback not begun to start test in correct state'
					);
				} catch (playErr) {
					UIALogger.logError('Playback paused after tapping play. Error: %0'.format(playErr.message));
					springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PLAY);
					UIAUtilities.assert(
						CAMMediaRemote.isMediaPlaying(),
						'Playback not begun to start test in correct state after second attempt'
					);
				}
			}
			UIALogger.logMessage('Starting control center playback tests');
			this.lockScreenAndControlCenterSharedTests(episodePlayed, false);
		}

		this.launch();
	}
	this.verifyWifi();
	UIALogger.logMessage('Lock screen and control center tests completed and passed');
};


/**
 * Function to perform quicklook tests of My Podcasts
 * NOTE: NOT UPDATED FOR TIGRIS - MY PODCASTS IS NOW LIBRARY, SHOWS
 * Expected Starting State: Any
 *
 * @param {string} podcastTitle - Title of podcast to use for testing. Should have small feed but at least 4 episodes
 * @param {string} podcastURL - URL od the test podcast to subscribe to if needed
 *
 * @throws if episodes do not show the correct play state or are not un Played Episodes to Be Deleted
 * @returns none
 */
podcasts.quicklookMyPodcasts = function quicklookMyPodcasts (podcastTitle, podcastURL) {
	UIALogger.logMessage('***TEST***: quicklookMyPodcasts');

	this.verifyWifi();

	this.quitOrKillApp({errorDetail:'Failed to quit podcasts at start of quicklookMyPodcasts'});

	this.launch();
	var testPodcastTitles = ['Planet Money', 'This American Life'];
	var testPodcastURLs = [PODCAST_URLS.Planet_Money, PODCAST_URLS.This_American_Life];
	this.getToTab(TABS.LIBRARY);

	// Populate My Podcasts with some podcasts to use during test
	for (var i = 0; i < testPodcastTitles.length; i++) {
		this.subscribeViaPlusSignToURL(testPodcastURLs[i], testPodcastTitles[i], {verify:false, needToNav:false});
	}

	// Subscribe to test URL
	this.subscribeViaPlusSignToURL(podcastURL, podcastTitle, {needToNav:false});
	this.waitForDownloadsToComplete(5);

	UIALogger.logMessage('Testing podcast reordering in My Podcasts');
	var myPodcastOrder = this.generateShowsList({needToNav:false});

	// Move the 2nd test podcast in the list down one space
	this.tap(UIAQuery.Podcasts.EDIT_NAVBAR.leftmost());
	this.swipeDown(UIAQuery.tableCells().contains(testPodcastTitles[1]).children().contains('Reorder'));
	var testIndex = myPodcastOrder.indexOf(testPodcastTitles[1]);

	// Swap order of items in array to make them match what should be there now
	var temp = myPodcastOrder[testIndex];
	myPodcastOrder[testIndex] = myPodcastOrder[testIndex + 1];
	myPodcastOrder[testIndex + 1] = temp;

	this.tap(UIAQuery.Podcasts.DONE_NAVBAR);
	this.checkMyPodcastsOrder(myPodcastOrder);

	this.scrollEpisodeCellToVisible(podcastTitle);
	this.tap(podcastTitle);
	this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
	var feedEpisodes = this.generateEpisodeList({podcastTitle:podcastTitle, feed:true});
	var episodeData = this.getAllEpisodeData(feedEpisodes[0]);

	//If the first episode is played, mark it as unplayed
	if (episodeData.playState === 'Played') {
		UIALogger.logMessage('Setting play state of first episode to Unplayed');
		this.setEpisodePlayState('Unplayed', [feedEpisodes[0]], {isInFeed:true});
	}

	// Added this try catch to work around <rdar://problem/26117334> Automation: Buttons That Are Children of Episode
	// tableCells No Longer Being Found in Whitetail14A251
	try {
		UIALogger.logMessage('Testing mark as played by swiping');
		this.setEpisodePlayState('Played', [feedEpisodes[0]], {method: 'swipe', isInFeed: true});
		// Verify it shows up correctly on the Unplayed tab
		this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_UNPLAYED);
		UIALogger.logMessage('Verifying episode is under played episodes to be deleted header');
		this.verifyPlayedToBeDeleted([feedEpisodes[0]]);

		UIALogger.logMessage('Testing mark as unplayed by swiping');
		this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
		this.setEpisodePlayState('Unplayed', [feedEpisodes[0]], {method: 'swipe', isInFeed: true});
		// Verify it shows up correctly on the Unplayed tab
		this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_UNPLAYED);
		this.verifyEpisodePlayState('Unplayed', [feedEpisodes[0]]);
	} catch (e) {
		if (e.message.indexOf('Button did not appear after swipe') !== -1) {
			UIALogger.logError('Error caused by rdar://problem/26117334. Error: %0'.format(e.message));
		} else {
			throw e;
		}
		// Exit edit mode if device is in edit mode
		this.tapIfExists(UIAQuery.Podcasts.DONE_NAVBAR);
	}

	// This is needed to feed in to the setEpisodePlayState function due to issues in UIA2
	var reverseFeedEpisodes = feedEpisodes.reverse();
	var episodeSubSet = reverseFeedEpisodes.slice(0,1);
	this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
	UIALogger.logMessage('Marking 2 episodes as Unplayed using edit');
	this.setEpisodePlayState('Unplayed', episodeSubSet, {isInFeed:true});
	// Verify on the podcast unplayed tab
	this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_UNPLAYED);
	this.verifyEpisodePlayState('Unplayed', episodeSubSet);

	UIALogger.logMessage('Marking 2 episodes as played with edit');
	this.setEpisodePlayState('Played', episodeSubSet);
	this.verifyPlayedToBeDeleted(episodeSubSet);

	UIALogger.logMessage('Marking an episode as Unplayed with track actions');
	this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
	this.setEpisodePlayState('Unplayed', [feedEpisodes[1]], {method:'track actions', isInFeed:true});

	UIALogger.logMessage('Marking an episode as played with track actions');
	this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_UNPLAYED);
	this.setEpisodePlayState('Played', [feedEpisodes[1]], {method:'track actions'});
	this.verifyPlayedToBeDeleted([feedEpisodes[1]]);

	// Verify episodes can be saved
	this.tapTrackActions(feedEpisodes[0]);
	this.tap('Save Episode');
	this.assertExists(UIAQuery.Podcasts.PODCASTS_SEGMENT_SAVED, 'Saved did not appear after saving an episode');

	//Delay for Saved message to appear on screen to work around <rdar://problem/26064199> Automation:
	// "UIA2_PodcastsQA_Quick Look My Podcasts" failed with "Element does not have a visible scrollable ancestor:
	// My Podcasts"
	this.delay(2);

	// Get back to My Podcasts tab quickly if needed
	this.tap(UIAQuery.Podcasts.LIBRARY_TAB);

	// Waiting for downloads to hopefully prevent rdar://problem/24195611
	this.waitForDownloadsToComplete(5);

	UIALogger.logMessage('Deleting a podcast by swiping');
	this.deleteFromMyPodcasts({bySwipe:true, toDelete:[testPodcastTitles[0]]});

	UIALogger.logMessage('Deleting a podcast with edit');
	this.deleteFromMyPodcasts({toDelete:[testPodcastTitles[1]], needToNav:false});

	UIALogger.logMessage('PASS* - quicklookMyPodcasts() PASSED');
};


/**
 * Quicklook sharing test
 *
 * @param {string} podcast - Title of podcast to share
 * @param {string[]} services - Array of services to share to
 * @param {string} URL - URL to podcast starting with pcast://
 *
 * @throws if service cannot be set up or sharing fails
 * @returns none
 */
podcasts.quicklookSharing = function quicklookSharing (podcast, URL, services) {
	UIALogger.logMessage('***TEST***: quicklookSharing');

	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Sharing test'});
	var username = 'ottoiq@icloud.com';
	var password = 'podIQ6616';

	for (var i = 0; i < services.length; i++) {
		UIALogger.logMessage('Starting quicklook sharing test of %0'.format(services[i]));

		if (services[i] === 'Twitter') {
			UIALogger.logMessage('Setting correct twitter login');
			username = 'ottopod';
		}

		if (services[i] !== 'Copy Link') {
			UIALogger.logMessage('Attempting login from quicklookSharing');
			this.loginToService(services[i], username, password);
		}

		this.subscribeViaPlusSignToURL(URL, podcast);
		this.tap(UIAQuery.Podcasts.PODCAST_CONTAINER.contains(podcast));

		// Create a waiter for the specific pop up menu of podcast actions
		var menuWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "NowPlayingUI.ContextActionsViewController"'
		);

		// Tap on the action button and wait for menu to appear, fail if it doesn't
    if (this.inspect(UIAQuery.Podcasts.PODCAST_MORE).isVisible){
      UIALogger.logMessage('More Button was visible, select it');
      this.tap(UIAQuery.Podcasts.PODCAST_MORE);
    } else {
      var a = podcasts.inspect(UIAQuery.Podcasts.PODCAST_MORE).rect;
      var xOffset = a.x / target.mainScreen().rect().width;
      var yOffset = a.y / target.mainScreen().rect().height;
      UIALogger.logMessage('Tapping via window offset');
      podcasts.tap(UIAQuery.application(), {offset: {x: xOffset, y: yOffset}});
    }
	UIAUtilities.assert(menuWaiter.wait(), 'Action menu did not appear');

	// Create waiter to wait for the sharing menu
	var shareWaiter = UIAWaiter.withPredicate(
		'ViewDidAppear',
		'controllerClass = "MTShareUtilActivityViewController"'
	);

	// Tap the share button and wait for share menu to open, fail if it does not
	this.tap(UIAQuery.Podcasts.PODCAST_ACTION_SHARE);
	UIAUtilities.assert(shareWaiter.wait(10), 'Share sheet did not appear');

	//Works around strange bug causing messages to not be an option just after log in
	if (services[i] === 'Messages') {
		UIALogger.logMessage('Handling messages share sheet button bug');
		if (iPad) {
			this.dismissPopovers();
		} else {
			this.tap('Cancel');
		}
		this.tap(UIAQuery.Podcasts.PODCAST_ACTION_SHARE);
	}

	this.delay(2);
	// CALL THE SHARING TEST
	this.shareToService(services[i], false, podcast);
	}
	if (services.indexOf('iCloud') !== -1) {
		try {
			UIALogger.logMessage('Attempting to log out of iCloud');
			settings.deleteiCloudAccount(password);
		} catch (deleteError) {
			UIALogger.logError('iCloud account failed to delete with error: %0'.format(deleteError.message));
		}
	}
	if (services.indexOf('Messages') !== -1) {
		// Delay for notification to complete coming through
		this.delay(20);
		settings.launch();
		try {
			UIALogger.logMessage('Attempting to log out of iMessage');
			settings.signOutOfiMessage();
		} catch (outError) {
			UIALogger.logError('iMessages failed to log out. Error: %0'.format(outError.message));
		}
	}

	UIALogger.logMessage('quicklookSharing completed');
};


/**
 * Runs a quicklook test on Siri using This American Life as a default
 *
 * @param {object} options - Options dictionary
 * @param {string} options.podcastTitle - Title of podcast that is used for the tests
 * @param {string} options.podcastURL - URL to subscribe to if podcast is not subscribed
 *
 * @throws If test fails
 * @return none
 */
podcasts.quicklookSiri = function quicklookSiri(options) {
	UIALogger.logMessage('***TEST***: quicklookSiri');
	options = UIAUtilities.defaults(options, {
		podcastTitle : 'This American Life',
		podcastURL   : PODCAST_URLS.This_American_Life,
	});
	var i = 0;
	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Siri test'});
	this.launch();
	this.subscribeViaPlusSignToURL(options.podcastURL, options.podcastTitle);
	this.waitForDownloadsToComplete();

	// Enable Siri if not on 
	target.holdMenu(1.50);
	if (springboard.waitUntilPresent('Turn On Siri', 2)) {
		UIALogger.logWarning("** Siri was off.  Turning it on...");
		springboard.tap('Turn On Siri');
		this.delay(2);
		target.clickMenu();
		this.delay(5);  // Siri apparently needs time to start up
	} else {
		UIALogger.logMessage("Siri is enabled. Exiting out of Siri...");
		target.clickMenu();
		this.delay(2);
	}
	// SIRI Play a specific podcast
	UIALogger.logMessage('Issuing command to Siri to "Play %0"'.format(options.podcastTitle));
	// have to loop to work around known issues:
	while (i<2) {
		this.issueSiriCommand('Play %0'.format(options.podcastTitle));
		if (!springboard.waitUntilPresent('Playing podcasts', 5)) {
			if (springboard.exists(UIAQuery.query("Install Podcasts"))) {
				UIALogger.logWarning("**WARN: <rdar://problem/34659335> Siri error - thinks podcasts not installed");
				target.clickMenu();
				this.delay(2);
			} else {
				UIALogger.logWarning("**WARN: Playing podcasts was not found. looking for Open Podcasts button...");
				if (springboard.waitUntilPresent('Open Podcasts')) {
					UIALogger.logMessage("Open Podcasts was found.");
					break;
				} else { 
					throw new UIAError('Playing podcasts was not visible');
				}
			}
		} else {
			break; // if playing, we're done
		}
		i++;
	}
	this.waitForPlayback(30);
	// Tap home button and we should be back in the app
	target.clickMenu();
	this.waitForAnimations();
	this.verifyPlaying();
	this.tapIfExists(UIAQuery.Podcasts.MINIPLAYER_MINI);
	this.waitForAnimations();
	this.assertExists(
			UIAQuery.query("_MPUMarqueeContentView").andThen(UIAQuery.beginsWith(options.podcastTitle)),
			'The correct podcast is not playing');
	UIALogger.logMessage('Playing for 15 seconds');
	this.delay(15);
	UIALogger.logMessage('Play specific podcast siri test PASSED');

	// SIRI Pause in background
	UIALogger.logMessage('Issuing command to pause, app in background');
	target.clickMenu();
	this.waitForAnimations();
	this.issueSiriCommand('Pause');
	springboard.waitUntilPresent('paused');
	springboard.delay(1); //Required due to rdar://problem/23502316
	UIALogger.logMessage('Verifying playback is paused');
	this.verifyNotPlaying();
	// this checks for an old, longstanding bug:
	UIALogger.logMessage('Pressing the home button after pausing');
	target.clickMenu();
	try {
		this.delay(1);
		UIALogger.logMessage('Verifying playback is paused after pressing home button');
		this.verifyNotPlaying();
	} catch (err) {
		UIALogger.logError('Playback resumed after pressing home button error was %0'.format(err.message));
		this.tap('Pause');
	}

	// Issue command to Siri to play podcasts, with app already in background
	UIALogger.logMessage('Issuing command to Siri to Play podcasts, App should already be in background...');
	this.issueSiriCommand('Play podcasts');
	if (springboard.waitUntilPresent('Open Podcasts', 30)) {
		springboard.delay(20); // Required due to rdar://problem/23502316 and rdar://problem/23620496
		springboard.tap('Open Podcasts');
	} else {
		throw new UIAError ('Open podcasts did not appear after 10 seconds');
	}
	UIALogger.logMessage('Playing back for 15 seconds');
	this.delay(15);
	this.verifyPlaying();
	UIALogger.logMessage('Play podcasts command test PASSED');

	// PAUSE to end test
	UIALogger.logMessage('Issuing command to pause, app in foreground');
	this.issueSiriCommand('Pause');
	springboard.waitUntilPresent('paused');
	springboard.delay(1); //Required due to rdar://problem/23502316
	UIALogger.logMessage('Verifying playback is paused');
	this.verifyNotPlaying();
	target.clickMenu();
	this.tapIfExists(UIAQuery.Podcasts.DISMISS_BUTTON);
	UIALogger.logMessage('PASS: quicklookSiri completed and passed');
};


/**
 * Performs the quicklook test of stations. Creates a station with default settings and one with non-default settings.
 * Makes changes to station settings and verifies contents and order of station. Verifies episode downloads
 *
 * Expected starting state: Any
 *
 * @param {object} options - Options dictionary
 * @param {string} [options.audioPodcastTitle="Serial"] - Title of audio podcast to use
 * @param {string} [options.audioPodcastIRL] - URL for the audio podcast
 * @param {string} [options.videoPodcastTitle="TEDTalks (video)"] - Title of video podcast to use
 * @param {string} [options.videoPodcastURL] - URL for video to use
 *
 * @throws if station fails to create, settings don't change, downloads do not succeed, order of episodes is wrong
 */
podcasts.quicklookStations = function quicklookStations(options) {
	options = UIAUtilities.defaults(options, {
		audioPodcastTitle : 'Serial',
		audioPodcastURL   : PODCAST_URLS.Serial,
		videoPodcastTitle : 'TED Talks Daily',
		videoPodcastURL   : PODCAST_URLS.TEDTalks_video,
	});

	UIALogger.logMessage('FUNCTION: quicklookStations');
	this.logStartingOptions(options);

	var currentDate = new Date();
	var defaultStation = 'Default %0'.format(currentDate);
	var changeStation = 'Changes %0'.format(currentDate);
	var episodesOfPassedInPodcasts = [];
	var allUnplayedNotPDF = [];
	var mostRecentEpisodes = [];
	var currentPodcast = '';
	var index = -1;

	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Stations test'});
	this.launch();

	this.subscribeViaPlusSignToURL(options.audioPodcastURL, options.audioPodcastTitle, {verify:false});
	this.subscribeViaPlusSignToURL(options.videoPodcastURL, options.videoPodcastTitle, {verify:false});

	this.waitForDownloadsToComplete(5);

	var allEpisodes = this.getAllEpisodeDataFromAllContainers();
	for (var i = 0; i < allEpisodes.length; i++) {
		// Create an array of all unplayed episodes that are not documents
		if (allEpisodes[i].playState !== 'Played' && allEpisodes[i].type !== 'Document') {
			UIALogger.logMessage(
					'%0 added to allUnplayedNotPDF'.format(allEpisodes[i]));
			allUnplayedNotPDF.push(allEpisodes[i]);
		} else {
			UIALogger.logMessage('%0 NOT added to allUnplayedNotPDF. The playState was %1 and type was %2'.format(
				allEpisodes[i].title,
				allEpisodes[i].playState,
				allEpisodes[i].type
			));
		}
	}
	for (var c = 0; c < allUnplayedNotPDF.length; c++) {
		// Generate an array containing all episodes of the passed in podcasts to use to verify the stations
		if (allUnplayedNotPDF[c].podcast === options.audioPodcastTitle ||
				allUnplayedNotPDF[c].podcast === options.videoPodcastTitle) {
			episodesOfPassedInPodcasts.push(allUnplayedNotPDF[c]);
			UIALogger.logMessage('%0 added to episodesOfPassedInPodcasts'.format(allUnplayedNotPDF[c].title));
		}
		// Gets just the most recent episodes to be used for verification later
		if (currentPodcast === allUnplayedNotPDF[c].podcast) {
			UIALogger.logMessage('currentPodcast and allUnplayedNotPDF[c].podcast matched!');
			if (mostRecentEpisodes[index].fullDate.getTime() < allUnplayedNotPDF[c].fullDate.getTime()) {
				UIALogger.logMessage('%0 replaced %1 in mostRecentEpisodes'.format(
						allUnplayedNotPDF[c].title,
						mostRecentEpisodes[index].title));
				mostRecentEpisodes[index] = allUnplayedNotPDF[c];
			}
		} else {
			index++;
			mostRecentEpisodes[index] = allUnplayedNotPDF[c];
			UIALogger.logMessage('%0 added to mostRecentEpisodes array'.format(allUnplayedNotPDF[c]));
			currentPodcast = allUnplayedNotPDF[c].podcast;
		}

	}

	// Cancel out of first attempt by passing in nothing
	this.createStation();

	UIALogger.logMessage('Creating station with default settings');
	this.createStation(defaultStation, {includeAll:true});
	this.tap(defaultStation);

	UIALogger.logMessage('Verifying correct episode in defaultStation');
	for (var u = 0; u < mostRecentEpisodes.length; u++) {
		this.assertExists(
				UIAQuery.tableCells().contains(mostRecentEpisodes[u].title),
				'Episode %0 not found in station'.format(mostRecentEpisodes[u].title));
	}

	UIALogger.logMessage('Verifying correct number of episodes in defaultStation');
	var defaultStationEpisodesList = this.generateEpisodeList({stationName:defaultStation});
	UIAUtilities.assertEqual(
			defaultStationEpisodesList.length,
			mostRecentEpisodes.length,
			'Found %0 episodes in station when there should be %1'.format(
					defaultStationEpisodesList.length, mostRecentEpisodes.length));

	UIALogger.logMessage('Creating changes station using %0 and %1.'.format(
			options.audioPodcastTitle, options.videoPodcastTitle));
	// Get back to top of My Podcasts
	this.tap(UIAQuery.Podcasts.LIBRARY_TAB);
	this.createStation(changeStation, {
		useDefaultSettings : false,
		podcastsToUse      : [options.audioPodcastTitle, options.videoPodcastTitle],
		episodesToInclude  : 'All',
	});
	UIALogger.logMessage('Verifying only the podcasts chosen are part of the station');
	this.verifyStationSettings(
			[changeStation],
			{onlyTheseSelected:[options.audioPodcastTitle, options.videoPodcastTitle]});

	// Generate episode list to use to compare against
	var stationEpisodeList = this.generateEpisodeList({stationName:changeStation});

	UIALogger.logMessage('Verifying the number of episodes in the station is correct');
	UIAUtilities.assertEqual(
			stationEpisodeList.length,
			episodesOfPassedInPodcasts.length,
			'Number of episode in station is %0 but should be %1'.format(
					stationEpisodeList.length, episodesOfPassedInPodcasts.length));

	UIALogger.logMessage('Verifying the expected episodes are in the station');
	for (var k = 0; k < episodesOfPassedInPodcasts.length; k++) {
		UIAUtilities.assert(
				this.exists(UIAQuery.contains(episodesOfPassedInPodcasts[k].title)),
				'%0 was not found in the station but should be there'.format(episodesOfPassedInPodcasts[k].title));
	}

	// Generate a list of video and audio episodes in station
	var audioEpisodes = [];
	var videoEpisodes = [];
	for (var p = 0; p < episodesOfPassedInPodcasts.length; p++) {
		if (episodesOfPassedInPodcasts[p].type === 'Video') {
			videoEpisodes.push(episodesOfPassedInPodcasts[p]);
			UIALogger.logMessage('%0 added to videoEpisodes'.format(episodesOfPassedInPodcasts[p].title));
		} else {
			audioEpisodes.push(episodesOfPassedInPodcasts[p]);
			UIALogger.logMessage('%0 added to audioEpisodes'.format(episodesOfPassedInPodcasts[p].title));
		}
	}

	/* *************** THIS FEATURE DOES NOT (YET) EXIST 
	UIALogger.logMessage('Testing downloading of an episode in stations');
	// Delete the download of the first episode of passed in podcast and then re-download
	if (episodesOfPassedInPodcasts[0].downloaded) {
		this.tapTrackActions(episodesOfPassedInPodcasts[0].title);
		this.tap('Remove Download');
		// Confirm remove download
		this.waitUntilPresent(UIAQuery.buttons('Cancel'));
		this.tap('Remove Download');
		// Verify episode download was actually removed
		var episodeInfo = this.getAllEpisodeData(episodesOfPassedInPodcasts[0].title);
		UIAUtilities.assert(!episodeInfo.downloaded, 'Download was not removed');
	}

	this.tapTrackActions(episodesOfPassedInPodcasts[0].title);
	this.tap('Download Episode');

	// Workaround verifyIndividualEpisodeDownload not working <rdar://problem/25985165> Automation: Investigate Station
	// Download Failures. Start by tapping out of station when after starting download to verify downloads are occurring
	this.tap(UIAQuery.Podcasts.LIBRARY_TAB);
	this.waitForDownloadsToComplete();
	// On phones tap back in to station, on iPads refreshes the station list to work around <rdar://problem/22221869>
	// Episode Cells: Cloud Icon Not Removed From Episode Cell in Stations After Download Completes
	this.tap(changeStation);
	*/
	UIALogger.logMessage('Changing to video only and verifying correct episodes are included');
	this.tap(UIAQuery.query('Edit').rightmost());
	this.tap(UIAQuery.Podcasts.STATION_SETTINGS_MAIN);
	this.changeStationSettings([changeStation], {mediaType:'Video', needToNav:false});
	// Get out of settings view
	this.tap('back-nav-button');
	this.tap('Done');

	// Ensure the count of episodes is correct
	var videoStationEpisodes = this.generateEpisodeList({stationName:changeStation});
	UIAUtilities.assertEqual(
			videoStationEpisodes.length,
			videoEpisodes.length,
			'There should be %0 video episodes in station but there are %1'.format(
					videoEpisodes.length, videoStationEpisodes.length));

	// Verify the correct episodes are shown in station
	for (var v = 0; v < videoEpisodes.length; v++) {
		this.assertExists(UIAQuery.tableCells().contains(videoEpisodes[v].title));
	}

	UIALogger.logMessage('Switching changeStation to audio only and verifying');
	this.tap(UIAQuery.query('Edit').rightmost());
	this.tap(UIAQuery.Podcasts.STATION_SETTINGS_MAIN);
	this.changeStationSettings([changeStation], {mediaType:'Audio', needToNav:false});
	// Get out of settings view
	this.tap('back-nav-button');
	this.tap('Done');

	// Ensure the count of episodes is correct
	var audioStationEpisodes = this.generateEpisodeList({stationName:changeStation});
	UIAUtilities.assertEqual(
			audioStationEpisodes.length,
			audioEpisodes.length,
			'There should be %0 audio episodes in station but there are  %1'.format(
					audioEpisodes.length, audioStationEpisodes.length));

	// Verify correct episodes are shown in the station
	for (var a = 0; a < audioEpisodes.length; a++) {
		this.assertExists(
				UIAQuery.tableCells().contains(audioEpisodes[a].title),
				'Episode %0 not found in station'.format(audioEpisodes[a].title));
	}

	UIALogger.logMessage('Deleting the default station by edit');
	this.deleteStations({toDelete:[defaultStation]});

	UIALogger.logMessage('Delete via button.  Future: Deleting changeStation by swipe?');
	// Have to try catch currently due to <rdar://problem/23811652> swipeLeft() Does Not Always Swipe Left
	try {
		this.deleteStations({toDelete: [changeStation], bySwipe: true});
	} catch (err) {
		UIALogger.logError('Delete Station by swipe failed with error %0'.format(err.message));
	}

	UIALogger.logMessage('Stations quicklook completed and passed');
};

/**
 * Quicklook test for streaming from prod store
 *
 * Expected State: Any
 *
 * @param {{}} options - options dictionary
 * @param {number} [options.streamTime=30] - time, in seconds, we'll stream episode
 *
 * @returns none
 * @throws if playback does not begin or stop playing part way through
 */
podcasts.testStreamFromStore = function testStreamFromStore(options) {
	options = UIAUtilities.defaults(options, {
		streamTime : 30
	});
	UIALogger.logMessage('***TEST*** testStreamFromStore');
	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of stream from store test'});
	this.launch();
	this.streamFromStore(options);
	this.tapIfExists(UIAQuery.Podcasts.BROWSE_TAB); // cleanup
	UIALogger.logMessage('quicklookStore completed and passed');

};


/**
 * Test the loading of all Podcasts store categories
 *	Works for either Featured or Top Charts
 *  Uses STORE_CATEGORIES_ARRAY.
 *
 * Expected Starting state: Any.
 *   Must have working network connection.
 *
 */
podcasts.testTopChartsCategories = function testTopChartsCategories() {
	UIALogger.logMessage("***TEST***: Test all store categories.");
	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of testTopChartsCategories'});

	this.launch();
	// get to top level of inputted tab
	this.getToTab(TABS.BROWSE);
	// TODO: test for All or Top Charts here, or use sep. functions.
	podcasts.tap(UIAQuery.Podcasts.TOP_CHARTS_CELL);
	podcasts.delay(2);  // Change.  Should wait for page to load

	// Do we need to dismiss the popover from the test above?
	// LOOP Through Categories and load each page
	// Start at 0 may be redundant, but we can't be sure of our starting point otherwise
	for (var i = 0; i < STORE_CATEGORIES_ARRAY.length; i++) {
		this.getToStoreCategoryPage(STORE_CATEGORIES_ARRAY[i]);
		target.delay(2);
	}

	// tap back to All Categories when done.
	this.getToStoreCategoryPage(STORE_CATEGORIES_ARRAY[0]);
	UIALogger.logMessage("************* FINISHED: testStoreAllCategories.*************");
};


/**
 * Test all elements in the Mini Player UI.
 *	Includes media playback.
 *  Use of delay is intended - so that media playback can occur
 *
 * Expected Starting state: Important - mini player must be visible.
 *		Close now playing first if necessary.
 * @param {object} options
 * @param {boolean} options.isVideo - subscribe to search result
 * @param {boolean} options.isPlaying - subscribe to search result
 *
 */
podcasts.testMiniPlayerUI = function testMiniPlayerUI(options) {
	options = UIAUtilities.defaults(options, {
        isVideo:	false,
        isPlaying:	true,
    });
    UIALogger.logMessage("TEST: testMiniPlayerUI...");
    if (!this.exists(UIAQuery.Podcasts.MINIPLAYER_MINI.isVisible())) {
    	UIALogger.logMessage("Shit.");
    }
    UIAUtilities.assert(
  		this.exists(UIAQuery.Podcasts.MINIPLAYER_MINI.isVisible()),
  		"•ERROR:  testMiniPlayerUI: Mini Player is not visible."
	);

    // If not playing, play
	if (!(this.exists(UIAQuery.Podcasts.PAUSE_BUTTON_MINI))) {
		UIALogger.logMessage("MiniPlayer: not playing; Will tap play...");
		this.tap(UIAQuery.Podcasts.PLAY_BUTTON_MINI);
		target.delay(5);
	}
	this.verifyPlaying( {isMiniPlayer: true} );
	UIALogger.logMessage("MiniPlayer: Test pause, then Play again...");
	this.tap(UIAQuery.Podcasts.PAUSE_BUTTON_MINI);
	this.verifyNotPlaying();
	target.delay(2);
	this.tap(UIAQuery.Podcasts.PLAY_BUTTON_MINI);
	this.verifyPlaying( {isMiniPlayer: true} );
	target.delay(5);

	UIALogger.logMessage("Mini Player: Test rotation...");
	target.setDeviceOrientation(1);
	this.waitForAnimations();
	target.setDeviceOrientation(3);
	this.waitForAnimations();
	target.setDeviceOrientation(1);
	this.waitForAnimations();

	UIALogger.logMessage("Mini Player: Tap 3 times each Fast-forward...");
	this.tap(UIAQuery.Podcasts.FF15_BUTTON, {tapCount: 3});
	target.delay(1);

	// Verify we're still playing
	this.verifyPlaying( {isMiniPlayer: true} );

	UIALogger.logMessage("Mini Player: Test rotation, 2nd time...");
	target.setDeviceOrientation(1);
	this.waitForAnimations();
	target.setDeviceOrientation(3);
	this.waitForAnimations();
	target.setDeviceOrientation(1);
	this.waitForAnimations();

    // Finally, stop playback
    // <rdar://problem/25810216>
    this.waitUntilPresent(UIAQuery.Podcasts.PAUSE_BUTTON_MINI, 3);
    this.tap(UIAQuery.Podcasts.PAUSE_BUTTON_MINI);
	this.verifyNotPlaying();
	UIALogger.logMessage("****FINISHED: testMiniPlayerUI *****");

};


/**
 * Test all elements in the NowPlaying UI.
 *	Includes media playback.
 *  Use of delay is intended - so that media playback can occur
 *
 * Expected Starting state: Should already be in NowPlaying full screen.
 *   app should already be playing 
 *   and one podcast episode should be available.
 * @param {object} options
 * @param {boolean} options.isVideo - subscribe to search result
 * @param {boolean} options.isPlaying - subscribe to search result
 *
 */
podcasts.testNowPlayingUI = function testNowPlayingUI(options) {
	//noinspection JSUnusedAssignment
	options = UIAUtilities.defaults(options, {
		currentEpisode: null,
        isVideo:	false,
        isPlaying:	true,
    });
    UIALogger.logMessage("***TEST***: testNowPlayingUI.  Episode title: %0".format(options.currentEpisode));
    this.waitForAnimations();
    UIAUtilities.assert(
  		this.exists(UIAQuery.Podcasts.NOW_PLAYING),
  		"•ERROR:  testNowPlayingUI: Now Playing full-screen is not present."
	);
	if (options.currentEpisode != null) {
		UIAUtilities.assert(
  			podcasts.exists(UIAQuery.query(
  				'NowPlayingUI.NowPlayingControlsHeader').andThen(
				UIAQuery.contains(options.currentEpisode))),
  			"•ERROR:  testNowPlayingUI: Title did not match."
		);
	}

	// Turn down volume
	target.holdVolumeDown(1);

	/* can remove - play should've already been tapped
	// If not playing, play
	if (!(this.exists(UIAQuery.Podcasts.PAUSE_BUTTON))) {
		this.play();
		target.delay(10);
	}
	*/
	UIAUtilities.assert(
  			this.waitUntilPresent(UIAQuery.Podcasts.PAUSE_BUTTON, 3),
  			"•ERROR:  Pause button not found." 
  	);
	this.verifyPlaying();
	UIALogger.logMessage("Now Playing: Test pause, then Play again...");
	this.pause();
	this.verifyNotPlaying();
	target.delay(3);
	this.play();
	this.verifyPlaying();
	target.delay(10);

	if (options.isVideo) {
		UIALogger.logMessage("Now Playing: Test for video full screen...");
		podcasts.tap(UIAQuery.query('NowPlayingUI.NowPlayingControlsHeader').andThen(
					UIAQuery.query("Video")));
		target.delay(5); // let video display a bit
		podcasts.tap(UIAQuery.query('IMVideoPlaybackOverlayView').andThen(UIAQuery.buttons('Done')));
	}

	UIALogger.logMessage("Now Playing: Test volume slider up and down...");
	//note: isVisible may be for video or iphone video only
	this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0.66);
	target.delay(3);
	this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0.25);

	UIALogger.logMessage("Now Playing: Test rotation with waiting for animations...");
	target.setDeviceOrientation(1);
	this.waitForAnimations();
	target.setDeviceOrientation(3);
	this.waitForAnimations();
	target.setDeviceOrientation(1);
	this.waitForAnimations();
	this.waitUntilPresent(UIAQuery.Podcasts.FF15_BUTTON, 3); // <rdar://problem/25810216>
	UIALogger.logMessage("Now Playing: Tap 3 times each Fast-forward then Rewind...");
	this.tap(UIAQuery.Podcasts.FF15_BUTTON, {tapCount: 3});
	target.delay(2);
	this.tap(UIAQuery.Podcasts.REW15_BUTTON, {tapCount: 10});  // <rdar://problem/23903817>

	// Verify we're still playing
	this.verifyPlaying();

	/*
	// Define correct speed button on iPads playing videos
	if (iPad && options.isVideo) {
		UIAQuery.Podcasts.SPEED_BUTTON = UIAQuery.buttons().atIndex(2);
	}
	*/
	UIALogger.logMessage("Now Playing: Playback Speed tests...");
	// For now, assume we're at Normal Speed...
	this.tap(UIAQuery.Podcasts.SPEED_BUTTON);
	target.delay(1);
	UIAUtilities.assertEqual(
		CAMMediaRemote.getNowPlayingPlaybackRate(),
		1.5,
		'Playback not running at 1.5 times speed'
	);
	this.tap(UIAQuery.Podcasts.SPEED_BUTTON);
	target.delay(1);
	UIAUtilities.assertEqual(
		CAMMediaRemote.getNowPlayingPlaybackRate(),
		2,
		'Playback not running at 2 times speed'
	);
	this.tap(UIAQuery.Podcasts.SPEED_BUTTON);
	target.delay(1);
	UIAUtilities.assertEqual(
		CAMMediaRemote.getNowPlayingPlaybackRate(),
		.5,
		'Playback not running at .5 times speed'
	);
	this.tap(UIAQuery.Podcasts.SPEED_BUTTON);
	// Should be playing at normal speed now
	UIAUtilities.assertEqual(
		CAMMediaRemote.getNowPlayingPlaybackRate(),
		1,
		'Playback not running at normal speed'
	);

	UIALogger.logWarning("WARN - UP NEXT NOT IMPLEMENTED.  SKIPPING...");
	/*
	UIALogger.logMessage("Now Playing: Tap Up Next...");
	this.tap(UIAQuery.Podcasts.UPNEXT_BUTTON);
	target.delay(3);
	if (iPad) {
		this.tap(UIAQuery.Podcasts.UPNEXT_DONE_BUTTON);
	} else {
		this.tap(UIAQuery.Podcasts.DONE_NAVBAR);
	}
	this.waitForAnimations();
*/
	// simple workaround for running out of time:
	this.tap(UIAQuery.Podcasts.REW15_BUTTON, {tapCount: 15});


	UIALogger.logMessage("Now Playing: Tap More Button...");
	this.tap(UIAQuery.Podcasts.MORE_BUTTON);
	target.delay(3);
	if (iPad) {
		this.tap(UIAQuery.Podcasts.DISMISS_POPUP);
	} else {
		this.tap("Cancel"); // UI keeps changing here
	}

	// change or remove this:
	/*
	UIALogger.logMessage("Now Playing: Tap Sharing, then Copy Link...");
	this.tap(UIAQuery.Podcasts.SHARE_BUTTON);
	target.delay(3);
	this.tap("Copy Link"); // dismisses as well
*/
	UIALogger.logWarning("WARN - SLEEP TIMER NOT IMPLEMENTED.  SKIPPING...");
	/*
	UIALogger.logMessage("Now Playing: Tap Sleep Timer...");
	this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
	target.delay(3);
	this.tap("Off");
*/
	UIALogger.logMessage("Now Playing: Test rotation, 2nd time...");
	target.setDeviceOrientation(1);
	this.waitForAnimations();
	target.setDeviceOrientation(3);
	this.waitForAnimations();
	target.setDeviceOrientation(1);
	this.waitForAnimations();
    // Track progress slider view


    // Finally, stop playback
    // <rdar://problem/25810216> waitforAnimations is not sufficient
    this.waitUntilPresent(UIAQuery.Podcasts.PAUSE_BUTTON, 3);
    this.pause();
	this.verifyNotPlaying();
	// Rewind to avoid errors down the line
	this.tap(UIAQuery.Podcasts.REW15_BUTTON, {tapCount: 20});
	// Close now playing
	this.tapIfExists(UIAQuery.Podcasts.DISMISS_BUTTON);
	UIALogger.logMessage("************* FINISHED: testNowPlayingUI.*************");
};

/**
 * Test subscribing to multiple podcasts using URL's and the '+' button
 *	Useful for run prior to other tests, so that these podcasts are present
 *
 *
 * Expected Starting state: Any
 *
 * @param {object} options
 * @param {boolean} options.isVideo - subscribe to search result
 * @param {boolean} options.isPlaying - subscribe to search result
 *
 */
podcasts.testSubscribeToMultiple = function testSubscribeToMultiple(options) {
	options = UIAUtilities.defaults(options, {
		podcastURLs   : [PODCAST_URLS.Planet_Money, PODCAST_URLS.TEDTalks_video],
		podcastTitles : ['Planet Money',            'TED Talks Daily'],
		waitToDownload: false,
		verify:			true,
	});

	UIALogger.logMessage('***TEST***: testSubscribeToMultiple');

	if (this.isActive()) {
		try {
			UIALogger.logMessage('Attempting to quit Podcasts');
			target.performTask('/usr/bin/killall', ['Podcasts'], 5);
		} catch (err) {
			UIALogger.logWarning('Failed to quit podcasts before continuing');
			UIALogger.logError(err.message);
		}
	}
	this.delay(1); //rdar://problem/24263433
	this.launch();
	this.getToTab(TABS.LIBRARY, {getToTopLevel:false});
	// Subscribe
	for (var i = 0; i < options.podcastURLs.length; i++) {
		this.subscribeViaPlusSignToURL(options.podcastURLs[i],
									   options.podcastTitles[i],
									   {verify:false,
										needToNav:false});
	}
	// Wait for Downloads to complete
	if (options.waitToDownload) {
		this.waitForDownloadsToComplete();
	}
	// Verify all settings
	if (options.verify) {
		this.verifyPodcastSettings(options.podcastTitles, {verifyDefaults: true});
	}
};


/**
 * Checks that the welcome screen is shown at launch and then clears it. Then it verifies it is not shown
 */
podcasts.checkAndClearWelcomeScreen = function checkAndClearWelcomeScreen() {
    this.launch();
    if (this.waitUntilPresent(UIAQuery.Podcasts.PRIVACY_ALERT_START_BUTTON, 10)){
      this.tap(UIAQuery.Podcasts.PRIVACY_ALERT_START_BUTTON);

    }else if (this.waitUntilPresent(UIAQuery.Podcasts.PRIVACY_ALERT_HEADER, 10)){
      this.tap(UIAQuery.Podcasts.PRIVACY_ALERT_START_BUTTON);
    }else{
      throw new UIAError ('Failed to find welcome screen or button.');
    }

    UIAUtilities.assert(
        this.waitUntilAbsent(UIAQuery.Podcasts.PRIVACY_ALERT_HEADER),
        'Welcome screen was not dismissed'
    );

     UIAUtilities.assert(
        this.waitUntilPresent(UIAQuery.Podcasts.LISTEN_NOW_TAB, 15),
        'Listen Now tab not present'
    );
};

/********************************************************************************/
/*                                                                              */
/*   Mark: Tasks - Verify Functions                                             */
/*                                                                              */
/*      Helper functions for verifying different pages within the app 	        */
/*		We use different functions because verification for each view/page      */
/*			is very different, and a lot of verification will be done           */
/*                                                                              */
/********************************************************************************/


/**
 * Function that verifies a user was taken to the correct location in the app after tapping on a shared link.
 * Verification of sharing when the user does not have the podcast currently not implemented
 *
 * Expected starting state: Just after clicking on a shared link
 * @param {bool} isEpisode - True indicates an episode was shared, false, an entire podcast
 * @param podcastTitle - Title of podcast that was shared
 * @param {object} options - Array of optional arguments
 * @param {string} options.episodeTitle - Title of episode that was shared
 * @param {bool} options.inCollection - True if verifying for a podcast with a container, false if store
 */
podcasts.verifyCorrectItemWhenShared = function verifyCorrectItemWhenShared (isEpisode, podcastTitle, options) {
	options = UIAUtilities.defaults(options, {
		episodeTitle : null,
		inCollection : true,
	});
	UIALogger.logMessage("VERIFY verifyCorrectItemWhenShared %0".format(podcastTitle));
	// Catches if needed arguments were not passed in
	if (isEpisode && options.episodeTitle === null) {
		throw new UIAError ('Need episode title to verify episode. No episode title passed in.');
	}

	if (options.inCollection) {
		// Verify on My Podcasts
		this.assertExists(UIAQuery.Podcasts.LIBRARY_TAB.isSelected());
		// Verify episode is expanded if episode was shared and episode is on screen
		if (isEpisode) {
			this.assertNotExists(
				UIAQuery.tableCells().contains(options.episodeTitle).andThen(UIAQuery.buttons('more\u2026')),
				'Episode that was shared is not expanded');
			this.assertExists(
				UIAQuery.tableCells().contains(options.episodeTitle).isVisible(),
				'Episode is not visible');
		} else {
			this.assertExists(
				UIAQuery.tableViews().andThen(UIAQuery.staticTexts(podcastTitle)),
				'UI not in to the correct podcast container');
		}
	}

	if (!options.inCollection) {
		// TODO: Implement this
	}
};


/**
 * Verifies the play states of episodes are what is expected
 *
 * Expected starting state - On the tab with the episodes to be verified
 *
 * @param {string} playState - The play state that is expected. Can be Unplayed, Played, Partially played or Now Playing
 * @param {string[]} episodeTitles - String array containing the title of the episodes to verify
 *
 * @throws if play state of episode does not match or episode cannot be found
 * @returns none
 */
podcasts.verifyEpisodePlayState = function verifyEpisodePlayState(playState, episodeTitles) {

	UIALogger.logMessage('VERIFY: verifyEpisodePlayState');

	UIAUtilities.assertNotEqual(
					VALID_PLAYSTATES.indexOf(playState),
					-1,
					'Play state %0 is not a valid play state'.format(playState)
	);

	for (var i = 0; i < episodeTitles.length; i++) {
		UIALogger.logMessage('Verifying play state of %0'.format(episodeTitles[i]));
		// Waiter added to try to work around <rdar://problem/27004180> Podcasts: Item That Existed Was Thought to Not Exist
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.tableCells().contains(episodeTitles[i]).rightmost(), 10),
			'Episode %0 did not exist after 10 seconds'.format(episodeTitles[i])
		);
		var episodeDetails = this.getAllEpisodeData(episodeTitles[i]);
		UIAUtilities.assertEqual(
				episodeDetails.playState,
				playState,
				"Episode %0's play state was %1 and should have been %2".format(
						episodeTitles[i], episodeDetails.playState, playState));
	}
	UIALogger.logMessage('PASS* Episode play states verified');
};


/**
 * Verifies an individual episode downloads by looking for the purchase button. If no download occurs the function
 * will throw an error even if the episode was already downloaded. This function does not work due to
 * rdar://problem/25528451
 *
 * Expected starting state - Download already in progress with episode downloading visible
 *
 * @param options - options dictionary
 * @param {string} episodeTitle - Title of the episode to check
 * @param {number} [options.timeout=120] - Number of seconds to wait for download to complete
 *
 * @throws if episode is not downloaded or does not download
 */
podcasts.verifyIndividualEpisodeDownload = function verifyIndividualEpisodeDownload(episodeTitle, options) {
	options = UIAUtilities.defaults(options, {
		timeout          : 120,
	});

	UIALogger.logMessage('FUNCTION: verifyIndividualEpisodeDownload');
	this.logStartingOptions(options, 'episodeTitle = "%0"'.format(episodeTitle));

	// Query to download progress button of passed in episode
	var query = UIAQuery.tableCells().contains(episodeTitle).children().andThen(UIAQuery.Podcasts.DOWNLOAD_PROGRESS);

	// Wait for downloads progress indicator to appear and fail if it doesn't
	UIAUtilities.assert(
			this.waitUntilPresent(query, 30),
			'Download progress indicator did not appear after 30 seconds');

	UIALogger.logMessage('Download progress button appeared');

	// Wait for timeout number of seconds for PurchaseButton to disappear
	UIAUtilities.assert(
			this.waitUntilAbsent(query, options.timeout),
			'Download did not complete after %0 seconds'.format(options.timeout));

	this.delay(1); //Sometimes it moves too fast and gets episode information before it has been updated
	// Verify episode is now seen as downloaded
	UIAUtilities.assert(
			this.getAllEpisodeData(episodeTitle).downloaded,
			'Though purchase button is not present episode is not downloaded');

	UIALogger.logMessage('verifyIndividualEpisodeDownload complete');
};


/**
 * Verify the Browse Tab
 * Essentially waits for UI to render
 *
 * Expected starting state - must already be on the Browse tab;
 * Best to not call directly - getToTab will call this
 *
 * @param {object} options - Array of optional arguments
 * @param {bool} options.noPodcasts - if True, store page should be blank (e.g. no wi-fi connection on first launch)
 * @param {int} options.waitToLoadTime - time allotted for store page to load
 *
 * @throws if page contents do not load in allotted time
 */
podcasts.verifyBrowseTab = function verifyBrowseTab(options) {
	UIALogger.logMessage("VERIFY: verifyBrowseTab");
	options = UIAUtilities.defaults(options, {
        noPodcasts:		false,
        waitToLoadTime:	WAIT_TIME,
    });
    var verified = true;

	// TODO:  Use noPodcasts for when store is expected to NOT load
		// e.g. wifi is off, etc.
	// TODO: verify the banner lockup has loaded (store content) after the UI loads
	if (podcasts.waitUntilPresent(UIAQuery.Podcasts.FEATURED, options.waitToLoadTime)) {
		UIALogger.logMessage("Featured cell found on page.");
	} else {
		verified = false;
		UIALogger.logMessage("%0 was not found after: %1".format(
			"Featured",
			options.waitToLoadTime)
		);
	}

	// Verify UI state after giving time for page to load
	//Finished verifying
	if (verified) {
		UIALogger.logMessage("•PASS: The Browse tab did verify.");
	} else {
		throw new UIAError("•••FAIL: The Browse tab failed to verify.");
	}
};


/**
 * Verify the My Podcasts Tab
 */
podcasts.verifyMyPodcastsTab = function verifyMyPodcastsTab(options) {
	UIALogger.logMessage("VERIFY: verifyMyPodcastsTab");
	options = UIAUtilities.defaults(options, {
        noPodcasts:		false,
        waitToLoadTime:	WAIT_TIME,
    });
	var verified = true;

	if (options.noPodcasts) {
		UIALogger.logMessage("•WARN: Need to verify empty library text.");
		/*
		if (!podcasts.exists(UIAQuery.staticTexts(
				UIStateDescription.Podcasts.NO_PODCASTS).isVisible())) {
			verified = false;
			UIALogger.logMessage("•FAIL:Expected 'No Podcasts' text to exist, but it didn't.");
		}
		*/
	}
	//Finished verifying
	if (verified) {
		UIALogger.logMessage("•PASS: My Podcasts tab did verify.");
	} else {
		throw new UIAError("•••FAIL: My Podcasts tab failed to verify.");
	}
};


/**
 * Verify the app is NOT playing.
 *
 * @param {Object} options - options dictionary
 * @param {number} [options.waitTime=2] - Number of seconds to wait for playback to stop before failing
 * @param {string} [options.errorMessage=""] - Optional string to append to standard error message
 *
 *
 * @throws if not playing
 * @returns None
 */
podcasts.verifyNotPlaying = function verifyNotPlaying(options) {
	options = UIAUtilities.defaults(options, {
		waitTime      : 2,
		errorMessage  : '',
	});

	var activeApp = target.activeApp();
	UIALogger.logMessage("VERIFY verifyNotPlaying");
	UIALogger.logMessage('waitTime = "%0", errorMessage = "%1"'.format(options.waitTime, options.errorMessage));

	var pauseButton = activeApp.exists(UIAQuery.Podcasts.PAUSE_BUTTON);
	var isCAMPlaying = CAMMediaRemote.isMediaPlaying();
	var timer = 0;

	while ((isCAMPlaying || pauseButton) && timer < options.waitTime) {
		activeApp.delay(1);
		timer++;
	}
	UIAUtilities.assert(
		!CAMMediaRemote.isMediaPlaying(),
		'Playback failed to pause after %0 seconds. %1'.format(options.waitTime, options.errorMessage).trim()
	);

	UIALogger.logMessage("•Pass: App is NOT playing.");
};


/**
 * Verify the app is playing
 *	Works for both audio and video, mini-player or full-screen
 * Expected starting state:  mini-player or Now Playing must be visible
 * @param {object} options - Options dictionary
 * @param {bool} options.isMiniPlayer - If true, mini-player UI is expected; otherwise Now Playing view
 * @throws if not playing
 * @returns None
 */
podcasts.verifyPlaying = function verifyPlaying(options) {
	UIALogger.logMessage("VERIFY PLAYING");
	options = UIAUtilities.defaults(options, {
        isMiniPlayer:	false,
    });
	var counter = 0;
	var theQuery = null;
	// Now Playing and mini-player in Eagle have different queries
	if(options.isMiniPlayer) {
		UIALogger.logMessage("Verifying MiniPlayer playing");
		theQuery = UIAQuery.Podcasts.PAUSE_BUTTON_MINI;
	} else {
		theQuery = UIAQuery.Podcasts.PAUSE_BUTTON;
	}

	// Verify app is playing
	UIAUtilities.assert(
  		this.exists(theQuery),
  		"•FAIL:  App is not currently playing."
	);
	// Verify core media is playing
	// BUG:  possibly in script;  sometimes Core Media is not playing, though the app is
	// if we're streaming, wait for core media to play back
	while (counter <= 15) {
		if(CAMMediaRemote.isMediaPlaying()) {
			UIALogger.logMessage("•PASS: App is playing.");
			break;
		} else if (counter >= 15) {
			throw new Error("•••FAIL:  App is playing, but Core Media is not.");
		} else {
			UIALogger.logMessage("•WARN: Core Media is not playing on %0 attempts...".format(counter));
			counter++;
			target.delay(2);
		}
	}
};


/**
 * Determines if episodes are under played episodes to be deleted. Does not work if episode is scrolled above the header
 *
 * Starting state: In podcast container with episodes to verify
 *
 * @param {string[]} episodesToVerify - Array of episodes to verify as being under played episodes to be deleted
 *
 * @throws if episodes are not found under the header
 * @returns none
 */
podcasts.verifyPlayedToBeDeleted = function verifyPlayedToBeDeleted(episodesToVerify) {
	UIALogger.logMessage('VERIFY: verifyPlayedToBeDeleted');

	for (var i = 0; i < episodesToVerify.length; i++) {
		this.assertExists(UIAQuery.contains(episodesToVerify[i]).below('Played Episodes to be Deleted'));
	}
	UIALogger.logMessage('All episodes under the played episodes to be deleted header');
};

/**
 * Verifies the settings of a podcast or a group of podcasts.
 *
 * Updated for Tigris and new Tigris settings UI
 *
 * Expected starting state: Any
 *
 * @param {object} options - Options dictionary
 * @param {string} options.expectedOrder - null for don't check at all, 
 *        "sequentialOrder", "mostRecentFirst", or "keepMostRecent" 
 * @param {bool} options.customSettings - If true, sets podcast to "Custom Settings"
 * @param {bool} options.oldestToNewest - If true, sets it to Oldest to Newest, if false, sets it to Newest to Oldest
 * @param {bool} options.subscribed - If false, turns subscribed off, true, turns subscribed on
 * @param {bool} options.notifications - If false, turns notifications off, true, turns notification on
 * @param {string} options.refresh - String representing refresh rate
 * @param {string} options.limit - String representing limit episode setting
 * @param {string} options.download - String representing download setting
 * @param {string} options.deleteSetting - String representing the delete setting
 * @param {bool} [options.verifyDefaults=false] - If true, verifies podcast is subscribed, notifications are on,
 *      Customer Settings is selected and Limit, Download, Delete, and Refresh settings are set to default
 * @param {string[]|string} toVerify - Array containing podcasts to change the settings of, or name of one podcast
 *
 * @throws if settings don't match
 * @returns none
 */
podcasts.verifyPodcastSettings = function verifyPodcastSettings(toVerify, options) {
    options = UIAUtilities.defaults(options, {
        expectedOrder 	  : null,
        // sequentialOrder   : false,
       //  mostRecentFirst   : true,
       // keepMostRecent    : false,
       customSettings    : false,
        oldestToNewest    : null,
        subscribed        : null,
        notifications     : null,
        refresh           : null,
        limit             : null,
        download          : null,
        deleteSetting     : null,
        verifyDefaults    : false,
    });

    // If just a string passed in, convert to an array
    if (typeof toVerify == 'string') {
        UIALogger.logMessage('Individual string passed in');
        var a = [];
        a[0] = toVerify;
        toVerify = a;
    }

	UIALogger.logMessage('FUNCTION: verifyPodcastSettings');
	this.logStartingOptions(options, 'toVerify = "%0"'.format(toVerify));

	this.launch();
	this.getToTab(TABS.LIBRARY);
	this.tap(UIAQuery.Podcasts.SHOWS_CELL);
	var podcast;

	if (options.verifyDefaults) {
		UIALogger.logMessage('Will verify default settings.');
		options.subscribed = true;
		options.notifications = true;
		options.refresh = 'Default';
		options.limit = 'Default';
		options.download = 'Default';
		options.deleteSetting = 'Default';
	}

	//Loop over the podcasts passed in verifying the settings
	for (var i = 0; i < toVerify.length; i++) {
		podcast = toVerify[i];
		UIALogger.logMessage('VERIFYING settings for %0'.format(podcast));

		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.tableCells().contains(podcast)),
			'**********Could not find podcast %0**********'.format(podcast)
		);
		this.tap(UIAQuery.tableCells().contains(podcast).rightmost());

		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_ACTION_MENU),
			'Container more... button did not appear after 5 seconds'
		);

    // Tap on the action button and wait for manu to appear, fail if it doesn't
    if (this.inspect(UIAQuery.Podcasts.PODCAST_ACTION_MENU).isVisible){
      UIALogger.logMessage('More Button was visible, select it');
      this.tap(UIAQuery.Podcasts.PODCAST_ACTION_MENU);
    }else{
      var tapRect = podcasts.inspect(UIAQuery.Podcasts.PODCAST_ACTION_MENU).rect;
      var xOffset = tapRect.x / target.mainScreen().rect().width;
      var yOffset = tapRect.y / target.mainScreen().rect().height;
      UIALogger.logMessage('Tapping via window offset');
      podcasts.tap(UIAQuery.application(), {offset: {x: xOffset, y: yOffset}});
    }


		// Wait for action window to appear
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_ACTION_SETTINGS),
			'Podcast action menu did not open after 5 seconds'
		);

		this.tap(UIAQuery.Podcasts.PODCAST_ACTION_SETTINGS);

		// Wait for the settings window to open
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_WINDOW),
			'Settings window did not appear after 5 seconds'
		);

        if (options.subscribed !== null) {
            UIALogger.logMessage('Attempting to verify subscribe setting');

            // Throws error if subscribe setting does not match
            UIAUtilities.assert(
                options.subscribed == this.valueOf(UIAQuery.switches('Subscribed')),
                'Subscription setting not correct'
            );
        }

        if (options.notifications !== null) {
            UIALogger.logMessage('Attempting to verify notifications setting');

            // Throws error if notification setting does not match
            UIAUtilities.assert(
                options.notifications == this.valueOf(UIAQuery.switches('Notifications')),
                'notification setting not correct'
            );
        }
		
		if (options.expectedOrder) {
			if (options.expectedOrder === "sequentialOrder" ) {
				UIALogger.logMessage('Verifying sequential order');
				this.assertExists(
					UIAQuery.Podcasts.PODCAST_SETTINGS_SEQ_ORDER.isSelected(),
					'Play in Sequential Order is not selected'
				);
			} else if (options.expectedOrder === "mostRecentFirst") {
				UIALogger.logMessage('Verifying most recent first');
				this.assertExists(
					UIAQuery.Podcasts.PODCAST_SETTINGS_REC_FIRST.isSelected(),
					'Play Most Recent First is not selected'
				);
			} else if (options.expectedOrder === "keepMostRecent") {
				UIALogger.logMessage('Verifying keep most recent');
				this.assertExists(
					UIAQuery.Podcasts.PODCAST_SETTINGS_KEEP_RECENT.isSelected(),
					'Only Keep the Most Recent Episodes is not selected'
				);

				if (options.limit !== null) {
					this.assertExists(
						UIAQuery.query(options.limit).parent().isSelected(),
						'%0 is not selected'.format(options.limit)
					);
				}
			} else {
				throw new UIAError('•••FAIL verifyPodcastSettings(): Unknown Sort Order passed in for Settings: %0'.format(options.expectedOrder));
			}
			
        } else if (options.customSettings) {
            UIALogger.logMessage('Verifying custom settings');
            this.assertExists(
                UIAQuery.Podcasts.PODCAST_SETTINGS_CUSTOM.isSelected(),
                'Custom Settings is not selected'
            );

            if (options.oldestToNewest !== null) {
                UIALogger.logMessage('Attempting to verify play order setting.');
                var episodeOrderText;

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_PLAY);
                if (options.oldestToNewest) {
                    episodeOrderText = 'Oldest to Newest';
                } else {
                    episodeOrderText = 'Newest to Oldest';
                }

                // Wait for play order screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_PLAY_NAVBAR),
                    'Play order settings did not open after 5 seconds'
                );

                // Throws error if setting does not match
                this.assertExists(UIAQuery.query(episodeOrderText).parent().isSelected(), 'Play order not correct');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.refresh !== null) {
                UIALogger.logMessage('Attempting to verify refresh setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH);
                // Wait for refresh settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH_NAVBAR),
                    'Refresh settings did not open after 5 seconds'
                );

                // Finds what the app default is listed as to use for verification
                if (options.refresh === 'Default') {
                    options.refresh = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.refresh, 'Make sure you pass only one of the following strings, Default, 1' +
                    ' Hour, 6 Hours, Day, Week, Manually.');

                // Throws error if refresh setting is incorrect
                this.assertExists(UIAQuery.query(options.refresh).parent().isSelected(), 'Refresh setting not correct');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.limit !== null) {
                UIALogger.logMessage('Attempting to verify limit setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT);
                // Wait for limit settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT_NAVBAR),
                    'Limit settings did not open after 5 seconds'
                );

                // Finds the app default for limit episodes
                if (options.limit === 'Default') {
                    options.limit = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.limit, 'Make sure you pass only one of the following strings, Default, Off,' +
                    ' Most Recent, 2 Most Recent, 3 Most Recent, 5 Most Recent, 10 Most Recent, 1 Day, 1 Week, 2 Weeks,' +
                    ' 1 Month');

                // Throws error if limit setting does not match
                this.assertExists(UIAQuery.query(options.limit).parent().isSelected(), 'Limit setting not correct');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.download !== null) {
                UIALogger.logMessage('Attempting to verify download setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD);
                // Wait for download settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD_NAVBAR),
                    'Download settings did not open after 5 seconds'
                );

                // Find the app default for downloads
                if (options.download === 'Default') {
                    options.download = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.download, 'Make sure you only pass one of the following strings, Default, Off,' +
                    ' Only New, All Unplayed');

                // Throws error is download setting does not match
                this.assertExists(UIAQuery.query(options.download).parent().isSelected(), 'Download setting not correct');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.deleteSetting !== null) {
                UIALogger.logMessage('Attempting to verify delete setting');
                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE);
                // Wait for delete settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE_NAVBAR),
                    'Delete settings did not open after 5 seconds'
                );

                // Finds the app default for delete episodes
                if (options.deleteSetting === 'Default') {
                    options.deleteSetting = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.deleteSetting, 'Make sure you only pass one of the following strings, Default,' +
                    ' On, Off');

                // Throws error if delete setting does not match
                this.assertExists(UIAQuery.query(
                    options.deleteSetting).parent().isSelected(),
                    'Delete setting not correct');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }
        }

        this.tap("Done");
        this.waitUntilReady();
        this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);
	}
};

/**
 * Takes in an options dictionary and verifies the values of the app settings match. Only checks the values that are
 * passed in
 *
 * Expected starting state : Any
 *
 * @param {{}} options - options dictionary
 * @param {bool} [options.allowNotifications] - Verifies Allow Notifications setting
 * @param {bool} [options.showInNotificationCenter] - Verifies Show In Notification Center setting
 * @param {bool} [options.badgeAppIcon] - Verifies Badge App Icon setting
 * @param {bool} [options.showOnLockScreen] - Verifies Show on Lock Screen setting
 * @param {string} [options.alertStyle] - String to select alert type. Valid inputs are, 'None', 'Banners' or 'Alerts'
 * @param {bool} [options.backgroundAppRefresh] - Verifies Background App Refresh setting
 * @param {bool} [options.cellularData] - Verifies Cellular Data setting
 * @param {bool} [options.syncPodcasts] - Verifies Sync Podcasts setting
 * @param {bool} [options.onlyDownloadOnWifi] - Verifies Only Download on Wi-Fi setting
 * @param {string} [options.refreshEvery] - Verifies the Refresh Every setting with the string passed in. Valid
 * 		inputs are '1 Hour', '6 Hours', 'Day', 'Week', 'Manually'
 * @param {string} [options.limitEpisodes] - Verifies the Limit Episodes setting with the string passed in. Valid
 * 		inputs are 'Off', 'Most Recent', '2 Most Recent', '3 Most Recent', '5 Most Recent', '10 Most Recent',
 * 		'1 Day', '1 Week', '2 Weeks', '1 Month'
 * @param {string} [options.downloadEpisodes] - Verifies the Download Episodes setting with the string passed in. Valid
 * 		inputs are 'Off', 'Only New', 'All Unplayed'
 * @param {bool} [options.deletePlayedEpisodes] - Verifies Delete Played Episodes setting
 * @param {bool} [options.customColors] - Verifies Custom Colors setting
 *
 * @throws if settings do not match the expected value
 */
podcasts.verifyAppSettings = function verifyAppSettings(options) {
	options = UIAUtilities.defaults(options, {
		allowNotifications       : null,
		showInNotificationCenter : null,
		badgeAppIcon             : null,
		showOnLockScreen         : null,
		alertStyle               : null,
		backgroundAppRefresh     : null,
		cellularData             : null,
		syncPodcasts             : null,
		onlyDownloadOnWifi       : null,
		refreshEvery             : null,
		limitEpisodes            : null,
		downloadEpisodes         : null,
		deletePlayedEpisodes     : null,
		customColors             : null,
	});

	UIALogger.logMessage('FUNCTION: verifyAppSettings');
	this.logStartingOptions(options);
	var localNotificationNav = null;
	// If settings item is not set to null, script changes to that setting and confirms the switch worked
	if (options.allowNotifications !== null) {
		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		settings.chooseSetting(localNotificationNav);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Allow Notifications')),
			options.allowNotifications,
			'Allow Notifications setting does not match expectation.'
		);
	}

	if (options.showInNotificationCenter !== null) {
		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		settings.chooseSetting(localNotificationNav);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Show in Notification Center')),
			options.showInNotificationCenter,
			'Show in Notification Center setting does not match expectation.'
		);
	}

	if (options.badgeAppIcon != null) {
		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		settings.chooseSetting(localNotificationNav);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Badge App Icon')),
			options.badgeAppIcon,
			'Badge App Icon setting does not match expectation.'
		);
	}

	if (options.showOnLockScreen != null) {
		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		settings.chooseSetting(localNotificationNav);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Show on Lock Screen')),
			options.showOnLockScreen,
			'Show On Lock Screen setting does not match expectation.'
		);
	}

	if (options.alertStyle != null) {
		UIAUtilities.assert(
			VALID_ALERT_TYPES.contains(options.alertStyle),
			'Refresh option invalid. Was %0, should have been one of %1'.format(options.alertStyle, VALID_ALERT_TYPES)
		);

		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		settings.chooseSetting(localNotificationNav);
		settings.assertExists(
			UIAQuery.query(options.alertStyle).isSelected(),
			'%0 is not selected.'.format(options.alertStyle)
		);
	}

	if (options.backgroundAppRefresh != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Background App Refresh')),
			options.backgroundAppRefresh,
			'Background App Refresh setting does not match expectation'
		);
	}

	if (options.cellularData != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Cellular Data')),
			options.cellularData,
			'Cellular Data setting does not match expectation'
		);
	}

	if (options.syncPodcasts != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Sync Podcasts')),
			options.syncPodcasts,
			'Sync Podcasts setting does not match expectation'
		);
	}

	if (options.onlyDownloadOnWifi != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Only Download on Wi-Fi')),
			options.onlyDownloadOnWifi,
			'Only Download on Wi-Fi setting does not match expectation'
		);
	}

	if (options.refreshEvery != null) {
		UIAUtilities.assert(
			VALID_REFRESH_SETTINGS.contains(options.refreshEvery),
			'Refresh option invalid. Was %0, should have been one of %1'.format(options.refreshEvery, VALID_REFRESH_SETTINGS)
		);

		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		var localRefreshNav = SETTINGS_NAV_ARRAYS.refresh.slice();
		settings.chooseSetting(localRefreshNav);
		UIAUtilities.assertEqual(
			settings.inspect(UIAQuery.tableCells().isSelected().rightmost()).label,
			options.refreshEvery,
			'Refresh Every setting does not match expectation'
		);
	}

	if (options.limitEpisodes != null) {
		UIAUtilities.assert(
			VALID_LIMIT_SETTINGS.contains(options.limitEpisodes),
			'Limit Episodes option invalid. Was %0, should have been %1'.format(options.limitEpisodes, VALID_LIMIT_SETTINGS)
		);

		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		var localLimitNav = SETTINGS_NAV_ARRAYS.limit.slice();
		settings.chooseSetting(localLimitNav);
		UIAUtilities.assertEqual(
			settings.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost(), 'label'),
			options.limitEpisodes,
			'Limit Episodes setting does not match expectation'
		);
	}

	if (options.downloadEpisodes != null) {
		UIAUtilities.assert(
			VALID_DOWNLOAD_SETTINGS.contains(options.downloadEpisodes),
			'Download Episodes option invalid. Was %0, should have been %1'.format(options.downloadEpisodes, VALID_DOWNLOAD_SETTINGS)
		);

		// Handles the fact that chooseSetting manipulates the array passed in making it useless as a global.
		// <rdar://problem/24827952> settings.chooseSetting Destroys the Array Passed in to It
		var localDownloadNav = SETTINGS_NAV_ARRAYS.download.slice();
		settings.chooseSetting(localDownloadNav);
		UIAUtilities.assertEqual(
			settings.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost(), 'label'),
			options.downloadEpisodes,
			'Download Episodes setting does not match expectation'
		);
	}

	if (options.deletePlayedEpisodes != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Delete Played Episodes')),
			options.deletePlayedEpisodes,
			'Delete Played Episodes setting does not match expectation'
		);
	}

	if (options.customColors != null) {
		settings.chooseSetting(['Podcasts']);
		UIAUtilities.assertEqual(
			settings.valueOf(UIAQuery.switches('Custom Colors')),
			options.customColors,
			'Custom Colors setting does not match expectation'
		);
	}

	UIALogger.logMessage('All app settings verified');
};


/**
 * Verify the Search Tab
 */
podcasts.verifySearchTab = function verifySearchTab(options) {
	UIALogger.logMessage("VERIFY: verifySearchTab");
	options = UIAUtilities.defaults(options, {
        noPodcasts:		false,
        waitToLoadTime:	0,
    });
    var verified = true;

	if (podcasts.waitUntilPresent(UIAQuery.Podcasts.SEARCH_FIELD, options.waitToLoadTime)){
		UIALogger.logMessage("•PASS: Search tab loaded.");
	} else {
		verified = false;
		UIALogger.logMessage("•••FAIL: Search page did not load.");
	}
	//Finished verifying
	if (verified) {
		UIALogger.logMessage("•PASS: Search tab did verify.");
	} else {
		throw new UIAError("•••FAIL: Search tab failed to verify.");
	}
	return true;
};

/**
 * Verifies all episodes that should be on the Unplayed tab appear there and are in the correct order
 */
podcasts.verifyUnplayedTabContents = function verifyUnplayedTabContents() {
	UIALogger.logMessage('FUNCTION: verifyUnplayedTabContents');

	this.getToTab(TABS.LIBRARY);
	var allEpisodes = this.getAllEpisodeDataFromAllContainers();

	// Gets rid of any played episodes from allEpisodes
	for (var i = 0; i < allEpisodes.length; i++) {
		if (allEpisodes[i].playState === 'Played') {
			UIALogger.logMessage('%0 was played and was removed from allEpisodes'.format(allEpisodes[i].title));
			allEpisodes.splice(i, 1);
			i--;
		} else {
			UIALogger.logMessage('%0 was unplayed and was not removed from allEpisodes'.format(allEpisodes[i].title));
		}
	}

	UIALogger.logMessage('allEpisodes was %0'.format(allEpisodes));

	var sortedEpisodes = this.sortEpisodesByDate(allEpisodes);

	this.getToTab(TABS.UNPLAYED);
	for (var k = 0; k < allEpisodes.length; k++) {
		this.assertExists(UIAQuery.tableCells().contains(allEpisodes[k].title),
			'Not all unplayed episodes present on the Unplayed tab');
	}

	// Unless downloads bar present, 2 more table cells than episodes on the unplayed tab
	var unplayedTabCount = this.count(UIAQuery.tableCells()) - 2;

	// Handles download bar being present
	if (!iPad) {
		if (this.exists(UIAQuery.tableCells().topmost().contains('Downloading'))) {
			UIALogger.logMessage('Downloads bar present, subtracting 1 from unplayedTabCount');
			unplayedTabCount--;
		}
	}
	if (unplayedTabCount !== allEpisodes.length) {
		throw new UIAError (
			'Number of unplayed episodes and number of episodes on unplayed not matching, ' +
			'expected %0 episodes but found %1 on Unplayed'.format(allEpisodes.length, unplayedTabCount));
	}

	// Verify the order of episodes on the Unplayed tab
	this.checkEpisodeOrder(sortedEpisodes, {getCleanedTitle : false});
};

/**
 * Verifies that the unplayed counts of the passed in podcasts are greater than, less than or equal to an expected value
 *
 * @param {number} comparison - value to indicate type of comparison. -1 for less than, 0 for equals, 1 for greater than
 * @param {number} compareCount - Number of unplayed episodes used to compare
 * @param {Object} options - options dictionary
 * @param {Object|string} [options.toCompare] - Array of podcasts to validate. If nothing is passed in it verifies
 * 		all podcasts. Otherwise takes a string title of a podcast, array of titles or array of outputs from
 * 		getPodcastContainerData
 * @throws if unplayed counts are not valid on at least one item
 */
podcasts.verifyUnplayedCount = function verifyUnplayedCount(comparison, compareCount, options) {
	options = UIAUtilities.defaults(options, {
		toCompare : []
	});

	this.logStartingOptions(options, 'comparison = %0, compareCount = %1'.format(comparison, compareCount));
	var trueCompare = [];

	switch (typeof options.toCompare) {
		case 'object':
			UIALogger.logMessage('toCompare was an object');
			if (options.toCompare.length === 0) {
				UIALogger.logMessage('toCompare was empty, generating list');
				trueCompare = this.generateListOfOnlyPodcasts();
			} else if (typeof options.toCompare[0] === 'string') {
				UIALogger.logMessage('toCompare is an array of strings, getting podcast data');
				for (var i = 0; i < options.toCompare.length; i++) {
					trueCompare.push(this.getPodcastContainerData(this.inspectElementKey(
						UIAQuery.tableCells().contains(options.toCompare[i]), 'label')));
				}
			} else {
				UIALogger.logMessage('Items in toCompare are not strings. Assuming they are dictionaries from' +
					' getPodcastContainerData');
				if (Array.isArray(options.toCompare)) {
					trueCompare = options.toCompare;
				} else {
					trueCompare.push(options.toCompare);
				}
			}
			break;

		case 'string':
			UIALogger.logMessage('toCompare was a string');
			trueCompare.push(this.getPodcastContainerData(this.inspectElementKey(
				UIAQuery.tableCells().contains(options.toCompare), 'label'
			)));
			break;

		default:
			throw new UIAError('%0 is not a valid type for toCompare'.format(typeof options.toCompare));
	}

	var isGood = true;
	var errors = [];
	for (var c = 0; c < trueCompare.length; c++) {
		var unplayedCount = parseInt(trueCompare[c]['unplayedCount']);
		UIALogger.logMessage('Unplayed count of "%0" was %1'.format(trueCompare[c]['title'], unplayedCount));
		var resultString;
		var individualCompareGood = true;

		switch (comparison) {
			case -1:
				UIALogger.logMessage('Verifying unplayed is less than compareCount');
				if (compareCount <= unplayedCount) {
					resultString = 'Unplayed count for "%0" of %1 is not less than compareCount'.format(trueCompare[c]['title'], unplayedCount);
					isGood = false;
					individualCompareGood = false;
				} else {
					resultString = 'Unplayed count for "%0" of %1 is less than compareCount'.format(trueCompare[c]['title'], unplayedCount);
				}
				break;
			case 0:
				UIALogger.logMessage('Verifying unplayed is equal to compareCount');
				if (unplayedCount !== compareCount) {
					resultString = 'Unplayed count for "%0" of %1 is not equal to compareCount'.format(trueCompare[c]['title'], unplayedCount);
					isGood = false;
					individualCompareGood = false;
				} else {
					resultString = 'Unplayed count for "%0" of %1 is equal to compareCount'.format(trueCompare[c]['title'], unplayedCount);
				}
				break;
			case 1:
				UIALogger.logMessage('Verifying unplayed is greater than compare count');
				if (compareCount >= unplayedCount) {
					resultString = 'Unplayed count for "%0" of %1 is not greater than compareCount'.format(trueCompare[c]['title'], unplayedCount);
					isGood = false;
					individualCompareGood = false;
				} else {
					resultString = 'Unplayed count for "%0" of %1 is greater than compareCount'.format(trueCompare[c]['title'], unplayedCount);
				}
				break;
			default:
				throw new UIAError ('%0 is not a valid comparison value'.format(comparison));
		}

		if (!individualCompareGood) {
			errors.push(resultString);
			UIALogger.logFail(resultString);
		} else {
			UIALogger.logPass(resultString);
		}
	}

	if (!isGood) {
		UIALogger.logTAResults({'unplayedErrors':errors});
		throw new UIAError('Unplayed counts are not as expected.');
	} else {
		UIALogger.logPass('Unplayed counts verified');
	}
};

/**
 * Verify the settings in a station
 *
 * Expected starting state: Any, unless passing false for options.needToNavigate
 *
 * @param {string[]} toVerify - Array containing the stations to have their settings verified
 * @param {object} options - options dictionary
 * @param {string} options.playOrder - String to verify the station's play order against
 * @param {bool} options.groupByPodcast - If true, verifies group by podcast is on
 * @param {string} options.episodesToInclude - String to verify the station's episodes to include against
 * @param {string} options.mediaType - String to verify the station's media type setting against
 * @param {bool} options.unplayedOnly - If true, verifies the station's unplayed only option is on
 * @param {bool} options.includeAll - If true, verifies the station's include all option is on
 * @param {bool} options.allDeselected - If true, verifies no podcasts are selected
 * @param {string[]} options.selectedPodcasts - Podcasts that should be included in the station
 * @param {string[]} options.deselectedPodcasts - Podcasts that should be deselected in the station
 * @param {string[]} options.onlyTheseSelected - Verifies that only the podcasts passed in are selected in the station
 * @param {bool} options.needToNavigate - If false, stays on current UI page
 *
 * @throws if settings do not match expected state
 * @returns none
 */

podcasts.verifyStationSettings = function verifyStationSettings(toVerify, options) {
	options = UIAUtilities.defaults(options, {
		playOrder:          null,
		groupByPodcast:     null,
		episodesToInclude:  null,
		mediaType:          null,
		unplayedOnly:       null,
		includeAll:         null,
		allDeselected:      false,
		selectedPodcasts:   null,
		deselectedPodcasts: null,
		onlyTheseSelected:  null,
		needToNavigate:     true,
	});
	UIALogger.logMessage('VERIFY FUNCTION: verifyStationSettings()');

	if (options.needToNavigate) {
		this.launch();
		this.getToTab(TABS.LIBRARY);
	}

	var station;
	var podcast;

	for (var i = 0; i < toVerify.length; i++) {
		station = toVerify[i];
		
		if (options.needToNavigate) {
			this.assertExists(station, 'Station not found');
			this.tap(station);
			this.tap(UIAQuery.query('Edit').rightmost());
			this.tap('Settings');
		}
		
		if (options.playOrder !== null) {
			UIALogger.logMessage('Verifying play order setting');

			if (options.needToNavigate) {
				this.tap(UIAQuery.staticTexts('Play'));
			}

			// Replace standard quotes with unicode smart quotes
			options.playOrder = options.playOrder.replace('"', "\u201C", 1);
			options.playOrder = options.playOrder.replace('"', "\u201D");

			// Catches if passed in setting does not exist
			this.assertExists(options.playOrder, 'Could not find play order option. Pass in only 1 of the following' +
				' strings. "My Podcasts" Order, Newest to Oldest, Oldest to Newest, Manual');

			this.assertExists(UIAQuery.query(options.playOrder).parent().isSelected(), 'Play order setting does not' +
				' match');

			if (options.needToNavigate) {
				this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			}
		}

		if (options.groupByPodcast !== null) {
			UIALogger.logMessage('Verifying Group by Podcast setting');

			UIAUtilities.assert(options.groupByPodcast == this.valueOf(UIAQuery.switches('Group by Podcast')),
				'Group by Podcast setting does not match');
		}

		if (options.episodesToInclude !== null) {
			UIALogger.logMessage('Verifying episodes to include setting');

			if (options.needToNavigate) {
				this.tap('Episodes');
			}

			// Catches if passed in setting does not exist
			this.assertExists(options.episodesToInclude, 'Could not find episodes to include option. Pass in only 1' +
				' of the following strings. Most Recent Episode, Most Recent 2 Episodes, Most Recent 5 Episodes,' +
				' Most Recent 10 Episodes, All Episodes');

			// Verifies setting is correct
			this.assertExists(UIAQuery.query(options.episodesToInclude).parent().isSelected(), 'Episodes to Include' +
				' setting does not match');

			if (options.needToNavigate) {
				this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			}
		}

		if (options.mediaType !== null) {
			UIALogger.logMessage('Verifying Media Type setting');

			if (options.needToNavigate) {
				this.tap('Media Type');
			}

			// Catches if passed in setting does not exist
			this.assertExists(options.mediaType, 'Could not find Media Type option. Pass in only 1 of the following' +
				' strings. All, Audio, Video');

			// Verifies setting is correct
			this.assertExists(UIAQuery.query(options.mediaType).parent().isSelected(), 'Media Type setting does not' +
				' match');

			if (options.needToNavigate) {
				this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			}
		}

		if (options.unplayedOnly !== null) {
			UIALogger.logMessage('Verifying unplayed only setting');

			UIAUtilities.assert(options.unplayedOnly == this.valueOf(UIAQuery.switches('Unplayed Only')),
				'Unplayed only setting does not match');
		}

		if (options.allDeselected ||
			options.onlyTheseSelected !== null ||
			options.selectedPodcasts !== null ||
			options.deselectedPodcasts !== null ||
			options.includeAll !== null) {

			if (options.needToNavigate) {
				this.tap(UIAQuery.contains('Choose Podcasts'));
			}

			if (options.onlyTheseSelected !== null) {
				UIALogger.logMessage('Verifying podcasts to include');

				var query = UIAQuery.tableCells().isSelected();
				var queryCount = this.count(query);

				// Removes 1 selected item from count on iPads since there is always 1 selected tabled cell underneath
				if (iPad) {
					queryCount--;
				}

				for (var j = 0; j < options.onlyTheseSelected.length; j++) {
					podcast = options.onlyTheseSelected[j];

					// Verifies we haven't gone beyond the number of podcasts listed as options
					this.assertExists(query.atIndex(j), 'More podcasts in the list to include then are available to' +
						' be part of the station');

					// Verifies podcast is included in the station
					this.assertExists(query.andThen(UIAQuery.contains(podcast)), 'Podcast %0 not included in station'.format(podcast));
				}

				// Verifies there are not more podcasts included in a station than there should be
				UIAUtilities.assertEqual(
						queryCount,
						options.onlyTheseSelected.length,
						'Incorrect number of items selected in station. Expected %0 and found %1'.format(
								options.onlyTheseSelected.length,
								queryCount));
			}

			if (options.includeAll !== null) {
				UIALogger.logMessage('Verifying Include all Podcasts switch');

				UIAUtilities.assert(options.includeAll == this.valueOf(UIAQuery.switches()), 'Include All' +
					' Podcasts' +
					' setting does not match');
			}

			if (options.allDeselected) {
				UIALogger.logMessage('Verifying all podcasts deselected');

				this.waitUntilPresent(UIAQuery.contains('Choose Podcasts'));

				// Account for iPad always having 1 item selected
				var check;
				if (iPad) {
					check = 1;
				} else {
					check = 0;
				}

				UIAUtilities.assert(this.count(UIAQuery.tableCells().isSelected()) === check, 'Some podcasts are' +
					' selected');
			}

			if (options.selectedPodcasts !== null) {
				UIALogger.logMessage('Verifying podcasts passed in are selected');

				for (var k = 0; k < options.selectedPodcasts.length; k++) {
					podcast = options.selectedPodcasts[k];
					this.assertExists(UIAQuery.tableCells(podcast).isSelected(), '%0 not selected'.format(podcast));
				}
			}

			if (options.deselectedPodcasts !== null) {
				UIALogger.logMessage('Verifying podcasts passed in are not selected');

				for (var l = 0; l < options.deselectedPodcasts.length; l++) {
					podcast = options.deselectedPodcasts[l];
					this.assertNotExists(UIAQuery.tableCells(podcast).isSelected(),
						'%0 is selected and should not be'.format(podcast));
				}
			}
			if (options.needToNavigate) {
				this.tap('back-nav-button');
			}
		}

		if(options.needToNavigate) {
			this.tap('back-nav-button');
			this.tap('Done');
		}
	}

	UIALogger.logMessage('Station settings verified');
};


/**
 * Verify a podcast is subscribed to
 * This function is about to be deprecated
 *
 * Expected starting state:  top level of a tab
 *
 * @param {string} containerName - Podcast name
 *
 * @throws if not subscribed
 * @returns None
 */
podcasts.verifySubscription = function verifySubscription(containerName) {
	//Can delete this whole function - no longer used.
	UIALogger.logMessage("VERIFY Subscription");
	UIALogger.logWarning("•WARN!!!!!!!!!!! This function will soon be deprecated.");

	// Get to My Podcasts
	this.getToTab(TABS.LIBRARY);

	// NOTE: This may fail due to Bug in UIA2 not scrolling to invisible items
	// Tap on podcast container
	podcasts.tap(UIAQuery.beginsWith(containerName));

	var waiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "MTPodcastSettingsViewController"'
	);
	// Tap on settings
	podcasts.tap(UIAQuery.Podcasts.PODCAST_SETTINGS);
	if (!waiter.wait()) {
		throw new UIAError ('••• FAIL: Settings view did not open in time.');
	}
	// read subscription setting
	if (podcasts.valueOf(UIAQuery.query("Subscribed"))) {
		UIALogger.logMessage("•PASS: Subscription verified.");
	} else {
		throw new Error("•••FAIL:  Subscription verification in My Podcasts Settings failed.");
	}
	// Tap out of Settings
	if (iPad) {
		podcasts.dismissPopover();
	} else {
		this.tap('back-nav-button');
	}
};


/**
 * Verify the Top Charts Tab
 * Essentially waits for iTML page content to load from the store - these times can vary widely
 *
 * Expected starting state - must already be on the Top Charts tab;
 * Best to not call directly - getToTab will call this
 *
 * @param {object} options - Array of optional arguments
 * @param {bool} options.noPodcasts - if True, store page should be blank (e.g. no wi-fi connection on first launch)
 * @param {int} options.waitToLoadTime - time allotted for store page to load
 *
 * @throws if page contents do not load in allotted time
 */
podcasts.verifyTopChartsTab = function verifyTopChartsTab(options) {
	UIALogger.logMessage("VERIFY: verifyTopChartsTab");
	options = UIAUtilities.defaults(options, {
        noPodcasts:		false,
        waitToLoadTime:	WAIT_TIME,
    });
    var verified = true;

	// Wait to load
	if (iPad) {
		if (!podcasts.waitUntilPresent(
				UIAQuery.collectionViews("Audio Podcasts").andThen(
				UIAQuery.query('SKUIHorizontalLockupView')),
				options.waitToLoadTime) ) {
			UIALogger.logMessage("•••FAIL: LockupView did not load");
			verified = false;
		}
	} else {
		// phones - slightly different than pads - no "Audio Podcasts" name for collection view
			//- probably due to known BUG
		if (podcasts.waitUntilPresent(UIAQuery.collectionViews().andThen(
				UIAQuery.query('SKUIHorizontalLockupView')),
				options.waitToLoadTime)) {
			UIALogger.logMessage("•PASS: LockupView did load");
		} else {
			verified = false;
			UIALogger.logMessage("•••FAIL: LockupView did not load");
		}
	}
	// Verify
	/* OLD BUG
	if (currentState != UIStateDescription.Podcasts.TOP_CHARTS) {
		if (currentState == UIStateDescription.Podcasts.FEATURED &&
			podcasts.exists(UIAQuery.Podcasts.TOPCHARTS_TAB.isSelected()) ) {
			UIALogger.logMessage("BUG WORKAROUND: Top Charts nav bar name is wrong.");
		} else {
			verified = false;
			UIALogger.logMessage("•••FAIL: State does not match.  Current state: " + currentState);
		}
	}
	*/

	// DO ADDITIONAL VERIFICATION HERE
	// BUG:  <rdar://problem/21424164> ITML Podcasts: Top Charts has no segmented control for Audio - Video
	// May not be fixed until later: workaround for now
	// When fixed:  Check for segmented controls on phone, two columns on pad
	// For now, separate pad/phone verification

	//Finished verifying
	if (verified) {
		UIALogger.logMessage("•PASS: Top Charts tab did verify.");
	} else {
		throw new UIAError("•••FAIL: Top Charts tab failed to verify.");
	}
	return true;
};



/**
 * Verify the Unplayed Tab
 */
podcasts.verifyUnplayedTab = function verifyUnplayedTab(options) {
	UIALogger.logMessage("VERIFY: verifyUnplayedTab");
	options = UIAUtilities.defaults(options, {
        noPodcasts:		false,
        waitToLoadTime:	WAIT_TIME,
    });
	var verified = true;

	if (options.noPodcasts) {
		if (!podcasts.exists(UIAQuery.staticTexts(
				UIStateDescription.Podcasts.NO_PODCASTS).isVisible())) {
			verified = false;
			UIALogger.logMessage("•FAIL:Expected 'No Podcasts' text to exist, but it didn't.");
		}
	}
	//Finished verifying
	if (verified) {
		UIALogger.logMessage("•PASS: Unplayed tab did verify.");
	} else {
		throw new UIAError("•FAIL: Unplayed tab failed to verify.");
	}
};

/**
 * Verify the WiFi is enabled
 */
podcasts.verifyWifi = function verifyWifi() {
	UIALogger.logMessage('VERIFY: verifyWifi');
	var app = target.activeApp();
	UIAUtilities.assert(
		app.exists(UIAQuery.contains('Wi-Fi bars')) ||
		app.exists(UIAQuery.contains('WLAN bars')),
		'Wi-Fi is not running on the device');
};



/********************************************************************************/
/*                                                                              */
/*   Mark: Tasks - Other High-level Functions                                            */
/*                                                                              */
/*      Helper functions for verifying different pages within the app 	        */
/*		We use different functions because verification for each view/page      */
/*			is very different, and a lot of verification will be done           */
/*                                                                              */
/********************************************************************************/


/**
 * Takes in an options dictionary and changes those specified settings to the value specified. Does not touch a
 * setting unless it is passed in. Note: If Allow Notifications is false it makes it impossible to change any of the
 * other notification related settings.
 *
 * Expected starting state : Any
 *
 * @param {{}} options - options dictionary
 * @param {bool} [options.allowNotifications] - Turns Allow Notifications on if true, off is false
 * @param {bool} [options.showInNotificationCenter] - Turns Show in Notification Center on if true, off is false
 * @param {bool} [options.badgeAppIcon] - Turns Badge App Icon on if true, off if false
 * @param {bool} [options.showOnLockScreen] - Turns Show on Lock Screen on if true, off if false
 * @param {string} [options.alertStyle] - String to select alert type. Valid inputs are, 'None', 'Banners' or 'Alerts'
 * @param {bool} [options.backgroundAppRefresh] - Turns Background App Refresh on if true, off if false
 * @param {bool} [options.cellularData] - Turns Cellular Data on if true, off is false
 * @param {bool} [options.syncPodcasts] - Turns Sync Podcasts on if true, off if false
 * @param {bool} [options.onlyDownloadOnWifi] - Turns Only Download on Wi-Fi on if true, off if false
 * @param {string} [options.refreshEvery] - Sets the Refresh Every setting to the string passed in. Valid inputs are
 * 		'1 Hour', '6 Hours', 'Day', 'Week', 'Manually'
 * @param {string} [options.limitEpisodes] - Sets the Limit Episodes setting to the string passed in. Valid inputs are
 * 		'Off', 'Most Recent', '2 Most Recent', '3 Most Recent', '5 Most Recent', '10 Most Recent', '1 Day', '1 Week',
 * 		'2 Weeks', '1 Month'
 * @param {string} [options.downloadEpisodes] - Sets the Download Episodes setting to the string passed in. Valid
 * 		inputs are 'Off', 'Only New', 'All Unplayed'
 * @param {bool} [options.deletePlayedEpisodes] - Turns Delete Played Episodes on if true, off if false
 * @param {bool} [options.customColors] - Turns Custom Colors on if true, off if false
 * @param {bool} [options.newUI] - Turns New UI on if true, off if false
 *
 * @throws if settings cannot be changed
 */
podcasts.changeAppSettings = function changeAppSettings(options) {
	options = UIAUtilities.defaults(options, {
		allowNotifications       : null,
		showInNotificationCenter : null,
		badgeAppIcon             : null,
		showOnLockScreen         : null,
		alertStyle               : null,
		backgroundAppRefresh     : null,
		cellularData             : null,
		syncPodcasts             : null,
		onlyDownloadOnWifi       : null,
		refreshEvery             : null,
		limitEpisodes            : null,
		downloadEpisodes         : null,
		deletePlayedEpisodes     : null,
		customColors             : null,
		newUI					 : null,
	});

	UIALogger.logMessage('FUNCTION: changeAppSettings');
	this.logStartingOptions(options);

	// If settings item is not set to null, script changes to that setting and confirms the switch worked

	if (options.allowNotifications != null) {
		settings.changeSingleSwitch(
			SETTINGS_NAV_ARRAYS.notifications,
			'Allow Notifications',
			options.allowNotifications
		);
		UIALogger.logMessage('Set Allow Notifications to %0'.format(options.allowNotifications));
	}

	if (options.showInNotificationCenter != null) {
		settings.changeSingleSwitch(
			SETTINGS_NAV_ARRAYS.notifications,
			'Show in Notification Center',
			options.showInNotificationCenter
		);
		UIALogger.logMessage('Set Show in Notification Center to %0'.format(options.allowNotifications));
	}

	if (options.badgeAppIcon != null) {
		settings.changeSingleSwitch(
			SETTINGS_NAV_ARRAYS.notifications,
			'Badge App Icon',
			options.badgeAppIcon
		);
		UIALogger.logMessage('Set Badge App Icon to %0'.format(options.badgeAppIcon));
	}

	if (options.showOnLockScreen != null) {
		settings.changeSingleSwitch(
			SETTINGS_NAV_ARRAYS.notifications,
			'Show on Lock Screen',
			options.showOnLockScreen
		);
		UIALogger.logMessage('Set Show On Lock Screen to %0'.format(options.showOnLockScreen));
	}

	if (options.alertStyle != null) {
		UIAUtilities.assert(
			VALID_ALERT_TYPES.contains(options.alertStyle),
			'Alert style invalid. Was %0, should have been one of %1'.format(options.alertStyle, VALID_ALERT_TYPES)
		);
		// Create an array to be used that will navigate to the setting and select it
		var alertNav = SETTINGS_NAV_ARRAYS.notifications.slice();
		alertNav.push(options.alertStyle);
		settings.chooseSetting(alertNav);
		UIALogger.logMessage('Set Alert Style to %0'.format(options.alertStyle));
	}

	if (options.backgroundAppRefresh != null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Background App Refresh',
			options.backgroundAppRefresh
		);
		UIALogger.logMessage('Set Background App Refresh to %0'.format(options.backgroundAppRefresh));
	}

	if (options.cellularData != null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Cellular Data',
			options.cellularData
		);
		UIALogger.logMessage('Set Cellular Data to %0'.format(options.cellularData));
	}

	if (options.syncPodcasts != null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Sync Podcasts',
			options.syncPodcasts
		);
		UIALogger.logMessage('Set Sync Podcasts to %0'.format(options.syncPodcasts));
	}

	if (options.onlyDownloadOnWifi != null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Only Download on Wi-Fi',
			options.onlyDownloadOnWifi
		);
		UIALogger.logMessage('Set Only Download on Wi-Fi to %0'.format(options.onlyDownloadOnWifi));
	}

	if (options.refreshEvery != null) {
		UIAUtilities.assert(
			VALID_REFRESH_SETTINGS.contains(options.refreshEvery),
			'Refresh option invalid. Was %0, should have been one of %1'.format(options.refreshEvery, VALID_REFRESH_SETTINGS)
		);
		// Create an array to be used that will navigate to the setting and select it
		var refreshNav = SETTINGS_NAV_ARRAYS.refresh.slice();
		refreshNav.push(options.refreshEvery);
		settings.chooseSetting(refreshNav);
		UIALogger.logMessage('Set Refresh Every to %0'.format(options.refreshEvery));
	}

	if (options.limitEpisodes != null) {
		UIAUtilities.assert(
			VALID_LIMIT_SETTINGS.contains(options.limitEpisodes),
			'Limit Episodes option invalid. Was %0, should have been %1'.format(options.limitEpisodes, VALID_LIMIT_SETTINGS)
		);

		// Create an array to be used that will navigate to the setting and select it
		var limitNav = SETTINGS_NAV_ARRAYS.limit.slice();
		limitNav.push(options.limitEpisodes);
		settings.chooseSetting(limitNav);
		UIALogger.logMessage('Set Limit Episodes to %0'.format(options.limitEpisodes));
	}

	if (options.downloadEpisodes != null) {
		UIAUtilities.assert(
			VALID_DOWNLOAD_SETTINGS.contains(options.downloadEpisodes),
			'Download Episodes option invalid. Was %0, should have been %1'.format(options.downloadEpisodes, VALID_DOWNLOAD_SETTINGS)
		);

		// Create an array to be used that will navigate to the setting and select it
		var downloadNav = SETTINGS_NAV_ARRAYS.download.slice();
		downloadNav.push(options.downloadEpisodes);
		settings.chooseSetting(downloadNav);
		UIALogger.logMessage('Set Download Episodes to %0'.format(options.downloadEpisodes));
	}

	if (options.deletePlayedEpisodes != null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Delete Played Episodes',
			options.deletePlayedEpisodes
		);
		UIALogger.logMessage('Set Delete Played Episodes to %0'.format(options.deletePlayedEpisodes));
	}

	if (options.customColors !== null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'Custom Colors',
			options.customColors
		);
		UIALogger.logMessage('Set Custom Colors to %0'.format(options.customColors));
	}

	if (options.newUI !== null) {
		settings.changeSingleSwitch(
			['Podcasts'],
			'New UI',
			options.newUI
		);
		UIALogger.logMessage('Set New UI to %0'.format(options.newUI));
	}

	UIALogger.logMessage('Changed all app settings');

};


/**
 * Changes settings of a podcast. To set a setting to default simply pass in the string 'Default'.
 *
 * Updated for Tigris and new Tigris settings UI
 *
 * Expected starting state: Any
 * @param {object} options - Options dictionary
 * @param {bool} options.sequentialOrder - If true, sets podcast to "Play in Sequential Order"
 * @param {bool} options.mostRecentFirst - If true, sets podcast to "Play Most Recent First"
 * @param {bool} options.keepMostRecent - If true, sets podcast to "Only Keep the Most Recent Episodes"
 * @param {bool} options.customSettings - If true, sets podcast to "Custom Settings"
 * @param {bool} options.oldestToNewest - If true, sets it to Oldest to Newest, if false, sets it to Newest to Oldest
 * @param {bool} options.subscribed - If false, turns subscribed off, true, turns subscribed on
 * @param {bool} options.notifications - If false, turns notifications off, true, turns notification on
 * @param {string} options.refresh - String representing refresh rate
 * @param {string} options.limit - String representing limit episode setting
 * @param {string} options.download - String representing download setting
 * @param {string} options.deleteSetting - String representing the delete setting
 * @param {string[]|string} toChange - Array containing podcasts to change the settings of, or name of one podcast
 *
 * @throws if settings don't get changed
 * @returns none
 */
podcasts.changePodcastSettings = function changePodcastSettings(toChange, options) {
	options = UIAUtilities.defaults(options, {
		sequentialOrder   : false,
		mostRecentFirst   : false,
		keepMostRecent    : false,
		customSettings    : false,
		oldestToNewest    : null,
		subscribed        : null,
		notifications     : null,
		refresh           : null,
		limit             : null,
		download          : null,
		deleteSetting     : null,
	});

	// Catch bad input
	UIAUtilities.assert(
		options.sequentialOrder + options.mostRecentFirst + options.keepMostRecent + options.customSettings <= 1,
		'Can pass 1 or 0, of sequentialOrder, mostRecentFirst, keepMostRecent, or customSettings as true'
	);

	// If just a string passed in, convert to an array
	if (typeof toChange == 'string') {
		UIALogger.logMessage('Individual string passed in');
		var a = [];
		a[0] = toChange;
		toChange = a;
	}

	this.launch();
	this.getToTab(TABS.LIBRARY);
	this.tap(UIAQuery.Podcasts.SHOWS_CELL);
	var podcast;

	//Loop over the podcasts passed in, changing the settings
	for (var i = 0; i < toChange.length; i++) {

		podcast = toChange[i];

        this.assertExists(UIAQuery.tableCells().contains(podcast), '**********Could not find podcast %0**********'.format(podcast));
        this.tap(UIAQuery.tableCells().contains(podcast).rightmost());

        this.tap(UIAQuery.Podcasts.PODCAST_ACTION_MENU);

        // Wait for action window to appear
        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_ACTION_SETTINGS),
            'Podcast action menu did not open after 5 seconds'
        );

        this.tap(UIAQuery.Podcasts.PODCAST_ACTION_SETTINGS);

        // Wait for the settings window to open
        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_WINDOW),
            'Settings window did not appear after 5 seconds'
        );

        // Set subscribe option
        if (options.subscribed !== null) {
            UIALogger.logMessage('Attempting to change subscribe setting');

            this.setControl(UIAQuery.switches('Subscribed'), options.subscribed);

            // Verifies subscribed setting was set and throws error if not
            UIAUtilities.assert(
                options.subscribed == this.valueOf(UIAQuery.switches('Subscribed')),
                'Could not set the subscription setting'
            );
        }

        // Set notifications setting
        if (options.notifications !== null) {
            UIALogger.logMessage('Attempting to change notifications setting');

            this.setControl(UIAQuery.switches('Notifications'), options.notifications);

            // Verifies notifications setting was set and throws error if not
            UIAUtilities.assert(
                options.notifications == podcasts.valueOf(UIAQuery.switches('Notifications')),
                'Could not set the notifications setting'
            );
        }

        // Set the settings to match the options passed in
        if (options.sequentialOrder) {
        	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_SEQ_ORDER);

        	this.assertExists(
        		UIAQuery.Podcasts.PODCAST_SETTINGS_SEQ_ORDER.isSelected(),
				'After tapping, Play in Sequential Order is not selected'
			);
		} else if (options.mostRecentFirst) {
        	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_REC_FIRST);

        	this.assertExists(
        		UIAQuery.Podcasts.PODCAST_SETTINGS_REC_FIRST.isSelected(),
				'After tapping, Play Most Recent First is not selected'
			);
		} else if (options.keepMostRecent) {
        	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_KEEP_RECENT);

        	this.assertExists(
        		UIAQuery.Podcasts.PODCAST_SETTINGS_KEEP_RECENT.isSelected(),
				'After tapping, Only Keep the Most Recent Episodes is not selected'
			);

        	if (options.limit !== null) {
        		this.tap(options.limit);

        		this.assertExists(
        			UIAQuery.query(options.limit).parent().isSelected(),
					'After tapping, number of episodes to limit not selected'
				);
			}
		} else {

            if (options.oldestToNewest !== null) {
                UIALogger.logMessage('Attempting to change episode order setting.');
                var episodeOrderText;

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_ORDER);
                // Wait for play order screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_PLAY_NAVBAR),
                    'Play order settings did not open after 5 seconds'
                );
                if (options.oldestToNewest) {
                    episodeOrderText = 'Oldest to Newest';
                } else {
                    episodeOrderText = 'Newest to Oldest';
                }

                this.tap(episodeOrderText);

                // Verifies play order was set and throws error if not
                this.assertExists(UIAQuery.query(episodeOrderText).parent().isSelected(), 'Play order not set');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.refresh !== null) {
                UIALogger.logMessage('Attempting to change refresh setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH);
                // Wait for refresh settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH_NAVBAR),
                    'Refresh settings did not open after 5 seconds'
                );

                // Finds what the app default is listed as to use for verification
                if (options.refresh === 'Default') {
                    options.refresh = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.refresh, 'Make sure you pass only one of the following strings, Default, 1' +
                    ' Hour, 6 Hours, Day, Week, Manually.');
                this.tap(options.refresh);

                // Verifies setting was set, throws error if not
                this.assertExists(UIAQuery.query(options.refresh).parent().isSelected(), 'Refresh setting not set');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.limit !== null) {
                UIALogger.logMessage('Attempting to change limit setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT);
                // Wait for limit settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT_NAVBAR),
                    'Limit settings did not open after 5 seconds'
                );

                // Finds the app default for limit episodes
                if (options.limit === 'Default') {
                    options.limit = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.limit, 'Make sure you pass only one of the following strings, Default, Off,' +
                    ' Most Recent, 2 Most Recent, 3 Most Recent, 5 Most Recent, 10 Most Recent, 1 Day, 1 Week, 2 Weeks,' +
                    ' 1 Month');
                this.tap(options.limit);

                // Verifies setting was changed and throws error if not
                this.assertExists(UIAQuery.query(options.limit).parent().isSelected(), 'Limit setting not set');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.download !== null) {
                UIALogger.logMessage('Attempting to change download setting');

                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD);
                // Wait for download settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD_NAVBAR),
                    'Download settings did not open after 5 seconds'
                );

                // Find the app default for downloads
                if (options.download === 'Default') {
                    options.download = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.download, 'Make sure you only pass one of the following strings, Default, Off,' +
                    ' Only New, All Unplayed');
                this.tap(options.download);

                // Verifies download setting was changed and throws error if not
                this.assertExists(UIAQuery.query(options.download).parent().isSelected(), 'Download setting not set');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }

            if (options.deleteSetting !== null) {
                UIALogger.logMessage('Attempting to change delete setting');
                this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE);
                // Wait for delete settings screen to load
                this.waitUntilReady();
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE_NAVBAR),
                    'Delete settings did not open after 5 seconds'
                );

                // Finds the app default for delete episodes
                if (options.deleteSetting === 'Default') {
                    options.deleteSetting = this.inspectElementKey(UIAQuery.contains('Default'), 'label');
                }

                this.assertExists(options.deleteSetting, 'Make sure you only pass one of the following strings, Default,' +
                    ' On, Off');

                this.tap(options.deleteSetting);

                // Verifies delete setting was set and throws error if not
                this.assertExists(UIAQuery.query(options.deleteSetting).parent().isSelected(), 'Delete setting not set');

                this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());
            }
        }
        this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);
        this.waitUntilReady();
        this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);
	}
};


/**
 * Change the settings in a station. Passing deselectAll as true will deselect all podcasts and then execute the
 * podcastsToSelect and podcastsToDeselect options in that order. Passing includeAll as true means you cannot pass
 * values for deselectAll, podcastsToSelect or podcastsToDeselect. Passing in any of those options will
 * automatically turn off the Include All Podcasts option.
 *
 * Expected starting state: On My Podcasts with the station already created
 *
 * @param {string[]} toChange - Array containing the stations to have their settings changed
 * @param {object} options - options dictionary
 * @param {string[]} options.nameChange - Array matched with toChange to change the name of each station
 * @param {string} options.playOrder - String to change the station's play order
 * @param {bool} options.groupByPodcast - If true, sets group by podcast to on
 * @param {string} options.episodesToInclude - String to change the station's episodes to include setting
 * @param {string} options.mediaType - String to change the station's media type setting to
 * @param {bool} options.unplayedOnly - If true, changes the station's unplayed only option to on
 * @param {bool} options.includeAll - If true, changes the station's include all option to on
 * @param {string[]} options.podcastsToSelect - Podcasts to be individually included in the station
 * @param {string[]} options.podcastsToDeselect - Podcasts to be individually excluded from the station
 * @param {bool} options.deselectAll - If true, deselects all podcasts in station settings
 * @param {boolean} [options.needToNav=true] - False if already on the station settings page
 *
 * @throws if settings do not match expected state
 * @returns none
 */
podcasts.changeStationSettings = function changeStationSettings(toChange, options) {
	options = UIAUtilities.defaults(options, {
		nameChange:         null,
		playOrder:          null,
		groupByPodcast:     null,
		episodesToInclude:  null,
		mediaType:          null,
		unplayedOnly:       null,
		includeAll:         null,
		podcastsToSelect:   null,
		podcastsToDeselect: null,
		deselectAll:        false,
		needToNav:          true,
	});
	UIALogger.logMessage("FUNCTION: changeStationSettings()");
	this.launch();
	var station;
	if (options.episodesToInclude === 'All') {
		options.episodesToInclude = 'All Episodes';
	}

	if (options.deselectAll &&
		(options.includeAll === true ||
		options.podcastsToSelect !== null ||
		options.podcastsToDeselect !== null)) {
		throw new UIAError('Include all cannot be true while deselectAll is true or either podcastsToSelect or' +
			' podcastsToDeselect have values');
	}

	for (var i = 0; i < toChange.length; i++) {
		station = toChange[i];

		if (options.needToNav) {
			this.assertExists(station, 'Station not found');
			this.tap(station);
			this.tap('Settings');
		}

		if (options.nameChange !== null) {
			UIALogger.logMessage('Attempting to change podcast name');

			this.tap('Clear text');
			this.typeString(options.nameChange[i]);
			this.typeString('\n');

			this.waitUntilAbsent(UIAQuery.keyboard());

			// Verify name was changed
			UIAUtilities.assert(
				this.valueOf(UIAQuery.textFields().atIndex(1)) === options.nameChange[i],
				"Station's name was not changed"
			);

			UIALogger.logMessage('Name changed');
		}

		if (options.playOrder !== null) {
			UIALogger.logMessage('Attempting to change play order setting');

			this.tap(UIAQuery.staticTexts('Play'));

			// Replace standard quotes with unicode smart quotes
			options.playOrder = options.playOrder.replace('"', "\u201C", 1);
			options.playOrder = options.playOrder.replace('"', "\u201D");

			// Catches if passed in setting does not exist
			this.assertExists(options.playOrder, 'Could not find play order option. Pass in only 1 of the following' +
				' strings. "My Podcasts" Order, Newest to Oldest, Oldest to Newest, Manual');

			this.tap(options.playOrder);

			this.verifyStationSettings([station], {playOrder: options.playOrder, needToNavigate: false});

			this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			UIALogger.logMessage('Play order setting set');
		}

		if (options.groupByPodcast !== null) {
			UIALogger.logMessage('Attempting to set Group by Podcast setting');

			this.setControl(UIAQuery.switches('Group by Podcast'), options.groupByPodcast);

			this.verifyStationSettings([station], {groupByPodcast: options.groupByPodcast, needToNavigate: false});
			UIALogger.logMessage('Group by Podcast setting set');
		}

		if (options.episodesToInclude !== null) {
			UIALogger.logMessage('Attempting to set episodes to include setting');

			this.tap(UIAQuery.query("Episodes").rightmost());

			// Catches if passed in setting does not exist
			this.assertExists(options.episodesToInclude, 'Could not find episodes to include option. Pass in only 1' +
				' of the following strings. Most Recent Episode, Most Recent 2 Episodes, Most Recent 5 Episodes,' +
				' Most Recent 10 Episodes, All Episodes');

			// Sets and verifies
			this.tap(options.episodesToInclude);
			this.verifyStationSettings([station], {
				episodesToInclude: options.episodesToInclude,
				needToNavigate: false
			});

			this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			UIALogger.logMessage('Episode to Include setting set');
		}

		if (options.mediaType !== null) {
			UIALogger.logMessage('Attempting to set Media Type setting');

			this.tap('Media Type');

			// Catches if passed in setting does not exist
			this.assertExists(options.mediaType, 'Could not find Media Type option. Pass in only 1 of the following' +
				' strings. All, Audio, Video');

			// Sets and verifies setting
			this.tap(options.mediaType);
			this.verifyStationSettings([station], {mediaType: options.mediaType, needToNavigate: false});

			this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
			UIALogger.logMessage('Media type setting set');
		}

		if (options.unplayedOnly !== null) {
			UIALogger.logMessage('Attempting to set unplayed only setting');

			// Sets and verifies setting
			this.setControl(UIAQuery.switches('Unplayed Only'), options.unplayedOnly);
			this.verifyStationSettings([station], {unplayedOnly: options.unplayedOnly, needToNavigate: false});
			UIALogger.logMessage('Unplayed Only setting set');
		}

		if (options.deselectAll ||
			options.includeAll !== null ||
			options.podcastsToSelect !== null ||
			options.podcastsToDeselect !== null) {

			this.tap(UIAQuery.contains('Choose Podcasts'));

			var podcast;

			// Turns off Include All Podcasts if on
			if (options.includeAll !== true) {
				this.setControl(UIAQuery.switches(), false);
			}

			var listedPodcasts = UIAQuery.tableCells().isSelected();
			var totalListed = this.count(listedPodcasts);
			UIALogger.logMessage(totalListed);
			var allSelected = [];
			var podcastSelected = null;

			if (options.deselectAll) {
				UIALogger.logMessage('Attempting to deselect all podcasts');

				// Handles iPad having an extra selected item on screen
				var index = iPad ? 1 : 0;

				for (var j = index; j < totalListed; j++) {
					allSelected.push(this.inspectElementKey(listedPodcasts.atIndex(j), 'name'));
				}

				for (var k = 0; k < allSelected.length; k++) {
					this.tapIfExists(UIAQuery.tableCells(allSelected[k]).rightmost());
				}

				this.verifyStationSettings([station], {allDeselected: true, needToNavigate: false});
				UIALogger.logMessage('All podcasts deselected');
			}

			if (options.includeAll !== null) {
				UIALogger.logMessage('Attempting to set Include all Podcasts switch');

				this.setControl(UIAQuery.switches(), options.includeAll);

				this.verifyStationSettings([station], {includeAll: options.includeAll, needToNavigate: false});
				UIALogger.logMessage('Include All setting set');
			}

			if (options.podcastsToSelect !== null) {
				UIALogger.logMessage('Attempting to select podcasts to include');

				for (var l = 0; l < options.podcastsToSelect.length; l++) {

					podcast = options.podcastsToSelect[l];

					// Asserts that the podcast is actually available to be selected
					this.assertExists(podcast, '%0 is not listed'.format(podcast));

					podcastSelected = this.exists(listedPodcasts.andThen(
						UIAQuery.tableCells().contains(podcast).rightmost()));
					if (!podcastSelected) {
						this.tap(UIAQuery.tableCells().contains(podcast).rightmost());
					}
				}
				this.verifyStationSettings([station],
					{selectedPodcasts: options.podcastsToSelect, needToNavigate: false});
				UIALogger.logMessage('Podcasts selected successfully');

				UIALogger.logMessage('Podcasts successfully selected');
			}


			if (options.podcastsToDeselect !== null) {
				UIALogger.logMessage('Attempting to deselect podcasts in station');

				for (var m = 0; m < options.podcastsToDeselect.length; m++) {
					podcast = options.podcastsToDeselect[m];

					// Asserts that a podcast actually exists
					this.assertExists(podcast, '%0 is not listed'.format(podcast));

					podcastSelected = this.exists(listedPodcasts.andThen(UIAQuery.tableCells(podcast).rightmost()));
					if (podcastSelected) {
						this.tap(UIAQuery.tableCells().contains(podcast).rightmost());
					}
				}
				this.verifyStationSettings([station],
					{deselectedPodcasts: options.podcastsToDeselect, needToNavigate: false});
				UIALogger.logMessage('Podcasts successfully deselected');
			}

			this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR);
		}

		if (options.needToNav) {
			this.tap('back-nav-button');
			this.tap('Done');
		}
	}

	UIALogger.logMessage('Station settings changed');
};


/**
 * Create a station. Note that default behavior is to include no podcasts so either includeAll must be true or some
 * 		podcasts have to be passed in
 *
 *
 * Expected Starting state: Any.
 * @param {string} stationName - null => cancel out; otherwise, pass in a name of your choice
 * @param {object} options - Option dictionary
 * @param {boolean} [options.useDefaultSettings=true] - False to change the settings
 * @param {string} [options.playOrder='"My Podcasts" Order'] - Playback order. Can be the default, Newest to Oldest,
 * 		Oldest to Newest or Manual
 * @param {string} [options.nameChange=null] - Name to change during creation process
 * @param {boolean} [options.groupByPodcast=null] - True to group station by podcast
 * @param {string} [options.episodesToInclude=null] - Episodes to be included. Can be, Most Recent
 * 		Episode, Most Recent 2 Episodes, Most Recent 3 Episodes, Most Recent 5 Episodes, Most Recent 10 Episodes,
 * 		All Episodes
 * @param {string} [options.mediaType=null] - Type of media to include. Can be All, Audio or Video
 * @param {boolean} [options.unplayedOnly=null] - Unplayed only setting, false turns it off
 * @param {boolean} [options.includeAll=null] - If all podcasts should be included in the station
 * @param {array} [options.podcastsToUse] - Array of podcasts to include in the station
 */
podcasts.createStation = function createStation(stationName, options) {
	UIALogger.logMessage("FUNCTION: createStation()");
	options = UIAUtilities.defaults(options, {
		useDefaultSettings:	true,
        playOrder:			null,
        nameChange: 		null,
        groupByPodcast:		null,
        episodesToInclude:	null,
        mediaType:			null,
        unplayedOnly:		null,
        includeAll:			null,
        podcastsToUse:  	[],
		needToNav:          false,
    });
    //noinspection JSUnusedLocalSymbols

    // Do not fail on undefined station name - use below

	this.logStartingOptions(options, 'stationName = %0'.format(stationName));

	// Nav to my podcasts if needed
	if (options.needToNav) {
		this.getToTab(TABS.LIBRARY);
		this.tap('Shows');
	}
	//this.getToTopLevelCurrentTab();

	podcasts.tap(UIAQuery.Podcasts.EDIT_NAVBAR);
	target.delay(1);
	// BUG:  UIA alert handlers are getting triggered too late
	// So we have to handle these in-line
	// If no station name is passed in, cancel out of alert
	if (typeof stationName === 'undefined' ) {
		// Tap Add Station, allow the default alert handler to cancel alert
		UIALogger.logMessage('Station name undefined, tapping on Add');
		this.handlingAlertsInline(UIAQuery.alerts("New Station"), function() {
			UIALogger.logMessage("******HERE IN ALERT HANDLER!!!!!!!!!!!!!!!!!!!!!");
			this.tap("New Station");
			UIALogger.logMessage("Waiting for alert...");
			this.waitUntilPresent(UIAQuery.alerts("New Station"), 7);
			if (this.exists(UIAQuery.buttons('Cancel'))) {
				UIALogger.logMessage('Tapping Cancel in Alert...');
				this.tap(UIAQuery.buttons('Cancel'));
			} else {
				UIALogger.logMessage('Typing return character...');
				this.typeString('\n');
			}
		});
		// Verify we're out of the alert
		if (this.currentUIState() === UIStateDescription.Podcasts.LIBRARY) {
			UIALogger.logMessage('• PASS:  verified alert is gone.');
		} else {
			throw new UIAError('••• FAIL: alert should be gone, but My Podcasts was not detected.');
		}
		this.tap('Done');
		return;
	}
	// If arrived here, Create a Station
	UIALogger.logMessage('Tapping Add with in-line Alert Handler...');
	this.handlingAlertsInline(UIAQuery.alerts("New Station"), function() {
		UIALogger.logMessage("******HERE IN ALERT HANDLER!!!!!!!!!!!!!!!!!!!!!");
		this.tap("New Station");
		UIALogger.logMessage("Waiting for alert...");
		this.waitUntilPresent(UIAQuery.alerts("New Station"), 7);
		if (this.exists(UIAQuery.textFields())) {
			this.enterText(UIAQuery.textFields(), stationName);
			this.tap("Save");
			//this.typeString('\n');
		}
	});
	// Set All Podcasts or select individual podcasts if needed
	this.tap(UIAQuery.contains("Choose Podcasts"));
	this.waitForAnimations();
	if (options.includeAll) {
		this.setControl(UIAQuery.switches().rightmost(), true);
	} else {
		for (var i = 0; i < options.podcastsToUse.length; i++) {
			this.tap(UIAQuery.tableCells().contains(options.podcastsToUse[i]).rightmost());
		}
	}
	// Tap back
	UIALogger.logMessage("Tapping out of Choose Podcasts, to Station Settings...");
	this.tap(UIAQuery.Podcasts.STATION_SETINGS_NAVBAR); // button is not called 'Back'
	// Set the rest of the settings...
	if (!options.useDefaultSettings) {
		this.changeStationSettings([stationName], options);
	}
	// Tap back to Station details view
	if (iPad) {
		this.tap('back-nav-button');
	} else {
		this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons(stationName)));
		podcasts.tap('Library');
	}
	// still in Edit mode so...
	this.tap('Done');

	// VERIFY Station Name exists
	//padOffset = (iPad) ? 1 : 0;  //if iPad, use second nav bar
	var foundStationName = false;
	if (iPad) {
		if (this.nameOf(UIAQuery.VISIBLE_NAVBARS.atIndex(1)) === stationName) {
			foundStationName = true;
		}
	} else {
		if (this.exists(UIAQuery.query(stationName))) {
			foundStationName = true;
		}
	}
	if (foundStationName) {
		UIALogger.logMessage('• PASS:  station %0 verified in Nav Bar'.format(stationName));
	} else {
		throw new UIAError('••• FAIL: station %0 was not created'.format(stationName));
	}
};


/**
 * Deletes a specific group of podcasts from the Shows menu. Optionally deletes all. Allows user to select to delete the
 * podcast by swiping or using the edit function
 *
 * Updated for Tigris
 *
 * Expected starting state: Any, unless needToNav is false in which case, My Podcasts
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.deleteAll - If true, all items removed from My Podcasts
 * @param {string[]} options.toDelete - Array containing podcasts and stations to delete from My Podcasts
 * @param {bool} [options.needToNav=true] - If true, will navigate to My Podcasts
 *
 * @throws if deleting fails
 * @returns none
 */
podcasts.deleteFromMyPodcasts = function deleteFromMyPodcasts(options) {
	options = UIAUtilities.defaults(options, {
		deleteAll: false,
		toDelete:  [],
		needToNav : true
	});

	UIALogger.logMessage('FUNCTION: deleteFromMyPodcasts');
	this.logStartingOptions(options);
	this.launch();

	if (options.needToNav) {
		this.getToTab(TABS.LIBRARY);
		this.tap(UIAQuery.Podcasts.SHOWS_CELL);
	}

	//Overwrite options.toDelete to be all items in My Podcasts if options.deleteAll is true.
	if (options.deleteAll) {
		options.toDelete = this.generateShowsList({needToNav:false});
	}

	if (options.toDelete[0] === 'Empty') {
		UIALogger.logMessage('My Podcasts is empty');
		return;
	}

	//Wait for edit button to be enabled indicating editing can take place
	if (!this.waitUntilPresent(UIAQuery.buttons('Edit').leftmost().isEnabled(), 10)) {
		throw new UIAError ('Edit button in navbar did not become active after 10 seconds');
	}


	this.tap(UIAQuery.buttons('Edit').rightmost());

	for (var i = 0; i < options.toDelete.length; i++) {
		this.assertExists(
			UIAQuery.staticTexts(options.toDelete[i]).siblings().andThen(UIAQuery.Podcasts.DELETE_BUTTON_IN_SHOWS),
			'No delete button exists. May not be in edit mode'
		);

		this.tap(UIAQuery.staticTexts(options.toDelete[i]).siblings().andThen(UIAQuery.Podcasts.DELETE_BUTTON_IN_SHOWS));
	}

    this.tap(UIAQuery.Podcasts.DONE_BUTTON);

	// Verifies all items that should have been deleted were deleted.
	if (options.deleteAll) {
		UIAUtilities.assert(
			this.count(UIAQuery.query('Artwork').below(UIAQuery.navigationBars('Shows'))) === 0,
			'Some podcasts remain after deletion'
		);
	} else {
		for (var x = 0; x < options.toDelete.length; x++) {
			this.assertNotExists(
				UIAQuery.staticTexts(options.toDelete[x])
			);
		}
	}

	UIALogger.logMessage('All items deleted correctly from My Podcasts');
};

/**
 * Removes Podcasts and restores it. Verifies nothing is left in My Podcasts
 *
 * @throws if there are Podcasts in My Podcasts
 */
podcasts.deleteDatabaseWithAppRemoval = function deleteDatabaseWithAppRemoval() {
	UIALogger.logMessage('FUNCTION: deleteDatabaseWithAppRemoval');
	UIALogger.logWarning("WARNING: THIS TEST IS BYPASSED, SINCE LSAW CAN NO LONGER BE USED TO RESTORE.  SHOWS WERE NOT DELETED.");

	/*
	target.performTask('/usr/local/bin/lsaw', ['uninstall', 'com.apple.podcasts'], 30);
	springboard.delay(3);
	var mediaDirectory = '/var/mobile/Media/Podcasts';
	UIAFileManagement.removeDirectory(mediaDirectory);
	UIAFileManagement.makeDirectory(mediaDirectory);
	target.performTask('/usr/sbin/chown', ['mobile:mobile', mediaDirectory]);
	target.performTask('/bin/cp', ['-R', '/Library/ApplicationBackups/Podcasts.app', '/tmp/Podcasts.app'], 10);
	target.performTask('/usr/local/bin/mobile_install', ['installType', 'System', '/tmp/Podcasts.app'], 10);
	springboard.delay(5);
	this.launch();
	this.getToTab(TABS.LIBRARY, {noPodcasts:true});
	*/
};

/**
 * Deletes one or all stations from Library. Optionally deletes all. Allows user to select to delete the
 * podcast by swiping or using the edit function
 *
 * Expected starting state: Any, unless needToNav is false in which case, Library
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.deleteAll - If true, all items removed from My Podcasts
 * @param {string[]} options.toDelete - Array containing podcasts and stations to delete from My Podcasts
 * @param {bool} [options.needToNav=true] - If true, will navigate to My Podcasts
 *
 * @throws if deleting fails
 * @returns none
 */
podcasts.deleteStations = function deleteStations(options) {
	options = UIAUtilities.defaults(options, {
		deleteAll: false,
		toDelete:  [],
		needToNav : true
	});

	var theQ = "Delete ";  // Delete button for station
	UIALogger.logMessage('FUNCTION: deleteStations\n');
	this.logStartingOptions(options);
	this.launch();

	if (options.needToNav) {
		this.getToTab(TABS.LIBRARY);
	}

	//Overwrite options.toDelete to be all items in My Podcasts if options.deleteAll is true.
	if (options.deleteAll) {
		throw new UIAError ('Delete all stations not implemented yet');
		//options.toDelete = this.generateShowsList({needToNav:false});
	}

	if (options.toDelete[0] === 'Empty') {
		UIALogger.logMessage('Station list is empty');
		return;
	}

	//Wait for Library edit button to be enabled indicating editing can take place
	if (!this.waitUntilPresent(UIAQuery.buttons('Edit').leftmost().isEnabled(), 10)) {
		throw new UIAError ('Edit button in navbar did not become active after 10 seconds');
	}

	this.tap(UIAQuery.buttons('Edit').leftmost());
	// DELETE
	for (var i = 0; i < options.toDelete.length; i++) {
		// build query - the station name with Delete at the beginning
		this.tap(UIAQuery.query(theQ + options.toDelete[i]));
		this.tap(UIAQuery.buttons("Delete"));
	}

    this.tap(UIAQuery.Podcasts.DONE_BUTTON);

	// Verifies all items that should have been deleted were deleted.
	if (options.deleteAll) {
		throw new UIAError ('Verification for Delete All Stations is not yet implemented.');
		// verify that no stations exist between Downloaded Episodes and New Station
		
	} else {
		for (var x = 0; x < options.toDelete.length; x++) {
			this.assertNotExists(
				UIAQuery.staticTexts(options.toDelete[x])
			);
		}
	}

	UIALogger.logMessage('All items deleted correctly from Library tab.');
};


/**
 * Gets the settings for a podcast and returns a dictionary compatible with verifyPodcastSettings
 *
 * @param {string} podcast - Title of podcast to get the settings of
 * @returns {{playOldestFirst: bool,
 * 			  sortOldestFirst: bool,
 * 			  subscribed: bool,
 * 			  notifications: bool,
 * 			  refresh: string,
 * 			  limit: string,
 * 			  download: string,
 * 			  deleteSetting: string}}
 */
podcasts.getPodcastSettings = function getPodcastSettings (podcast) {
	UIALogger.logMessage('FUNCTION: getPodcastSettings with podcast = %0'.format(podcast));

	// Create the array to return and set a value for all items. This way, if a value is not assigned it will still
	// fail the verification step. Prevents silent failures.
	var toReturn = {
		playOldestFirst: 'FAIL',
		sortOldestFirst: 'FAIL',
		subscribed:      'FAIL',
		notifications:   'FAIL',
		refresh:         'FAIL',
		limit:           'FAIL',
		download:        'FAIL',
		deleteSetting:   'FAIL'
	};

	this.tap(podcast);
	this.waitForAnimations();
	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS);
	// Try to open settings twice
	if (!this.waitUntilPresent(UIAQuery.navigationBars('Settings'))) {
		this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS);
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.SETINGS_NAVBAR),
			'Settings pane for podcast never opened'
		);
	} else {
		UIALogger.logMessage('Settings pane opened on first attempt');
	}

	// Get Play Order setting
	var playOrderSetting = this.inspectElementKey(UIAQuery.Podcasts.PODCAST_SETTINGS_PLAY.siblings(), 'label');
	if (playOrderSetting === 'Newest to Oldest') {
		toReturn.playOldestFirst = false;
	} else if (playOrderSetting === 'Oldest to Newest') {
		toReturn.playOldestFirst = true;
	}

	// Get Sort Order setting
	var sortOrderSetting = this.inspectElementKey(UIAQuery.Podcasts.PODCAST_SETTINGS_SORT.siblings(), 'label');
	if (sortOrderSetting === 'Newest on Top') {
		toReturn.sortOldestFirst = false;
	} else if (sortOrderSetting === 'Oldest on Top') {
		toReturn.sortOldestFirst = true;
	}

	// Get Subscribed setting
	toReturn.subscribed = this.valueOf(UIAQuery.Podcasts.PODCAST_SETTINGS_SUBSCRIBED);

	// Get Notifications setting
	toReturn.notifications = this.valueOf(UIAQuery.Podcasts.PODCAST_SETTINGS_NOTIFICATIONS);

	// Get Refresh Every setting
	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH);
	this.waitUntilReady();
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_REFRESH_NAVBAR),
		'Refresh settings did not open after 5 seconds'
	);
	var refreshEverySetting = this.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost().children(), 'label');
	UIAUtilities.assert(
		VALID_REFRESH_SETTINGS.contains(refreshEverySetting),
		'Refresh Every setting "%0" invalid'.format(refreshEverySetting)
	);
	toReturn.refresh = refreshEverySetting;
	// Get back to previous page
	this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());

	// Get Limit Episodes setting
	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT);
	this.waitUntilReady();
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_LIMIT_NAVBAR),
		'Limit settings did not open after 5 seconds'
	);
	var limitEpisodesSetting = this.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost().children(), 'label');
	UIAUtilities.assert(
		VALID_LIMIT_SETTINGS.contains(limitEpisodesSetting),
		'Limit Episodes setting "%0" invalid'.format(limitEpisodesSetting)
	);
	toReturn.limit = limitEpisodesSetting;
	// Get back to previous page
	this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());

	// Get Download Episodes setting
	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD);
	this.waitUntilReady();
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DOWNLOAD_NAVBAR),
		'Download settings did not open after 5 seconds'
	);
	var downloadEpisodesSetting = this.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost().children(), 'label');
	UIAUtilities.assert(
		VALID_DOWNLOAD_SETTINGS.contains(downloadEpisodesSetting),
		'Download Episodes setting "%0" invalid'.format(downloadEpisodesSetting)
	);
	toReturn.download = downloadEpisodesSetting;
	// Get back to previous page
	this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());

	// Get Delete Played Episodes setting
	this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE);
	this.waitUntilReady();
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_DELETE_NAVBAR),
		'Delete settings did not open after 5 seconds'
	);
	var deletePlayedSetting = this.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost().children(), 'label');
	UIAUtilities.assert(
		VALID_DELETE_PLAYED_SETTINGS.contains(deletePlayedSetting),
		'Download Episodes setting "%0" invalid'.format(deletePlayedSetting)
	);
	toReturn.deleteSetting = deletePlayedSetting;
	// Get back to previous page
	this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON.isVisible());

	if(iPad) {
		this.dismissPopover();
	} else {
		this.tap(UIAQuery.Podcasts.DONE_NAVBAR);
		this.tap(UIAQuery.Podcasts.PODCAST_DETAILS);
	}

	UIALogger.logMessage('getPodcastSettings complete for %0'.format(podcast));
	return toReturn;
};


/**
 * Issues a voice command to Siri by using setVoiceRecognitionStrings and holding the menu button
 *
 * Expected starting state - Any
 *
 * @param {string} command - Command to be issued to Siri
 */
podcasts.issueSiriCommand = function issueSiriCommand(command) {
	UIALogger.logMessage('SIRI: issueSiriCommand');
	UIALogger.logMessage('Command was %0'.format(command));

	target.setVoiceRecognitionStrings([command]);
	target.holdMenu(1.5);
};


/**
 * All quicklook tests for playback controls on the lock screen and in control center that are the same between the
 * 2 for the purposes of the quicklook
 *
 * Updated for Tigris
 *
 * Expected state: Already on the screen to be tested. Either on lock screen or with control center up
 * @param {string} episode - Title of episode that was played
 * @param {bool} lockScreen - If true, runs lock screen tests, if false, runs control center tests
 *
 * @throws if a playback test fails
 * @returns none
 */
podcasts.lockScreenAndControlCenterSharedTests = function lockScreenAndControlCenterSharedTests(episode, lockScreen) {
	UIALogger.logMessage('FUNCTION: lockScreenAndControlCenterSharedTests with episode = "%0" and lockScreen = "%1"'.format(episode, lockScreen));

	// Assert the episode played is playing
  if (springboard.exists(UIAQuery.contains(episode)) || springboard.exists(UIAQuery.contains(episode.toLowerCase()))){
    UIALogger.logMessage('Correct episode is playing');
  }else{
    throw new UIAError ('Episode that should be playing is not');
  }
	// springboard.assertExists(UIAQuery.contains(episode), 'Episode that should be playing is not');
	springboard.waitUntilReady();

	// Pause playback
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_PAUSE_BUTTON);
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PAUSE);
	}
	this.verifyNotPlaying({errorMessage : 'Playback did not pause after tapping pause button'});

	// Resume playing
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_PLAY_BUTTON);
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PLAY);
	}
	this.waitForPlayback(2, {errorMessage:'Playback failed after tapping play button'});
	target.delay(2);  // let it play for 2 secs
	// Pause playback again
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_PAUSE_BUTTON);
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PAUSE);
	}
	this.verifyNotPlaying({errorMessage:'Playback did not pause after tapping pause button 2nd time'});
	target.delay(2);  // let it pause for 2 secs
	// Resume playback again
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_PLAY_BUTTON);
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PLAY);
	}
	this.waitForPlayback(2, {errorMessage:'Playback failed after tapping play button after pausing'});
	target.delay(2);  // let it play for 2 secs
	// Commented out to work around <rdar://problem/26245632> Automation: Volume Slider Missing Label in Control Center
	// Adjust volume
	//springboard.setControl(UIAQuery.Podcasts.CONTROL_CENTER_VOLUME, 0);
	//springboard.delay(1);
	//springboard.setControl(UIAQuery.Podcasts.CONTROL_CENTER_VOLUME, 1);
	//springboard.delay(1);
	//springboard.setControl(UIAQuery.Podcasts.CONTROL_CENTER_VOLUME, .25);
	//springboard.delay(1);

	// Pause playback
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_PAUSE_BUTTON);
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_PAUSE);
	}
	this.verifyNotPlaying({errorMessage:'Playback not paused before skip tests'});
	
	// Added delay to troubleshoot <rdar://problem/24914839> Automation: Sometimes App Does Not Skip Ahead Correctly
	// When 15 Second Skip Pressed on Lock Screen
	springboard.delay(3);
	// Test 15 second skip buttons
	var playbackValue = Math.round(CAMMediaRemote.getNowPlayingElapsedTime());
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_FFBUTTON, {tapCount: 3});
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_15FF, {tapCount: 3});
	}
	UIALogger.logMessage('playbackValue was %0, current elapsed time was %1'.format(playbackValue,
			Math.round(CAMMediaRemote.getNowPlayingElapsedTime())));
			
	UIALogger.logWarning("WARN : SKIPPING TEST for time measurement.");
	/*
	if((playbackValue + 45) == Math.round(CAMMediaRemote.getNowPlayingElapsedTime())) {
		UIALogger.logMessage('This is TRUE. Assert should pass');
	}
	UIAUtilities.assertEqual((playbackValue + 45), Math.round(CAMMediaRemote.getNowPlayingElapsedTime()),
			'Playback did not skip ahead 45 seconds when 15 second skip forward button tapped 3 times. Skipped' +
			' ahead %0 seconds'.format(Math.round(CAMMediaRemote.getNowPlayingElapsedTime()) - playbackValue));
	if (lockScreen) {
		springboard.tap(UIAQuery.Podcasts.LS_REWINDBUTTON, {tapCount: 3});
	} else {
		springboard.tap(UIAQuery.Podcasts.CONTROL_CENTER_15RW, {tapCount: 3});
	}
	UIALogger.logMessage('playbackValue was %0, current elapsed time was %1'.format(playbackValue,
			Math.round(CAMMediaRemote.getNowPlayingElapsedTime())));
	if (playbackValue == CAMMediaRemote.getNowPlayingElapsedTime()) {
		UIALogger.logMessage('This is TRUE, Assert after this should pass');
	}
	UIAUtilities.assertEqual(playbackValue, Math.round(CAMMediaRemote.getNowPlayingElapsedTime()),
			'Playback did not skip back 45 seconds when 15 second skip back button tapped 3 times. Skipped back' +
			' %0 seconds'.format(playbackValue + 45 - Math.round(CAMMediaRemote.getNowPlayingElapsedTime())));
			
	*/
};


/**
 * Simply tap the Play button and verify.
 *	Works for both audio and video, mini-player or full-screen
 *
 * Expected starting state:  mini-player or Now Playing must be visible
 *
 * @returns None
 */
podcasts.play = function play() {
	UIALogger.logMessage("PLAY");
	this.tap(UIAQuery.Podcasts.PLAY_BUTTON);

	// VERIFY
	// If no Pause button, wait, in case we're buffering a stream
	if (!podcasts.exists(UIAQuery.Podcasts.PAUSE_BUTTON)) {
		if(!podcasts.waitUntilPresent(UIAQuery.Podcasts.PAUSE_BUTTON, 10)) {
		throw new Error("'PLAY' did not begin (Pause button was not found) after 10 seconds.");
		}
	} else {
		UIALogger.logMessage("Podcasts is Playing...");
	}
};


/**
 * Tap the Pause button and verify.
 *	Works for both audio and video, mini-player or full-screen
 *
 * Expected starting state:  mini-player or Now Playing must be visible
 *
 * @returns None
 */
podcasts.pause = function pause() {
	// Do not verify first - tap will fail anyway if Pause button is not present
	// PAUSE
	this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
	// Log after tap to give time for UI to catch up
	UIALogger.logMessage("PAUSE");

	// VERIFY
	this.verifyNotPlaying();
};


/**
 * Changes the play state of an array of episodes using edit, track actions or swiping. Swiping only works in the
 * feed tab of a podcast. Track action changes are not supported on the Unplayed tab because the buttons there are
 * not visible to automation currently
 *
 * Expected starting state - On the tab with the episodes to be changed
 *
 * @param {string} playState - Unplayed or Played to indicate play state to be set
 * @param {string[]} episodeTitles - Array string containing all the episode titles to change to the new state
 * @param {object} options - options dictionary
 * @param {string} [options.method='edit'] - String of value edit, swipe or track actions to indicate method to use to
 * 		change play state.
 * @param {string} [options.appTab='My Podcasts'] - String indicating Unplayed or My Podcasts. Default is My Podcasts
 * @param {bool} [options.isStation=false] - False by default, true indicates episodes are part of a station
 * @param {bool} [options.isInFeed=false] - False by default, true indicates episodes are in a podcast feed tab
 * @param {bool} [options.stationUnplayedOnly=false] - False by default, placeholder for future when that setting
 * 		actually does something
 *
 * @throws if episode play state cannot be set
 * @returns none
 */
podcasts.setEpisodePlayState = function setEpisodePlayState(playState, episodeTitles, options) {
	options = UIAUtilities.defaults(options, {
		method              : 'edit',
		appTab              : 'My Podcasts',
		isStation			: false,
		isInFeed			: false,
		stationUnplayedOnly : false,
	});

	UIALogger.logMessage('FUNCTION setEpisodePlayState');
	var buttonToTap;

	options.method = options.method.toLowerCase();

	// Deals with extra space in the buttons when swiping
	if (options.method === 'swipe') {
		buttonToTap = 'Mark as  ' + playState;
	} else {
		buttonToTap = 'Mark as ' + playState;
	}

	if (options.method !== 'edit' && options.method !== 'track actions' && options.method !== 'swipe') {
		throw new UIAError ('Must enter edit, track actions or swipe as a method to mark episodes');
	}

	switch (options.method) {
		case 'edit':
			this.tap(UIAQuery.Podcasts.EDIT_NAVBAR.rightmost());

			for (var i = 0; i < episodeTitles.length; i++) {
				this.scrollEpisodeCellToVisible(episodeTitles[i]);

				this.tap(UIAQuery.contains(episodeTitles[i]));
				// Verify episode is selected, currently does not work on Unplayed tab rdar://problem/23524032
				if (options.appTab !== 'Unplayed') {
					this.assertExists(
							UIAQuery.tableCells().contains(episodeTitles[i]).isSelected(),
							'Episode %0 was not selected and highlighted'.format(episodeTitles[i]));
				}
			}

			this.tap('Mark');
			this.waitUntilPresent('Mark as Played');
			this.tap(UIAQuery.buttons(buttonToTap));
			this.tapIfExists(UIAQuery.Podcasts.DONE_NAVBAR);
			// Delay added to work around <rdar://problem/27004180> Podcasts: Item That Existed Was Thought to Not Exist
			this.delay(2);


			if ((options.appTab === 'Unplayed' || options.stationUnplayedOnly || options.isStation) && playState === 'Played') {
				for (var j = 0; j < episodeTitles.length; j++) {
					this.assertNotExists(
							UIAQuery.tableCells().contains(episodeTitles[j]),
							'Episode %0 still found on Unplayed tab after marking as played'.format(episodeTitles[j]));
				}
				UIALogger.logMessage('Verified episodes marked as played no longer present');
			} else {
				this.verifyEpisodePlayState(playState, episodeTitles);
			}
			break;
		case 'swipe':
			if (options.isInFeed) {
				for(var k = 0; k < episodeTitles.length; k++) {
					this.scrollEpisodeCellToVisible(episodeTitles[k]);

					this.swipeLeftOnTableCell(episodeTitles[k], buttonToTap);
					this.tap(buttonToTap);
				}
			} else {
				// Throw error if options passed in aren't possible
				throw new UIAError ('Swiping to change play state only possible from within My Podcasts feed tab');
			}
			// Delay added to work around <rdar://problem/27004180> Podcasts: Item That Existed Was Thought to Not Exist
			this.delay(2);
			this.verifyEpisodePlayState(playState, episodeTitles);
			break;
		case 'track actions':
			UIAUtilities.assertNotEqual(
					options.appTab,
					'Unplayed',
					'Track action buttons on the Unplayed tab are currently not accessible by automation'
			);

			for (var m = 0; m < episodeTitles.length; m++) {
				this.scrollEpisodeCellToVisible(episodeTitles[m]);
				this.tapTrackActions(episodeTitles[m]);
				this.waitUntilPresent('Play Next');
				this.tap(buttonToTap);
			}
			// Delay added to work around <rdar://problem/27004180> Podcasts: Item That Existed Was Thought to Not Exist
			this.delay(2);
			this.verifyEpisodePlayState(playState, episodeTitles);
			break;
	}

	UIALogger.logMessage('PASS* setEpisodePlayState completed');
};

/**
 * Function to scroll to a podcast cell that tries to work around <rdar://problem/23882904> [Eagle] 13182 -
 * 		Elements Beneath Mini-Player Reporting isVisible to AX When Visibility is Obscured to User
 *
 * @param episodeTitle - Title of episode to scroll to
 */
podcasts.scrollEpisodeCellToVisible = function scrollEpisodeCellToVisible(episodeTitle) {
	UIALogger.logMessage('FUNCTION: scrollEpisodeCellToVisible');
	UIALogger.logMessage('episodeTitle was %0'.format(episodeTitle));

	// Get currentUIState
	var state = this.currentUIState();
	var upperBoundElement = null;

	// Set upper bound based off of segmented control. If not in Podcast Details assume it is either Unplayed or
	// station and set upper bound based on navBar
	if (state === 'Podcast Details' || this.exists(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED.isVisible())) {
		upperBoundElement = this.inspect(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
	} else {
		upperBoundElement = this.inspect(UIAQuery.navigationBars());
	}

	// Set the upperBound
	var upperBound = upperBoundElement.hitpoint.y;
	var lowerBound = null;
	// Catch if mini player is present and get UI location information for mini player or tab bar as needed
	if (this.exists(UIAQuery.Podcasts.MINIPLAYER_MINI.isVisible())) {
		UIALogger.logMessage('Mini player found');
		var miniUI = this.inspect(UIAQuery.Podcasts.MINIPLAYER_MINI);
		lowerBound = miniUI.hitpoint.y;
	} else if (this.exists(UIAQuery.Podcasts.LIBRARY_TAB.isVisible())) {
		UIALogger.logMessage('Mini player not found. Found My Podcasts tab');
		var tabUI = this.inspect(UIAQuery.Podcasts.LIBRARY_TAB);
		lowerBound = tabUI.hitpoint.y;
	} else {
		UIALogger.logMessage('Mini player and tab bar not found');
		var markUI = this.inspect(UIAQuery.buttons('Mark'));
		lowerBound = markUI.hitpoint.y;
	}

	UIALogger.logMessage('lowerBound was %0 and upperBound was %1'.format(lowerBound, upperBound));

	var query = UIAQuery.tableCells().contains(episodeTitle);
	this.scrollToVisible(query);
	var cellUI = this.inspect(query);
	var cellCenter = cellUI.center.y;
	var count = 0;
	UIALogger.logMessage('cellCenter was %0 before entering loop'.format(cellCenter));

	// Change bounds depending on size of episode cell
	var cellHeight = cellUI.rect.height;
	var shifter = cellHeight/2;
	upperBound = upperBound + shifter;
	lowerBound = lowerBound - shifter;
	// Track previous values of cellCenter to exit loop if the value is not changing
	var oldCellCenter = cellCenter - 100;

	while ((cellCenter < upperBound || cellCenter > lowerBound) && count < 5 && cellCenter !== oldCellCenter) {
		if (cellCenter < upperBound) {
			this.drag(
				UIAQuery.tableCells().contains(episodeTitle).parent(),
				{fromOffset:{x:0, y:.5}, toOffset:{x:0,y:.7}});
		} else {
			this.drag(
				UIAQuery.tableCells().contains(episodeTitle).parent(),
				{fromOffset:{x:0, y:.5}, toOffset:{x:0,y:.3}});
		}

		oldCellCenter = cellCenter;
		cellUI = this.inspect(query);
		cellCenter = cellUI.center.y;

		count++;
		UIALogger.logMessage('cellCenter was %0 after %1 loops'.format(cellCenter, count));
	}

	if (count === 5) {
		UIALogger.logWarning('It took 5 attempts to scroll item to screen and may not have worked.');
	} else if (cellCenter === oldCellCenter) {
		UIALogger.logMessage('Broke loop because cellCenter did not change between loops');
	}
};

/**
 * Shares an episode to the specified service. Verifies user is taken to the correct UI when using the copy link
 * option. Not that this feature does not yet support shares from the store. At this time, Location sharing is
 * experimental and may not work. Currently does not support Notes.
 *
 * Expected state: Call when the share sheet is already open on the device
 *
 * @param {string} service - Service to be shared to
 * @param {bool} isEpisode - True if you are sharing just an episode, false if sharing a podcast
 * @param {string} podcastTitle - Title of the podcast being shared
 * @param {{}} options - Dict containing options
 * @param {string} options.receiver - Email address to send iMessages and Emails to
 * @param {string} options.episodeTitle - Title of the episode being shared, only require if sharing episode
 * @param {bool} options.inCollection - True if podcast has a container, false if not
 * @param {bool} options.location - If true, shares current location to Facebook and Twitter
 * @param {string} options.facebookAudience - Audience for sharing on Facebook
 * @param {bool} options.verifyiMessage - If true, assumes the sender is the same as the receiver and verifies a
 * 		message is received
 *
 * @throws If a message is incorrect, it cannot share or some UI elements are missing
 * @returns none
 */
podcasts.shareToService = function shareToService (service, isEpisode, podcastTitle, options) {
	options = UIAUtilities.defaults(options, {
		receiver:          'ottoiq@icloud.com',
		episodeTitle:      null,
		inCollection:      true,
		location:          false,
		facebookAudience:  'Only me',
		verifyiMessage : true,
	});

	if (service === 'Messages') {
		service = 'Message';
	} else if (service === 'iCloud') {
		service = 'Mail';
	}

	// Verifies the service in question is available to be shared to
	this.assertExists(service,
		'%0 not found. Be sure to pass in only 1 of the following strings. Mail, Notes, Twitter, Facebook, Copy Link or Message'.format(service));

	if (isEpisode && options.episodeTitle === null) {
		throw new UIAError ('Need episode title to verify episode. No episode title passed in.');
	}

	UIALogger.logMessage('Attempting to share via %0'.format(service));

	var verificationString = 'https://itunes.apple.com';
	var message;

	if (service === 'Mail') {
		verificationString = 'https://itunes.apple.com';
		var mailSheetWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "MFMailComposeViewController"'  // was MFMailComposeController
		);
		this.tap(service);
		UIAUtilities.assert(
			mailSheetWaiter.wait(30),
			'Mail sheet did not appear'
		);

		var subjectString = 'Listen to %0 in Podcasts'.format(podcastTitle);
		// need to wait for Ui to render and fields to populate.
		// subjectField can still fail even after image is drawn, so we'll assert 
		this.waitUntilPresent(UIAQuery.contains('Image-1.jpg'), 30);
		UIAUtilities.assert(this.waitUntilPresent(UIAQuery.query('subjectField').isVisible(), 30));
		// Verify correct text in various fields
		if (this.valueOf('subjectField') !== subjectString) {
			throw new UIAError ('Subject is incorrect');
		}

		if (!this.waitUntilPresent(UIAQuery.query('Message body'), 30)) {
			throw new UIAError ('Message body failed to appear within 30 seconds');
		}
		UIALogger.logMessage('Message body did appear');

		message = this.valueOf('Message body');
		UIAUtilities.assert(
			message.indexOf(verificationString) !== -1,
			'Message body "%0" does not contain expected string "%1"'.format(message, verificationString)
		);

		// Sends the message
		this.tap('toField');
		UIAUtilities.assert(
			this.waitForKeyboard(),
			'Keyboard never appeared'
		);
		// Delay to try to work around <rdar://problem/26420204> 14A267 - Automation: Keyboard Fails to Type 'o'
		this.delay(3);
		this.typeString(options.receiver);
		this.delay(1);
    	this.tapIfExists('dismiss popup'); // remove this one?
		this.dismissKeyboard();
		if (!podcasts.exists(UIAQuery.buttons("Send").isVisible())) {
			// popup with previous recipient 
			this.tapIfExists('dismiss popup');
		}
		this.tap('Send');

		UIAUtilities.assert(
			this.isActive(),
			'Podcasts no longer active after sharing with Mail'
		);
		UIALogger.logMessage('PASS* - Sharing with Mail complete**');
	}

	if (service === 'Message') {
		var messageSheetWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "CKModalTranscriptController"'
		);
		var receivedWaiter = null;

		this.tap(service);
		UIAUtilities.assert(
			messageSheetWaiter.wait(30),
			'Messages sheet did not appear'
		);

		this.typeString(options.receiver);
		this.typeString('\n');

		if (options.verifyiMessage) {
			// Add a unique number identifier to each message sent so multiple tests can be run at once and still pass
			var uniqueID = Math.floor((Math.random() * 100000000000000));
			this.typeString('\n');
			this.typeString(' ' + uniqueID);

			receivedWaiter = UIAWaiter.withPredicate(
				'Announcement',
				'announcement CONTAINS "%0" OR announcement CONTAINS "Message Failed to Send"'.format(uniqueID)
			);
		}

		// Send the message
		var sentWaiter = UIAWaiter.withPredicate(
			'ViewDidDisappear',
			'controllerClass = "MFMessageComposeViewController"'
		);

		this.tap('Send');

		UIAUtilities.assert(
			sentWaiter.wait(),
			'Message send sheet did not dismiss. Message likely did not send'
		);

		if (options.verifyiMessage) {
			UIALogger.logMessage('Waiting for message to be received');
			UIAUtilities.assert(
				receivedWaiter.wait(902, function (event) {
					if (event.announcement.contains('%0'.format(uniqueID))) {
						UIALogger.logPass('Message sent and notification received');
					} else if (event.announcement.contains('Message Failed to Send')) {
						throw new UIAError ('Message failed to send');
					} else {
						throw new UIAError('Alert appeared but contents were unknown');
					}
				}),
				'No Messages alert appeared'
			);
		}

		UIAUtilities.assert(
			this.isActive(),
			'Podcasts no longer active after sharing with messages'
		);
		UIALogger.logMessage('PASS* - Sharing to iMessage complete**');
	}

	if (service === 'Copy Link') {
		this.tap(service);
		this.waitUntilAbsent(UIAQuery.collectionViews());
		// Move user off of tab they are on so the sharing verification is valid
		if (iPad) {
			this.tapIfExists(podcastTitle);
		} else {
			this.tapIfExists(UIAQuery.Podcasts.LIBRARY_TAB);
		}
		this.tapIfExists(UIAQuery.Podcasts.LISTEN_NOW_TAB);

		var safari = target.appWithBundleID('com.apple.mobilesafari');

		UIALogger.logMessage('Attempting to launch Safari for Copy Link test');
		safari.launch();
		if (safari.waitUntilPresent('Show Bookmarks', 15)){
			UIALogger.logMessage('Safari Bookmarks button was found');
		} else {
			UIALogger.logWarning('Safari Bookmarks button did not appear after 15 seconds. Safari may not be running');
		}


		// Works around pop up being dismissed in Whitetail documented <rdar://problem/26245139> REG: Paste and Go
		// Option in Address Bar Dismissed After Bookmark Icons Finish Loading
		safari.delay(10);

		// Works around no label for address bar when not selected
		var loops = 0;
		while (!safari.exists('Paste and Go') && loops < 5) {
			safari.touchAndHold(UIAQuery.buttons('URL'), 2);
			loops++;
		}

		safari.handlingAlertsInline(UIAQuery.alerts().isVisible(), function () {
			// All below meant to work around strange issue with active apps. If it ain't broke, don't fix it
			var linkWaiter = UIAWaiter.withPredicate(
				'Alert',
				'title = "Open this page in \u201cPodcasts\u201d?"'
			);
			safari.tap('Paste and Go');

			if (!linkWaiter.wait(10)) {
				throw new UIAError('Alert to open in podcasts did not appear');
			}
			var safariWaiter = UIAWaiter.waiter('ApplicationStateChanged', {
				predicate: 'bundleID == "com.apple.mobilesafari" and state == "Background"'
			});

			var podcastsWaiter = UIAWaiter.waiter('ApplicationStateChanged', {
				predicate: 'bundleID == "com.apple.podcasts" and state == "Foreground"'
			});

			safari.tap('Open');
			if (!safariWaiter.wait(10)) {
				throw new UIAError ('Safari never closed');
			}

			if (!podcastsWaiter.wait(10)) {
				throw new UIAError ('Podcasts did not open');
			}
		});

		if (!this.waitUntilPresent(UIAQuery.Podcasts.LIBRARY_TAB.isSelected(), 15)) {
			throw new UIAError ('Podcast container never navigated to');
		}
		safari.deactivate();
		this.verifyCorrectItemWhenShared(
			isEpisode,
			podcastTitle,
			{episodeTitle:options.episodeTitle, inCollection:options.inCollection});

		UIALogger.logMessage('PASS* - Sharing via Copy Link complete**');
	}

	if (service === 'Facebook') {
		// Works around issue with message not having a value rdar://problem/24769396
		var facebookWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "SLSheetRootViewController" AND controllerTitle = "Facebook"'
		);

		this.tap(service);

		UIAUtilities.assert(
			facebookWaiter.wait(30),
			'Facebook share sheet did not appear'
		);

		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.FACEBOOK_BODY),
			'Body of Facebook message not found. Window may not be visible'
		);

		var facebookPost = this.inspect(UIAQuery.Podcasts.FACEBOOK_BODY).value;
		UIALogger.logMessage('Text in facebook post was ' + facebookPost);
		// Verify there is no message for Facebook sharing
		UIAUtilities.assertEqual(
			undefined,
			facebookPost,
			'Value of the Facebook post was not undefined. Should be empty but instead was ' + facebookPost
		);

		// Verify Location and Audience options are there
		this.assertExists('Location', 'No location option available');
		this.assertExists('Audience', 'No Audience option available');

		if (options.location) {
			var handler = function () {
				var app = target.activeApp();
				if (app.exists(UIAQuery.contains('access your location'))) {
					app.tap('Allow');
					return true;
				} else {
					return false;
				}
			};

			this.withAlertHandler(handler, function () {
				this.tap('Location');
			});
			this.tap('Facebook');
		}

		this.tap('Audience');
		// Verify option passed for audience exists
		if (this.waitUntilPresent(options.facebookAudience)) {
			this.tap(options.facebookAudience);
		} else {
			throw new UIAError ('No such audience option could be found');
		}
		this.waitForKeyboard();
		this.tap('Post');

		this.waitUntilAbsent(UIAQuery.keyboard());

		UIAUtilities.assert(
			this.isActive(),
			'Podcasts no longer active after sharing with Facebook'
		);

		UIALogger.logMessage('PASS* - Share to Facebook complete**');
	}

	if (service === 'Twitter') {
		var twitterWaiter = UIAWaiter.withPredicate(
			'ViewDidAppear',
			'controllerClass = "SLSheetRootViewController" AND controllerTitle = "Twitter"'
		);

		this.tap(service);

		UIAUtilities.assert(
			twitterWaiter.wait(30),
			'Twitter share sheet did not appear'
		);

		// Create a unique number to use on tweet since Erie now prevents duplicate tweets from being posted
        var tweetID = Math.floor((Math.random() * 10000));
        this.waitForKeyboard();
        this.typeString(tweetID);

		if (options.location) {
			var handleIt = function () {
				var app = target.activeApp();
				if (app.exists(UIAQuery.contains('access your location'))) {
					app.tap('Allow');
					return true;
				} else {
					return false;
				}
			};

			this.withAlertHandler(handleIt, function () {
				this.tap('Location');
			});

			this.tap('Twitter');
		}

		this.delay(2);
		this.tap('Post');
		if (!this.waitUntilAbsent(UIAQuery.keyboard(), 10)) {
			throw new UIAError('Could not tap Post for Twitter');
		}

		UIAUtilities.assert(
			this.isActive(),
			'Podcasts no longer active after sharing with Twitter'
		);
		UIALogger.logMessage('PASS* - Sharing to Twitter complete**');
	}
};

/**
 * Streams an audio episode from Top Charts in the production podcasts store
 * @param {{}} options - options dictionary
 * @param {number} [options.streamTime=30] - time, in seconds, we'll stream episode
 * @returns none
 * @throws if fails
 */
podcasts.streamFromStore = function streamFromStore(options) {
	UIALogger.logMessage('FUNCTION - streamFromStore()');
	options = UIAUtilities.defaults(options, {
		streamTime : 30
	});

	// if currently playing, stop
	if(CAMMediaRemote.isMediaPlaying()) {
		UIALogger.logWarning("••WARN: App is currently playing.  Pausing...");
		this.pause();
	}

	this.getToTab(TABS.BROWSE);
	this.tap(UIAQuery.Podcasts.TOP_CHARTS_CELL);
	if (iPad) {
		UIAUtilities.assert(
			this.waitUntilPresent('Top Audio Podcasts', 10),
			'No header for audio podcasts on top charts screen'
		);
		UIAUtilities.assert(
			this.waitUntilPresent('Top Video Podcasts', 10),
			'No header for video podcasts on top charts screen'
		);
	} else {
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.TOP_CHARTS_AUDIO_CONTROL, 10),
			'No segmented control for audio podcasts on top charts screen'
		);
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.TOP_CHARTS_VIDEO_CONTROL, 10),
			'No segmented control for video podcasts on top charts screen'
		);
	}

	// Tap on first podcast - '1,' is the first part of the label of the top podcast
	// should be audio - may need to add code to specify the audio table view
	this.tap(UIAQuery.beginsWith('1,').leftmost());
	this.waitForAnimations();

	// See if container page loaded
    if(!this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBE, 120)) {
    	// may already be subscribed
    	if(!this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBED, 20)) {
    		UIALogger.logWarning("•• WARN - No subscribe label found. Podcast store page may not have loaded.");
    	}
    }

	// Wait for episodes to appear - may fail without waiting
	if(!this.waitUntilPresent(UIAQuery.query("PodcastsUI.EpisodeView"), 30)) {
    		UIALogger.logWarning("•• WARN - No episode cell found.  May not have loaded.");
    }
	// Tap on episode now opens up details view
	var episodeQuery = UIAQuery.query("PodcastsUI.EpisodeView");
	var playedEpisode = this.inspectElementKey(episodeQuery, 'label');
	playedEpisode = playedEpisode.split(', ')[1];
	UIALogger.logMessage('Tapping on episode "%0" to open it...'.format(playedEpisode));
	this.tap(episodeQuery);

	// wait to load
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.query("Play"), 120),
		'Quickplay button did not appear after tapping on episode'
	);

	podcasts.tap(UIAQuery.query("Play").parent());

	// Wait 60 seconds for playback to begin
	this.waitForPlayback(60);
	UIALogger.logMessage('Success! - We are streaming!  Will stream for %0 seconds...'.format(options.streamTime));

	// TODO: verify name in mini player, verify mini player button state?

	// let it play/stream
	this.delay(options.streamTime);
	UIALogger.logMessage('Verifying app is still playing after delay');
	this.verifyPlaying();

	try {
		this.pause();
	} catch (e) {
		UIALogger.logError('Failed to pause playback after streaming test. Error message :%0'.format(e.message));
	}
	UIALogger.logMessage('•PASS - Successfully streamed via Store');
};

/**
 * Subscribes to one of the podcasts in the carousel in the store
 *
 * Updated for Tigris
 *
 * @param {{}} options - options dictionary
 * @param {string[]} options.toAvoid - String list of podcasts to avoid, not currently implemented here
 * @param {bool} options.verifySettings - if true, verifies the podcast has the correct settings after subscribe,
 * 		otherwise, only verification that the podcast appeared is done
 * @param {Object} options.expectedSettings - The expected settings to be passed in to verifyPodcastSettings
 *
 * @returns none
 * @throws if subscribe fails
 */
podcasts.subscribeFromFeatured = function subscribeFromFeatured(options) {
	options = UIAUtilities.defaults(options, {
		toAvoid 	     : [],
		verifySettings   : true,
		expectedSettings : {subscribed:true, notifications:true}, 
		/* removed sort order from above, since now each Show can have a different one */
	});
	UIALogger.logMessage('FUNCTION: subscribeFromFeatured');
	this.logStartingOptions(options);
	//var newToAvoid = options.toAvoid.slice();

	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Subscribe from Featured test'});
	this.launch();
	this.waitUntilPresent(UIAQuery.Podcasts.BROWSE_TAB);
	this.getToFeatured();

	// TAP on the first featured flow case item (the banner at top)
    this.tap('PodcastsUI.EditorialCardCollectionViewCell');
    var title = this.inspectElementKey(UIAQuery.query('PodcastsUI.DynamicTypeLabel').atIndex(0), 'label');
    // If already subscribed to this show, try another one
	if (this.exists(UIAQuery.Podcasts.SUBSCRIBED)) {
		UIALogger.logWarning('** WARN: already subscribed to %0'.format(title));
		this.tap('Featured');
		this.waitForAnimations();
		// swipe left can fail, so use index
		this.tap(UIAQuery.query('PodcastsUI.EditorialCardCollectionViewCell').atIndex(1));
	} 
	title = this.inspectElementKey(UIAQuery.query('PodcastsUI.DynamicTypeLabel').atIndex(0), 'label');
	// Wait to load the Subscribe button
	 UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBE, 120),
		'Subscribe button did not appear after 120 seconds'
	);
	// <rdar://problem/34232024> Store: Subscribe: 1st tap on Subscribe fails if done fast enough
	UIALogger.logWarning("**WARN: delaying 2 seconds due to <rdar://problem/34232024>");
	this.delay(2);
	this.tap(UIAQuery.Podcasts.SUBSCRIBE);

    UIALogger.logMessage('Title of show is %0'.format(title));
	// Update toAvoid and add it to results dictionary
	// newToAvoid.push(title);
	// UIALogger.logMessage('newToAvoid was %0'.format(newToAvoid));
	// UIALogger.logTAResults({toAvoid:newToAvoid});

	UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBED, 60),
			'Subscribed label did not appear after 60 seconds');

	// Verify settings match expected defaults
	if (options.verifySettings) {
        this.verifyPodcastSettings(title, options.expectedSettings);
    }

    //Broken in Tigris, not critical but will need to be fixed
	// Try to clear my podcasts but don't fail if it does not work
	// try {
	// 	this.deletePodcastFromMyPodcasts({deleteAll: true, needToNav: true});
	// } catch (err) {
	// 	UIALogger.logError('Could not delete all after subscribing from Featured. ERROR: %0'.format(err.message));
	// 	this.tapIfExists(UIAQuery.Podcasts.DONE_BUTTON);
	// }
	UIALogger.logMessage('*PASS subscribeFromFeatured complete');
};

/**
 * Subscribe to a podcast from the Search tab, in the store
 *  Verifies in the subscription in search UI, not in podcasts library
 *
 * @param {string} podcastSearchTitle - the name of the podcast to search for
 * @param {object} options
 * @param {int} options.waitToLoadTime - number of seconds to wait for (store) UI to load
 *
 * @returns {bool} true if successfully subscribed
 */
podcasts.subscribeFromSearch = function subscribeFromSearch(podcastSearchTitle, options) {
	UIALogger.logMessage("FUNCTION: subscribeFromSearch(): %0".format(podcastSearchTitle));
	options = UIAUtilities.defaults(options, {
        waitToLoadTime:	122,
    });

    //this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of subscribeFromSearch'});
	this.launch();
	this.waitUntilPresent(UIAQuery.Podcasts.BROWSE_TAB);

    // var modTitle = "";
    // may have to build a query if first search fails
    var queryWithRealTitle = UIAQuery.query(podcastSearchTitle);
	// this.quitOrKillApp();
	// this.launch();

	if (typeof podcastSearchTitle === undefined) {
		podcastSearchTitle = "Car Talk";
		UIALogger.logWarning("••WARN: No search title provided, searching for Car Talk instead...");
	}

	podcasts.getToTab(TABS.SEARCH);
	// Tap on Store segment

	UIALogger.logMessage("Do the Search...");
	// This does the search for us
	// If this is flaky, like previously, we should write our own
	podcasts.search(podcastSearchTitle);
	podcasts.delay(2);
	podcasts.tap(UIAQuery.segmentedControls().andThen(UIAQuery.buttons("All Podcasts")));


	// Get the title of the first thing returned in the list
	// Tigris TODO:  eventually, loop through the cells to find the exact one, splitting the name first
	/*
	modTitle = podcasts.inspectElementKey(UIAQuery.query(
		'PodcastsUI.SmallLockupView').atIndex(0),
		'label');
		UIALogger.logMessage('podcastName was "%0"'.format(modTitle));
	// Title also has provider, so we strip it
	modTitle = modTitle.split(', ')[0];

	if (podcasts.waitUntilPresent(
			UIAQuery.collectionViews().andThen(
			UIAQuery.query("PodcastsUI.SmallLockupView")).andThen(
			UIAQuery.query(modTitle)),
			options.waitToLoadTime)) {
		UIALogger.logMessage("•PASS: Search results loaded for: " + podcastSearchTitle);
	} else {*/
		// todo: remove this?  now that we split the string above
		// If we fail, see if our string is a subset of the actual title on store
		//UIALogger.logWarning("•WARN: First search failed, trying beginsWith... " + podcastSearchTitle);
		if (podcasts.waitUntilPresent(UIAQuery.beginsWith(podcastSearchTitle)), 5) {
			UIALogger.logMessage("•PASS: Search results loaded for: " + podcastSearchTitle);
			queryWithRealTitle = UIAQuery.beginsWith(podcastSearchTitle);
		} else {
			throw new UIAError("•••FAIL: Results may have loaded but " + podcastSearchTitle + " was not found.");
		}
//	}

	// SET UP WAITER - SKUIStorePageSectionsViewController is critical to use here
	/*
	var pcPageLoaded = UIAWaiter.withPredicate(
						'ViewDidAppear',
						'controllerClass = "SKUIStorePageSectionsViewController"'
	);
	*/
	// Tap on Podcast

	UIALogger.logMessage("Attempt to Tap on then Subscribe to " + podcastSearchTitle);
	podcasts.tap(queryWithRealTitle.topmost());

	// Wait for Podcast container page to load
	// if(!pcPageLoaded.wait(options.waitToLoadTime)) {}

	// Check if already subscribed, if not, Tap on subscribe
	if (podcasts.exists(UIAQuery.Podcasts.SUBSCRIBED)) {
		UIALogger.logWarning("••WARN: Already subscribed to %0.".format(podcastSearchTitle));
	} else {
		podcasts.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBE.isVisible(), 60);
		// <rdar://problem/34232024> Store: Subscribe: 1st tap on Subscribe fails if done fast enough
		UIALogger.logWarning("**WARN: delaying 2 seconds due to <rdar://problem/34232024>");
		this.delay(5);
		podcasts.tap(UIAQuery.Podcasts.SUBSCRIBE);
		//Verify Subscribe occurred
		if (podcasts.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBED.isVisible(), 90)) {
			UIALogger.logMessage("•PASS: Subscribe succeeded: Subscribed label is present.");
		} else {
			throw new UIAError("•••FAIL:  Subscribe failed: Subscribed label not found after 60 seconds.");
		}
	}

	// TO DO:  verify elsewhere - have to check the container, since the feed may
		// have a more recent episode, which will have downloaded
	/*
	var episodeQuery;
	if (iPad)
	{
		episodeQuery = UIAQuery.query('OverlayCaptureView').andThen(UIAQuery.Podcasts.PURCHASE_BUTTON).atIndex(1);
	} else
	{
		episodeQuery = UIAQuery.Podcasts.PURCHASE_BUTTON.atIndex(1);
	}

	// Verify the topmost episode
	// The episodes can load much later than the subscribe button, so wait...
	UIAUtilities.assert(
		this.waitUntilPresent(episodeQuery, 120),
		'Top episode never loaded'
	);

	episodeName = this.inspectElementKey(episodeQuery, 'label').split(', ')[0];
	UIALogger.logMessage('episodeName = %0'.format(episodeName));
	*/
	return true;
};


/**
 * Subscribes to the first audio podcast in Top Charts unless it is set as toAvoid
 *
 * @param {{}} options - options dictionary
 * @param {string[]} [options.toAvoid] - list of strings with podcast titles to avoid
 * @param {bool} [options.verifySettings] - If true, verifies settings after subscribe, otherwise only verifies the
 * 		podcast appeared
 * @param {Object} options.expectedSettings - The expected settings to be passed in to verifyPodcastSettings
 *
 * @returns none
 * @throws if subscribe fails
 */
podcasts.subscribeFromTopCharts = function subscribeFromTopCharts(options) {
	options = UIAUtilities.defaults(options, {
		toAvoid        : [],
		verifySettings : true,
        expectedSettings : {subscribed:true, notifications:true, mostRecentFirst:true},
	});
	UIALogger.logMessage('FUNCTION: subscribeFromTopCharts');
	this.logStartingOptions(options);

	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Subscribe from Top Charts test'});

	this.launch();

	// Avoid potential for toAvoid to be the $$ passed in value
	if (!Array.isArray(options.toAvoid)) {
		UIALogger.logWarning('toAvoid is not an Array');
		options.toAvoid = [];
	}

	this.getToTab(TABS.BROWSE);
	this.tap(UIAQuery.Podcasts.TOP_CHARTS_CELL);

	if (iPad) {
		UIAUtilities.assert(
			this.waitUntilPresent('Top Audio Podcasts', 10),
			'No header for audio podcasts on top charts screen'
		);
		UIAUtilities.assert(
			this.waitUntilPresent('Top Video Podcasts', 10),
			'No header for video podcasts on top charts screen'
		);
	} else {
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.TOP_CHARTS_AUDIO_CONTROL, 10),
			'No segmented control for audio podcasts on top charts screen'
		);
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.TOP_CHARTS_VIDEO_CONTROL, 10),
			'No segmented control for video podcasts on top charts screen'
		);
	}

	var unique = false;
	var k = 1;
	var itemLabel = null;

	// Taps the top episode in Top Charts not in toAvoid
	while (!unique) {
		var stringNumber = k + ', ';
		UIALogger.logMessage('stringNumber was %0'.format(stringNumber));
		// Wait for number to be available and fail if it does not appear after 2 minutes
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.beginsWith(stringNumber).leftmost(), 120),
			'No numbers became visible on Top Charts page'
		);
		itemLabel = this.inspectElementKey(UIAQuery.beginsWith(stringNumber).leftmost(), 'label');

		// If toAvoid has no entries, then determine that it is in fact unique. Otherwise loop through toAvoid to see
		// if item is unique
		if (options.toAvoid.length === 0) {
			unique = true;
		} else {
			for (var i = 0; i < options.toAvoid.length; i++) {
				UIALogger.logMessage('Checking for %0'.format(options.toAvoid[i]));
				// Exit this loop if item to avoid is found
				var index = itemLabel.indexOf(options.toAvoid[i]);
				if (index !== -1) {
					UIALogger.logMessage('%0 found in item name'.format(options.toAvoid[i]));
					unique = false;
					break;
				} else {
					UIALogger.logMessage('%0 is not in item label'.format(options.toAvoid[i]));
					unique = true;
				}
			}
		}
		k++;
	}

	this.tap(itemLabel);

	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBE, 120),
		'Subscribe button did not appear after 120 seconds'
	);

	var title = itemLabel.split(', ')[1];
	UIALogger.logMessage('Title was %0'.format(title));
	
	// <rdar://problem/34232024> Store: Subscribe: 1st tap on Subscribe fails if done fast enough
	UIALogger.logWarning("**WARN: delaying 2 seconds due to <rdar://problem/34232024>");
	this.delay(2);
	this.tap(UIAQuery.Podcasts.SUBSCRIBE);

	UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBED, 60),
			'Subscribed label did not appear after 60 seconds');

    // Verify settings match expected defaults
    if (options.verifySettings) {
        this.verifyPodcastSettings([title], options.expectedSettings);
    }

    // Broken in Tigris. Not a critical fix
	// Try to clear my podcasts but don't fail if it does not work
	// try {
	// 	this.deletePodcastFromMyPodcasts({deleteAll: true, needToNav: true});
	// } catch (err) {
	// 	UIALogger.logError('Could not delete all after subscribing from Top Charts. ERROR: %0'.format(err.message));
	// 	this.tapIfExists(UIAQuery.Podcasts.DONE_BUTTON);
	// }
	UIALogger.logMessage('PASS* subscribeFromTopCharts complete');
};


/**
 * Launches app and passes in a a Feed URL
 *
 * @param {{}} options
 * @param {string} options.feedUrl - Podcast feed url to subscribe to
 */
podcasts.subscribeToPodcastUsingURL = function subscribeToPodcastUsingURL(options) {
	options = UIAUtilities.defaults(options, {
		feedUrl : "pcast://www.npr.org/rss/podcast.php?id=344098539"
	});

	this.handlingAlertsInline(UIAQuery.Podcasts.ADD_PODCAST_ALERT, function () {
		UIALogger.logDebug("URL is "+ options.feedUrl);
		var pt = target.performTask("/usr/local/bin/LaunchApp", ["-url", options.feedUrl]);
		UIALogger.logDebug(pt);

		this.tap(UIAQuery.buttons('Subscribe'));
	});
	UIALogger.logWarning("No verification of subscription occurs in this function.");

};


/**
 * Subscribe by tapping the Add Podcast in Shows if the podcast is not already listed in Shows
 *
 * Starting state: Any
 *
 * @param {string} URL - URL to subscribe to
 * @param {string} podcastTitle - Title of podcast being subscribed to
 * @param {{}} options - Options dictionary
 * @param {bool} options.verify - if true, verify subscribe switch in podcast settings
 * @param {bool} options.needToNav=true - If true, navigates to My Podcasts page
 *
 * @throws if subscribe fails
 * @returns none
 */
podcasts.subscribeViaPlusSignToURL = function subscribeViaPlusSignToURL (URL, podcastTitle, options) {
	UIALogger.logMessage('FUNCTION: subscribeViaPlusSignToURL: URL: %0, Podcast: %1'.format(URL, podcastTitle ));
	options = UIAUtilities.defaults(options, {
		verify    : false,
		needToNav : true,
	});
	var libIsEmpty = false;
	var theQuery = null;
	this.logStartingOptions(options, 'URL was %0, podcastTitle was %1'.format(URL, podcastTitle));

	if (options.needToNav) {
		this.launch();
		this.getToTab(TABS.LIBRARY);
		// Library may be empty; if so, there is no Shows cell 
		if (!this.tapIfExists(UIAQuery.Podcasts.SHOWS_CELL)) {
			libIsEmpty = true;
		}
	} else {
		UIALogger.logMessage('No navigation occurring because needToNav was false');
	}

	if (!this.exists(UIAQuery.Podcasts.PODCAST_CONTAINER.contains(podcastTitle))) {
		if (libIsEmpty) {
			UIALogger.logMessage('Library is empty..................');
			theQuery = UIAQuery.query('Add a Podcast by URL');
		} else {
			this.tap(UIAQuery.Podcasts.EDIT_NAVBAR.rightmost());
			theQuery = UIAQuery.Podcasts.ADD_PODCAST_BUTTON;
		}
		UIALogger.logMessage('*******************************************');
		this.handlingAlertsInline(UIAQuery.Podcasts.ADD_PODCAST_ALERT, function () {
			this.delay(1); // tap sometimes fails
			this.tap(theQuery);
			this.waitUntilPresent(UIAQuery.keyboard());
			this.typeString(URL);
		});
		// NOW WE'RE IN THE SUBSCRIBE ALERT:
		this.handlingAlertsInline(UIAQuery.Podcasts.SUBSCRIBE_ERROR_ALERT.orElse(
							      UIAQuery.Podcasts.NOT_CONNECTED_ALERT).orElse(
							      UIAQuery.Podcasts.AIRPLANE_MODE_ALERT), function () {

			this.tap('Subscribe');

			// Wait 120 seconds for Podcast to appear or alert indicating subscribe failed
			if (this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBE_ERROR_ALERT.orElse(
								      UIAQuery.Podcasts.NOT_CONNECTED_ALERT).orElse(
								      UIAQuery.Podcasts.AIRPLANE_MODE_ALERT).orElse(
									  UIAQuery.contains(podcastTitle)), 120)) {
				if (this.exists(UIAQuery.tableCells().contains(podcastTitle))) {
					UIALogger.logMessage('Podcast appeared in My Podcasts');
				} else if (this.exists(UIAQuery.Podcasts.SUBSCRIBE_ERROR_ALERT)) {
					this.tap('OK');
					throw new UIAError('Podcasts was unable to subscribe to the podcast');
				} else if (this.exists(UIAQuery.Podcasts.NOT_CONNECTED_ALERT)) {
					this.tap('OK');
					throw new UIAError('Unable to subscribe to podcast. Device indicates it is not connected to the' +
						' internet');
				} else if (this.exists(UIAQuery.Podcasts.AIRPLANE_MODE_ALERT)) {
					this.tap('OK');
					throw new UIAError('Unable to subscribe to podcast. Device indicates it is in AirPlane Mode');
				}
			} else {
				throw new UIAError('Unable to subscribe due to unknown error. Podcasts failed to subscribe to the' +
					' podcast and did not throw an error indicating it was unable to subscribe. Title: %0'.format(podcastTitle));
			}
		});

		this.delay(2); // tap sometimes fails
		this.tapIfExists(UIAQuery.Podcasts.DONE_BUTTON);

		if (options.verify) {
			this.drillIntoPodcastContainer(podcastTitle);

			this.tap(UIAQuery.Podcasts.PODCAST_SETTINGS);

			// Wait for Subscribe setting to be present
			UIAUtilities.assert(
				this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS_SUBSCRIBED),
				'Subscribe setting for podcast did not appear after 5 seconds'
			);
			UIAUtilities.assert(
				this.valueOf(UIAQuery.Podcasts.PODCAST_SETTINGS_SUBSCRIBED) == 1,
				'Podcast "%0" is not Subscribed'.format(podcastTitle)
			);

			this.dismissPopover();
			if (!iPad) {
				this.getToTab(TABS.LIBRARY);
			}
			UIALogger.logMessage('•PASS: Subscribed to %0 successfully'.format(podcastTitle));
		} else {
			UIALogger.logMessage('•PASS - Subscribe succeeded without verification.');
		}
	} else {
		UIALogger.logMessage('Podcast %0 already has a container'.format(podcastTitle));
	}
};


/**
 * Take in the name of an episode and taps on the episode's track action button. Only works in My Podcasts as
 * currently the button might as well not exist on Unplayed as far as automation is concerned. Tracked by
 * <rdar://problem/22873522> Podcasts: "Track actions" button cannot be seen by accessibility. Though the original
 * bug mentioned here may have inadvertently been resolved, there is still an issue tracked by <rdar://problem/26741180>
 * Buttons Exist in Accesbility On Unplayed Tab But Automation Continues to try To Scroll to Visibile
 *
 * Expected starting state: In the container with the episode that will be selected
 *
 * @param {string} episodeName - Episode name to indicate which track action button to tap on
 *
 * @throws if track actions does not open or episode is not visible
 * @returns none
 */
podcasts.tapTrackActions = function tapTrackActions(episodeName) {
	UIALogger.logMessage('FUNCTION: tapTrackActions');
	UIALogger.logMessage('episodeName was %0'.format(episodeName));

	this.assertExists(UIAQuery.contains(episodeName));
	var buttonIndex = 0;

	if (this.exists(UIAQuery.contains(episodeName).andThen(UIAQuery.buttons('more\u2026')))) {
		buttonIndex = 1;
	}

	this.tap(UIAQuery.contains(episodeName).andThen(UIAQuery.buttons().atIndex(buttonIndex)));

	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.actionSheets(), 5),
		'Track actions did not open after waiting 5 seconds');
};


/**
 * Attempts to tap on the episode passed in, in order to play it
 * If no episodeName is given, it will attempt to simply play the first unplayed episode
 *    for that podcast container
 *
 * Updated for Tigris
 *
 * Expected starting state: Any
 *
 * @param {string} podcastTitle - Podcast container name to play
 * @param {object} options - Options dictionary
 * @param {bool} options.keepUpNext - Defaults to true, if false it will clear up next
 *
 * @throws if episode cannot be tapped
 * @returns Cleaned title of episode tapped on to play
 */

podcasts.tapToPlayEpisodeInMyPodcasts = function tapToPlayEpisodeInMyPodcasts(podcastTitle, options) {
	UIAUtilities.assert(
		podcastTitle !== undefined,
		"•ERROR: tapToPlayEpisodeInMyPodcasts called with no podcast title."
	);
	options = UIAUtilities.defaults(options, {
		episodeName : null,
		keepUpNext  : true,
	});
	UIALogger.logMessage("FUNCTION: tapToPlayEpisodeInMyPodcasts: %0, %1".format(podcastTitle, options.episodeName));
	//var episodeList = [];
	var upNextOption;
	var episodeTapped = null;
	if (options.keepUpNext) {
		upNextOption = 'Keep Up Next';
	} else {
		upNextOption = 'Clear Up Next';
	}

	// This gets to the tab and to the podcast details for us
	this.getToPodcastDetails(podcastTitle);

	if (options.episodeName === null || options.episodeName === '') {
		// TODO: see code below to handle the Up Next alert 
		// Play the episode listed in Quickplay  - usually the most recent unless you've already played another episode
		this.tap(UIAQuery.query("Play").topmost()); // the Quickplay Play button
		episodeTapped = this.nameOf('PodcastsUI.QuickPlayView');
		// this string contains its play state, e.g. "Play, Episode name X"
		episodeTapped = episodeTapped.split(', ')[1];
		this.verifyPlaying();
		/* todo: old way below, always generates a list.
		// This looks broken right now - needs to handle new UI from late Tigris updates
		UIALogger.logMessage("NO EPISODE name was passed in; Will tap on first episode...");
		episodeList = this.generateEpisodeList( {
			podcastTitle: podcastTitle,
		});
		*/

	} else {
		this.assertExists(
			UIAQuery.Podcasts.CONTAINER_EPISODE_CELL.contains(options.episodeName),
			'Episode named %0 not found'.format(options.episodeName)
		);
		episodeTapped = options.episodeName;
		// TO DO: this code handles the case for the Up Next alert 
		// create individual functions to handle this?
		this.handlingAlertsInline(UIAQuery.contains('Keep Up Next'), function() {
			this.tap(UIAQuery.Podcasts.CONTAINER_EPISODE_CELL.contains(episodeTapped));
			if (this.waitUntilPresent(UIAQuery.buttons('ActionItem QuickPlay'), 1)){
				this.tap(UIAQuery.buttons('ActionItem QuickPlay'));
			}
			if (this.waitUntilPresent(UIAQuery.contains('Keep Up Next'), 10)) {
				this.tap(upNextOption);
				UIALogger.logMessage('Tapped on %0 in the Up Next prompt'.format(upNextOption));
			} else {
				UIALogger.logMessage('Up Next prompt did not appear after 10 seconds');
			}
		});
	}
	UIALogger.logMessage('episodeTapped was %0'.format(episodeTapped));
	return episodeTapped;
};

/**
 * Plays a specific episode from Unplayed or plays the top item
 *
 * @param {Object}options - options dictionary
 * @param {string} [options.episodeName=null] - Name of episode to play. If nothing passed in, playes the top episode
 * @param {boolean} [options.keepUpNext=true] - If true, keeps up next. When false, clears it
 *
 * @returns {string} - Name of episode played
 */
podcasts.tapToPlayEpisodeInUnplayed = function tapToPlayEpisodeInUnplayed(options) {
	options = UIAUtilities.defaults(options, {
		episodeName : null,
		keepUpNext  : true,
	});
	UIALogger.logMessage('FUNCTION: tapToPlayEpisodeInUnplayed');
	this.logStartingOptions(options);

	var upNextOption;
	if (options.keepUpNext) {
		upNextOption = 'Keep Up Next';
	} else {
		upNextOption = 'Clear Up Next';
	}

	this.getToTab(TABS.UNPLAYED);

	if (options.episodeName === null || options.episodeName === '') {
		options.episodeName = this.generateEpisodeList({limit : 1})[0];
	}

	this.scrollEpisodeCellToVisible(options.episodeName);
	this.handlingAlertsInline(UIAQuery.contains('Keep Up Next'), function() {
		this.tap(UIAQuery.tableCells().contains(options.episodeName).rightmost());

		if (this.waitUntilPresent(UIAQuery.contains('Keep Up Next'), 10)) {
			this.tap(upNextOption);
			UIALogger.logMessage('Tapped on %0 in the Up Next prompt'.format(upNextOption));
		} else {
			UIALogger.logMessage('Up Next prompt did not appear after 10 seconds');
		}
	});
	return options.episodeName;
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: HELPER FUNCTIONS                                                   */
/*      These don't test the app directly, but are needed       			   */
/*        by other test functions or operate outside of the app                */
/*                                                                             */
/*                                                                             */
/*******************************************************************************/


/**
 * Backgrounds and foregrounds Podcasts
 *
 * @throws if Podcasts fails to launch after 2 attempts
 */
podcasts.backgroundForeground = function backgroundForeground() {
	UIALogger.logMessage('FUNCTION: backgroundForeground');

	target.clickMenu();
	//Without delay script fails to activate Podcasts rdar://problem/24263433
	springboard.delay(1);
	this.launch();

	// Needed to work around similar issue to Radar above in which launch fails to actually launch app
	if (!this.isRunning()) {
		this.delay(15);
		this.launch();
	}
	UIAUtilities.assert(this.isRunning(), 'Podcasts failed to launch after 2 attempts');
};

/**
 * Tries to quit Podcasts via the UI and if that fails it kills the app using performTask
 *
 * @param {Object} options - Options dictionary
 * @param {string} [options.errorDetail="Podcasts failed to quit"] - Error message to print before the full error is
 * 		printed
 */
podcasts.quitOrKillApp = function quitOrKillApp(options) {
	options = UIAUtilities.defaults(options, {
		errorDetail : 'Podcasts failed to quit'
	});
	UIALogger.logMessage('FUNCTION: quitOrKillApp');
	this.logStartingOptions(options);

	try {
		this.quit();
		springboard.delay(2);
	} catch (e) {
		UIALogger.logError('%0. Error was: %1'.format(options.errorDetail, e.message));

		try {
			UIALogger.logMessage('Trying to kill Podcasts with killall');
			target.performTask('/usr/bin/killall', ['Podcasts'], 5);
			// Give it enough time to recover from killing the app so it can launch
			springboard.delay(15);
		} catch (killErr) {
			UIALogger.logError('%0. killall Error was: %1'.format(options.errorDetail, killErr.message));
		}
	}
};


/**
 * Checks the order of all episodes in a specific container
 *
 * Expected starting state: Drilled in to the container that need to be verified. Station not grouped by podcast
 *
 * @param {string[]} episodeList - Array containing ordered list of cleaned episode titles to compare against in the
 * 		correct order from top to bottom with top being at index 0
 * @param {{}} options - options dictionary
 * @param {string} [options.podcastTitle=null] - Title of podcast container being checked. If checking a podcast
 * 		container, title of podcast must be passed in
 * @param {string} [options.stationName=null] - Name of the station being checked. If a station is being checked a
 * 		station name must be passed in
 * @param {bool} options.feed - If true, will navigate to the feed tab
 * @param {bool} options.saved - If true, till navigate to saved
 * @param {bool} options.needToNavigate - if false, starting state must have episodes in UI
 * @param {bool} [options.getCleanedTitle=true] - If false, it will compare titles as found by getAllEpisodeData
 *
 * @throws If episodes are not in order
 */
podcasts.checkEpisodeOrder = function checkEpisodeOrder(episodeList, options) {
	options = UIAUtilities.defaults(options,{
		podcastTitle    : null,
		stationName     : null,
		feed            : false,
		saved           : false,
		needToNavigate  : false,
		getCleanedTitle : true,
	});
	UIALogger.logMessage('FUNCTION: checkEpisodeOrder');
	this.logStartingOptions(options, 'episodeList was %0'.format(episodeList));

	var currentOrder = this.generateEpisodeList(options);
	UIALogger.logMessage('Length of currentOrder was %0. Length of episodeList was %1'.format(
		currentOrder.length, episodeList.length
	));

	UIAUtilities.assert(currentOrder.length === episodeList.length,
		'The length of the episodeList and currentOrder do not match');

	// If using cleaned titles then simply compare the strings. Otherwise get all episode data to confirm against
	if (options.getCleanedTitle) {
		for (var i = 0; i < currentOrder.length; i++) {
			UIAUtilities.assert(currentOrder[i] === episodeList[i],
				'Found %0 at index %1, expected %2'.format(currentOrder[i], i, episodeList[i]));
		}
	} else {
		// Get all episode data from the cells for comparison
		var allCurrentEpisodeData = this.getAllEpisodeDataFromRawValues(currentOrder, options.podcastTitle);

		for (var t = 0; t < allCurrentEpisodeData.length; t++) {
			UIALogger.logMessage('Verifying %0 = %1'.format(allCurrentEpisodeData[t].title, episodeList[t].title));

			UIAUtilities.assertEqual(
				allCurrentEpisodeData[t].title,
				episodeList[t].title,
				'Found %0 at index %1, expected %2'.format(allCurrentEpisodeData[t].title, t, episodeList[t].title)
			);
		}
	}
	UIALogger.logMessage('checkEpisodeOrder Passed');
};


/**
 * Check for the existence of all podcast and stations containers and verify the order
 *
 * Expected starting state: On My Podcasts at the top level
 * @param {string[]} podcastList - Array containing ordered list of podcast container UI element names ordered as
 * they should appear in the app from top to bottom. Top podcast is at [0], the next at [1] and so on
 *
 * @throws If podcasts are not in the expected order
 */
podcasts.checkMyPodcastsOrder = function checkMyPodcastsOrder(podcastList){
	UIALogger.logMessage('FUNCTION: checkMyPodcastsOrder()');

	var currentOrder = this.generateShowsList({needToNav:false});

	// Confirm there are the correct number of items on each list
	UIAUtilities.assertEqual(
		podcastList.length,
		currentOrder.length,
		'podcastOrder and currentOrder are different lengths.'
	);
	var listsMatch = true;

	for (var i = 0; i < podcastList.length; i++) {
		var itemsMatch = true;
		// Compares values representing actual UI to array passed in and verifies they match
		if (currentOrder[i] !== podcastList[i]) {
			itemsMatch = false;
			listsMatch = false;
			UIALogger.logFail('Expected %0 but found %1'.format(podcastList[i], currentOrder[i]));
		}
	}

	if (!listsMatch) {
		throw new UIAError ('My Podcasts lists do not match');
	}

	UIALogger.logPass('checkMyPodcastsOrder verified lists match');
};

/**
 * Compares an expected list of items in Up Next to the current list of items in Up Next. List should be one
 * generated by generateUpNextList
 *
 * @param {Object} expectedList
 * @param {Object} options - options dictionary
 * @param {boolean} [options.needToNav=true] - When true, navigate to the Up Next tab
 * @param {boolean} [options.needToClose=true] - When true, closes Up Next after generating the list
 * @param {string} [options.location="Now Playing"] - Now Playing to get the list from Now Playing, Mini Player to
 * 		grab it from the mini player on iPads
 * @param {string} [options.additionalMessage=""] - Additional message to include in case of an error
 *
 * @throws if lists do not match
 */
podcasts.checkUpNextOrder = function checkUpNextOrder (expectedList, options) {
	options = UIAUtilities.defaults(options, {
		needToNav   	  : true,
		needToClose 	  : true,
		location    	  : 'Now Playing',
		additionalMessage : '',
	});
	UIALogger.logMessage('FUNCTION: checkUpNextOrder');
	this.logStartingOptions(options, 'expectedList = "%0"'.format(expectedList));

	var currentList = this.generateUpNextList(options);

	// Check each possible key
	var keys = ['history', 'playing', 'next'];
	for (var i = 0; i < keys.length; i++) {
		var expectedLength = expectedList[keys[i]].length;
		var currentLength = currentList[keys[i]].length;


		UIAUtilities.assertEqual(
			expectedLength,
			currentLength,
			'Lengths do not match. \nexpectedList was "%0"\ncurrentList was "%1"\n%2'.format(
				expectedList, currentList, options.additionalMessage.trim())
		);

		for (var k = 0; k < expectedLength; k++) {
			UIAUtilities.assertEqual(
				expectedList[keys[i]][k],
				currentList[keys[i]][k],
				'Lists are not equal. %0'.format(options.additionalMessage.trim()),
				{expectedList: expectedList, currentList: currentList}
			);
		}
		UIALogger.logMessage('Items in %0 are equal'.format(keys[i]));
	}
	UIALogger.logPass('All items in Up Next equal');
};

/**
 * Generates a list of episodes in the correct order from top to bottom. Prints the array to log to also
 * be used to quickly generate an array that can be copied and pasted in to code for testing purposes.
 *
 * Expected starting state: Any
 *
 * Updated for Tigris
 *
 * @param {{}} options - Options dictionary
 * @param {string} options.podcastTitle - Full title of podcast. This is required if you are getting episode
 * 		information from a specific podcast container
 * @param {string} options.stationName - Full station name, required if generating from station
 * @param {bool} options.needToNavigate - if false, starting state must have episodes in UI
 * @param {bool} [options.getCleanedTitle=true] - If false, returns the whole chunk of automation information, not
 * 		just the title
 * @param {number} [options.limit=-1] - Number of episodes to limit the list to
 *
 * @returns {string[]} - Array containing the cleaned titles of episodes or the whole text of the tableCell
 */
podcasts.generateEpisodeList = function generateEpisodeList(options) {
	options = UIAUtilities.defaults(options, {
		podcastTitle    : null,
		stationName     : null,
		needToNavigate  : false,
		getCleanedTitle : true,
		limit			: -1,
	});

	UIALogger.logMessage('FUNCTION: generateEpisodeList');
	this.logStartingOptions(options);

	var count = options.limit;
	var screenshotName = 'Container_';
	var returnArray = [];
	if (options.stationName != null && options.podcastTitle != null ||
		options.stationName == null && options.podcastTitle == null) {
		throw new UIAError('Must pass in either podcastTitle or stationName');
	}

	this.launch();

	//Generates episodes from podcast container
	if (options.podcastTitle !== null) {
		screenshotName = screenshotName + options.podcastTitle;
		if (options.needToNavigate) {
			UIALogger.logMessage('Navigating to podcast %0'.format(options.podcastTitle));
			this.getToPodcastDetails(options.podcastTitle);

		} else {
			UIALogger.logMessage('No navigation will occur.  Should already be in My Podcasts details.');
		}

		var episodeCellQuery;
		if (this.exists('Best of the Podcast')) {
			episodeCellQuery = UIAQuery.Podcasts.CONTAINER_EPISODE_WITH_BEST;
		} else {
			episodeCellQuery = UIAQuery.Podcasts.CONTAINER_EPISODE_CELL;
		}

		if (count === -1)
			count = this.count(episodeCellQuery);

		// Get info for every episode cell and then loop through the array grabbing labels
		var allEpisodesData = this.inspectAll(episodeCellQuery);

		for (var i = 0; i < count; i++) {
			returnArray.push(allEpisodesData[i].label);
			if (options.getCleanedTitle)
				returnArray[i] = this.getCleanedEpisodeTitle(returnArray[i]);
		}
	} else {
		//Generates episodes from station
		screenshotName = screenshotName + options.stationName;
		if (options.needToNavigate) {
			UIALogger.logMessage('Navigating to station %0'.format(options.stationName));
			this.getToTab(TABS.LIBRARY);
			this.tap(options.stationName);
		} else {
			UIALogger.logMessage('No navigation will occur. Should already be in Station details.');
		}

		if (count === -1)
		    count = this.count(UIAQuery.Podcasts.STATION_EPISODE_CELL);

        // Get info for every episode cell and then loop through the array grabbing labels
        var stationEpisodes = this.inspectAll(UIAQuery.Podcasts.STATION_EPISODE_CELL);

		for (var j = 0; j < count; j++) {
			returnArray.push(stationEpisodes[j].label);
			if (options.getCleanedTitle)
			    returnArray[j] = this.getCleanedEpisodeTitle(returnArray[j]);
		}
	}

    this.takeScreenShot(UIAScreenIdentifier.MAIN, screenshotName);

	UIALogger.logMessage('Array generated by generateEpisodeList was %0'.format(returnArray));
	return returnArray;
};

/**
 * Generates a list of items in My Podcasts in the correct order from top to bottom. Prints the array to log to also
 * be used to quickly generate an array that can be copied and pasted in to code for testing purposes
 *
 * Updated for Tigris
 *
 * Expected starting state: Any
 *
 * @param {object} options - options dictionary
 * @param {bool} [options.needToNav=true] - Indicate if function should navigate for the user
 *
 * @returns {string[]} - Array containing the element names of stations and podcasts in My Podcasts, single entry of
 * 		the value ['Empty'] is returned if My Podcasts is empty
 */
podcasts.generateShowsList = function generateMyPodcastsList(options) {
	options = UIAUtilities.defaults(options, {
		needToNav 		: true,
	});
	UIALogger.logMessage('FUNCTION: generateShowsList()');
	this.logStartingOptions(options);

	if (options.needToNav) {
		UIALogger.logMessage('Navigating to My Podcasts/Shows');
		this.launch();
		this.getToTab(TABS.LIBRARY);
		this.tap(UIAQuery.Podcasts.SHOWS_CELL);
	}
	var returnArray = [];

	//Sets returnArray to ['Empty'] if My Podcasts is empty otherwise generates list
	if (this.exists(UIAQuery.staticTexts().contains('You have no podcasts'))) {
		UIALogger.logMessage('My Podcasts is empty and no list was generated');
		returnArray = ['Empty'];
	} else {
		var originalCount = 0;
		var currentCount = 0;
		var changed = false;
		do {
			// Get the total count of artwork items to catch if anything changes when each query occurs
			originalCount = this.count(UIAQuery.query('Artwork').below(UIAQuery.navigationBars('Shows')));
			changed = false;

			// Loops through the items in My Podcasts, if the number of artwork items changes, break the for loop and
			// start again
			for (var i = 0; i < originalCount; i++) {
				currentCount = this.count(UIAQuery.query('Artwork').below(UIAQuery.navigationBars('Shows')));
				if (currentCount !== originalCount) {
					UIALogger.logWarning('Number of items changed, starting over');
					returnArray = [];
					changed = true;
					break;
				}

				returnArray.push(this.inspect(UIAQuery.query('Artwork').below(UIAQuery.navigationBars('Shows')).atIndex(i).siblings()).label);
			}
			if (currentCount !== originalCount && !changed) {
				UIALogger.logWarning('Number of tableCells changed after final item gathered. Generating list again.');
				changed = true;
			}
		} while (changed);

		UIALogger.logMessage('Array generated by generateShowsList was %0'.format(returnArray));
	}
	return returnArray;
};

/**
 * Generates a list of the top level items in My Podcasts. Currently blocked
 *
 * Updated for Tigris, though not functional
 *
 * @param options - options dictionary
 * @param [options.needToNav=true] - If true, navigates to My Podcasts, other wise assumes already there
 */
podcasts.generateMyPodcastsList = function generateMyPodcastsList(options) {
    options = UIAUtilities.defaults(options, {
        needToNav : true,
    });
    throw new UIAError('Not implemented due to rdar://problem/31618066 Items That Are Below a UI Element Show Up ' +
        'Above it in Tree on My Podcasts in Podcasts and rdar://problem/31618130 REG: Numbers Next to Top Level Items ' +
        "in My Podcasts Do Not Show Up In Accessibility, Aren't Read by Voiceover");
	/*
    if (options.needToNav) {
    	this.getToTab(TABS.LIBRARY);
	}
	*/
};

/**
 * Generates a list containing the ouput of getPodcastContainerData for all podcasts in My Podcasts
 *
 * Expected Starting State - On My Podcasts tab
 *
 * @returns {Array} - array of all podcasts data as gathered by getPodcastContainerData
 */
podcasts.generateListOfOnlyPodcasts = function generateListOfOnlyPodcasts() {
	UIALogger.logMessage('FUNCTION: generateListOfOnlyPodcasts');

	var toReturn = [];
	var count = this.count(UIAQuery.tableCells().contains('unplayed'));
	UIALogger.logMessage('count = %0'.format(count));

	for (var i = 0; i < count; i++) {
		toReturn.push(this.getPodcastContainerData(
			this.inspectElementKey(UIAQuery.tableCells().contains('unplayed').atIndex(i), 'label')));
	}

	return toReturn;
};
/**
 * Generates a list of items in Up Next returning a dictionary with arrays for history, playing and next in Up Next
 *
 * @param {Object} options - options dictionary
 * @param {boolean} [options.needToNav=true] - When true, navigate to the Up Next tab
 * @param {boolean} [options.needToClose=true] - When true, closes Up Next after generating the list
 * @param {string} [options.location="Now Playing"] - Now Playing to get the list from Now Playing, Mini Player to
 * 		grab it from the mini player on iPads
 *
 * @returns {{history: Array, playing: Array, next: Array}}
 */
podcasts.generateUpNextList = function generateUpNextList(options) {
	options = UIAUtilities.defaults(options, {
		needToNav   : true,
		needToClose : true,
		location    : 'Now Playing',
	});

	var toReturn = {history:[], playing:[], next:[]};
	if (options.needToNav) {
		this.launch();
		if (options.location === 'Now Playing') {
			if (!this.exists(UIAQuery.Podcasts.UPNEXT_NAV_BAR)) {
				this.getToNowPlaying();
				this.tap(UIAQuery.Podcasts.UPNEXT_BUTTON);
			} else {
				UIALogger.logMessage('Already in Up Next');
			}
		}
		// Tigris removed: else if.  no mini player Up Next exists
	}

	this.waitUntilPresent(
		UIAQuery.Podcasts.UPNEXT_NAV_BAR,
		5,
		'Up Next nav bar did not appear'
	);

	// Find number of header items in Up Next
	var headerCount = this.count(UIAQuery.Podcasts.UPNEXT_HEADERS);
	var getHistory = false;
	var playingIndex = 0;

	if (this.exists(UIAQuery.Podcasts.UPNEXT_HEADERS.children().andThen('History'))) {
		getHistory = true;
		playingIndex = 1;
		var histQuery = UIAQuery.tableCells().above(UIAQuery.Podcasts.UPNEXT_HEADERS.atIndex(playingIndex).below(
			UIAQuery.Podcasts.UPNEXT_HEADERS.atIndex(0)));

		var historyCount = this.count(histQuery);

		for (var i = 0; i < historyCount; i++) {
			toReturn.history.push(this.inspectElementKey(histQuery.atIndex(i).children(), 'label'));
		}
	}

	if (headerCount >= 3 || (headerCount === 2 && !getHistory)) {
		var nextIndex = playingIndex + 1;
		var nextQuery = UIAQuery.tableCells().below(UIAQuery.Podcasts.UPNEXT_HEADERS.atIndex(nextIndex));

		var nextCount = this.count(nextQuery);

		for (var j = 0; j < nextCount; j++) {
			toReturn.next.push(this.inspectElementKey(nextQuery.atIndex(j).children(), 'label'));
		}
	}

	toReturn.playing.push(this.inspectElementKey(UIAQuery.tableCells().below(UIAQuery.Podcasts.UPNEXT_HEADERS.atIndex(
		playingIndex)).children(), 'label'));

	if (options.needToClose) {
		var closeWaiter = UIAWaiter.withPredicate(
			'ViewDidDisappear',
			'navigationItemTitle = "Up Next"'
		);
		this.tap(UIAQuery.Podcasts.UPNEXT_DONE_BUTTON);

		UIAUtilities.assert(
			closeWaiter.wait(5),
			'Up Next never dismissed'
		);
	}

	UIALogger.logMessage('Up Next list was %0'.format(toReturn));
	return toReturn;
};

/**
 * Generates a list of items that are present on the CarPlay screen for Unplayed, My Podcasts, Podcast Container,
 * 		Station and station containers. If a podcast has a Saved Episodes container that item is removed
 *
 * Expected starting state: Must be on the page desired in CarPlay to generate the list
 *
 * @returns {Array} - Array containing the title or names of the items in order from top to bottom that are on the
 * 		current CarPlay screen
 */
podcasts.generateCarPlayItemList = function generateCarPlayItemList() {
	UIALogger.logMessage('FUNCTION: generateCarPlayItemList');

	var toReturn = [];

	UIALogger.logMessage('Getting count of tableCells on CarPlay screen');
	var count = springboard.count(UIAQuery.tableCells().onScreen('CarPlay'));

	for (var i = 0; i < count; i++) {
		var itemName = springboard.inspectElementKey(
			UIAQuery.tableCells().atIndex(i).onScreen('CarPlay').children().atIndex(0), 'label');
		// Remove Saved Episodes entry from list
		if (itemName !== 'Saved Episodes') {
			UIALogger.logMessage('%0 added to list'.format(itemName));
			toReturn.push(itemName);
		} else {
			UIALogger.logMessage('Saved Episodes item not added to list');
		}
	}

	return toReturn;
};

/**
 * Returns an array of dictionaries containing episode information with only episodes older than the date passed in
 *
 * @param {Date} date - JS Date object used to compare to the episode date. If an episode is newer than that date it
 * is removed from the list
 * @param episodeArray - Array of dictionaries containing episode information to be checked
 * @returns {Array} - Array that has had the new items removed
 */
podcasts.removeRecentlyDroppedEpisodes = function removeRecentlyDroppedEpisode (date, episodeArray) {
	UIALogger.logMessage('FUNCTION: removeRecentlyDroppedEpisodes with date = %0, episodeArray = %1'.format(date,
																											episodeArray));
	var toReturn = episodeArray.slice();

	// Look for any date that is newer than the permitted date and remove the entry
	for (var i = 0; i < toReturn.length; i++) {
		if (toReturn[i].fullDate > date) {
			UIALogger.logMessage('Removed episode %0 in removeRecentlyDroppedEpisode'.format(toReturn[i].title));
			toReturn.splice(i, 1);
			// Set index back 1 so that all items are checked
			i--;
		} else {
			UIALogger.logMessage('Episode %0 not removed'.format(toReturn[i].title));
		}
	}

	return toReturn;
};

/**
 * Clears the Now Playing queue completely
 *
 * Expected starting state: Mini player visible and tappable
 *
 * @throws if Now Playing cannot be cleared
 */
podcasts.clearNowPlaying = function clearNowPlaying() {
	UIALogger.logMessage('FUNCTION: clearNowPlaying()');

	this.tap(UIAQuery.Podcasts.MINIPLAYER_MINI);
	this.waitUntilPresent(UIAQuery.Podcasts.UPNEXT_BUTTON);
	this.tap(UIAQuery.Podcasts.UPNEXT_BUTTON);
	UIAUtilities.assert(
		this.waitUntilPresent(UIAQuery.Podcasts.UPNEXT),
		'Up Next did not open'
	);

	var count = this.count(UIAQuery.tableCells());
	UIALogger.logMessage('Number of tableCells was %0'.format(count));

	this.tap(UIAQuery.tableCells().atIndex(count - 1));

	// Get info to determine if CarPlay is connected of not
	var carScreen = target.screenWithIdentifier(UIAScreenIdentifier.CAR_PLAY);
	var carScreenHeight;

	// It is possible for the screen to either be undefined or have a height of 0 when not connected, handle those
	// possibilities
	if (typeof(carScreen) != 'undefined') {
		carScreenHeight = carScreen.rect().height;
	} else {
		carScreenHeight = 0;
	}

	var siriWaiter = UIAWaiter.withPredicate(
		'ApplicationStateChanged',
		'bundleID = "com.apple.Siri"'
	);

	this.issueSiriCommand('Play next episode');

	if (carScreenHeight === 0) {
		UIALogger.logMessage('CarPlay screen not connected');

		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.OPEN_PODCASTS),
			'Open Podcasts button did not appear'
		);
		springboard.delay(1);
		springboard.tap(UIAQuery.Podcasts.OPEN_PODCASTS);
	} else {
		UIALogger.logMessage('CarPlay screen connected');

		UIAUtilities.assert(
			siriWaiter.wait(30),
			'Siri view was never dismissed'
		);
	}
	this.getToTab(TABS.LIBRARY);

	this.assertNotExists(
		UIAQuery.Podcasts.MINIPLAYER_MINI,
		'Now Playing is still present'
	);

	UIALogger.logMessage('Now Playing cleared');
};

/**
 * Gets all the data from an episode cell and splits it out in to a dictionary for reference based on the attribute.
 * Puts descriptions split by commas together correctly for reference. This is not a perfect process because several
 * elements shift around but this will do a relatively good job with most podcast episodes. If an episode is causing
 * problems try with a different podcast
 *
 * Expected state: Already be on the page of the episode being referenced
 *
 * @param {string} episode - Title of the episode
 * @param {{}} options - Dictionary of attributes about the episode
 * @param {string} [options.podcast=null] - Optional title of the podcast the episode came from
 * @param {bool} [options.rawDataProvided=false] - Bool indicating if the whole contents of the episode cell was
 * 		provided. If this is the case time is saved because the UI does not need to be queried
 * @returns Dictionary containing the relevant episode data
 *
 * Returned dictionary keys
 * podcast {string} = name of podcast passed in
 * playState {string} = Play state of episode, Unplayed, Played, Partially Played or Now playing
 * explicit {bool} = True if explicit, false otherwise
 * downloaded {bool} = True if downloaded, false if streaming
 * size {string} = Size of episode file
 * type {string} = Audio, Video or Document
 * saved {bool} = True if saved, false otherwise
 * year {string} = Year the episode was posted
 * day {string} = Day episode was released with 3 letter abbreviated month and number (ex: Apr 4)
 * postTime {string} = Time the episode was posted
 * fullDate {Date} = Date object representing the date and time the episode was posted
 * hours {string} = Number of hours in duration of episode, "0 hours" if no hours in duration
 * minutes {string} = Number of minutes in duration of episode, "0 minutes" if no minutes in duration
 * seconds {string} = Number of seconds in duration of episode, "0 seconds" if no seconds in duration
 * duration {string} = Full duration of episode
 * dateText {string} = Date the episode was posted as shown in the UI. May not be present on Unplayed tab. If not
 * 		found, value will be "No date text found"
 * timeRemainingTest {string} = Time remaining as it appears in the label under the episode. May be full duration.
 * 		If not found, value will be "No time remaining text found"
 * description {string} = Description of the episode
 * title {string} = Title of the episode
 */
podcasts.getAllEpisodeData = function getAllEpisodeData (episode, options) {
	options = UIAUtilities.defaults (options, {
		podcast 		: null,
		rawDataProvided : false,
	});
	UIALogger.logMessage('FUNCTION getAllEpisodeData');
	UIALogger.logMessage('This function is imperfect. If you are seeing aberrant behavior try with a different' +
		' episode');
	this.logStartingOptions(options, 'episode was %0'.format(episode));

	var rawData;
	var descStart;
	var descEnd;
	var endOfTitleIndex = -1;
	var timeSplit;

	if (options.rawDataProvided) {
		rawData = episode;
	} else {
		rawData = this.inspectElementKey(UIAQuery.tableCells().contains(episode).rightmost(), 'label');
	}
	var elementDict = {};
	var splitData = rawData.split(', ');

	elementDict.podcast = options.podcast;

	//Get Play State
	elementDict.playState = splitData[0];

	// Find if episode is Explicit
	if (splitData.indexOf('Explicit') != -1) {
		elementDict.explicit = true;
		endOfTitleIndex = splitData.indexOf('Explicit');
	} else {
		elementDict.explicit = false;
	}

	// Get download state which always has "Streaming" as the last data entry. Get size of episode which is always
	// next to streaming or at the very end of the array
	if (splitData[splitData.length-1] === 'Streaming' || splitData[splitData.length-1] === 'Error') {
		elementDict.downloaded = false;
		elementDict.size = splitData[splitData.length-2];
	} else {
		elementDict.downloaded = true;
		elementDict.size = splitData[splitData.length-1];
	}

	// Catches and corrects issues for episodes that are documents
	if (splitData[splitData.length-1] === 'Document') {
		elementDict.type = 'Document';
		elementDict.size = splitData[splitData.length-2];
		descEnd = splitData.length - 2;
		elementDict.downloaded = false;
	}

	// Get saved state
	elementDict.saved = splitData.indexOf('Saved') !== -1;

	// Get date and time of episode
	// Find the year by looking for the first instance of a number and set other values accordingly
	var postTimeIndex = null;
	for (var i = 3; i < splitData.length; i++) {
		if (!isNaN(splitData[i])) {
			elementDict.year = splitData[i];
			elementDict.day = splitData[i-1];
			elementDict.postTime = splitData[i+1];
			// Setting postTimeIndex
			postTimeIndex = i + 1;
			// Set endOfTitleIndex if it hasn't been set already by Explicit
			if (endOfTitleIndex === -1) {
				endOfTitleIndex = i - 1;
			}
			break;
		}
	}
	elementDict.fullDate = new Date ('%0 %1 %2'.format(elementDict.day, elementDict.year, elementDict.postTime));

	// Get the hours, minutes and seconds which follow after the postTime but may not all be there. None of the
	// items have to be listed for a podcast. Also sets the starting point of the description. Splitting values at
	// indexes prevent descriptions that contain the words hour second or minute from being added as a time
	elementDict.hours = '0 hours';
	elementDict.minutes = '0 minutes';
	elementDict.seconds = '0 seconds';
	for (var j = postTimeIndex + 1; j < postTimeIndex + 4; j++){
		if (splitData[j].indexOf('hour') !== -1) {
			timeSplit = splitData[j].split(' ');
			if (timeSplit.length === 2 && timeSplit[1].slice(0,4) === 'hour') {
				elementDict.hours = splitData[j];
				descStart = j + 1;
			}
		} else if (splitData[j].indexOf('minute') !== -1) {
			timeSplit = splitData[j].split(' ');
			if (timeSplit.length === 2 && timeSplit[1].slice(0,6) === 'minute') {
				elementDict.minutes = splitData[j];
				descStart = j + 1;
			}
		} else if (splitData[j].indexOf('second') !== -1) {
			timeSplit = splitData[j].split(' ');
			if (timeSplit.length === 2 && timeSplit[1].slice(0,6) === 'second') {
				elementDict.seconds = splitData[j];
				descStart = j + 1;
			}
		}
	}
	elementDict.duration = '%0 %1 %2'.format(elementDict.hours, elementDict.minutes, elementDict.seconds);

	// Determine day and time (possibly time remaining) displayed in episode cell. Use second item in splitData to
	// search on. Perform catch to work around <rdar://problem/26016007> Automation: "UIA2_PodcastsQA_Quick Look My
	// Podcasts" failed with "Uncaught exception in Quick Look My Podcasts: 'undefined is not an object (evaluating
	// 'this.inspect(UIAQuery.tableCells().contains(splitData"
	try {
		// Unplayed tab may not have a day showing, need to search less precisely on the Unplayed tab. In all other
		// instances, look for the label that includes a bullet
		var dateAndDurationText = null;
		if (this.currentUIState() === UIStateDescription.Podcasts.UNPLAYED) {
			UIALogger.logMessage(
				'axtree for query on unplayed was:\n%0'.format(axtree(UIAQuery.tableCells().contains(splitData[1])))
			);
			var query;
			// If a label with a bullet exists, use that label. Otherwise use the UILabel under the item
			if (this.exists(UIAQuery.tableCells().contains(splitData[1]).children().contains('\u2022'))) {
				UIALogger.logMessage('A child with a bullet exists');
				query = UIAQuery.tableCells().contains(splitData[1]).children().contains('\u2022');
			} else {
				query = UIAQuery.tableCells().contains(splitData[1]).children().andThen(UIAQuery.query('UILabel'));
			}
			dateAndDurationText = this.inspectElementKey(query, 'label');
		} else {
			dateAndDurationText = this.inspectElementKey(
				UIAQuery.tableCells().contains(splitData[1]).children().contains('\u2022'), 'label');
		}

		UIALogger.logMessage('dateAndDurationText was %0'.format(dateAndDurationText));

		// Split on the bullet if it exists to get day and time remaining. Otherwise indicate date is not listed
		if (dateAndDurationText.indexOf('\u2022') !== -1) {
			var splitDateAndDuration = dateAndDurationText.split(' \u2022 ');
			UIALogger.logMessage('Bullet found in dateAndDurationText');
			elementDict.dateText = splitDateAndDuration[0];
			elementDict.timeRemainingText = splitDateAndDuration[1];
		} else {
			UIALogger.logMessage('No bullet and no date found in dateAndDurationText');
			elementDict.dateText = 'No date text found';
			elementDict.timeRemainingText = dateAndDurationText;
		}

		// If there is a time remaining then there are extra entries in the main tableCell with the time remaining
		// information. descStart needs to be increased by 1 for each item that is there. Only runs if timeRemainingText
		// indicates there is actually time remaining. Keeps increasing descStart by 1 until the item at the index
		// before includes the word 'remaining'
		if (elementDict.timeRemainingText.indexOf('remaining') !== -1 || elementDict.playState === 'Now playing') {
			UIALogger.logMessage('timeRemainingText indicated that episode was partially played');
			while (splitData[descStart - 1].indexOf('remaining') === -1) {
				UIALogger.logMessage('descStart incremented by 1');
				descStart++;
			}
		}

	} catch (err) {
		UIALogger.logError ('No sub text indicating date and time remaining. Error was %0'.format(err));
		elementDict.dateText = 'No date text found';
		elementDict.timeRemainingText = 'No time remaining text found';

		// Increment descStart if hour, minute or second is found at the index. Not very reliable but only way to do
		// it if there is no label to show that there is a time remaining
		if (splitData[descStart].indexOf('hour') !== -1) {
			UIALogger.logMessage('Word "hour" found at %0'.format(descStart));
			descStart++;
		}
		if (splitData[descStart].indexOf('minute') !== -1) {
			UIALogger.logMessage('Word "minute" found at %0'.format(descStart));
			descStart++;
		}
		if (splitData[descStart].indexOf('second') !== -1) {
			UIALogger.logMessage('Word "second" found at %0'.format(descStart));
			descStart++;
		}
	}

	// Find the type of episode
	if (splitData.indexOf('Audio') !== -1) {
		elementDict.type = 'Audio';
	} else if (splitData.indexOf('Video') !== -1) {
		elementDict.type = 'Video';
	}
	// For audio and video episodes, the description always ends 1 index before the Audio or Video index
	if (elementDict.type !== 'Document') {
		descEnd = splitData.indexOf(elementDict.type);
	}

	// Join together the full description
	UIALogger.logMessage('descStart = %0, descEnd = %1'.format(descStart, descEnd));
	elementDict.description = splitData.slice(descStart, descEnd).join(', ');

	// Find the title which also may include the provider
	elementDict.title = splitData.slice(1, endOfTitleIndex).join(', ');

	// Log the output of elementDict
	var keys = Object.keys(elementDict);
	var dictLogging = [];
	for (var m = 0; m < keys.length; m++) {
		dictLogging[m] = '%0 : %1'.format(keys[m], elementDict[keys[m]]);
		UIALogger.logMessage(dictLogging[m]);
	}
	UIALogger.logMessage('elementDict was:\n%0'.format(dictLogging.join('\n')));

	return elementDict;
};


/**
 * Generate a list of all podcast episodes in containers in My Podcasts on the device
 *
 * Expected starting state: Top level of My Podcasts
 *
 * @param {object} options - Options dictionary
 * @param {boolean} [options.feed=false] - If true, it will get all episode data from episodes in the feed
 * @param {boolean} [options.saved=false] - If true, it will get all saved episode data
 *
 * @returns {Array} - Returns an array of objects with episode data generated by getAllEpisodeData
 * @throws if true passed in for both options.feed and options.saved
 */
podcasts.getAllEpisodeDataFromAllContainers = function getAllEpisodeDataFromAllContainers(options) {
	options = UIAUtilities.defaults(options, {
		feed  : false,
		saved : false,
	});

	UIALogger.logMessage('FUNCTION: getAllEpisodeDataFromAllContainers');
	this.logStartingOptions(options);

	// Catches if both fromFeed and fromSaved are both true and throws error if that is the case
	UIAUtilities.assert(
			!options.feed || !options.saved,
			'fromFeed and fromSaved cannot both be true');

	// Get list of all items in My Podcasts
	var allMyPodcasts = this.generateShowsList({needToNav:false, includeStations:false});
	// Used to skip to the next podcast if no saved tab exists
	var toContinue = true;
	var episodeDataToReturn = [];

	for (var i = 0; i < allMyPodcasts.length; i++) {
		//Determines if item is a podcast
		if (this.exists(UIAQuery.tableCells().contains(allMyPodcasts[i]).contains('unplayed episode'))) {

			this.drillIntoPodcastContainer(allMyPodcasts[i]);

			// Sets segmented control to Feed or Saved depending on options. Also logs if Saved does not exist
			if (options.feed) {
				this.setControl(UIAQuery.segmentedControls(), 'Feed');
			} else if (options.saved) {
				if (!this.exists(UIAQuery.segmentedControls().children('Saved'))) {
					UIALogger.logMessage('No saved episodes in %0'.format(allMyPodcasts[i]));
					toContinue = false;
				}
			}

			if (toContinue) {
				var currentList = this.generateEpisodeList({podcastTitle : allMyPodcasts[i],
															getCleanedTitle:false});

				for (var j = 0; j < currentList.length; j++) {
					episodeDataToReturn.push(this.getAllEpisodeData(currentList[j], {podcast:allMyPodcasts[i],
																					 rawDataProvided:true}));
				}
			}
			if (!this.tapIfExists(UIAQuery.Podcasts.LIBRARY_TAB)) {
				UIALogger.logMessage('My Podcasts did not exist and was not tapped');
			}
		} else {
			UIALogger.logMessage('%0 does not appear to be a podcast'.format(allMyPodcasts[i]));
		}
	}

	return episodeDataToReturn;
};


/**
 * Takes in an array of raw episode cell information and returns an array of dictionaries with the information parsed
 *
 * @param {string[]} data - String array of episode data to be parsed
 * @param {string} podcast - String representing where the episodes came from. Does not have to be podcast title.
 * 		Could be 'Unplayed' or 'Station' for example
 *
 * @returns {Array} of dictionaries with parsed episode data
 */
podcasts.getAllEpisodeDataFromRawValues = function getAllEpisodeDataFromRawValues(data, podcast) {
	UIALogger.logMessage('FUNCTION: getAllEpisodeDataFromRawValues with data = %0 and podcast = %1'.format(data,podcast));
	var toReturn = [];

	for (var i = 0; i < data.length; i++) {
		toReturn.push(this.getAllEpisodeData(data[i], {podcast:podcast, rawDataProvided:true}));
	}

	return toReturn;
};

/**
 * Sorts an array of dictionaries with episode data from getAllEpisodeData by date in reverse chronological order,
 * i.e. the most recent episode at the top
 *
 * @param {Array} episodes - Array of episode data generated by getAllEpisodeData to be sorted
 *
 * @returns {Array} - Sorted array
 */
podcasts.sortEpisodesByDate = function sortEpisodesByDate(episodes) {
	UIALogger.logMessage('FUNCTION: sortEpisodesByDate');

	var toChange = episodes.slice(0);
	var toReturn = [];

	while (toChange.length > 0) {
		UIALogger.logMessage('toChange length was %0'.format(toChange.length));
		var greatest = 0;
		for (var i = 1; i < toChange.length; i++) {
			if (toChange[greatest].fullDate < toChange[i].fullDate) {
				greatest = i;
			}
		}
		UIALogger.logMessage('greatest was %0'.format(greatest));
		UIALogger.logMessage('%0 with date: %1 added to sorted list'.format(toChange[greatest].title,
																			toChange[greatest].fullDate));
		toReturn.push(toChange[greatest]);
		// Can't do all in one because data does not all get added to toReturn
		toChange.splice(greatest, 1);
	}

	return toReturn;
};

/**
 * Gets the settings for every podcast on the device
 *
 * @returns {Object} - Array containing dictionaries with all the podcast's settings. Podcast name is list under the
 * 		key "podcast" for each index
 */
podcasts.getAllPodcastSettings = function getAllPodcastSettings() {
	UIALogger.logMessage('FUNCTION: getAllPodcastSettings');

	var podcastList = this.generateShowsList();
	var podcastSettings = [];
	for (var k = 0; k < podcastList.length; k++) {
		// Work around <rdar://problem/23882904> [Eagle] 13182 - Elements Beneath Mini-Player Reporting isVisible
		// to AX When Visibility is Obscured to User
		if (!iPad) {
			this.swipeUp(UIAQuery.query('UITableView'));
		}
		if (this.exists(UIAQuery.tableCells().contains(podcastList[k]).contains('unplayed episode'))) {
			var tempSet = this.getPodcastSettings(podcastList[k]);
			tempSet['podcast'] = podcastList[k];
			podcastSettings.push(tempSet);
		}
	}

	return podcastSettings;
};


/**
 * Splits the title of an episode on ', ' and returns the string stored at array [1]
 *
 * Expected starting state: Any
 * @param {string} toSplit - String with the full episode title needing to be cleaned
 *
 * @returns {string} - Cleaned title of episode
 */
podcasts.getCleanedEpisodeTitle = function getCleanedEpisodeTitle(toSplit) {
	UIALogger.logMessage('FUNCTION: getCleanedEpisodeTitle');
	UIALogger.logMessage('toSplit was %0'.format(toSplit));

	var splitArray = toSplit.split(', ');

	return splitArray[2];
};

/**
 * Take in the Whitetail AX label from a podcast container and returns a dictionary containing the title, date and
 * 		unplayedCount using those names as the keys. Catches if title has commas in the title and includes it in the
 * 		title
 *
 * @param toSplit - Label returned from AX for the podcast container
 *
 * @returns {{}} - Dictionary containing the title, date and unplayedCount
 */
podcasts.getPodcastContainerData = function getCleanedPodcastTitle(toSplit) {
	UIALogger.logMessage('FUNCTION: getPodcastContainerData');
	UIALogger.logMessage('toSplit was %0'.format(toSplit));

	var splitArray = toSplit.split(', ');
	var toReturn = {};

	// Set the title to be the first index of split array
	var podcastTitle = splitArray[0];

	// Catch if the title included commas and add the missing item back on to the title to be returned
	if (splitArray.length > 3) {
		var extras = splitArray.length - 3;

		for (var i = 1; i < extras; i++) {
			podcastTitle = '%0, %1'.format(podcastTitle, splitArray[i]);
		}
	}

	toReturn.title = podcastTitle;
	toReturn.date = splitArray[splitArray.length - 2];
	toReturn.unplayedCount = splitArray[splitArray.length - 1];

	return toReturn;
};



/**
 * Logs in to the specified service. Argument for service can be iCloud, Messages, Store, Facebook or Twitter.
 * Leaves user on the main page of settings at the end
 *
 * Starting state: Any
 *
 * @param {string} service - Service to log in to
 * @param {string} username - Username to log in with
 * @param {string} password - Password to log in with
 * @param {{}} options - options dictionary
 * @param {bool} [options.passIfAlreadyLoggedIn=true] - If false, test will fail if the account is already logged in
 *
 * @throws if it fails to log in to a service
 * @returns none
 */
podcasts.loginToService = function loginToService (service, username, password, options) {
	UIALogger.logMessage('FUNCTION: loginToService');
	UIALogger.logMessage('Attempting to log in to %0'.format(service));
	options = UIAUtilities.defaults(options, {
		passIfAlreadyLoggedIn : true
	});

	try {
		this.deactivate();
	} catch (err) {
		UIALogger.logError('Failed to deactivate podcasts ERROR: %0'.format(err.message));
	}

	try {
		if(settings.isActive()) {
			UIALogger.logMessage('Attempting to quit settings');
			settings.quit();
		}
	} catch (err) {
		UIALogger.logError('Failed to quit Settings with error %0'.format(err.message));
	}

	UIALogger.logMessage('Attempting to launch Settings');
	settings.launch({timeout:60});

	// Converts services passed in to corresponding settings menus
	if (service === 'iCloud') {
		UIALogger.logMessage('Converting iCloud to Mail');
		service = 'Mail';
	} else if (service === 'Store') {
		UIALogger.logMessage('Converting Store to iTunes & App Store');
		service = 'iTunes & App Store';
	}

	// Get to top of settings on an iPhone
	if (!iPad) {
		UIALogger.logMessage('Getting to the top level of settings');
		while (settings.exists('back-nav-button')) {
			var settingsWaiter = UIAWaiter.waiter('ViewDidAppear');
			settings.tap('back-nav-button');
			if (!settingsWaiter.wait()) {
				throw new UIAError ('Could not navigate to top level of settings');
			}
		}
	}
	// Confirms top level of Settings before continuing
	settings.assertExists(UIAQuery.navigationBars('Settings'), 'Not at top of Settings');
	settings.assertExists(service, 'No option %0 found. Pass only these strings as an option. Messages, iCloud,' +
		' Store, Facebook, Twitter'.format(service));

	settings.tap(service);

	switch (service) {
		case 'Twitter':
			if (settings.exists(UIAQuery.contains('Update Contacts'))) {
				UIALogger.logMessage('Twitter already logged in');
				break;
			}

			settings.tap('User Name');
			settings.typeString(username);
			settings.tap('Password');
			settings.typeString(password);

			// Handle alert to install Twitter
			settings.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.contains('Install Twitter')), function () {
				settings.tap('Sign In');
				settings.waitUntilPresent('Later', 10);
				settings.tap('Later');
			});
			break;

		case 'Facebook':
			if (settings.exists(UIAQuery.contains('Update All Contacts'))) {
				UIALogger.logMessage('Facebook already logged in');
				break;
			}

			settings.tap('User Name');
			settings.typeString(username);
			settings.tap('Password');
			settings.typeString(password);

			// Handle extra Facebook sign in page
			var fbWaiter = UIAWaiter.withPredicate(
				'ViewDidAppear',
				'controllerClass = "SLFacebookLoginInfoViewController"'
			);
			settings.tap('Sign In');
			if (!fbWaiter.wait()) {
				throw new UIAError('Failed to get to the Facebook sign in confirmation window');
			}

			// Handle alert to install Facebook
			settings.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.contains('Install Facebook')), function () {
				settings.tap('right-nav-button');
				settings.waitUntilPresent('Later', 10);
				settings.tap('Later');
			});
			break;

		case 'Messages':
			UIAUtilities.safeCleanup({
                test: function () {settings.signInToiMessage(username, password, options.passIfAlreadyLoggedIn);},
				cleanup: function () {podcasts.signOutOfStoreWithAsclient();}
			});
			break;

		case 'iTunes & App Store':
			settings.signInToiTunes(username, password);
			break;

		case 'Mail':
			UIAUtilities.safeCleanup({
                test: function () {
                    settings.signInToiCloud(username, password, options.passIfAlreadyLoggedIn);
                    settings.tap('iCloud');
                    settings.setSyncOptions({password: password, setFindMy: false});
                },
                cleanup: function() {podcasts.signOutOfStoreWithAsclient();}
            });
			break;
	}
	var picName = 'After_Login_To_%0.png'.format(service).trim().replace(/ /g, '_');
	this.takeScreenShot(UIAScreenIdentifier.MAIN, picName);

	settings.tapIfExists('back-nav-button');

	UIALogger.logMessage('Successfully logged in to %0'.format(service));
};


/**
 * Logs the arguments passed in to a function
 *
 * @param {object} argumentsDict - Dictionary of optional arguments passed in to function
 * @param {string} logString - String passed in containing the required arguments of a function and
 * 		their values
 */
podcasts.logStartingOptions = function logStartingOptions (argumentsDict, logString) {

	UIALogger.logMessage('LOG: logStartingOptions');
	if (logString !== undefined) {
		logString += ', ';
	} else {
		logString = '';
	}

	var keys = Object.keys(argumentsDict);
	var optionalString = '';
	for (var i = 0; i < keys.length; i++) {
		optionalString += '%1 was %2'.format(logString, keys[i], argumentsDict[keys[i]]);
		if (i < keys.length-1) {
			optionalString += ', ';
		}
	}

	UIALogger.logDebug(logString + optionalString);
};


podcasts.signOutOfStoreWithAsclient = function signOutOfStoreWithAsclient() {
    var logOut = target.performTask('/usr/local/bin/asclient', ['signOut']);
    UIAUtilities.assertEqual(
        logOut.exitCode,
        0,
        'Log out from store failed, stderr = %0, stdout = %1'.format(logOut.stderr, logOut.stdout)
    );
};


/**
 * Takes a screenshot and saves it with the specified name
 *
 * @param screen - Screen to take screenshot of, either UIAScreenIdentifer.MAIN or UIAScreenIdentifier.CAR_PLAY
 * @param {string} name - name to give the file
 * @param options - options dictionary
 * @param {string} [options.filePath] - Base file path to save the screenshot that does not include the file name.
 * 		Defaults to /var/mobile/Library/Logs/Testing/
 */
podcasts.takeScreenShot = function takeScreenShot(screen, name, options) {
	options = UIAUtilities.defaults(options, {
		filePath : SCREENSHOT_DIRECTORY_FILE_PATH
	});
	UIALogger.logMessage('FUNCTION: takeScreenShot');
	this.logStartingOptions(options, 'screen = "%0" and name = "%1"'.format(screen, name));

	// Trim filePath
	options.filePath = options.filePath.trim();

	// Trim name and replace spaces with _
	name = name.trim().replace(/ /g, '_');

	// Add forward slash if needed
	if (options.filePath[options.filePath.length - 1] != '/') {
		options.filePath = options.filePath + '/';
	}
	// Create directory if it doesn't exist
	UIAFileManagement.makeDirectory(options.filePath);
	var fullFilePath = UIAFileManagement.makeSafePath('%0%1'.format(options.filePath, name));

	try {
		var screenObject = target.screenWithIdentifier(screen);
		screenObject.saveScreenshotToFile(fullFilePath);
	} catch (e) {
		UIALogger.logError(e);
	}
};


/**
 * Verifies two dictionaries have matching values for the keys passed in
 *
 * @param {{}} data1 - 1st dictionary to compare
 * @param {{}} data2 - 2nd dictionary to compare
 * @param {string[]} keys - String array of keys to verify match between the 2 dictionaries
 *
 * @throws if values for each key do not match
 */
podcasts.verifyEpisodeDataMatches = function verifyEpisodeDataMatches (data1, data2, keys) {
	UIALogger.logMessage('FUNCTION verifyEpisodeDataMatches');
	UIALogger.logMessage('data1 length = %0 data2 length = %1'.format(data1.length, data2.length));
	UIALogger.logMessage('Verifying %0'.format(data1.podcast));
	// Logs the most recent data1 and data2, in the case of a failure this will be the items being operated on when
	// the failure took place
	UIALogger.logTAResults({data1Values:data1, data2Values:data2});

	// Loop through each dictionary in the data sets and verify keys match
	for (var i = 0; i < data1.length; i++) {
		for (var k = 0; k < keys.length; k++) {
			UIALogger.logMessage('i = %0 and k = %1'.format(i, k));
			UIALogger.logMessage('Verifying "%0" of episode "%1"'.format(keys[k], data1[i].title));
			UIAUtilities.assertEqual (
				data1[i][keys[k]],
				data2[i][keys[k]],
				'Values for key %0 do not match in data1 and data2'.format(keys[k])
			);
			UIALogger.logMessage('Verified "%0" of episode "%1"'.format(keys[k], data1[i].title));
		}
	}
};


/**
 * Verifies all downloads are completed by making sure there is no download tab or bar for 15 seconds. If calling
 * this as part of actual download test an assert should be used to throw an error and the download state of the
 * episode should be separately verified
 *
 * @param {number} [minutes=2] - Number of minutes to wait
 *
 * @returns bool true if downloads completed false otherwise
 */
podcasts.waitForDownloadsToComplete = function waitForDownloadsToComplete(minutes) {
	if(minutes == null) {
		minutes = 2;
	}

	UIALogger.logMessage('FUNCTION: waitForDownloadsToComplete with minutes = %0'.format(minutes));

	// Nav to top of Library if not there already
	if (!this.exists(UIAQuery.query("PodcastsUI.DynamicTypeLabel").andThen("Shows"))) {
		this.getToTab("Library");	
	}
	// See if Downloading cell is there
	if (this.waitUntilPresent("Downloading", 30)) {
		UIALogger.logMessage('Downloading cell found.  Waiting for it to go away...');
		if (this.waitUntilAbsent("Downloading", minutes * 60)) {
			// Downloads complete
			UIALogger.logMessage('DOWNLOADS COMPLETED.');
			// return true;
		} else {
			UIALogger.logWarning('••WARN: Downloads did not complete');
			return false;
		}
		
	} else {
		UIALogger.logWarning('Downloading cell never appeared.');
		return true;
	}
	
};

/**
 * Waits for playback to start using the global WAIT_TIME as a default if nothing is passed in
 *
 * @param {Object} options - options dictionary
 * @param {number} timeout - number of seconds to wait before failing
 * @param {string} [options.errorMessage=""] - Error message to append to the standard error message if the test fails
 *
 * @returns none
 * @throws if playback does not begin after timeout
 */
podcasts.waitForPlayback = function waitForPlayback(timeout, options) {
	options = UIAUtilities.defaults(options, {
		errorMessage : ''
	});
	if (timeout === null) {
		timeout = WAIT_TIME;
	}
	var timer = 0;
	UIALogger.logMessage('FUNCTION: waitForPlayback called with %0 second timeout'.format(timeout));

	while (!CAMMediaRemote.isMediaPlaying() && timer < timeout) {
		UIALogger.logMessage('Playback has not started after %0 seconds'.format(timer));
		this.delay(1);
		timer++;
	}
	UIAUtilities.assert(
		CAMMediaRemote.isMediaPlaying(),
		'Playback failed to start after %0 seconds. %1'.format(timeout, options.errorMessage).trim()
	);
	UIALogger.logMessage('Playback started after %0 seconds'.format(timer));
};

