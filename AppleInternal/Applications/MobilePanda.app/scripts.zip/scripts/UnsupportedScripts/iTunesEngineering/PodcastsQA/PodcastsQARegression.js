load('PodcastsQA.js');

/*jshint strict:false, unused:true, eqnull:true, sub:true, -W008 */

/* REGRESSION TESTS */

/**
 * Runs a long play regression test and sets up for said test
 *
 * @param {Object} options - options dictionary
 * @param {num} [options.length] - Length in hours test should run
 * @param {num} [options.waitTime] - Lenght of time in minutes to wait for downloads to complete, if -1, will multiple
 * 		options.length by 15 to determine time to wait for downloads to complete
 * @param {string[]} [options.podcastTitles] - Titles of podcasts in order they should be used. Test will use all
 * 		episodes from the first one, then the second, then the 3rd and so on until it has enough episodes to run the
 * 		full length of time
 * @param {string[]} [options.podcastURLs] - URLs index matched to the titles in podcastTitles
 * @param {bool} [options.screenLocks] - If true, screen is locked before testing proceeds
 * @param {bool} [options.podcastsBackgrounded] - If true, Podcasts is backgrounded before testing proceeds
 * @param {bool} [options.downloaded] - If true, all episodes are downloaded before testing proceeds and if they are
 * 		not, it fails
 * @param {bool} [options.setUpOnly] - If true, only the set up portion of the test will be run
 * @param {bool} [options.testOnly] - If true, set up steps are not run
 *
 * @throws If downloads do not complete or if Podcasts stops playback in the middle of testing
 */
podcasts.longPlayRegressionTest = function longPlayRegressionTest(options) {
	options = UIAUtilities.defaults(options, {
		length               : 8,
		waitTime             : -1,
		podcastTitles        : ['Serial', 'This American Life', "Dan Carlin's Hardcore History"],
		podcastURLs          : [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life, PODCAST_URLS.Dan_Carlin],
		screenLocked         : false,
		podcastsBackgrounded : false,
		downloaded           : true,
		setUpOnly            : false,
		testOnly             : false,
	});
	UIALogger.logMessage('FUNCTION: longPlayRegressionTest');
	this.logStartingOptions(options);
	this.quitOrKillApp();
	this.launch();

	var testTimeInSec = options.length * 60 * 60;

	// Run setup if it is not only meant to run test
	if (!options.testOnly) {
		var totalEpisodeTime = 0;
		var addPodcast = true;
		var subscribeIndex = 0;
		var episodeIndex = 0;
		var toMark = [];
		var episodeCount = 0;
		var currentPodcast = '';

		// Mark episodes as unplayed until total run time is equal to total test length plus 20 minutes
		while (totalEpisodeTime < testTimeInSec + 1200) {
			// If a podcast needs to be added then subscribe to a new podcast
			if (addPodcast) {
				UIALogger.logMessage('Adding Podcast');
				// Mark any episodes that need to be marked as unplayed as unplayed before adding a new podcast
				if (toMark.length > 0) {
					this.setEpisodePlayState('Unplayed', toMark, {isInFeed:true});
				}

				this.getToTab(TABS.MY_PODCASTS);
				this.subscribeViaPlusSignToURL(options.podcastURLs[subscribeIndex],
											   options.podcastTitles[subscribeIndex],
											   {verify:false, needToNav:false}
				);
				// Navigate in to the podcast container to the feed tab
				this.tap(UIAQuery.tableCells().contains(options.podcastTitles[subscribeIndex]));
				this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);

				// Get total number of episodes in the feed
				episodeCount = this.count(
					UIAQuery.images().contains(options.podcastTitles[subscribeIndex]).siblings().andThen(
						UIAQuery.tableCells())
				);
				UIALogger.logMessage('Count of episodes was %0'.format(episodeCount));

				currentPodcast = options.podcastTitles[subscribeIndex];

				// Increment subscribeIndex to use next podcast in list if needed
				subscribeIndex++;

				toMark = [];
				addPodcast = false;
				episodeIndex = 0;
			}

			// Get title of episode at episode index
			var episodeInfo = this.getAllEpisodeData(
				this.inspectElementKey(UIAQuery.images().contains(currentPodcast).siblings().andThen(
					UIAQuery.tableCells().atIndex(episodeIndex)), 'label'),
				{podcast:currentPodcast, rawDataProvided:true}
			);
			var durationSecs = this.convertTimeRemaining(episodeInfo.timeRemainingText);

			// Update totalEpisodeTime
			totalEpisodeTime += durationSecs;
			UIALogger.logMessage('totalEpisodeTime = %0'.format(totalEpisodeTime));

			// Add episode to array of episodes to be marked
			if (episodeInfo.playState !== 'Unplayed') {
				UIALogger.logMessage('Episode "%0" added to toMark'.format(episodeInfo.title));
				toMark.push(episodeInfo.title);
			}

			// Increment episode index
			episodeIndex++;

			//Catch if no episodes are left and indicate a new podcast is needed
			if (episodeIndex === episodeCount) {
				UIALogger.logMessage('Out of episodes in feed, need to add a new podcast');
				addPodcast = true;
			}
		}
		// Mark last podcast to be added's episodes as Unplayed
		if (toMark.length > 0) {
			UIALogger.logMessage('toMark length = %0'.format(toMark.length));
			this.setEpisodePlayState('Unplayed', toMark, {isInFeed: true});
		} else {
			UIALogger.logMessage('Length of toMark was 0');
		}

		this.getToTab(TABS.MY_PODCASTS);

		if (options.downloaded) {
			// Create a station to easily download all episodes
			this.createStation('Playback Test', {
				useDefaultSettings:false,
				groupByPodcast:true,
				episodesToInclude:'All Episodes',
				includeAll:true
			});
			// Drill in to station
			this.tap(UIAQuery.query('Playback Test'));
			this.waitUntilPresent(UIAQuery.buttons('Download All').isEnabled());

			this.tap(UIAQuery.buttons('Download All'));

			// Get back to My Podcasts top level
			if (!iPad) {
				this.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);
			}

			// Wait for downloads for length of test times 15 or the specified waitTime. All times in minutes
			if (options.waitTime === -1)
				options.waitTime = options.length * 15;

			this.withAlertHandler(DOWNLOAD_ERROR_HANDLER, function() {
				try {
                    UIAUtilities.assert(this.waitForDownloadsToComplete(options.waitTime),
                        'Downloads did not complete after %0 minutes'.format(options.waitTime)
                    );
                } catch (e) {
                    UIALogger.logError(e.message);
                    try {
						if (this.exists(UIAQuery.Podcasts.DOWNLOADS_TAB) || this.exists(UIAQuery.Podcasts.PHONE_DOWNLOAD_BAR)) {
                            if (iPad)
                                this.tap(UIAQuery.Podcasts.DOWNLOADS_TAB);
                            else
                                this.tap(UIAQuery.Podcasts.PHONE_DOWNLOAD_BAR);

                            this.takeScreenShot(UIAScreenIdentifier.MAIN, 'Downloads_Page.png');
                        } else
                            UIALogger.logMessage('Downloads page not present');
                    } catch (shotError) {
                    	UIALogger.logError(shotError.message);
					}

					throw (e);
				}
			});

			// Verify episodes are downloaded
			this.getToTab(TABS.UNPLAYED);
			var episodeList = this.generateEpisodeList();
			for (var e = 0; e < episodeList.length; e++) {
				var info = this.getAllEpisodeData(episodeList[e]);
				UIAUtilities.assertEqual(
					true,
					info.downloaded,
					'Episode "%0" not downloaded'.format(info.title)
				);
			}
			// Once downloads are complete, turn on Airplane Mode to remove any possible interference but do not
			// fail test if turning on Airplane Mode fails
			try {
				settings.changeSingleSwitch(['Airplane Mode'], 'Airplane Mode', 1);
			} catch (err){
				UIALogger.logError('Failed to enable Airplane Mode. ERROR: %0'.format(err.message));
			}
		}
	}

	if (!options.setUpOnly) {
		// Start playback from Unplayed tab by tapping on tableCell at index 2
		this.getToTab(TABS.UNPLAYED);
		this.tap(UIAQuery.tableCells().atIndex(2));
		this.waitForPlayback(15);

		// Lower volume by pressing button 6 times
		for (var i = 0; i < 6; i++) {
			target.clickVolumeDown();
		}

		if (options.podcastsBackgrounded) {
			UIALogger.logMessage('Backgrounding podcasts');
			target.clickMenu();
		}
		if (options.screenLocked) {
			UIALogger.logMessage('Locking screen');
			taget.clickLock();
		}

		var currentTime = new Date();
		UIALogger.logMessage('currentTime = %0'.format(currentTime));
		var testEndDate = new Date();
		testEndDate = testEndDate.setSeconds(testEndDate.getSeconds() + testTimeInSec);
		UIALogger.logMessage('testEndDate was %0'.format(new Date(testEndDate)));

		var lastPlaying = CAMMediaRemote.getNowPlayingTitle();

		// Loop running waitForPlayback with 3 second wait time for full length of test
		while (currentTime < testEndDate) {
			// Verify Podcasts is still running
			UIAUtilities.assertNotEqual(
				this.stateDescription(),
				'Terminated',
				'Podcasts was terminated during long play test'
			);

			var currentlyPlaying = CAMMediaRemote.getNowPlayingTitle();
			if (currentlyPlaying !== lastPlaying) {
				UIALogger.logMessage('%0 replace %1 in Now Playing'.format(currentlyPlaying, lastPlaying));
				lastPlaying = currentlyPlaying;
			}

			UIALogger.logMessage('"%0" is in Now Playing, verifying playback'.format(currentlyPlaying));
			var queueCount = CAMMediaRemote.getNowPlayingTotalQueueCount();
			if (queueCount === 1) {
				UIALogger.logMessage('There is 1 item in queue');
			} else {
				UIALogger.logMessage('There are %0 items in queue'.format(queueCount));
			}
			UIALogger.logMessage('Time remaining on episode before playback is verified was %0 seconds'.format(
				CAMMediaRemote.getNowPlayingDuration() - CAMMediaRemote.getNowPlayingElapsedTime()
			));
			this.waitForPlayback(3);
			UIALogger.logMessage('"%0" is playing'.format(CAMMediaRemote.getNowPlayingTitle()));
			UIALogger.logMessage('Time remaining on episode before waiting 30 seconds was %0 seconds'.format(
				CAMMediaRemote.getNowPlayingDuration() - CAMMediaRemote.getNowPlayingElapsedTime()
			));
			this.delay(30);
			currentTime = new Date();
			UIALogger.logMessage('currentTime was %0'.format(currentTime));
		}

		UIALogger.logMessage('Stopping playback by quitting Podcasts');
		this.quitOrKillApp({errorDetail:'Failed to quit at the end of Long Play test'});
	}
};


/**
 * Sets up a test to launch after logging in to an iCloud account. Then verifies My Podcasts and Unplayed depending
 * on arguments passed in
 *
 * @param {Object} options - options dictionary
 * @param {string} [options.test="Setup"] - Portion of the test to run. Can be Setup, Launch, My Podcasts or Unplayed
 * @param {string[]} [options.expectedMyPodcasts=["This","OS X","Launch 1","Myths and Legends","Criminal","NPR Politics Podcast",
 * 		"The Way I Heard It with Mike Rowe","Anna Faris Is Unqualified",
 * 		"Comedy Central Stand-Up","Grammar Girl Quick and Dirty Tips for Better Writing",
 * 		"CLIMAX!","Look Like a Local:  Travelers Not Tourists","The Dirtbag Diaries",
 * 		"Trends Like These","Mystery Show","Hello Internet","TEDTalks (video)",
 * 		"Accidental Tech Podcast","Serial","This American Life",
 * 		"Common Sense with Dan Carlin","Dan Carlin's Hardcore History",
 * 		"WTF with Marc Maron Podcast","The Adam and Dr. Drew Show","The Bugle",
 * 		"TEDTalks Business","The Joe Rogan Experience","The Nerdist"]] - Array of stations and My Podcasts in order as
 *  		they should appear in My Podcasts on the device
 * @param {string} [options.appleID="ottoiqlaunchtest1@icloud.com"] - Store account to use for test
 * @param {string} [options.appleIDPassword="podIQ6616"] - Password for the store account
 * @param {bool} [options.screenLocked=false] - If true, test will lock screen after launch
 * @param {number} [options.waitTime=10] - Time in minutes to wait for database to update
 * @param {bool} [options.background=true] - When true, Podcasts is backgrounded after launch
 * @param {bool} [options.getJetsamPriority=true] - When true, jatsam priority is grabbed during the launch every 5
 * 		seconds
 * @param {bool} [options.getVMMap=false] - When true, take vmmap every 15 seconds during launch phase
 */
podcasts.regressionLaunchWithLargeDatabase = function regressionLaunchWithLargeDatabase(options) {
	options = UIAUtilities.defaults(options, {
		test               : 'Setup',
		expectedMyPodcasts : ["This Test","OS X","Launch 1","Despicable Me","Myths and Legends","Criminal",
							  "NPR Politics Podcast",
			                  "The Way I Heard It with Mike Rowe","Anna Faris Is Unqualified",
			                  "Grammar Girl Quick and Dirty Tips for Better Writing",
			                  "CLIMAX!","Look Like a Local:  Travelers Not Tourists","The Dirtbag Diaries",
			                  "Trends Like These","Mystery Show","Hello Internet",
			                  "Accidental Tech Podcast","Serial","This American Life",
			                  "Common Sense with Dan Carlin","Dan Carlin's Hardcore History",
			                  "WTF with Marc Maron Podcast","The Adam and Dr. Drew Show","The Bugle",
			                  "The Joe Rogan Experience","The Nerdist"],
		appleID            : 'ottoiqlaunchtest1@icloud.com',
		appleIDPassword    : 'podIQ6616',
		screenLocked       : false,
		waitTime           : 10,
		background         : true,
		getJetsamPriority  : true,
		getVMMap           : false,
	});

	UIALogger.logMessage('FUNCTION: regressionLaunchWithLargeDatabase');
	this.logStartingOptions(options);

	var validTests = ['Setup', 'Launch', 'My Podcasts', 'Unplayed'];
	UIAUtilities.assertNotEqual(
		validTests.indexOf(options.test),
		-1,
		'Test "%0" is not valid'.format(options.test)
	);

	switch (options.test) {
		case 'Setup':
			UIALogger.logMessage('Setting up for regressionLaunchWithLargeDatabase');
			this.loginToService('Store', options.appleID, options.appleIDPassword);
			break;

		case 'Launch':
			this.launch();
			this.delay(2);

			if (options.background) {
				target.clickMenu();
			}
			if (options.screenLocked) {
				target.clickLock();
			}

			// Time waited value in seconds
			var timeWaited = 0;
			// Time to wait before checking if Podcasts is running
			var interval = 1;
			var counter = 0;
			// Wait for options.waitTime minutes and check podcasts is not terminated every <interval> seconds
			while (timeWaited <= options.waitTime * 60) {
				UIAUtilities.assertNotEqual(
					this.stateDescription(),
					'Terminated',
					'Podcasts was terminated'
				);
				if (counter % 60 === 0) {
					UIALogger.logMessage('Podcasts still running after %0 minutes'.format(counter/60));
				}

				// Take screenshot every 2 minutes
				if (counter % 120 === 0) {
					var picName = 'Screen_After_%0_Minutes.png'.format(counter/60);
					this.takeScreenShot(UIAScreenIdentifier.MAIN, picName);
				}

				// Verify that there is at least something showing up in the database after having been launched for
				// 1 minute. Only run if screen is no locked and podcasts is not backgrounded
				if (counter === 60 && !options.background && !options.screenLocked) {
					this.assertNotExists(
						UIAQuery.Podcasts.NO_PODCASTS_IMAGE.isVisible(),
						'No podcasts in database after running for 1 minute'
					);
				}

				// Generate the jetsam_priority file
				if (options.getJetsamPriority && counter % 5 === 0) {
					UIALogger.logMessage('Generating jetsam_priority');
					var jFile = UIAFile.open('/var/mobile/Library/Logs/jetsam_priority.txt', 'a');
					var time = new Date();
					var jp = target.performTask ('/usr/local/bin/jetsam_priority', ['-s', 'name']);

					// Find the line with Podcasts in it and remove the rest
					var jpSplit = jp.stdout.split('\n');
					var pcastValue = 'No jetsam_priority entry found for Podcasts';
					for (var p = 0; p < jpSplit.length; p++) {
						if (jpSplit[p].indexOf('Podcasts') != -1) {
							pcastValue = jpSplit[p];
							UIALogger.logMessage('Found Podcasts at index %0, exiting loop'.format(p));
							break;
						}
					}
					// Have to use write due to <rdar://problem/26893377> When Trying to use UIAFile.writeIn(), the
					// Script Fails with a Type Error Indicating writeIn is Not a Function
					jFile.write(time);
					jFile.write('\n');
					jFile.write(jpSplit[0]);
					jFile.write('\n');
					jFile.write(pcastValue);
					jFile.write();
					jFile.write('\n\n');
					jFile.close();
				}
				// Generate vmmap file
				if (options.getVMMap && counter % 15 === 0) {
					UIALogger.logMessage('Generating vmmap');
					var vFile = UIAFile.open('/var/mobile/Library/Logs/vmmap.txt', 'a');
					var vmTask = target.performTask ('/usr/bin/vmmap', ['Podcasts'], 10);
					// Have to use write due to <rdar://problem/26893377> When Trying to use UIAFile.writeIn(), the
					// Script Fails with a Type Error Indicating writeIn is Not a Function
					vFile.write('***************NEW ENTRY***************\n');
					vFile.write(vmTask.stdout);
					vFile.write('\n\n\n');
					vFile.close();
				}
				this.delay(interval);
				timeWaited += interval;
				counter++;
			}

			// Check for existence of at least some data in podcasts after wait interval but only if it wasn't
			// checked for in the middle of the launch test which will only be needed if the device was locked or
			// the app was backgrounded
			if (options.screenLocked || options.background) {
				this.launch();
				this.assertNotExists(
					UIAQuery.Podcasts.NO_PODCASTS_IMAGE.isVisible(),
					'No podcasts in database after waiting for full database to load'
				);
			}


			break;

		case 'My Podcasts':
			if (options.screenLocked || options.background) {
				this.launch();
			}
			// Verify stations and Podcasts on My Podcasts
			this.getToTab(TABS.LIBRARY);
			this.verifyUnplayedCount(1, 0);
			this.checkMyPodcastsOrder(options.expectedMyPodcasts);
			break;

		case 'Unplayed':
			if (options.screenLocked || options.background) {
				this.launch();
			}
			// Verify contents of Unplayed tab using the unplayed quicklook test
			this.verifyUnplayedTabContents();
	}
};


/* SLEEP TIMER TESTS */

/**
 * Performs the various tests required to verify sleep timer
 *
 * @param {Object} options - options dictionary
 * @param {string} [options.test="Setup"] - Test to run, see test information below for valid entries and actions
 * 		taken by each
 * @param {string} [options.audioPodcastName="This American Life"] - Name of audio podcast to use for testing
 * @param {string} [options.audioPodcastURL] - URL of the audio podcast
 * @param {string} [options.audioEpisode=""] - Name of the audio episode to play for tests
 * @param {string} [options.videoPodcastName="Apple Keynotes"] - Name of video podcast to use for testing
 * @param {string} [options.videoPodcastURL] - URL of video podcast
 * @param {string} [options.videoEpisode=""] - Name of the video episode to play for tests
 *
 *Test Options:
 * Setup - Sets up for test by subscribing to the test podcasts and getting the name of the top episode in each
 * 	feed and then saving that information to the test dictionary to be used by tests later
 * 5 min - Runs a basic 5 minute sleep timer test on video and audio podcasts TSTT: 16416668
 * 10 min - Runs a basic 10 minute sleep timer test on video and audio podcasts TSTT: 16416668
 * 15 min - Runs a basic 15 minute sleep timer test on video and audio podcasts TSTT: 16416668
 * 30 min - Runs a basic 30 minute sleep timer test on video and audio podcasts TSTT: 16416668
 * 45 min - Runs a basic 45 minute sleep timer test on video and audio podcasts TSTT: 16416668
 * 1 hour - Runs a basic 1 hour sleep timer test on video and audio podcasts TSTT: 16416668
 * End - Runs a basic sleep timer test for end of episode TSTT: 16416668
 * Add While Paused - Adds a sleep timer with episode paused and verifies the sleep timer UI updates TSTT: 16416671
 * Selection Maintained - Verifies the sleep timer option stays selected after initially being selected TSTT: 16416674
 * Timer Paused Properly - Verifies sleep timer pauses when playback pauses and trigger correctly TSTT: 16416679
 * Maintained on Switch - Verifies sleep timer is maintained when switching episodes and triggers correctly TSTT: 16416686
 * Full Screen - Verifies sleep timers trigger correctly with video in full screen TSTT: 16416690
 * PiP - Verifies sleep timer triggers while in PiP TSTT: 16422061
 * Background - Verifies sleep timer triggers while Podcasts is in background TSTT: 16422096
 * Locked - Verifies sleep timer triggers while screen is locked TSTT: 16422123
 */
podcasts.sleepTimerRegression = function sleepTimerRegression(options) {
	options = UIAUtilities.defaults(options, {
		test			  : 'Setup',
		audioPodcastName  : 'This American Life',
		audioPodcastURL   : PODCAST_URLS.This_American_Life,
		audioEpisode      : '',
		videoPodcastName  : 'Apple Keynotes',
		videoPodcastURL   : PODCAST_URLS.Apple_Keynotes,
		videoEpisode      : '',
	});

	this.quitOrKillApp();
	this.launch();
	var stopTime = new Date();

	switch (options.test) {
		case 'Setup':
			this.subscribeViaPlusSignToURL(
				options.audioPodcastURL,
				options.audioPodcastName,
				{verify:false}
			);
			this.subscribeViaPlusSignToURL(
				options.videoPodcastURL,
				options.videoPodcastName,
				{verify:false}
			);
			this.waitForDownloadsToComplete(10);

			// Get top episode name from each podcast feed to save time when starting playback.
			this.drillIntoPodcastContainer(options.audioPodcastName);
			this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
			var audioEpisodeName = this.inspectElementKey(
				UIAQuery.images().contains(options.audioPodcastName).siblings().andThen(
					UIAQuery.tableCells().atIndex(0)), 'label');
			audioEpisodeName = this.getCleanedEpisodeTitle(audioEpisodeName);
			UIALogger.logTAResults({AudioEpisodeName:audioEpisodeName});

			if (!iPad) {
				this.getToTopLevelCurrentTab(TABS.MY_PODCASTS);
			}

			this.drillIntoPodcastContainer(options.videoPodcastName);
			this.tap(UIAQuery.Podcasts.PODCASTS_SEGMENT_FEED);
			var videoEpisodeName = this.inspectElementKey(
				UIAQuery.images().contains(options.videoPodcastName).siblings().andThen(
					UIAQuery.tableCells().atIndex(0)), 'label');
			videoEpisodeName = this.getCleanedEpisodeTitle(videoEpisodeName);
			UIALogger.logTAResults({VideoEpisodeName:videoEpisodeName});
			break;
		case 'Add While Paused':
			UIALogger.logMessage('Running rdar://tsc/16416671 Sleep Timer: Timer Shows Value if Added While Paused');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			// Lower volume of playback
			this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0);
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
			this.verifyNotPlaying();

			this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
			this.waitUntilReady();
			this.tap(UIAQuery.Podcasts.SLEEP_IN_5);
			// Assert that the sleep timer button now includes a colon indicating it includes a time
			this.assertExists(
				UIAQuery.Podcasts.SLEEP_TIMER_BUTTON.contains(':'),
				'Sleep timer did not display after being added with episode paused'
			);
			break;
		case 'Selection Maintained':
			UIALogger.logMessage('Running rdar://tsc/16416674 Sleep Timer: Time Selected Remains Selected on Dismiss');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			// Lower volume of playback
			this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0);
			// pause playback
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);

			this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
			this.waitUntilReady();
			this.tap(UIAQuery.Podcasts.SLEEP_IN_10);
			this.waitUntilReady();
			this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
			this.waitUntilReady();
			this.assertExists(
				UIAQuery.Podcasts.SLEEP_IN_10.isSelected(),
				'Sleep timer selection is not selected after dismissing menu'
			);
			break;
		case 'Timer Paused Properly':
			UIALogger.logMessage('Running rdar://tsc/16416679 Sleep Timer: Pausing Playback Pauses the Sleep Timer');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			// Lower volume of playback
			this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0);
			// Start a 10 minute sleep timer
			this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
			this.waitUntilReady();
			this.tap(UIAQuery.Podcasts.SLEEP_IN_5);
			this.waitUntilReady();

			// Pause playback
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);

			// Get sleep timer value, wait 5 seconds and verify they stayed the same
			var label = this.inspectElementKey(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON, 'label');
			this.delay(5);
			UIAUtilities.assertEqual(
				label,
				this.inspectElementKey(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON, 'label'),
				'Sleep timer label changed after 5 seconds. No change expected'
			);

			UIALogger.logMessage('Sleep timer paused when playback paused');

			// Wait a full minute and then verify sleep timer did not continue in background
			this.delay(60);
			// Tap play then pause to update sleep timer to see if it was running in background
			this.tap(UIAQuery.Podcasts.PLAY_BUTTON);
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
			var splitLabel = label.split(', ');
			var currentLabel = this.inspectElementKey(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON, 'label');
			var firstSplit = currentLabel.split(', ');
			var splitCurrent = firstSplit[1].split(':');

			// Verify the values match for all except the last item as that would be seconds and may have updated
			for (var m = 0; m < splitLabel.length - 1; m++) {
				UIAUtilities.assertEqual(
					splitLabel[m],
					firstSplit[m],
					'Timer incremented while playback was paused'
				);
			}
			UIALogger.logMessage('Sleep timer did not increment while playback was paused');
			var timerSeconds = 0;
			// Determine how much time is left in order to add to the date
			if (splitCurrent.length === 3) {
				timerSeconds += parseInt(splitCurrent[0]) * 60 * 60;
				timerSeconds += parseInt(splitCurrent[1]) * 60;
				timerSeconds += parseInt(splitCurrent[2]);
			} else if (splitCurrent.length === 2) {
				timerSeconds += parseInt(splitCurrent[0]) * 60;
				timerSeconds += parseInt(splitCurrent[1]);
			} else {
				timerSeconds += parseInt(splitCurrent[0]);
			}

			this.tap(UIAQuery.Podcasts.PLAY_BUTTON);
			stopTime.setTime(Date.now());
			UIALogger.logMessage('Playback resumed at "%0"'.format(stopTime));
			UIALogger.logMessage('timerSeconds was %0'.format(timerSeconds));
			stopTime.setSeconds(stopTime.getSeconds() + timerSeconds - 1);

			// Wait for playback to end
			this.sleepTimerWaitForTimer(stopTime);
			break;
		case 'Maintained on Switch':
			UIALogger.logMessage('Running rdar://tsc/16416686 Sleep Timer: Timer Maintained When Switching Episodes');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			// Lower volume of playback
			this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0);

			this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
			this.waitUntilReady();
			this.tap(UIAQuery.Podcasts.SLEEP_IN_10);
			var startTime = new Date();
			UIALogger.logMessage('Timer started at "%0"'.format(startTime));
			this.waitUntilReady();

			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
			var pauseTime = new Date();
			UIALogger.logMessage('Playback paused at "%0"'.format(pauseTime));

			stopTime = new Date(startTime).setSeconds(startTime.getSeconds() + 599)-(pauseTime-startTime);
			UIALogger.logMessage('stopTime was "%0"'.format(new Date(stopTime)));

			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:true}
			);
			stopTime = new Date();
			stopTime = stopTime.setSeconds(stopTime.getSeconds() + 599)-(pauseTime-startTime);
			UIALogger.logMessage('stopTime was "%0"'.format(new Date(stopTime)));
			this.waitUntilReady();

			// Wait for sleep timer to finish
			this.sleepTimerWaitForTimer(stopTime);
			break;
		case 'Full Screen':
			UIALogger.logMessage('Running rdar://tsc/16416690 Sleep Timer: Timer Triggered Properly With Video in Full Screen');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(10, {fullscreen:true});
			break;
		case '5 min':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 5 min sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(5);

			UIALogger.logMessage('Starting 5 min sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(5);
			break;
		case '10 min':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 10 min sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(10);

			UIALogger.logMessage('Starting 10 min sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(10);
			break;
		case '15 min':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 15 min sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(15);

			UIALogger.logMessage('Starting 15 min sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(15);
			break;
		case '30 min':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 30 min sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(30);

			UIALogger.logMessage('Starting 30 min sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(30);
			break;
		case '45 min':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 45 min sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(45);

			UIALogger.logMessage('Starting 45 min sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(45);
			break;
		case '1 hour':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting 1 hour sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(1);

			UIALogger.logMessage('Starting 1 hour sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.getToNowPlaying();
			this.sleepTimerperformBasicTest(1);
			break;
		case 'End':
			UIALogger.logMessage('Running rdar://tsc/16416668 Sleep Timer: Test All Playback Times');
			UIALogger.logMessage('Starting end of episode sleep audio test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);
			this.advanceNearEndOfEpisode();
			this.sleepTimerperformBasicTest(-1);

			UIALogger.logMessage('Starting end of episode sleep video test');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);
			this.advanceNearEndOfEpisode();
			this.sleepTimerperformBasicTest(-1);
			break;
		case 'PiP':
			UIALogger.logMessage('Running rdar://tsc/16422061 Sleep Timer: Triggers While in PiP');
			this.tapToPlayEpisodeInMyPodcasts(
				options.videoPodcastName, {episodeName:options.videoEpisode, inFeed:true, keepUpNext:false}
			);

			this.getToNowPlaying();

			this.sleepTimerperformBasicTest(10, {PiP:true, background:true});

			// Verify PiP window was not dismissed
			springboard.assertExists(
				UIAQuery.Podcasts.PIP_WINDOW,
				'PiP window dismissed after sleep timer triggered'
			);
			break;
		case 'Background':
			UIALogger.logMessage('Running rdar://tsc/16422096 Sleep Timer: Trigger While Backgrounded');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);

			this.getToNowPlaying();

			this.sleepTimerperformBasicTest(10, {background:true});
			break;
		case 'Locked':
			UIALogger.logMessage('Running rdar://tsc/16422123 Sleep Timer: Triggers With Screen Locked');
			this.tapToPlayEpisodeInMyPodcasts(
				options.audioPodcastName, {episodeName:options.audioEpisode, inFeed:true, keepUpNext:false}
			);

			this.getToNowPlaying();

			this.sleepTimerperformBasicTest(10, {locked:true});
			break;
		default:
			throw new UIAError('The test "%0" is not a valid test'.format(options.test));
	}
};

/**
 * Perform a basic test of any of the sleep timer values
 *
 * Expected Starting State: In Now Playing with an episode either playing or paused
 *
 * @param {number} time - Time to test. For each of the minute settings simply enter the corresponding minute value.
 * 		Enter 1 for the 1 hour sleep timer and -1 for end of episode
 * @param {Object} options - options dictionary
 * @param {bool} [options.fullscreen=false] - When true, enters full screen after setting sleep timer
 * @param {bool} [options.locked=false] - When true, locks the screen after setting sleep timer
 * @param {bool} [options.background=false] - When true, backgrounds podcasts after setting sleep timer
 * @param {bool} [options.PiP=false] - When true, enters PiP after starting sleep timer
 */
podcasts.sleepTimerperformBasicTest = function sleepTimerperformBasicTest (time, options) {
	options = UIAUtilities.defaults(options, {
		fullscreen : false,
		locked     : false,
		background : false,
		PiP        : false,
	});
	UIALogger.logMessage('FUNCTION: sleepTimerperformBasicTest');
	this.logStartingOptions(options, 'time = %0'.format(time));

	UIALogger.logMessage('Start time was %0'.format(Date.now()));

	var validTimes = [-1,1,5,10,15,30,45];
	UIAUtilities.assertNotEqual(
		validTimes.indexOf(time),
		-1,
		'Entered value for time, "%0", is not valid'.format(time)
	);

	if (options.PiP && !iPad) {
		throw new UIAError ('Cannot run PiP test on phone');
	}
	// Lower volume of playback
	this.setControl(UIAQuery.Podcasts.VOLUME_SLIDER.isVisible(), 0);
	this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
	// Turn off sleep timer if already set
	if (!this.exists(UIAQuery.Podcasts.SLEEP_OFF.isSelected())) {
		this.tap(UIAQuery.Podcasts.SLEEP_OFF);
		this.assertNotExists(
			UIAQuery.Podcasts.SLEEP_TIMER_BUTTON.contains(':'),
			'Sleep timer still active after being turned off'
		);
		this.tap(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON);
	}
	this.waitUntilReady();
	var testSeconds = time * 60;
	var timerStop = new Date();
	var timerText;

	switch (time) {
		case 5:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_5);
			timerStop.setTime(Date.now());
			timerText = ', 4:';

			break;
		case 10:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_10);
			timerStop.setTime(Date.now());
			timerText = ', 9:';

			break;
		case 15:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_15);
			timerStop.setTime(Date.now());
			timerText = ', 14:';

			break;
		case 30:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_30);
			timerStop.setTime(Date.now());
			timerText = ', 29:';

			break;
		case 45:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_45);
			timerStop.setTime(Date.now());
			timerText = ', 44:';

			break;
		case 1:
			this.tap(UIAQuery.Podcasts.SLEEP_IN_1_HOUR);
			timerStop.setTime(Date.now());
			timerText = ', 59:';
			// Make testSeconds reflect actual test seconds
			testSeconds *= 60;

			break;
		case -1:
			this.tap(UIAQuery.Podcasts.SLEEP_AT_END);
			timerStop.setTime(Date.now());
			// Get time remaining. Pause so that timing is accurate
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
			testSeconds = CAMMediaRemote.getNowPlayingDuration() - CAMMediaRemote.getNowPlayingElapsedTime();
			UIALogger.logMessage('timeRemaining = %0'.format(testSeconds));
			this.tap(UIAQuery.Podcasts.PLAY_BUTTON);
			timerText = false;

			break;
		default:
			throw new UIAError('%0 is not a valid test time'.format(time));
	}

	// Commented out to work around <rdar://problem/27349690> REG: Sleep Timer in Podcasts Does Not List Time
	// Remaining per <rdar://problem/27969123> Work Around Sleep Timer Regression Suite Failures.
	// if (typeof timerText === 'string') {
	// 	UIALogger.logMessage('Verifying text in sleep timer');
	// 	// Verify sleep timer displayed with at least the first digit correct
	// 	this.assertExists(
	// 		UIAQuery.Podcasts.SLEEP_TIMER_BUTTON.contains(timerText),
	// 		'Time shown for sleep timer incorrect. Sleep timer showed "%0"'.format(
	// 			this.inspectElementKey(UIAQuery.Podcasts.SLEEP_TIMER_BUTTON, 'label')
	// 		)
	// 	);
	// }

	UIALogger.logMessage('testSeconds = %0'.format(testSeconds));

	if (options.fullscreen) {
		this.getToFullScreenVideo();
	}
	if (options.PiP) {
		this.tap(UIAQuery.Podcasts.PIP_BUTTON);
		UIAUtilities.assert(
			springboard.waitUntilPresent(UIAQuery.Podcasts.PIP_WINDOW),
			'PIP window never appeared'
		);
	}
	if (options.background) {
		target.clickMenu();
	}
	if (options.locked) {
		target.clickLock();
	}

	UIALogger.logMessage('Sleep timer started at "%0"'.format(timerStop));
	timerStop.setSeconds(timerStop.getSeconds() + (testSeconds - 1));
	this.sleepTimerWaitForTimer(timerStop);
};


/**
 * Wait for a sleep timer to complete verifying playback is progressing as expected and that playback ends when expected
 *
 * @param {Date} stopTime - Date representing when sleep timer should trigger
 *
 * @throw if playback stops before it should or does not stop when expected
 */
podcasts.sleepTimerWaitForTimer = function sleepTimerWaitForTimer(stopTime) {
	UIALogger.logMessage('FUNCTION: sleepTimerWaitForTimer with stopTime = %0'.format(stopTime));

	var count = 0;
	var currentTime = new Date();

	// Wait for the prescribed number of minutes verifying playback is still running every minute. Check how close
	while (currentTime < stopTime) {
		if ((stopTime - currentTime) / 1000 < 15) {
			UIALogger.logMessage('Too close to stopTime to test for playback');
			this.delay(1);
		} else {
			UIALogger.logMessage('Waiting for playback after minute %0 passed'.format(count));
			// Wait for playback giving 5 seconds in case episodes are transitioning
			this.waitForPlayback(5);
			this.delay(60);
			count++;
		}
		currentTime.setTime(Date.now());
		UIALogger.logMessage('currentTime = "%0"'.format(currentTime));
	}

	// Verify Podcasts is not terminated
	UIAUtilities.assertNotEqual(
		this.stateDescription(),
		'Terminated',
		'Podcasts was terminated'
	);
	// Verify playback is not occurring
	this.launch();
	this.verifyNotPlaying();

	this.assertNotExists(
		UIAQuery.Podcasts.SLEEP_TIMER_BUTTON.contains(':'),
		'Sleep timer still showing a time'
	);
};

/***************************** UPGRADE REGRESSION TESTS *****************************/
/**
 * Performs either a setup or verify for upgrade testing. Will support iCloud backup and restore as well
 *
 * @param {{}} options - Options dictionary
 * @param {{}} [options.settingsToSet] - App settings to change for the test. Dictionary must be compatible with
 *		changeAppSettings
 * @param {{}} [options.settingsToCompare] - Dictionary of app settings compatible with verifyAppSettings. Used to
 * 		verify settings are correct
 * @param {Object[]} [options.unplayedToCompare] - Array of dictionary items as generated by getAllEpisodeData
 * 		representing episode information from the Unplayed tab to compare against
 * @param {string[]} [options.myPodcastsToCompare] - String array of all items from the My Podcasts tab to verify
 * @param {Object[]} [options.myPodcastsEpisodeDataToCompare] - Array of dictionary items as generated by
 * 		getAllEpisodeDataFromAllContainers to compare the contents of all podcast containers
 * @param {string[]} [options.testPodcastTitles] - Array of podcast titles to use index matched to
 * 		options.testPodcastURLs
 * @param {string[]} [options.testPodcastURLs] - Array of podcast URLs to use to subscribe index matched to
 * 		options.testPodcastTitles
 * @param {Date} [options.testStartTime] - Date representing when setup completed to be used to remove any new
 * 		episodes that dropped in between tests
 * @param {{}} [options.podcastSettingsToSet] - Podcast settings to change on one of the podcasts. Dictionary
 * 		compatible with changePodcastSettings()
 * @param {Object[]} [options.podcastSettingsToVerify	- Array of dictionary items containing the settings for all the
 * 		podcasts to compare them
 * @param {boolean} [options.verify=false] - If true, verifies with information passed in
 * @param {string} [options.upgradeTestType] - String representing test type. Only supports "Upgrade" currently
 * @param {string} [options.upgradeStationName] - Name to be used for the station created by the test
 * @param {Object[]} [options.stationEpisodesToCompare] - Array of dictionary items as generated by getAllEpisodeData
 * 		representing episode information from the station to compare against
 *
 * 	@throws if any of the items do not match the expected
 */
podcasts.upgradeRegressionTest = function upgradeRegressionTest (options) {
	options = UIAUtilities.defaults(options, {
		settingsToSet                  : null,
		settingsToCompare              : null,
		unplayedToCompare              : null,
		myPodcastsToCompare            : null,
		myPodcastsEpisodeDataToCompare : null,
		testPodcastTitles              : ['Serial', 'This American Life', 'Car Talk', 'The Flop House',
			                              'Planet Money', 'Fresh Air', 'Start Cooking',
			                              'Grammar Girl Quick and Dirty Tips for Better Writing',
		                                  'Look Like a Local:  Travelers Not Tourists', 'The Dirtbag Diaries'],
		testPodcastURLs                : [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life, PODCAST_URLS.Car_Talk,
			                              PODCAST_URLS.The_Flop_House, PODCAST_URLS.Planet_Money, PODCAST_URLS.Fresh_Air,
			                              PODCAST_URLS.Start_Cooking, PODCAST_URLS.Grammar_Girl,
			                              PODCAST_URLS.Look_Like_a_Local, PODCAST_URLS.The_Dirtbag_Diaries],
		testStartTime                  : new Date(),
		podcastSettingsToSet           : null,
		podcastSettingsToVerify        : null,
		upgradeTestType                : 'Setup',
		stationName                    : 'Upgrade Test Station',
		stationEpisodesToCompare       : null,
	});

	this.logStartingOptions(options);
	// Convert testStartTime to Date object
	options.testStartTime = new Date (options.testStartTime);

	// Create variable to represent keys needing to be verified
	var keysToVerify = ['title', 'playState', 'explicit', 'downloaded', 'saved'];

	switch (options.upgradeTestType) {
		case ('Setup'):
			// Run the test to setup a device for upgrade testing
			this.launch();
			this.getToTab(TABS.MY_PODCASTS);
			// Create a copy of the podcast list that will be popped to make sure the same podcast isn't used repeatedly
			// during setup phase
			var setupTitleArray = options.testPodcastTitles.slice();
			var stationName = options.stationName;

			// Subscribe to all the podcasts to be used for the test without verifying the subscription settings. This will
			// be handled later
			for (var i = 0; i < options.testPodcastURLs.length; i++) {
				this.subscribeViaPlusSignToURL(
					options.testPodcastURLs[i],
					options.testPodcastTitles[i],
					{needToNav: false, verify: false}
				);
			}

			// Get date to be used to remove any episodes that dropped in between tests
			var testDate = new Date();
			var testDateString = testDate.toString();
			UIALogger.logTAResults({UpgradeSetupDate:testDateString});

			// Wait up to 20 minutes for any and all downloads to complete and cancels any that aren't complete yet
			if (!this.waitForDownloadsToComplete(20)) {
				if (iPad) {
					this.tapIfExists(UIAQuery.Podcasts.DOWNLOADS_TAB);
                } else {
					this.tapIfExists(UIAQuery.Podcasts.PHONE_DOWNLOAD_BAR);
                }
				this.tapIfExists(UIAQuery.Podcasts.CANCEL_DOWNLOADS);
            }

			// Set up the database for the tests to be run in the next steps
			// Change one podcast to be Not Subscribed
			var notSubscribedPodcast = setupTitleArray.pop();
			UIALogger.logMessage('notSubscribedPodcast was %0'.format(notSubscribedPodcast));
			this.changePodcastSettings([notSubscribedPodcast], {subscribed: false});
			this.tap(UIAQuery.Podcasts.MYPODCASTS_TAB);

			// Create a station
			this.createStation(stationName, {includeAll:true});
			this.tap(UIAQuery.Podcasts.MYPODCASTS_TAB);

			// Change app settings to settingsToSet
			this.changeAppSettings(options.settingsToSet);
			var appSettings = this.getAppSettings();
			// Log appSettings to results dictionary to be passed to next test
			UIALogger.logTAResults({AppSettings:appSettings});

			// Mark several episodes of a podcast as unplayed. Using This American Life due to short feed
			var severalUnplayedPodcast = 'This American Life';
			UIALogger.logMessage('severalUnplayedPodcast was %0'.format(severalUnplayedPodcast));
			// Remove This American Life from the test array so it won't be used
			setupTitleArray.splice(setupTitleArray.indexOf(severalUnplayedPodcast),1);
			// Navigate to feed and get list of episodes there
			var eList = this.generateEpisodeList({
				podcastTitle: severalUnplayedPodcast,
				feed: true,
				needToNavigate: true
			});
			// Create a list of episodes to mark as unplayed
			var toChange = eList.slice(1, eList.length - 1);
			this.setEpisodePlayState('Unplayed', toChange, {isInFeed: true});
			this.tap(UIAQuery.Podcasts.MYPODCASTS_TAB);
			// Change the settings of a podcast to podcastSettingsToSet
			var changedSettingsPodcast = setupTitleArray.pop();
			UIALogger.logMessage('changedSettingsPodcast was %0'.format(changedSettingsPodcast));
			this.changePodcastSettings([changedSettingsPodcast], options.podcastSettingsToSet);
			this.tap(UIAQuery.Podcasts.MYPODCASTS_TAB);

			// Partially play an episode
			var partiallyPlayedPodcast = setupTitleArray.pop();
			UIALogger.logMessage('partiallyPlayedPodcast was %0'.format(partiallyPlayedPodcast));
			this.tapToPlayEpisodeInMyPodcasts(partiallyPlayedPodcast);
			this.tapIfExists(UIAQuery.Podcasts.MINIPLAYER_MINI);
			// Skip ahead 3 minutes
			this.tap(UIAQuery.Podcasts.FF15_BUTTON, {tapCount:12});
			this.tap(UIAQuery.Podcasts.PAUSE_BUTTON);
			this.tap(UIAQuery.Podcasts.NOW_PLAYING);

			// Play an episode completely
			var playedEpisodePodcast = setupTitleArray.pop();
			UIALogger.logMessage('playedEpisodePodcast was %0'.format(playedEpisodePodcast));
			this.tapToPlayEpisodeInMyPodcasts(playedEpisodePodcast);
			// Open Now Playing if needed
			this.tapIfExists(UIAQuery.Podcasts.MINIPLAYER_MINI);
			// Fast forward to the end of the episode by finding the length of the episode, converting the value to
			// seconds and then skipping ahead near to the end and letting it finish playing
			var trackInfo = this.valueOf('Track Position');
			var trackSplit = trackInfo.split(' ');
			var runTime = this.getSecondsFromTrackPosition(trackSplit[2]);
			UIALogger.logMessage('runTime = %0'.format(runTime));
			var tapCount = Math.floor(runTime/15);
			UIALogger.logMessage('tapCount = %0'.format(tapCount));
			this.tap(UIAQuery.Podcasts.FF15_BUTTON, {tapCount:tapCount});
			UIAUtilities.assert(
				this.waitUntilAbsent(UIAQuery.Podcasts.FF15_BUTTON, 30),
				'Now Playing did not dismiss after waiting for 30 seconds'
			);

			// Get settings from each podcast
			var podcastSettings = this.getAllPodcastSettings();
			UIALogger.logTAResults({AllPodcastSettings:podcastSettings});

			// Get list of all items on My Podcasts tab and add to results dictionary
			var myPodcastsList = this.generateShowsList();
			UIALogger.logTAResults({MyPodcastsList:myPodcastsList});

			// Get all episode data from all Podcasts and add to results dictionary
			this.getToTab(TABS.MY_PODCASTS);
			var allMyPodcastsEpisodeData = this.getAllEpisodeDataFromAllContainers();
			this.removeFullDates(allMyPodcastsEpisodeData);
			UIALogger.logTAResults({MyPodcastsEpisodeData:allMyPodcastsEpisodeData});

			// Get all episode data from the station
			var stationEpisodeList = this.generateEpisodeList({stationName:stationName,
				needToNavigate:true,
				getCleanedTitle:false});
			var parsedStationEpisodeData = this.getAllEpisodeDataFromRawValues(stationEpisodeList, 'Test Upgrade Station');
			this.removeFullDates(parsedStationEpisodeData);
			UIALogger.logTAResults({StationEpisodeData:parsedStationEpisodeData});
			if (!iPad) {
				this.tapIfExists(UIAQuery.Podcasts.BACK_NAV_BUTTON);
			}

			// Get all episodes from Unplayed
			this.getToTab(TABS.UNPLAYED);
			var unplayedEpisodeData = this.generateEpisodeList({getCleanedTitle:false});
			var parsedUnplayedEpisodeData = this.getAllEpisodeDataFromRawValues(unplayedEpisodeData, 'Unplayed');
			this.removeFullDates(parsedUnplayedEpisodeData);
			UIALogger.logTAResults({UnplayedTabEpisodeData:parsedUnplayedEpisodeData});

			this.getToTab(TABS.MY_PODCASTS);

			UIALogger.logMessage('Upgrade Test Setup Complete');

			break;

		case ('Verify App Settings'):
			UIALogger.logMessage('Verifying App Settings');

			this.verifyAppSettings(options.settingsToCompare);
			UIALogger.logMessage('testStartTime was "%0"'.format(options.testStartTime));

			break;

		case ('Verify Unplayed Tab'):
			UIALogger.logMessage('Verifying contents of Unplayed tab');
			this.launch();
			UIALogger.logMessage('Gathering episode data to verify Unplayed tab has correct content');
			var currentUnplayedTabEpisodes = this.generateEpisodeList({needToNavigate:true,
				getCleanedTitle : false});

			// Get all episode data and remove any episodes that dropped in between tests. This is imperfect because it
			// relies on getAllEpisodeData which is imperfect as well but should prevent at least some issues
			var allParsedUnplayedData = this.getAllEpisodeDataFromRawValues(currentUnplayedTabEpisodes, 'Unplayed');
			var dateCheckedUnplayedData = this.removeRecentlyDroppedEpisodes(options.testStartTime,
				allParsedUnplayedData);

			UIALogger.logMessage('Verifying current episode data against expected on Unplayed tab');
			this.verifyEpisodeDataMatches(dateCheckedUnplayedData, options.unplayedToCompare, keysToVerify);
			UIALogger.logMessage('Unplayed tab content verified');

			break;

		case ('Verify My Podcasts Tab'):
			UIALogger.logMessage('Verifying order of My Podcasts tab');

			this.launch();
			this.getToTab(TABS.MY_PODCASTS);
			this.tap(UIAQuery.statusBars());
			this.checkMyPodcastsOrder(options.myPodcastsToCompare);

			break;

		case ('Verify Station Contents'):
			UIALogger.logMessage('Verifying content of the test station');
			this.launch();

			var currentStationEpisodeList = this.generateEpisodeList({stationName:options.stationName,
				needToNavigate:true,
				getCleanedTitle:false});

			// Get all episode data and remove any episodes that dropped after test started. This is imperfect because it
			// relies on getAllEpisodeData which is imperfect as well but should prevent at least some issues
			var allStationEpisodeData = this.getAllEpisodeDataFromRawValues(currentStationEpisodeList, options.stationName);
			var dateCheckedStationData = this.removeRecentlyDroppedEpisodes(options.testStartTime, allStationEpisodeData);

			UIALogger.logMessage('Verifying current episode data against expected in station');
			this.verifyEpisodeDataMatches(dateCheckedStationData, options.stationEpisodesToCompare, keysToVerify);

			break;

		case ('Verify Container Contents'):
			this.launch();
			this.getToTab(TABS.MY_PODCASTS);

			for (var p = 0; p < options.testPodcastTitles.length; p++) {
				// Get all items for the specific podcast from myPodcastsEpisodeDataToCompare
				var podcastEpisodes = [];
				for (var e = 0; e < options.myPodcastsEpisodeDataToCompare.length; e++) {
					if (options.myPodcastsEpisodeDataToCompare[e].podcast === options.testPodcastTitles[p]) {
						UIALogger.logMessage('Added %0 to podcastEpisodes'.format(options.myPodcastsEpisodeDataToCompare[e].title));
						podcastEpisodes.push(options.myPodcastsEpisodeDataToCompare[e]);
						// Remove the episode info to make future searches shorter
						options.myPodcastsEpisodeDataToCompare.splice(e,1);
						e--;
					} else {
						UIALogger.logMessage('%0 not added to podcastEpisodes'.format(options.myPodcastsEpisodeDataToCompare[e].title));
					}
				}

				this.drillIntoPodcastContainer(options.testPodcastTitles[p]);
				var episodes = this.generateEpisodeList({podcastTitle:options.testPodcastTitles[p]});
				var currentEpisodeInfo = [];
				for (var t = 0; t < episodes.length; t++) {
					currentEpisodeInfo.push(this.getAllEpisodeData(episodes[t]));
				}
				var dateCheckedCurrentEpisodeInfo = this.removeRecentlyDroppedEpisodes(options.testStartTime, currentEpisodeInfo);

				this.verifyEpisodeDataMatches(dateCheckedCurrentEpisodeInfo, podcastEpisodes, keysToVerify);
				this.getToTab(TABS.MY_PODCASTS);
			}

			break;

		case ('Verify Podcast Settings'):
			UIALogger.logMessage('Verifying all podcast settings');
			this.launch();

			for (i = 0; i < options.podcastSettingsToVerify.length; i++) {
				this.verifyPodcastSettings([options.podcastSettingsToVerify[i].podcast], options.podcastSettingsToVerify[i]);
			}
			break;

		default:
			throw new UIAError('No test with name %0 exists'.format(options.test));
	}
};



/* SIRI TEST FUNCTIONS */
/**
 * Calls necessary function to run a siri regression suite
 *
 * @param {Object} options - options dictionary
 * @param {string[]} [options.testAudioPodcastNames=""] - Titles of audio podcasts to use for testing
 * @param {string[]} [options.testAudioPodcastURLs=""] - Array of URLs index matched to testAudioPodcastNames
 * @param {string[]} [options.testVideoPodcastNames=""] - Array of video podcasts to use for testing
 * @param {string[]} [options.testVideoPodcastURLs=""] - Array of URLs index matched to testVideoPodcastNames
 * @param {string[]} [options.testEnhancedPodcastNames=""] - Array of enhanced podcasts to use for testing
 * @param {string[]} [options.testEnhancedPodcastURLs=""] - Array of URLs index matched to testEnhancedPodcastNames
 * @param {string} [options.test="Setup"] - Test to be performed
 * @param {string} [options.passcode="1111"] - Passcode to use on the device during testing
 * @param {string[]} [options.commands=""] - commands to issue to siri, can be just 1 or multiple. If issuing
 * 		multiple the test will be run with each command with each app and device state that is passed in
 * @param {string[]} [options.appStates=""] - App states to test the command with. Foreground, Background or Force Quit
 * @param {string[]} [options.deviceStates=""] - Device states to run commands in. Locked With Passcode, Locked No
 * 		Passcode or Unlocked
 * @param {string} [options.testPodcastTitle="Serial"] - Podcast to use for test
 * @param {string} [options.episodeName=""] - Specific episode to play back
 * @param {bool} [options.inFeed=false] - Determines if playback should be started from the feed when starting
 * 		playback via tap
 * @param {bool} [options.isSaved=false] - Determines if playback should be started from the saved tab when
 * 		starting playback via tap
 * @param {bool} [options.keepUpNext=true] - Determines if Up Next is kept or cleared when starting playback via tap
 * @param {bool} [options.insertPodcastInCommand=false] - When true, inserts options.testPodcastTitle in to the
 * 		commands passed in with options.commands using format. So "Play %0" passed in as command becomes "Play
 * 		options.testPodcastTitle"
 * @param {bool} [options.insertEpisodeInCommand=false] - When true, inserts options.episodeName in to the commands
 * 		passed in with options.commands using format. So "Play %0" passed in as command becomes "Play
 * 		options.episodeName"
 * @param {bool} [options.openPodcasts=false] - When true, verifies the Open Podcasts button becomes visible after
 * 		each siri command and taps on it
 * @param {bool} [options.homeButton=false] - When true, home button is pressed to dismiss Siri
 * @param {bool} [options.pauseBetween=false] - When true, playback is paused in between tests
 * @param {bool} [options.needUnlock=false] - When true, device will be unlocked if needed in between states
 * @param {bool} [options.exitNowPlaying=false] - When true, exits Now Playing in between tests
 * @param {bool} [options.verifyRunning=true] - When true, verifies Podcasts app state is not Terminated at end
 * 		of all verifications
 * @param {bool} [options.verifyForeground=false] - When true, verifies Podcasts is in the foreground after test
 * @param {bool} [options.verifyBackground=false] - When true, verifies Podcasts is in the background after test
 * @param {bool} [options.verifyPlaying=false] - When true, verifies media is playing after podcasts is opened
 * @param {bool} [options.verifyNotPlaying=false] - When true, verifies a pause command was seen by Siri as
 * 		successful and verifies media is not playing
 * @param {bool} [options.verifyPodcastPlaying=false] - When true, verifies that the Podcast playing is correct
 * @param {bool} [options.verifyEpisodePlaying=false] - When true, verifies that the correct episode is playing
 * @param {bool} [options.verifyPausedAfterHome=false] - When true, verifies media is not playing after home button
 * 		is pressed
 * @param {bool} [options.verifyPlayingAfterHome=false] - When true, verifies media is playing after pressing home
 * 		button
 * @param {bool} [options.verifyPlayHead=false] - When true, verifies the playhead is withing 5 seconds of the
 * 		position it was in when playback was paused
 * @param {bool} [args.verifyUpNext=false] - When true, verifies the Up Next tab is the same as it was before
 * 		the Siri command was issued
 * @param {number} [options.markAsUnplayed=0] - Number of episodes of testPodcastTitle to mark as Unplayed from the
 * 		feed
 * @param {Object} [options.verifyUIState=""] - When UI state is passed in, verifies the currentUIState matches
 * @param {number} [options.prepAction=-1] - Function to run after all other verifications are complete
 */
podcasts.siriRegressionTests = function siriRegressionTests(options) {
	options = UIAUtilities.defaults(options, {
		testAudioPodcastNames    : ['Serial', 'This American Life'],
		testAudioPodcastURLs     : [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life],
		testVideoPodcastNames    : ['TEDTalks (video)'],
		testVideoPodcastURLs     : [PODCAST_URLS.TEDTalks_video],
		testEnhancedPodcastNames : ['Colonial Williamsburg History Podcasts - Image Enhanced'],
		testEnhancedPodcastURLs  : [PODCAST_URLS.Colonial_Williamsburg_Enhanced],
		testPrep 			 	 : 'Setup',
		passcode         		 : '1111',
		commands				 : '',
		appStates				 : ['Foreground', 'Background', 'Force Quit'],
		deviceStates			 : ['Locked With Passcode', 'Locked No Passcode', 'Unlocked'],
		testPodcastTitle		 : 'Serial',
		episodeName		         : '',
		inFeed					 : false,
		isSaved  			     : false,
		keepUpNext				 : true,
		insertPodcastInCommand   : false,
		insertEpisodeInCommand   : false,
		openPodcasts	         : false,
		homeButton               : false,
		pauseBetween	         : false,
		needUnlock               : false,
		exitNowPlaying           : false,
		verifyRunning            : false,
		verifyForeground         : false,
		verifyBackground         : false,
		verifyPlaying            : false,
		verifyNotPlaying         : false,
		verifyEpisodePlaying     : false,
		verifyPausedAfterHome    : false,
		verifyPlayingAfterHome   : false,
		verifyPodcastPlaying     : false,
		verifyPlayHead			 : false,
		verifyUpNext			 : false,
		markAsUnplayed           : 0,
		verifyUIState            : '',
		prepAction		         : -1,
	});
	this.logStartingOptions(options);

	// Combine all the test podcast arrays of titles and URLs in to one array to be used to subscribe to all of them
	var allPodcastNames = [];
	var allPodcastURLs = [];
	var failureDict = null;
	UIALogger.logMessage('video length is %0, enhanced length is %1'.format(options.testVideoPodcastNames.length, options.testEnhancedPodcastNames.length));
	if (options.testAudioPodcastNames.length > 0) {
		UIAUtilities.assertEqual(
			options.testAudioPodcastNames.length,
			options.testAudioPodcastURLs.length,
			'testAudioPodcastNames and testAudioPodcastURLs do not have the same number of entries'
		);
		allPodcastNames.push.apply(allPodcastNames,options.testAudioPodcastNames);
		allPodcastURLs.push.apply(allPodcastURLs, options.testAudioPodcastURLs);
	}
	if (options.testVideoPodcastNames.length > 0) {
		UIAUtilities.assertEqual(
			options.testVideoPodcastNames.length,
			options.testVideoPodcastURLs.length,
			'testVideoPodcastNames and testVideoPodcastURLs do not have the same number of entries'
		);
		allPodcastNames.push.apply(allPodcastNames,options.testVideoPodcastNames);
		allPodcastURLs.push.apply(allPodcastURLs, options.testVideoPodcastURLs);
	}
	if (options.testEnhancedPodcastNames.length > 0) {
		UIAUtilities.assertEqual(
			options.testEnhancedPodcastNames.length,
			options.testEnhancedPodcastURLs.length,
			'testEnhancedPodcastNames and testEnhancedPodcastURLs do not have the same number of entries'
		);
		allPodcastNames.push.apply(allPodcastNames,options.testEnhancedPodcastNames);
		allPodcastURLs.push.apply(allPodcastURLs, options.testEnhancedPodcastURLs);
	}

	UIALogger.logMessage('allPodcastNames was %0'.format(allPodcastNames));
	UIALogger.logMessage('allPodcastURLs was %0'.format(allPodcastURLs));

	// Format the commands to include the options.testPodcastTitle if options.insertTitleInCommand is true
	if (options.insertPodcastInCommand) {
		for (var i = 0; i < options.commands.length; i++) {
			options.commands[i] = options.commands[i].format(options.testPodcastTitle);
		}
	} else if (options.insertEpisodeInCommand) {
		for (var d = 0; d < options.commands.length; d++) {
			options.commands[d] = options.commands[d].format(options.episodeName);
		}
	}

	springboard.unlock({passcode:options.passcode});
	this.quitOrKillApp();

	if (options.markAsUnplayed > 0) {
		this.launch();
		this.getToTab(TABS.MY_PODCASTS);
		var containerInfo = this.getPodcastContainerData(
			this.inspect(UIAQuery.tableCells().contains(options.testPodcastTitle)).label);

		if (parseInt(containerInfo.unplayedCount) < options.markAsUnplayed) {
			var episodes = this.generateEpisodeList({
				podcastTitle: options.testPodcastTitle,
				feed: true,
				needToNavigate: true,
				limit: options.markAsUnplayed,
			});
			this.setEpisodePlayState('Unplayed', episodes, {isInFeed: true});
		}
	}
	switch (options.testPrep) {
		case ('Setup'):
			// Set up by subscribing to several podcasts
			this.launch();
			this.getToTab(TABS.MY_PODCASTS);

			for (var j = 0; j < allPodcastNames.length; j++) {
				this.subscribeViaPlusSignToURL(
					allPodcastURLs[j],
					allPodcastNames[j],
					{verify:false, needToNav:false}
				);
			}
			this.waitForDownloadsToComplete(10);
			// Work around <rdar://problem/23466735> UIAApp quit() fails with only one app in the app switcher
			settings.launch();

			break;
		case ('No Prep'):
			UIALogger.logMessage('No Prep required');

			break;

		case ('With Episode Paused'):
			// Starts an episode playing and pauses it and then saves the episode title to options
			UIALogger.logMessage('Starting playback of an episode and pausing it');
			this.launch();
			options.episodeName = this.tapToPlayEpisodeInMyPodcasts(options.testPodcastTitle);
			this.getBackToStartOfEpisode();
			this.pause();
			var playPositionAtPause = CAMMediaRemote.getNowPlayingElapsedTime();

			break;

		case ('With Episode Playing'):
			UIALogger.logMessage('Starting an episode playing');
			this.launch();

			options.episodeName = this.tapToPlayEpisodeInMyPodcasts(options.testPodcastTitle);
			this.getBackToStartOfEpisode();

			break;

		case ('No Command'):
			this.launch();

			this.tapToPlayEpisodeInMyPodcasts(options.testPodcastTitle);
			this.getBackToStartOfEpisode();

			break;

		case ('With Episode Paused From Unplayed'):
			this.launch();

			options.episodeName = this.tapToPlayEpisodeInUnplayed();
			this.getBackToStartOfEpisode();
			this.pause();

			break;

		default:
			throw new UIAError('Test "%0" is not a valid test'.format(options.testPrep));
	}

	try {

		if (options.testPrep !== 'Setup') {
			// Actually perform the test
			var priorDS = -1;
			var changePasscode = null;
			var upNext = null;
			for (var ds = 0; ds < options.deviceStates.length; ds++) {
				for (var c = 0; c < options.commands.length; c++) {
					for (var as = 0; as < options.appStates.length; as++) {
						if (options.verifyUpNext) {
							upNext = this.generateUpNextList();
							if (options.exitNowPlaying) {
								this.tapIfExists(UIAQuery.Podcasts.NOW_PLAYING);
							}
						}
						this.siriLogTest(true, options.commands[c], options.appStates[as], options.deviceStates[ds]);
						failureDict = {
							command:options.commands[c],
							appState:options.appStates[as],
							deviceState:options.deviceStates[ds]
						};

						// If this is the first test run with a locked state, change the passcode settings. Otherwise,
						// don't change
						if (options.deviceStates[ds].contains('Locked') && ds > priorDS) {
							changePasscode = true;
						} else {
							changePasscode = false;
						}
						priorDS = ds;

						springboard.unlock({passcode: options.passcode});

						this.siriPrepForTest(
							options.appStates[as],
							options.deviceStates[ds],
							{passcode: '1111', changePasscode: changePasscode}
						);

						var siriClearWaiter = UIAWaiter.withPredicate(
							'ViewDidDisappear',
							'controllerClass = "SBAssistantRootViewController"'
						);
						// Delay just to keep things from getting ahead of themselves
						target.delay(1);

						this.issueSiriCommand(options.commands[c]);

						if (options.verifyPlaying) {
							UIALogger.logMessage('Verify playing');
							var query = UIAQuery.Podcasts.PLAY_CONFIRMED_BY_KIND.orElse(UIAQuery.Podcasts.PLAY_CONFIRMED_GENERAL);
							this.siriVerifySiriResponded(
								query,
								{
									additionalMessage: 'Command: %0, App State: %1, Device State: %2'.format(
										options.commands[c], options.appStates[as], options.deviceStates[ds])
								}
							);
							this.waitForPlayback(
								30,
								{errorMessage: 'Command: "%0" App State: "%1", Device State: "%2"'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])}
							);
							if (options.verifyPlayHead) {
								UIALogger.logMessage('Verify play head');
								var playPositionAfterCommand = CAMMediaRemote.getNowPlayingElapsedTime();

								UIALogger.logMessage('playPositionAfterCommand = %0, playPositionAtPause = %1'.format(
									playPositionAfterCommand, playPositionAtPause
								));
								// Verify play head is no more than 1 second away from where it should be
								UIAUtilities.assert(
									Math.abs(playPositionAfterCommand - playPositionAtPause) < 2,
									'Playhead is not where it was at pause'
								);
							}
							target.delay(1);
						}

						if (options.verifyNotPlaying) {
							UIALogger.logMessage('Verify not playing');
							this.siriVerifySiriResponded(
								UIAQuery.Podcasts.PAUSE_CONFIRMED,
								{
									additionalMessage: 'Command: %0, App State: %1, Device State: %2'.format(
										options.commands[c], options.appStates[as], options.deviceStates[ds])
								}
							);
							UIAUtilities.assert(
								!CAMMediaRemote.isMediaPlaying(),
								'Media is still playing. Command: %0, App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])
							);
						}

						if (options.openPodcasts) {
							UIALogger.logMessage('Open Podcasts');
							springboard.assertExists(
								UIAQuery.Podcasts.OPEN_PODCASTS,
								'Open Podcasts button does not exist'
							);

							springboard.tap(UIAQuery.Podcasts.OPEN_PODCASTS);
						}

						if (options.homeButton) {
							UIALogger.logMessage('Home button');
							target.clickMenu();
						}

						// Handle entering passcode if needed
						if (options.deviceStates[ds] === 'Locked With Passcode' && options.needUnlock) {
							UIALogger.logMessage('Unlocking');
							// Wait for passcode and then enter code
							UIAUtilities.assert(
								springboard.waitUntilPresent('Passcode field'),
								'Passcode entry did not appear after issuing Siri command'
							);
							// Make this just a bit more human by adding a delay
							target.delay(1);
							this.siriUnlockAfterSiri(options);
						}

						// Wait for siri to dismiss
						UIAUtilities.assert(
							siriClearWaiter.wait(60),
							'siri was never dismissed'
						);
						UIALogger.logMessage('Siri dismissed');

						if (options.verifyPausedAfterHome) {
							UIALogger.logMessage('Verify paused after home');
							// May not resume right away. Need to wait 2 seconds
							springboard.delay(2);
							this.verifyNotPlaying(
								{
									errorMessage: 'Not paused after pressing home. Command: %0, App State: %1, Device State: %2'.format(
										options.commands[c], options.appStates[as], options.deviceStates[ds])
								}
							);
						}

						if (options.verifyPlayingAfterHome) {
							UIALogger.logMessage('Verify playing after home');
							this.waitForPlayback(
								10,
								{
									errorMessage: 'Not playing after pressing home. Command: %0, App State: %1, Device State: %2'.format(
										options.commands[c], options.appStates[as], options.deviceStates[ds])
								}
							);
						}

						// Verify podcasts is still playing after opening
						if (options.openPodcasts && options.verifyPlaying) {
							UIALogger.logMessage('Verify still playing after Open Podcasts tapped');
							this.waitForPlayback(
								5,
								{
									errorMessage: 'Not playing after opening Podcasts. ' +
									'Command: "%0" App State: "%1", Device State: %2'.format(
										options.commands[c], options.appStates[as], options.deviceStates[ds])
								}
							);
						}

						if (options.verifyUIState !== '') {
							UIALogger.logMessage('Verify UI State');
							UIAUtilities.assertEqual(
								this.currentUIState(),
								options.verifyUIState,
								'Not in Now Playing after Siri command %0. App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])
							);
						}

						if (options.verifyPodcastPlaying) {
							UIALogger.logMessage('Verify podcast playing');
							this.assertExists(
								UIAQuery.query('MusicNowPlayingTitlesView').contains(options.testPodcastTitle),
								'The correct podcast is not playing');
						}

						if (options.verifyEpisodePlaying) {
							UIALogger.logMessage('Verify episode playing');
							this.assertExists(
								UIAQuery.query('MusicNowPlayingTitlesView').contains(options.episodeName),
								'The correct episode is not playing. Expected %0'.format(options.episodeName));
						}

						if (options.verifyUpNext) {
							UIALogger.logMessage('Verify Up Next');
							this.checkUpNextOrder(
								upNext,
								{additionaMessage:'Command: %0, App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])}
							);
						}

						if (options.verifyForeground) {
							UIALogger.logMessage('Verify Foreground');
							this.waitUntilReady();
							UIAUtilities.assert(
								this.stateDescription() === 'Foreground Running',
								'Podcasts not running in foreground. Command: %0, App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])
							);
						}

						if (options.verifyBackground) {
							UIALogger.logMessage('Verify Background');
							UIAUtilities.assert(
								this.stateDescription().contains('Background'),
								'Podcasts not running in background. Command: %0, App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])
							);
						}

						if (options.pauseBetween) {
							UIALogger.logMessage('Pause between');
							this.pause();
							playPositionAtPause = CAMMediaRemote.getNowPlayingElapsedTime();
						}

						if (options.exitNowPlaying) {
							UIALogger.logMessage('Exit Now Playing');
							this.tap(UIAQuery.Podcasts.NOW_PLAYING);
						}

						if (options.verifyRunning) {
							UIALogger.logMessage('Verify running');
							UIAUtilities.assertNotEqual(
								this.stateDescription(),
								'Terminated',
								'Podcasts was terminated. Command: %0, App State: %1, Device State: %2'.format(
									options.commands[c], options.appStates[as], options.deviceStates[ds])
							);
						}
						this.siriLogTest(false, options.commands[c], options.appStates[as], options.deviceStates[ds]);

						UIALogger.logMessage('options.deviceStates length = %0, options.appStates length = %1, options.commands length = %2'.format(
							options.deviceStates.length, options.appStates.length, options.commands.length
						));
						UIALogger.logMessage('ds = %0, as = %1, c = %2'.format(ds, as, c));
						if (options.prepAction !== -1 &&
							!(ds === options.deviceStates.length - 1 &&
							as === options.appStates.length - 1 &&
							c === options.commands.length - 1)
						) {
							UIALogger.logMessage('Prep action');
							switch (options.prepAction) {
								case (0) :
									// Defines the prepAction that runs between each test to:
									//	1. Unlock the device if needed
									//	2. Launch Podcasts
									//	3. If media is not playing, start playing again with mini player or start top episode of
									// options.testPodcastTitle playing
									UIALogger.logMessage('Making sure some podcast media is playing');
									springboard.unlock({passcode:options.passcode});
									podcasts.launch();

									if (!CAMMediaRemote.isMediaPlaying()) {
										if (this.exists(UIAQuery.Podcasts.PLAY_BUTTON_MINI.orElse(
											UIAQuery.Podcasts.PLAY_BUTTON))) {
											podcasts.tap(UIAQuery.Podcasts.PLAY_BUTTON_MINI.orElse(
												UIAQuery.Podcasts.PLAY_BUTTON
											));
										} else {
											podcasts.tapToPlayEpisodeInMyPodcasts(options.testPodcastTitle);
										}

										podcasts.waitForPlayback(5, {errorMessage:'Playback not resumed in between Siri tests'});
									}

									break;
								default:
									throw new UIAError('%0 does not reference a prepAction function that exists'.format(
										options.prepAction
									));
							}
						}
					}
				}
			}
		}
	} catch (e) {
		this.takeScreenShot(UIAScreenIdentifier.MAIN, 'siri_failure.png');
		UIALogger.logFail(e.message);
		UIALogger.logTAResults(failureDict);
		try {
			// Disable passcode and rethrow error
			springboard.unlock({passcode:options.passcode});
			settings.disablePasscode(options.passcode);
			if (CAMMediaRemote.isMediaPlaying) {
				this.quitOrKillApp();
			}
		} catch (e2) {
			UIALogger.logError('Failed to disable passcode. Error: %0'.format(e2.message));
		}
		throw e;
	}
};

/**
 * Sets a passcode and gets Podcasts in to the correct state for a specific siri test
 *
 * @param {Object} options - option dictionary
 * @param {string} appState - State the app should be in, Foreground, Background or Force Quit
 * @param {string} deviceState - State the device should be in, Locked No Passcode, Locked With Passcode, Unlocked
 * @param {string} [options.passcode="1111"] - Passcode to use to unlco the device or to set the device to use
 * @param {string} [options.oldPasscode="1111"] - Old passcode used when changing from one passcode to another
 * @param {bool} [options.changePasscode=false] - If true, goes through the process of changing passcode settings.
 * 		If false, keep current passcode settings
 *
 * 	@throws if device not put in to correct state
 */
podcasts.siriPrepForTest = function siriPrepForTest(appState, deviceState, options) {
	options = UIAUtilities.defaults(options, {
		passcode 	   : '1111',
		oldPasscode    : '1111',
		changePasscode : false,
	});
	// Get episode play state before setting up tests to verify it did not change later
	var playState = CAMMediaRemote.isMediaPlaying();

	if (options.changePasscode) {
		UIALogger.logMessage('Changing passcode settings');
		target.performTask('/usr/bin/killall', ['Preferences'], 5);
		target.delay(5);

		// Disable passcode first in case device already has a passcode. Device does not permit use of same password
		// twice so there is a possibility tests will fail if they try to change password to the same value
		UIALogger.logMessage('Disabling passcode');
		settings.disablePasscode(options.passcode);

		if (deviceState === 'Locked With Passcode') {
			UIALogger.logMessage('Enabling passcode %0'.format(options.passcode));
			settings.setPasscode(options.passcode, options.oldPasscode);
		}
	} else {
		UIALogger.logMessage('Not changing passcode settings');
	}

	switch (appState) {
		case ('Foreground'):
			UIALogger.logMessage('Launching app to Foreground');
			this.launch();
			break;

		case ('Background'):
			UIALogger.logMessage('Putting Podcasts in background');
			if (this.isActive()) {
				this.waitUntilReady();
				var backgroundWaiter = UIAWaiter.withPredicate(
					'ApplicationStateChanged',
					'bundleID == "com.apple.podcasts" AND state == "Background"'
				);
				target.clickMenu();
				UIAUtilities.assert(
					backgroundWaiter.wait(5),
					'Podcasts not backgrounded. State was "%0"'.format(this.stateDescription())
				);
			} else {
				UIALogger.logMessage('Podcasts already in background');
			}

			target.activeApp().waitUntilReady();
			break;
		case('Force Quit'):
			UIALogger.logMessage('Force quiting Podcasts');
			var quitWaiter = UIAWaiter.withPredicate(
				'ApplicationStateChanged',
				'bundleID == "com.apple.podcasts" AND state == "Terminated"'
			);
			this.quitOrKillApp();
			UIAUtilities.assert(
				quitWaiter.wait(60),
				'Podcasts not terminaret. State was "%0"'.format(this.stateDescription())
			);
			target.activeApp().waitUntilReady();
			break;

		default:
			throw new UIAError('"%0" is not a valid app state'.format(appState));
	}

	switch (deviceState) {
		case ('Locked No Passcode'):
		case ('Locked With Passcode'):
			springboard.lock();
			break;

		case ('Unlocked'):
			springboard.unlock(options);
			break;

		default:
			throw new UIAError('"0" is not a valid device state'.format(deviceState));
	}

	UIAUtilities.assertEqual(
		playState,
		CAMMediaRemote.isMediaPlaying(),
		'Play state changed after setting up for siri test'
	);

	target.delay(1);
	target.activeApp().waitUntilReady();
};

/**
 * Just used to log the start and end of siri testing to keep logging consitant throughout
 *
 * @param {bool} start - if true, starts the log with "****START" otherwise starts the message with "****END"
 * @param {string} command - Command given to Siri
 * @param {string} appState - State the app was in, Foreground, Barkground, Force Quit
 * @param {string} deviceState - State device was in, Locked No Passcode, Locked With Passcode, Unlocked
 */
podcasts.siriLogTest = function siriLogTest(start, command, appState, deviceState) {
	var leader;

	if (start) {
		leader = '****START ';
	} else {
		leader = '****END ';
	}

	UIALogger.logMessage(
		'%0 Siri test with command "%1" with Podcasts in "%2" and device "%3"****'.format(leader, command, appState, deviceState)
	);
};

/**
 * Enters the passcode after a siri command on a locked device. A waiter waiting for password prompt should be
 * executed before calling this
 *
 * @param {Object} options - Option dictionary
 * @param {string} [options.passcode="1111"] - Passcode to enter in to unlock device
 */
podcasts.siriUnlockAfterSiri = function siriUnlockAfterSiri(options) {
	options = UIAUtilities.defaults(options, {
		passcode : '1111'
	});

	for (var i = 0; i < options.passcode.length; i++) {
		springboard.tap(options.passcode[i]);
	}
};

/**
 * Verifies we got a response from Siri that indicated the correct action happened
 *
 * @param {UIAQuery} confirmationQuery - Query of item that should appear in siri after command is given
 * @param {Object} options - options dictionary
 * @param {number} [options.wait=60] - Number of seconds to wait for item to appear
 * @param {string} [options.additionalMessage=""] - Extra string to be appended to end of default log message
 *
 * @throws if item does not appear within "wait" seconds or if Siri indicates Podcasts isn't installed
 */
podcasts.siriVerifySiriResponded = function siriVerifySiriResponded(confirmationQuery, options) {
	options = UIAUtilities.defaults(options, {
		wait 			  : 60,
		additionalMessage : '',
	});
	UIALogger.logMessage('FUNCTION: siriVerifySiriResponded');
	this.logStartingOptions(options, 'confirmationQuery = "%0"'.format(confirmationQuery));

	UIAUtilities.assert(
		springboard.waitUntilAbsent(UIAQuery.Podcasts.SIRI_SUGGESTION, options.wait+5),
		'The Siri suggestions sheet never went away'
	);

	UIAUtilities.assert(
		springboard.waitUntilPresent(UIAQuery.Podcasts.SIRI_MESSAGE, options.wait),
		'No Siri responses appeared after %0 seconds'.format(options.wait)
	);

	this.takeScreenShot(UIAScreenIdentifier.MAIN, 'Siri_After_Command.png');
	var messageCount = springboard.count(UIAQuery.Podcasts.SIRI_MESSAGE);
	UIALogger.logMessage('messageCount = %0'.format(messageCount));
	var siriMessage = [];
	var siriAccessibilityItem = [];
	for (var i = 0; i < messageCount; i++) {
		siriMessage.push(springboard.inspectElementKey(UIAQuery.Podcasts.SIRI_MESSAGE.atIndex(i), 'label'));
		siriAccessibilityItem.push(springboard.inspectElementKey(UIAQuery.Podcasts.SIRI_MESSAGE.atIndex(i).parent(), 'identifier'));
	}
	UIALogger.logMessage('siriMessage = %0'.format(siriMessage));
	UIALogger.logMessage('siriAccessibilityItem = %0'.format(siriAccessibilityItem));

	// Because sometimes 2 of these show up, check for all error messages before checking for playback confirmation
	springboard.assertNotExists(
		UIAQuery.contains('playMedia#notInstalled'),
		'Siri indicated Podcasts was not installed. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('playMedia#nothingPlaying'),
		'Siri indicated nothing is playing. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('dynamicCannedDucs#canned$dalStop'),
		'Siri indicated nothing is available to be stopped. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('playMedia#noLibraryForType'),
		'Siri indicated no library is available to play back. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('timer#timerIsStopped'),
		'Siri indicated a timer was stopped. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('error#speechOtherFailure'),
		'Siri indicated she did not understand what was said. %0'.format(options.additionalMessage).trim()
	);
	springboard.assertNotExists(
		UIAQuery.contains('trouble with the connection'),
		'Siri indicated she was having issues with the connection'
	);
	springboard.assertExists(
		confirmationQuery,
		'Siri confirmation item did not appear. Unknown Siri error appeared. ' +
		'Siri messages were [%0] with accessibility items [%1]'.format(siriMessage, siriAccessibilityItem)
	);
};


/**
 * Subscribes to a podcast using a shared URL generated by the app. If already subscribed to the podcast, logs that
 * is subscribed but does not error
 *
 * @param podcast - name of podcast being subscribed to
 * @param URL - URL to use to subscribe to
 */
podcasts.subscribeToPodcastUsingSharedURL = function subscribeToPodcastUsingSharedURL(podcast, URL) {

	this.launch();
	this.getToTab(TABS.MY_PODCASTS);
	this.tap(UIAQuery.Podcasts.SHOWS_CELL);

	// If the podcast does not exist in shows, go through subscribing
	if (!this.exists(podcast)) {
        target.performTask('/usr/local/bin/LaunchApp', ['-url', URL]);

        // Wait for podcast offer button of one kind or the other to appear
        UIAUtilities.assert(
        	this.waitUntilPresent(UIAQuery.query('PodcastsUI.PodcastOfferButton'), 120),
			'PodcastOfferButton did not appear after 120 seconds'
		);

        // Verify the offer button is not a subscribe button
        this.assertNotExists(
        	UIAQuery.Podcasts.SUBSCRIBED,
			'Podcast is shown as already subscribed'
		);

        // Verify the offer button is a subscribe button
		this.assertExists(
			UIAQuery.Podcasts.SUBSCRIBE,
			'Subscribe button does not exist'
		);

		// Subscribe and wait for it to become Subscribed
		this.tap(UIAQuery.Podcasts.SUBSCRIBE);
        UIAUtilities.assert(
            this.waitUntilPresent(UIAQuery.Podcasts.SUBSCRIBED, 60),
            'Subscribed label did not appear after 60 seconds'
		);

        // Get to Shows and verifies the podcast is now listed there
        this.getToTab(TABS.MY_PODCASTS);
        this.tap(UIAQuery.Podcasts.SHOWS_CELL);
        UIAUtilities.assert(
        	this.waitUntilPresent(podcast),
			'Podcast did not appear in Shows'
		);
    } else {
		UIALogger.logMessage('Already subscribed');
	}
};

/***************************** CLOUD SYNC TESTS *****************************/
/**
 * Launches podcasts and waits for sync to complete. If null value for myPodcastsOrder it generates and adds the
 * order to the results dictionary. If it has some value then it compares the device it is running on to the list
 *
 * Expected state: Any, with Apple ID already logged in for the store
 *
 * @param {{}} options - Options dictionary
 * @param {string[]} options.myPodcastsOrder - Order of episodes in My Podcasts to compare
 * @param {bool} [options.verifyEpisode] - If true, verifies an episode list matches
 * @param {bool} [options.verifyStation] - If true, verifies a station exists and included episodes match
 * @param {string} [options.podcastTitle] - Name of podcast used for testing
 * @param {string} [options.stationName] - Name of station used for testing
 */
podcasts.cloudSyncLaunchAndVerify = function cloudSyncLaunchAndVerify (options) {
	options = UIAUtilities.defaults(options, {
		myPodcastsOrder : null,
		verifyEpisode   : false,
		verifyStation   : false,
		podcastTitle    : 'This American Life',
		stationName     : 'Cloud Sync Test Station',
	});

	UIALogger.logMessage('FUNCTION: cloudSyncLaunchAndVerify');
	this.logStartingOptions(options);

	UIAUtilities.assert(
		!options.verifyEpisode || !options.verifyStation,
		'verifyEpisode and verifyStation cannot both be true'
	);
	//Background podcasts if it is running
	if (this.isRunning()) {
		this.backgroundForeground();
	} else {
		this.launch();
	}

	UIALogger.logMessage('Waiting 15 seconds for sync to complete');
	this.delay(15);
	this.getToTab(TABS.MY_PODCASTS);

	if (options.verifyEpisode) {
		this.tap(UIAQuery.tableCells().contains(options.podcastTitle));

		this.checkEpisodeOrder(options.myPodcastsOrder, {podcastTitle:options.podcastTitle});

		// Verify play state after mark as unplayed setup test. Very brittle and will need to be changed if even
		// more tests are added
		if (options.myPodcastsOrder.length > 0) {
			this.verifyEpisodePlayState('Unplayed', options.myPodcastsOrder);
		}
	} else if (options.verifyStation) {
		UIAUtilities.assert(
			this.exists(UIAQuery.tableCells().children().contains(options.stationName)),
			'Station did not appear in My Podcasts after sync'
		);
		UIALogger.logMessage('Verified station appeared after sync');

		this.tap(UIAQuery.tableCells().children().contains(options.stationName));
		UIAUtilities.assert(
			this.waitUntilPresent(UIAQuery.navigationBars(options.stationName)),
			'Station was never drilled in to'
		);

		this.checkEpisodeOrder(options.myPodcastsOrder, {stationName:options.stationName});

		try {
			this.deleteFromMyPodcasts({toDelete:[options.stationName], needToNav:false});
		} catch (err) {
			UIALogger.logError('Could not delete station in cloud sync test, Error: %0'.format(err.message));
		}
	} else {
		if (options.myPodcastsOrder === null) {
			var podcastList = this.generateShowsList({needToNav: false});
			UIALogger.logTAResults({MyPodcastsList: podcastList});
		} else {
			this.checkMyPodcastsOrder(options.myPodcastsOrder);
		}
	}
};


/**
 * Subscribes to a podcast and then background and foregrounds app to sync
 *
 * @param options - options dictionary
 * @param [options.syncTestPodcastTitle="This American Life"] - Title of podcast to use
 * @param [options.syncTestPodcastURL] - URL of podcast to use for testing
 */
podcasts.cloudSyncSubscribeAndSync = function cloudSyncSubscribeAndSync(options) {
	options = UIAUtilities.defaults(options, {
		syncTestPodcastTitle : 'This American Life',
		syncTestPodcastURL   : PODCAST_URLS.This_American_Life,
	});

	UIALogger.logMessage('FUNCTION: cloudSyncSubscribeAndSync');
	this.logStartingOptions(options);

	//Subscribe to test podcast
	this.subscribeViaPlusSignToURL(options.syncTestPodcastURL, options.syncTestPodcastTitle, {needToNav:false});
	this.waitForDownloadsToComplete(5);

	// Work around <rdar://problem/24596697> After Deleting Episodes Via Edit, Adding Another Podcast Starts in Edit Mode
	this.tapIfExists(UIAQuery.Podcasts.DONE_NAVBAR);

	//Generate a list of all the podcasts in My Podcasts and add it to results dictionary
	var podcastList = this.generateShowsList({needToNav:false});
	UIALogger.logTAResults({MyPodcastsList:podcastList});

	this.backgroundForeground();
	//Put in 5 second delay which should be enough with automation overhead
	this.delay(5);
};

/**
 * Deletes and episode to test with cloud sync
 *
 * @param options - options dictionary
 * @param {string} [options.syncTestPodcastTitle="This American Life"] - Podcast title to use for testing
 */
podcasts.cloudSyncDeleteEpisodeAndSync = function cloudSyncDeleteEpisodeAndSync(options) {
	options = UIAUtilities.defaults(options, {
		syncTestPodcastTitle : 'This American Life'
	});

	UIALogger.logMessage('FUNCTION: cloudSyncDeleteEpisodeAndSync');
	this.logStartingOptions(options);
	this.launch();

	this.getToTab(TABS.MY_PODCASTS);

	this.tap(options.syncTestPodcastTitle);
	// Work around possibility that episode may not be Unplayed and may exist under the Played Episodes to be
	// Deleted Banner
	var episodeIndex = 0;
	if (this.exists(UIAQuery.Podcasts.PLAYED_TO_BE_DELETED) && !this.exists(UIAQuery.tableCells().contains('Unplayed'))) {
		episodeIndex = 1;
	}

	//Take the top most episode in the container to delete
	var title = this.getCleanedEpisodeTitle(this.inspectElementKey(
		UIAQuery.images().contains(options.syncTestPodcastTitle).siblings().andThen(UIAQuery.tableCells().atIndex(episodeIndex)),
		'label'
	));
	this.deleteEpisodeFromContainer(title);
	UIALogger.logTAResults({EpisodeTitle:title});

	var episodeList = this.generateEpisodeList({podcastTitle:options.syncTestPodcastTitle, needToNav:false});
	UIALogger.logTAResults({MyPodcastsList:episodeList});

	this.backgroundForeground();
	this.delay(5); //Give it a few seconds to complete sync
};


/**
 * Tests turning off subscribe and then syncing
 *
 * @param options - options dictionary
 * @param {string} [options.syncTestPodcastTitle="This American Life"] - Title of podcast to use for testing
 * @param {bool} [options.unsubscriber=false] - True if device is doing the unsubscribing, false otherwise
 */
podcasts.cloudSyncUnsubscribe = function cloudSyncUnsubscribe(options) {
	options = UIAUtilities.defaults(options, {
		syncTestPodcastTitle : 'This American Life',
		unsubscriber         : false,
	});

	UIALogger.logMessage('FUNCTION: cloudSyncUnsubscribe');
	this.logStartingOptions(options);

	this.launch();

	if (options.unsubscriber) {
		this.changePodcastSettings([options.syncTestPodcastTitle], {subscribed:false});
		this.backgroundForeground();
		this.delay(5);
	} else {
		this.backgroundForeground();
		this.delay(10);
		this.verifyPodcastSettings([options.syncTestPodcastTitle], {subscribed:false});
	}
};

/**
 * Maintenance to clean up a cloud account for testing. Makes sure one episode is marked as unplayed and that no
 * podcasts are subscribed
 *
 * @param {string} options.appleID - Apple ID to use to log in to the store
 * @param {string} options.appleIDPassword - Password for the account
 * @param {{}} options - options dictionary
 * @param {string} options.syncTestPodcastTitle - Title of podcast to be used for testing
 * @param {string} options.syncTestPodcastURL - URL for the podcast
 */
podcasts.cloudSyncCleanUp = function cloudSyncCleanUp (options) {
	options = UIAUtilities.defaults(options, {
		syncTestPodcastTitle : 'This American Life',
		syncTestPodcastURL   : PODCAST_URLS.This_American_Life,
		storeAppleID		 : null,
		storePassword        : null,
	});

	this.loginToService('Store', options.storeAppleID, options.storePassword);

	this.launch();
	this.getToTab(TABS.MY_PODCASTS);

	this.subscribeViaPlusSignToURL(options.syncTestPodcastURL, options.syncTestPodcastTitle, {needToNav:false});

	// Generate list of episodes in the unplayed tab of container and perform actions based on how many episodes are
	// present. If more than one, marks all but the top as played, if less than one it marks an episode as Unplayed
	this.tap(options.syncTestPodcastTitle);
	var episodeList = this.generateEpisodeList({podcastTitle:options.syncTestPodcastTitle, needToNavigate:false});
	if (episodeList.length > 1) {
		UIALogger.logMessage('More than one episode was found');
		var toMark = episodeList.slice(1,episodeList.length);

		for (var i = 0; i < toMark.length; i++) {
			this.deleteEpisodeFromContainer(toMark[i]);
		}
		this.backgroundForeground();
		this.delay(5);
	} else if (episodeList.length === 0) {
		UIALogger.logMessage('There were no episodes found');
		this.cloudSyncMarkAsUnplayedSync(options);
	} else {
		UIALogger.logMessage('Only 1 episode was found, as expected');
	}
	//Change subscribe setting to off
	this.changePodcastSettings([options.syncTestPodcastTitle], {subscribed:false});
	this.backgroundForeground();
	this.delay(5);

	// Delete everything from My Podcasts
	this.deleteFromMyPodcasts({deleteAll:true});
};


/**
 * Marks an episode as unplayed and generates a list to verify sync with another device. If not episode title is
 * passed in, marks the top most episode in the feed as Unplayed
 *
 * Expected starting state: My Podcasts
 *
 * @param options
 * @param {string} options.syncTestPodcastTitle - Title of podcast to use for testing
 * @param {string} options.title - Title of episode to be marked as unplayed
 */
podcasts.cloudSyncMarkAsUnplayedSync = function cloudSyncMarkAsUnplayedSync(options) {
	options = UIAUtilities.defaults(options, {
		syncTestPodcastTitle : 'This American Life',
		title				 : null
	});
	UIALogger.logMessage('FUNCTION: cloudSyncMarkAsUnplayedSync');
	this.logStartingOptions(options);

	this.launch();

	this.tap(options.syncTestPodcastTitle);
	this.tap('Feed');

	// If no title passed in get title of top most episode in feed and set Results dictionary value
	if (options.title == null) {
		options.title = this.getCleanedEpisodeTitle(
			this.inspectElementKey(UIAQuery.tableCells().contains('Played').topmost(), 'label'));
		UIALogger.logTAResults({EpisodeTitle:options.title});
	}
	// Change the play state then go back to the Unplayed tab in the container and generate a list of items to
	// compare and then add that list to the results dictionary
	this.setEpisodePlayState('Unplayed', [options.title], {isInFeed:true});
	this.setControl(UIAQuery.query('UISegmentedControl'), 'Unplayed');
	var episodeList = this.generateEpisodeList({podcastTitle:options.syncTestPodcastTitle});

	// Assert the list has at least 1 item
	UIAUtilities.assert(episodeList.length > 0, 'episodeList had a length of 0. Manual test account repair may be' +
		' required');
	UIALogger.logTAResults({MyPodcastsList:episodeList});

	this.backgroundForeground();
	// Give it time to sync
	this.delay(5);
};

/**
 * Creates a station and syncs to iCloud
 *
 * @param options - options dictionary
 * @param {string} [options.stationName] - Name for the station
 */
podcasts.cloudSyncCreateStationAndSync = function cloudSyncCreateStationAndSync (options) {
	options = UIAUtilities.defaults(options, {
		stationName : 'Cloud Sync Test Station'
	});
	UIALogger.logMessage('FUNCTION: cloudSyncCreateStationAndSync');
	this.logStartingOptions(options);

	this.launch();
	this.getToTab(TABS.MY_PODCASTS);
	this.createStation(options.stationName, {includeAll:true});
	this.waitUntilPresent(UIAQuery.tableCells().children().contains(options.stationName));

	// Navigate in to container
	this.tap(UIAQuery.tableCells().children().contains(options.stationName));
	// Generate list of episodes in the station and log to TA results
	var episodeList = this.generateEpisodeList(options);
	UIALogger.logTAResults({MyPodcastsList:episodeList});

	this.backgroundForeground();
	// Give time to sync
	this.delay(5);
};

/**
 * Makes sure no podcast has more than "numUnplayed" unplayed episodes and syncs back to the cloud
 *
 * @param {Object} options - options dictionary
 * @param {num} [options.numUnplayed=2] - Number of unplayed episodes to have for each podcast
 * @param {string} [options.appleID="ottoiqlaunchtest1@icloud.com"] - Store account to clean
 * @param {string} [options.appleIDPassword="podIQ6616"] - Password for store account
 */
podcasts.cloudSyncCleanUpAccount = function cloudSyncCleanUpAccount(options) {
	options = UIAUtilities.defaults(options, {
		numUnplayed     : 2,
		appleID         : 'ottoiqlaunchtest1@icloud.com',
		appleIDPassword : 'podIQ6616',
	});

	UIALogger.logMessage('FUNCTION: cloudSyncCleanUpAccount');
	this.logStartingOptions(options);

	this.loginToService('Store', options.appleID, options.appleIDPassword);

	this.launch();

	this.waitUntilReady();
	// Wait 2 minutes for database to be pulled down fully
	this.delay(120);

	this.getToTab(TABS.MY_PODCASTS);

	var podcastCount = this.count(UIAQuery.tableCells().contains('unplayed'));
	var podcastsToMark = [];

	// Find all podcasts with more than <options.numUnplayed> unplayed episodes
	for (var i = 0; i < podcastCount; i++) {
		var tableCellInfo = this.getPodcastContainerData(this.inspect(UIAQuery.tableCells().contains('unplayed').atIndex(i)).label);
		var unplayedCount = parseInt(tableCellInfo.unplayedCount);
		if (unplayedCount > options.numUnplayed) {
			UIALogger.logMessage('Adding "%0" to podcastsToMark'.format(tableCellInfo.title));
			podcastsToMark.push(tableCellInfo.title);
		} else {
			UIALogger.logMessage('Not adding "%0" to podcastsToMark'.format(tableCellInfo.title));
		}
	}

	// Mark any episodes above <option.numUnplayed> as played
	for (var k = 0; k < podcastsToMark.length; k++) {
		if (!iPad) {
			this.getToTopLevelCurrentTab(TABS.MY_PODCASTS);
		}

		var toMark = [];
		this.scrollEpisodeCellToVisible(podcastsToMark[k]);
		this.tap(UIAQuery.tableCells().contains(podcastsToMark[k]));
		this.waitUntilPresent(UIAQuery.Podcasts.PODCAST_SETTINGS);
		var episodeList = this.generateEpisodeList({podcastTitle:podcastsToMark[k]});
		while (episodeList.length > options.numUnplayed) {
			toMark.push(episodeList.pop());
		}

		this.setEpisodePlayState('Played', toMark);
	}

	this.backgroundForeground();
};

/* HELPER FUNCTIONS */

/**
 * Advances playhead to within options.min number of minutes from the end. Not extremely precise. Do not rely on
 * being exactly options.min number of minutes from the end
 *
 * Expected Starting State: A podcast is in the Now Playing queue with Podcasts in the foreground. Podcast does not
 * have to be playing back
 *
 * @param {Object} options - options dictionary
 * @param {number} [options.min=5] - Number of minutes from end to position playhead. Not precise.
 */
podcasts.advanceNearEndOfEpisode = function advanceNearEndOfEpisode(options) {
	options = UIAUtilities.defaults(options, {
		min : 5
	});

	this.getToNowPlaying();

	// Calculate timeRemaining
	var timeRemaining = CAMMediaRemote.getNowPlayingDuration() - CAMMediaRemote.getNowPlayingElapsedTime();
	UIALogger.logMessage('timeRemaining = %0'.format(timeRemaining));

	// Remove min * 60 number of seconds from timeRemaining
	timeRemaining -= options.min * 60;
	// Set timeRemaining to floor of timeRemaining
	timeRemaining = Math.floor(timeRemaining);
	UIALogger.logMessage('timeRemaining before calculating taps = %0'.format(timeRemaining));

	// Calculate number of taps and take floor
	var timesToTap = Math.floor(timeRemaining / 15);
	// Set timesToTap to 1 if not greater than 1
	if (timesToTap < 2) {
		timesToTap = 1;
	}

	this.tap(UIAQuery.Podcasts.FF15_BUTTON, {tapCount:timesToTap});
};


/**
 * Makes changes to a passed in array without mutating original. Function will add entries to the end of the array,
 * replace entries in the array with a different value, overwrite it completely or remove entries.
 *
 * @param {Array} toChange - Array to change
 * @param {Object} changes - Dictionary of changes to make. See below for usage example
 * @returns {Array}
 *
 * Removing Items:
 * 	To remove an item pass it is as the value of the key 'remove'. To remove multiple items, pass them in as the value
 * 	of remove separate by ', '
 * 	Example:
 * 		test = ['a', 'b', 'c']
 * 		arrayUpdater(test, {remove:'a'}) --> ['b', 'c']
 *		arrayUpdater(test, {remove:'a, c'}) --> ['b']
 *
 * Adding Items:
 * 	To add an item pass it in as the value of the key 'add'. To add multiple items, pass them in as the value of
 * 	'add' but separated by ', '
 * 	Example:
 * 		test = ['a', 'b', 'c']
 * 		arrayUpdater(test, {add:'d'}) --> ['a', 'b', 'c', 'd']
 * 		arrayUpdater(test, {add:'d, e'} --> ['a', 'b', 'c', 'd','e']
 *
 * Replacing Items:
 * 	To replace an item, pass it in as the value of the key 'replace' in the format <to replace>, <replace with>. If
 * 	replacing multiple items, seperate out each of the passed in items by ';'
 * 	Example:
 * 		test = ['a', 'b', 'c']
 * 		arrayUpdater(test, {replace:'a, d'}) --> ['d', 'b', 'c']
 * 		arrayUpdater(test, {replace:'a, d;c, e'}) --> ['d', 'b', 'e']
 *
 * Overwriting:
 * 	To overwrite the array simply pass in the new array as the value of the key 'overwrite'
 * 	Example:
 * 		test = ['a', 'b', 'c']
 * 		arrayUpdater(teat, {overwrite:['d', 'e', 'f']) --> 	['d', 'e', 'f']
 */
podcasts.arrayUpdater = function arrayUpdater (toChange, changes) {
	// Get keys of changes
	var keys = Object.keys(changes);
	var toReturn = toChange.slice();

	for (var i = 0; i < keys.length; i++) {
		switch (keys[i]) {

			case 'remove':
				var toRemove = [];
				toRemove.push(changes.remove);
				if (toRemove[0].contains(', ')) {
					toRemove = toRemove [0].split(', ');
				}
				for (var m = 0; m < toRemove.length; m++) {
					toReturn.splice(toReturn.indexOf(toRemove[m]), 1);
				}
				break;

			case 'add':
				var toAdd = [];
				toAdd.push(changes.add);
				if (toAdd[0].contains(', ')) {
					toAdd = toAdd[0].split(', ');
				}

				for (var k = 0; k < toAdd.length; k++) {
					toReturn.push(toAdd[k].trim());
				}
				break;

			case 'replace':
				var toReplace = [];
				toReplace.push(changes.replace);
				if (toReplace[0].contains(';')) {
					toReplace = toReplace[0].split(';');
				}

				for (var r = 0; r < toReplace.length; r++) {
					var replacement = toReplace[r].split(', ');
					toReturn[toReturn.indexOf(replacement[0])] = replacement[1];
				}
				break;

			case 'overwrite':
				toReturn = changes.overwrite;
				break;

			default:
				throw new UIAError('%0 is not a valid change'.format(changes.keys[i]));
		}
	}
	UIALogger.logMessage('toReturn was %0'.format(toReturn));
	return toReturn;
};

/**
 * Takes in the value from an episode cell representing the time remaining and returns a representation of that in
 * 		seconds
 *
 * @param {string} time - Time remaining value from an episode cell
 *
 * @returns {number} - Time remaining of episode in seconds
 */
podcasts.convertTimeRemaining = function convertTimeRemaining(time) {
	UIALogger.logMessage('FUNCTION: convertTimeRemaining with time = %0'.format(time));

	// Split the time remaining value on spaces
	var splitTime = time.split(' ');
	var toReturn = 0;

	for (var i = 0; i < splitTime.length; i++) {

		// Break if "remaining" is the value being referenced
		if (splitTime[i] === 'remaining') {
			UIALogger.logMessage('Reached "remaining", break loop');
			break;
		}

		if (splitTime.indexOf('min') !== -1 || splitTime.indexOf('hr') !== -1 || splitTime.indexOf('sec') !== -1) {
			UIALogger.logMessage('"hr", "min" or "sec" found in splitTime');
			UIALogger.logMessage('splitTime[%0] was %1'.format(i, splitTime[i]));
			UIALogger.logMessage('splitTime[%0] was %1'.format(i + 1, splitTime[i + 1]));

			if (splitTime[i + 1] === 'hr') {
				toReturn = toReturn + parseInt(splitTime[i]) * 60 * 60;
				// Increment i manually so it will start at the next number
				i++;
			} else if (splitTime[i + 1] === 'min') {
				toReturn = toReturn + parseInt(splitTime[i]) * 60;
			} else if (splitTime [i + 1] === 'sec') {
				toReturn = toReturn + parseInt(splitTime[i]);
			}
		} else {
			UIALogger.logMessage('"hr", "min" or "sec" not found in splitTime');
			UIALogger.logMessage('splitTime[%0] was %1'.format(i, splitTime[i]));

			if (splitTime[i].indexOf('h') !== -1) {
				toReturn = toReturn + parseInt(splitTime[i]) * 60 * 60;
			} else if (splitTime[i].indexOf('m') !== -1) {
				toReturn = toReturn + parseInt(splitTime[i]) * 60;
			} else if (splitTime[i].indexOf('s') !== -1) {
				toReturn = toReturn + parseInt(splitTime[i]);
			}
		}
	}
	UIALogger.logMessage('toReturn = %0'.format(toReturn));

	return toReturn;
};

/**
 * Deletes an episode from a container by swiping or via edit
 *
 * @param {string} episodeTitle - Episode to delete
 * @param options - options dictionary
 * @param {string} [options.method="edit"] - Either edit or swipe to indicate which way to delete the episode
 *
 * @throws if episode is not deleted
 */
podcasts.deleteEpisodeFromContainer = function deleteEpisodeFromContainer(episodeTitle, options) {
	options = UIAUtilities.defaults(options, {
		method : 'edit'
	});

	UIALogger.logMessage('FUNCTION: deleteEpisodeFromContainer');
	this.logStartingOptions(options, 'episodeTitle was %0'.format(episodeTitle));

	options.method = options.method.toLowerCase();
	if (options.method !== 'edit' && options.method !== 'swipe') {
		throw new UIAError ('Must enter edit or swipe as a method to delete episodes');
	}

	switch (options.method) {
		case 'edit':
			this.tap(UIAQuery.Podcasts.EDIT_NAVBAR.rightmost());

			this.tap(UIAQuery.tableCells().contains(episodeTitle));
			this.tap('Delete');
			this.tapIfExists(UIAQuery.Podcasts.DONE_NAVBAR);
			break;
		case 'swipe':
			this.swipeLeftOnTableCell(episodeTitle, 'Delete');
			this.tap('Delete');
			break;
	}
	//Verify episode deleted
	this.assertNotExists(UIAQuery.tableCells().contains(episodeTitle), '%0 was not deleted'.format(episodeTitle));
};


/**
 * Returns a dictionary compatible with changeAppSettings and verifyAppSettings with all the values found in the
 * settings app for Podcasts.
 *
 * @returns {{}} - Dictionary containing all the settings found in the Settings app for Podcasts
 */
podcasts.getAppSettings = function getAppSettings() {
	UIALogger.logMessage('FUNCTION: getAppSettings');

	var toReturn = {};

	// Create a local copy of the notification navigation array to work around <rdar://problem/24827952>
	// settings.chooseSetting Destroys the Array Passed in to It
	var localNotificationNav = SETTINGS_NAV_ARRAYS.notifications.slice();

	// Get all values from the Notifications sub menu
	// Navigate to the settings page for notifications
	settings.chooseSetting(localNotificationNav);
	toReturn['allowNotifications'] = settings.valueOf(UIAQuery.switches('Allow Notifications'));
	UIALogger.logMessage(toReturn.allowNotifications);
	if (toReturn.allowNotifications) {
		UIALogger.logMessage('BUT IT IS NOT TRUE');
	}

	// Doesn't check for other values in settings if Allow Notifications is off because it hides the other settings
	if (toReturn.allowNotifications === true) {
		UIALogger.logMessage('But I already showed this is not true');
		toReturn['showInNotificationCenter'] = settings.valueOf(UIAQuery.switches('Show in Notification Center'));
		toReturn['badgeAppIcon'] = settings.valueOf(UIAQuery.switches('Badge App Icon'));
		toReturn['showOnLockScreen'] = settings.valueOf(UIAQuery.switches('Show on Lock Screen'));
		toReturn['alertStyle'] = settings.inspect(
			UIAQuery.tableCells('Select notification style').children().isSelected()).label;
	}

	// Navigate back to the podcasts menu
	settings.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);

	// Get Cellular Data value if the option exists
	if (settings.exists(UIAQuery.switches('Cellular Data'))) {
		toReturn['cellularData'] = settings.valueOf(UIAQuery.switches('Cellular Data'));
	}

	// Get Background App Refresh setting
	toReturn['backgroundAppRefresh'] = settings.valueOf(UIAQuery.switches('Background App Refresh'));

	// Get Sync Podcasts setting
	toReturn['syncPodcasts'] = settings.valueOf(UIAQuery.switches('Sync Podcasts'));

	// Get Only Download on Wi-Fi setting
	toReturn['onlyDownloadOnWifi'] = settings.valueOf(UIAQuery.switches('Only Download on Wi-Fi'));

	// Get Refresh Every setting
	settings.tap(UIAQuery.tableCells('Refresh Every'));
	toReturn['refreshEvery'] = settings.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost(), 'label');
	settings.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);

	// Get Limit Episodes setting
	settings.tap(UIAQuery.tableCells('Limit Episodes'));
	toReturn['limitEpisodes'] = settings.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost(), 'label');
	settings.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);

	// Get Download Episodes setting
	settings.tap(UIAQuery.tableCells('Download Episodes'));
	toReturn['downloadEpisodes'] = settings.inspectElementKey(UIAQuery.tableCells().isSelected().rightmost(), 'label');
	settings.tap(UIAQuery.Podcasts.BACK_NAV_BUTTON);

	// Get Delete Played Episodes setting
	toReturn['deletePlayedEpisodes'] = settings.valueOf(UIAQuery.switches('Delete Played Episodes'));

	// Get Custom Colors setting
	toReturn['customColors'] = settings.valueOf(UIAQuery.switches('Custom Colors'));

	UIALogger.logMessage('Completed getAppSettings');
	return toReturn;
};


/**
 * Gets back to the start of the episode that is playing
 *
 * Expected Starting State: Episode in Now Playing. Do not need to be in Now Playing
 */
podcasts.getBackToStartOfEpisode = function getBackToStartOfEpisode() {
	UIALogger.logMessage('FUNCTION: getBackToStartOfEpisode');

	this.launch();
	this.getToNowPlaying();

	// Calculate time advanced in to episode
	var timeAdvanced = CAMMediaRemote.getNowPlayingElapsedTime();
	UIALogger.logMessage('timeAdvanced = %0'.format(timeAdvanced));

	var tapCount = Math.ceil(timeAdvanced / 15);
	UIALogger.logMessage('tapCount = %0'.format(tapCount));

	this.tap(UIAQuery.Podcasts.REW15_BUTTON, {tapCount:tapCount});
};


/**
 * Takes in a string of the format HH:MM:SS or similar and returns the number of seconds it represents
 *
 * @param value - String from this.valueOf('Track Position') of just the time in format HH:MM:SS
 * @returns {number} - Number of seconds the time represents
 */
podcasts.getSecondsFromTrackPosition = function getSecondsFromTrackPosition(value) {
	UIALogger.logMessage('FUNCTION: getSecondsFromTrackPosition with value = %0'.format(value));

	// Split on the : to get individual numbers
	var split = value.split(':');
	var hourSeconds = 0;
	var minuteSeconds = 0;
	var seconds = 0;
	if (split.length === 3) {
		hourSeconds = parseInt(split[0]) * 60 * 60;
		minuteSeconds = parseInt(split[1]) * 60;
		seconds = parseInt(split[2]);
	} else if (split.length === 2) {
		minuteSeconds = parseInt(split[0]) * 60;
		seconds = parseInt(split[1]);
	} else if (split.length === 1) {
		seconds = parseInt(split[0]);
	} else {
		throw new UIAError('Expected length of 3, 2, or 1 and did not find it');
	}
	return hourSeconds + minuteSeconds + seconds;
};


/**
 * Removes fullDate entries from an array of episode dictionaries with episode date to work around
 * 		<rdar://problem/24936639> Though an Item is Able to be Stringified, it is Skipped From Being Added to the Results
 * 		Dictionary
 * @param toChange - Array to remove fullDate entries from
 */
podcasts.removeFullDates = function removeFullDates(toChange) {
	UIALogger.logMessage('FUNCTION: removeFullDates');

	for (var i = 0; i < toChange.length; i++) {
		delete toChange[i]['fullDate'];
	}
};


/**
 * Sets the ITMS environment of the device. To reset to production pass in 'prod'
 *
 * Expected state: Any
 *
 * @param {string} environment - Environment to connect to. Enter itms# where # is the number to connect to
 *
 * @returns none
 * @throws if the environment is not set correctly
 */
podcasts.setITMSEnvironment = function setITMSEnvironment (environment) {
	UIALogger.logMessage('FUNCTION: setITMSEnvironment, environment was %0'.format(environment));

	settings.launch();
	settings.returnToTopLevel();

	if (environment === 'prod') {
		environment = 'Reset to Production';
	}

	settings.tap('Internal Settings');
	settings.tap('Server Environments');
	UIAUtilities.assert(settings.waitUntilPresent('iTunes', 10), 'Server environments list did not load');
	settings.tap('iTunes');

	if (environment !== 'Reset to Production') {
		settings.handlingAlertsInline(UIAQuery.alerts('Related Environments'), function () {
			settings.tap(environment);
			settings.tap('Not Now');
		});
	} else {
		settings.tap(environment);
	}

	if (environment !== 'Reset to Production') {
		settings.assertExists(UIAQuery.query(environment).isSelected(), 'ITMS environment not selected');
	} else {
		settings.delay(.5);
		settings.assertNotExists(
				UIAQuery.query('itms5').parent().children().isSelected(),
				'Environment still selected');
	}

	this.quitOrKillApp({errorDetail:'Failed to quit Podcasts after changing ITMS environment'});

	UIALogger.logMessage('ITMS Environment set');
};

/**
 * Function to set up Notes by moving past the splash screen. Not complete and tested
 */
podcasts.setupNotes = function setupNotes() {
	UIALogger.logMessage('FUNCTION: setupNotes');

	var app = target.appWithBundleID('com.apple.mobilenotes');

	app.launch();

	if (app.waitUntilPresent(UIAQuery.buttons('Continue'), 10)) {
		app.tap('Continue');
	} else {
		UIALogger.logWarning('Continue button did not appear to setup Notes after 10 seconds');
	}

	if (app.waitUntilPresent(UIAQuery.navigationBars('Notes'), 10)) {
		UIALogger.logMessage('Notes finished setting up');
	} else {
		UIALogger.logWarning('Notes did not complete setting up');
	}
};

