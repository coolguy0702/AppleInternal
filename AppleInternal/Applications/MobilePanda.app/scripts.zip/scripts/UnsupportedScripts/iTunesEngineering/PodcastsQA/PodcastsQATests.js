load('UIATesting.js');
load('PodcastsQA.js');

UIAUtilities.assert(
  typeof PodcastsQATests === 'undefined',
  'PodcastsQA has already been defined.'
);

/**
 * @namespace Podcasts
 */
var PodcastsQATests = {

	/**
	 * Podcasts QA. Launch Podcasts and Verify Tabs are present
	 * Assumes: first-time launch, or no podcasts are present
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object}	args - Test arguments
	 * @param {boolean}	[args.verify=true] - If set we verify elements and
	 *                  	contents of tabs/views.
	 * @param {boolean}	[args.noPodcasts=true] - If true, verify that there are
	 *                   	no podcasts or episodes in the app.
	 *						used mostly for first-time launch tests
	 * @param {int}  	[args.waitToLoadTime=122] - Defaults to global WAIT_TIME Max time to wait for view or store page
	 *                   	to load.  0 = don't wait.  Store pages can take widely
	 *						varying times to load.
	 */
	launchAndVerifyTabs: function launchAndVerify(args) {
		args = UIAUtilities.defaults(args, {
			verify:			true,
			noPodcasts:		true,
			waitToLoadTime:	WAIT_TIME,
		});

		podcasts.logStartingOptions(args);
		podcasts.quitOrKillApp();
		UIALogger.logMessage('Launch Podcasts');
		podcasts.launch();
		podcasts.delay(5);  // BUG
		podcasts.waitForAnimations(); // New: iPad seems to take awhile to draw UI
		var bundleVersion = podcasts.bundleVersion();
		UIALogger.logMessage('***Podcast bundle version was %0'.format(bundleVersion));
		UIALogger.logTAResults({PodcastsBundleVersion:bundleVersion});

		var tabsArray = ['Listen Now', 'Library', 'Browse', 'Search'];

		for (var tab in tabsArray) {
		  UIALogger.logMessage("Testing Tab " + tabsArray[tab]);
		  podcasts.getToTab(tabsArray[tab], args);
  		}
	},

    /**
     * Podcasts QA. Change the Podcasts UI setting to New UI
     */
    enableNewUI: function launchAndVerify(args) {
        podcasts.changeAppSettings({newUI:true});
    },

    /**
	 * Podcasts QA. Checks that the welcome screen is shown at launch and then clears it. Then it verifies it is not shown
     */
    checkAndClearWelcomeScreen: function checkAndClearWelcomeScreen() {
    	podcasts.checkAndClearWelcomeScreen();
	},

    /**
	 * Subscribes to a podcast using a shared URL
	 *
     * @param {object} args - Test arguments
	 * @param {string} [args.podcast="Hello Internet"] - Name of podcast to subscribe to
	 * @param {string} [args.sharedURL] - Shared URL of the podcast to be subscribed to
     */
    subscribingWithSharedURL: function subscribingWithSharedURL(args) {
    	args = UIAUtilities.defaults(args, {
    		podcast : 'Hello Internet',
			sharedURL : PODCAST_SHARED_URLS.Hello_Internet,
		});
        podcasts.subscribeToPodcastUsingSharedURL(args.podcast, args.sharedURL);
    },

	/**
	 * Podcasts QA. Subscribe to multiple podcasts using the Add button and URL's
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string[]} [args.podcastURLs] - Array of podcast URLs to subscribe to
	 * @param {string[]} [args.podcastTitles] - Array of titles index matched to podcastURLs
	 */
	subscribeToMultiplePodcasts: function subscribeToMultiplePodcasts(args) {
		args = UIAUtilities.defaults(args, {
			podcastURLs   : [PODCAST_URLS.Car_Talk, PODCAST_URLS.TEDTalks_video],
			podcastTitles : ['Car Talk',            'TED Talks Daily'],
		});

		podcasts.logStartingOptions(args);

		UIALogger.logMessage('SUBCRIBE TO MULTIPLE PODCASTS...');
		podcasts.testSubscribeToMultiple({
			podcastURLs:    args.podcastURLs,
			podcastTitles:  args.podcastTitles,
			waitToDownload: true,
			verify:			true,
		});
	},

	/**
	 * PodcastsQA. Tests subscribing via plus sign to a URL and verifies it was subscribed
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {Object} args - argument dictionary
	 * @param {string} [args.podcastTitle="Car Talk"] - Name of the podcast to be subscribed to
	 * @param {string} [args.podcastURL=""] - URL of podcast to be subscribed to
	 * @param {bool} [args.needToNav=true] - If My Podcasts should be navigated to
	 * @param {bool} [args.verify=true] - If true, verifies the podcast is subscribed in settings
     */
	subscribeViaPlusSign: function sunbscribeViaPlusSign(args) {
		args = UIAUtilities.defaults(args, {
			podcastsTitle : 'Car Talk',
			podcastURL    : '',
			needToNav	  : true,
			verify		  : true,
		});

		if (args.podcastURL === '') {
			args.podcastURL = PODCAST_URLS.Car_Talk;
		}

		podcasts.subscribeViaPlusSignToURL(args.podcastURL, args.podcastTitle, args);
	},

	/**
	 * Podcasts QA. Subscribe to a Podcast through Search
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.podcastSearchTitle="Hello Internet"] - Required name of the podcast to subscribe to
	 * @param {int} [args.waitToLoadTime=122] - Time to wait for store pages to load. Default is 122 seconds
	 */
	searchAndSubscribe: function searchAndSubscribe(args) {
		args = UIAUtilities.defaults(args, {
				podcastSearchTitle: 'Hello Internet',
				waitToLoadTime: 122,
			});

		podcasts.logStartingOptions(args);
		podcasts.subscribeFromSearch(args.podcastSearchTitle, args);
		//podcasts.verifySubscription(args.podcastSearchTitle);
		podcasts.verifyPodcastSettings([args.podcastSearchTitle], {verifyDefaults: true});
		// verify download as well
	},

	/**
	 * Podcasts QA. Launch app and pass in a Feed URL
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.feedURL] - Required URL of the feed to subscribe to
	 */
	launchAndSubscribeByURL: function launchAndSubscribeByURL(args) {
		args = UIAUtilities.defaults(args, {feedURL: PODCAST_URLS.Fresh_Air});

		podcasts.logStartingOptions(args);
		UIALogger.logMessage("Launch and subscribe by URL: " + args.feedURL );
		podcasts.subscribeToPodcastUsingURL(args);

	},

	/**
  * Podcasts QA. Test all UI elements in Now Playing
  *	as well as media playback
  *
  * @targetApps Podcasts, itunesstored, medialibraryd
  *
  * @param {{}} options - Options dictionary
  * @param {string[]} options.audioTitle - Array of titles of audio podcasts, should be index matched with
  * options.audioURL
  * @param {string[]} options.audioURL - Array of audio podcast URLs, should be index matched with options.audioTitle
  * @param {string[]} options.videoTitle - Array of titles of video podcasts, should be index matched with
  * options.videoURL
  * @param {string[]} options.videoURL - Array of video podcast URLs, should be index matched with options.videoTitle
  *
  * @returns none
  * @throws if there is an error in playback
  */
	quickLookNowPlaying: function quickLookNowPlaying(options) {
		UIALogger.logMessage('TEST: Quick Look Now Playing');
		options = UIAUtilities.defaults(options, {
			audioTitle : ['Car Talk'],
			videoTitle : ['TEDTalks Business'],
		});
		podcasts.quitOrKillApp({errorDetail:'Failed to quit Podcasts at start of Now Playing test'});
		var epTitleArray = [];
		var episodeToTap = null;
		var fail = false;
		var errorString = '';
		podcasts.launch();
		var episodes = options.audioTitle.concat(options.videoTitle); // was const
		for (var title of episodes) {
			podcasts.subscribeFromSearch(title);
		}
		
		podcasts.waitForDownloadsToComplete();

		// loop through each Audio podcast and test Now Playing
		for (title of episodes) {
		  UIALogger.logMessage("TEST NOW PLAYING: %0".format(title));
		  podcasts.getToTab(TABS.LIBRARY);
		  podcasts.tap(UIAQuery.Podcasts.SHOWS_CELL);
		  try {
			//.tapToPlayEpisodeInMyPodcasts(title); // todo - use then when it works
			podcasts.tap(UIAQuery.contains(title));
			episodeToTap = podcasts.inspect(UIAQuery.query("PodcastsUI.EpisodeView")).label;
			epTitleArray = episodeToTap.split(', ');
			episodeToTap = epTitleArray[1]; //the string after the date
			podcasts.tap(UIAQuery.query("PodcastsUI.EpisodeView").andThen(UIAQuery.contains(episodeToTap)));
			podcasts.tap(UIAQuery.Podcasts.CONTAINER_QUICKPLAY);
			podcasts.getToNowPlaying();
			podcasts.testNowPlayingUI({currentEpisode: episodeToTap});
			podcasts.testMiniPlayerUI();
		  } catch (err) {
			UIALogger.logError('Now Playing episode test failed with error %0\n'.format(err.message));
			errorString = errorString + err.message + ' ';
			fail = true;
		  }
		}
	
		if (fail) {
		  throw new UIAError (errorString);
		}
		return true;
  },

	/**
	 * Podcasts QA. Test streaming from the store
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {{}} args - arguments dictionary
	 * @param {number} [args.streamTime=30] - Time to stream from the store
	 *
     */
	quickLookStreamFromStore: function quickLookStreamFromStore(args) {
		UIALogger.logMessage('TEST: Quick Look Stream From Store');
		args = UIAUtilities.defaults(args, {
			streamTime : 30
		});
		podcasts.testStreamFromStore(args);
  },

  	/**
	 * Podcasts QA. Quicklook all store categories in Featured and Top Charts
	 *   Verifies all category pages load.
	 *
	 *   @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 *  @param {int} [args.iterations=1] - number of iterations desired
	 */
	quickLookStoreCategories: function quickLookStoreCategories(args) {
		args = UIAUtilities.defaults(args, {
				iterations: 1,
		});
		podcasts.logStartingOptions(args);
		if (args.iterations > 1000) {
			args.iterations = 10;
		}

		for (var i = 0; i < args.iterations; i++) {
			podcasts.testTopChartsCategories();
		}
	},

	/**
	 * Podcasts QA. Quicklook Stations
	 *   Cancels out, then creates and verifies station, verifies downloading in station and changing station settings
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.audioPodcastTitle="Car Talk"] - Title of audio podcast to use
	 * @param {string} [args.audioPodcastURL=""] - URL for the audio podcast
	 * @param {string} [args.videoPodcastTitle="TED Talks Daily"] - Title of video podcast to use
	 * @param {string} [args.videoPodcastURL=""] - URL for video to use
	 */
	quickLookStations: function quickLookStations(args) {
		args = UIAUtilities.defaults(args, {
			audioPodcastTitle : 'Car Talk',
			audioPodcastURL   : PODCAST_URLS.Car_Talk,
			videoPodcastTitle : 'TED Talks Daily',
			videoPodcastURL   : PODCAST_URLS.TEDTalks_video,
		});

		if (args.audioPodcastURL === '') {
			args.audioPodcastURL = PODCAST_URLS.Car_Talk;
		}
		if (args.videoPodcastURL === '') {
			args.videoPodcastURL = PODCAST_URLS.TEDTalks_video;
		}
		UIALogger.logMessage('TEST: Quick Look Stations');
		podcasts.logStartingOptions(args);
		podcasts.quicklookStations(args);

	},

	/**
	 * Podcasts QA. Quicklook Sharing
	 *   Shares the given podcast to a few different services
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {object} args - Test arguments
	 * @param {string} [args.podcastName="Car Talk"] - podcast container name to share
	 * @param {string} [args.podcastURL="pcast://www.npr.org/templates/rss/podcast.php?id=510208"] - URL to subscribe to if needed
	 * @param {array} [args.services=["iCloud"]] - Array of services to share to
	 */
	quickLookSharing: function quickLookSharing(args) {
		args = UIAUtilities.defaults(args, {
			podcastName 	: "Car Talk",
			podcastURL  	: PODCAST_URLS.Car_Talk,
      		services    	: ['iCloud','Copy Link'],
		});
		podcasts.logStartingOptions(args);
		//podcasts.launch();
		UIALogger.logMessage("TEST: Quicklook Sharing...");
		podcasts.quicklookSharing(args.podcastName, args.podcastURL, args.services);
	},

	/**
	 * Podcasts QA. Quicklook Lock Screen Play Tests
	 * Verifies playback controls work on the lock screen
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args
	 * @param {string[]} [args.podcastURLs=[]] - Array of podcast URLs to subscribe to
	 * @param {string[]} [args.podcastTitles=[]] - Array of title index matched to podcastURLs
	 * @param {bool} [args.lockScreenTest=true] - If true, runs a lock screen quicklook, if false, runs Control Center
	 * 		quicklook
	 */
	quickLookLockScreenPlayTests : function quickLookLockScreenPlayTests(args) {
		args = UIAUtilities.defaults(args, {
			podcastURLs      : [],
			podcastTitles    : [],
			lockScreenTest  : true,
		});
		if (args.podcastURLs.length === 0) {
			args.podcastURLs = [PODCAST_URLS.Car_Talk, PODCAST_URLS.TEDTalks_video];
		}
		if (args.podcastTitles.length === 0) {
			args.podcastTitles = ['Car Talk', 'TED Talks Daily'];
		}
		podcasts.logStartingOptions(args);
		UIALogger.logMessage('TEST: Lock Screen Quicklook');
		podcasts.quicklookLockScreenAndControlCenterPlayback(args);
	},

	/**
	 * Podcasts QA. Quicklook Control Center Playback Controls
	 * Verifies playback controls work in control center
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args
	 * @param {string[]} [args.podcastURLs=[]] - Array of podcast URLs to subscribe to
	 * @param {string[]} [args.podcastTitles=[]] - Array of title index matched to podcastURLs
	 * @param {bool} [args.lockScreenTest=false] - If true, runs a lock screen quicklook, if false, runs Control Center
	 * 		quicklook
	 */
	quickLookControlCenterPlayTests : function quickLookControlCenterPlayTests(args) {
		args = UIAUtilities.defaults(args, {
			podcastURLs      : [],
			podcastTitles    : [],
			lockScreenTests  : false,
		});
		if (args.podcastURLs.length === 0) {
			args.podcastURLs = [PODCAST_URLS.Car_Talk, PODCAST_URLS.TEDTalks_video];
		}
		if (args.podcastTitles.length === 0) {
			args.podcastTitles = ['Car Talk', 'TED Talks Daily'];
		}
		podcasts.logStartingOptions(args);
		UIALogger.logMessage('TEST: Control Center Quicklook');
		podcasts.quicklookLockScreenAndControlCenterPlayback(args);
	},

	/**
	 * Podcasts QA. Quicklook Siri
	 * Tests siri playing controls
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, siri, voiced
	 *
	 * @param args
	 * @param {string} [args.podcastTitle="This American Life"] - Title of podcast for siri
	 * @param {string} [args.podcastURL=null] - URL of podcast to subscribe to if needed
	*/
	quickLookSiri : function quickLookSiri(args) {
		args = UIAUtilities.defaults(args, {
			podcastTitle : 'This American Life',
			podcastURL   : PODCAST_URLS.This_American_Life,
		});
		podcasts.logStartingOptions(args);

		UIALogger.logMessage('TEST: Siri Quicklook Test');
		podcasts.quicklookSiri({podcastTitle:args.podcastTitle, podcastURL:args.podcastURL});
	},

	/**
	 * Podcasts QA. Quicklook My Podcasts. Tests reordering of podcasts, marking episodes as played by swiping, from
	 * edit and through track actions and verifies episodes drop below played episodes to be deleted
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args
	 * @param {string} [args.podcastTitle="Serial"] - Title of podcast to use for testing
	 * @param {string} [args.podcastURL=""] - URL to subscribe to podcast if needed
     */
	quickLookMyPodcasts : function quickLookMyPodcasts(args) {
		args = UIAUtilities.defaults(args, {
			podcastTitle : 'Serial',
			podcastURL   : PODCAST_URLS.Serial,
		});

		if (args.podcastURL === '') {
			args.podcastURL = PODCAST_URLS.Serial;
		}
		podcasts.quicklookMyPodcasts(args.podcastTitle, args.podcastURL);
	},

	/**
	 * Podcasts QA. Subscribes to a podcast on the featured tab
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string[]} [args.toAvoid=[]] - Podcasts to avoid using for testing
	 * @param {bool} [args.verifySettings=true] - If true, verifies settings of podcast, otherwise just verified
	 * 		podcast appears
	 * @param {object} [args.expectedSettings=""] - Expected settings after subscribed
	 */
	subscribingFromFeatured : function subscribingFromFeatured(args) {
		args = UIAUtilities.defaults(args, {
			toAvoid        : TO_AVOID,
			verifySettings : true,
            expectedSettings : {subscribed:true, notifications:true, mostRecentFirst:true},
		});
		if (args.expectedSettings === '') {
			args.expectedSettings = {subscribed:true, notifications:true, mostRecentFirst:true};
		}
		podcasts.subscribeFromFeatured(args);
	},

	/**
	 * Podcasts QA. Subscribes to a podcast in Top Charts
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args - Test arguments
	 * @param {string[]} [args.toAvoid=[]] - Podcasts to avoid using for testing
	 * @param {bool} [args.verifySettings=true] - If true, verifies settings of podcast, otherwise just verified
     * 		podcast appears
	 * @param {object} [args.expectedSettings=""] - Expected settings after subscribed
	 */
	subscribingFromTopCharts : function subscribingFromTopCharts(args) {
        args = UIAUtilities.defaults(args, {
            toAvoid        : TO_AVOID,
            verifySettings : true,
            expectedSettings : {subscribed:true, notifications:true, mostRecentFirst:true},
        });
        if (args.expectedSettings === '') {
            args.expectedSettings = {subscribed:true, notifications:true, mostRecentFirst:true};
        }

		podcasts.subscribeFromTopCharts(args);
	},

	/**
	 * Podcasts QA. Connects to wifi and desired ITMS environment
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {object} args - argument dictionary
	 * @param {string} [args.environment="itms5"] - store environment to use
	 * @param {string} [args.network="Hawkeye"] - Wireless network to use
	 * @param {string} [args.password="wait-wait-from-NPR"] - Password for the network
     */
	setupITMSEnvironment : function setupITMSEnvironment(args) {
		args = UIAUtilities.defaults(args, {
			environment : 'itms5',
			network	    : 'Hawkeye',
			password    : 'wait-wait-from-NPR',
		});

		podcasts.logStartingOptions(args);
		UIALogger.logMessage('TEST: Setup ITMS Environment');
		settings.launch();
		settings.returnToTopLevel();
		settings.tap('Wi-Fi');
		settings.connectToWiFi(args);
		podcasts.setITMSEnvironment(args.environment);
	},

	/**
	 * Podcasts QA. Log in to iTunes Store account and delete everything from My Podcasts
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {object} args - argument dictionary
	 * @param {string} [args.storeAppleID="ottocloudsync@icloud.com"] - Store account user name
	 * @param {string} [args.storePassword="podIQ6616"] - Password for account
	 */
	prepForCloudSyncTest : function prepForCloudSyncTest(args) {
		args = UIAUtilities.defaults(args, {
			storeAppleID  : 'ottocloudsync@icloud.com',
			storePassword : 'podIQ6616',
		});
		podcasts.logStartingOptions(args);

		podcasts.loginToService('Store', args.storeAppleID, args.storePassword);

	},

	/**
	 * Podcasts QA. Launch podcasts and verify correct podcasts sync
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {} args - arguments dictionary
	 * @param {string[]} [args.myPodcastsOrder=null] - List of podcasts that should be in My Podcasts
	 * @param {bool} [args.verifyEpisode=false] - If true, verifies an episode list matches
	 * @param {bool} [args.verifyStation=false] - If true, verifies a station exists and included episodes match
	 * @param {string} [args.podcastTitle="This American Life] - Name of podcast used for testing
	 * @param {string} [args.stationName="Cloud Sync Test Station"] - Name of station used for testing
     */
	launchSyncAndVerify : function launchSyncAndVerify(args) {
		args = UIAUtilities.defaults(args, {
			myPodcastsOrder : null,
			verifyEpisode   : false,
			verifyStation   : false,
			podcastTitle    : 'This American Life',
			stationName     : 'Cloud Sync Test Station',
		});
		podcasts.cloudSyncLaunchAndVerify(args);
	},

	/**
	 * Podcasts QA. Subscribe to a podcast and background/foreground to sync
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {} args - Arguments dictionary
	 * @param {string} [args.syncTestPodcastTitle="This American Life"] - Title of podcast to use in test
	 * @param {} [args.syncTestPodcastURL=null] - URL of podcast that matches the title
     */
	subscribeAndCloudSyncTest : function subscribeAndCloudSyncTest(args) {
		args = UIAUtilities.defaults(args, {
			syncTestPodcastTitle : 'This American Life',
			syncTestPodcastURL   : PODCAST_URLS.This_American_Life,
		});

		podcasts.cloudSyncSubscribeAndSync(args);
	},

	/**
	 * Podcasts QA. Deletes an episode and syncs to the cloud
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args - arguments dictionary
	 * @param {string} [args.syncTestPodcastTitle="This American Life"] - Title of podcast to use for testing
     */
	deleteEpisodeAndCloudSyncTest : function deleteEpisodeAndCloudSyncTest(args) {
		args = UIAUtilities.defaults(args, {
			syncTestPodcastTitle : 'This American Life'
		});

		podcasts.cloudSyncDeleteEpisodeAndSync(args);
	},

	/**
	 * Podcasts QA. Unsubscribes and tests cloud sync
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args - arguments dictionary
	 * @param {string} [args.syncTestPodcastTitle="This American Life"] - Title of podcast to use for testing
	 * @param {bool} [args.unsubscriber=false] - Whether to use the device to unsubscribe
     */
	unsubscribeCloudSyncTest : function unsubscribeCloudSyncTest(args) {
		args = UIAUtilities.defaults(args, {
			syncTestPodcastTitle : 'This American Life',
			unsubscriber         : false,
		});

		podcasts.cloudSyncUnsubscribe(args);
	},

	/**
	 * Podcasts QA. Unsubscribe from all podcasts and sync that setting up to the cloud
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param args - arguments dictionary
	 * @param {string} [args.appleID=null] - Apple ID to use to log in to the store
	 * @param {string} [args.appleIDPassword=null] - Password for the account
	 * @param {string} [args.syncTestPodcastTitle="This American Life"] - Title of podcast to be used for testing
	 * @param {string} [args.syncTestPodcastURL=null] - URL for the podcast
     */
	cloudSyncCleanUp : function cloudSyncCleanUp(args) {
		args = UIAUtilities.defaults(args, {
			syncTestPodcastTitle : 'This American Life',
			syncTestPodcastURL   : PODCAST_URLS.This_American_Life,
			storeAppleID         : null,
			storePassword        : null,
		});
		podcasts.cloudSyncCleanUp(args);
	},

	/**
	 * Creates a station and syncs to iCloud
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args - args dictionary
	 * @param {string} [args.stationName="Cloud Sync Test Station"] - Name for the station
	 */
	createStationAndCloudSyncTest : function createStationAndCloudSyncTest(args) {
		args = UIAUtilities.defaults(args, {
			stationName : 'Cloud Sync Test Station'
		});

		podcasts.cloudSyncCreateStationAndSync(args);
	},

	/**
	 * Podcasts QA. Tests left swipe function
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {object} args
     */
	swipeTest : function swipeTest(args) {
		args = UIAUtilities.defaults(args, {
			name : 'A'
		});

		podcasts.swipeLeft(args.name);
		podcasts.tap('Done');
	},

	/**
	 * Podcasts QA. Delete all items in My Podcasts. If this fails, it may cause issues in later tests
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args
     */
	eraseAllFromMyPodcasts : function eraseAllFromMyPodcasts(args) {
		podcasts.deleteFromMyPodcasts({deleteAll:true, needToNav:true});
	},

	/**
	 * Podcasts QA. Deletes and brings back Podcasts using lsaw to clear the database
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args
     */
	deleteDatabaseViaAppRemoval : function deleteDatabaseViaAppRemoval(args) {
		podcasts.deleteDatabaseWithAppRemoval();
	},

	/**
	 * Podcasts QA. Mark an episode as unplayed and sync to cloud
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param args
	 * @param {string} [args.syncTestPodcastTitle="This American Life"] - Title of podcast to use for testing
	 * @param {string} [args.title=null] - Title of episode to be marked as unplayed
	 */
	markAsUnplayedAndSync : function markAsUnplayedAndSync(args) {
		args = UIAUtilities.defaults(args, {
			syncTestPodcastTitle : 'This American Life',
			title				 : null
		});
		podcasts.cloudSyncMarkAsUnplayedSync(args);
	},

	/**
	 * Podcasts QA. Tests playback of video and audio podcasts in CarPlay as well as general UI
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, MusicUIService
	 *
	 * @param args - Argument dictionary
	 * @param {string} [args.carPlayAudioPodcast="Planet Money"] - Audio podcast to use for CarPlay tests
	 * @param {string} [args.carPlayAudioURL=""] - URL of audio podcast
	 * @param {string} [args.carPlayVideoPodcast="Start Cooking"] - Video podcast to use for CarPlay tests
	 * @param {string} [args.carPlayVideoURL=""] - URL of video podcast
	 * @param {bool} [args.runCarPlay=true] - If false, test not run
     */
	quickLookCarPlay : function quickLookCarPlay(args) {
		args = UIAUtilities.defaults(args, {
			carPlayAudioPodcast : 'Planet Money',
			carPlayAudioURL     : PODCAST_URLS.Planet_Money,
			carPlayVideoPodcast : 'Start Cooking',
			carPlayVideoURL     : PODCAST_URLS.Start_Cooking,
			runCarPlay          : true,
		});

		if (args.carPlayAudioURL === '') {
			args.carPlayAudioURL = PODCAST_URLS.Planet_Money;
		}
		if (args.carPlayVideoURL === '') {
			args.carPlayVideoURL = PODCAST_URLS.Start_Cooking;
		}
		podcasts.quicklookCarPlay(args);
	},

	/**
	 * Podcasts QA. Set up or verify upgrade or restore testing
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {object} args - Arguments dictionary
	 * @param {null|object} [args.settingsToSet=null] - App settings to change for the test. Dictionary must be
	 * 		compatible with changeAppSettings
	 * @param {null|object} [args.settingsToCompare=null] - Dictionary of app settings compatible with
	 * 		verifyAppSettings. Used to verify settings are correct
	 * @param {null|object} [args.unplayedToCompare=null] - Array of dictionary items as generated by getAllEpisodeData
	 * 		representing episode information from the Unplayed tab to compare against
	 * @param {null|object} [args.myPodcastsToCompare=null] - String array of all items from the My Podcasts tab to
	 * 		verify
	 * @param {null|object} [args.myPodcastsEpisodeDataToCompare=null] - Array of dictionary items as generated by
	 * 		getAllEpisodeDataFromAllContainers to compare the contents of all podcast containers
	 * @param {null|object} [args.testPodcastTitles=[]] - Array of podcast titles to use index matched to
	 * 		options.testPodcastURLs
	 * @param {null|object} [args.testPodcastURLs=[]] - Array of podcast URLs to use to subscribe index matched to
	 * 		options.testPodcastTitles
	 * @param {null|Date} [args.testStartTime=null] - Date representing when setup completed to be used to remove any
	 * 		new episodes that dropped in between tests
	 * @param {null|object} [args.podcastSettingsToSet=null] - Podcast settings to change on one of the podcasts.
	 * 		Dictionary compatible with changePodcastSettings()
	 * @param {null|object} [args.podcastSettingsToVerify=null] - Array of dictionary items containing the settings for
	 * 		all the podcasts to compare them
	 * @param {string} [args.upgradeTestType="Setup"] - String representing test type
	 * @param {string} [args.upgradeStationName="Upgrade Test Station"] - Name to be used for the station created by the
	 * 		test
	 * @param {null|object} [args.stationEpisodesToCompare=null] - Array of dictionary items as generated by
	 * 		getAllEpisodeData representing episode information from the station to compare against
     */
	regressionUpgradeTest : function regressionUpgradeTest(args) {
		args = UIAUtilities.defaults(args, {
			settingsToSet                  : null,
			settingsToCompare              : null,
			unplayedToCompare              : null,
			myPodcastsToCompare            : null,
			myPodcastsEpisodeDataToCompare : null,
			testPodcastTitles              : [],
			testPodcastURLs                : [],
			testStartTime                  : new Date(),
			podcastSettingsToSet           : null,
			podcastSettingsToVerify        : null,
			upgradeTestType                : 'Setup',
			stationName                    : 'Upgrade Test Station',
			stationEpisodesToCompare       : null,
		});

		if (args.testPodcastTitles.length === 0) {
			args.testPodcastTitles = ['Serial', 'This American Life', 'Car Talk', 'The Flop House',
				'Planet Money', 'Fresh Air', 'Start Cooking',
				'Grammar Girl Quick and Dirty Tips for Better Writing',
				'Look Like a Local:  Travelers Not Tourists', 'The Dirtbag Diaries'];
		}
		if (args.testPodcastURLs.length === 0) {
			args.testPodcastURLs = [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life, PODCAST_URLS.Car_Talk,
				PODCAST_URLS.The_Flop_House, PODCAST_URLS.Planet_Money, PODCAST_URLS.Fresh_Air,
				PODCAST_URLS.Start_Cooking, PODCAST_URLS.Grammar_Girl,
				PODCAST_URLS.Look_Like_a_Local, PODCAST_URLS.The_Dirtbag_Diaries];
		}

		podcasts.upgradeRegressionTest(args);
	},

	/**
	 * Podcasts QA. Runs or sets up a long play regression test
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {Object} args - options dictionary
	 * @param {number} [args.length=8] - Length in hours test should run
	 * @param {number} [args.waitTime=-1] - Length of time in minutes to wait for downloads to complete, if -1,
	 *  	will multiply options.length by 15 to determine time to wait for downloads to complete
	 * @param {string[]} [args.podcastTitles=[]] - Titles of podcasts in order they should be used. Test will use all
	 * 		episodes from the first one, then the second, then the 3rd and so on until it has enough episodes to run the
	 * 		full length of time
	 * @param {string[]} [args.podcastURLs=[]] - URLs index matched to the titles in podcastTitles
	 * @param {bool} [args.screenLocks=false] - If true, screen is locked before testing proceeds
	 * @param {bool} [args.podcastsBackgrounded=false] - If true, Podcasts is bckgrounded before testing proceeds
	 * @param {bool} [args.downloaded=true] - If true, all episodes are downloaded before testing proceeds and if
	 * 		they are not, it fails
	 * @param {bool} [args.setUpOnly=false] - If true, only the set up portion of the test will be run
	 * @param {bool} [args.testOnly=false] - If true, set up steps are not run
	 *
	 * @throws If downloads do not complete or if Podcasts stops playback in the middle of testing
	 */
	regressionLongPlayTest : function regressionLongPlayTest(args) {
		args = UIAUtilities.defaults(args, {
			length: 8,
			waitTime : -1,
			podcastTitles: [],
			podcastURLs: [],
			screenLocked: false,
			podcastsBackgrounded: false,
			downloaded: true,
			setUpOnly: false,
			testOnly: false,
		});

		if (args.podcastTitles.length === 0) {
			args.podcastTitles = ['Car Talk', 'This American Life', "Dan Carlin's Hardcore History"];
		}
		if (args.podcastURLs.length === 0) {
			args.podcastURLs = [PODCAST_URLS.Car_Talk, PODCAST_URLS.This_American_Life, PODCAST_URLS.Dan_Carlin];
		}
		podcasts.longPlayRegressionTest(args);
	},

	/**
	 * Podcasts QA. Sets up a test to launch with a large database and then verifies My Podcasts and Unplayed
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {Object} args - arguments dictionary
	 * @param {string} [args.test="Setup"] - Portion of the test to run. Can be Setup, Launch, My Podcasts or Unplayed
	 * @param {string[]} [args.expectedMyPodcasts=[]] - Array of stations and My Podcasts in order as they should
	 * 		appear in My Podcasts on the device
	 * @param {string} [args.appleID="ottoiqlaunchtest1@icloud.com"] - Store account to use for test
	 * @param {string} [args.appleIDPassword="podIQ6616"] - Password for the store account
	 * @param {bool} [args.screenLocked=false] - If true, test will lock screen after launch
	 * @param {number} [args.waitTime=10] - Time in minutes to wait for database to update
	 * @param {bool} [args.background=true] - When true, Podcasts is backgrounded after launch
	 * @param {bool} [options.getJetsamPriority=true] - When true, jatsam priority is grabbed during the launch every 5
	 * 		seconds
	 * @param {bool} [options.getVMMap=false] - When true, take vmmap every 15 seconds during launch phase
	 */
	regressionLaunchWithLargeAccountTest : function regressionLaunchWithLargeAccountTest(args) {
		args = UIAUtilities.defaults(args, {
			test               : 'Setup',
			expectedMyPodcasts : [],
			appleID            : 'ottoiqlaunchtest1@icloud.com',
			appleIDPassword    : 'podIQ6616',
			screenLocked       : false,
			waitTime           : 10,
			background         : true,
			getJetsamPriority  : true,
			getVMMap           : false,
		});

		if (args.expectedMyPodcasts.length === 0) {
			args.expectedMyPodcasts = ["This Test","OS X","Launch 1","Despicable Me","Myths and Legends","Criminal",
				"NPR Politics Podcast",
				"The Way I Heard It with Mike Rowe","Anna Faris Is Unqualified",
				"Grammar Girl Quick and Dirty Tips for Better Writing",
				"CLIMAX!","Look Like a Local:  Travelers Not Tourists","The Dirtbag Diaries",
				"Trends Like These","Mystery Show","Hello Internet",
				"Accidental Tech Podcast","Serial","This American Life",
				"Common Sense with Dan Carlin","Dan Carlin's Hardcore History",
				"WTF with Marc Maron Podcast","The Adam and Dr. Drew Show","The Bugle",
				"The Joe Rogan Experience","The Nerdist"];
		}
		podcasts.regressionLaunchWithLargeDatabase(args);
	},

	/**
	 * Podcasts QA. Logs in to an account and sets all podcasts to have "numUnplayed" or less unplayed episodes
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd, Preferences
	 *
	 * @param {Object} args - argument dictionary
	 * @param {number} [args.numUnplayed=2] - Max number of unplayed episodes
	 * @param {string} [args.appleID="ottoiqlaunchtest1@icloud.com"] - Account to use
	 * @param {string} [args.appleIDPassword="podIQ6616"] - Account password
     */
	cleanLaunchTestAccount : function cleanLaunchTestAccount(args) {
		args = UIAUtilities.defaults(args, {
			numUnplayed     : 2,
			appleID         : 'ottoiqlaunchtest1@icloud.com',
			appleIDPassword : 'podIQ6616',
		});

		podcasts.cloudSyncCleanUpAccount(args);
	},

	/**
	 * Podcasts QA. Runs any of several sleep timer tests based on the test argument
	 *
	 * @targetApps Podcasts, itunesstored, medialibraryd
	 *
	 * @param {Object} args - Arguments dictionary
	 * @param {string} [args.test="Setup"] - Test to run, see test information below for valid entries and actions
	 * 		taken by each
	 * @param {string} [args.audioPodcastName="This American Life"] - Name of audio podcast to use for testing
	 * @param {string} [args.audioPodcastURL=""] - URL of the audio podcast
	 * @param {string} [args.audioEpisode=""] - Name of the audio episode to play for tests
	 * @param {string} [args.videoPodcastName="Apple Keynotes"] - Name of video podcast to use for testing
	 * @param {string} [args.videoPodcastURL=""] - URL of video podcast
	 * @param {string} [args.videoEpisode=""] - Name of the video episode to play for tests
     */
	regressionSleepTimerTests : function regressionSleepTimerTests(args) {
		args = UIAUtilities.defaults(args, {
			test			  : 'Setup',
			audioPodcastName  : 'This American Life',
			audioPodcastURL   : PODCAST_URLS.This_American_Life,
			audioEpisode      : '',
			videoPodcastName  : 'Apple Keynotes',
			videoPodcastURL   : PODCAST_URLS.Apple_Keynotes,
			videoEpisode      : '',
		});

		if (args.audioPodcastURL === '') {
			args.audioPodcastURL = PODCAST_URLS.This_American_Life;
		}
		if (args.videoPodcastURL === '') {
			args.videoPodcastURL = PODCAST_URLS.Apple_Keynotes;
		}

		podcasts.sleepTimerRegression(args);
	},

	/**
	 * Podcasts QA, performs one of several siri regression tests
	 *
	 * @targetApps Podcasts, siri, medialibraryd, itunesstored, assistantd
	 *
	 * @param {Object} args - args dictionary
	 * @param {string[]} [args.testAudioPodcastNames=""] - Titles of audio podcasts to use for testing
	 * @param {string[]} [args.testAudioPodcastURLs=""] - Array of URLs index matched to testAudioPodcastNames
	 * @param {string[]} [args.testVideoPodcastNames=""] - Array of video podcasts to use for testing
	 * @param {string[]} [args.testVideoPodcastURLs=""] - Array of URLs index matched to testVideoPodcastNames
	 * @param {string[]} [args.testEnhancedPodcastNames=""] - Array of enhanced podcasts to use for testing
	 * @param {string[]} [args.testEnhancedPodcastURLs=""] - Array of URLs index matched to testEnhancedPodcastNames
	 * @param {string} [args.testPrep="Setup"] - Test to be performed
	 * @param {string} [args.passcode="1111"] - Passcode to use on the device during testing
	 * @param {string[]} [args.commands=""] - commands to issue to siri, can be just 1 or multiple. If issuing
	 * 		multiple the test will be run with each command with each app and device state that is passed in
	 * @param {string[]} [args.appStates=""] - App states to test the command with. Foreground, Background or Force Quit
	 * @param {string[]} [args.deviceStates=""] - Device states to run commands in. Locked With Passcode, Locked No
	 * 		Passcode or Unlocked
	 * @param {string} [args.testPodcastTitle="Serial"] - Podcast to use for test
	 * @param {string} [args.episodeName=""] - Specific episode to play back
	 * @param {bool} [args.inFeed=false] - Determines if playback should be started from the feed when starting
	 * 		playback via tap
	 * @param {bool} [args.isSaved=false] - Determines if playback should be started from the saved tab when
	 * 		starting playback via tap
	 * @param {bool} [args.keepUpNext=true] - Determines if Up Next is kept or cleared when starting playback via tap
	 * @param {bool} [args.insertPodcastInCommand=false] - When true, inserts options.testPodcastTitle in to the
	 * 		commands passed in with options.commands using format. So "Play %0" passed in as command becomes "Play
	 * 		options.testPodcastTitle"
	 * @param {bool} [args.insertEpisodeInCommand=false] - When true, inserts options.episodeName in to the commands
	 * 		passed in with options.commands using format. So "Play %0" passed in as command becomes "Play
	 * 		options.episodeName"
	 * @param {bool} [args.openPodcasts=false] - When true, verifies the Open Podcasts button becomes visible after
	 * 		each siri command and taps on it
	 * @param {bool} [args.homeButton=false] - When true, home button is pressed to dismiss Siri
	 * @param {bool} [args.pauseBetween=false] - When true, playback is paused in between tests
	 * @param {bool} [args.needUnlock=false] - When true, device will be unlocked if needed in between states
	 * @param {bool} [args.exitNowPlaying=false] - When true, exits Now Playing in between tests
	 * @param {bool} [args.verifyRunning=true] - When true, verifies Podcasts app state is not Terminated at end
	 * 		of all verifications
	 * @param {bool} [args.verifyForeground=false] - When true, verifies Podcasts is in the foreground after test
	 * @param {bool} [args.verifyBackground=false] - When true, verifies Podcasts is in the background after test
	 * @param {bool} [args.verifyPlaying=false] - When true, verifies media is playing after podcasts is opened
	 * @param {bool} [args.verifyNotPlaying=false] - When true, verifies a pause command was seen by Siri as
	 * 		successful and verifies media is not playing
	 * @param {bool} [args.verifyPodcastPlaying=false] - When true, verifies that the Podcast playing is correct
	 * @param {bool} [args.verifyEpisodePlaying=false] - When true, verifies that the correct episode is playing
	 * @param {bool} [args.verifyPausedAfterHome=false] - When true, verifies media is not playing after home button
	 * 		is pressed
	 * @param {bool} [args.verifyPlayingAfterHome=false] - When true, verifies media is playing after pressing home
	 * 		button
	 * @param {bool} [args.verifyPlayHead=false] - When true, verifies the playhead is withing 5 seconds of the
	 * 		position it was in when playback was paused
	 * @param {bool} [args.verifyUpNext=false] - When true, verifies the Up Next tab is the same as it was before
	 * 		the Siri command was issued
	 * @param {number} [args.markAsUnplayed=0] - Number of episodes of testPodcastTitle to mark as Unplayed from the
	 * 		feed
	 * @param {Object} [args.verifyUIState=""] - When UI state is passed in, verifies the currentUIState matches
	 * @param {number} [args.prepAction=-1] - Function to run after all other verifications are complete. The
	 * 		functions need to be defined in PodcastsQA.js if calling from ptest. They are referenced by a number
	 */
	regressionSiriTests : function regressionSiriTests(args) {
		args = UIAUtilities.defaults(args, {
			testAudioPodcastNames    : ['Serial', 'This American Life'],
			testAudioPodcastURLs     : [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life],
			testVideoPodcastNames    : ['TED Talks Daily'],
			testVideoPodcastURLs     : [PODCAST_URLS.TEDTalks_video],
			testEnhancedPodcastNames : ['Colonial Williamsburg History Podcasts - Image Enhanced'],
			testEnhancedPodcastURLs  : [PODCAST_URLS.Colonial_Williamsburg_Enhanced],
			testPrep 			 	 : 'Setup',
			passcode         		 : '1111',
			commands				 : '',
			appStates				 : ['Foreground', 'Background', 'Force Quit'],
			deviceStates			 : ['Locked With Passcode', 'Locked No Passcode', 'Unlocked'],
			testPodcastTitle		 : 'Serial',
			episodeName		         : '',
			inFeed					 : false,
			isSaved  			     : false,
			keepUpNext				 : true,
			insertPodcastInCommand   : false,
			insertEpisodeInCommand   : false,
			openPodcasts	         : false,
			homeButton               : false,
			pauseBetween	         : false,
			needUnlock               : false,
			exitNowPlaying           : false,
			verifyRunning            : false,
			verifyForeground         : false,
			verifyBackground         : false,
			verifyPlaying            : false,
			verifyNotPlaying         : false,
			verifyPodcastPlaying     : false,
			verifyEpisodePlaying     : false,
			verifyPausedAfterHome    : false,
			verifyPlayingAfterHome   : false,
			verifyPlayHead			 : false,
			verifyUpNext		     : false,
			markAsUnplayed			 : 0,
			verifyUIState            : '',
			prepAction		         : -1,
		});

		if (args.testAudioPodcastNames === '') {
			args.testAudioPodcastNames = ['Serial', 'This American Life'];
		}
		if (args.testAudioPodcastURLs === '') {
			args.testAudioPodcastURLs = [PODCAST_URLS.Serial, PODCAST_URLS.This_American_Life];
		}
		if (args.testVideoPodcastNames === '') {
			args.testVideoPodcastNames = ['TED Talks Daily'];
		}
		if (args.testVideoPodcastURLs === '') {
			args.testVideoPodcastURLs = [PODCAST_URLS.TEDTalks_video];
		}
		if (args.testEnhancedPodcastNames === '') {
			args.testEnhancedPodcastNames = ['Colonial Williamsburg History Podcasts - Image Enhanced'];
		}
		if (args.testEnhancedPodcastURLs === '') {
			args.testEnhancedPodcastURLs = [PODCAST_URLS.Colonial_Williamsburg_Enhanced];
		}
		if (args.appStates === '') {
			args.appStates = ['Foreground', 'Background', 'Force Quit'];
		}
		if (args.deviceStates === '') {
			args.deviceStates = ['Locked With Passcode', 'Locked No Passcode', 'Unlocked'];
		}

		podcasts.siriRegressionTests(args);
	},

};
