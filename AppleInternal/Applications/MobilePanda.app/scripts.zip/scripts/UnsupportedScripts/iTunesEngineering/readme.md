		App/Project/Feature: For Appstore, iTunesStore, Music, TV, Remote, and more tests, contact sbuttner@apple.com or aborretto@apple.com to get the most up to date code.
		Maintainer(s): Shawn Buttner
		Maintainer(s) Email: sbuttner@apple.com
		Maintainer(s) Team: iTS Apps iTunes QA
		Maintainer(s) Team Manger: Andy Boretto
		Maintainer(s) Team Manger Email: aboretto@apple.com
        See:   https://gitlab.sd.apple.com/itunes_appletv_automation/itunes

		App/Project/Feature: Podcasts
		Maintainer(s): Andy Boretto
		Maintainer(s) Email: aboretto@apple.com
		Maintainer(s): Rob Baker
		Maintainer(s) Email: rbaker@apple.com
		Maintainer(s) Team: AMP Automation
		Maintainer(s) Team Manger: Andy Boretto
		Maintainer(s) Team Manger Email: aboretto@apple.com

    Automation scripts vetted by iTunes Engineering and iTunes QA for the following iOS apps:
    - Podcasts


These tests are more in-depth than the ones supported in the main repo, to support our engineering and QA group's needs.  
