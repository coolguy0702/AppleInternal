load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof AVAssetDownloaderApp === 'undefined',
    'AVAssetDownloaderApp has already been defined.'
);

/**
    @namespace
    @augments UIAApp
*/
var avAssetDownloaderApp = target.appWithBundleID('com.apple.AVAssetDownloader');

Labels = {
    /** Failed State */
    FAILED_STATE:'Failed!',

    /** Downloading State */
    DOWNLOADING_STATE: 'Downloading',

    /** Success State */
    SUCCESS_STATE: 'Success',

    /** Aging State */
    AGING_STATE: 'Aging assets...',

    /** Aging Complete State */
    AGING_COMPLETE_STATE: 'Aging Complete',

    /** Icon Name */
    ICON_NAME: 'AVAssetDownloader',
};

UIAQuery.AVAssetDownloaderApp = {
    
    // Download small asset button on the app
    SMALL_ASSET_BUTTON: UIAQuery.buttons('Small'),
    
    // Download large asset button on the app
    LARGE_ASSET_BUTTON: UIAQuery.buttons('Large'),
    
    // Download asset set button on the app
    ASSET_SET_BUTTON: UIAQuery.buttons('Set'),
    
    // Age assets button on the app
    AGE_ASSETS_BUTTON: UIAQuery.buttons('Age'),
    
    // Success element on the app
    SUCCESS_STATIC_TEXT_ELEMENT: UIAQuery.staticTexts('success'),
};

/**
 * Get to the app
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.iconName] - Name of icon 'AVAssetDownloader'
 *
 * throws UIAError if App with given name is not available on Springboard
 *
 * @returns None
 */
avAssetDownloaderApp.navigateToAppIcon = function navigateToAppIcon(options) {
    // Get to springboard, if an app is active
    springboard.launch();

    if (springboard.exists(UIAQuery.icons().withPredicate(
        "label ENDSWITH \"folder\" AND ANY children.identifiers CONTAINS \"%0\"".format(
            options.iconName)))) {
        UIALogger.logMessage('Icon in a folder. Trying to tap the Folder icon');

        springboard.getToIcon(UIAQuery.icons().withPredicate(
            "label ENDSWITH \"folder\" AND ANY children.identifiers CONTAINS \"%0\"".format(
                options.iconName)));

        springboard.tap(UIAQuery.icons().withPredicate(
            "label ENDSWITH \"folder\" AND ANY children.identifiers CONTAINS \"%0\"".format(
                options.iconName)));
    } else if (springboard.exists(options.iconName)) {
        springboard.getToIcon(options.iconName);
    } else {
        throw new UIAError('App with name %0 not present on springboard'.format(
            options.iconName));
    }
}

/**
 * Download small assets using AVAssetDownloader App
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.fromState] - The state in which the app is when downloading
 * @param {string} [options.toState] - The state in which app gets when download finishes
 * @param {number} [options.timeout] - Timeout of this operation
 * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
 *
 * @returns None
 */
avAssetDownloaderApp.downloadSmallAsset = function downloadSmallAsset(options){
    options = UIAUtilities.defaults(options, {
            fromState: Labels.DOWNLOADING_STATE,
            toState: Labels.SUCCESS_STATE,
            timeout: 300,
            iconName: Labels.ICON_NAME,
            num_assets_to_download: 1,
        });
    this.navigateToAppIcon(options);
    this.launch();
    for (var i =1 ; i <= options.num_assets_to_download; i++) {
        UIALogger.logMessage('Downloading asset #%0'.format(i));
        this.tapIfExists(UIAQuery.AVAssetDownloaderApp.SMALL_ASSET_BUTTON);
        target.delay(2);
    }
    this.waitForStateChange(options);
    this.quit();
}

/**
 * Download large assets using AVAssetDownloader App
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.fromState] - The state in which the app is when downloading
 * @param {string} [options.toState] - The state in which app gets when download finishes
 * @param {number} [options.timeout] - Timeout of this operation
 * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
 *
 * @returns None
 */
avAssetDownloaderApp.downloadLargeAsset = function downloadLargeAsset(options){
    options = UIAUtilities.defaults(options, {
            fromState: Labels.DOWNLOADING_STATE,
            toState: Labels.SUCCESS_STATE,
            timeout: 300,
            iconName: Labels.ICON_NAME,
        });
    this.navigateToAppIcon(options);
    this.launch();
    this.tapIfExists(UIAQuery.AVAssetDownloaderApp.LARGE_ASSET_BUTTON);
    this.waitForStateChange(options);
    this.quit();
}

/**
 * Download asset set using AVAssetDownloader App
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.fromState] - The state in which the app is when downloading
 * @param {string} [options.toState] - The state in which app gets when download finishes
 * @param {number} [options.timeout] - Timeout of this operation
 * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
 *
 * @returns None
 */
avAssetDownloaderApp.downloadAssetSet = function downloadAssetSet(options){
    options = UIAUtilities.defaults(options, {
            fromState: Labels.DOWNLOADING_STATE,
            toState: Labels.SUCCESS_STATE,
            timeout: 300,
            iconName: Labels.ICON_NAME,
        });
    this.navigateToAppIcon(options);
    this.launch();
    this.tapIfExists(UIAQuery.AVAssetDownloaderApp.ASSET_SET_BUTTON);
    this.waitForStateChange(options);
    this.quit();
}

/**
 * Age assets using AVAssetDownloader App
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.fromState] - The state in which the app is when downloading
 * @param {string} [options.toState] - The state in which app gets when download finishes
 * @param {number} [options.timeout] - Timeout of this operation
 * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
 *
 * @returns None
 */
avAssetDownloaderApp.ageAssets = function ageAssets(options){
    options = UIAUtilities.defaults(options, {
            fromState: Labels.AGING_STATE,
            toState: Labels.AGING_COMPLETE_STATE,
            timeout: 300,
            iconName: Labels.ICON_NAME,
        });
    this.navigateToAppIcon(options);
    this.launch();
    this.tapIfExists(UIAQuery.AVAssetDownloaderApp.AGE_ASSETS_BUTTON);
    this.waitForStateChange(options);
    this.quit();
}

/**
 * Download AVAssetdownloader app from a http server
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.appWithBundleIDPath] - Path where the app ipa resides on the device
 * @param {string} [options.trustDevName] - Name of the Dev to trust the app
 *
 * Returns None
 */
avAssetDownloaderApp.downloadAppFromServer = function downloadAppFromServer(options){
    options = UIAUtilities.defaults(options, {
        serverURL: 'http://cc0102a-dhcp239.apple.com:8000/AVAssetDownloader.ipa',
        downloadDestination: '/tmp/AVAssetDownloader.ipa',
    });
    var additionalArgs = {};
    additionalArgs.curlArgs = ['-o', options.downloadDestination];
    var curlResult = UIAUtilities.httpQueryUrl(options.serverURL, additionalArgs);

    UIALogger.logMessage(
        'Trying to download app using curl from server: %0 to location: %1'.format(
            options.serverURL, options.downloadDestination));

    UIALogger.logMessage('stderr: %0'.format(curlResult.stderr));
    UIALogger.logMessage('stderr: %0'.format(curlResult.stdout));
 }

/**
 * Install AVAssetdownloader app
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {string} [options.appWithBundleIDPath] - Path where the app ipa resides on the device
 * @param {string} [options.trustDevName] - Name of the Dev to trust the app
 */
avAssetDownloaderApp.installApp = function installApp(options){
    options = UIAUtilities.defaults(options, {
        appWithBundleIDPath: '/tmp/AVAssetDownloader.ipa',
        trustDevName: 'iPhone Distribution: Apple, Inc. - PEP',
    });
    UIALogger.logMessage('Trying to install Avdownloader using mobile_install');
    var mobileInstallResult = target.performTask(
        '/usr/local/bin/mobile_install', ['install', options.appWithBundleIDPath]);

    UIALogger.logMessage('stderr: %0'.format(mobileInstallResult.stderr));
    UIALogger.logMessage('stderr: %0'.format(mobileInstallResult.stdout));
    UIALogger.logMessage('Trying to trust the app using profilectl');
    var trustAppResult = target.performTask(
        '/usr/local/bin/profilectl', ['trustdevs', options.trustDevName]);

    UIALogger.logMessage('stderr: %0'.format(trustAppResult.stderr));
    UIALogger.logMessage('stderr: %0'.format(trustAppResult.stdout));
}

/**
 * Utility function that returns the current state of the App
 *
 * Required Starting View: NA
 *
 * Returns: {string} Current state
 */
avAssetDownloaderApp.currentAppState = function currentAppState(){
    return this.inspect(UIAQuery.AVAssetDownloaderApp.SUCCESS_STATIC_TEXT_ELEMENT).label;
}

/**
 * Utility function that returns wheather the app is in given state or not
 *
 * Required Starting View: NA
 *
 * @param {string} [state] The state app should be in
 *
 * Returns: {bool} If the app is in the state specified
 */
avAssetDownloaderApp.isAppInState = function isAppInState(state){
    UIALogger.logMessage('Current State: %0'.format(this.currentAppState()));
    UIALogger.logMessage('To State: %0'.format(state));
    return this.currentAppState() == state; 
}

/**
 * Utility function that waits for the app state to change from starting state to ending state
 *
 * Required Starting View: NA
 *
 * @param {object} [options] argument dictionary
 * @param {object} [options.fromState] starting state
 * @param {object} [options.toState] ending state
 * @param {object} [options.timeout] timeout allowed to change state
 *
 * Returns: {bool} If app changed state within timeout
 */
avAssetDownloaderApp.waitForStateChange = function waitForStateChange(options){
    UIALogger.logMessage(
        'Waiting for state to change from %0 to %1'.format(
            options.fromState, options.toState));

    target.delay(2);
    if (this.isAppInState(Labels.FAILED_STATE)){
        this.tapIfExists(UIAQuery.AVAssetDownloaderApp.SMALL_ASSET_BUTTON);
    }

    UIAUtilities.assert(
        this.isAppInState(options.fromState) || this.isAppInState(options.toState),
        'AVAssetDownloader not in %0 state'.format(options.fromState)
    );

    while (!this.isAppInState(options.toState) && options.timeout > 0){
        UIALogger.logMessage('State: %0'.format(this.currentAppState()));
        target.delay(30);
        options.timeout--;

        if (this.isAppInState(Labels.FAILED_STATE)){
            this.tapIfExists(UIAQuery.AVAssetDownloaderApp.SMALL_ASSET_BUTTON);
        }

        if (!options.timeout){
            throw new UIAError(
                'State did not change from %0 to %1. Operation timed out'.format(
                    fromState, toState));
        }
    }

    UIALogger.logMessage(
        'State successfully changed from %0 to %1'.format(
            options.fromState, options.toState));

    target.delay(10);
    return true;
}