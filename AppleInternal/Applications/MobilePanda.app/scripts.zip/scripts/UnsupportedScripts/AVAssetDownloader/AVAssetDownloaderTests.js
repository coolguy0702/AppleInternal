load('UIATesting.js');
load('SpringBoard.js');
load('AVAssetDownloader.js');

if (typeof AVAssetDownloaderAppTests !== 'undefined') {
    throw new UIAError("Namespace 'AVAssetDownloaderAppTests' has already been defined.");
}

/**
 * @namespace AVAssetDownloaderApp
 */
var AVAssetDownloaderAppTests = {

    /**
     * Download small assets using AVAssetDownloader App
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.fromState] - The state in which the app is when downloading
     * @param {string} [options.toState] - The state in which app gets when download finishes
     * @param {number} [options.timeout] - Timeout of this operation
     * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
     */
    downloadSmallAsset: function downloadSmallAsset(args){
        avAssetDownloaderApp.downloadSmallAsset(args);
    },

    /**
     * Download large assets using AVAssetDownloader App
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.fromState] - The state in which the app is when downloading
     * @param {string} [options.toState] - The state in which app gets when download finishes
     * @param {number} [options.timeout] - Timeout of this operation
     * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
     */
    downloadLargeAsset: function downloadLargeAsset(args){
        avAssetDownloaderApp.downloadLargeAsset(args);
    },

    /**
     * Download asset set using AVAssetDownloader App
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.fromState] - The state in which the app is when downloading
     * @param {string} [options.toState] - The state in which app gets when download finishes
     * @param {number} [options.timeout] - Timeout of this operation
     * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
     */
    downloadAssetSet: function downloadAssetSet(args){
        avAssetDownloaderApp.downloadAssetSet(args);
    },

    /**
     * Age assets using AVAssetDownloader App
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.fromState] - The state in which the app is when downloading
     * @param {string} [options.toState] - The state in which app gets when download finishes
     * @param {number} [options.timeout] - Timeout of this operation
     * @param {string} [options.iconName] - Name of icon for AVAssetDownloader App
     */
    ageAssets: function ageAssets(args){
        avAssetDownloaderApp.ageAssets(args);
    },

    /**
     * Install AVAssetdownloader app
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.appWithBundleIDPath] - Path where the app ipa resides on the device
     * @param {string} [options.trustDevName] - Name of the Dev to trust the app
     */
    installApp: function installApp(args){
        avAssetDownloaderApp.installApp();
    },

    /**
     * Utility function that waits for the app state to change from starting state to ending state
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {object} [options.fromState] starting state
     * @param {object} [options.toState] ending state
     * @param {object} [options.timeout] timeout allowed to change state
     *
     * Returns: {bool} If app changed state within timeout
     */
    waitForStateChange: function waitForStateChange(){
        avAssetDownloaderApp.waitForStateChange();
    },

    /**
     * Download AVAssetdownloader app from a http server
     *
     * Required Starting View: NA
     *
     * @param {object} [options] argument dictionary
     * @param {string} [options.appWithBundleIDPath] - Path where the app ipa resides on the device
     * @param {string} [options.trustDevName] - Name of the Dev to trust the app
     */
    downloadAppFromServer: function downloadAppFromServer(){
        avAssetDownloaderApp.downloadAppFromServer();
    },
};