load('UIAApp.js');

UIAUtilities.assert(
	typeof Axaudit === 'undefined',
	'Axaudit has already been defined.'
);

/**
	@namespace
	@augments Axaudit
*/
Axaudit = {
}

/**
 * Runs axaudit tool for accessibility
 * if there is any error message in output regarding of large text
 *
 * @param {object} options An options dictionary
 * @param {string} [options.outputFilePath="/tmp/axaudit/"] - the output file path
 * @param {string} [options.outputFileName="axaudit"] - the output file name
 * @param {array} [options.errorsToCatch=[3001, 3002, 3003]] - all the error IDs you like to catch
 *
 * @returns {boolean} true if no error message is found. otherwise, returns false
 *
 */

Axaudit.runAxaudit = function runAxaudit(options) {
	options = UIAUtilities.defaults(options, {
		outputFilePath:     '/tmp/axaudit/',
		outputFileName:     'axaudit',
		errorsToCatch:      [3001, 3002, 3003],
	});

	UIALogger.logMessage("runAxaudit " + options.outputFilePath + options.outputFileName + options.errorsToCatch);
	if (!UIAFile.fileExists(options.outputFilePath)) {
		var result = performTask('/usr/bin/login',
			['-f', 'mobile', '/bin/mkdir', '-p', options.outputFilePath]
		);
		if ( result.exitCode != 0) {
			UIALogger.logMessage("runAxaudit fail, can't create directory: " + options.outputFilePath);
			return false;
		}
	}

	var htmlFileName = options.outputFilePath + options.outputFileName + '.html';
	var jsonFileName = options.outputFilePath + options.outputFileName + '.json';
	var configJsonFileName = options.outputFilePath + options.outputFileName + '_config.json';
	var configPlistFileName = options.outputFilePath + options.outputFileName + '_config.plist';

	if (options.errorsToCatch.length > 1) {
		var errorDict = {'auditWarnings': options.errorsToCatch};
		var rConfigFile = new UIAFile(configJsonFileName);
		rConfigFile.open('w', 'unicode');
		rConfigFile.writeln(JSON.stringify(errorDict));
		var configFileResult = target.performTask('/usr/bin/login', ['-f', 'mobile', '/usr/bin/plutil', '-convert', 'xml1',  configJsonFileName, '-o', configPlistFileName], 5);
		var axauditResult = target.performTask('/usr/bin/login', ['-f', 'mobile', '/usr/local/bin/axaudit', '-h', htmlFileName, '-j', jsonFileName, '-i', configPlistFileName], 5);
	} else {
		var axauditResult = target.performTask('/usr/bin/login', ['-f', 'mobile', '/usr/local/bin/axaudit', '-h', htmlFileName, '-j', jsonFileName], 5);
	}

	if ( axauditResult.exitCode != 0) {
		UIALogger.logMessage("runAxaudit fail running axaudit: " + axauditResult.stderr);
		return false;
	}
	UIALogger.logMessage("setting up logTAResults to {FILE1: %0}".format(jsonFileName));
	UIALogger.logMessage("setting up logTAResults to {FILE2: %0}".format(htmlFileName));
	UIALogger.logTAResults({FILE1: jsonFileName});
	UIALogger.logTAResults({FILE2: htmlFileName});
	target.delay(2);
	return true;
}

/**
 * parse json file from axaudit
 * if there is any error message in output regarding of large text
 *
 * @param {object} options An options dictionary
 * @param {string} [options.outputFilePath="/tmp/axaudit/"] - the output file path
 * @param {string} [options.outputFileName="axaudit"] - the output file name
 * @param {array} [options.errorsToCatch=[3001, 3002, 3003]] - all the error IDs you like to catch
 *
 * @returns {string} error message if any
 *
 */

Axaudit.parseAxuditJSON = function parseAxuditJSON(options) {
	options = UIAUtilities.defaults(options, {
		outputFilePath:     '/tmp/axaudit/',
		outputFileName:     'axaudit',
		errorsToCatch:      [3001, 3002, 3003],
	});
	UIALogger.logMessage("parseAxuditJSON " + options.outputFilePath + options.outputFileName + options.errorsToCatch);

	var jsonFileName = options.outputFilePath + options.outputFileName + '.json';
	if (!UIAFile.fileExists(jsonFileName)) {
		UIALogger.logMessage("No json file available to parse.  json Filename: " + jsonFileName);
		return false;
	}

	var jsonFile = new UIAFile(jsonFileName);
	jsonFile.open('r','unicode');
	var errorsInJson = JSON.parse(jsonFile.read());
	jsonFile.close();
	for (var property in errorsInJson) {
		UIALogger.logMessage("property: %0".format(property));
	}

	// parses and filters error message
	var errormessage = '';
	var allIssues = errorsInJson['_axKeyAllScreens'][0]['_axKeyAllIssues'];
	for (var itemNumber in allIssues) {
		for (var itemKey in allIssues[itemNumber]) {
			if(itemKey === '_axKeyErrorCode' && options.errorsToCatch.indexOf(allIssues[itemNumber][itemKey]) >= 0 ) {
				UIALogger.logWarning('KEY: %0 VALUE: %1'.format(itemKey, allIssues[itemNumber][itemKey]));
				UIALogger.logWarning('%0'.format(allIssues[itemNumber]['_axKeyLongDesc']));
				errormessage = errormessage + allIssues[itemNumber][itemKey] + " " + allIssues[itemNumber]["_axKeyLongDesc"] + "\n";
			}
		}
	}

	return errormessage;
}

/**
 * Runs axaudit and provide error message
 * if there is any error message in output regarding of large text
 *
 * @param {object} options An options dictionary
 * @param {string} [options.outputFilePath="/tmp/axaudit/"] - the output file path
 * @param {string} [options.outputFileName="axaudit"] - the output file name
 * @param {array} [options.errorsToCatch=[3001, 3002, 3003]] - all the error IDs you like to catch
 *
 * @returns {string} error message if any
 *
 */

Axaudit.axaudit_analysis = function axaudit_analysis(options) {
	options = UIAUtilities.defaults(options, {
		outputFilePath:     '/tmp/axaudit/',
		outputFileName:     'axaudit',
		errorsToCatch:      [3001, 3002, 3003],
	});
	UIALogger.logMessage("axaudit_analysis " + options.outputFilePath + options.outputFileName);

	Axaudit.runAxaudit(options);
	var errormessage = Axaudit.parseAxuditJSON(options);
	return errormessage;
}