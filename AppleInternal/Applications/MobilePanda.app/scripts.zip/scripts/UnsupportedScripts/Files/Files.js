load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof files === 'undefined',
    'files undefined'
);

/*******************************************************************************/
/*                                                                             */
/*  Query Constants - App specific queries that will be made frequently        */
/*                                                                             */
/*******************************************************************************/

/** Constants for common files queries */
UIAQuery.Files = {
    /** 'Recents' button in main tab bar */
    RECENTS_BUTTON:  UIAQuery.tabBars().andThen(UIAQuery.buttons().contains('Recents')),

    /** 'Browse' button in main tab bar */
    BROWSE_BUTTON:   UIAQuery.tabBars().andThen(UIAQuery.buttons().contains('Browse')),

    /** Navigation bar on main page */
    MAIN_NAV_BAR:    UIAQuery.query('FullDocumentManagerViewControllerNavigationBar').andThen(UIAQuery.query('Recents')),

    /** Search bar */
    SEARCH_BAR:      UIAQuery.searchBars('Search'),
};


/*******************************************************************************/
/*                                                                             */
/*   Other Constants - Any other app specific constants                        */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var files = target.appWithBundleID('com.apple.DocumentsApp');



/*******************************************************************************/
/*                                                                             */
/*   Helper functions for navigating to different pages within the app         */
/*                                                                             */
/*******************************************************************************/

/**
 * Go to top level view of app.
 */
files.getToAppTopLevel = function getToAppTopLevel() {
    this.tapIfExists(UIAQuery.Files.RECENTS_BUTTON);
}


/***********************************************************************************/
/*                                                                                 */
/*   A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail     */
/*   These will be comprised of multiple Action functions                          */
/*                                                                                 */
/***********************************************************************************/

/**
 * Basic verification of top level UI components
 */
files.verifyMainUI = function verifyMainUI() {
    var errString = '';

    this.launch();
    this.getToAppTopLevel();

    if (this.exists(UIAQuery.Files.BROWSE_BUTTON) !== true) {
        errString += " Browse Button ";
    } else {
        this.tap(UIAQuery.Files.BROWSE_BUTTON);
    }

    if (this.exists(UIAQuery.Files.RECENTS_BUTTON) !== true) {
        errString += " Recents Button ";
    } else {
        this.tap(UIAQuery.Files.RECENTS_BUTTON);
    }

    if (this.exists(UIAQuery.Files.MAIN_NAV_BAR) !== true) {
        errString += " Navigation Bar ";
    }
    if (this.exists(UIAQuery.Files.SEARCH_BAR) !== true) {
        errString += " Search Bar ";
    }

    if (errString.length > 0) {
        throw new UIAError("Missing UI Components:" + errString);        
    }
}
