load('UIATesting.js');
load('Files.js');

UIAUtilities.assert(
    typeof FilesTests === 'undefined',
    'FilesTests undefined'
);

/**
 * @namespace FilesTests
 */
var FilesTests = {

    /**
      * Launch Files app and do basic verification of top level user interface
      *
      * @targetApps Files
      *
      */
    launchAndVerifyInterface: function launchAndVerifyInterface() {
        files.verifyMainUI();
    },
}