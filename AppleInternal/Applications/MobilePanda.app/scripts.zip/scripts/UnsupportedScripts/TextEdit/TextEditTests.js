load('UIATesting.js');
load('TextEdit.js');

UIAUtilities.assert(
    typeof TextEditTests === 'undefined',
    'TextEditTests undefined'
);

/**
 * Default note testing arguments. All function comment
 * parameter listings should exactly match these!
 */
var TEST_ARG_DEFAULTS = {
    TITLE: 'Hello',
    BODY: 'This is the specialist note',
    BODYBEFORECOPY: 'This is the specialist ',
    BODY_MANIPULATED: 'This is the specialist notenote',
};

/**
 * @namespace TextEditTests
 */
var TextEditTests = {
    /**
     * Create a new note.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="Hello"]
     *                       - (Required) Title of note.
     * @param {string} [args.noteContents="This is the specialist note"]
     *                       - (Optional) Body of note.
     */
    createNote: function createNote(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: TEST_ARG_DEFAULTS.TITLE,
            noteContents: TEST_ARG_DEFAULTS.BODY,
        });
        textedit.createNote(args.noteContents, args);
    },
    
    /**
     * Edit a note.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="Hello"]
     *                       - (Required) Title of note.
     * @param {string} [args.noteContents="This is the specialist note"]
     *                       - (Optional) Body of note.
     */
    editNote: function editNote(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: "Hello",
            noteContents: TEST_ARG_DEFAULTS.BODY,
        });
        textedit.editNote(args.noteContents, args.noteTitle);
    },
    
    /**
     * Verify number of notes are as expected or not.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.numNote="6"]
     *                       - (Required) Number of notes to expect.
     */
    verifyNoteNumbers: function verifyNoteNumbers(args) {
        args = UIAUtilities.defaults(args, {
            numNote: "6",
        });
        
        textedit.verifyNoteCount(args.numNote);
    },
    
    /**
     * Verify a note exists or not.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="txt-0001"] - (Required) Title of the note
     * @param {string} [args.folderName=null] - (Optional) Folder name
     */
    verifyNoteExists: function verifyNoteExists(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: "txt-0001",
            folder: false,
            folderName: null
        });
    
        textedit.searchTENotes(args.noteTitle, args);
    },
    
    /**
     * Verify a note does not exists.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="Hello"] - (Required) Title of the note
     */
    verifyNoteDoesNotExists: function verifyNoteDoesNotExists(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: "Hello",
        });
        
        var count = textedit.getNoteCount();
        UIALogger.logMessage('We need to use complex or random security code, lets tap on advanced options!');
        UIALogger.logMessage(count);
        if(count > 0) {
            var failFlag = textedit.searchTENotes(args.noteTitle);
            if (!failFlag) {
                throw new UIAError('The note still exists. Failing test.');
            }
        }
    },
    
    /**
     * Verify contents of notes are as expected or not.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="Hello"] - (Required) Title of the note
     * @param {string} [args.expected="Hello"] - (Required) Title of the note
     */
    confirmExpectedNoteContent: function confirmExpectedNoteContent(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: "Hello",
            expected: "Hello",
        });
    
        textedit.searchTENotes(args.noteTitle);
        textedit.confirmExpectedNoteContent(args.expected);
    },
    
    /**
     * Deletes a note with given title.
     *
     * @targetApps TextEdit
     *
     * @param {object} args - Test arguments
     * @param {string} [args.noteTitle="Hello"] - (Required) Title of the note
     */
    deleteNote: function deleteNote(args) {
        args = UIAUtilities.defaults(args, {
            noteTitle: TEST_ARG_DEFAULTS.TITLE,
        });
    
        textedit.searchTENotes(args.noteTitle);
        textedit.deleteNote(args.noteTitle);
    },
    
    /**
     * Deletes all notes.
     *
     * @targetApps TextEdit
     */
    deleteAllNotes: function deleteAllNotes() {
        textedit.deleteAllNotes();
    },
    
};



