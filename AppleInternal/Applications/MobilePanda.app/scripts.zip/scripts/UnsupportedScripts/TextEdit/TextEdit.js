load('UIAApp.js');
load('UIAApp+Mail.js');
load('UIAApp+Photos.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof textedit === 'undefined',
    'textedit undefined'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common TextEdit queries */
UIAQuery.TextEdit = {
    /* Delete button: */
    DELETE_NOTE: UIAQuery.tableCells().andThen(UIAQuery.buttons('Delete')),

    /* Create a new note: */
    NEW_NOTE_BUTTON:                    UIAQuery.buttons('Compose').orElse(UIAQuery.buttons('New note')).orElse(UIAQuery.buttons().contains('compose').isVisible()),

    /* First file in some specified folder */
    TOP_FILE:                           UIAQuery.tableViews().last().andThen(UIAQuery.tableCells().first()),

    /* Back button on the navigation bar. Needed for iPhones. */
    BACK_NAV_BUTTON:                    UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Back')),

    /* Textview of the note. Text content is stored inside this element. */
    NOTE_TEXT_CONTENT:                  UIAQuery.textViews(),
    
    /* Add Button: */
    ADD_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Add")),
    
    /* Cancel Button: */
    CANCEL_BUTTON: UIAQuery.buttons('Cancel'),
    
    /* Done Button: */
    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Done")),
    
    /* Rename Done Button */
    RENAME_DONE: UIAQuery.buttons("Done"),
    
    /* Agree Button */
    AGREE_BUTTON: UIAQuery.buttons("Agree"),
    
    /* Clear text Button: */
    CLEAR_TEXT_BUTTON: UIAQuery.buttons().withPredicate('name contains[c] "Clear text"'),
    
    /* Edit Button: */
    EDIT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Edit")),
    
    /* Delete Button: */
    DELETE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Delete")),
    
    /* Back Button: */
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("TextEdit")).orElse(UIAQuery.buttons('Files')),
    
    /* Share Button: */
    SHARE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Share")),
    
    /* Search Button: */
    SEARCH_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Search")),
    
    /* More Info Button: */
    MORE_INFO_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("More Info")),
    
    /* Organize Button: */
    ORGANIZE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Organize")),
    
    /* Deleting notes Button for determining state for the deletion of notes */
    DELETE_CURRENT_NOTE_BUTTON: UIAQuery.buttons().withPredicate('name contains[c] "Delete "'),
    
    /* Delete  Button */
    DELETE: UIAQuery.buttons('Delete'),
    
    /* Table Views: */
    TABLE_VIEWS: UIAQuery.tableViews(),
    
    /* Text Views: */
    TEXT_VIEWS:    UIAQuery.textViews(),
    
    /* File name here: */
    FILE_NAME:  UIAQuery.textFields('Your File Name Here'),
    
    /* Sample query for deleting a single note button "Delete 5/3/01, 8:12 PM"*/
    
    /** Alerts */
    Alerts:                     {
        
        /** 'Confirm' alert */
        CONFIRM_ALERT: UIAQuery.beginsWith('Confirm'),
        
        /** 'Renaming' alert */
        RENAMING_ALERT:           UIAQuery.contains('Renaming'),
        
    },

    ALERT_TEXTFIELD: UIAQuery.query('_UIInterfaceActionGroupHeaderScrollView').andThen(UIAQuery.textFields().bottommost()),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to TextEdit */
UIStateDescription.TextEdit = {
    
    /** Welcome Page */
    WELCOME_PAGE:                                 'welcome page',
    
    /** File Lists */
    FILE_LISTS:                                   'file list',

    /** Add a new document. */
    ADD_DOCUMENTS:                                'add new documents (options)',
    
    /** Add a new document. */
    ADD_NEW_DOCUMENT:                             'add new document',
    
    /** TODO - Add a new document. */
    ADD_TEMPLATE_DOCUMENT:                        'add new document from template',

    /** Edit mode on a note. Same mode for compose. */
    EDIT_NOTE:                                    'compose/edit a note',

    /** Edit mode on a note. Same mode for compose. Delete note prompt. */
    EDIT_NOTE_DELETE:                             'compose/edit a note (delete)',
    
    /** Rename mode on a note. Used for renaming document once it has been created. */
    EDIT_NOTE_RENAME:                             'rename a note',
    
    /** Read mode on a note. */
    READ_NOTE:                                    'open a note',
    
    /** Rename mode on a note. */
    RENAME_NOTE:                                  'rename a note',

    /** TODO - Share note menu. */
    EDIT_NOTE_SHARE_MENU:                         'share menu',

    /** TODO - Turn on icloud notification (can come up at different times) */
    TURN_ON_ICLOUD_DRIVE:                         'Folder contents on iCloud Drive',

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 *   @namespace {UIAApp} TextEdit
 */
var textedit = target.appWithBundleID('com.apple.TextEdit');

/**
 *  Constants for TextEdit
 */
textedit.Constants = {
    TextEdit:   'TextEdit',
};

function isHorizontalRegularUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription
 * constants defined in UIAApp and Notes for possible values.
 *
 * TODO: Editing a note, sharing it on iCloud drive
 * TODO:
 * TODO: Flush out more of the share menu
 *
 * @returns {string} Description of current UI state from a list of
 *           possible constants contained in UIStateDescription.
 */
textedit.getCurrentUIState = function getCurrentUIState() {
    this.launch();
    
    //<rdar://problem/23828937> Welcome page doesn't shows up as soon as the TextEdit App is launched.
    target.delay(5);
    if (this.exists(UIAQuery.TextEdit.ADD_BUTTON.isEnabled())) {
        return UIStateDescription.TextEdit.FILE_LISTS;
    }
    
    if (this.exists(UIAQuery.contains('User Agreement')) && this.exists(UIAQuery.TextEdit.AGREE_BUTTON.isEnabled())) {
        return UIStateDescription.TextEdit.WELCOME_PAGE;
    }
    
    if (this.exists(UIAQuery.contains('New Document')) || this.exists(UIAQuery.contains('New From Template'))) {
        return UIStateDescription.TextEdit.ADD_DOCUMENTS;
    }
    
    if (this.exists(UIAQuery.contains('Untitled')) && this.exists(UIAQuery.windows('UIRemoteKeyboardWindow').andThen(UIAQuery.keyboard().isVisible()))) {
        return UIStateDescription.TextEdit.ADD_NEW_DOCUMENT;
    }

    if (this.exists(UIAQuery.navigationBars('Share via iCloud').isVisible())) {
        return UIStateDescription.TextEdit.EDIT_NOTE_SHARE_MENU;
    }

    if (!this.exists(UIAQuery.contains('Untitled')) && this.exists(UIAQuery.windows('UIRemoteKeyboardWindow').andThen(UIAQuery.keyboard().isVisible())) && this.exists(UIAQuery.TextEdit.DONE_BUTTON.isEnabled())) {
        return UIStateDescription.TextEdit.EDIT_NOTE;
    }
    
    if (this.exists(UIAQuery.TextEdit.SEARCH_BUTTON.isEnabled())) {
        return UIStateDescription.TextEdit.READ_NOTE;
    }

    if (this.exists(UIAQuery.TextEdit.DELETE_CURRENT_NOTE_BUTTON)) {
        return UIStateDescription.TextEdit.EDIT_NOTE_DELETE;
    }
    
    if (this.exists(UIAQuery.contains('Size')) && this.exists(UIAQuery.TextEdit.DONE_BUTTON.isEnabled()) && this.exists(UIAQuery.TextEdit.FILE_NAME)) {
        return UIStateDescription.TextEdit.RENAME_NOTE;
    }
    
    // if we get to here, we have no idea where we are...
    throw new UIAError('Cannot determine state.');
}

textedit.launchTextEdit = function launchTextEdit() {
    textedit.launch();
    target.setDeviceOrientation(UIADeviceOrientation.FACE_UP);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/**
* Navigation function to get to the main folder list UI from some starting
* state.
* Any critia for defining a transition from a state to the main
* folder list state should be very exact so we always end up in the main
* folder list state or else throw.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If transition from startin state to main files list UI has not been
*           defined in this function yet.
*/
textedit.getToFileList = function getToFileList() {
    this.launchTextEdit();

    var maxDepth = 5;
    UIALogger.logMessage('Navigating to %0 UI'.format(UIStateDescription.TextEdit.FILE_LISTS));
    
    for (var i = 0; i < maxDepth; i++) {
        var currentState = this.getCurrentUIState();
        UIALogger.logMessage('Current state: \'%0\''.format(currentState));

        if (currentState === UIStateDescription.TextEdit.FILE_LISTS) {
            return;
        }

        var waiter = UIAWaiter.waiter('ViewDidAppear');
        switch (currentState) {
            case UIStateDescription.TextEdit.ADD_DOCUMENTS:
                this.tapIfExists(UIAQuery.TextEdit.CANCEL_BUTTON);
                break;
            case UIStateDescription.TextEdit.ADD_NEW_DOCUMENT:
                this.tapIfExists(UIAQuery.TextEdit.BACK_BUTTON);
                break;
            case UIStateDescription.TextEdit.EDIT_NOTE_SHARE_MENU:
                this.tapIfExists(UIAQuery.TextEdit.CANCEL_BUTTON);
                break;
            case UIStateDescription.TextEdit.EDIT_NOTE:
                this.tapIfExists(UIAQuery.TextEdit.BACK_BUTTON);
                break;
            case UIStateDescription.TextEdit.READ_NOTE:
                this.tapIfExists(UIAQuery.TextEdit.BACK_BUTTON);
                break;
            case UIStateDescription.TextEdit.DELETE_CURRENT_NOTE_BUTTON:
                this.tapIfExists(UIAQuery.TextEdit.DONE_BUTTON);
                break;
            case UIStateDescription.TextEdit.RENAME_NOTE:
                this.tapIfExists(UIAQuery.TextEdit.DONE_BUTTON);
                break;
            case UIStateDescription.TextEdit.WELCOME_PAGE:
                var confirmAlert = UIAQuery.alerts().andThen(UIAQuery.TextEdit.Alerts.CONFIRM_ALERT);
                this.handlingAlertsInline(confirmAlert, function () {
                    //<rdar://problem/23828937> Welcome page doesn't shows up as soon as the TextEdit App is launched.
                    target.delay(5);
                    this.tapIfExists(UIAQuery.TextEdit.AGREE_BUTTON);
                    if (this.waitUntilPresent(confirmAlert, 30)) {
                        textedit.tap('default-button');
                    }
                });
                break;
            default:
                // we found and new state and need to update
                throw new UIAError('Current UI State unexpected. Update getToFolderList with new state: %0'.format(currentState));
        }
        waiter.wait(2);
    }

    var previousState = currentState;
    currentState = this.getCurrentUIState();

    if (currentState !== UIStateDescription.TextEdit.FILE_LISTS) {
        throw new UIAError('Could not get to \'%0\' UI from \'%1\' UI'.format(UIStateDescription.TextEdit.FILE_LISTS, currentState));
    }

}

/**
* Navigation function to get to the top note
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*/
textedit.getToTopNote = function getToTopNote() {
    this.getToFileList();
    //this.tap("UIViewControllerWrapperView");
    this.tap(UIAQuery.TextEdit.TOP_FILE);
}

/**
 * If any dialogs, popovers, etc are open, we dismiss them so we get to
 * a known state
 *
 * Expected starting states: EDIT_NOTE*
 *
 * @return None
 */
textedit.getToDefaultNoteState = function getToDefaultNoteState() {
    //this.dismissPopovers();
    var currentState = this.getCurrentUIState();
    switch (currentState) {
        case UIStateDescription.TextEdit.EDIT_NOTE:
            this.dismissKeyboard();
            break;
        default:
    }
}


/**
 * Get to old list view
 *
 * @return None
 */
textedit.getTolistNoteState = function getTolistNoteState() {
    //this.dismissPopovers();
    //this.drag(UIAQuery.collectionViews(), {startOffset: {x: 0.85, y: 0.12}, duration: 1.95, endOffset: {x: 0.87, y: 0.33}});
    this.delay(2);
    //this.tap("UIViewControllerWrapperView");
    this.delay(10);
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - createNote          */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


/**
 * Create a note
 *
 * @param {string} noteContents - String to be
 *                     typed into the note.
 * @param {object} options - Options dictionary
 * @param {string} options.noteTitle - If set, note will not
 */
textedit.createNote = function createNote(noteContents, options) {
    options = UIAUtilities.defaults(options, {
        noteTitle: 'Hello',
    });
    
    var nextViewAppeared = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "_UIDocumentPickerRemoteViewController"',
        }
    );

    this.getToFileList();
    this.getTolistNoteState();
    this.tap(UIAQuery.TextEdit.ADD_BUTTON);
    if (!nextViewAppeared.wait(5)) {
        UIALogger.logWarning("'_UIDocumentPickerRemoteViewController' never appeared after 5s");
    }
    
    this.tap(UIAQuery.contains('New Document'));
    // bring keyboard up
    if (!this.exists(UIAQuery.keyboard().isVisible())) {
        this.tap(UIAQuery.TextEdit.NOTE_TEXT_CONTENT);
    }
    this.waitUntilPresent(UIAQuery.keyboard(), 5);
    if (!this.exists(UIAQuery.keyboard())) {
        throw new UIAError('Keyboard did not appear');
    }
    this.typeString(noteContents);
    textedit.tapIfExists('back-nav-button');
    this.tapIfExists(UIAQuery.TextEdit.DONE_BUTTON);
    var count = this.getNoteCount();
    var defaultNoteTitle = this.inspect(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().andThen(UIAQuery.withPredicate("name BEGINSWITH 'Untitled'")))).name;

    // Assume we want to take text up to first ',' as actual filename
    var i = defaultNoteTitle.indexOf(',');
    var realDefaultNoteTitle = defaultNoteTitle.slice(0,i);
    this.renameNewNote(realDefaultNoteTitle, options.noteTitle);
}

/**
 * Searches if a document exists and opens it for read.
 *
 * * @param {string} noteTitle - note title to search against
 */
textedit.searchTENotes = function searchTENotes(noteTitle, options) {
    options = UIAUtilities.defaults(options, {
        folder: false,
        folderName: null,
    });
    
    this.getToFileList();
    UIAUtilities.assertNotEqual(
        0,
        this.getNoteCount(),
        'No notes exists. Cannot search.'
    );
    
    if (options.folder) {
        if(this.exists(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().andThen(UIAQuery.contains(options.folderName))))) {
           this.tap(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().andThen(UIAQuery.contains(options.folderName))));
        }
    }
    
    if (!this.exists(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().andThen(UIAQuery.contains(noteTitle))))) {
        return 1;
    }
    
    this.tap(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().andThen(UIAQuery.contains(noteTitle))));
}

/*
* Finds number of document exists.
*/
textedit.getNoteCount = function getNoteCount() {
    this.getToFileList();
    var theCount;
    theCount = this.count(UIAQuery.query('UICollectionViewCellAccessibilityElement'));
    return theCount;
}

/*
 * Finds if correct number of documents exists.
 * @param {string} numNote - number of Notes available
 */
textedit.verifyNoteCount = function verifyNoteCount(numNote) {
    this.getToFileList();
    var count = this.getNoteCount();
    if(numNote != count) {
        throw new UIAError('Number of notes are ' + count + ' ,not as expected: ' + numNote);
    }
}


/**
 * Edit a note
 *
 * @param {string} noteContents - String to be
 *                     typed into the note.
 * @param {object} options - Options dictionary
 * * @param {string} noteTitle - note title to search against
 */
textedit.editNote = function editNote(noteContents, noteTitle) {
    
    this.searchTENotes(noteTitle);
    
    this.tap(UIAQuery.TextEdit.NOTE_TEXT_CONTENT);
    
    // bring keyboard up
    if (!this.exists(UIAQuery.keyboard().isVisible())) {
        this.tap(UIAQuery.TextEdit.NOTE_TEXT_CONTENT);
    }
    this.waitUntilPresent(UIAQuery.keyboard(), 5);
    if (!this.exists(UIAQuery.keyboard())) {
        throw new UIAError('Keyboard did not appear');
    }
    this.typeString(noteContents);
    this.tapIfExists(UIAQuery.TextEdit.DONE_BUTTON);
    this.getToFileList();
}

/**
 * Checks to see if the passed values are the same. If not, we throw.
 */
textedit.confirmExpectedNoteContent = function confirmExpectedNoteCount(expected) {
    var currentContent = this.getNoteTextContent();
    
    if ((currentContent === undefined) && (expected === "") ) {
        return;
    }
    
    if ( expected !== currentContent ) {
        throw new UIAError("Expecting: '%0' Actual: '%1'".format(expected, currentContent));
    }
}

/**
 * Delete a note
 *
 * @param {object} options - Options dictionary
 * * @param {string} noteTitle - note title to search against
 */
textedit.deleteNote = function deleteNote(noteTitle) {
    this.getToFileList();
    this.touchAndHold(UIAQuery.tableCells().contains(noteTitle), 2.00);
    this.tap("Delete…");
    this.tap("destructive-button");
    //if(this.exists(UIAQuery.query('UICollectionViewCellAccessibilityElement').andThen(UIAQuery.contains(noteTitle)))) {
        //this.touchAndHold(UIAQuery.query('UICollectionViewCellAccessibilityElement').andThen(UIAQuery.contains(noteTitle)), 1.0);
        
        //var timestamp = this.getTimeStamp(noteTitle);
        //this.tapIfExists(UIAQuery.TextEdit.EDIT_BUTTON);
        //var delButton = "Delete %0".format(timestamp);
        //this.tap(UIAQuery.buttons().withPredicate('name contains[c] "%0"'.format(delButton)));
        //this.tapIfExists(UIAQuery.TextEdit.DELETE);
    //}
}

/**
 * Deletes all notes.
 */
textedit.deleteAllNotes = function deleteAllNotes(){
    var notesCount = this.getNoteCount();
    for (i = 0; i < notesCount; i++) {
        var nameOfFirstNote = textedit.inspect(UIAQuery.collectionViews().andThen(UIAQuery.tableCells().first()).andThen(UIAQuery.staticTexts().topmost())).name;
        UIALogger.logMessage("Name of the first note is " + nameOfFirstNote + " deleting it now..");
        this.deleteNote(nameOfFirstNote);
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - getNoteCount                     */
/*      Other helper functions. E.g. - getNoteTextContent                      */
/*                                                                             */
/*******************************************************************************/





/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Renames the most latest created note.
 *
 * * @param {string} noteTitle - note title to search against
 */
textedit.renameNewNote = function renameNewNote(noteTitle, newnoteTitle) {
    this.getToFileList();
    this.touchAndHold(UIAQuery.tableCells().contains(noteTitle), 2.00);
    var renameAlert = UIAQuery.alerts().andThen(UIAQuery.TextEdit.Alerts.RENAMING_ALERT);
    this.handlingAlertsInline(renameAlert, function () {
        this.tap('Rename…');
        if (this.waitUntilPresent(renameAlert, 30)) {
            this.tap('Clear text');
            this.enterText(UIAQuery.TextEdit.ALERT_TEXTFIELD, newnoteTitle);
            this.tap('default-button');
        }
    });
}

/**
 * Gets the text content on a note.
 *
 * Required Starting View: Inside a note.
 */
textedit.getNoteTextContent = function getNoteTextContent() {
    return this.valueOf(UIAQuery.TextEdit.NOTE_TEXT_CONTENT).trim();
}

/**
 * Gets the time stamp for creation of a note.
 *
 * Required Starting View: File List
 * * @param {string} noteTitle - note title to search against
 */
textedit.getTimeStamp = function getTimeStamp(noteTitle) {
    return this.nameOf(UIAQuery.staticTexts(noteTitle).siblings());

}
