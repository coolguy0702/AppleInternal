App: VainGlory
Maintainer(s): Alejandro Ramirez
Maintainer(s) Email: aramirez5@apple.com
Maintainer(s) Team: PEP Automation Team
Maintainer(s) Team Manger: Alok Ahuja
Maintainer(s) Team Manger Email: aahuja@apple.com