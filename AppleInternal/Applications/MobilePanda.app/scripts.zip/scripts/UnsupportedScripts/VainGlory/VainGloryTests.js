load('UIATesting.js');
load('VainGlory.js');
load('SpringBoard.js');

if (typeof VainGloryTests === 'undefined') {
    /**
     * @namespace
     */
    var VainGloryTests = {
        /**
         * Test gets past the required Initiation Phase so we can get to actual bot testing
         *
         * @targetApps VainGlory
         */
        getPastInitiation: function getPastInitiation() {
            vg.launch();

            options = {
                selections: ["Solo Mode", "Initiation", "Start"],
                hero: "Ringo"
            };

            vg.navigateMenu(options);

            vg.playInitiation();
        },

        /**
         * Test begins a Solo Practice game
         *
         * @targetApps VainGlory
         */
        startSoloPractice: function startSoloPractice() {
            vg.launch();

            options = {
                selections: ["Solo Mode", "Initiation", "Start"],
                hero: "Ringo"
            };

            vg.startNewPractice(options);
        },

        /**
         * Test plays a Solo Practice game
         *
         * @targetApps VainGlory
         */
        playSoloPractice: function playSoloPractice() {
            vg.launch();

            options = {
                selections: ["Solo Mode", "Initiation", "Start"],
                hero: "Ringo"
            };

            vg.playGame(options);
        },

        /**
         * Test quits a Solo Practice game
         *
         * @targetApps VainGlory
         */
        quitSoloPractice: function quitSoloPractice() {
            vg.launch();

            vg.quitPractice(options);
        }
    }
}
