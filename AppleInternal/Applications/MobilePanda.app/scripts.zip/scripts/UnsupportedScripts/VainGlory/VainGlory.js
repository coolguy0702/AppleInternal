load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof vg === 'undefined',
    "VainGlory has already been defined"
);

/**
 * @namespace {UIAApp} vg
 */
var vg = target.appWithBundleID('com.superevilmegacorp.kindred');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.VainGlory = {
    /**
     * Menu item locations
     */
    MAIN_MENU: {
        BACK: {x:35.50, y:39.50},

        PLAY: {x:36.00, y:275.00},

        NEWS: {x:36.00, y:300.00},

        ACADEMY: {x:36.00, y:360.00},

        FRIENDS: {x:36.00, y:420.00},

        MARKET: {x:36.50, y:480.00},

        PROFILE: {x:32.00, y:717.00},
    },

    /**
     * Play Menu item locations
     */
    PLAY_MENU: {
        PRACTICE: {x:436.00, y:722.50},
    },

    /**
     * Party Menu item locations
     */
    PARTY_MENU: {
        LEAVE_PARTY: {x:258.00, y:710.50},
    },

    /**
     * Practice Menu item locations
     */
    PRACTICE_MENU: {
        SOLO_PRACTICE: {x:197.00, y:551.00},
    },

    /**
     * Choose Hero item locations
     */
    CHOOSE_HERO: {
        JOULE: {x:58.00, y:459.00},

        START_GAME: {x:952.50, y:371.50},

        EXIT_PRACTICE: {x:598.50, y:24.00},
    },

    /**
     * In Game item locations
     */
    IN_GAME: {
        SHOP: {x:984.50, y:730.50},

        SCORE: {x:929.50, y:726.50},

        TELEPORT: {x:814.00, y:729.00},

        EXIT_PRACTICE: {x:489.50, y:623.50},
    },

    /**
     * In Shop item locations
     */
    IN_SHOP: {
        CLOSE_SHOP: {x:991.00, y:49.00},

        RECOMMENDED: {x:66.50, y:187.00},

        WEAPON: {x:68.00, y:265.00},

        ABILITY: {x:64.00, y:344.00},

        DEFENSE: {x:69.00, y:415.00},

        UTILITY: {x:68.50, y:493.50},

        CONSUMABLES: {x:66.00, y:578.00},

        POT_OF_GOLD: {x:618.50, y:413.50},

        LEVEL_JUICE: {x:612.00, y:485.00},

        WEAPON_INFUSION: {x:623.00, y:256.00},

        CRYSTAL_INFUSION: {x:611.00, y:329.50},

        SCOUT_TRAP: {x:389.50, y:330.50},

        BUY: {x:971.50, y:653.50},
    },

    /**
     * Post Game item locations
     */
    POST_GAME: {
        DETAILS: {x:336.00, y:687.50},

        FINISH: {x:667.50, y:685.00},
    },
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to VainGlory */
UIStateDescription.VainGlory = {
    /** Main menu */
    MAIN_MENU:              'Main Menu',

    /** Play menu */
    PLAY_MENU:              'Play',

    /** Practice menu */
    PRACTICE_MENU:          'Practice',

    /** Party menu */
    PARTY_MENU:             'Party',

    /** Choosing a hero menu */
    CHOOSE_HERO:            'Choose',

    /** In-game screen */
    IN_GAME:                'N/A',

    /** Shopping screen */
    IN_SHOP:                'Shop',

    /** Post-game screen */
    POST_GAME:              'VICTORY' || 'DEFEAT',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.
* See VainGlory UIStateDescription constants for possible values.
* Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw
* if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in VainGlory UIStateDescription.
*
* @throws If cannot determine state.
*/
vg.currentUIState = function currentUIState() {
    // TODO: make constants for my switch statement
    // TODO: make constants for queries

    UIALogger.logMessage('Evaluating current UI state ...');

    // TODO: figure out how to grab the UI state with no labels (OCR?)
    //var currentUIState =  this.__proto__.currentUIState.apply(this);

    switch (currentUIState) {
        case 'Main Menu':
            return UIStateDescription.VainGlory.MAIN_MENU;
        default:
            UIALogger.logMessage('Unknown UI state...');
    }

    // we have no idea where we are
    throw new UIAError('Could not determine state.');
}

    // TODO: I'll deal with this later
    // Beacons !#$%*
    // vg.inGame_questionBeacon = function() {
    //     vg.tap({x:1005.00, y:22.00});
    // }
    // vg.inGame_arrowsBeacon = function() {
    //     vg.tap({x:948.00, y:22.00});
    // }
    // vg.inGame_runBeacon = function() {
    //    vg.tap({x:908.50, y:24.00});
    // }
    // vg.inGame_warnBeacon = function() {
    //     vg.tap({x:862.50, y:20.00});
    // }
    // vg.inGame_targetBeacon = function() {
    //     vg.tap({x:810.00, y:26.00});
    // }

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Attempts to back out of any menu into the top Main Menu
 *
 * Expected starting states: MAIN_MENU
 */
vg.allTheWayBack = function allTheWayBack() {
    vg.tap(UIAQuery.VainGlory.MAIN_MENU.BACK);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.MAIN_MENU.PLAY);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.PARTY_MENU.LEAVE_PARTY);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.MAIN_MENU.BACK);
    this.delay(2);
}

/**
 * Attempts to start a new Practice match
 *
 * Expected starting states: MAIN_MENU
 */
vg.startNewPractice = function startNewPractice() {
    vg.tap(UIAQuery.VainGlory.MAIN_MENU.PLAY);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.PLAY_MENU.PRACTICE);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.PRACTICE_MENU.SOLO_PRACTICE);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.CHOOSE_HERO.JOULE);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.CHOOSE_HERO.START_GAME);
    this.delay(10);
}

/**
 * Attempts to quit Practice mode
 *
 * Expected starting states: IN_GAME
 */
vg.quitPractice = function quitPractice() {
    vg.tap(UIAQuery.VainGlory.IN_GAME.SCORE);
    this.delay(2);

    vg.tap(UIAQuery.VainGlory.IN_GAME.EXIT_PRACTICE);
    this.delay(5);

    vg.tap(UIAQuery.VainGlory.POST_GAME.FINISH);
    this.delay(10);
}

// GAME BEHAVIORS

/**
 * In game behavior: Rush forward
 *
 * Expected starting states: IN_GAME
 *
 * @param {object} options - Options dictionary
 * @param {boolean} options.leftTeam - Determines our orientation
 *                      (true means we face right, false means face left)
 */
vg.inGame_rush = function inGame_rush(options) {
    if (options.leftTeam) {
        vg.tap({tapOffset:{x:0.75, y:0.5}});
    } else {
        vg.tap({tapOffset:{x:0.25, y:0.5}});
    }
}

/**
 * In game behavior: Attempt to attack
 *
 * Expected starting states: In Game
 *
 * @param {object} options - Options dictionary
 * @param {boolean} options.leftTeam - Determines our orientation
 *                      (true means we face right, false means face left)
 */
vg.inGame_attack = function inGame_attack(options) {
    if (options.leftTeam) {
        vg.tap({tapOffset:{x:Math.random()*0.7+0.3, y:Math.random()*0.5+0.18}});
    } else {
        vg.tap({tapOffset:{x:Math.random()*0.3-0.3, y:Math.random()*0.5+0.18}});
    }
    this.delay(Math.random());
}

/**
 * In game behavior: Attempt to be a wuss
 *
 * Expected starting states: In Game
 *
 * @param {object} options - Options dictionary
 * @param {boolean} options.leftTeam - Determines our orientation
 *                      (true means we face right, false means face left)
 */
vg.inGame_retreat = function inGame_retreat(options) {
    if (options.leftTeam) {
        vg.tap({tapOffset:{x:0.2, y:0.3}});
        vg.tap({tapOffset:{x:0.3, y:0.2}});
    } else {
        vg.tap({tapOffset:{x:0.7, y:0.3}});
        vg.tap({tapOffset:{x:0.8, y:0.2}});
    }
    this.delay(0.25);
}

/**
 * In game behavior: Upgrade our abilities
 *
 * Expected starting states: In Game
 */
vg.inGame_upgradeAbilities = function inGame_upgradeAbilities() {
    vg.tap({x:595.00, y:666.50});
    this.delay(0.5);
    vg.tap({x:419.50, y:663.50});
    this.delay(0.5);
    vg.tap({x:513.50, y:670.00});
    this.delay(0.5);
    vg.tap({tapOffset:{x:0.75, y:0.2}});
    this.delay(1);
}

/**
 * In game behavior: Attempt to use an ability
 *
 * Expected starting states: In Game
 *
 * @param {object} options - Options dictionary
 */
vg.inGame_ability = function inGame_ability(options) {
    vg.tap({x:595.00, y:666.50});
    vg.inGame_attack(options);
    this.delay(1);

    vg.tap({x:431.50, y:721.50});
    vg.inGame_attack(options);
    this.delay(1);

    vg.tap({x:513.50, y:724.00});
    vg.inGame_attack(options);
    this.delay(1);
}

/**
 * In game behavior: Attempt to attack
 *
 * Expected starting states: In Game
 */
vg.inGame_juiceUp = function inGame_juiceUp() {
    vg.inGame_letsGoShopping(["Pot of Gold", "Pot of Gold", "Pot of Gold", "Pot of Gold", "Level Juice", "Level Juice"]);
    for(var i = 0; i < 6; i+=1) {
        vg.inGame_lay6Traps();
    }
    vg.tap(UIAQuery.VainGlory.IN_GAME.TELEPORT);
    this.delay(6);
    vg.tap(UIAQuery.VainGlory.IN_GAME.SHOP);
    this.delay(1);
    vg.inShop_sellEverything();
    vg.tap(UIAQuery.VainGlory.IN_SHOP.CLOSE_SHOP);
}

/**
 * In game behavior: Attempt to go shopping
 *
 * Expected starting states: In Game
 *
 * @param {list} list - List of items to buy
 */
vg.inGame_letsGoShopping = function inGame_letsGoShopping(list) {
    vg.tap(UIAQuery.VainGlory.IN_GAME.SHOP);
    this.delay(1);
    for (var i = 0; i < list.length; i += 1) {
        UIALogger.logMessage("Buying " + list[i]);
        switch (list[i]) {
            case "Pot of Gold":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.CONSUMABLES);
                vg.tap(UIAQuery.VainGlory.IN_SHOP.POT_OF_GOLD);
                break;
            case "Level Juice":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.CONSUMABLES);
                vg.tap(UIAQuery.VainGlory.IN_SHOP.LEVEL_JUICE);
                break;
            case "Sorrowblade":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.WEAPON);
                vg.tap({x:620.00, y:130.00});
                break;
            case "Shatterglass":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.ABILITY);
                vg.tap({x:620.00, y:130.00});
                break;
            case "Clockwork":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.ABILITY);
                vg.tap({x:617.00, y:448.50});
                break;
            case "Contraption":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.UTILITY);
                vg.tap({x:623.50, y:336.00});
                break;
            case "Crucible":
                vg.tap(UIAQuery.VainGlory.IN_SHOP.DEFENSE);
                vg.tap({x:623.50, y:216.00});
                break;
        }
        this.delay(1);
        vg.tap(UIAQuery.VainGlory.IN_SHOP.BUY);
        this.delay(1);
    }
    vg.tap(UIAQuery.VainGlory.IN_SHOP.CLOSE_SHOP);
}

/**
 * In game behavior: Sell everything
 *
 * Expected starting states: In Shop
 */
vg.inShop_sellEverything = function inShop_sellEverything() {
    for (var i = 0; i < 8; i += 1) {
        vg.tap({x:352.00, y:684.50});
        this.delay(1);
        vg.inShop_buy();  // sell
        this.delay(1);
    }
}

/**
 * In game behavior: Sell everything
 *
 * Expected starting states: In Game
 */
vg.buyALottaScoutTraps = function buyALottaScoutTraps() {
    for (var i = 0; i < 5; i++) {vg.inGame_retreat();}
    vg.tap(UIAQuery.VainGlory.IN_GAME.TELEPORT);
    this.delay(6);
    vg.tap(UIAQuery.VainGlory.IN_GAME.SHOP);
    this.delay(1);
    vg.tap(UIAQuery.VainGlory.IN_SHOP.CONSUMABLES);
    this.delay(1);
    vg.tap(UIAQuery.VainGlory.IN_SHOP.SCOUT_TRAP);
    for (var i=0;i<30;i++){vg.tap(UIAQuery.VainGlory.IN_SHOP.BUY);this.delay(1);}
    vg.tap(UIAQuery.VainGlory.IN_SHOP.CLOSE_SHOP);
    this.delay(1);
}

/**
 * In game behavior: Attempt to lay 6 scout traps
 *
 * Expected starting states: In Game
 *
 * @param {object} options - Options dictionary
 */
vg.inGame_lay6Traps = function inGame_lay6Traps(options) {
    vg.tap({x:33.00, y:729.00});
    vg.inGame_attack(options);
    vg.tap({x:94.00, y:730.50});
    vg.inGame_attack(options);
    vg.tap({x:161.50, y:736.00});
    vg.inGame_attack(options);
    vg.tap({x:224.50, y:726.00});
    vg.inGame_attack(options);
    vg.tap({x:280.00, y:736.00});
    vg.inGame_attack(options);
    vg.tap({x:337.00, y:733.00});
    vg.inGame_attack(options);
}

/**
 * In game behavior: Attempt to lay X num of scout traps
 *
 * Expected starting states: In Game
 *
 * @param {number} num - Number of scout traps to try and lay
 */
vg.inGame_layTrap = function(num) {
    var t = num%6;
    if (t == 0) {
        vg.tap({x:33.00, y:729.00});
    } else if (t == 1) {
        vg.tap({x:94.00, y:730.50});
    } else if (t == 2) {
        vg.tap({x:161.50, y:736.00});
    } else if (t == 3) {
        vg.tap({x:224.50, y:726.00});
    } else if (t == 4) {
        vg.tap({x:280.00, y:736.00});
    } else if (t == 5) {
        vg.tap({x:337.00, y:733.00});
    }
}

/**
 * In game behavior: Play the game!
 *
 * Expected starting states: In Game
 *
 * @param {object} args - Argument dictionary
 */
vg.playGame = function(args) {
    args = UIAUtilities.defaults(args, {
        leftTeam: true,
    });

    UIALogger.logMessage("Starting!");
    var n = 0;
    var i = 0;
    var m = 30;
    var r = 10;
    var shoppingList = ["Sorrowblade","Shatterglass","Clockwork","Contraption","Crucible","Crucible"];
    while (n < 5) {
        UIALogger.logMessage("|\\+,_ "+n+" ~-+<=>+-~ "+i+" _,+/|");
        if (i === 0) {
            // SHOP //
            //vg.buyALottaScoutTraps();
            vg.inGame_juiceUp();
            vg.inGame_attack(args);
            vg.tap(UIAQuery.VainGlory.IN_GAME.TELEPORT);
            this.delay(6);
            vg.inGame_letsGoShopping(shoppingList);
        } else if (i<r) {
            vg.inGame_rush(args);
            vg.inGame_rush(args);
        } else if (i > m) {
            //retreat();// never surrender!
            vg.buyALottaScoutTraps();
            i=1;
            m+=5;
            r+=2;
            n+=1;
        } else {
            vg.inGame_attack(args);
            vg.inGame_ability(args);
            vg.inGame_attack(args);
            if (i%5===0) {vg.inGame_lay6Traps(args);}
            if (i%6===0) {vg.inGame_upgradeAbilities();}
            vg.inGame_attack(args);
        }
        this.delay(Math.random());
        i+=1;
    }
    vg.inGame_retreat(args);
    this.delay(5);
}
