load('Camera.js');
load('UIAApp.js');
load('Photos.js');
load('UIAApp+Camera.js');


/**
 @namespace
 @augments UIAApp
 */
var edumodecamera = target.appWithBundleID('com.apple.camera');

/**
* Takes a picture with the given parameters
*
* @param {object} options - Test arguments
* @param {boolean} [options.clearCameraRoll=false] - Should we clear the existing camera roll first?
* @param {int} [options.pictureCount=1] - The number of pictures to take
* @param {int} [options.delay=0] - The time in seconds to delay between each photo
* @param {string} [options.flashMode="Off"] - Which flash mode to use: "On", "Off", or "Automatic"
* @param {string} [options.hdrMode="Off"] - Which HDR mode to use: "On", "Off", or "Auto"
* @param {boolean} [options.irisOn=false] - Should we make an Iris asset?
* @param {string} [options.cameraFilter=null] - Use a specific filter. String should equal the filter's name.
* @param {boolean} [options.burstMode=false] - Are we takng a burst photo?"
* @param {int} [options.burstDuration=10] - The time duration in seconds for taking a burst photo"
*/
edumodecamera.takePicture = function takePicture(options) {
    this.launch();
    this.setCameraMode(options.captureMode);
    this.setCameraFacingMode(options.cameraFacingMode);
    UIALogger.logMessage("Picture count is:" + options.pictureCount);
    target.delay(5);
    for (var i = 0; i < options.pictureCount; i++) {
        UIALogger.logMessage('Tapping on PhotoCapture button');
        this.tap('PhotoCapture');
        target.delay(options.delay);
    }
}


/**
*  Captures a video.
*
* @param {object} options Test arguments
* @param {int}    [options.length=5] - The length of the video in seconds
* @param {string} [options.flashMode=null] - Which flash mode to use: "On", "Off", or "Automatic"
* @param {string} [options.captureMode="video"] - Which video mode to use: "video" or "slo-mo"
* @param {string} [options.cameraFacingMode=null] - Choose front or rear facing camera: "Front" or "Back"
*/
edumodecamera.captureVideo = function captureVideo(options) {
    this.launch();
    this.setCameraMode(options.captureMode);
    UIALogger.logDebug("Capturing video for " + options.length + " seconds.");
    this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);
    this.delay(options.length);
    this.tap(UIAQuery.Camera.VIDEO_CAPTURE_BUTTON);
}

/**
 * Navigate to photos to get number of photos
 */
edumodecamera.getPhotoCount = function getPhotoCount() {
    return this.getThumbnailCount(camera.MEDIA_TYPE.Photo);
}

/**
 * Navigate to photos to get number of videos
 */
edumodecamera.getVideoCount = function getVideoCount() {
    this.switchoverToAllPhotos();
    var originalThumbsNumber = photos.numberOfThumbnails();
    return originalThumbsNumber;
}

/**
 * Navigate to photos to get number of thumbnails
 */
edumodecamera.getThumbnailCount = function getThumbnailCount(thumbnailType) {
    this.switchoverToAllPhotos();
    var thumbnailCount = 0;
    if (thumbnailType == camera.MEDIA_TYPE.Photo) {
        UIALogger.logMessage("Inside Photo");
        thumbnailCount = photos.count(photos.photoThumbnails());
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Iris) {
        UIALogger.logMessage("Inside Iris");
        thumbnailCount = photos.count(photos.irisThumbnails());
    }
    else if (thumbnailType == camera.MEDIA_TYPE.Video) {
        UIALogger.logMessage("Inside Video");
        thumbnailCount = photos.count(photos.videoThumbnails());
    }
    else {
        thumbnailCount = photos.numberOfThumbnails();
    }
    UIALogger.logMessage("Thumbnail count for type '%0': %1".format(thumbnailType, thumbnailCount));
    return thumbnailCount;
}

/**
 * Delete Photo/Photos
 */
edumodecamera.deletePhotos = function deletePhotos() {
    this.switchoverToAllPhotos();
    photos.tap(photos.photoThumbnails().last());
    
    if (!photos.exists(UIAQuery.PHOTO_BROWSER_TITLE.isVisible())) {
        throw new UIAError("We should be on the video detail view but we aren't.");
    }
    
    photos.deleteAndConfirm();
}

/**
 * Delete Video/Videos
 */
edumodecamera.deleteVideos = function deleteVideos() {
    this.switchoverToAllPhotos();
    photos.tap(photos.videoThumbnails().last());
    
    if (!photos.exists(UIAQuery.PHOTO_BROWSER_TITLE.isVisible())) {
        throw new UIAError("We should be on the video detail view but we aren't.");
    }
    
    photos.deleteAndConfirm();
}
