
load("UIATesting.js");
load("SpringBoard.js");
load("Camera.js");
load("Photos.js");
load("Settings.js");
load("EduModeCamera.js");

if (typeof EduModeCameraTests !== 'undefined') {
    throw new UIAError("Namespace 'EduModeCameraTests' has already been defined.");
}

/**
 * @namespace
 */
var EduModeCameraTests = {

    /**
     * Takes a picture
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     * @param {int} [args.pictureCount=1] - The number of pictures to take
     * @param {int} [args.delay=5] - The time in seconds to delay between each photo
     * @param {string} [args.captureMode="photo"] - Which capture mode to use {'photo', 'square', 'pano'}
     * @param {string} [args.cameraFacingMode="Back facing"] - Choose front or rear facing camera: "Front facing" or "Back facing"
     */
    takePicture: function takePicture(args) {
        args = UIAUtilities.defaults(args, {
            pictureCount: 5,
            delay: 5,
            captureMode: 'photo',
            cameraFacingMode : 'Back facing',
        });
        edumodecamera.takePicture(args);
    },

    /**
     * Captures a video.
     *
     * @targetApps Camera, MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {int}    [args.length=5] - The length of the video in seconds
     * @param {string} [args.captureMode="video"] - Which video mode to use: "video", "slo-mo", or "time-lapse"
     * @param {string} [args.cameraFacingMode=null] - Choose front or rear facing camera: "Front" or "Back"
     */
    captureVideo: function captureVideo(args) {
        args = UIAUtilities.defaults(args, {
            length: 5,
            captureMode: "video",
            cameraFacingMode: null,
        });

        edumodecamera.captureVideo(args);
    },
    
    /**
     * Get Photo Count
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     */
    getPhotoCount: function getPhotoCount(args) {
        edumodecamera.getPhotoCount();
    },
        
    /**
     * Get Video Count
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     */
    getVideoCount: function getVideoCount(args) {
        edumodecamera.getVideoCount();
    },
    /**
     * Delete Photos
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     * @param {int}    [args.Number=1] - Number of photos to be deleted
     */
    deletePhotos: function deletePhotos(args) {
        args = UIAUtilities.defaults(args, {
                 Number: 1,
            });
        UIALogger.logMessage("Deleting "+ args.Number + " photo/photos");
        for(var i=0; i<args.Number; i++) {
            edumodecamera.deletePhotos();
        }
    },
    
    /**
     * Delete Videos
     *
     * @targetApps Camera
     *
     * @param {object} args Test arguments
     * @param {int}    [args.Number=1] - Number of photos to be deleted
     */
deleteVideos: function deleteVideos(args) {
    args = UIAUtilities.defaults(args, {
            Number: 1,
        });
    UIALogger.logMessage("Deleting "+ args.Number + "video/videos");
    for(var i=0; i<args.Number; i++) {
        edumodecamera.deleteVideos();
    }
},
    
};
