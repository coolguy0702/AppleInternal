load("UIATesting.js");
load("SpringBoard.js");
load("EduKeynote.js");

if (typeof EduKeynoteTests !== 'undefined') {
    throw new UIAError("Namespace 'EduKeynoteTests' has already been defined.");
}

var EduKeynoteTests = {
    /**
     * Creates a Keynote document and add a captured photo.
     *
     * @targetApps MobileKeynote
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.DocumentTheme="Gradient"] - Document Theme type from Keynote
     * @param {string} [args.DocumentSize="Standard"] - Document template to start with
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
     * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
     * @param {integer} [args.VideoDuration=30] - Duration of each video to be captured
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    createDocumentByCapturingMedia: function createDocumentByCapturingMedia(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            DocumentTheme: 'Gradient',
            DocumentSize: 'Standard',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               },
            ],
            userPassword: '1234',
            PhotoCount: 1,
            VideoCount: 1,
            VideoDuration: 5,
            iCloudSyncTimeout: 30,
        });
        eduKeynote.createDocumentByCapturingMedia(args);
    },

    /**
     * Creates a Keynote document with text data and adds photos/videos from the library
     *
     * @targetApps MobileKeynote
     *
     * @param {object} args - Test arguments
     * @param {integer} [args.AlbumData.All Photos=1] - Number of photos to be included from the album
     * @param {integer} [args.AlbumData.Videos=1] - Number of photos to be included from the video
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.DocumentTheme="Gradient"] - Document Theme type from Keynote
     * @param {string} [args.DocumentSize="Standard"] - Document template to start with
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SAMPLE TEXT","Overwrite":false}]]     - Contents to add to document
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    createDocumentWithRandomMediaFromLibrary: function createDocumentWithRandomMediaFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            AlbumData: {
                'All Photos': 1,
                'Videos': 1,
            },
            DocumentName: 'SyncBubbleTest',
            DocumentTheme: 'Gradient',
            DocumentSize: 'Standard',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               },
            ],
            userPassword: "1234",
            iCloudSyncTimeout: 30,
        });
        eduKeynote.createDocumentWithRandomMediaFromLibrary(args);
    },

    /**
     * Edits a Keynote document and add a captured photo.
     *
     * @targetApps MobileKeynote
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.DocumentTheme="Gradient"] - Document Theme type from Keynote
     * @param {string} [args.DocumentSize="Standard"] - Document template to start with
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
     * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
     * @param {integer} [args.VideoDuration=30] - Duration of each video to be captured
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    editDocumentByCapturingMedia: function editDocumentByCapturingMedia(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            DocumentTheme: 'Gradient',
            DocumentSize: 'Standard',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               },
            ],
            userPassword: '1234',
            PhotoCount: 1,
            VideoCount: 1,
            VideoDuration: 5,
            iCloudSyncTimeout: 30,
        });
        eduKeynote.editDocumentByCapturingMedia(args);
    },

    /**
     * Edits a Keynote document with text data and adds photos/videos from the library
     *
     * @targetApps MobileKeynote
     *
     * @param {object} args - Test arguments
     * @param {integer} [args.AlbumData.All Photos=1] - Number of photos to be included from the album
     * @param {integer} [args.AlbumData.Videos=1] - Number of photos to be included from the video
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.DocumentTheme="Gradient"] - Document Theme type from Keynote
     * @param {string} [args.DocumentSize="Standard"] - Document template to start with
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SAMPLE TEXT","Overwrite":false}]]     - Contents to add to document
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    editDocumentWithRandomMediaFromLibrary: function editDocumentWithRandomMediaFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            AlbumData: {
                'All Photos': 1,
                'Videos': 1,
            },
            DocumentName: 'SyncBubbleTest',
            DocumentTheme: 'Gradient',
            DocumentSize: 'Standard',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               },
            ],
            userPassword: "1234",
            iCloudSyncTimeout: 30,
        });
        eduKeynote.editDocumentWithRandomMediaFromLibrary(args);
    },

    /**
     * Verifies the Keynote document text content.
     *
     * @targetApps MobileKeynote
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.ExpectedText="SyncBubbleTest"] - Document text to be verified against
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     * @param {integer} [args.retryCount=3] - Retry verification as iCloud sync needs to complete
     */
    verifyDocument: function verifyDocument(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            ExpectedText: 'SyncBubbleTest',
            userPassword: "1234",
            iCloudSyncTimeout: 30,
            retryCount: 3,
        });
        while(args.retryCount > 0) {
            try{
                eduKeynote.verifyDocument(args);
                return;
            } catch (e) {
                // if document not found then it might be because if iCloud sync. Hence retry
                if (e.message.contains("Did not find a document")) {
                    args.retryCount -= 1;
                } else {
                    throw e;
                }
            }
        }
    },

    /**
     * Deletes document from the Keynote app
     *
     * @targetApps MobileKeynote
     * @param {object} args - Test arguments
     * @param {string[]} [args.DocumentNames=["SyncBubbleTest"]] - (Required) Name of document
     * @param {integer} [args.iCloudSyncTimeout=15] - Wait for iCloud sync to finish
     */
    deleteDocumentsIfPresent: function deleteDocumentsIfPresent(args) {
        args = UIAUtilities.defaults(args, {
            DocumentNames: ["SyncBubbleTest"],
            iCloudSyncTimeout: 15,
        });
        eduKeynote.deleteDocumentsIfPresent(args);
    }
}