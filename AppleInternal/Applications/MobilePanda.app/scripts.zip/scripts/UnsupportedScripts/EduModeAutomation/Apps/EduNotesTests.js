load("UIATesting.js");
load("SpringBoard.js");
load("EduNotes.js");

if (typeof EduNotesTests !== 'undefined') {
    throw new UIAError("Namespace 'EduNotesTests' has already been defined.");
}

/**
 * @namespace EduNotesTests
 */
var EduNotesTests = {
    
    /**
     * Create a note with simple text.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.title="SyncBubbleTest"] - Title of the Note
     * @param {string} [args.body=""] - Note text body
     * @param {boolean} [args.leaveOpenForEditing=true] - Leave the note open/closed for further editing
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     */
    createNote: function createNote(args) {
        args = UIAUtilities.defaults(args, {
            title: "SyncBubbleTest",
            body: "",
            leaveOpenForEditing: true,
            userPassword: "1234",
            PhotoCount: 0,
            VideoCount: 0,
            VideoDuration: 0
        });
        eduNotes.createNoteByCapturingMedia(args);
    },

    /**
     * Create a note and add a captured image.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.title="SyncBubbleTest"] - Title of the Note
     * @param {string} [args.body=""] - Note text body
     * @param {boolean} [args.leaveOpenForEditing=true] - Leave the note open/closed for further editing
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
     * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
     * @param {integer} [args.VideoDuration=5] - Duration of each video to be captured
     */
    createNoteByCapturingMedia: function createNoteByCapturingMedia(args) {
        args = UIAUtilities.defaults(args, {
            title: "SyncBubbleTest",
            body: "",
            leaveOpenForEditing: true,
            userPassword: "1234",
            PhotoCount: 1,
            VideoCount: 1,
            VideoDuration: 5
        });
        eduNotes.createNoteByCapturingMedia(args);
    },

    /**
     * Method creates a note with text data and adds photos/videos from the library
     *
     * @param {object} args - Test arguments
     * @param {string} [args.title="SyncBubbleTest"] - Title of the Note
     * @param {string} [args.body=""] - Note text body
     * @param {boolean} [args.leaveOpenForEditing=true] - Leave the note open/closed for further editing
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {integer} [args.AlbumData.All Photos=1] - Number of photos to be included from the album
     * @param {integer} [args.AlbumData.Videos=1] - Number of videos to be included from the album
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    createNoteWithRandomMediaFromLibrary: function createNoteWithRandomMediaFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            AlbumData: {
                'All Photos': 1,
                'Videos': 1
            },
            title: "SyncBubbleTest",
            body: "",
            leaveOpenForEditing: true,
            userPassword: "1234",
            iCloudSyncTimeout: 30,
        });
        eduNotes.createNoteWithRandomMediaFromLibrary(args);
    },

    /**
     * Verify the note's text content.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.title="SyncBubbleTest"] - Title of the Note
     * @param {string} [args.body=""] - Note text body
     * @param {boolean} [args.leaveOpenForEditing=false] - Leave the note open/closed for further editing
     * @param {string} [args.folder="Notes"] - Folder to be searched for the note
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     */
    verifyNote: function verifyNote(args) {
        args = UIAUtilities.defaults(args, {
            title: "SyncBubbleTest",
            body: "",
            leaveOpenForEditing: false,
            userPassword: "1234",
            folder: "Notes",
        });
        eduNotes.verifyNote(args);
    }
}