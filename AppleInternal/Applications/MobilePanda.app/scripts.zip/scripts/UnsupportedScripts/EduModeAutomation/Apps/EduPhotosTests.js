load("UIATesting.js");
load("SpringBoard.js");
load("EduPhotos.js");

if (typeof EduPhotosTests !== 'undefined') {
    throw new UIAError("Namespace 'PhotosTests' has already been defined.");
}

/**
 * @namespace PhotosTests
 */
var EduPhotosTests = {
    /**
     * Edits a photo.
     *
     * @targetApps MobileSlideShow
     *
     * @param {object} args Test arguments
     * @param {string} [args.editTypeDetail="Chrome"] - Sub-selection of the edit type to apply.
     * @param {int} [args.count=1] - Number of pictures to edit.
     * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
     * @param {string} [args.collectionName=null] - The name of the photo collection to edit a photo in. Random if null.
     * @param {boolean} [args.requireMinimumPhotoCount=false] - require a selected album to have at least MIN_PHOTO_COUNT number of photos

     */
    editPhoto: function editPhoto(args) {
        args = UIAUtilities.defaults(args, {
            editTypeDetail: "Chrome",
            count: 1,
            viewName: "Albums",
            collectionName: null,
            requireMinimumPhotoCount: false,
        });
        eduPhotos.editRandomPhotos(args);
    }
}