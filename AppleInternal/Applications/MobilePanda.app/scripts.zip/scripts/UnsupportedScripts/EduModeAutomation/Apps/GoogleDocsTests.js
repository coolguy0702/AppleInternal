load("UIATesting.js");
load("GoogleDocs.js");

if (typeof GoogleDocsTests !== "undefined") {
    throw new UIAError("Namespace 'GoogleDocsTests' has already been defined.");
}

/**
 * @namespace GoogleDocsTests
 */
var GoogleDocsTests = {
    /**
     * Google Docs sign in
     *
     * @param {object} args - Test arguments
     * @param {string} [args.Username=""] - Username needed to sign into Google account
     * @param {string} [args.Password=""] - Password needed to sign into Google account
     */
    signIn: function signIn(args) {
        args = UIAUtilities.defaults(args, {
            Username: "",
            Password: "",
        });
        googleDocs.signIn(args);
    },

    /**
     * Create document
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="Test Document"] - Name of the new document
     * @param {string} [args.DocumentContents="This is a test document"] - Contents to write in the document
     * @param {integer} [args.PhotoCount=0] - Number of photos to be added to the document
     */
    createDocument: function createDocument(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: "Test Document",
            DocumentContents: "This is a test document",
            PhotoCount: 0,
        });
        googleDocs.createDocument(args);
    },

    /**
     * Edit document
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="Test Document"] - Name of the existing document
     * @param {string} [args.DocumentContents="This is a test document"] - Contents to write in the document
     * @param {integer} [args.PhotoCount=0] - Number of photos to be added to the document
     */
    editDocument: function editDocument(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: "Test Document",
            DocumentContents: "This is a test document",
            PhotoCount: 0,
        });
        googleDocs.editDocument(args);
    },

    /**
     * Rename document 
     *
     * @param {object} args - Test arguments
     * @param {string} [args.OldDocumentName="Test Document"] - Name of the existing document
     * @param {string} [args.NewDocumentName="New Test Document"] - Rename document to this name
     */
    renameDocument: function renameDocument(args) {
        args = UIAUtilities.defaults(args, {
            OldDocumentName: "Test Document",
            NewDocumentName: "New Test Document", 
        });
        googleDocs.renameDocument(args);
    },

    /**
     * Remove document
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="Test Document"] - Name of the document to be removed
     */
    removeDocument: function removeDocument(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: "Test Document",
        });
        googleDocs.removeDocument(args);
    },
}