load("UIATesting.js");
load("SpringBoard.js");
load("EduPages.js");

if (typeof EduPagesTests !== 'undefined') {
    throw new UIAError("Namespace 'EduPagesTests' has already been defined.");
}

/**
 * @namespace PagesTests
 */
var EduPagesTests = {
    /**
     * Creates a Pages document and add a captured photo.
     *
     * @targetApps MobilePages
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.TemplateType="Blank"] - Document Template type from Pages
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
     * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
     * @param {integer} [args.VideoDuration=5] - Duration of each video to be captured
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    createDocumentByCapturingMedia: function createDocumentByCapturingMedia(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            TemplateType: 'Blank',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               }
            ],
            userPassword: '1234',
            PhotoCount: 1,
            VideoCount: 1,
            VideoDuration: 5,
            iCloudSyncTimeout: 30,
        });
        eduPages.createDocumentByCapturingMedia(args);
    },

    /**
     * Creates a pages document with text data and adds photos/videos from the library
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.TemplateType="Blank"] - Document Template type from Pages
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.AlbumData.All Photos=1] - Number of photos to be included from the album
     * @param {integer} [args.AlbumData.Videos=1] - Number of photos to be included from the video
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    createDocumentWithRandomMediaFromLibrary: function createDocumentWithRandomMediaFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            AlbumData: {
                'All Photos': 1,
                'Videos': 1,
            },
            DocumentName: 'SyncBubbleTest',
            TemplateType: 'Blank',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               }
           ],
            userPassword: "1234",
            iCloudSyncTimeout: 30,
        });
        eduPages.createDocumentWithRandomMediaFromLibrary(args);
    },

    /**
     * Edits a Pages document and add a captured photo.
     *
     * @targetApps MobilePages
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.TemplateType="Blank"] - Document Template type from Pages
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
     * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
     * @param {integer} [args.VideoDuration=5] - Duration of each video to be captured
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    editDocumentByCapturingMedia: function editDocumentByCapturingMedia(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            TemplateType: 'Blank',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               }
            ],
            userPassword: '1234',
            PhotoCount: 1,
            VideoCount: 1,
            VideoDuration: 5,
            iCloudSyncTimeout: 30,
        });
        eduPages.editDocumentByCapturingMedia(args);
    },

    /**
     * Edits a pages document with text data and adds photos/videos from the library
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.TemplateType="Blank"] - Document Template type from Pages
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {DocumentContent[]}   [args.DocumentContents=[{"DocumentSection":"Body","Contents":"SyncBubbleTest","Overwrite":true}]]     - Contents to add to document
     * @param {integer} [args.AlbumData.All Photos=1] - Number of photos to be included from the album
     * @param {integer} [args.AlbumData.Videos=1] - Number of photos to be included from the video
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    editDocumentWithRandomMediaFromLibrary: function editDocumentWithRandomMediaFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            AlbumData: {
                'All Photos': 1,
                'Videos': 1,
            },
            DocumentName: 'SyncBubbleTest',
            TemplateType: 'Blank',
            DocumentContents: [
               {
                   DocumentSection: 'Body',
                   Contents: 'SyncBubbleTest',
                   Overwrite: true,
               }
           ],
            userPassword: "1234",
            iCloudSyncTimeout: 30,
        });
        eduPages.editDocumentWithRandomMediaFromLibrary(args);
    },

    /**
     * Verifies the pages document text content.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.DocumentName="SyncBubbleTest"] - Name of the new document
     * @param {string} [args.ExpectedText="SyncBubbleTest"] - Document text to be verified against
     * @param {string} [args.userPassword="1234"] - User password nedded for handling auth alert
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     * @param {integer} [args.retryCount=3] - Retry verification as iCloud sync needs to complete
     */
    verifyDocument: function verifyDocument(args) {
        args = UIAUtilities.defaults(args, {
            DocumentName: 'SyncBubbleTest',
            ExpectedText: 'SyncBubbleTest',
            userPassword: "1234",
            iCloudSyncTimeout: 30,
            retryCount: 3
        });
        while(args.retryCount > 0) {
            try{
                eduPages.verifyDocument(args);
                return;
            } catch (e) {
                // if document not found then it might be because if iCloud sync. Hence retry
                if (e.message.contains("Did not find a document")) {
                    args.retryCount -= 1;
                } else {
                    throw e;
                }
            }
        }
    },

    /**
     * Deletes document from the Pages app
     *
     * @param {object} args - Test arguments
     * @param {string[]} [args.DocumentNames=["SyncBubbleTest"]] - (Required) Name of document
     * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
     */
    deleteDocumentsIfPresent: function deleteDocumentsIfPresent(args) {
        args = UIAUtilities.defaults(args, {
            DocumentNames: ["SyncBubbleTest"],
            iCloudSyncTimeout: 30,
        });
        eduPages.deleteDocumentsIfPresent(args);
    }
}