load('Numbers.js');
load('EduApp.js');

var eduNumbers = numbers;
var userPassword = "";

/**
 * UIAlert handler for handling the authentication alerts after logging into
 * Education mode.
 */
var handler = function() {
    app = target.activeApp();
    // Alert titles to be handled
    if(app.exists("Apple ID Verification")) {
        throw new UIAError("Prompted for Apple ID Verification");
    } else if(app.exists("Sign In to iCloud")) {
        throw new UIAError("Prompted for iCloud Sign In");
    } else {
        return false;
    }
    return true;
}

/**
 * If Numbers is launched for the first time then navigate throught the setup UI and
 * make Numbers use iCloud
 */
eduNumbers.setupOnFirstLaunch = function setupOnFirstLaunch() {
    target.delay(2);
    if(this.exists("Continue")) {
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Continue"));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Use Numbers"));
    }
}

/**
 * Method to add Photos from the photo library to the current Numbers document.
 *
 * @param {string} albumName - Name of the Album from the Library
 * @param {int} count - count for the number of photos to be added
 * @param {integer} [iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.addPhotosToDocument = function addPhotosToDocument(albumName, count, iCloudSyncTimeout) {
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Media"));
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.staticTexts(albumName).parent());
    for (var i = 0; i < count; i++) {
        var randomIndex = UIAUtilities.randomInt(1, this.count(UIAQuery.tableCells()) - 1);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.tableCells().atIndex(randomIndex));
        this.waitUntilAbsent(UIAQuery.withPredicate('name contains[c] "connection in progress"'), iCloudSyncTimeout);
        this.tapIfExists(UIAQuery.buttons("Use"));
        this.tapIfExists(UIAQuery.staticTexts("Choose Video"));
    };
    if (this.exists(UIAQuery.buttons("Albums"))) {
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
    }
}

/**
 * Method to add Videos from the photo library to the current Numbers document.
 *
 * @param {int} count - count for the number of photos to be added
 * @param {integer} [iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.addVideosToDocument = function addVideosToDocument(count, iCloudSyncTimeout) {
    albumName = "Videos";
    for (var i = 0; i < count; i++) {
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Media"));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.staticTexts(albumName).parent());
        var randomIndex = UIAUtilities.randomInt(1, this.count(UIAQuery.tableCells()) - 1);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.tableCells().atIndex(randomIndex));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Use"));
        this.waitUntilAbsent(UIAQuery.staticTexts("Choose Video"));
        this.waitUntilAbsent(UIAQuery.withPredicate('name contains[c] "connection in progress"'), iCloudSyncTimeout);
    };
}

/**
 * Method creates a Numbers document with text data and adds a photo by capturing
 * one using the Camera. 
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document template type from Numbers
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {object} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be overwritten
 * @param {integer} [DocumentContents.Sheet] - Sheet number in the document
 * @param {integer} [DocumentContents.Row] - Row number in the sheet of document
 * @param {boolean} [DocumentContents.Column] - Column number in the sheet of document
 * @param {integer} [DocumentContents.PhotoCount] - Number of photos to be added to the document
 * @param {integer} [DocumentContents.VideoCount] - Number of videos to be added to the document
 * @param {integer} [DocumentContents.VideoDuration] - Duration of each video to be captured
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.createDocumentByCapturingMedia = function createDocumentByCapturingMedia(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                Sheet: 1,
                Row: 1,
                Column: 1,
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        PhotoCount: 1,
        VideoCount: 1,
        VideoDuration: 5,
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.deleteDocumentsIfPresent({'DocumentNames': [options.DocumentName], 'iCloudSyncTimeout': options.iCloudSyncTimeout});
        this.tapIfExists(UIAQuery.beginsWith("Create a Spreadsheet"));
        this.createDocument(options.DocumentName, options);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
        EduApp.prototype.addMediaToDocument(this, options.PhotoCount, options.VideoCount, options.VideoDuration);
        this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
        this.target.clickMenu();
    });
}

/**
 * Method creates a Numbers document with text data and adds photos/videos from the library
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document template type from Numbers
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {object} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be overwritten
 * @param {integer} [DocumentContents.Sheet] - Sheet number in the document
 * @param {integer} [DocumentContents.Row] - Row number in the sheet of document
 * @param {boolean} [DocumentContents.Column] - Column number in the sheet of document
 * @param {object} AlbumData - Dictionary of Album names and corresponding integer count for the photos
 * @param {int} [AlbumData.<Album Name>] - Map the album name with the number of photos from that album you want to add to the document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.createDocumentWithRandomMediaFromLibrary = function createDocumentWithRandomMediaFromLibrary(options) {
    options = UIAUtilities.defaults(options, {
        AlbumData: {
            'All Photos': 1,
            'Videos': 1
        },
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                Sheet: 1,
                Row: 1,
                Column: 1,
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.deleteDocumentsIfPresent({'DocumentNames': [options.DocumentName], 'iCloudSyncTimeout': options.iCloudSyncTimeout});
        this.tapIfExists(UIAQuery.beginsWith("Tap to create"));
        this.createDocument(options.DocumentName, options);
        for (albumName in options.AlbumData) {
            EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
            if (albumName === "Videos") {
                this.addVideosToDocument(options.AlbumData[albumName], options.iCloudSyncTimeout);
            } else {
                this.addPhotosToDocument(albumName, options.AlbumData[albumName], options.iCloudSyncTimeout);
            }
            this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
        }
        this.target.clickMenu();
    });
}

/**
 * Method edits a Numbers document with text data and adds a photo by capturing
 * one using the Camera. 
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document template type from Numbers
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {object} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be overwritten
 * @param {integer} [DocumentContents.Sheet] - Sheet number in the document
 * @param {integer} [DocumentContents.Row] - Row number in the sheet of document
 * @param {boolean} [DocumentContents.Column] - Column number in the sheet of document
 * @param {integer} [DocumentContents.PhotoCount] - Number of photos to be added to the document
 * @param {integer} [DocumentContents.VideoCount] - Number of videos to be added to the document
 * @param {integer} [DocumentContents.VideoDuration] - Duration of each video to be captured
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.editDocumentByCapturingMedia = function editDocumentByCapturingMedia(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                Sheet: 1,
                Row: 1,
                Column: 1,
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        PhotoCount: 1,
        VideoCount: 1,
        VideoDuration: 5,
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.editDocument(options.DocumentName, options);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
        EduApp.prototype.addMediaToDocument(this, options.PhotoCount, options.VideoCount, options.VideoDuration);
        this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
        this.target.clickMenu();
    });
}

/**
 * Method edits a Numbers document with text data and adds photos/videos from the library
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document template type from Numbers
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {object} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be overwritten
 * @param {integer} [DocumentContents.Sheet] - Sheet number in the document
 * @param {integer} [DocumentContents.Row] - Row number in the sheet of document
 * @param {boolean} [DocumentContents.Column] - Column number in the sheet of document
 * @param {object} AlbumData - Dictionary of Album names and corresponding integer count for the photos
 * @param {int} [AlbumData.<Album Name>] - Map the album name with the number of photos from that album you want to add to the document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.editDocumentWithRandomMediaFromLibrary = function editDocumentWithRandomMediaFromLibrary(options) {
    options = UIAUtilities.defaults(options, {
        AlbumData: {
            'All Photos': 1,
            'Videos': 1
        },
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                Sheet: 1,
                Row: 1,
                Column: 1,
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.editDocument(options.DocumentName, options);
        for (albumName in options.AlbumData) {
            EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
            if (albumName === "Videos") {
                this.addVideosToDocument(options.AlbumData[albumName], options.iCloudSyncTimeout);
            } else {
                this.addPhotosToDocument(albumName, options.AlbumData[albumName], options.iCloudSyncTimeout);
            }
            this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
        }
        this.target.clickMenu();
    });
}


/**
 * Method verifies the Numbers document text content.
 * Future work - add image verifier
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.ExpectedText] - Document text to be verified against
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {integer} [options.Sheet] - Sheet number in the document
 * @param {integer} [options.Row] - Row number in the sheet of document
 * @param {boolean} [options.Column] - Column number in the sheet of document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.verifyDocument = function verifyDocument(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        ExpectedText: 'SyncBubbleTest',
        Sheet: 1,
        Row: 1,
        Column: 1,
        userPassword: "1234",
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    var sheetQuery = UIAQuery.contains("Sheet %0".format(options.Sheet));
    var cellQuery = UIAQuery.contains("Row %0, Column: %1".format(options.Row, options.Column));
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for documents"), options.iCloudSyncTimeout);
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Updating"), (options.iCloudSyncTimeout * 2));
        documentQuery = this._findDocument(options.DocumentName);
        EduApp.prototype.checkUIBeforeTapping(this, documentQuery, options.iCloudSyncTimeout);
        this.waitUntilPresent(UIAQuery.textViews(cellQuery), options.iCloudSyncTimeout);
        this.tap(sheetQuery);
        this.delay(2);
        var textContents = this.inspect(cellQuery).value
        if (!textContents.contains(options.ExpectedText)){
            throw new UIAError("Numbers document does not contain the expected body");
        }
        UIALogger.logDebug("Numbers document verified");
        this.target.clickMenu();
    });
}

/**
 * Deletes document from the Numbers app
 *
 * @param {object} args - Test arguments
 * @param {string[]} [args.DocumentNames=[""]] - (Required) Name of document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduNumbers.deleteDocumentsIfPresent = function deleteDocumentsIfPresent(options) {
    options = UIAUtilities.defaults(options, {
        DocumentNames: ["SyncBubbleTest"],
        iCloudSyncTimeout: 15
    });
    this.withAlertHandler(handler, function() {
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for spreadsheets"), options.iCloudSyncTimeout);
        try {
            this.deleteDocuments(options.DocumentNames);
        } catch (e) {
            UIALogger.logDebug("Document not found")
        }
    });    
}
