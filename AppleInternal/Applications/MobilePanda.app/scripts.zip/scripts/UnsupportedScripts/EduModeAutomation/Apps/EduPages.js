load('Pages.js');
load('EduApp.js');
load('Settings.js')

var eduPages = pages;
var userPassword = "";

/**
 * UIAlert handler for handling the authentication alerts after logging into
 * Education mode.
 */
var handler = function() {
    app = target.activeApp();
    // Alert titles to be handled
    if(app.exists("Apple ID Verification")) {
        throw new UIAError("Prompted for Apple ID Verification");
    } else if(app.exists("Sign In to iCloud")) {
        throw new UIAError("Prompted for iCloud Sign In");
    } else {
        return false;
    }
    return true;
}

/**
 * If pages is launched for the first time then navigate throught the setup UI and
 * make Pages use iCloud
 */
eduPages.setupOnFirstLaunch = function setupOnFirstLaunch() {
    // It has been observed that sometimes it takes time for the UI element to
    // be accessible hence the delay 
    target.delay(2); 
    if(this.exists("Continue")) {
        EduApp.prototype.checkUIBeforeTapping(this, "Continue");
        EduApp.prototype.checkUIBeforeTapping(this, "Use Pages");
    }
}

/**
 * Method to add Photos from the photo library to the current Pages document.
 *
 * @param {string} albumName - Name of the Album from the Library
 * @param {int} count - count for the number of photos to be added
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.addPhotosToDocument = function addPhotosToDocument(albumName, count, iCloudSyncTimeout) {
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Media"));
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.staticTexts(albumName).parent());
    for (var i = 0; i < count; i++) {
        var randomIndex = UIAUtilities.randomInt(1, this.count(UIAQuery.tableCells()) - 1);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.tableCells().atIndex(randomIndex));
        this.waitUntilAbsent(UIAQuery.withPredicate('name contains[c] "connection in progress"'), iCloudSyncTimeout);
        this.tapIfExists(UIAQuery.buttons("Use"));
        this.tapIfExists(UIAQuery.staticTexts("Choose Video"));
    };
    if (this.exists(UIAQuery.buttons("Albums"))) {
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
    }
}

/**
 * Method to add Videos from the photo library to the current Pages document.
 *
 * @param {int} count - count for the number of photos to be added
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.addVideosToDocument = function addVideosToDocument(count, iCloudSyncTimeout) {
    albumName = "Videos";
    for (var i = 0; i < count; i++) {
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Insert"));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Media"));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.staticTexts(albumName).parent());
        var randomIndex = UIAUtilities.randomInt(1, this.count(UIAQuery.tableCells()) - 1);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.tableCells().atIndex(randomIndex));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Use"));
        this.waitUntilAbsent(UIAQuery.staticTexts("Choose Video"))
        this.waitUntilAbsent(UIAQuery.withPredicate('name contains[c] "connection in progress"'), iCloudSyncTimeout);
    };
}

/**
 * Method creates a pages document with text data and adds a photo by capturing
 * one using the Camera. 
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document Template type from Pages
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {string} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.DocumentSection] - Section of pages document to be edited
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be qverwritten
 * @param {integer} [DocumentContents.PhotoCount] - Number of photos to be added to the document
 * @param {integer} [DocumentContents.VideoCount] - Number of videos to be added to the document
 * @param {integer} [DocumentContents.VideoDuration] - Duration of each video to be captured
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.createDocumentByCapturingMedia = function createDocumentByCapturingMedia(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                DocumentSection: 'Body',
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        PhotoCount: 1,
        VideoCount: 1,
        VideoDuration: 5,
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.deleteDocumentsIfPresent({'DocumentNames': [options.DocumentName], 'iCloudSyncTimeout': options.iCloudSyncTimeout});
        this.tapIfExists(UIAQuery.beginsWith("Tap to create"));
        this.createDocument(options.DocumentName, options);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
        EduApp.prototype.addMediaToDocument(this, options.PhotoCount, options.VideoCount, options.VideoDuration);
        this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
        this.target.clickMenu();
    });
}

/**
 * Method creates a pages document with text data and adds photos/videos from the library
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document Template type from Pages
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {string} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.DocumentSection] - Section of pages document to be edited
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be qverwritten
 * @param {object} AlbumData - Dictionary of Album names and corresponding integer count for the photos
 * @param {int} [AlbumData.<Album Name>] - Map the album name with the number of photos from that album you want to add to the document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.createDocumentWithRandomMediaFromLibrary = function createDocumentWithRandomMediaFromLibrary(options) {
    options = UIAUtilities.defaults(options, {
        AlbumData: {
            'All Photos': 1,
            'Videos': 1
        },
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                DocumentSection: 'Body',
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: "1234",
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.deleteDocumentsIfPresent({'DocumentNames': [options.DocumentName], 'iCloudSyncTimeout': options.iCloudSyncTimeout});
        this.tapIfExists(UIAQuery.beginsWith("Tap to create"));
        this.createDocument(options.DocumentName, options);
        for (albumName in options.AlbumData) {
            EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
            if (albumName === "Videos") {
                this.addVideosToDocument(options.AlbumData[albumName], options.iCloudSyncTimeout);
            } else {
                this.addPhotosToDocument(albumName, options.AlbumData[albumName], options.iCloudSyncTimeout);
            }
            this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
        }
        this.target.clickMenu();
    });
}

/**
 * Method edits a pages document with text data and adds a photo by capturing
 * one using the Camera. 
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document Template type from Pages
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {string} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.DocumentSection] - Section of pages document to be edited
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be qverwritten
 * @param {integer} [DocumentContents.PhotoCount] - Number of photos to be added to the document
 * @param {integer} [DocumentContents.VideoCount] - Number of videos to be added to the document
 * @param {integer} [DocumentContents.VideoDuration] - Duration of each video to be captured
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.editDocumentByCapturingMedia = function editDocumentByCapturingMedia(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                DocumentSection: 'Body',
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: '1234',
        PhotoCount: 1,
        VideoCount: 1,
        VideoDuration: 5,
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.editDocument(options.DocumentName, options);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
        EduApp.prototype.addMediaToDocument(this, options.PhotoCount, options.VideoCount, options.VideoDuration);
        this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
        this.target.clickMenu();
    });
}

/**
 * Method edits a pages document with text data and adds photos/videos from the library
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.TemplateType] - Document Template type from Pages
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {string} [options.DocumentContents] - Document Contents arguments
 * @param {string} [DocumentContents.DocumentSection] - Section of pages document to be edited
 * @param {string} [DocumentContents.Contents] - Document text contents
 * @param {boolean} [DocumentContents.Overwrite] - Boolean which specifies if Contents should be qverwritten
 * @param {object} AlbumData - Dictionary of Album names and corresponding integer count for the photos
 * @param {int} [AlbumData.<Album Name>] - Map the album name with the number of photos from that album you want to add to the document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.editDocumentWithRandomMediaFromLibrary = function editDocumentWithRandomMediaFromLibrary(options) {
    options = UIAUtilities.defaults(options, {
        AlbumData: {
            'All Photos': 1,
            'Videos': 1
        },
        DocumentName: 'SyncBubbleTest',
        TemplateType: 'Blank',
        DocumentContents: [
            {
                DocumentSection: 'Body',
                Contents: 'SyncBubbleTest',
                Overwrite: true
            }
        ],
        userPassword: "1234",
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for"), options.iCloudSyncTimeout);
        this.editDocument(options.DocumentName, options);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.contains(options.DocumentName));
        for (albumName in options.AlbumData) {
            if (albumName === "Videos") {
                this.addVideosToDocument(options.AlbumData[albumName], options.iCloudSyncTimeout);
            } else {
                this.addPhotosToDocument(albumName, options.AlbumData[albumName], options.iCloudSyncTimeout);
            }
        }
        this.navigation.goTo(UIStateDescription.Pages.DOCUMENT_MANAGER_VIEW);
        this.target.clickMenu();
    });
}

/**
 * Method verifies the pages document text content.
 * Future work - add image verifier
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.ExpectedText] - Document text to be verified against
 * @param {integer} [options.userPassword] - User password nedded for handling auth alert
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.verifyDocument = function verifyDocument(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'SyncBubbleTest',
        ExpectedText: 'SyncBubbleTest',
        userPassword: "1234",
        iCloudSyncTimeout: 30
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        // EduApp.prototype.enableiCloud(this);
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for documents"), options.iCloudSyncTimeout);
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Updating"), (options.iCloudSyncTimeout * 2));
        documentQuery = this._findDocument(options.DocumentName);
        EduApp.prototype.checkUIBeforeTapping(this, documentQuery, options.iCloudSyncTimeout);
        this.waitUntilPresent(UIAQuery.textViews('Body'), options.iCloudSyncTimeout);
        var textContents = eduPages.inspect(UIAQuery.textViews('Body')).value;
        if (!textContents.contains(options.ExpectedText)){
            throw new UIAError("Pages document does not contain the expected body");
        }
        UIALogger.logDebug("Pages document verified");
        this.deleteDocumentsIfPresent({'DocumentNames': [options.DocumentName], 'iCloudSyncTimeout': options.iCloudSyncTimeout});
        this.target.clickMenu();
    });
}

/**
 * Deletes document from the Pages app
 *
 * @param {object} options - Test arguments
 * @param {string[]} [options.DocumentNames=[""]] - (Required) Name of document
 * @param {integer} [options.iCloudSyncTimeout] - Wait for iCloud sync to finish
 */
eduPages.deleteDocumentsIfPresent = function deleteDocumentsIfPresent(options) {
    options = UIAUtilities.defaults(options, {
        DocumentNames: ["SyncBubbleTest"],
        iCloudSyncTimeout: 30
    });
    this.withAlertHandler(handler, function() {
        this.launch();
        this.setupOnFirstLaunch();
        this.waitUntilAbsent(UIAQuery.staticTexts().contains("Checking for documents"), options.iCloudSyncTimeout);
        try {
            this.deleteDocuments(options.DocumentNames);
        } catch (e) {
            UIALogger.logDebug("Document not found")
        }
    });    
}
