load("Photos.js");
load("EduApp.js");

var eduPhotos = photos;

/**
 * Selects a random photo and edits it by using Filters
 *
 * @param {string} elementName - Name of the element
 */
eduPhotos.selectRandomPhotoAndApplyFilter = function selectRandomPhotoAndApplyFilter(editTypeDetail) {
    var editType = "Filters";
    EduApp.prototype.tap(this.photoThumbnails().any());
    EduApp.prototype.checkUIBeforeTapping(UIAQuery.buttons("Edit"), "Edit");
    UIATarget.localTarget().delay(5); // necessary because on some devices we get the UI element but automation is unable to tap
    EduApp.prototype.checkUIBeforeTapping(UIAQuery.buttons(editType), editType);
    EduApp.prototype.checkUIBeforeTapping(UIAQuery.tableCells(editTypeDetail), editTypeDetail);
    EduApp.prototype.checkUIBeforeTapping(UIAQuery.buttons("Done"), "Done");
    EduApp.prototype.checkUIBeforeTapping(UIAQuery.buttons("Camera Roll"), "Camera Roll");
}

/**
 * Edits multiple random photos. This method expects all the arguments required by the standard Photos library.
 *
 * @param {object} args Test arguments
 * @param {string} [args.editTypeDetail="Chrome"] - Sub-selection of the edit type to apply.
 * @param {int} [args.count=1] - Number of pictures to edit.
 * @param {string} [args.viewName="Albums"] - Name of the view to choose a photo collection from.
 * @param {string} [args.collectionName=null] - The name of the photo collection to edit a photo in. Random if null.
 * @param {boolean} [args.requireMinimumPhotoCount=false] - require a selected album to have at least MIN_PHOTO_COUNT number of photos
 */
eduPhotos.editRandomPhotos = function editRandomPhotos(args) {
    if (!args.collectionName || args.collectionName.length < 1) {
        UIALogger.logDebug("No collection name was specified. Choosing one at random.");
        this.launch();
        args.collectionName = this.randomCollectionNameFromView(args.viewName);
    }

    this.getToCollectionInView(args.collectionName, args.viewName);
    for (var i = 0; i < args.count; i++) {
        this.selectRandomPhotoAndApplyFilter(args.editTypeDetail);
    };
}