load('Notes.js');
load('EduApp.js');

UIAQuery.EduNotesCamera = {
    NAVIGATE_TO_CAMERA_OPTION : UIAQuery.buttons("Insert"),
    NAVIGATE_TO_CAMERA : UIAQuery.buttons("Take Photo or Video"),
    NAVIGATE_TO_CAMERA_LIBRARY : UIAQuery.buttons("Photo Library"),
    PHOTO_CAPTURE_BUTTON : UIAQuery.buttons("PhotoCapture"),
    VIDEO_CAPTURE_BUTTON : UIAQuery.buttons("VideoCapture"),
    PHOTO_CAPTURE_WAITER : UIAWaiter.waiter("PhotoCapture"),
    VIDEO_CAPTURE_WAITER : UIAWaiter.waiter("VideoCapture"),
    USE_PHOTO : UIAQuery.buttons("Use Photo"),
    USE_VIDEO : UIAQuery.buttons("Use Video"),
    USE_PHOTO_VIDEO_FROM_LIBRARY : UIAQuery.buttons("Use"),
    CAMERA_MODE : UIAQuery.query("CameraMode"),
    CHOOSE_PHOTO_OR_VIDEO : UIAQuery.navigationBars("Choose Photo").orElse(UIAQuery.navigationBars("Choose Video")),
};

eduNotes = notes;
var userPassword = "";
/**
 * UIAlert handler for handling the authentication alerts after logging into
 * Education mode.
 */
var handler = function() {
    app = target.activeApp();
    // Alert titles to be handled
    if(app.exists("Apple ID Verification")) {
        throw new UIAError("Prompted for Apple ID Verification");
    } else if(app.exists("Sign In to iCloud")) {
        throw new UIAError("Prompted for iCloud Sign In");
    } else {
        return false;
    }
    return true;
}

eduNotes.navigateToCamera = function navigateToCamera() {
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.NAVIGATE_TO_CAMERA_OPTION);
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.NAVIGATE_TO_CAMERA);
}

eduNotes.addMedia = function addMedia(photoCount, videoCount, videoDuration) {
    var photoCaptureWaiter = UIAQuery.EduNotesCamera.PHOTO_CAPTURE_WAITER;
    var videoCaptureWaiter = UIAQuery.EduNotesCamera.VIDEO_CAPTURE_WAITER;

    for (var i = 0; i < photoCount; i++) {
        this.delay(2);
        this.navigateToCamera();    
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.PHOTO_CAPTURE_BUTTON);
        photoCaptureWaiter.wait();
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.USE_PHOTO);
        target.delay(2);
    }

    for (var i = 0; i < videoCount; i++) {
        this.delay(2);
        this.navigateToCamera();
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.CAMERA_MODE);
        this.dragUpInside("CameraMode")
        target.delay(5);
        if(!this.exists(UIAQuery.EduNotesCamera.VIDEO_CAPTURE_BUTTON)) {
            this.tap(UIAQuery.EduNotesCamera.CAMERA_MODE)
        }
        //start video
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.VIDEO_CAPTURE_BUTTON);
        target.delay(videoDuration);
        
        //end video
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.VIDEO_CAPTURE_BUTTON);
        videoCaptureWaiter.wait();
        
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.USE_VIDEO);
        target.delay(2);
    }
}

/**
 * Method creates a note and adds a capture image.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.title] - Title of the Note
 * @param {string} [options.body] - Note text body
 * @param {boolean} [options.leaveOpenForEditing] - Leave the note open/closed for further editing
 * @param {string} [options.userPassword] - User password nedded for handling auth alert
 * @param {integer} [args.PhotoCount=1] - Number of photos to be added to the document
 * @param {integer} [args.VideoCount=1] - Number of videos to be added to the document
 * @param {integer} [args.VideoDuration=5] - Duration of each video to be captured
 */
eduNotes.createNoteByCapturingMedia = function createNoteByCapturingMedia(options) {
    options = UIAUtilities.defaults(options, {
        title: "SyncBubbleTest",
        body: "",
        leaveOpenForEditing: true,
        userPassword: "1234",
        PhotoCount: 1,
        VideoCount: 1,
        VideoDuration: 5
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        this.createNote([options.title, options.body], options);
        this.addMedia(options.PhotoCount, options.VideoCount, options.VideoDuration)
        this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        this.target.clickMenu();
    });
}

/**
 * Method to add Media from the photo library to the current Notes.
 *
 * @param {string} albumName - Name of the Album from the Library
 * @param {int} count - count for the number of photos to be added
 */
eduNotes.addMediaToNote = function addMediaToNote(albumName, count, iCloudSyncTimeout) {
    for (var i = 0; i < count; i++) {
        this.delay(2);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.NAVIGATE_TO_CAMERA_OPTION);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.NAVIGATE_TO_CAMERA_LIBRARY);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons(albumName));
        var randomIndex = UIAUtilities.randomInt(1, this.count(UIAQuery.tableCells()) - 1);
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.tableCells().atIndex(randomIndex));
        if(this.waitUntilPresent(UIAQuery.EduNotesCamera.CHOOSE_PHOTO_OR_VIDEO, iCloudSyncTimeout)) {
            EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.EduNotesCamera.USE_PHOTO_VIDEO_FROM_LIBRARY);
        }
    }
}

/**
 * Method creates a note with text data and adds photos/videos from the library
 *
 * @param {object} options - Test arguments
 * @param {string} [options.title] - Title of the Note
 * @param {string} [options.body] - Note text body
 * @param {boolean} [options.leaveOpenForEditing] - Leave the note open/closed for further editing
 * @param {string} [options.userPassword] - User password nedded for handling auth alert
 * @param {object} AlbumData - Dictionary of Album names and corresponding integer count for the photos
 * @param {int} [AlbumData.<Album Name>] - Map the album name with the number of photos from that album you want to add to the document
 * @param {integer} [args.iCloudSyncTimeout=30] - Wait for iCloud sync to finish
 */
eduNotes.createNoteWithRandomMediaFromLibrary = function createNoteWithRandomMediaFromLibrary(options) {
    options = UIAUtilities.defaults(options, {
        AlbumData: {
            'All Photos': 1,
            'Videos': 1
        },
        title: "SyncBubbleTest",
        body: "",
        leaveOpenForEditing: true,
        userPassword: "1234",
        iCloudSyncTimeout: 30,
    });

    this.withAlertHandler(handler, function() {
        this.createNote([options.title, options.body], options);
        for (albumName in options.AlbumData) {
            this.addMediaToNote(albumName, options.AlbumData[albumName], options.iCloudSyncTimeout);
        }
        this.tapIfExists(UIAQuery.Notes.BACK_NAV_BUTTON);
        this.tapIfExists(UIAQuery.Notes.BACK_NAV_BUTTON);
        this.target.clickMenu();
    });
}


/**
 * Method verifies the note's text content.
 * Future work - add image verifier
 *
 * @param {object} options - Test arguments
 * @param {string} [options.title] - Title of the Note
 * @param {string} [options.body] - Note text body
 * @param {boolean} [options.leaveOpenForEditing] - Leave the note open/closed for further editing
 * @param {string} [options.folder] - Folder to be searched for the note
 * @param {string} [options.userPassword] - User password nedded for handling auth alert
 */
eduNotes.verifyNote = function verifyNote(options) {
    options = UIAUtilities.defaults(options, {
        title: "SyncBubbleTest",
        body: "",
        leaveOpenForEditing: false,
        userPassword: "1234",
        folder: "Notes",
    });
    userPassword = options.userPassword;
    // add alert handler
    // For more information: https://testautomation.apple.com/docs/UIAutomationScripts/UIAAlertManager.html
    this.withAlertHandler(handler, function() {
        this.getToFolder(options.folder);
        this.tap(UIAQuery.tableCells().withPredicate('name contains "%0"'.format(options.title)));
        var textData = eduNotes.getNoteTextContent();
        if(!textData.contains(options.title + options.body)) {
            throw new UIAError("Note does not contain the expected body");
        }
        UIALogger.logDebug("Note verified");
        this.target.clickMenu();
    });
}
