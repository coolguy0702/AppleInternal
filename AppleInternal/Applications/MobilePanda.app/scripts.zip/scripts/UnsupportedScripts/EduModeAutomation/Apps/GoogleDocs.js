load('UIAApp.js');
load('EduApp.js');

UIAUtilities.assert(
    typeof googleDocs === 'undefined',
    "Google Docs has already been defined"
);

var googleDocs = target.appWithBundleID("com.google.Docs");

/**
 * Method signs into a Google account.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.Username] - Username needed to sign into Google account
 * @param {string} [options.Password] - Password needed to sign into Google account
 */
googleDocs.signIn = function signIn(options) {
    options = UIAUtilities.defaults(options, {
        'Username': '',
        'Password': '',
    });
    this.launch()
    EduApp.prototype.checkUIBeforeTapping(this,"SIGN IN");
    this.enterText(UIAQuery.textFields().withPredicate("name contains[c] 'email'"), options.Username);
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons("NEXT"));
    this.enterText(UIAQuery.secureTextFields().withPredicate("name contains[c] 'password'"), options.Password);
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons("NEXT"));
}

/**
 * Method adds photos to the Google Document
 * 
 * @param {integer} photoCount - Number of photos to be added
 */
googleDocs.addPhotos = function addPhotos(photoCount) {
    var photoCaptureWaiter = UIAWaiter.waiter("PhotoCaptured");
    for (var i = 1; i <= photoCount; i++) {
        EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons("Insert"));
        EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.tableCells("Image"));
        EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.tableCells("From camera"));
        UIALogger.logDebug("Insert photo : %0".format(i));
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("PhotoCapture"));
        photoCaptureWaiter.wait();
        EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons("Use Photo"));
        target.delay(2);
    };
}

/**
 * Method edits an existing document in Google Docs.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the new document
 * @param {string} [options.DocumentContents] - Contents to write in the document
 */
googleDocs.createDocument = function createDocument(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'Test Document',
        DocumentContents: 'This is a test document',
        PhotoCount: 1
    });
    documentName = options.DocumentName;
    documentContents = options.DocumentContents;
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons("Create New"));
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons("New document"));
    this.enterText(UIAQuery.textFields("New Name"), documentName);
    EduApp.prototype.checkUIBeforeTapping(this,"Create");
    if(this.exists(UIAQuery.buttons("Edit").isVisible())) {
        this.tap("Edit");
    }
    this.enterText(UIAQuery.query("Document contents"), documentContents);
    this.addPhotos(options.PhotoCount);
    EduApp.prototype.checkUIBeforeTapping(this,"Done");
    EduApp.prototype.checkUIBeforeTapping(this,"ic_arrow_back");
}

/**
 * Method edits an existing document in Google Docs.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the existing document
 * @param {string} [options.DocumentContents] - Contents to write in the document
 */
googleDocs.editDocument = function editDocument(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'Test Document',
        DocumentContents: 'This is a test document',
        PhotoCount: 0
    });
    documentName = options.DocumentName;
    documentContents = options.DocumentContents;
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons().andThen(UIAQuery.beginsWith(documentName)));
    EduApp.prototype.checkUIBeforeTapping(this,"Edit");
    this.enterText(UIAQuery.query("Document contents"), documentContents);
    this.addPhotos(options.PhotoCount);
    EduApp.prototype.checkUIBeforeTapping(this,"Done");
    EduApp.prototype.checkUIBeforeTapping(this,"ic_arrow_back");
}

/**
 * Method renames an existing document in Google Docs.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.OldDocumentName] - Name of the existing document
 * @param {string} [options.NewDocumentName] - Rename document to this name
 */
googleDocs.renameDocument = function renameDocument(options) {
    options = UIAUtilities.defaults(options, {
        OldDocumentName: 'Test Document',
        NewDocumentName: 'New Test Document',
    });
    oldDocumentName = options.OldDocumentName;
    newDocumentName = options.NewDocumentName;
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons().andThen(UIAQuery.beginsWith(oldDocumentName).siblings()));
    EduApp.prototype.checkUIBeforeTapping(this,"Rename");
    this.enterText(UIAQuery.textFields().withPredicate("name contains[c] 'rename'"), newDocumentName);
    EduApp.prototype.checkUIBeforeTapping(this, UIAQuery.buttons().withPredicate("name contains[c] 'rename'"));
}

/**
 * Method removes an existing document in Google Docs.
 *
 * @param {object} options - Test arguments
 * @param {string} [options.DocumentName] - Name of the document to be removed
 */
googleDocs.removeDocument = function removeDocument(options) {
    options = UIAUtilities.defaults(options, {
        DocumentName: 'Test Document',
    });
    documentName = options.DocumentName;
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons().andThen(UIAQuery.beginsWith(documentName).siblings()));
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons().withPredicate("name contains[c] 'remove'"));
    EduApp.prototype.checkUIBeforeTapping(this,UIAQuery.buttons().withPredicate("name contains[c] 'remove'"));
}