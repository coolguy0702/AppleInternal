load('UIAApp.js');
load('UIAUtility.js');
load('UIATesting.js');
load('Safari.js');
load('Settings.js');
load('SpringBoard.js');
load('UIAApp+Camera.js');

function EduApp() {}

/**
 * This method will wait for the element to appear on the UI till timeout is reached.
 * If element appears then it will tap the element else log an UIAError
 *
 * @param {object} app - app object which has the element
 * @param {string} query - UIAQuery
 * @param {integer} timeout - timeout for the wait
 */
EduApp.prototype.checkUIBeforeTapping = function(app, elementQuery, timeout) {
    timeout = UIAUtilities.defaults(timeout, 15);
    if(app.waitUntilPresent(elementQuery, timeout)) {
        app.tap(elementQuery);
    } else {
        UIALogger.logError('Timed out waiting for ' + elementQuery);
    }
}

/**
 * This method serves as a common method for the iWorks document to add media
 * to the document.
 *
 * @param {object} app - iWorks app object
 * @param {integer} photoCont - Number of photos to be added to the document
 * @param {integer} videoCount - Number of videos to be added to the document
 * @param {integer} videoDuration - duration of each video in seconds
 */
EduApp.prototype.addMediaToDocument = function(app, photoCount, videoCount, videoDuration) {
	var photoCaptureWaiter = UIAWaiter.waiter("CUShutterButton");
	var videoCaptureWaiter = UIAWaiter.waiter("CUShutterButton");
	for (var i = 0; i < photoCount; i++) {
		UIALogger.logDebug("Insert photo : %0".format(i));
		this.checkUIBeforeTapping(app, UIAQuery.buttons("Insert"));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Media"));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Take Photo or Video"));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("CUShutterButton"));
        photoCaptureWaiter.wait();
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Use Photo"));
        target.delay(2);
	};

	for (var i = 0; i < videoCount; i++) {
        UIALogger.logDebug("Insert video : %0".format(i));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Insert"));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Media"));
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Take Photo or Video"));
        var cameraModeBar = UIAQuery.CAMERA_MODE
        app.dragUpInside(cameraModeBar)
        this.checkUIBeforeTapping(app, UIAQuery.query("CAMModeDialItem").atIndex(0))
        var videoPresent = UIAQuery.buttons("VideoCapture")
        while (!app.exists(videoPresent)){
            UIALogger.logMessage('Do not see Video Capture. Going to try changing to video mode')
            var cameraModeBar = UIAQuery.CAMERA_MODE
            app.dragUpInside(cameraModeBar)
            var videoPresent = UIAQuery.buttons("VideoCapture")
        }
        this.checkUIBeforeTapping(app, UIAQuery.buttons("CUShutterButton"));
        target.delay(videoDuration);
        this.checkUIBeforeTapping(app, UIAQuery.buttons("CUShutterButton"));
        if (!app.exists(UIAQuery.buttons("Use Video"))){
            this.tap("Video Capture")
        }
        videoCaptureWaiter.wait();
        this.checkUIBeforeTapping(app, UIAQuery.buttons("Use Video"));
        target.delay(2);
	};
}

EduApp.prototype.enableiCloud = function enableiCloud(app) {
    var appCell = UIAQuery.tableCells().andThen(app.name());
    settings.launch();
    settings.tap(appCell);
    settings.setControl(UIAQuery.switches("Use iCloud"), true);
}
