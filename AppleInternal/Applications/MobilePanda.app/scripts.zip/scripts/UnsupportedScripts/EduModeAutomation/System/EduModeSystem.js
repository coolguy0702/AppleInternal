
load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");
load('SpringBoardTests.js');
load('EduLoginUI.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State                                                    */
/*                                                                             */
/*      A function to determine which UI state the app is currently in         */
/*                                                                             */
/*******************************************************************************/

var edumodesystem = target.systemApp();
var LOGIN_UI_APP_BUNDLE_ID = 'com.apple.LoginUI';

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and SpringBoard for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
edumodesystem.logOutEduModeUser = function logOutEduModeUser() {
    var loginUIApp = target.appWithBundleID(LOGIN_UI_APP_BUNDLE_ID);
    if (loginUIApp && loginUIApp.isRunning()) {
        UIALogger.logMessage('Already landed on LoginUI screen. Assume user already signed out.');
        return '';
    }

    var locked = edumodesystem.lock();
    if ((typeof locked === 'undefined' || locked) && target.isLocked()) {
        // do nothing for now
    } else {
        throw new UIAError('Could not lock device');
    }
    target.clickLock();
    
    // tap the log out element
    edumodesystem.tap(UIAQuery.buttons('Log Out'));
}

/**
 * Check for unexpected alerts during apps launch process.
 * Closes all alerts silently. If there are unexpected alerts handled during launch period,
 * the method throws an error after launch process completes.
 *
 * @throws If unexpected alerts appeared or if app was not launched.
 */
edumodesystem.launchAppsVerifyAlerts = function launchAppsVerifyAlerts(args) {
    eduModeAlertHandler.setOptions(args);
    UIALogger.logMessage('Checking for unexpected alert(s) during apps launch: %0'.format(args.unexpectedAlerts.join(', ')));
    SpringBoardTests.launchApps(args);
    if (args.unexpectedAlertsTracker.length) {
        throw new UIAError('Unexpected alerts encountered: %0'.format(args.unexpectedAlertsTracker.join(', ')))
    }
}

