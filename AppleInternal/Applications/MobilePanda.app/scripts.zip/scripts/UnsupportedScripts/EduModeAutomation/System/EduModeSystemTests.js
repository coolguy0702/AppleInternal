load('UIATesting.js');
load('UIAApp.js');
load('SpringBoard.js');
load('EduModeSystem.js');

UIAUtilities.assert(
    typeof SystemTests === 'undefined',
    'SystemTests has already been defined.'
);

var SystemTests = {
    
    /**
     * Log out edu mode user
     *
     * @param {object} args Test arguments
     */
    logOutEduModeUser: function logOutEduModeUser(args) {
        edumodesystem.logOutEduModeUser();
    },

    /**
     * Check for unexpected prompts during apps launch process.
     *
     * @param {object} args Test arguments.
     * @param {array}  [args.apps=["com.apple.iBooks"]] - Bundle ids for the apps to launch.
     * @param {object} [args.launchOptions={"deactivate": true}] - Options to be passed into UIAApp.launch
     *      (see [UIAApp.launch]{@link UIAApp#launch} for options that can be passed through through launchOptions).
     * @param {boolean} [args.verifyUsingSwitcher=false] - if true close and reopen each app using the switcher.
     * @param {boolean} [args.quit=false] - if true close the app after verifying launch.
     * @param {object} [args.quitOptions={}] - Options to be passed into UIAApp.quit.
     * @param {array} [args.unexpectedAlerts=["Sign", "Apple ID Verification"]] - Titles of unexpected alerts to match against.
     * @param {array} [args.unexpectedAlertsTracker=[]]
     * @param {string} [args.username=""]
     * @param {string} [args.password=""]
     * @alertHandlers eduModeAlertHandler
     */
    launchAppsVerifyAlerts: function launchAppsVerifyAlerts(args) {
        args = UIAUtilities.defaults(args, {
            apps: ['com.apple.iBooks'],
            launchOptions: {deactivate: true},
            verifyUsingSwitcher: false,
            quit: false,
            quitOptions: {},
            unexpectedAlerts: ['Sign', 'Apple ID Verification'],
            unexpectedAlertsTracker: [],
            username: '',
            password:'',
        });

        edumodesystem.launchAppsVerifyAlerts(args);
    },
};
