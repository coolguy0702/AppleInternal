
load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");



/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIStateDescription.EduLoginUI = {
}

/**
 @namespace
 @augments UIAApp
 */
var eduloginui = target.appWithBundleID('com.apple.LoginUI');

var handler = function() {
    app = target.activeApp();
    if(app.exists('The Apple ID you entered couldn\'t be found or your password was incorrect. Please try again.')) {
        app.tap(UIAQuery.buttons('OK'));
        throw new UIAError('Apple ID couldnt be found or incorrect password');
    } else if (app.exists('This Apple ID cannot be used on this device.')) {
        app.tap(UIAQuery.buttons('OK'));
        throw new UIAError('Device isn\'t whitelisted');
    } else {
        return false;
    }
    return true;
}

/**
 * Handler that tracks and handles unexpected alerts.
 * Unexpected alerts may appear before test execution, so it is essential to eliminate
 * standard and base alert handlers to leave unexpected alerts unhandled for custom alert handler.
 * eduModeAlertHandler.options is used to propagate test arguments needed to handle some alerts.
 *
 * The eduModeAlertHandler.options.unexpectedAlerts array contains strings against which alert titles will be matched.
 * In case of a match, if eduModeAlertHandler.options.unexpectedAlertsTracker is provided, the alert's title and body
 * will be added to it. Otherwise an error will be thrown on the first match against unexpected alerts.
 *
 * @returns {boolean} - True if alert was handled.
 *
 * @throws if an alert was not handled or if eduModeAlertHandler.options.unexpectedAlertsTracker
 * is not provided and unexpected alert was handled.
 */
 var eduModeAlertHandler = function eduModeAlertHandler() {
    if(!eduModeAlertHandler.options) {
      UIALogger.logMessage('Options not set yet. Leaving alert unhandled.');
      // Prevent standard alert handling.
      return true;
    }
    var options = eduModeAlertHandler.options;

    var app = target.activeApp();
    var unexpectedAlertTitle;
    var unexpectedAlertBody;
    var PASSWORD_TEXTFIELD = UIAQuery.secureTextFields();
    var unexpectedAlerts = options.unexpectedAlerts;
    var username = (options.username).concat('\n');
    var password = (options.password).concat('\n');

    target.delay(2);

    //optional argument
    unexpectedAlertsTracker = options.unexpectedAlertsTracker;

    // use while loop in case of several alerts simultaneously present one above another
    while (app.exists(UIAQuery.alerts().isVisible())) {
        var title = app.inspect(UIAQuery.alerts()).name;
        UIALogger.logMessage('<%0> alert appeared. Tapping it...'.format(title));

        for (var i = 0; i < unexpectedAlerts.length; i++) {
            if (title.toLowerCase().indexOf(unexpectedAlerts[i].toLowerCase()) > -1) {
                unexpectedAlertTitle = title;
                unexpectedAlertBody = app.inspect(UIAQuery.alerts().andThen(UIAQuery.staticTexts()).last()).identifiers[0];
                if (unexpectedAlertsTracker) {
                    unexpectedAlertsTracker.push('%0 %1'.format(unexpectedAlertTitle, unexpectedAlertBody));
                }
                break;
            }
        }

        target.delay(1); // allow alert to be captured in case of failure video.
        // Subsequent alerts (if any) doesn't belong to existing app, thus calling target.activeApp() to handle them
        if (title.contains('Sign In to iTunes Store') || title.contains('Sign In to iCloud')) {
            target.activeApp().tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Sign In to iTunes Store')));
            target.activeApp().tap(UIAQuery.alerts().andThen(PASSWORD_TEXTFIELD));
            target.activeApp().typeString(password);
        } else if (title.contains('Sign In Required')) {
            app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Sign In')));
            target.activeApp().waitUntilPresent(UIAQuery.alerts('Sign In'), 3);
            target.activeApp().tap(UIAQuery.alerts().andThen(UIAQuery.buttons('Use Existing Apple ID')));
        } else if (title.contains('Apple ID Verification')) {
            app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Settings')));
            if (target.activeApp().exists(UIAQuery.alerts('Apple ID Password'))) {
                target.activeApp().tap(UIAQuery.alerts().andThen(PASSWORD_TEXTFIELD));
                target.activeApp().typeString(password);
            } else {
               throw new UIAError("Settings did not open");
            }
        } else {
            // default alerts handling
            var tapped = target.activeApp().tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Cancel'))) ||
                target.activeApp().tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('OK'))) ||
                target.activeApp().tapIfExists(UIAQuery.alerts().andThen(UIAQuery.buttons()));
            if (!tapped) {
                throw new UIAError('Cannot handle alert <%0>.'.format(title));
            }
        }
    }
    if (!unexpectedAlertsTracker && unexpectedAlertTitle) {
        throw new UIAError(
            'Unexpected alert <%0> appeared: %1'.format(unexpectedAlertTitle, unexpectedAlertBody));
    }
    return true;
}

/**
 * Sets handler's options and checks for missed alerts.
 *
 * @param {object} options - Handler options.
 */
eduModeAlertHandler.setOptions = function setOptions(options) {
    eduModeAlertHandler.options = options;
    UIALogger.logMessage('Checking for missed alerts...');
    eduModeAlertHandler();
}

/**
 * Log into Edu User using Managed AppleID.
 * @param {string} managedID - Managed Apple ID
 * @param {string} managedIDPassword - Managed Apple ID Password
 * @returns {None}
 */
eduloginui.loginEduModeUser = function loginEduModeUser(appleID,appleIDPassword) {
    if (target.activeApps()[0].bundleID() == 'com.apple.LoginUI') {
        this.withAlertHandler(handler, function() {
            // Press home button
            target.clickMenu();
            UIALogger.logMessage('Tapping on a ID Filed');
            appleID = appleID.concat('\n');
            appleIDPassword = appleIDPassword.concat('\n');
            eduloginui.tapIfExists('Other users');
            eduloginui.enterText(UIAQuery.textFields(),appleID);
            eduloginui.enterText(UIAQuery.secureTextFields(),appleIDPassword);
            return;
        });
    } else {
        UIALogger.logMessage('Target app is not LoginUI; Assuming user already signed in');
        return;
    }
}

/**
 * Login user by selecting it from the class roaster
 *
 * @param {string} [className] - Name of the class student belongs to
 * @param {string} [studentName] - Full name of the student (Do not pass student id)
 * @param {string} [password] - Student password
 */
eduloginui.loginEduModeUserFromClassRoster = function loginEduModeUserFromClassRoster(className, studentName, password) {
    if (target.activeApps()[0].bundleID() == this.bundleID()) {
        this.withAlertHandler(handler, function() {
            target.clickMenu();
            this.tapIfExists('Classes');
            this.tap(className);
            this.tap(studentName);
            for (var i = 0; i < password.length; i++) {
                this.tap(password[i]);
            }
        });
    } else {
        UIALogger.logMessage('Target app is not LoginUI; Assuming user already signed in');
    }
}

/**
 * Select user from the recent users list
 *
 * @param {string} [studentName] - Full name of the student (Do not pass student id)
 * @param {string} [password] - Student password
 */
eduloginui.loginEduModeRecentUser = function loginEduModeRecentUser(studentName, password) {
    if (target.activeApps()[0].bundleID() == this.bundleID()) {
        this.withAlertHandler(handler, function() {
            target.clickMenu();
            this.tap(studentName);
            for (var i = 0; i < password.length; i++) {
                this.tap(password[i]);
            }
        });
    } else {
        UIALogger.logMessage('Target app is not LoginUI; Assuming user already signed in');
    }
}

/**
 * Checks if alerts from unexpectedAlerts appeared for already logged in user.
 * Closes an alert silently if it is not matched by any of the unexpectedAlerts.
 * Otherwise, closes the alert and throws an error.
 *
 * @param {number} [options.delay=60] - Number of seconds to wait for alerts.
 * @param {array} [options.unexpectedAlerts=["Sign", "Apple ID Verification"]] - Titles of unexpected alerts to match against.
 * @param {string} [options.username=""] - managed apple id
 * @param {string} [options.password=""] - managed apple id password
 *
 * @throws If unexpected alerts appeared.
 */
eduloginui.eduModeUserVerifyPrompt = function eduModeUserVerifyPrompt(options) {
    eduModeAlertHandler.setOptions(options);
    UIALogger.logMessage('Waiting for unexpected alert(s): %0'.format(options.unexpectedAlerts.join(', ')));
    target.delay(options.delay);
}


