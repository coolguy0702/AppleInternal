load('UIATesting.js');
load('UIAApp.js');
load('SpringBoard.js');
load('EduLoginUI.js');

UIAUtilities.assert(
    typeof EduModeLoginUITests === 'undefined',
    'EduModeLoginUITests has already been defined.'
);

var EduModeLoginUITests = {
    /**
     * Login using managed apple id from LoginUI
     *
     * @param {object} args Test arguments
     * @param {string} [args.managedID=""] - Required grade number
     * @param {string} [args.managedIDPassword=""] - Required student name
     */
    loginEduModeUser: function loginEduModeUser(args) {
        args = UIAUtilities.defaults(args, {
                 managedID: "",
                 managedIDPassword: "",
        });
        eduloginui.loginEduModeUser(args.managedID,args.managedIDPassword);
    },

    /**
     * Login user by selecting it from the class roaster
     *
     * @param {object} args Test arguments
     * @param {string} [args.className=""] - Name of the class student belongs to
     * @param {string} [args.studentName=""] - Full name of the student (Do not pass student id)
     * @param {string} [args.password=""] - Student password
     */
    loginEduModeUserFromClassRoster: function loginEduModeUserFromClassRoster(args) {
        args = UIAUtilities.defaults(args, {
            className: "",
            studentName: "",
            password: "",
        });
        eduloginui.loginEduModeUserFromClassRoster(args.className, args.studentName, args.password);
    },

    /**
     * Select user from the recent users list
     *
     * @param {object} args Test arguments
     * @param {string} [args.studentName=""] - Full name of the student (Do not pass student id)
     * @param {string} [args.password=""] - Student password
     */
    loginEduModeRecentUser: function loginEduModeRecentUser(args) {
        args = UIAUtilities.defaults(args, {
            studentName: "",
            password: "",
        });
        eduloginui.loginEduModeRecentUser(args.studentName, args.password);
    },

    /**
     * Check for unexpected prompts for already logged in user
     *
     * @param {object} args Test arguments
     * @param {number} [args.delay=60] - Number of seconds to wait for alerts.
     * @param {array} [args.unexpectedAlerts=["Sign", "Apple ID Verification"]] - Titles of unexpected alerts to match against.
     * @param {string} [args.username=""] - managed apple id
     * @param {string} [args.password=""] - managed apple id password
     * @param {array} [args.unexpectedAlertsTracker=null] - list to track unexpected alerts
     * @alertHandlers eduModeAlertHandler
     */
    eduModePromptVerification: function eduModePromptVerification(args) {
        args = UIAUtilities.defaults(args, {
            delay: 60,
            unexpectedAlerts: ['Sign', 'Apple ID Verification'],
            username: '',
            password: '',
            unexpectedAlertsTracker: null,
        });
        eduloginui.eduModeUserVerifyPrompt(args);
    },
};
