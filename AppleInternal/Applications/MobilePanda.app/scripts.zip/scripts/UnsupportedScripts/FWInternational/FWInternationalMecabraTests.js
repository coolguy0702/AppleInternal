load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('International.js');
load('Notes+International.js');
load('FWInternationalEmojis.js');
load('FWInternationalMecabra15668202.js');
load('FWInternational.js');

if (typeof MecabraQuicklookTests === 'undefined') {
	/**
	 * @namespace MecabraQuicklookTests
	 */
	var MecabraQLTests = {
		/**
		 * Mecabra Quicklook Prediction and Completion Test
		 * <rdar://tsc/15884634> Sub-TLF: Inline Prediction improvements
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLCompletionAndPrediction: function mecabraQLCompletionAndPrediction(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			var testStrings = {	'xiaogebu':'笑个不停',
								'haoshan':'好山好水',
								'huyugengduode':'呼吁更多的人',
								'niyoulai':'你又来了',
								'shenmeye':'什么也没有',
								'palihualuojin':'怕梨花落尽成秋色',
								'chouxifunanmian':'丑媳妇难免见公婆',
								'yirenzuoshi':'一人做事一人当',
								'jiangjunbaizhan':'将军百战身名裂',
								'wudebu':'无德不报',
								'wohenxing':'我很幸运',
								'mingzhishan':'明知山有虎',
								'bubaohezhi':'不饱和脂肪酸',
								'chulaihunzong':'出来混总是要还的',
								'zhunixing':'祝你幸福',
								'fazhancaishi':'发展才是硬道理',
								'buzuosijiu':'不作死就不会死',
								};
			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Prediction And Completion FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Prediction And Completion FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var totalCase = 0;
			for (var dictKey in testStrings) {
				target.activeApp().typeKeystrokes(dictKey,null,false);
				if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(testStrings[dictKey]))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("Fail case: " + dictKey + ":" + testStrings[dictKey] );
					numIssues++;
				}
				else {
					target.activeApp().tap( UIAQuery.tableCells(testStrings[dictKey]));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}
			if (numIssues > 0) {
				throw new UIAError(" mecabraTLF Prediction And Competion failed " + numIssues + " of " + totalCase + " cases.");
			}
		},

		/**
		 * Mecabra Quicklook English Prediction and Correction Test
		 * <rdar://tsc/15650728> English completion and prediction for Chinese input (iOS)
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLEnglishCompletionAndCorrection: function mecabraQLEnglishCompletionAndCorrection(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			var testStrings = {	'califor':'California',
								'confere':'conference',
								'christm':'Christmas',
								'straightfo':'straightforward',
								'accordi':'according',
								'weeke':'weekend',
								'miscel':'miscellaneous',
								'infor':'information',

								'hellp':'hello',
								'pleasr':'please',
								'virtdhay':'birthday',
								'backgroind':'background',
								'chaklenge':'challenge',
								};
			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('Mecabra Quicklook English Completion and Correction Test FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();

			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('Mecabra Quicklook English Completion and Correction Test FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var totalCase = 0;
			for (var dictKey in testStrings) {
				target.activeApp().typeKeystrokes(dictKey,null,false);
				if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(testStrings[dictKey]))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("Fail case: " + dictKey + ":" + testStrings[dictKey] );
					numIssues++;
				}
				else {
					target.activeApp().tap( UIAQuery.tableCells(testStrings[dictKey]));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}
			if (numIssues > 0) {
				throw new UIAError("Mecabra Quicklook English Completion and Correction Test failed " + numIssues + " of " + totalcase + " cases.");
			}
			UIALogger.logMessage("Pass all " + totalCase + "cases");

		},

		/**
		 * Mecabra Quicklook English Prediction and Correction Test
		 * <rdar://tsc/15650728> English completion and prediction for Chinese input (iOS)
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLEnglishPrediction: function mecabraQLEnglishPrediction(args) {
			var language= 		'Chinese (Simplified)';
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			var testStrings = {	'thank':'you',
								'how are':'you doing',
								'nice to':'see you',
								'do you mind':'following me',
								};
			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('Mecabra Quicklook English Prediction Test FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('Mecabra Quicklook English Prediction Test FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var fail = 0;
			var totalCase = 0;
			for (var dictKey in testStrings) {
				var entries = dictKey.split(" ");
				for (i=0; i < entries.length; i++) {
					target.activeApp().typeKeystrokes(entries[i],null,false);
					target.activeApp().tap("Return");
					target.activeApp().tap("空格");
				}
				var predicts = testStrings[dictKey].split(" ");
				i = 0;
				fail = 0;
				while (i < predicts.length && fail==0) {
					if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(predicts[i]))) {
						fail = 1;
					}
					else {
						target.activeApp().tap( UIAQuery.tableCells(predicts[i]));
					}
					i++;
				}
				numIssues += fail;
				totalCase ++;
				target.activeApp().tap("Return");
			}
			if (numIssues > 0) {
				throw new UIAError(" Mecabra Quicklook English Prediction Test failed " + numIssues + " of " + testStrings.length + " cases.");
			}
			UIALogger.logMessage("Pass all " + totalCase + "cases");
		},

		/**
		 * Mecabra Quicklook Emoji Test
		 * <rdar://tsc/15449539> Improve emoji input relevancy
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLEmoji: function mecabraQLEmoji(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			settings.addKeyboard(language, type, keyboard, null, true);

			/* create note */
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.1;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Emoji FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			for (var pinyin in phraseDictionary) {
				emoji = phraseDictionary[pinyin];
				target.activeApp().typeString(pinyin,null,false);
				var gotkey = false;		
				if(target.activeApp().waitUntilPresent(UIAQuery.tableCells(emoji))) {
					target.activeApp().tap(UIAQuery.tableCells(emoji));
					gotkey = true;
				}
				else {  // check emoji in the candidate view
					if(target.activeApp().waitUntilPresent(UIAQuery.buttons("More suggestions"))) {
						target.activeApp().tap(UIAQuery.buttons("More suggestions"));
						if(target.activeApp().waitUntilPresent(UIAQuery.buttons("表情"))) {
							target.activeApp().tap(UIAQuery.buttons("表情"));
							if(target.activeApp().waitUntilPresent(UIAQuery.tableCells(emoji))) {
								target.activeApp().tap(UIAQuery.tableCells(emoji));
								gotkey = true;
							}
						}
					}
				}
				if( gotkey == 0 ) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("Emoji Fail case: " + pinyin + " : " + emoji );
					numIssues++;
				}
				target.activeApp().tap("Return");
			}
			if (numIssues > 0) {
				throw new UIAError("MecabraTLF emoji failed " + numIssues + " of " + phraseDictionary.length + " cases.");
			}
		},

		/**
		 * Mecabra Quicklook Simplified Chinese language model improvements (iOS )
		 * <rdar://tsc/15668202> Whitetail Sub-TLF: Simplified Chinese language model improvements (iOS )
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLanguageModelImprovement: function mecabraQLLanguageModelImprovement(args) {
			var language =		'Chinese (Simplified)';
			var type =			'Pinyin – QWERTY';
			var keyboard =		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic';

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('MecabraTLF Simplified Chinese Language Model Improvements FAILED to add keyboard and reset dictionary ' + keyboard);
			}

			/* create note */
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('MecabraTLF Simplified Chinese language model improvements FAILED to find keyboard ' + keyboard);
			}

			var maxTest = languageModelDictionary.length;
			if (maxTest > 100 ) maxTest = 100;
			var numIssues = 0;
			var totalCase = 0;
			for (var pinyin in languageModelDictionary) {
				phrase = languageModelDictionary[pinyin];
				target.activeApp().typeString(pinyin,null,false);
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(phrase))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("MecabraTLF Simplified Chinese Language Model Improvements Fail Case: " + language + ' ' + pinyin + " : " + phrase+ " is not in candidate view" );
					numIssues++;
				}
				else {
					target.activeApp().tap(UIAQuery.tableCells(phrase));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}

			if (numIssues > 31) {
				throw new UIAError('MecabraTLF Simplified Chinese Language Model Improvement failed ' + numIssues + " of " + totalCase + " cases.  Baseline on Whitetail is 31 cases");
			}
		},
		
		/**
		 * Mecabra Quicklook Learning New Phrase Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningNewPhrase: function mecabraQLLearningNewPhrase(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning New Phrase FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning New Phrase FAILED to find keyboard ' + keyboard);
			}

			var testStringFull = "xuezhigang"
			var testStringAbbr = "xzg"
			var name1 = "薛志钢"
			var name2 = "薛至刚"
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			for( i = 0 ; i < 3 ; i++) {
				if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name1[i]))) {
					throw new UIAError("Mecabra Learning New Phrase, can't find" + name1[i]);
				} else {
					target.activeApp().tap( UIAQuery.tableCells(name1[i]));
				}
			}
			target.activeApp().typeKeystrokes(testStringAbbr,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name1))) {
				throw new UIAError("Mecabra Learning New Phrase, can't find" + name1);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(name1));
			}
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			for( i = 0 ; i < 3 ; i++) {
				if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name2[i]))) {
					throw new UIAError("Mecabra Learning New Phrase, can't find" + name2[i]);
				} else {
					target.activeApp().tap( UIAQuery.tableCells(name2[i]));
				}
			}
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name2[i]))) {
				throw new UIAError("Mecabra Learning New Phrase, can't find" + name2[i]);
			}
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name1[i]))) {
				throw new UIAError("Mecabra Learning New Phrase, can't find" + name1[i]);
			}
		},

		/**
		 * Mecabra Quicklook Learning Reranking Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningReranking: function mecabraQLLearningReranking(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning Reranking FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning Reranking FAILED to find keyboard ' + keyboard);
			}

			var testString = "yige"
			var name = "一格"
			target.activeApp().typeKeystrokes(testString,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name))) {
				throw new UIAError("Mecabra Learning Reranking, can't find" + name);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(name));
			}
			target.activeApp().tap("Return");
			
			target.activeApp().typeKeystrokes(testString,null,false);
			var cell = UIAQuery.collectionViews('UIKBCandidateCollectionView').andThen(UIAQuery.tableCells().first())
			target.activeApp().tap( cell);
			var notesContent = notes.getNoteTextContent();
			var content = notesContent.replace("一格\n","");

			if(content!=name) {
				throw new UIAError("Mecabra Learning reranking failed" + content);
			}
			target.activeApp().tap("delete");
			target.activeApp().tap("delete");
			target.activeApp().tap("delete");
			target.activeApp().tap("delete");
			target.activeApp().tap("delete");

			target.activeApp().typeKeystrokes("yg",null,false);
			var cell = UIAQuery.collectionViews('UIKBCandidateCollectionView').andThen(UIAQuery.tableCells().first())
			target.activeApp().tap(cell);

			if(content!=name) {
				throw new UIAError("Mecabra Learning Reranking failed" + content);
			}
		},
		/**
		 * Mecabra Quicklook Learning Inline Prediction Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningInlinePrediction: function mecabraQLLearningInlinePrediction(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning Inline Prediction FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning Inline Prediction FAILED to find keyboard ' + keyboard);
			}

			var testStringFull = "jiuquxigongyugang"
			var testStringShort = "jiuquxigong"
			var name = "就去西贡渔港"
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			for( i = 0 ; i < name.length ; i++) {
				if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name[i]))) {
					throw new UIAError("Mecabra Learning Inline Prediction, can't find" + name[i]);
				} else {
					target.activeApp().tap( UIAQuery.tableCells(name[i]));
				}
			}
			target.activeApp().tap("Return");
			target.activeApp().typeKeystrokes(testStringShort,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(name))) {
				throw new UIAError("Mecabra Learning Inline Prediction, can't find" + name);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(name));
			}
		},
		/**
		 * Mecabra Quicklook Learning Adaptation Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningAdaptation: function mecabraQLLearningAdaptation(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning Adaptation FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning Adaptation FAILED to find keyboard ' + keyboard);
			}
			var setupString = "wodepengyoujiao";
			var setupPhrase = "我的朋友叫";
			target.activeApp().typeKeystrokes(setupString,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(setupPhrase))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + setupPhrase);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(setupPhrase));
			}

			
			target.activeApp().typeKeystrokes("zhang",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("张"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "张");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("张"));
			}

			target.activeApp().typeKeystrokes("po",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("破"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "破");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("破"));
			}

			target.activeApp().typeKeystrokes("xuan",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("悬"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "悬");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("悬"));
			}
			target.activeApp().tap("Return");

			var testStringFull = "wodepengyoujiaozhangpoxuan"
			var fullPhrase = "我的朋友叫张破悬"
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(fullPhrase))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + fullPhrase);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(fullPhrase));
			}
			target.activeApp().tap("Return");

			target.activeApp().typeKeystrokes(setupString,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(setupPhrase))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + setupPhrase);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(setupPhrase));
			}
			
			target.activeApp().typeKeystrokes("zhang",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("张"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "张");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("张"));
			}

			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("破"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "破");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("破"));
			}
			
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("悬"))) {
				throw new UIAError("Mecabra Learning Adaptation, can't find" + "悬");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("悬"));
			}
			target.activeApp().tap("Return");
		},
		/**
		 * Mecabra Quicklook Learning Adaptation Emoji Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningAdaptationEmoji: function mecabraQLLearningAdaptationEmoji(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning Adaptation Emoji FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning Adaptation Emoji FAILED to find keyboard ' + keyboard);
			}

			var testStringFull = "taihaole"
			var phrase = "太好了"
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(phrase))) {
				throw new UIAError("Mecabra Learning Adaptation Emoji, can't find" + phrase);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(phrase));
			}
			
			target.activeApp().typeKeystrokes("zan",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("👍"))) {
				throw new UIAError("Mecabra Learning Adaptation Emoji, can't find" + "👍");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("👍"));
			}

			target.activeApp().tap("Return");
			
			target.activeApp().typeKeystrokes(testStringFull,null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells(phrase))) {
				throw new UIAError("Mecabra Learning Adaptation Emoji, can't find" + phrase);
			} else {
				target.activeApp().tap( UIAQuery.tableCells(phrase));
			}
			
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("👍"))) {
				throw new UIAError("Mecabra Learning Adaptation Emoji, can't find" + "👍");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("👍"));
			}
		},
		/**
		 * Mecabra Quicklook Learning Vulgar prediction Test
		 * <rdar://tsc/15892182> Chinese Learning test cases - #1
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		mecabraQLLearningVulgarPrediction: function mecabraQLLearningVulgarPrediction(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('mecabraTLF Learning Vulgar prediction FAILED to add keyboard and reset dictionary ' + keyboard);
			}
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			target.activeApp().interKeyDelay = 0.2;

			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('mecabraTLF Learning Vulgar prediction FAILED to find keyboard ' + keyboard);
			}

			target.activeApp().typeKeystrokes("qusi",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("去死"))) {
				throw new UIAError("Mecabra Learning Vulgar prediction, can't find" + "去死");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("去死"));
			}

			target.activeApp().typeKeystrokes("ni",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("你"))) {
				throw new UIAError("Mecabra Learning Vulgar prediction, can't find" + "你");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("你"));
			}
			target.activeApp().tap("Return");

			target.activeApp().typeKeystrokes("qusi",null,false);
			if(!target.activeApp().waitUntilPresent( UIAQuery.tableCells("去死"))) {
				throw new UIAError("Mecabra Learning Vulgar prediction, can't find" + "去死");
			} else {
				target.activeApp().tap( UIAQuery.tableCells("去死"));
			}

			if(target.activeApp().waitUntilPresent( UIAQuery.tableCells("你"))) {
				throw new UIAError("Mecabra Learning Vulgar prediction, should not find" + "你");
			}
		},
	}
}
