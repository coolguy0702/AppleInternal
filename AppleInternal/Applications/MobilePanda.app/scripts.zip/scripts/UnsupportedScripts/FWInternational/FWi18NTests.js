load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('International.js');
load('Notes+International.js');
load('FWInternational.js');

if (typeof FWi18NTests === 'undefined') {
	/**
	 * @namespace
	 */
	var FWi18NTests = {

		/**
		 * i18N Geometry Data Base Test 1
		 * <rdar://tsc/15449181> Geometry data is lost after choosing a partial candidate
		 *
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 * @param {string}  [args.language] - Language
		 * @param {string}  [args.type] - Language type
		 * @param {string}  [args.keyboard] - keybaord ID
		 * @param {string}  [args.testString] - Keystorkes for the expected text
		 * @param {string}  [args.selectCandidate] - select text
		 * @param {string}  [args.completionCandidate] - expect candidate.
		 **/
		i18NCompletionPredictionBasic: function i18NCompletionPredictionBasic(args) {
			args = UIAUtilities.defaults(args, {
				language: "Chinese (Simplified)",
				type: "Pinyin – QWERTY" ,
				keyboard: "zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic",
				testString: " jintiantuanqi",
				selectCandidate: "今天",
				completionCandidate: "天气",
			}, true);

			settings.addKeyboard(args.language, args.type, args.keyboard, null, true);
			notes.getToNewNote();  // create note
			try {
				FWInternational.findKeyboard(args.keyboard);
			} catch(e) {
				throw new UIAError('i18N Geometry Data Test Keyboard: ' + args.keyboard + ' not found');
			}

			target.activeApp().typeKeystrokes(args.testString, null, false);
			if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(args.selectCandidate), 5)) {
				throw new UIAError("fail finding selection candidate" + args.selectCandidate);
			} else {
				target.activeApp().tap(UIAQuery.tableCells(args.selectCandidate));
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(args.completionCandidate), 5)) {
					throw new UIAError("fail finding completion candidate" + args.completionCandidate);
				} else {
					target.activeApp().tap(UIAQuery.tableCells(args.completionCandidate));
				}
			}
		},
		/**
		 * i18N Geometry Data Base Test 2
		 * <rdar://tsc/15449181> Geometry data is lost after choosing a partial candidate
		 *
		 * @targetApps Notes
		 *
		 **/
		i18NGeometryDataBaseTest: function i18NGeometryDataBaseTest(args) {
			var tap_x = 0.103;
			var tap_y = 0.811;
			var hwmodel = target.mobileGestaltQuery('HWModelStr');
			//if( 'N56AP' == hwmodel || 'N66mAP' == hwmodel ) {
				// other model geometry 
			//}
			language = "Japanese";
			type = "Romaji";
			keyboard = "ja_JP-Romaji@sw=QWERTY-Japanese;hw=Automatic";
			selectCandidate = "神戸";
			completionCandidate = "から";
		
			settings.addKeyboard(language, type, keyboard, null, true);

			notes.getToNewNote();  // create note
			try {
				FWInternational.findKeyboard(keyboard);
			} catch(e) {
				throw new UIAError('i18N Geometry Data Test Keyboard: ' + keyboard + ' not found');
			}

			target.activeApp().typeKeystrokes("koubek", null, false);
			target.activeApp().tap(UIAQuery.application(),{offset:{x:tap_x, y:tap_y}}); /* cloud candidate*/
			target.activeApp().typeKeystrokes("r", null, false);
			target.activeApp().tap(UIAQuery.application(),{offset:{x:tap_x, y:tap_y}}); /* cloud candidate*/
			if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(selectCandidate), 5)) {
				throw new UIAError("fail finding selection candidate" + selectCandidate);
			} else {
				target.activeApp().tap(UIAQuery.tableCells(selectCandidate));
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(completionCandidate), 5)) {
					throw new UIAError("fail finding completion candidate" + completionCandidate);
				} else {
					target.activeApp().tap(UIAQuery.tableCells(completionCandidate));
				}
			}
		},

		/**
		 * i18N Kana Multitap Geometry Data Base Test
		 * <rdar://tsc/15449182> kana: preserve geometry information on multitap
		 * part of <rdar://ts/895682> TLF: QFA: Improve Autocorrection For Chinese And Japanese
		 *
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 **/
		i18NKanaMultitapGeometryDataBaseTest: function i18NKanaMultitapGeometryDataBaseTest(args) {
			var hwmodel = target.mobileGestaltQuery('HWModelStr');
			var tap_x = 0.6;
			var tap_y = 0.73;
			//if( 'N56AP' == hwmodel || 'N66mAP' == hwmodel ) {
				// other model geometry 
			//}
			language = "Japanese";
			type = "Kana";
			keyboard = "ja_JP-Kana@sw=Kana;hw=Automatic";
			candidate1 = "ヨンリンクドウノク、カケル、シヨウスルノシ、ツカウ"; //駆使
			candidate2 = "コトブキ、ジュミョウノジュ、シカイシャノシ"; //寿司
		
			settings.addKeyboard(language, type, keyboard, null, true);
			notes.getToNewNote();  // create note
			try {
				FWInternational.findKeyboard(keyboard);
			} catch(e) {
				throw new UIAError('i18N Geometry Data Test Keyboard: ' + keyboard + ' not found');
			}

			target.activeApp().tap(UIAQuery.application(),{offset:{x:tap_x, y:tap_y},tapCount: 3}); /* cloud candidate*/
			target.delay(3);  // this is work around back to back tap is causing multitab behavior on N66.
			target.activeApp().tap(UIAQuery.application(),{offset:{x:tap_x, y:tap_y}, tapCount: 2}); /* cloud candidate*/
			if(target.activeApp().waitUntilPresent(UIAQuery.buttons("More suggestions"))) {
				target.activeApp().tap(UIAQuery.buttons("More suggestions"));
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(candidate1), 5)){
					throw new UIAError("fail finding selection candidate" + candidate1);
				} 
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(candidate2), 5)){
					throw new UIAError("fail finding selection candidate" + candidate2);
				} 
			}
		},
		/**
		 * i18N Chinese Input Test
		 * new keyboard should appear.
		 *
		 * @targetApps Preferences
		 *
		 * @param {object}  args Test arguments
		 * @param {string}  [args.language] - Language
		 * @param {string}  [args.type] - Language type
		 * @param {string}  [args.keyboard] - keybaord ID
		 * @param {string}  [args.testString] - Keystorkes for the expected text (e.g, J-Romaji: "roppongi")
		 * @param {string}  [args.expectCandidate] - Optional expected text to be typed (e.g, "六本木") - No conversion if this is not presented (For C/J).
		 **/
		i18NChineseInput: function i18NChineseInput(args) {
			args = UIAUtilities.defaults(args, {
				language: "Chinese (Simplified)",
				type: "Pinyin – QWERTY" ,
				keyboard: "zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic",
				testString: "ceshi",
				expectCandidate: "测试",
			}, true);

			settings.addKeyboard(args.language, args.type, args.keyboard, null, true);
			notes.getToNewNote();  // create note
			try {
				FWInternational.findKeyboard(args.keyboard);
			} catch(e) {
				throw new UIAError('i18N Quicklook Input Test Keyboard: ' + args.keyboard + ' not found');
			}

			target.activeApp().typeKeystrokes(args.testString, null, false);
			if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(args.expectCandidate), 5)) {
				throw new UIAError("fail finding candidate" + args.expectCandidate);
			} else {
				if(args.testString == 'come') {
					target.activeApp().tap(UIAQuery.keys('选定'));
				} else {
					target.activeApp().tap(UIAQuery.tableCells(args.expectCandidate));
				}
			}
		},
	}
}