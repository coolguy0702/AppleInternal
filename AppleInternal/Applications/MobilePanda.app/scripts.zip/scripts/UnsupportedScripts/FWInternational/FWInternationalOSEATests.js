load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('International.js');
load('Notes+International.js');
load('FWInternational.js');

if (typeof FWInternationalOSEATests === 'undefined') {
	/**
	 * @namespace
	 */
	var FWInternationalOSEATests = {

		/**
		 * Quicklook OSEA Input Test
		 * new keyboard should appear.
		 *
		 * @targetApps Preferences
		 *
		 * @param {object}  args Test arguments
		 * @param {string}  [args.language] - Language
		 * @param {string}  [args.type] - Language type
		 * @param {string}  [args.keyboard] - keybaord ID
		 * @param {string}  [args.testString] - Keystorkes for the expected text (e.g, J-Romaji: "roppongi")
		 * @param {string}  [args.expectCandidate] - Optional expected text to be typed (e.g, "六本木") - No conversion if this is not presented (For C/J).
		 **/
		oseaQuicklookChineseInput: function oseaQuicklookChineseInput(args) {
			args = UIAUtilities.defaults(args, {
				language: "Chinese (Simplified)",
				type: "Pinyin – QWERTY" ,
				keyboard: "zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic",
				testString: "ceshi",
				expectCandidate: "测试",
			}, true);

			settings.addKeyboard(args.language, args.type, args.keyboard, null, true);
			notes.getToNewNote();  // create note
			try {
				FWInternational.findKeyboard(args.keyboard);
			} catch(e) {
				throw new UIAError('OSEA Quicklook Input Test Keyboard: ' + args.keyboard + ' not found');
			}

			target.activeApp().typeKeystrokes(args.testString, null, false);
			if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(args.expectCandidate), 5)) {
				throw new UIAError("fail finding candidate" + args.expectCandidate);
			} else {
				if(args.testString == 'come') {
					target.activeApp().tap(UIAQuery.keys('选定'));
				} else {
					target.activeApp().tap(UIAQuery.tableCells(args.expectCandidate));
				}
			}
		},
	}
}
