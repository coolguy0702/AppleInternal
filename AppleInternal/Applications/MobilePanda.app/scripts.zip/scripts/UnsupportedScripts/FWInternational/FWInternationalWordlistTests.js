load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('International.js');
load('Notes+International.js');
load('FWInternationalEmojis.js');
load('FWInternationalWordlist.js');
load('FWInternational.js');

if (typeof WordlistsTests === 'undefined') {
	/**
	 * @namespace WordlistsTests
	 */
	var WordlistsTests = {
		/**
		 * TC Zhuyin Wordlists Tests
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		tcZhuyinWordlistsTests: function tcZhuyinWordlistsTests(args) {
			var language= 		'Chinese (Traditional)';	
			var type =			'Zhuyin – Standard';
			var keyboard = 		'zh_Hant-Zhuyin@sw=Zhuyin;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('TC Zhuyin Wordlists Tests FAILED to add keyboard and reset dictionary ' + keyboard);
			}

			/* create note */
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('TC Zhuyin Wordlists Tests FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var totalCase = 0;
			for (var pinyin in tcZhuyinDictionary) {
				phrase = tcZhuyinDictionary[pinyin];
				target.activeApp().typeKeystrokes(pinyin, null, false);
				//target.activeApp().typeString(pinyin,null,false);
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(phrase))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("TC Zhuyin Wordlists Tests Fail Case: " + language + ' ' + pinyin + " : " + phrase+ " is not in candidate view" );
					numIssues++;
				}
				else {
					target.activeApp().tap(UIAQuery.tableCells(phrase));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}

			if (numIssues > 0) {
				throw new UIAError('TC Zhuyin Wordlists Tests failed ' + numIssues + " of " + totalCase + " cases.  Baseline on Whitetail is 31 cases");
			}
		},
		
		/**
		 * TC Pinyin Wordlists Tests
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		tcPinyinWordlistsTests: function tcPinyinWordlistsTests(args) {
			var language= 		'Chinese (Traditional)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('TC Pinyin Wordlists Tests FAILED to add keyboard and reset dictionary ' + keyboard);
			}

			/* create note */
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('TC Pinyin Wordlists Tests FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var totalCase = 0;
			for (var pinyin in tcPinyinDictionary) {
				phrase = tcPinyinDictionary[pinyin];
				target.activeApp().typeString(pinyin,null,false);
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(phrase))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("TC Pinyin Wordlists Tests Fail Case: " + language + ' ' + pinyin + " : " + phrase+ " is not in candidate view" );
					numIssues++;
				}
				else {
					target.activeApp().tap(UIAQuery.tableCells(phrase));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}

			if (numIssues > 0) {
				throw new UIAError('TC Pinyin Wordlists Tests failed ' + numIssues + " of " + totalCase + " cases.  Baseline on Whitetail is 31 cases");
			}
		},
		/**
		 * SC Pinyin Wordlists Tests
		 * @targetApps Notes
		 *
		 * @param {object}  args Test arguments
		 */
		scPinyinWordlistsTests: function scPinyinWordlistsTests(args) {
			var language= 		'Chinese (Simplified)';	
			var type =			'Pinyin – QWERTY';
			var keyboard = 		'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=Automatic' ;

			try {
				settings.addKeyboard(language, type, keyboard, null, true);
				settings.navigateNavigationViews([ "General", "Reset"]);
				settings.tap(UIAQuery.tableCells("Reset Keyboard Dictionary"));
				target.activeApp().tap(UIAQuery.buttons("Reset Dictionary"));
			} catch(e) {
				throw new UIAError('SC Pinyin Wordlists Tests FAILED to add keyboard and reset dictionary ' + keyboard);
			}

			/* create note */
			notes.launch();
			notes.quit();
			notes.getToNewNote();
			try {
				FWInternational.findKeyboard(keyboard);
			}catch(e) {
				throw new UIAError('SC Pinyin Wordlists Tests FAILED to find keyboard ' + keyboard);
			}

			var numIssues = 0;
			var totalCase = 0;
			for (var pinyin in scPinyinDictionary) {
				phrase = scPinyinDictionary[pinyin];
				target.activeApp().typeString(pinyin,null,false);
				if(!target.activeApp().waitUntilPresent(UIAQuery.tableCells(phrase))) {
					target.activeApp().tap("Return");
					UIALogger.logMessage("SC Pinyin Wordlists Tests Fail Case: " + language + ' ' + pinyin + " : " + phrase+ " is not in candidate view" );
					numIssues++;
				}
				else {
					target.activeApp().tap(UIAQuery.tableCells(phrase));
				}
				target.activeApp().tap("Return");
				totalCase++;
			}

			if (numIssues > 0) {
				throw new UIAError('SC Pinyin Wordlists Tests failed ' + numIssues + " of " + totalCase + " cases.  Baseline on Whitetail is 31 cases");
			}
		},
	}
}
