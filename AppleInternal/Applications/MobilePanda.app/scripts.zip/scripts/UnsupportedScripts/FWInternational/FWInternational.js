load('UIAUtility.js');
load('UIAApp.js');
load('Settings.js');

UIAUtilities.assert(
    typeof FWInternational === 'undefined',
    'Framework International has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/
UIAQuery.FWInternational = {
}

/**
    @namespace
    @augments FWInternational
*/
FWInternational = {
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

FWInternational.findKeyboard = function findKeyboard(keyboard) {
	var startKeyboardID = target.activeApp().getKeyboardID();
	var keyboardID = startKeyboardID;
	var loopCount = 0;

	// setup keyboard
	UIALogger.logMessage('setup keyboardID ' + keyboardID);
	while ( (keyboardID != keyboard) && loopCount < 2) { 
		// extra loopCount to get around sometime the globe key skip keyboard.
		target.activeApp().tap(UIAQuery.buttons('Next keyboard'));
		keyboardID = target.activeApp().getKeyboardID();
		if (keyboardID == startKeyboardID) {
			loopCount++;
		}
	}
	if( keyboardID != keyboard ) {
		throw new UIAError('-------------------> FAILED : ' + keyboard + ' not found');
	}
} //findKeyboard
