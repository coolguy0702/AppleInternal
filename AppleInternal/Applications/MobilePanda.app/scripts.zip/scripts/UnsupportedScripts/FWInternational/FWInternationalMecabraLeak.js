load('UIATesting.js');
load('Settings.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAApp+Keyboard.js');
load('International.js');
load('Notes+International.js');

if (typeof fwmemoryleak === 'undefined') {
    /**
        @namespace
        @augments UIAApp
    */
    var fwmemoryleak = {};
    UIALogger.logDebug("Created 'fwmemoryleak' object for fwmemoryleak automation test.");
}


/******************************************************************************/
/*                                                                            */
/*   Mark: Query Constants                                                    */
/*                                                                            */
/*      App specific queries that will be used frequently                     */
/*                                                                            */
/******************************************************************************/
/** @namespace */
UIAQuery.fwmemoryleak = {};


/*****************************************************************************/
/*                                                                           */
/*   Mark: Actions                                                           */
/*                                                                           */
/*      Atomic units of UI automation and helper functions                   */
/*      These will assume the devices is already in the required state       */
/*                                                                           */
/*****************************************************************************/


fwmemoryleak.memoryLeakScenario1Test1 = function memoryLeakScenario1Test1(args) {
	var languages= 	[	'Chinese (Simplified)',
						'Chinese (Simplified)', 	
						'English',
						'Chinese (Simplified)',
						'Chinese (Traditional)'];
						
	var types = 	[	'Pinyin – QWERTY', 
						'Handwriting', 
						'', 
						'Stroke', 
						'Pinyin – QWERTY'];
						
	var keyboards = [	'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=US', 
						'zh_Hans-HWR@sw=HWR-Simplified', 
						'en_US@hw=US;sw=QWERTY',
						'zh_Hans-Wubihua@sw=Wubihua-Simplified;hw=US',
						'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US'];
						
	var testStrings = [	'yiziyizszyzy',
						'',
						'Twin artists create haunting images of clash between culture and religion.',
						'丿乛一一一一一丨乛丿丶乛丶',
						'yiziyizszyzy' ];
						
	for (var i = 0; i < languages.length; i++) {
		settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
	}

	/* create note */
	var options = UIAUtilities.defaults(args, {
		folder: 'Notes',
		leaveOpenForEditing: true,
	});
	notes.getToNewNote(args);

	UIALogger.logMessage('**************Ready to start typing ');
	/* switch to first keyboard*/	
	for (var i = 0; i < languages.length; i++) {
		var keyboardID = target.activeApp().getKeyboardID();
		UIALogger.logMessage('keyboardID ' + keyboardID);

		while (keyboards[i] != keyboardID) {
			target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
			keyboardID = target.activeApp().getKeyboardID()
		 }

		switch (keyboards[i]) {
			case 'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=US':
				target.activeApp().typeString(testStrings[i]);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'zh_Hans-HWR@sw=HWR-Simplified':
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.20, y: 0.37}, endOffset: {x: 0.13, y: 0.47}});
				notes.drag("UIKeyboardLayoutStar", {startOffset: {x: 0.10, y: 0.46}, endOffset: {x: 0.38, y: 0.47}})
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.16, y: 0.43}, endOffset: {x: 0.13, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.10, y: 0.62}, endOffset: {x: 0.21, y: 0.60}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.22, y: 0.39}, endOffset: {x: 0.3, y: 0.81}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.65}, endOffset:{x: 0.25, y: 0.69}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.40}, endOffset:{x: 0.38, y: 0.47}});

				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.60, y: 0.37}, endOffset: {x: 0.53, y: 0.47}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.56, y: 0.43}, endOffset: {x: 0.53, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.64, y: 0.45}, endOffset: {x: 0.61, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.66, y: 0.45}, endOffset: {x: 0.81, y: 0.46}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.81, y: 0.46}, endOffset: {x: 0.82, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.69, y: 0.43}, endOffset: {x: 0.69, y: 0.48}});
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'en_US@hw=US;sw=QWERTY':
				target.activeApp().typeString(testStrings[i]);
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;

			case 'zh_Hans-Wubihua@sw=Wubihua-Simplified;hw=US':
				target.activeApp().typeKeystrokes(testStrings[i],null,false);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;

			case 'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US':
				target.activeApp().typeString(testStrings[i]);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
		}
		
		UIALogger.logPass(">>>>>>>>>> Pass Test: " + languages[i] + ' ' + keyboardID);
	}
},

fwmemoryleak.memoryLeakScenario1Test2 = function memoryLeakScenario1Test2(args) {
	var languages= 	[	'Chinese (Traditional)',
						'Chinese (Traditional)', 	
						'Chinese (Traditional)', 	
						'English',
						'Chinese (Simplified)'];
						
	var types = 	[	'Pinyin – QWERTY', 
						'Handwriting', 
						'Cangjie – Standard', 
						'', 
						'Pinyin – QWERTY'];
						
	var keyboards = [	'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US', 
						'zh_Hant-HWR@sw=HWR-Traditional', 
						'zh_Hant-Cangjie@sw=Cangjie;hw=CangjieKeyboard',
						'en_US@hw=US;sw=QWERTY',
						'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=US'];
						
	var testStrings = [	'yiziyizszyzy',
						'',
						'月戈心人弓弓火土',
						'Twin artists create haunting images of clash between culture and religion.',
						'yiziyizszyzy' ];
						
	for (var i = 0; i < languages.length; i++) {
		settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
	}

	/* create note */
	var options = UIAUtilities.defaults(args, {
		folder: 'Notes',
		leaveOpenForEditing: true,
	});
	notes.getToNewNote(args);


	UIALogger.logMessage('**************Ready to start typing ');
	/* switch to first keyboard*/	
	for (var i = 0; i < languages.length; i++) {
		var keyboardID = target.activeApp().getKeyboardID();
		UIALogger.logMessage('keyboardID ' + keyboardID);

		while (keyboards[i] != keyboardID) {
			target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
			keyboardID = target.activeApp().getKeyboardID()
		 }

		switch (keyboards[i]) {
			case 'zh_Hans-Pinyin@sw=Pinyin-Simplified;hw=US':
			case 'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US':
			case 'zh_Hant-Cangjie@sw=Cangjie;hw=CangjieKeyboard':
				target.activeApp().typeString(testStrings[i]);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'zh_Hant-HWR@sw=HWR-Traditional':
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.20, y: 0.37}, endOffset: {x: 0.13, y: 0.47}});
				notes.drag("UIKeyboardLayoutStar", {startOffset: {x: 0.10, y: 0.46}, endOffset: {x: 0.38, y: 0.47}})
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.16, y: 0.43}, endOffset: {x: 0.13, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.10, y: 0.62}, endOffset: {x: 0.21, y: 0.60}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.22, y: 0.39}, endOffset: {x: 0.3, y: 0.81}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.65}, endOffset:{x: 0.25, y: 0.69}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.40}, endOffset:{x: 0.38, y: 0.47}});

				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.60, y: 0.37}, endOffset: {x: 0.53, y: 0.47}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.56, y: 0.43}, endOffset: {x: 0.53, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.64, y: 0.45}, endOffset: {x: 0.61, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.66, y: 0.45}, endOffset: {x: 0.81, y: 0.46}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.81, y: 0.46}, endOffset: {x: 0.82, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.69, y: 0.43}, endOffset: {x: 0.69, y: 0.48}});
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'en_US@hw=US;sw=QWERTY':
				target.activeApp().typeString(testStrings[i]);
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
		}
		
		UIALogger.logPass(">>>>>>>>>> Pass Test: " + languages[i] + ' ' + keyboardID);
	}
},

fwmemoryleak.memoryLeakScenario1Test3 = function memoryLeakScenario1Test3(args) {
	var languages= 	[	'Chinese (Traditional)',
						'Chinese (Traditional)', 	
						'Chinese (Traditional)', 	
						'English',
						'Chinese (Traditional)'];
						
	var types = 	[	'Zhuyin – Standard', 
						'Handwriting', 
						'Stroke', 
						'', 
						'Pinyin – QWERTY'];
						
	var keyboards = [	'zh_Hant-Zhuyin@sw=Zhuyin;hw=Zhuyin Bopomofo', 
						'zh_Hant-HWR@sw=HWR-Traditional', 
						'zh_Hant-Wubihua@sw=Wubihua-Traditional;hw=US',
						'en_US@hw=US;sw=QWERTY',
						'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US'];
						
	var testStrings = [	'ㄓㄨˋㄧㄣ',
						'',
						'丿乛一一一一一丨乛丿丶乛丶',
						'Twin artists create haunting images of clash between culture and religion.',
						'yiziyizszyzy' ];
						
	for (var i = 0; i < languages.length; i++) {
		settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
	}

	/* create note */
	var options = UIAUtilities.defaults(args, {
		folder: 'Notes',
		leaveOpenForEditing: true,
	});
	notes.getToNewNote(args);


	UIALogger.logMessage('**************Ready to start typing ');
	/* switch to first keyboard*/	
	for (var i = 0; i < languages.length; i++) {
		var keyboardID = target.activeApp().getKeyboardID();
		UIALogger.logMessage('keyboardID ' + keyboardID);

		while (keyboards[i] != keyboardID) {
			target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
			keyboardID = target.activeApp().getKeyboardID()
		 }

		switch (keyboards[i]) {
			case 'zh_Hant-Zhuyin@sw=Zhuyin;hw=Zhuyin Bopomofo':
			case 'zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US':
				target.activeApp().typeString(testStrings[i]);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'zh_Hant-HWR@sw=HWR-Traditional':
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.20, y: 0.37}, endOffset: {x: 0.13, y: 0.47}});
				notes.drag("UIKeyboardLayoutStar", {startOffset: {x: 0.10, y: 0.46}, endOffset: {x: 0.38, y: 0.47}})
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.16, y: 0.43}, endOffset: {x: 0.13, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.10, y: 0.62}, endOffset: {x: 0.21, y: 0.60}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.22, y: 0.39}, endOffset: {x: 0.3, y: 0.81}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.65}, endOffset:{x: 0.25, y: 0.69}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.34, y: 0.40}, endOffset:{x: 0.38, y: 0.47}});

				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.60, y: 0.37}, endOffset: {x: 0.53, y: 0.47}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.56, y: 0.43}, endOffset: {x: 0.53, y: 0.71}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.64, y: 0.45}, endOffset: {x: 0.61, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.66, y: 0.45}, endOffset: {x: 0.81, y: 0.46}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.81, y: 0.46}, endOffset: {x: 0.82, y: 0.68}});
				notes.drag(UIAQuery.query("UIInputSetHostView").atIndex(1), {startOffset: {x: 0.69, y: 0.43}, endOffset: {x: 0.69, y: 0.48}});
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'en_US@hw=US;sw=QWERTY':
				target.activeApp().typeString(testStrings[i]);
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'zh_Hant-Wubihua@sw=Wubihua-Traditional;hw=US':
				target.activeApp().typeKeystrokes(testStrings[i],null,false);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
		}
		
		UIALogger.logPass(">>>>>>>>>> Pass Test: " + languages[i] + ' ' + keyboardID);
	}
},
	
fwmemoryleak.memoryLeakScenario1Test4 = function memoryLeakScenario1Test4(args) {
	var languages= 	[	'Japanese',
						'Japanese', 	
						'English'];
						
	var types = 	[	'Kana', 
						'Romaji', 
						''];
						
	var keyboards = [	'ja_JP-Kana@sw=Kana;hw=US', 
						'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US', 
						'en_US@hw=US;sw=QWERTY'];
						
	var testStrings = [	'しゅうしょくひょうがきのきまつしけんがおわって、せいせいした',
						'shuushokuhyougakinokimatsushikenngaowatte、seiseishita',
						'Twin artists create haunting images of clash between culture and religion.'];
						
	for (var i = 0; i < languages.length; i++) {
		settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
	}

	/* create note */
	var options = UIAUtilities.defaults(args, {
		folder: 'Notes',
		leaveOpenForEditing: true,
	});
	notes.getToNewNote(args);


	UIALogger.logMessage('**************Ready to start typing ');
	/* switch to first keyboard*/	
	for (var i = 0; i < languages.length; i++) {
		var keyboardID = target.activeApp().getKeyboardID();
		UIALogger.logMessage('keyboardID ' + keyboardID);

		while (keyboards[i] != keyboardID) {
			target.activeApp().tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
			keyboardID = target.activeApp().getKeyboardID()
		 }

		switch (keyboards[i]) {
			case 'ja_JP-Kana@sw=Kana;hw=US':
				target.activeApp().typeKeystrokes(testStrings[i], null,false);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'ja_JP-Romaji@sw=QWERTY-Japanese;hw=US':
				target.activeApp().typeString(testStrings[i]);
				notes.tap(UIAQuery.collectionViews().children());
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
			case 'en_US@hw=US;sw=QWERTY':
				target.activeApp().typeString(testStrings[i]);
				key = UIAQuery.keyboard().andThen(UIAQuery.buttons('Return'));
				target.activeApp().tap(key);
				break;
				
		}
		
		UIALogger.logPass(">>>>>>>>>> Pass Test: " + languages[i] + ' ' + keyboardID);
	}
}
