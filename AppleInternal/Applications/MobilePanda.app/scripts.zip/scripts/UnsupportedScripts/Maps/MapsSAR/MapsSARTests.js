load('UIATesting.js');
load('MapsSAR.js');
load('UIAApp.js');
load('UIAUtility.js');


UIAUtilities.assert(
    typeof MapsSARTests === 'undefined',
    'MapsSARTests has already been defined.'
);


var MapsSARTests = {

    /**
     * Verifies that interaction with Map related elements in the Spotlight is handled correctly when user searches for Maps app
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     */
    spotlightSearchForMaps: function spotlightSearchForMaps(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
        });

        sar.removeApp(args.appName);

        sar.verifySpotlightSearchForMaps(args.appName);
    },


    /**
     * Verifies that interaction with Map related elements in the Spotlight is handled correctly when user searches for POI
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.searchTerm="The Home Depot"] - Search string to use in Spotlight
     */
    spotlightSearchForPoi: function spotlightSearchForPoi(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            searchTerm: 'The Home Depot',
        });

        sar.removeApp(args.appName);

        sar.verifySpotlightSearchForPOI(args.searchTerm);
    },


    /**
     * SPOTLIGHT - Verifies that user will be redirected to AppStore if he/she clicks on Show in App Store button in dialog
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.searchTerm="The Home Depot"] - Search string to use in Spotlight
     */
    spotlightRedirectsToAppStore: function spotlightRedirectsToAppStore(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            searchTerm: 'The Home Depot',
        });

        sar.removeApp(args.appName);

        sar.verifySpotlightRedirectsToAppStore(args.searchTerm);
    },


    /**
     * SAFARI - Verifies that user will be redirected to AppStore if he/she clicks on Show in App Store button in dialog
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.searchTerm="The Home Depot"] - Search string to use in Spotlight
     */
    safariRedirectsToAppStore: function safariRedirectsToAppStore(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            searchTerm: 'The Home Depot',
        });

        sar.removeApp(args.appName);

        sar.verifySafariRedirectsToAppStore(args.searchTerm);
    },


    /**
     * SIRI - Verifies that user will be redirected to AppStore if he/she clicks on Show in App Store button in dialog
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.siriCommand="Give me directions to Luu Noodle in Mountain View"] - Search string to use in Safari
     */
    siriRedirectsToAppStore: function siriRedirectsToAppStore(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            siriCommand: 'Give me directions to Luu Noodle in Mountain View',
        });

        sar.removeApp(args.appName);

        sar.verifySiriRedirectsToAppStore(args.siriCommand);
    },


    /**
     * Verifies that "Improve Maps" switch does not exists in Settings app at Privacy - Location Services - System Services
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     */
    improveMapsSwitch: function improveMapsSwitch(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
        });

        sar.removeApp(args.appName);

        sar.verifyImproveMapsSwitchNotExist();
    },


    /**
     * Verifies that Maps app does not exists in the list of installed apps in Settings app
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     */
    mapsAppInSettings: function mapsAppInSettings(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
        });

        sar.removeApp(args.appName);

        sar.verifyMapsNotExistInSettings();
    },


    /**
     * Verifies that interaction with Map related elements in Safari is handled correctly when user searches for POI
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.searchTerm="The Home Depot"] - Search string to use in Safari
     * @param {string} [args.address="United States"] - Part of the POI address to help locate address section
     */
    safariSearch: function safariSearch(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            searchTerm: 'The Home Depot',
            address: 'United States',
        });

        sar.removeApp(args.appName);

        sar.verifySafariSearch(args.searchTerm, args.address);
    },


    /**
     * Verifies that Siri request to get directions is handled correctly
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     * @param {string} [args.siriCommand="Give me directions to Luu Noodle in Mountain View"] - Search string to use in Safari
     */
    siriSearch: function siriSearch(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
            siriCommand: 'Give me directions to Luu Noodle in Mountain View',
        });

        sar.removeApp(args.appName);

        sar.verifySiriSearch(args.siriCommand);
    },


    /**
     * Verifies that no Maps related widgets are displayed
     *
     * @param {object} args - An args dictionary
     * @param {string} [args.appName="Maps"] - Name of the application to delete
     */
    widgetsNotDisplayed: function widgetsNotDisplayed(args) {
        args = UIAUtilities.defaults(args, {
            appName: 'Maps',
        });

        sar.removeApp(args.appName);

        sar.verifyNoMapsRelatedWidgetsAreDisplayed();
    },

};
