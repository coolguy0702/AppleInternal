load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('Safari.js');
load('Settings.js');
load('AppStore.js');


UIAUtilities.assert(
    typeof sar === 'undefined',
    'sar has already been defined.'
);


sar = {};


sar.Timeouts = {
    medium: 5,
    large: 10,
    xlarge: 20,
};


sar.Query = {
    ALERT_RESTORE_MAPS: UIAQuery.alerts('Restore “Maps”?'),
    ALERT_CANCEL_BUTTON: UIAQuery.alerts().andThen(UIAQuery.buttons('Cancel')),
    ALERT_SHOW_IN_APP_STORE_BUTTON: UIAQuery.alerts().andThen(UIAQuery.buttons('Show in App Store')),
    ALERT_DELETE_APP: UIAQuery.alerts().beginsWith('Delete'),
    ALERT_DELETE_BUTTON: UIAQuery.alerts().andThen(UIAQuery.buttons('Delete')),
    KEYBOARD_SEARCH_BUTTON: UIAQuery.keyboard().andThen(UIAQuery.buttons('Search')),
};


sar.Query.Spotlight = {
    MAPS_LABEL: UIAQuery.query('By Apple').siblings().andThen(UIAQuery.query('Maps')),
    BY_APPLE_LABEL: UIAQuery.query('Maps').siblings().andThen(UIAQuery.query('By Apple')),
    VIEW_BUTTON: UIAQuery.query('By Apple').siblings().andThen(UIAQuery.query('Maps').siblings().andThen(UIAQuery.withPredicate('name = "PurchaseButton" && label = "VIEW"'))),
    DIRECTIONS_BUTTON: UIAQuery.buttons('Directions'),
    SEARCH_IN_APP_BUTTON: UIAQuery.staticTexts('MAPS').siblings().andThen(UIAQuery.buttons('Search in App')),
};


sar.Query.Safari = {
    DIRECTIONS_BUTTON: UIAQuery.buttons('Directions'),
    DONE_BUTTON: UIAQuery.navigationBars('Maps').andThen(UIAQuery.buttons('Done')),
    ADDRESS_FIELD: UIAQuery.textFields('Address').isVisible().orElse(UIAQuery.textFields('URL').isVisible().orElse(UIAQuery.buttons('URL').isVisible())),
};


sar.Query.AppStoreExtPage = {
    CANCEL_BUTTON: UIAQuery.navigationBars('ProductPageExtension.ProductView').andThen(UIAQuery.buttons('Cancel')),
    MAPS_LABEL: UIAQuery.staticTexts('Apple').siblings().andThen(UIAQuery.staticTexts('Maps')),
    APPLE_LABEL: UIAQuery.staticTexts('Maps').siblings().andThen(UIAQuery.staticTexts('Apple')),
};


sar.Query.AppStorePage = {
    REDOWNLOAD_BUTTON: UIAQuery.buttons('Re-download'),
    MAPS_LABEL: UIAQuery.buttons('Re-download').siblings().andThen(UIAQuery.staticTexts('Maps')),
    APPLE_LABEL: UIAQuery.buttons('Re-download').siblings().andThen(UIAQuery.staticTexts('Apple')),
};


sar.Query.PlaceInfo = {
    CANCEL_BUTTON: UIAQuery.navigationBars('_MKPlaceView').andThen(UIAQuery.buttons('Cancel')),
    DIRECTIONS_BUTTON: UIAQuery.query('_MKStackView').andThen(UIAQuery.withPredicate('name contains[c] "Directions" AND behavior="Button"')),
    MAP_COMPONENT: UIAQuery.query('_MKStackView').andThen(UIAQuery.withPredicate('name contains[c] "Map containing" AND behavior="Button"')),
    ADDRESS: UIAQuery.query('MKPlaceSectionView').andThen(UIAQuery.beginsWith('Address')),
    REPORT_AN_ISSUE: UIAQuery.buttons('Report an Issue'),
    OPEN_IN_MAPS_LINK_WEB: UIAQuery.links('Open in Maps'), // This element has accessibility issue, visibility property is false, while it is visible on UI
    DIRECTIONS_LINK_WEB: UIAQuery.links().beginsWith('Directions'),
    ADDRESS_LINK_WEB: function(address) { return UIAQuery.links(address); },
};


sar.Query.Settings = {
    IMPROVE_MAPS_SWITCH: UIAQuery.switches('Improve Maps'),
    MAPS_APP_ITEM: UIAQuery.tableCells('Maps').andThen(UIAQuery.staticTexts('Maps')),
};


sar.Query.Widgets = {
    WIDGET_NAME_ON_TODAY_VIEW: function(widgetName) { return UIAQuery.query('WGWidgetPlatterView').andThen(UIAQuery.buttons(widgetName)) },
    WIDGET_NAME_ON_ADD_WIDGETS_VIEW: function(widgetName) { return UIAQuery.staticTexts('Add Widgets').parent().andThen(UIAQuery.tableCells(widgetName)) },
    EDIT_BUTTON: UIAQuery.query('WGWidgetListFooterView').andThen('Edit'),
};


sar.Predicates = {
    PRODUCT_PAGE_VIEW: 'controllerClass = "ProductPageExtension.ProductViewController"',
    PLACE_INFO_VIEW: 'controllerClass = "MKPlaceInfoViewController"',
    WIDGETS_ADD_VIEW: 'controllerClass = "WGWidgetListEditViewController"',
    APPSTORE_PRODUCT_VIEW: 'controllerClass = "AppStore.ProductViewController"',
    RESTORE_MAPS_ALERT: 'controllerTitle = "Restore “Maps”?"',
};


sar.Waiters = {
    RESTORE_MAPS_ALERT: 'Restore Maps Alert',
    APPSTORE_PRODUCT_VIEW: 'AppStore product view',
};


sar.removeApp = function removeApp(appName) {
    var iconQuery = UIAQuery.icons(appName);

    target.clickMenu();

    // Temporary solution, if there is no Maps icon on the first page then assume it was deleted.
    // Need to implement swiping between springboard pages to search for Maps app icon.
    if (!springboard.exists(iconQuery.isVisible())) {
        UIALogger.logMessage('Maps app icon was not found. Assuming Maps app was deleted');
        return;
    }

    springboard.tap(iconQuery, {duration: 3});

    // Have to use explicit delay due to:
    // <rdar://problem/31898796> Springboard icon’s (X) button has isVisible property set to false when it actually displayed on the screen
    target.delay(2);

    springboard.handlingAlertsInline(sar.Query.ALERT_DELETE_APP, function() {
        springboard.tap(iconQuery, {offset: {x: 0.05, y: 0.05}});
        springboard.tap(sar.Query.ALERT_DELETE_BUTTON);
    });

    target.clickMenu();
};


sar.searchInSpotlight = function searchInSpotlight(searchTerm) {
    target.clickMenu();
    target.delay(1); // Need explicit delay due to issue when swipe down gesture not recognized if any app was in the foreground
    springboard.search(searchTerm, {requiresEnterKey: false, enterTextOptions: {setValueToEnterText: true}});
    target.delay(2);
    UIALogger.logMessage("Tapping on Search button on keyboard");
    springboard.tap(sar.Query.KEYBOARD_SEARCH_BUTTON);
};


sar.getWaiter = function getWaiter(waiterType) {
    var waiter;

    switch (waiterType) {
        case sar.Waiters.RESTORE_MAPS_ALERT:
            waiter = UIAWaiter.withPredicate('ViewDidAppear', sar.Predicates.RESTORE_MAPS_ALERT);
            break;
        case sar.Waiters.APPSTORE_PRODUCT_VIEW:
            waiter = UIAWaiter.withPredicate('ViewDidAppear', sar.Predicates.APPSTORE_PRODUCT_VIEW);
            break;
        default:
            throw new UIAError('Unrecognized waiter requested: %0'.format(waiterType));
    }

    return waiter;
};


sar.issueSiriCommand = function issueSiriCommand(command) {
    UIALogger.logMessage('Issuing Siri command "%0"'.format(command));
    target.activeApp().withMaximumSnapshotBreadth(50, function() {
        target.activeApp().withMaximumSnapshotDepth(50, function() {
            target.setVoiceRecognitionStrings([command]);
            target.holdMenu(1.5);
        });
    });
};


sar.verifySpotlightSearchForMaps = function verifySpotlightSearchForMaps(searchTerm) {
    sar.searchInSpotlight(searchTerm);

    springboard.waitUntilPresent(sar.Query.Spotlight.MAPS_LABEL, sar.Timeouts.large);

    springboard.scrollToVisible(sar.Query.Spotlight.VIEW_BUTTON);

    UIAUtilities.assert(
        springboard.exists(sar.Query.Spotlight.MAPS_LABEL),
        'Maps icon did not appear in APP STORE section'
    );

    UIAUtilities.assert(
        springboard.exists(sar.Query.Spotlight.VIEW_BUTTON),
        'VIEW button not in APP STORE domain'
    );

    springboard.waitForViewToAppear(sar.Predicates.PRODUCT_PAGE_VIEW, function() {
        springboard.tap(sar.Query.Spotlight.MAPS_LABEL);
    });

    UIAUtilities.assert(
        springboard.waitUntilPresent(sar.Query.AppStoreExtPage.MAPS_LABEL, sar.Timeouts.large),
        'No Maps label displayed in ProductPageExtension view'
    );

    springboard.tap(sar.Query.AppStoreExtPage.CANCEL_BUTTON);

    springboard.waitForViewToAppear(sar.Predicates.PRODUCT_PAGE_VIEW, function() {
        springboard.tap(sar.Query.Spotlight.VIEW_BUTTON);
    });

    UIAUtilities.assert(
        springboard.waitUntilPresent(sar.Query.AppStoreExtPage.MAPS_LABEL, sar.Timeouts.large),
        'No Maps label displayed in ProductPageExtension view'
    );

    springboard.tap(sar.Query.AppStoreExtPage.CANCEL_BUTTON);
};


sar.verifyAppStoreProductPage = function verifyAppStoreProductPage() {
    UIAUtilities.assert(
        appstore.waitUntilPresent(sar.Query.AppStorePage.MAPS_LABEL, sar.Timeouts.large),
        'No Maps label displayed in AppStore Product View'
    );

    UIAUtilities.assert(
        appstore.waitUntilPresent(sar.Query.AppStorePage.APPLE_LABEL, sar.Timeouts.large),
        'No Apple label displayed in AppStore Product View'
    );

    UIAUtilities.assert(
        appstore.waitUntilPresent(sar.Query.AppStorePage.REDOWNLOAD_BUTTON, sar.Timeouts.large),
        'No Re-Download button displayed in AppStore Product View'
    );
};


sar.tapAndWaitForRestoreMapsAlert = function tapAndWaitForRestoreMapsAlert(args) {
    var elementQuery = args.elementToTap[0];
    var elementDescription = args.elementToTap[1];

    springboard.handlingAlertsInline(sar.Query.ALERT_RESTORE_MAPS, function() {
        var alertWaiter = sar.getWaiter(sar.Waiters.RESTORE_MAPS_ALERT);

        if (typeof args.tapOptions === 'object') {
            target.activeApp().tap(elementQuery, args.tapOptions);
        } else {
            target.activeApp().tap(elementQuery);
        }

        if (!alertWaiter.wait(sar.Timeouts.large)) {
            throw new UIAError('Tap on "%0" did not trigger Restore Maps alert to appear'.format(elementDescription));
        } else {
            UIALogger.logMessage('Received "Restore Maps" alert notification after tapping on "%0"'.format(elementDescription));
        }

        if (args.verifyShowInAppStoreButton) {
            var appStoreViewWaiter = sar.getWaiter(sar.Waiters.APPSTORE_PRODUCT_VIEW);

            springboard.tap(sar.Query.ALERT_SHOW_IN_APP_STORE_BUTTON);

            if (!appStoreViewWaiter.wait(sar.Timeouts.large)) {
                throw new UIAError('AppStore Product View did not show up after tapping on "Show in App Store" button');
            } else {
                UIALogger.logMessage('AppStore Product View showed up after tapping on "Show in App Store" button');
            }

            sar.verifyAppStoreProductPage();
        } else {
            springboard.tap(sar.Query.ALERT_CANCEL_BUTTON);
        }
    });
};


sar.verifySpotlightSearchForPOI = function verifySpotlightSearchForPOI(searchTerm) {
    sar.searchInSpotlight(searchTerm);

    springboard.waitUntilPresent(sar.Query.Spotlight.DIRECTIONS_BUTTON, sar.Timeouts.large);

    springboard.scrollToVisible(sar.Query.Spotlight.DIRECTIONS_BUTTON);

    sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.Spotlight.SEARCH_IN_APP_BUTTON, 'Search in App button']});
    sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.Spotlight.DIRECTIONS_BUTTON, 'Directions button']});

    springboard.scrollToVisible(sar.Query.Spotlight.DIRECTIONS_BUTTON);

    springboard.waitForViewToAppear(sar.Predicates.PLACE_INFO_VIEW, function() {
        springboard.tap(sar.Query.Spotlight.DIRECTIONS_BUTTON.parent());
    });

    elements = [[sar.Query.PlaceInfo.DIRECTIONS_BUTTON, 'Directions button'],
                [sar.Query.PlaceInfo.MAP_COMPONENT, 'Map Component'],
                [sar.Query.PlaceInfo.REPORT_AN_ISSUE, 'Report an Issue button'],
                [sar.Query.PlaceInfo.ADDRESS, 'Address section']];

    for (var i = 0; i < elements.length; i += 1) {
        sar.tapAndWaitForRestoreMapsAlert({elementToTap: elements[i]});
    }

    springboard.tap(sar.Query.PlaceInfo.CANCEL_BUTTON.isVisible());
};


sar.verifySpotlightRedirectsToAppStore = function verifySpotlightRedirectsToAppStore(searchTerm) {
    sar.searchInSpotlight(searchTerm);

    springboard.waitUntilPresent(sar.Query.Spotlight.DIRECTIONS_BUTTON, sar.Timeouts.large);

    springboard.scrollToVisible(sar.Query.Spotlight.DIRECTIONS_BUTTON);

    sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.Spotlight.SEARCH_IN_APP_BUTTON, 'Search in App button'], verifyShowInAppStoreButton: true});
};


sar.verifySafariRedirectsToAppStore = function verifySafariRedirectsToAppStore(searchTerm) {
    var mapsSearchResultQuery = safari.determineSearchResultQuery({searchCategory: 'Maps', resultIndex: 0});

    safari.launch();
    safari.enterText(sar.Query.Safari.ADDRESS_FIELD, searchTerm, {setValueToEnterText: true});

    UIAUtilities.assert(
        safari.waitUntilPresent(mapsSearchResultQuery, sar.Timeouts.large),
        'Search yielded no results in Maps section'
    );

    target.delay(2);

    sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.Safari.DIRECTIONS_BUTTON, 'Directions button'], verifyShowInAppStoreButton: true});
};


sar.verifySiriRedirectsToAppStore = function verifySiriRedirectsToAppStore(siriCommand) {
    target.clickMenu();

    springboard.handlingAlertsInline(sar.Query.ALERT_RESTORE_MAPS, function() {
        var alertWaiter = sar.getWaiter(sar.Waiters.RESTORE_MAPS_ALERT);

        sar.issueSiriCommand(siriCommand);

        if (!alertWaiter.wait(sar.Timeouts.large)) {
            throw new UIAError('Issuing Siri command "%0" did not trigger Restore Maps alert to appear'.format(siriCommand));
        } else {
            UIALogger.logMessage('Received "Restore Maps" alert notification after issuing Siri command "%0"'.format(siriCommand));
        }

        var appStoreViewWaiter = sar.getWaiter(sar.Waiters.APPSTORE_PRODUCT_VIEW);

        springboard.tap(sar.Query.ALERT_SHOW_IN_APP_STORE_BUTTON);

        if (!appStoreViewWaiter.wait(sar.Timeouts.large)) {
            throw new UIAError('AppStore Product View did not show up after tapping on "Show in App Store" button');
        } else {
            UIALogger.logMessage('AppStore Product View showed up after tapping on "Show in App Store" button');
        }

        sar.verifyAppStoreProductPage();
    });

    target.clickMenu();
};


sar.verifySafariSearch = function verifySafariSearch(searchTerm, address) {
    var mapsSearchResultQuery = safari.determineSearchResultQuery({searchCategory: 'Maps', resultIndex: 0});

    safari.launch();
    safari.enterText(sar.Query.Safari.ADDRESS_FIELD, searchTerm, {setValueToEnterText: true});

    UIAUtilities.assert(
        safari.waitUntilPresent(mapsSearchResultQuery, sar.Timeouts.large),
        'Search yielded no results in Maps section'
    );

    target.delay(2);

    safari.waitUntilPresent(sar.Query.Safari.DIRECTIONS_BUTTON, sar.Timeouts.medium);

    sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.Safari.DIRECTIONS_BUTTON, 'Directions button']});

    if (target.model() === 'iPad') {
        springboard.waitForWebPageLoaded(sar.Timeouts.xlarge, function() {
            safari.tap(sar.Query.Safari.DIRECTIONS_BUTTON.parent());
        });

        sar.tapAndWaitForRestoreMapsAlert({elementToTap: [UIAQuery.query("banner"), 'Open in Maps link'], tapOptions: {offset: {x: 0.92, y: 0.50}}});
        sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.PlaceInfo.DIRECTIONS_LINK_WEB, 'Directions link']});
        sar.tapAndWaitForRestoreMapsAlert({elementToTap: [sar.Query.PlaceInfo.ADDRESS_LINK_WEB(address), 'Address section']});

    } else {
        safari.waitForViewToAppear(sar.Predicates.PLACE_INFO_VIEW, function() {
            safari.tap(sar.Query.Safari.DIRECTIONS_BUTTON.parent());
        });

        var elements = [[sar.Query.PlaceInfo.DIRECTIONS_BUTTON, 'Directions button'],
                        [sar.Query.PlaceInfo.MAP_COMPONENT, 'Map Component'],
                        [sar.Query.PlaceInfo.REPORT_AN_ISSUE, 'Report an Issue button'],
                        [sar.Query.PlaceInfo.ADDRESS, 'Address section']];

        for (var i = 0; i < elements.length; i += 1) {
            sar.tapAndWaitForRestoreMapsAlert({elementToTap: elements[i]});
        }

        safari.tap(sar.Query.Safari.DONE_BUTTON.isVisible());
    }
};


sar.verifyImproveMapsSwitchNotExist = function verifyImproveMapsSwitchNotExist() {
    settings.navigateNavigationViews(['Privacy', 'Location Services', 'System Services']);

    UIAUtilities.assert(
        !settings.waitUntilPresent(sar.Query.Settings.IMPROVE_MAPS_SWITCH, sar.Timeouts.large),
        'Improve Maps switch exists on System Services view'
    );
};


sar.verifyMapsNotExistInSettings = function verifyMapsNotExistInSettings() {
    settings.launch();
    settings.returnToTopLevel();

    settings.scrollToVisibleIfExists(sar.Query.Settings.MAPS_APP_ITEM);

    UIAUtilities.assert(
        !settings.exists(sar.Query.Settings.MAPS_APP_ITEM),
        'Maps app displayed in the list of apps on the Settings view'
    );
};


sar.verifySiriSearch = function verifySiriSearch(siriCommand) {
    target.clickMenu();

    springboard.handlingAlertsInline(sar.Query.ALERT_RESTORE_MAPS, function() {
        var alertWaiter = sar.getWaiter(sar.Waiters.RESTORE_MAPS_ALERT);

        sar.issueSiriCommand(siriCommand);

        if (!alertWaiter.wait(sar.Timeouts.large)) {
            throw new UIAError('Issuing Siri command "%0" did not trigger Restore Maps alert to appear'.format(siriCommand));
        } else {
            UIALogger.logMessage('Received "Restore Maps" alert notification after issuing Siri command "%0"'.format(siriCommand));
        }

        springboard.tap(sar.Query.ALERT_CANCEL_BUTTON);
    });

    target.clickMenu();
};


sar.verifyNoMapsRelatedWidgetsAreDisplayed = function verifyNoMapsRelatedWidgetsAreDisplayed() {
    var widgets = ['Maps Transit',
                   'Maps Nearby',
                   'Maps Destinations'];
    var mapWidgetsDisplayed = [];
    var mapWidgetsDisplayedOnAddWidgetsView = [];
    var errorMsg = 'Maps Widgets were found!';

    springboard.getToWidgets();

    for (var i = 0; i < widgets.length; i += 1) {
        if (springboard.exists(sar.Query.Widgets.WIDGET_NAME_ON_TODAY_VIEW(widgets[i].toUpperCase()))) {
            UIALogger.logMessage('Found Map widget on Today view: "%0"'.format(widgets[i]));
            mapWidgetsDisplayed.push(widgets[i]);
        }
    }

    springboard.waitForViewToAppear(sar.Predicates.WIDGETS_ADD_VIEW, function() {
        springboard.tap(sar.Query.Widgets.EDIT_BUTTON);
    });

    for (var i = 0; i < widgets.length; i += 1) {
        if (springboard.exists(sar.Query.Widgets.WIDGET_NAME_ON_ADD_WIDGETS_VIEW(widgets[i]))) {
            UIALogger.logMessage('Found Map widget on Add Widgets view: "%0"'.format(widgets[i]));
            mapWidgetsDisplayedOnAddWidgetsView.push(widgets[i]);
        }
    }

    springboard.tap(UIAQuery.CANCEL_BUTTON.isVisible());

    if (mapWidgetsDisplayed.length !== 0) {
        errorMsg += '\nFollowing Maps app widgets are still displayed on Today view:\n\t\t"%0"'.format(mapWidgetsDisplayed.join('", "'));
    }

    if (mapWidgetsDisplayedOnAddWidgetsView.length !== 0) {
        errorMsg += '\nFollowing Maps app widgets are still displayed on Add Widgets view:\n\t\t"%0"'.format(mapWidgetsDisplayedOnAddWidgetsView.join('", "'));
    }

    UIAUtilities.assert(
        mapWidgetsDisplayed.length === 0 && mapWidgetsDisplayedOnAddWidgetsView.length === 0,
        errorMsg
    );
};


