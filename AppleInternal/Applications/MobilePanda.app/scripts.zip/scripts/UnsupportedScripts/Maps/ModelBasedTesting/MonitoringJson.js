load('UIAApp.js');

/**
 @namespace
 @augments UIAApp
 */
var maps = target.appWithBundleID('com.apple.Maps');

// Telemetry configuration
maps.TELEMETRY = {};
maps.TELEMETRY.Enabled = false;
maps.TELEMETRY.ESURL = 'http://rd12d00ls-wahba-elasticsearch.geo.apple.com:80';
maps.TELEMETRY.Index = 'maps-performance';
maps.TELEMETRY.DocumentType = 'maps-test-result';
maps.TELEMETRY.JSONDir = '/tmp/MapsTelemetry/';
maps.TELEMETRY.JSONFile = 'ELK.json';
maps.TELEMETRY.CachePath = '/var/mobile/Library/Caches/GeoServices/';
maps.TELEMETRY.AppPath = '/Applications/Maps.app/Maps';
maps.TELEMETRY.SinceName = 'since time:';
maps.TELEMETRY.WiFiName = 'wifiIN/wifiOUT';
maps.TELEMETRY.CellName = 'cellIN/cellOUT';
maps.TELEMETRY.AwdlName = 'awdlIN/awdlOUT';
maps.TELEMETRY.RnfName = 'rnfIN/rnfOUT';
maps.TELEMETRY.Iterations = {};
maps.TELEMETRY.TestID = null;
maps.TELEMETRY.TestName = null;
maps.TELEMETRY.document = null;

/**
 * Initialize json Telemetry file with test run info
 *
 * @param {object} UIATest object (this pointer in MapsTests.js function)
 * @param {array} args test arguments. must contain enablePerfLogging (true) to enable telemetry
 * @param {string} unique identifier for test run
 */
maps.initializeTelemetry = function initializeTelemetry(uiaTest, testOptions, testID) {
    if (testOptions.enablePerfLogging) {
        this.TELEMETRY.Enabled = true;
    } else {
        this.TELEMETRY.Enabled = false;
        return;
    }

    UIALogger.logMessage('creating JSON telemetry file');
    this.TELEMETRY.document = {
        TestName: uiaTest.name,
        Description: uiaTest.desc,
        StartTime: uiaTest.startTime,
        CurrentRun: uiaTest.currentRun,
        NumberOfRuns: uiaTest.numberOfRuns,
        TestParams: testOptions,
        ESURL: this.TELEMETRY.ESURL,
        TargetIndex: this.TELEMETRY.Index,
        DocumentType: this.TELEMETRY.DocumentType,
        DeviceModel: target.mobileGestaltQuery('HWModelStr'),
        DeviceBuild: target.mobileGestaltQuery('BuildVersion'),
        DeviceUDID: target.mobileGestaltQuery('UniqueDeviceID'),
        NetworkCondition: (target.mobileGestaltQuery('wapi')) ? 'WLAN' : 'Wi-Fi',
    };

    if (testID === null) {
        testID = this.TELEMETRY.guid();
    }
    this.TELEMETRY.document.TestID = testID;

    performTask('/bin/mkdir', ['-p', this.TELEMETRY.JSONDir]);

    performTask('/usr/local/bin/netusage', ['--reset-entry', '-n', 'com.apple.Maps']);
};

/**
 * public function to save perf data (memory, network, and file cache usage)
 *
 * @param {string} tag prefix for usage values to indicate point in the test readings are taken
 * @param {options} optional flags to get CPU, Memory, Cache and/or Network
 */
maps.logMBT = function logMBT(tag, options) {
    if (this.TELEMETRY.Enabled === false) {
        return;
    }

    UIALogger.logMessage('logging for MBT');
    options = UIAUtilities.defaults(options, {
        getCPU: true,
        getMemory: true,
        getNetwork: true,
    });

    this.TELEMETRY.document.DocumentType = tag;

    if (!this.TELEMETRY.Iterations.hasOwnProperty(tag)) {
        this.TELEMETRY.Iterations[tag] = 0;
    }

    this.TELEMETRY.document.Iteration = ++this.TELEMETRY.Iterations[tag];

    if (options.getNetwork) {
        this.TELEMETRY.document.NetworkUsage = this.TELEMETRY.getNetworkUsage(tag);
    }

    var psData = this.TELEMETRY.getPsData(tag, options);
    if (options.getMemory) {
        this.TELEMETRY.document.MemoryUsage = psData.memoryUsage;
    }
    if (options.getCPU) {
        this.TELEMETRY.document.CpuUsage = psData.cpuUsage;
    }

    var jsonTestData = new UIAFile('%0ELK%1.json'.format(this.TELEMETRY.JSONDir, this.TELEMETRY.guid()));
    jsonTestData.open('w', 'unicode');
    jsonTestData.write(JSON.stringify(this.TELEMETRY.document));
    jsonTestData.close();
};

/**
 * public function to save network, and file cache usage
 *
 * @param {string} tag prefix for usage values to indicate point in the test readings are taken
 */
maps.logNetwork = function logNetwork(tag) {
    if (this.TELEMETRY.Enabled === false) {
        return;
    }

    UIALogger.logMessage('logging network usage');

    this.TELEMETRY.document.TargetIndex = 'maps-network-usage';
    this.TELEMETRY.document['%0.NetworkUsage'.format(tag)] = this.TELEMETRY.getNetworkUsage(tag);
    var fileUsage = this.TELEMETRY.getFileSizes(this.TELEMETRY.CachePath);

    this.TELEMETRY.document['%0.Files'.format(tag)] = fileUsage.DirectoryFiles;
    for (var idx in fileUsage.Directories) {
        var fields = fileUsage.Directories[idx];
        var key = '%0%1'.format(tag, fields[0]);
        this.TELEMETRY.document[key] = fields[1];
    }

    var jsonTestData = new UIAFile('%0%1'.format(this.TELEMETRY.JSONDir, this.TELEMETRY.JSONFile));
    jsonTestData.open('w', 'unicode');
    jsonTestData.write(JSON.stringify(this.TELEMETRY.document));
    jsonTestData.close();
};

/**
 * get complete list of file sizes given a path, and list of directory sizes one level down from input path
 *
 * @param {string} tag prefix for usage values to indicate point in the test readings are taken
 * @param {string} path root directory to generate file size list
 */
maps.TELEMETRY.getFileSizes = function getFileSizes(path) {
    if (this.TELEMETRY.Enabled === false) {
        return;
    }

    if (!UIAFile.fileExists(path)) {
        UIALogger.logError('Invalid path argument to reportFileSizes %0'.format(path));
        return;
    }

    UIALogger.logMessage('adding file size data to JSON');

    var findString = '/usr/bin/find %0 -type f -exec /usr/bin/stat -f \'%z\t%N\t%Sm\' {} +'.format(path);
    var fileList = performTask('/bin/bash', ['-c', findString]);
    var directoryList = performTask('/usr/bin/du', ['-d', 1, path]);
    var directorySize = performTask('/usr/bin/du', ['-s', path]);

    var directoryFileList = {
        RootDirectory: path,
        CaptureTime: new Date(),
        DirectorySize: parseInt(directorySize.stdout.split('\t')[0]),
        Files: [],
    };

    records = fileList.stdout.split('\n');
    var fields = null;
    for (record = 0; record < records.length - 1; record++) { // the last line of fileList.stdout is blank
        fields = records[record].split('\t');
        var fileData = {
            FileName: fields[1],
            Size: parseInt(fields[0]),
            LastModified: fields[2],
        };
        directoryFileList.Files.push(fileData);
    }

    var directoryData = {
        DirectoryFiles: directoryFileList,
        Directories: [],
    };

    records = directoryList.stdout.split('\n');
    for (record = 0; record < records.length - 1; record++) { // the last line of directoryList.stdout is blank
        fields = records[record].split('\t');
        fieldName = fields[1].replace(path, '.');
        directoryData.Directories.push([fieldName, parseInt(fields[0])]);
    }

    return directoryData;
};

/**
 * get current network usage by Maps app
 *
 * @param {string} tag prefix for usage values to indicate point in the test readings are taken
 */
maps.TELEMETRY.getNetworkUsage = function getNetworkUsage(tag) {
    if (this.Enabled === false) {
        return;
    }

    UIALogger.logMessage('adding Maps network usage to JSON');

    var networkUsage = {
        CaptureTime: new Date(),
    };

    // $ netusage --all-traffic -n com.apple.Maps
    var netUsageCmd = performTask('/usr/local/bin/netusage', ['--all-traffic', '-n', 'com.apple.Maps']);
    if (netUsageCmd.stdout.split('\n').length > 1) {
        var header = netUsageCmd.stdout.split('\n')[0].split(/[ ]{2,}/);
        var dataRow = netUsageCmd.stdout.split('\n')[1].split(/[ ]{2,}/);

        var column = -1;

        if ((column = header.indexOf(this.SinceName)) !== -1) {
            networkUsage.SinceTime = dataRow[column];
        }

        if ((column = header.indexOf(this.WiFiName)) !== -1) {
            networkUsage.WifiIn = parseInt(dataRow[column].split('/')[0]);
            networkUsage.WifiOut = parseInt(dataRow[column].split('/')[1]);
        }

        if ((column = header.indexOf(this.CellName)) !== -1) {
            networkUsage.CellIn = parseInt(dataRow[column].split('/')[0]);
            networkUsage.CellOut = parseInt(dataRow[column].split('/')[1]);
        }

        if ((column = header.indexOf(this.AwdlName)) !== -1) {
            networkUsage.AwdlIn = parseInt(dataRow[column].split('/')[0]);
            networkUsage.AwdlOut = parseInt(dataRow[column].split('/')[1]);
        }

        if ((column = header.indexOf(this.RnfName)) !== -1) {
            networkUsage.RnfIn = parseInt(dataRow[column].split('/')[0]);
            networkUsage.RnfOut = parseInt(dataRow[column].split('/')[1]);
        }
    }

    return networkUsage;
};

/**
 * get current memory and/or CPU usage by Maps app
 *
 * @param {string} tag prefix for usage values to indicate point in the test readings are taken
 */
maps.TELEMETRY.getPsData = function getPsData(tag, options) {
    if (this.Enabled === false) {
        return;
    }
    UIALogger.logMessage('adding Maps memory/CPU usage to JSON');

    var psData = {};
    var memoryUsage = {
        CaptureTime: new Date(),
        VirtualSize: 0,
    };

    var cpuUsage = {
        CaptureTime: new Date(),
        CPUTime: 0,
    };

    var psCmd = performTask('/bin/ps', ['-avx']);
    var records = psCmd.stdout.split('\n');
    for (var index in records) {
        var fields = records[index].trim().split(/[ ]+/);
        if (fields.indexOf(this.AppPath) !== -1) {
            if (options.getMemory) {
                memoryUsage.VirtualSize = parseInt(fields[6]);
                psData.memoryUsage = memoryUsage;
            }
            if (options.getCPU) {
                cpuUsage.CPUTime = fields[2];
                psData.cpuUsage = cpuUsage;
            }
        }
    }
    return psData;
};

/**
 * Create a GUID string (this function should probably be moved to Common)
 */
maps.TELEMETRY.guid = function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return '%0%1-%2-%3-%4-%5-%6%7%8'.format(s4(), s4(), s4(), s4(), s4(), s4(), s4(), s4(), s4());
};
