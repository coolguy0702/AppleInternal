App/Project/Feature: |Elastic Search logging
-|
Maintainer(s): |Ijaz Sarwar, Chris Paulse
Maintainer(s) Email: |isarwar@apple.com, cpaulse@apple.com
Maintainer(s) Team: |Maps Client Testing
Maintainer(s) Team Manager: | Wali Sultani
Maintainer(s) Team Manager Email: |asultani@apple.com

Description
-----------
Scripts for monitoring/performance logging used in Maps Client model based testing.

Usage
-----

#### Public API:

```javascript
maps.initializeTelemetry(uiaTest, testOptions, testID); // call at the start of a UIA2 test
```
Model based testing logs one file per call to:
```javascript
maps.logMBT('Checkpoint name', options);
```
The json file will contain Maps client's current memory consumption, CPU and network usage.

To record network usage and cache file sizes (independently of model based testing), use:
```javascript
maps.logNetwork('Checkpoint name');
```
