App/Project/Feature: Maps Performance
Maintainer(s): Ijaz Sarwar, Avram Wahba
Maintainer(s) Email: isarwar@apple.com, awahba@apple.com
Maintainer(s) Team: Maps Eval
Maintainer(s) Team Manger: George Andraws
Maintainer(s) Team Manger Email: gandraws@apple.com

Scripts include performance tests for Maps. We are experimenting if we can get accurate performance information with UIA2 tests. We would be uploading that performance data to elastic search for analysis.