load('UIAApp.js');
load('UIAApp+Maps.js');
load('UIAApp+Mail.js');
load('UIAApp+Message.js');
load('UIAApp+AddressBook.js');
load('UIANavigation.js');
load('Safari.js');
load('SpringBoard.js');

if (typeof maps === 'undefined') {

    /**
     @namespace
     @augments UIAApp
     */
    var maps = target.appWithBundleID('com.apple.Maps');

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Maps Localized String Constants                                     */
    /*                                                                             */
    /*      A dictionary of localization look up strings                           */
    /*      To abstract the localized string constants for Maps                    */
    /*                                                                             */
    /*******************************************************************************/

    LocStrings.Maps = {
        /** Alternate route */
        ALTERNATE_ROUTE: maps.localizedString(
                            'ALTERNATE_ROUTE_LABEL',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** Arrived */
        ARRIVED:        maps.localizedString('GuidanceSign_Arrived'),

        /** Broswer item back */
        BACK:           maps.localizedString(
                            'BROWSE_ITEM_BACK',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** BEST MATCHES */
        BEST_MATCHES:  maps.localizedString('Best Matches'),

        /** Drop a Pin */
        DROP_A_PIN:     maps.localizedString('Drop a Pin'),

        /** Edit Favorite */
        EDIT_FAVORITE:  maps.localizedString('Edit Favorite'),

        /** End */
        END:            maps.localizedString('OverviewBar_End'),

        /** End location */
        END_LOCATION:   maps.localizedString(
                            'END_LOCATION',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** Hide List */
        HIDE_LIST:      maps.localizedString('Hide List'),

        /** Hide Traffic */
        HIDE_TRAFFIC:   maps.localizedString('Hide Traffic'),

        /** List Steps */
        LIST_STEPS:     maps.localizedString(
                            'LIST_BUTTON',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** Map */
        MAP:            maps.localizedString('Map'),

        /** Overview */
        OVERVIEW:       maps.localizedString('OverviewBar_Overview'),

        /** RAP Privacy */
        RAP_PRIVACY_AGREE:      maps.localizedString('Agree [Report an Issue]'),

        /** Recents */
        RECENTS:        maps.localizedString('Recents'),

        /** Report an Issue */
        REPORT_AN_ISSUE: maps.localizedString('Report an Issue'),

        /** Resume */
        RESUME:         maps.localizedString('DirectionsInfoBar_Resume'),

        /** Route */
        ROUTE:          maps.localizedString('Route'),

        /** Drive with route selected */
        ROUTE_DRIVE:    maps.localizedString('Drive [Route picking selection]'),

        /** Transit with route selected */
        ROUTE_TRANSIT:  maps.localizedString(
                            'Transit [Route picking selection]',
                            {tableName:'Caboose'}
                        ),

        /** Walk with route selected */
        ROUTE_WALK:     maps.localizedString('Walk [Route picking selection]'),

        /** Safety Warning alert text */
        SAFETY_WARNING: maps.localizedString('Safety Warning'),

        /** Satellite */
        SATELLITE:      maps.localizedString('Satellite'),

        /** Search Results Not Available */
        SEARCH_RESULTS_NOT_AVAILABLE: maps.localizedString('Search Results Not Available'),

        /** Share */
        SHARE:          maps.localizedString(
                            'SHARE_BUTTON',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** Show List */
        SHOW_LIST:      maps.localizedString('Show List'),

        /** Show Traffic */
        SHOW_TRAFFIC:   maps.localizedString('Show Traffic'),

        /** Start */
        START:          maps.localizedString('Start'),

        /** Start location */
        START_LOCATION: maps.localizedString(
                            'START_LOCATION',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** Swap Directions */
        SWAP_DIRECTIONS: maps.localizedString(
                            'SWAP_DIRECTIONS',
                            {tableName:'Accessibility-Maps'}
                        ),

        /** 3D Map*/
        THREE_D_MAP:    maps.localizedString('3D Map'),

        /** Transit */
        TRANSIT:        maps.localizedString(
                            'Transit',
                            {tableName:'Caboose'}
                        ),

        /** 2D Map */
        TWO_D_MAP:      maps.localizedString('2D Map'),
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for common maps queries */
    UIAQuery.Maps = {

        /* General queries for maps */
        CANCEL_BUTTON:  UIAQuery.buttons(LocStrings.CANCEL).isVisible(),
        CLEAR_BUTTON:   UIAQuery.buttons(LocStrings.CLEAR),
        DONE_BUTTON:    UIAQuery.buttons(LocStrings.DONE).isVisible(),
        BACK_BUTTON:    UIAQuery.buttons(LocStrings.Maps.BACK).leftmost(),
        STATUS_BAR:     UIAQuery.statusBars().first(),
        MAPS_NAV_BAR:   UIAQuery.navigationBars(maps.name()),
        DROPPED_PIN:    UIAQuery.query('MKMapView').andThen(UIAQuery.beginsWith(LocStrings.DROPPED_PIN)),
        POI_ELEMENTS:   UIAQuery.query('VKMapView').first().children(),

        /* Queries for items commonly on the map view */
        SEARCH_BAR:             UIAQuery.searchBars().topmost(),
        SEARCH_BAR_CLEAR_BUTTON: UIAQuery.searchBars().andThen(UIAQuery.buttons(LocStrings.CLEAR_TEXT)),
        SEARCH_SUGGESTIONS:     UIAQuery.staticTexts(LocStrings.FAVORITES).orElse(UIAQuery.staticTexts().withPredicate('name matches[c] "%0"'.format(LocStrings.Maps.BEST_MATCHES))),
        FAVORITES_LIST_BUTTON:  UIAQuery.staticTexts(LocStrings.FAVORITES),
        DIRECTIONS_BUTTON:      UIAQuery.buttons(LocStrings.DIRECTIONS).topmost(),
        SHARE_BUTTON:           UIAQuery.withPredicate('ANY identifiers == "' + LocStrings.Maps.SHARE + '" || ANY identifiers == "MapsShareButton"').topmost(),
        MAIL_COMPOSE_VIEW:      UIAQuery.query('MFMailComposeView'),
        DELETE_DRAFT_BUTTON:    UIAQuery.buttons(LocStrings.DELETE_DRAFT),
        TRACKING_BUTTON:        UIAQuery.buttons(LocStrings.TRACKING).bottommost(),
        SETTINGS_BUTTON:        UIAQuery.buttons('Settings').bottommost(),
        COMPASS_BUTTON:         UIAQuery.buttons(LocStrings.COMPASS).topmost(),
        SEARCH_BUTTON:          UIAQuery.buttons(LocStrings.SEARCH).bottommost(),
        POPOVER_DISMISS:        UIAQuery.query('PopoverDismissRegion'),
        CALLOUT:                UIAQuery.query('MKSmallCalloutView'),
        QUICK_ROUTE_BUTTON:     UIAQuery.buttons('DirectionsButton'),
        SHARE_SHEET:            UIAQuery.query('ActivityListView'),
        PLACECARD_NAV_BAR:      UIAQuery.navigationBars('_MKPlaceView'),
        DEBUG_NAV_BAR:          UIAQuery.navigationBars('Debug Settings').isVisible(),
        SHOW_LIST_BUTTON:       UIAQuery.buttons(LocStrings.Maps.SHOW_LIST).bottommost(),
        HIDE_LIST_BUTTON:       UIAQuery.buttons(LocStrings.Maps.HIDE_LIST).bottommost(),

        /* Queries for items commonly on the navigation view */
        ROUTE_MODE_SELECTOR:        UIAQuery.query('RoutePickingModeSelector'),
        ROUTE_MODE_DRIVE_BUTTON:    UIAQuery.query('RoutePickingModeSelector').andThen(LocStrings.Maps.ROUTE_DRIVE),
        ROUTE_MODE_WALK_BUTTON:     UIAQuery.query('RoutePickingModeSelector').andThen(LocStrings.Maps.ROUTE_WALK),
        ROUTE_MODE_TRANSIT_BUTTON:  UIAQuery.query('RoutePickingModeSelector').andThen(LocStrings.Maps.ROUTE_TRANSIT),
        ROUTE_FROM_TO_PINS:     UIAQuery.query('MKNewAnnotationContainerView'),
        END_BUTTON:             UIAQuery.buttons(LocStrings.Maps.END).topmost(),
        OVERVIEW_BUTTON:        UIAQuery.buttons(LocStrings.Maps.OVERVIEW).topmost(),
        RESUME_BUTTON:          UIAQuery.buttons(LocStrings.Maps.RESUME).topmost(),
        LIST_STEPS_BUTTON:      UIAQuery.buttons(LocStrings.Maps.LIST_STEPS).bottommost(),
        START_BUTTON:           UIAQuery.buttons(LocStrings.Maps.START).bottommost(),
        LIVE_NAVIGATION_SIGN:   UIAQuery.query('MNGuidanceSignContainerView').orElse(UIAQuery.query("SteppingSignsCarousel")),
        ARRIVED_MARKER:         UIAQuery.staticTexts(LocStrings.Maps.ARRIVED),
        STEPPING_TITLE_BAR:     UIAQuery.query('SteppingTopBarTitleView'),
        STEPPING_SIGN:          UIAQuery.withPredicate("ANY children.name == 'UIPageControl'").andThen(UIAQuery.collectionViews().first()),
        ALTERNATE_ROUTE:        UIAQuery.query('MKMapView').andThen(UIAQuery.beginsWith(LocStrings.Maps.ALTERNATE_ROUTE)),

        /* Queries for items on the settings view */
        DROP_A_PIN_BUTTON:          UIAQuery.query(LocStrings.Maps.DROP_A_PIN),
        REPORT_AN_ISSUE_BUTTON:     UIAQuery.query(LocStrings.Maps.REPORT_AN_ISSUE),
        SHOW_TRAFFIC_BUTTON:        UIAQuery.query(LocStrings.Maps.SHOW_TRAFFIC),
        HIDE_TRAFFIC_BUTTON:        UIAQuery.query(LocStrings.Maps.HIDE_TRAFFIC),
        MAP_3D_BUTTON:              UIAQuery.query(LocStrings.Maps.THREE_D_MAP),
        MAP_2D_BUTTON:              UIAQuery.query(LocStrings.Maps.TWO_D_MAP),
        MODE_SELECTOR:              UIAQuery.query('MapViewModeSelector'),
        MODE_MAP_BUTTON:            UIAQuery.query('MapViewModeSelector').andThen(LocStrings.Maps.MAP),
        MODE_TRANSIT_BUTTON:        UIAQuery.query('MapViewModeSelector').andThen(LocStrings.Maps.TRANSIT),
        MODE_SATELLITE_BUTTON:      UIAQuery.query('MapViewModeSelector').andThen(LocStrings.Maps.SATELLITE),

        /* Queries for items on the new directions view */
        SWAP_DIRECTIONS_BUTTON:     UIAQuery.buttons(LocStrings.Maps.SWAP_DIRECTIONS).leftmost(),
        ROUTE_BUTTON:               UIAQuery.buttons(LocStrings.Maps.ROUTE).rightmost(),
        DIRECTIONS_NAV_BAR:         UIAQuery.navigationBars(LocStrings.DIRECTIONS),
        START_LOCATION_TEXTFIELD:   UIAQuery.textFields().beginsWith(LocStrings.Maps.START_LOCATION),
        END_LOCATION_TEXTFIELD:     UIAQuery.textFields().beginsWith(LocStrings.Maps.END_LOCATION),

        /* Queries for items on the favorites/recents/contacts views */
        FAVORITES_TOOLBAR_BUTTON:   UIAQuery.segmentedControls().andThen(UIAQuery.buttons(LocStrings.FAVORITES)),
        FAVORITES_NAV_BAR:          UIAQuery.navigationBars(LocStrings.FAVORITES),
        EDIT_FAVORITE_NAV_BAR:      UIAQuery.navigationBars(LocStrings.Maps.EDIT_FAVORITE),
        RECENTS_TOOLBAR_BUTTON:     UIAQuery.segmentedControls().andThen(UIAQuery.buttons(LocStrings.Maps.RECENTS)),
        RECENTS_NAV_BAR:            UIAQuery.navigationBars(LocStrings.Maps.RECENTS),
        CONTACTS_TOOLBAR_BUTTON:    UIAQuery.segmentedControls().andThen(UIAQuery.buttons(LocStrings.CONTACTS)),
        CONTACTS_NAV_BAR:           UIAQuery.navigationBars(LocStrings.ALL_CONTACTS),
        GROUPS_BUTTON:              UIAQuery.buttons(LocStrings.GROUPS).topmost(),
        EDIT_BUTTON:                UIAQuery.buttons(LocStrings.EDIT).topmost(),
        FAVORITES_BACK_BUTTON:      UIAQuery.navigationBars().andThen(UIAQuery.buttons(LocStrings.FAVORITES).leftmost()),

        /* Queries for items on the placecard view */
        MAP_BACK_BUTTON:            UIAQuery.buttons(LocStrings.Maps.MAP),

        /* Queries for RAP view */
        RAP_PRIVACY_VIEW:           UIAQuery.query("UINavigationTransitionView").andThen(UIAQuery.images("RAPMapIcon")),
        RAP_PRIVACY_AGREE_BUTTON:   UIAQuery.navigationBars().andThen(LocStrings.Maps.RAP_PRIVACY_AGREE),

        /* Queries for common alerts */
        Alerts: {
            NO_SEARCH_RESULTS:          UIAQuery.contains(LocStrings.Maps.SEARCH_RESULTS_NOT_AVAILABLE),
            DIRECTIONS_NOT_AVAILABLE:   UIAQuery.contains(LocStrings.DIRECTIONS_NOT_AVAILABLE),
            OK_BUTTON:                  UIAQuery.alerts().andThen(UIAQuery.buttons(LocStrings.OK)),
            HELP_IMPROVE_MAPS:          UIAQuery.contains('Help Improve Maps'),
            SAFETY_WARNING:             UIAQuery.contains(LocStrings.Maps.SAFETY_WARNING),
        },
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/

    // Map view mode
    maps.MAPMODE                = {};
    maps.MAPMODE.Map            = 'Map';
    maps.MAPMODE.Satellite      = 'Satellite';
    maps.MAPMODE.Transit        = 'Transit';

    // Traffic mode
    maps.TRAFFICMODE            = {};
    maps.TRAFFICMODE.Show       = "Traffic On";
    maps.TRAFFICMODE.Hide       = "Traffic Off";

    // 3D mode
    maps.MAP3DMODE              = {};
    maps.MAP3DMODE.On           = "3D On";
    maps.MAP3DMODE.Off          = "3D Off";

    // Tracking mode
    maps.TRACKINGMODE           = {};
    maps.TRACKINGMODE.Off       = LocStrings.TRACKING_OFF;
    maps.TRACKINGMODE.Location  = LocStrings.TRACKING_ON;
    maps.TRACKINGMODE.Heading   = LocStrings.TRACKING_ON_WITH_HEADING;

    // Navigation mode
    maps.NAVIGATIONMODE         = {};
    maps.NAVIGATIONMODE.Live    = "Live Navigation";
    maps.NAVIGATIONMODE.Stepping = "Stepping Navigation";

    // Route mode
    maps.ROUTEMODE              = {};
    maps.ROUTEMODE.Driving      = 'Drive';
    maps.ROUTEMODE.Walking      = 'Walk';
    maps.ROUTEMODE.Transit      = 'Transit';

    // Sharing methods
    maps.SHARINGMETHOD          = {};
    maps.SHARINGMETHOD.Mail     = "Mail";
    maps.SHARINGMETHOD.Messages = "Messages";
    maps.SHARINGMETHOD.Twitter  = "Twitter";
    maps.SHARINGMETHOD.Facebook = "Facebook";

    // Screenshot settings
    maps.SCREENSHOTS            = {};
    maps.SCREENSHOTS.Enabled    = true;
    maps.SCREENSHOTS.Directory  = "/tmp/MapScreens/";

    // Timeouts
    maps.SEARCHTIMEOUT          = 61;


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: UI State Constants                                                  */
    /*                                                                             */
    /*      A dictionary of strings describing the possible UI states of the app   */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for possible UI state names specific to Maps */
    UIStateDescription.Maps = {
        SETTINGS:                   'Settings',
        SEARCH_EDIT:                'Editing Search',

        MAP:                        'Map',
        MAP_NO_CONTROLS:            'Fullscreen Map', // not on iPad devices
        MAP_WITH_CALLOUT:           'Map with Callout',

        DIRECTIONS_EDIT:            'Editing Directions',
        ROUTE_BEGIN:                'Route Loaded',
        ROUTE_END:                  'Ended Route',
        ROUTE_OVERVIEW:             'Route Overview',
        ROUTE_LIST:                 'Route Listed Steps',

        FAVORITES_LIST:             'Favorites List',
        FAVORITES_LIST_EDITING:     'Editing Favorites List',
        FAVORITES_EDITING:          'Editing Favorite',

        RECENTS_LIST:               'Recent Searches List',
        CONTACTS_LIST:              'Contacts List',
        CONTACTS_GROUPS:            'Contacts Groups',

        PLACECARD:                  'Placecard',
        SHARE_SHEET:                'Share Sheet',
        MAIL_COMPOSE:               'Mail Compose View',

        STEPPING_NAVIGATION:        'Stepping Navigation',
        LIVE_NAVIGATION:            'Live Navigation',
        LIVE_NAVIGATION_FULL:       'Fullscreen Live Navigation', // Not on iPad

        REPORT_A_PROBLEM:           'Report a Problem',
        REPORT_A_PROBLEM_PRIVACY:   'Report a Problem Privacy Info',

        DEBUG:                      'Debug',

    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get The Current UI State                                            */
    /*                                                                             */
    /*      A function to determine which UIState the app is currently in          */
    /*                                                                             */
    /*******************************************************************************/

    maps._dismissMailComposeView = function _dismissMailComposeView() {
        this.tap(UIAQuery.Maps.CANCEL_BUTTON);

        if (this.waitUntilPresent(UIAQuery.Maps.DELETE_DRAFT_BUTTON)) {
            this.tap(UIAQuery.Maps.DELETE_DRAFT_BUTTON);
        }
    }

    maps._tapEmptyLocationInMapView = function _tapEmptyLocationInMapView() {
        this.tapEmptyLocationInMapView();
    };

    maps.NAVIGATION_VIEW_TRANSITIONS = [

        // Getting to MapView from other versions
        { from: UIStateDescription.Maps.MAP_NO_CONTROLS, to: UIStateDescription.Maps.MAP, transition:{action:maps._tapEmptyLocationInMapView} },
        { from: UIStateDescription.Maps.MAP_WITH_CALLOUT, to: UIStateDescription.Maps.MAP, transition:{action:maps._tapEmptyLocationInMapView} },

        // Settings view
        { from: UIStateDescription.Maps.MAP, to: UIStateDescription.Maps.SETTINGS, transition:{action:maps.tap, options:UIAQuery.Maps.SETTINGS_BUTTON} },

        // Directions edit view
        { from: UIStateDescription.Maps.MAP, to: UIStateDescription.Maps.DIRECTIONS_EDIT, transition:{action:maps.tap, options:UIAQuery.Maps.DIRECTIONS_BUTTON} },
        { from: UIStateDescription.Maps.DIRECTIONS_EDIT, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.CANCEL_BUTTON} },

        // Routing views
        { from: UIStateDescription.Maps.ROUTE_BEGIN, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.CLEAR_BUTTON} },
        { from: UIStateDescription.Maps.LIVE_NAVIGATION_FULL, to: UIStateDescription.Maps.LIVE_NAVIGATION, transition:{action:maps.tap, options:UIAQuery.MAP_VIEW} },
        { from: UIStateDescription.Maps.LIVE_NAVIGATION, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.END_BUTTON} },
        { from: UIStateDescription.Maps.LIVE_NAVIGATION, to: UIStateDescription.Maps.ROUTE_OVERVIEW, transition:{action:maps.tap, options:UIAQuery.Maps.OVERVIEW_BUTTON} },
        { from: UIStateDescription.Maps.LIVE_NAVIGATION, to: UIStateDescription.Maps.ROUTE_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.LIST_STEPS_BUTTON} },
        { from: UIStateDescription.Maps.ROUTE_OVERVIEW, to: UIStateDescription.Maps.LIVE_NAVIGATION, transition:{action:maps.tap, options:UIAQuery.Maps.RESUME_BUTTON} },
        { from: UIStateDescription.Maps.ROUTE_OVERVIEW, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.END_BUTTON} },
        { from: UIStateDescription.Maps.ROUTE_OVERVIEW, to: UIStateDescription.Maps.ROUTE_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.LIST_STEPS_BUTTON} },
        { from: UIStateDescription.Maps.ROUTE_END, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.END_BUTTON} },

        // Search edit view
        { from: UIStateDescription.Maps.MAP, to: UIStateDescription.Maps.SEARCH_EDIT, transition:{action:maps.tap, options:UIAQuery.Maps.SEARCH_BAR} },

        // Favorites view
        { from: UIStateDescription.Maps.SEARCH_EDIT, to: UIStateDescription.Maps.FAVORITES_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.FAVORITES_LIST_BUTTON} },

        { from: UIStateDescription.Maps.FAVORITES_LIST, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} },
        { from: UIStateDescription.Maps.RECENTS_LIST, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} },
        { from: UIStateDescription.Maps.CONTACTS_LIST, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} },

        { from: UIStateDescription.Maps.FAVORITES_LIST, to: UIStateDescription.Maps.RECENTS_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.RECENTS_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.FAVORITES_LIST, to: UIStateDescription.Maps.CONTACTS_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.CONTACTS_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.FAVORITES_LIST, to: UIStateDescription.Maps.FAVORITES_LIST_EDITING, transition:{action:maps.tap, options:UIAQuery.Maps.EDIT_BUTTON} },
        { from: UIStateDescription.Maps.FAVORITES_LIST_EDITING, to: UIStateDescription.Maps.FAVORITES_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} },
        { from: UIStateDescription.Maps.RECENTS_LIST, to: UIStateDescription.Maps.FAVORITES_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.FAVORITES_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.RECENTS_LIST, to: UIStateDescription.Maps.CONTACTS_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.CONTACTS_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.CONTACTS_LIST, to: UIStateDescription.Maps.FAVORITES_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.FAVORITES_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.CONTACTS_LIST, to: UIStateDescription.Maps.RECENTS_LIST, transition:{action:maps.tap, options:UIAQuery.Maps.RECENTS_TOOLBAR_BUTTON} },
        { from: UIStateDescription.Maps.CONTACTS_LIST, to: UIStateDescription.Maps.CONTACTS_GROUPS, transition:{action:maps.tap, options:UIAQuery.Maps.GROUPS_BUTTON} },

        // Share sheet
        { from: UIStateDescription.Maps.MAP, to: UIStateDescription.Maps.SHARE_SHEET, transition:{action:maps.tap, options:UIAQuery.Maps.SHARE_BUTTON} },
        { from: UIStateDescription.Maps.MAP_WITH_CALLOUT, to: UIStateDescription.Maps.SHARE_SHEET, transition:{action:maps.tap, options:UIAQuery.Maps.SHARE_BUTTON} },
        { from: UIStateDescription.Maps.MAIL_COMPOSE, to: UIStateDescription.Maps.MAP, transition:{action:maps._dismissMailComposeView, options:null} },

        // Report a Problem
        { from: UIStateDescription.Maps.SETTINGS, to: UIStateDescription.Maps.REPORT_A_PROBLEM, transition:{action:maps.tap, options:UIAQuery.Maps.REPORT_AN_ISSUE_BUTTON} },
        { from: UIStateDescription.Maps.REPORT_A_PROBLEM_PRIVACY, to: UIStateDescription.Maps.REPORT_A_PROBLEM, transition:{action:maps.tap, options:UIAQuery.Maps.RAP_PRIVACY_AGREE_BUTTON} },
        { from: UIStateDescription.Maps.REPORT_A_PROBLEM, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.CANCEL_BUTTON} },
        { from: UIStateDescription.Maps.REPORT_A_PROBLEM, to: UIStateDescription.Maps.PLACECARD, transition:{action:maps.tap, options:UIAQuery.Maps.CANCEL_BUTTON} },
        { from: UIStateDescription.Maps.PLACECARD, to: UIStateDescription.Maps.REPORT_A_PROBLEM, transition:{action:maps.tap, options:UIAQuery.Maps.REPORT_AN_ISSUE_BUTTON} },

        // Debug
        { from: UIStateDescription.Maps.MAP, to: UIStateDescription.Maps.DEBUG, transition:{action:maps.tap, options:UIAQuery.Maps.STATUS_BAR} },
        { from: UIStateDescription.Maps.DEBUG, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} },

    ];

    if (UIATarget.localTarget().model() === "iPad") {
        // iPad stuff here
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SETTINGS, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.POPOVER_DISMISS} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.PLACECARD, to: UIStateDescription.Maps.MAP_WITH_CALLOUT, transition:{action:maps.tap, options:UIAQuery.MAP_VIEW} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SHARE_SHEET, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.POPOVER_DISMISS} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SEARCH_EDIT, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.SETTINGS_BUTTON} });
    } else {
        // iPhone stuff here
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SETTINGS, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.DONE_BUTTON} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.PLACECARD, to: UIStateDescription.Maps.MAP_WITH_CALLOUT, transition:{action:maps.tap, options:UIAQuery.Maps.MAP_BACK_BUTTON} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SHARE_SHEET, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.CANCEL_BUTTON} });
        maps.NAVIGATION_VIEW_TRANSITIONS.push({ from: UIStateDescription.Maps.SEARCH_EDIT, to: UIStateDescription.Maps.MAP, transition:{action:maps.tap, options:UIAQuery.Maps.CANCEL_BUTTON} });
    }

    maps._navigationBarValueIs = function _navigationBarValueIs(navigationBarValue) {
        var navigationBarInfo = this.inspect(UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.TOP_NAVBAR.isVisible())) || this.inspect(UIAQuery.TOP_NAVBAR.isVisible()) || (navigationBarValue == 'UISearch' && this.inspect(UIAQuery.TOP_NAVBAR));
        var navigationBarName = navigationBarInfo ? navigationBarInfo.name : null;
        return navigationBarName == navigationBarValue;
    };

    maps._allExists = function _allExists(queryList) {
        if (!(queryList instanceof Array)) {
            queryList = [queryList]
        }
        return queryList.every(maps.exists.bind(maps));
    };

    maps._existsAndNotExists = function _existsAndNotExists(options) {
        var existsList = (options.exists instanceof Array) ? options.exists : [];
        var notExistsList = (options.notExists instanceof Array) ? options.notExists : [];
        return this._allExists(existsList) && notExistsList.every(function (e) { return !maps.exists(e); });
    };

    maps.NAVIGATION_VIEWS = {};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.MAP]                      = {action:maps._existsAndNotExists, options:{
                                                                                    exists: [UIAQuery.MAP_VIEW.isVisible(), UIAQuery.Maps.DIRECTIONS_BUTTON, UIAQuery.Maps.SHARE_BUTTON, UIAQuery.Maps.TRACKING_BUTTON, UIAQuery.Maps.SETTINGS_BUTTON ],
                                                                                    notExists: [UIAQuery.Maps.SHARE_SHEET, UIAQuery.Maps.CALLOUT, UIAQuery.Maps.PLACECARD_NAV_BAR, UIAQuery.Maps.MODE_SELECTOR] } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.MAP_NO_CONTROLS]          = {action:maps._existsAndNotExists, options:{
                                                                                    exists: [UIAQuery.MAP_VIEW.isVisible()],
                                                                                    notExists: [UIAQuery.Maps.DIRECTIONS_BUTTON.isVisible(), UIAQuery.Maps.SHARE_BUTTON.isVisible(), UIAQuery.Maps.TRACKING_BUTTON.isVisible(), UIAQuery.Maps.SETTINGS_BUTTON.isVisible(), UIAQuery.navigationBars().isVisible(), UIAQuery.toolbars().isVisible() ] } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.MAP_WITH_CALLOUT]         = {action:maps._existsAndNotExists, options:{
                                                                                    exists: [UIAQuery.Maps.CALLOUT, UIAQuery.MAP_VIEW.isVisible()],
                                                                                    notExists: [UIAQuery.Maps.SHARE_SHEET] } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.SETTINGS]                 = {action:maps._allExists, options:[UIAQuery.Maps.MODE_SELECTOR, ] };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.SEARCH_EDIT]              = {action:maps._existsAndNotExists, options:{
                                                                                    exists: [UIAQuery.Maps.SEARCH_BAR.isVisible(), UIAQuery.Maps.SEARCH_SUGGESTIONS.isVisible()],
                                                                                    notExists: [UIAQuery.Maps.SHARE_SHEET] } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.DIRECTIONS_EDIT]          = {action:maps._allExists, options:[UIAQuery.Maps.DIRECTIONS_NAV_BAR, UIAQuery.Maps.SWAP_DIRECTIONS_BUTTON, UIAQuery.Maps.ROUTE_BUTTON ]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.ROUTE_BEGIN]              = {action:maps._allExists, options:[UIAQuery.Maps.CLEAR_BUTTON, UIAQuery.Maps.ROUTE_MODE_SELECTOR, UIAQuery.Maps.START_BUTTON ] };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.ROUTE_END]                = {action:maps._allExists, options:[UIAQuery.Maps.ARRIVED_MARKER, UIAQuery.Maps.END_BUTTON ]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.ROUTE_OVERVIEW]           = {action:maps._allExists, options:[UIAQuery.Maps.END_BUTTON, UIAQuery.Maps.RESUME_BUTTON ]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.ROUTE_LIST]               = {action:maps._allExists, options:[UIAQuery.Maps.DIRECTIONS_NAV_BAR, UIAQuery.Maps.Done]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.FAVORITES_LIST]           = {action:maps._allExists, options:[UIAQuery.Maps.FAVORITES_NAV_BAR, UIAQuery.Maps.FAVORITES_TOOLBAR_BUTTON, UIAQuery.Maps.EDIT_BUTTON ]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.FAVORITES_LIST_EDITING]   = {action:maps._existsAndNotExists, options:{
                                                                                    exists: [UIAQuery.Maps.FAVORITES_NAV_BAR, UIAQuery.Maps.FAVORITES_TOOLBAR_BUTTON, UIAQuery.Maps.DONE_BUTTON],
                                                                                    notExists: [UIAQuery.Maps.EDIT_BUTTON], } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.FAVORITES_EDITING]        = {action:maps._allExists, options:[UIAQuery.Maps.EDIT_FAVORITE_NAV_BAR, UIAQuery.Maps.FAVORITES_BACK_BUTTON]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.RECENTS_LIST]             = {action:maps._allExists, options:[UIAQuery.Maps.RECENTS_NAV_BAR, UIAQuery.Maps.RECENTS_TOOLBAR_BUTTON]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.CONTACTS_LIST]            = {action:maps._allExists, options:[UIAQuery.Maps.CONTACTS_NAV_BAR, UIAQuery.Maps.CONTACTS_TOOLBAR_BUTTON]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.CONTACTS_GROUPS]          = {action:maps._navigationBarValueIs, options:'Groups'};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.PLACECARD]                = {action:maps._allExists, options:[UIAQuery.Maps.PLACECARD_NAV_BAR, ]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.SHARE_SHEET]              = {action:maps.exists, options:UIAQuery.Maps.SHARE_SHEET};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.MAIL_COMPOSE]             = {action:maps.exists, options:UIAQuery.Maps.MAIL_COMPOSE_VIEW};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.STEPPING_NAVIGATION]      = {action:maps._allExists, options:[UIAQuery.Maps.STEPPING_TITLE_BAR, UIAQuery.Maps.STEPPING_SIGN]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.LIVE_NAVIGATION]          = {action:maps._allExists, options:[UIAQuery.Maps.LIVE_NAVIGATION_SIGN, UIAQuery.Maps.END_BUTTON.isVisible()]};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.LIVE_NAVIGATION_FULL]     = {action:maps._existsAndNotExists, options:{
                                                                                    exists:[UIAQuery.Maps.LIVE_NAVIGATION_SIGN],
                                                                                    notExists:[UIAQuery.Maps.END_BUTTON.isVisible()] } };
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.REPORT_A_PROBLEM]         = {action:maps._navigationBarValueIs, options:LocStrings.Maps.REPORT_AN_ISSUE};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.REPORT_A_PROBLEM_PRIVACY] = {action:maps.exists, options:UIAQuery.Maps.RAP_PRIVACY_VIEW};
    maps.NAVIGATION_VIEWS[UIStateDescription.Maps.DEBUG]                    = {action:maps._allExists, options:[UIAQuery.Maps.DEBUG_NAV_BAR, ]};

    maps.navigation = new UIANavigation(maps, maps.NAVIGATION_VIEW_TRANSITIONS, maps.NAVIGATION_VIEWS);
    maps.navigation.updateNavigation();

    /**
     * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Maps for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.Maps
     */
    maps.currentUIState = function currentUIState() {
        return this.navigation.getCurrentState();
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get To [page] functions                                             */
    /*                                                                             */
    /*      Helper functions for navigating to different pages within the app      */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Gets to the placecard for the element matching the name given
     *
     * @param {null | UIAQuery | string} query Query for element in the map view to go to placecard
     *          if null, wait until callout is present and tap callout
     */
    maps.goToPlacecardForMapElement = function goToPlacecardForMapElement(query) {
        // Get to map view
        if (query && !this.exists(UIAQuery.MAP_VIEW.andThen(query))) {
            UIALogger.logMessage("Did not find element, attempting to get to map view");
            this.goToState(UIStateDescription.Maps.MAP);
        }

        if (query && !this.exists(UIAQuery.Maps.CALLOUT)) { // Tap on matching POI/map element
            this.tap(UIAQuery.MAP_VIEW.andThen(query));
        }

        if (!this.waitUntilPresent(UIAQuery.Maps.CALLOUT, 5)) {
            throw new UIAError("No callout present after tapping map element");
        }

        // Tap on Callout to get to placecard
        var viewAppear = UIAWaiter.waiter("ViewDidAppear");
        this.tap(UIAQuery.Maps.CALLOUT);
        if (!viewAppear.wait()) {
            throw new UIAError("Placecard did not appear after tapping map element callout");
        }
    };

    /**
     * Gets to category. For example: Foods, Drinks,...
     *
     * @param {string} category Category to browse.
     */
    maps.goToSearchCategory = function goToSearchCategory(category) {
        // Waits until category table is present
        var categoryCellQuery = UIAQuery.tableViews().andThen(UIAQuery.tableCells().first());
        UIAUtilities.assert(this.waitUntilPresent(categoryCellQuery, 5), 'Category table not found');
        // Taps the category
        var categoryButtonQuery = categoryCellQuery.andThen(UIAQuery.buttons(category));
        this.assertExists(categoryButtonQuery, '"%0" button not found'.format(category));
        this.tap(categoryButtonQuery);
    };

    /**
     * Navigate to the given state
     *
     * @param {string} state A UI state defined in UIStateDescription.Maps.*
     */
    maps.goToState = function goToState(state) {
        UIALogger.logMessage("Going to Maps state: " + state);
        this.launch();
        return this.navigation.goTo(state);
    };

    /**
     * Goes to top level category if there is any
     */
    maps.goToTopLevelSearchCategory = function goToTopLevelSearchCategory() {
        this.tapIfExists(UIAQuery.tableCells().andThen(UIAQuery.buttons(LocStrings.Maps.BACK)));
    };

    /***********************************************************************************/
    /*                                                                                 */
    /*   Mark: Tasks                                                                   */
    /*                                                                                 */
    /*      A high-level goal we are trying to accomplish. These take care of reaching */
    /*      the appropriate views (e.g. - performMapSearch)                            */
    /*      These will be comprised of multiple Action functions                       */
    /*                                                                                 */
    /***********************************************************************************/

    /**
     * Gets the map viewing mode
     *
     * @returns {string} Current map mode
     */
    maps.getMapMode = function getMapMode() {
        // Go to settings view
        this.goToState(UIStateDescription.Maps.SETTINGS);
        // Gets map mode
        var mapMode;
        if (this.exists(UIAQuery.Maps.MODE_MAP_BUTTON.isSelected())) {
            mapMode = maps.MAPMODE.Map;
        } else if (this.exists(UIAQuery.Maps.MODE_TRANSIT_BUTTON.isSelected())) {
            mapMode = maps.MAPMODE.Transit;
        } else if (this.exists(UIAQuery.Maps.MODE_SATELLITE_BUTTON.isSelected())) {
            mapMode = maps.MAPMODE.Satellite;
        } else {
            throw new UIAError('Unknown map mode');
        }
        // To make sure we are not stuck in UIStateDescription.Maps.SETTINGS state
        this.goToState(UIStateDescription.Maps.MAP);

        return mapMode;
    };

    /**
     * Launches maps from notification center
     *
     * @param {string} notification Notification to verify in notification center
     *                  It could be a regex.
     */
    maps.launchFromNotificationCenter = function launchFromNotificationCenter(notification) {
        // Gets to springboard
        springboard.launch();
        // Gets to notification center
        UIAUtilities.assert(springboard.getToNotifications(),
            'Failed to get to notification center');

        var notificationQuery = UIAQuery.staticTexts().withPredicate('name matches "%0"'.format(notification));

        // A cached notification may be present so wait a short time for it to go away. Worst case scenario,
        // if it never goes away we'll timeout silently, continue on and pick up it's presence next.
        springboard.waitUntilAbsent(notificationQuery, 10)

        // Waits until the expected notification appears, then taps it to return to Maps route view
        UIAUtilities.assert(springboard.waitUntilPresent(notificationQuery, 25),
            '"%0" not found'.format(notification));
        maps.waitToBecomeActive(10,
            function() {
                springboard.tap(notificationQuery);
            }
        );
    };

    /**
     * Launches maps from Safari using url
     *
     * @param {string} the url to input in Safari
     *
     */
    maps.launchFromSafari = function launchFromSafari(url) {
        safari.launch();
        maps.waitToBecomeActive(10, function() {
            safari.handlingAlertsInline(UIAQuery.alerts(LocStrings.OPEN_THIS_PAGE_IN.replace('%@', maps.name())) , function() {
                    var alertAppeared = UIAWaiter.waiter('Alert');
                    safari.loadURL(url);
                    UIAUtilities.assert(alertAppeared.wait(5), 'Alert did not appear after opening the url in Safari.');
                    safari.tapIfExists(LocStrings.OPEN);
            });
        });
    };

    /**
     * Launches Siri assistant to search a term, selects the first one in the list
     *  and verifies it returns to Maps.
     *
     * @param {string} inputVoiceCommand Siri recording file with its path to find a term via siri assistant
     */
    maps.launchFromSiri = function launchFromSiri(inputVoiceCommand) {
        springboard.launch();
        // Workaround: <rdar://problem/22708540> Failed to issue a voice command with sringboard.issueVoiceCommand
        // Radar to fix the workaround: <rdar://problem/23108932> Update the workaround of sringboard.issueVoiceCommand
        springboard.getToAssistant();
        target.delay(10);
        // Issues a voice command
        var mapsSnippetAppearWaiter = UIAWaiter.waiter('ViewDidAppear',
            {predicate: 'controllerClass == "MAMapsSnippetController"'});
        springboard.issueVoiceCommand(inputVoiceCommand);
        // Verifies maps results are present
        UIAUtilities.assert(mapsSnippetAppearWaiter.wait(10), 'Maps results not found');
        var singleResultQuery = UIAQuery.query('MAMapSnippetView').andThen(UIAQuery.query('UIView')).children();
        var multipleResultsQuery = UIAQuery.query('MAListSnippetView').andThen(UIAQuery.query('UITableView')).children();
        // Waits until Maps is active
        maps.waitToBecomeActive(10,
            function() {
                // Tap the first result
                springboard.tap(singleResultQuery.orElse(multipleResultsQuery).first());
            }
        );
    };

    /**
     * Launches the app with the given URL and options
     *
     * @param {string} url Url to open launch the maps app with
     * @param {object} options An options dictionary
     * @param {boolean} [options.commandArgs=[]] Any additional arguments for LaunchApp
     */
    maps.launchWithURL = function launchWithURL(url, options) {
        options = UIAUtilities.defaults(options, {
            commandArgs: [],
        });

        var launchAppArgs = ["-url", url];
        launchAppArgs.push.apply(launchAppArgs, options.commandArgs);
        performTask("/usr/local/bin/LaunchApp", launchAppArgs);
    };

	/**
	 * Browses a category or keyword in the given mode. For example: Foods, Drinks,... when you tap search bar.
	 *
     * @param {object} options An options dictionary
	 * @param {string} [options.searchTerm="1 Infinite Loop Cupertino, CA"] - location where to browse categories
	 * @param {string} [options.browseTerm="Drinks"] - term to browse.
	 * @param {boolean} [options.browseCategory=true] - whether browse category or keyword
	 * @param {null | string} [options.verifyGroup=null] - group to verify in the drop list of category or keyword
	 * @param {null | string} [options.subcategory=null] - Subcategory to browse
	 * @param {null | string} [options.verifyTerm=null] - term to verify in results of subcategory
	 */
	maps.performMapBrowse = function performMapBrowse(options) {
		options = UIAUtilities.defaults(options, {
			searchTerm:         '1 Infinite Loop Cupertino, CA',
			browseTerm:         'Drinks',
			browseCategory:     true,
			verifyGroup:        null,
			subcategory:        null,
			verifyTerm:         null,
		});

		this.performMapSearch(options.searchTerm);
		this.clearAndTapSearchBar();
		this.goToTopLevelSearchCategory();
		// Browses category or keyword
		if (options.browseCategory) {
			this.goToSearchCategory(options.browseTerm);
		} else {
			this.performMapSearch(options.browseTerm, {tapSearch:false});
		}
		// Verifies group
		if (options.verifyGroup) {
			this.verifyGroupList(options.verifyGroup);
		}
		// Browses subcategory
		if (options.subcategory) {
			this.goToSearchCategory(options.subcategory);
		}
		// Verification
		if(options.verifyTerm) {
			if (options.subcategory) {
				this.verifySearchResults({multipleResults:true, verifyTermInAnyResult:options.verifyTerm});
				this.captureMapsScreenshot('Map_Browse_%0_%1'.format(options.browseTerm, options.subcategory).replace(/ |,/g, ''));
				this.tapSearchResult(options.verifyTerm);
			} else {
                this.captureMapsScreenshot('Map_Browse_%0_%1'.format(options.browseTerm, 'Popular').replace(/ |,/g, ''));
				this.tapSearchResult(options.verifyTerm);
				this.verifySearchResults({verifyTermInAnyResult:options.verifyTerm});
			}
			this.goToPlacecardForMapElement();
			UIAUtilities.assert(this.waitUntilPresent(UIAQuery.Maps.PLACECARD_NAV_BAR, 5), 'Not in placecard');
		}
    };

    /**
     * In a given view mode, browse maps with the following supported gestures,
     * rotate and re-orient the compass, browse maps again without crash
     *              'i': zoom in
     *              'o': zoom out
     *              'u': pan up
     *              'd': pan down
     *              'l': pan left
     *              'r': pan right
     *              'f': pitch up
     *              'b': pitch down
     *              't': rotate
     *              'c': rotate and tap on compass
     *
     * @param {string} gestures The search term to use to search maps
     * @param {number} [options.intervalBetweenGestures=0] wait time between the gestures in seconds
     */
    maps.performMapGestures = function performMapGestures(gestures, options) {
        options = UIAUtilities.defaults(options, {
            intervalBetweenGestures: 0,
        });

        for (var i = 0; i < gestures.length; i++) {
            var gesture = gestures[i];
            UIALogger.logDebug('Performing gesture: "%0"'.format(gesture));
            switch (gesture) {
                case 'i':
                    this.zoomMapIn();
                    break;
                case 'o':
                    this.zoomMapOut();
                    break;
                case 'u':
                    this.panMapUp();
                    break;
                case 'd':
                    this.panMapDown();
                    break;
                case 'l':
                    this.panMapLeft();
                    break;
                case 'r':
                    this.panMapRight();
                    break;
                case 'f':
                    this.pitchMapUp();
                    break;
                case 'b':
                    this.pitchMapDown();
                    break;
                case 't':
                    this.rotateMap();
                    break;
                case 'c':
                    this.rotateMap();
                    this.tapCompass();
                    break;
                default:
                    throw new UIAError('Invalid gesture found: "%0"'.format(gesture));
            }
            target.delay(options.intervalBetweenGestures);
        }
    };

    /**
     * Enters search term into search bar and searches for it
     *
     * @param {string} searchTerm The search term to use to search maps
     * @param {object} options An options dictionary
     * @param {UIAQuery | string} [options.partialTermCompletion=null] An element that should be tapped to
     *         complete the search using suggestions
     * @param {boolean} [options.tapSearch=true] Whether tap 'search' after enter search term
     */
    maps.performMapSearch = function performMapSearch(searchTerm, options) {
        options = UIAUtilities.defaults(options, {
            partialTermCompletion: null,
            tapSearch: true,
        });

        var alertHandler = function() {
            var app = target.activeApp();
            alertQuery = UIAQuery.Maps.Alerts.NO_SEARCH_RESULTS;
            if (alertQuery && app.exists(alertQuery)) {
                throw new UIAError('Received "%0" Alert'.format(app.inspect(alertQuery).label));
            }
        }

        // Get to map view
        this.goToState(UIStateDescription.Maps.SEARCH_EDIT);
        // Type string into search bar
        this.enterText(UIAQuery.Maps.SEARCH_BAR, searchTerm);
        // Tap search button
        this.withAlertHandler(alertHandler, function() {
            if (options.partialTermCompletion) {
                var suggestionListQuery = UIAQuery.tableViews().first();
                // The list dynamically updates. Waits until it's completely loaded.
                var previousTotalSuggestions;
                do {
                    previousTotalSuggestions = this.count(suggestionListQuery.children());
                    target.delay(1);
                } while (this.count(suggestionListQuery.children()) > previousTotalSuggestions);
                this.tap(suggestionListQuery.andThen(options.partialTermCompletion));
            } else if (options.tapSearch) {
                this.tap(UIAQuery.Maps.SEARCH_BUTTON);
            }
            var searchResultQuery = UIAQuery.Maps.CALLOUT.orElse(UIAQuery.tableCells());
            UIAUtilities.assert(this.waitUntilPresent(searchResultQuery, maps.SEARCHTIMEOUT),
                'No callout or search results list found');
        });
    };

    /**
     * Sets the map viewing mode
     *
     * @param {string} mapMode Map mode to change to, must be maps.MAPMODE.*
     */
    maps.setMapMode = function setMapMode(mapMode) {
        // Get to settings view
        this.goToState(UIStateDescription.Maps.SETTINGS);
        // Tap on corresponding mode button
        if (mapMode === maps.MAPMODE.Map) {
            this.tap(UIAQuery.Maps.MODE_MAP_BUTTON);
        } else if (mapMode === maps.MAPMODE.Transit) {
            this.tap(UIAQuery.Maps.MODE_TRANSIT_BUTTON);
        } else if (mapMode === maps.MAPMODE.Satellite) {
            this.tap(UIAQuery.Maps.MODE_SATELLITE_BUTTON);
        } else {
            throw new UIAError('Map mode "%0" does not exist.'.format(mapMode));
        }

        UIAUtilities.assert(this.getMapMode() === mapMode,
                            '"%0" is not set successfully'.format(mapMode));
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Actions                                                             */
    /*                                                                             */
    /*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
    /*      Other helper functions. E.g. - returnCleanedNumber                     */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Favorites an element in the map view
     *
     * @param {UIAQuery | string} query Query for the element in map view
     * @param {object} options An options dictionary
     * @param {boolean} [options.favoriteName=null] Custom name for favorite
     */
    maps.addFavorite = function addFavorite(query, options) {
        options = UIAUtilities.defaults(options, {
            favoriteName: null,
        });
        this.goToPlacecardForMapElement(query);
        // perform the add to favorites share sheet action
        this.performShareSheetAction('Add to Favorites');
        // Enter custom name
        if (options.favoriteName) {
            this.enterText(UIAQuery.textFields().first(), options.favoriteName);
        }
        // Confirm
        this.tap('Save');
    };

    /**
     * Clears and taps search bar
     */
    maps.clearAndTapSearchBar = function clearAndTapSearchBar() {
        // Gets to search edit view
        this.goToState(UIStateDescription.Maps.SEARCH_EDIT);
        // Clears and taps search bar
        this.enterText(UIAQuery.Maps.SEARCH_BAR, '');
    };

    /**
     * Clears map view search bar
     */
    maps.clearCurrentSearch = function clearCurrentSearch() {
        // Assumes in state where search bar is shown
        // Taps the clear button in the search bar
        this.tap(UIAQuery.Maps.SEARCH_BAR_CLEAR_BUTTON);
    };

    /**
     * Removes all recent searches
     */
    maps.clearRecentSearches = function clearRecentSearches() {
        // Get to recents list view
        this.goToState(UIStateDescription.Maps.RECENTS_LIST);
        // Tap clear button
        this.tap(UIAQuery.Maps.CLEAR_BUTTON);
        // Tap confirm
        this.tap('Clear All Recents');
    };

    /**
     * Returns the current step of navigation for current route
     *
     * @returns {number} The current step of navigation for current route
     */
    maps.currentNavigationStep = function currentNavigationStep() {
        // Assumes in stepping navigation state
        // Returns the current step based on page indicator
        var value = maps.inspect(UIAQuery.pageIndicators()).value;
        var regex = /page ([0-9]+) of ([0-9]+)/;
        var match = value.match(regex);
        if (match) {
            return Number(match[1]);
        } else {
            throw new UIAError("Could not parse current step from '" + value + "'");
        }
    };

    /**
     * Drops a pin on the map view
     *
     * @param {object} options An options dictionary
     * @param {boolean} [options.useHoldOnMap=false] Whether pin should be dropped
     *              by holding on map view
     */
    maps.dropPinAndVerify = function dropPinAndVerify(options) {
        options = UIAUtilities.defaults(options, {
            useHoldOnMap: false,
        });

        var calloutAppearWaiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "MKSmallCalloutViewController"'});
        if (!options.useHoldOnMap) {
            this.goToState(UIStateDescription.Maps.SETTINGS);
            this.tap(UIAQuery.Maps.DROP_A_PIN_BUTTON);
        } else {
            this.goToState(UIStateDescription.Maps.MAP);
            this.tap(UIAQuery.MAP_VIEW, {duration:3.0});
        }

        UIAUtilities.assert(calloutAppearWaiter.wait(7), 'Callout did not appear.');
    };

    /**
     * Ends the navigation for the current playing route
     */
    maps.endNavigation = function endNavigation() {
        // Assumes in some navigation state
        // Ends navigation, pushes End
        this.tap(UIAQuery.Maps.END_BUTTON);
    };

    /**
     * Gets the route mode for the loaded route
     *
     * @returns {string} Current route mode
     */
    maps.getRouteMode = function getRouteMode() {
        // Assumes in loaded route state
        if (this.exists(UIAQuery.Maps.ROUTE_MODE_DRIVE_BUTTON.isSelected())) {
            return maps.ROUTEMODE.Driving;
        } else if (this.exists(UIAQuery.Maps.ROUTE_MODE_WALK_BUTTON.isSelected())) {
            return maps.ROUTEMODE.Walking;
        } else if (this.exists(UIAQuery.Maps.ROUTE_MODE_TRANSIT_BUTTON.isSelected())) {
            return maps.ROUTEMODE.Transit;
        } else {
            throw new UIAError('Unknown route mode');
        }
    };

    /**
     * Returns whether live navigation has arrived at the destination
     *
     * @returns {boolean} Whether live navigation has arrived at the destination
     */
    maps.hasNavigationArrived = function hasNavigationArrived() {
        // Assumes in some navigation state
        // Checks to see if live navigation has arrived at destination
        return this.exists(UIAQuery.Maps.ARRIVED_MARKER);
    };

    /**ijaz
     * Loads route from start to destination
     * @param {string} start Start location search term
     * @param {string} destination Destination search term
     * @param {null | string} [routeModeToSet=null] - Mode of the route to set, must be maps.ROUTEMODE.*. If null, the current mode is used.
     * @param {object} options An options dictionary
     * @param {boolean} [options.useQuickRoute=false] Use the quick route button
     *            on callout (will override start to Current Location)
     */
    maps.loadRoute = function loadRoute(start, destination, routeModeToSet, options) {
        options = UIAUtilities.defaults(options, {
            useQuickRoute: false,
        });

		var d, startTime;
        var directionsNotAvailableAlertHandler = (function directionsNotAvailableAlertHandler() {
            if (this.isActive()) {
                var alertQuery = UIAQuery.Maps.Alerts.DIRECTIONS_NOT_AVAILABLE;
                var alertInfo = this.inspect(alertQuery);
                if (alertInfo) {
                    throw new UIAError("Received '%0' Alert".format(alertInfo.name), {identifier:"Directions not available"});
                }
            }

            return false;
        }).bind(this);

        var safetyAlertQuery = UIAQuery.Maps.Alerts.SAFETY_WARNING;

        this.withAlertHandler(directionsNotAvailableAlertHandler, function() {
            if (options.useQuickRoute) { // Different logic in case of quick route
                this.performMapSearch(destination);
                UIAUtilities.assert(
                    this.waitUntilPresent(UIAQuery.Maps.QUICK_ROUTE_BUTTON.isVisible()),
                    "Quick route button did not appear"
                );

                this.handlingAlertsInline(safetyAlertQuery, function() {
                    this.tap(UIAQuery.Maps.QUICK_ROUTE_BUTTON);
                    if (this.waitUntilPresent(safetyAlertQuery, 5)) {
                        this.tap(UIAQuery.Maps.Alerts.OK_BUTTON);
                    }
                });
            } else {
                this.goToState(UIStateDescription.Maps.DIRECTIONS_EDIT);
                this.enterText(UIAQuery.Maps.START_LOCATION_TEXTFIELD, start, {allowTypeStringToRetry:true});       // allowTypeToRetry for rdar://problem/21972515
                this.enterText(UIAQuery.Maps.END_LOCATION_TEXTFIELD, destination, {allowTypeStringToRetry:true});   // allowTypeToRetry for rdar://problem/21972515
                // start
                //d = new Date();
                //startTime = d.getTime();

				target.delay(2);

				startTime = Date.now();
				UIALogger.logMessage('PERF DEBUG Before Tap on Route: %0'.format(Date.now() - startTime));
				this.tap(UIAQuery.Maps.ROUTE_BUTTON);
				UIALogger.logMessage('PERF DEBUG After Tap on Route: %0'.format(Date.now() - startTime));

			}

            if (!this.waitUntilPresent(UIAQuery.Maps.ROUTE_FROM_TO_PINS.andThen(UIAQuery.contains(start)), 30)) {
            	throw new Error("Could not find start element: " + start);
        	}

        	// end
        	this.measureTime(startTime);

        	/*
            if (routeModeToSet) {
                this.setRouteMode(routeModeToSet);
            }
			if (!this.waitUntilPresent(UIAQuery.Maps.ROUTE_FROM_TO_PINS.andThen(UIAQuery.contains(destination)))) {
				throw new Error("Could not find destination element: " + destination);
			}
			*/
        });
    };

    /** It dumps perf time into the logs. It also prepares the json object for uploading the data
	 *
	 *
     * @param {number} startTime
	 */
	maps.measureTime = function measureTime(startTime) {
		//var d = new Date();
		var endTime = Date.now();//d.getTime();
		UIALogger.logMessage('PERF DEBUG start time: %0, end time: %1'.format(startTime, endTime));
		perfTime = endTime - startTime;
		UIALogger.logMessage('PERF DEBUG perf time in ms: %0'.format(perfTime));
		// Look for json object to see if marker already exist if yes then update the time since then
		var text = '{ "route" : [{ "timeElapse":%0 , "startTime":%1, "endTime":%2 } ]}'.format(perfTime, startTime, endTime);
		UIALogger.logMessage('PERF DEBUG JSON: %0'.format(text));
		var jsonObject = JSON.parse(text);
		UIALogger.logMessage('PERF DEBUG JSON OBJECT: %0'.format(jsonObject));
	};

    /**
     * Moves 'n' steps in stepping navigation
     *
     * @param {number} nSteps Number of steps to move (positive is foward, negative is backward)
     */
    maps.moveNavigationSteps = function moveNavigationSteps(nSteps) {
        // Assumes in stepping navigation state
        // Swipes 'n' steps on element
        var backwards = (nSteps < 0);
        steps = Math.abs(nSteps);
        for (var i = 0; i < steps; i++) {
            var q = UIAQuery.Maps.STEPPING_SIGN;
            var options = {
                duration: 1.0,
            };
            if (backwards) {
                options.fromOffset = {x:0.1, y:0.5};
                options.toOffset = {x:0.9, y:0.5};
            } else {
                options.fromOffset = {x:0.9, y:0.5};
                options.toOffset = {x:0.1, y:0.5};
            }
            this.drag(q, options);
        }
    };

    /**
     * Performs an action in the current placecard
     *
     * @param {UIAQuery | string} query Query to look for in placecard
     */
    maps.performPlacecardAction = function performPlacecardAction(query) {
        // Assume in place card view or map view
        // Tap on given action in share sheet
        this.tap(query);
    };

    /**
     * Performs a share sheet action from Map or Placecard view
     *
     * @param {UIAQuery | string} query Query to look for in share sheet
     */
    maps.performShareSheetAction = function performShareSheetAction(query) {
        // Assume in place card view or map view
        // Tap share button
        this.tap(UIAQuery.Maps.SHARE_BUTTON);
        // Tap on given action in share sheet
        var viewAppear = UIAWaiter.waiter("ViewDidAppear");
        this.tap(query);
        if (!viewAppear.wait()) {
            throw new UIAError("Tapping share action did not result in view change");
        }
    };

    /**
     * Loads and plays route from a given trace file
     *
     * @param {UIAQuery | string} traceQuery Query for trace in list
     */
    maps.playRouteTrace = function playRouteTrace(traceQuery) {
        // Gets to debug view
        this.goToState(UIStateDescription.Maps.DEBUG);
        // Goes to Navigation > Traces > Play Trace
        this.tap('Navigation');
        this.tap('Traces');
        this.tap('Play Trace');
        // Selects trace with traceQuery
        this.tap(traceQuery);
    };

    /**
     * Removes a favorited element
     *
     * @param {string} name Name of favorite to delete
     */
    maps.removeFavorite = function removeFavorite(name) {
        // Get to favorites view
        this.goToState(UIStateDescription.Maps.FAVORITES_LIST);
        // Tap on edit button
        this.tap(UIAQuery.Maps.EDIT_BUTTON);
        // Tap on corresponding delete button
        this.tap(UIAQuery.buttons('Delete ' + name));
        this.tap(UIAQuery.buttons('Delete'));
        // Tap done
        this.tap(UIAQuery.Maps.DONE_BUTTON);
    };

    /**
     * Removes a pin on the map view
     */
    maps.removePinAndVerify = function removePinAndVerify() {
        // Tap on dropped pin entry
        this.goToPlacecardForMapElement(UIAQuery.Maps.DROPPED_PIN);
        // Tap on Remove Pin in placecard and verify pin is removed
        var viewDisappearWaiter = UIAWaiter.waiter('ViewDidDisappear');
        this.performPlacecardAction(LocStrings.REMOVE_PIN);

        UIAUtilities.assert(viewDisappearWaiter.wait(5),
                            'Placecard did not disappear after tapping "%0"'.format(LocStrings.REMOVE_PIN));
        UIAUtilities.assert(!this.exists(UIAQuery.withPredicate('name beginsWith "%0"'.format(LocStrings.DROPPED_PIN))),
                            'Pin was not removed. Found "%0"'.format(LocStrings.DROPPED_PIN));
    };

    /**
     * Renames a favorited element
     *
     * @param {UIAQuery | string} query The favorite element in list
     * @param {string} newName New name for favorite
     */
    maps.renameFavorite = function renameFavorite(query, newName) {
        // Get to favorites view
        this.goToState(UIStateDescription.Maps.FAVORITES_LIST);
        // Tap on edit button
        this.tap(UIAQuery.Maps.EDIT_BUTTON);
        // Tap on corresponding favorite
        this.tap(query);
        // Enter new name
        this.enterText(UIAQuery.textFields().first(), newName);
        // Go back
        this.tap(UIAQuery.Maps.BACK_BUTTON);
        // Tap done
        this.tap(UIAQuery.Maps.DONE_BUTTON);
    };

    /**
     * Searches for a contact in the contacts list
     *
     * @param {UIAQuery | string} contact Query for the contact in the list
     */
    maps.searchContacts = function searchContacts(contact) {
        // Gets to contacts list
        this.goToState(UIStateDescription.Maps.CONTACTS_LIST);
        // Taps matching contact
        this.tap(UIAQuery.tableViews().andThen(contact));
    };

    /**
     * Searches for a favorite in the favorites list
     *
     * @param {UIAQuery | string} favorite Query for the favorite in the list
     */
    maps.searchFavorites = function searchFavorites(favorite) {
        // Gets to favorites list
        this.goToState(UIStateDescription.Maps.FAVORITES_LIST);
        // Taps matching favorite
        this.tap(UIAQuery.tableViews().andThen(favorite));
    };

    /**
     * Searches for a recent in the recents list
     *
     * @param {UIAQuery | string} recent Query for the recent in the list
     */
    maps.searchRecents = function searchRecents(recent) {
        // Gets to recents list
        this.goToState(UIStateDescription.Maps.RECENTS_LIST);
        // Taps matching recent
        this.tap(UIAQuery.tableViews().andThen(recent));
    };

    /**
     * Sets the 3d map view mode
     *
     * @param {string} mode 3D mode to change to, must be maps.MAP3DMODE.*
     */
    maps.set3DMode = function set3DMode(mode) {
        // Gets to settings view
        this.goToState(UIStateDescription.Maps.SETTINGS);
        // Enables/disables 3D mode
        if (mode === maps.MAP3DMODE.On) {
            this.tap(UIAQuery.Maps.MAP_3D_BUTTON);
        } else if (mode === maps.MAP3DMODE.Off) {
            this.tap(UIAQuery.Maps.MAP_2D_BUTTON);
        } else {
            throw new UIAError("3D mode '" + mode + "' does not exist.");
        }
    };

    /**
     * Sets a route mode for the loaded route
     *
     * @param {string} routeMode Route mode to select, must be maps.ROUTEMODE.*
     */
    maps.setRouteMode = function setRouteMode(routeMode) {
        // Assumes in loaded route state
        // Tap on corresponding mode button
        var routeModeQuery;
        if (routeMode === maps.ROUTEMODE.Driving) {
            routeModeQuery = UIAQuery.Maps.ROUTE_MODE_DRIVE_BUTTON;
        } else if (routeMode === maps.ROUTEMODE.Walking) {
            routeModeQuery = UIAQuery.Maps.ROUTE_MODE_WALK_BUTTON;
        } else if (routeMode === maps.ROUTEMODE.Transit) {
            routeModeQuery = UIAQuery.Maps.ROUTE_MODE_TRANSIT_BUTTON;
        } else {
            throw new UIAError('Route mode "%0" does not exist.'.format(routeMode));
        }
        this.tap(routeModeQuery);

        UIAUtilities.assert(this.waitUntilPresent(routeModeQuery.isSelected(), 5),
                            '"%0" is not set successfully'.format(routeMode));
    };

    /**
     * Sets the map tracking mode
     *
     * @param {string} trackingMode Tracking mode to change to, must be maps.TRACKINGMODE.*
     */
    maps.setTrackingMode = function setTrackingMode(trackingMode) {
        // Check first if active
        var trackingValue = this.inspect(UIAQuery.Maps.TRACKING_BUTTON).value;
        if (trackingValue === maps.TRACKINGMODE.Off &&
            trackingMode !== maps.TRACKINGMODE.Off) {
            var q = UIAQuery.alerts().andThen('Allow');
            this.handlingAlertsInline(q, function() {
                this.tap(UIAQuery.Maps.TRACKING_BUTTON);
                this.tapIfExists(q);
            });
        }

        // Taps tracking button until mode matches
        var maxAttempts = 3;
        for (var i = 0; i < maxAttempts; i++) {
            var trackingValue = this.inspect(UIAQuery.Maps.TRACKING_BUTTON).value;
            UIALogger.logMessage("Tracking values: '" + trackingValue + "'");
            if (trackingValue === trackingMode) {
                return;
            } else {
                this.tap(UIAQuery.Maps.TRACKING_BUTTON);
            }
        }

        if (!this.waitUntilPresent(UIAQuery.withPredicate("value == '" + trackingMode + "'"))) {
            throw new UIAError("Could not reach tracking mode '" + trackingMode + "'");
        }

    };

    /**
     * Sets the map traffic mode and verify state of Show/Hide Traffic button
     * It only works in maps.MAPMODE.Map or maps.MAPMODE.Satellite
     * It does NOT verify redering of traffic on map view
     *
     * @param {string} trafficMode Traffic mode to change to, must be maps.TRAFFICMODE.*
     */
    maps.setTrafficMode = function setTrafficMode(trafficMode) {
        // Go to settings view
        this.goToState(UIStateDescription.Maps.SETTINGS);
        // Select appropriate traffic mode if not already selected
        if (trafficMode === maps.TRAFFICMODE.Show) {
            // Tap only if traffic isn't already showing
            if (!this.exists(UIAQuery.Maps.HIDE_TRAFFIC_BUTTON)) {
                this.tap(UIAQuery.Maps.SHOW_TRAFFIC_BUTTON);
            }
            // Verify that HIDE_TRAFFIC_BUTTON is visible now
            this.goToState(UIStateDescription.Maps.SETTINGS);
            if (!this.waitUntilPresent(UIAQuery.Maps.HIDE_TRAFFIC_BUTTON.isVisible())) {
                throw new UIAError('Hide Traffic button did not appear after clicking on Show Traffic button.');
            }
        } else if (trafficMode === maps.TRAFFICMODE.Hide) {
            // Tap only if traffic isn't already hidden
            if (!this.exists(UIAQuery.Maps.SHOW_TRAFFIC_BUTTON)) {
                this.tap(UIAQuery.Maps.HIDE_TRAFFIC_BUTTON);
            }
            // Verify that SHOW_TRAFFIC_BUTTON is visible now
            this.goToState(UIStateDescription.Maps.SETTINGS);
            if (!this.waitUntilPresent(UIAQuery.Maps.SHOW_TRAFFIC_BUTTON.isVisible())) {
                throw new UIAError('Show Traffic button did not appear after clicking on Hide Traffic button.');
            }
        } else {
            throw new UIAError("Traffic mode '" + trafficMode + "' does not exist.");
        }
    };

    /**
     * Starts the navigation for the current loaded route
     */
    maps.startNavigation = function startNavigation() {
        // Assumes in loaded route state
        // Starts navigation, pushes Start
        this.tap(UIAQuery.Maps.START_BUTTON);
    };

    /**
     * Taps the compass on the map view
     */
    maps.tapCompass = function tapCompass() {
        // Assumes in map view with rotated map
        UIAUtilities.assert(this.waitUntilPresent(UIAQuery.Maps.COMPASS_BUTTON.isVisible(), 10), 'Compass button is not visible.');
        this.tap(UIAQuery.Maps.COMPASS_BUTTON);
        UIAUtilities.assert(this.waitUntilAbsent(UIAQuery.Maps.COMPASS_BUTTON.isVisible()), 'Compass button is still visible after tap.');

    };

    /**
     * Taps an empty spot in the map view, either dismissing a callout or showing/hiding controls
     */
    maps.tapEmptyLocationInMapView = function tapEmptyLocationInMapView() {
        var elementRects = [];
        var marginDistance = 32; // pixels
        if (this.exists(UIAQuery.Maps.CALLOUT)) { // Handles the callout rect as well
            var calloutRect = this.inspect(UIAQuery.Maps.CALLOUT).rect;
            elementRects.push(calloutRect);
        }

        var mapViewRect = this.inspect(UIAQuery.MAP_VIEW).rect;

        // Find empty point in map view
        var elementInfos = this.inspectAll(UIAQuery.Maps.POI_ELEMENTS);
        for (var i = 0; i < elementInfos.length; i++) {
            elementRects.push(elementInfos[i].rect);
        }

        var isPointFree = function isPointFree(point) {
            var isPointInRect = function isPointInRect(point, rect) {
                return (point.x >= rect.x - marginDistance && point.x <= rect.x + rect.width + marginDistance &&
                        point.y >= rect.y - marginDistance && point.y <= rect.y + rect.height + marginDistance)
            }
            var free = true;
            for (var i = 0; i < elementRects.length; i++) {
                if (isPointInRect(point, elementRects[i])) {
                    free = false;
                }
            }
            return free;
        }

        var incrementValue = 0.1;
        for (var x = incrementValue/2; x < 1.0; x += incrementValue) {
            for (var y = 0.2; y < 0.8; y += incrementValue) {
                var point = {x: x, y: y};
                var pointPixels = {x: point.x * mapViewRect.width, y: point.y * mapViewRect.height };
                UIALogger.logMessage("Testing " + x + ", " + y);
                if (isPointFree(pointPixels)) {
                    this.tap(UIAQuery.MAP_VIEW, {touchOffset: point});
                    return;
                }
            }
        }

        throw new UIAError("No free point found in the map view to tap.");
        // Tap it
    };

    /**
     * Taps relevant search result
     *
     * @param {string} result Result to tap.
     */
    maps.tapSearchResult = function tapSearchResult(result) {
        resultQuery = UIAQuery.tableCells().contains(result);
        this.scrollToVisibleIfExists(resultQuery);
        var viewAppear = UIAWaiter.waiter('ViewDidAppear');
        this.tap(resultQuery);
        // Verification is not included and is in a separate function.
        viewAppear.wait(10);
    }

    /**
     * Loads and plays route from a given trace file
     */
    maps.tapTraceControl = function tapTraceControl(traceName, options) {
        // Assumes in trace navigation
        // Taps on map view to show controls
        // Taps appropriate trace control
    };

    /**
     * Returns the total steps of navigation for current route
     *
     * @returns {number} The total step of navigation for current route
     */
    maps.totalNavigationSteps = function totalNavigationSteps() {
        // Assumes in stepping navigation state
        // Returns the total steps based on page indicator
        var value = maps.inspect(UIAQuery.pageIndicators()).value;
        var regex = /page ([0-9]+) of ([0-9]+)/;
        var match = value.match(regex);
        if (match) {
            return Number(match[2]);
        } else {
            throw new UIAError("Could not parse total steps from '" + value + "'");
        }
    };

    /**
     * Verify there exist at least one alternate route.
     *
     */
    maps.verifyAlternateRouteAvailable = function verifyAlternateRouteAvailable() {
        var alternateRouteElements = this.inspectAll(UIAQuery.Maps.ALTERNATE_ROUTE);
        UIAUtilities.assert(alternateRouteElements.length, 'No alternate route found');
        for (var i = 0; i < alternateRouteElements.length; i++) {
            UIALogger.logMessage("Alternate route element found:" + alternateRouteElements[i].name);
        }
    }

    /**
     * Verifies that all favorites exist
     *
     * @param {array} favorites An array of UIAQuerys and/or strings to verify
     * @param {object} options An options dictionary
     * @param {boolean} [options.orderMatters=false] Order of the favorites matters
     * @param {boolean} [options.countMatters=false] Total count of the favorites matters
     */
    maps.verifyFavorites = function verifyFavorites(favorites, options) {
        options = UIAUtilities.defaults(options, {
            orderMatters: false,
            countMatters: false,
        });
        // Get to favorites view
        this.goToState(UIStateDescription.Maps.FAVORITES_LIST);
        // Verify that all favorits are present
        var currentFavorites = maps.inspectAll(UIAQuery.tableViews().andThen(UIAQuery.staticTexts()));
        var names = []
        for (var i = 0; i < currentFavorites.length; i++) {
            names.push(currentFavorites[i].name);
        }

        // If order matters, check that too
        // If not allowing others, verify that as well
    };

    /**
     * Verifies Favorites View Toolbar buttons exist and are visible
     *
     */
    maps.verifyFavoritesViewToolbar = function verifyFavoritesViewToolbar() {
        // Assumes you are in favorites view
        var results = true;
        if (!UIAQuery.Maps.FAVORITES_TOOLBAR_BUTTON.isVisible()) {
            UIALogger.logMessage('Favorites toolbar button not found.');
            results = false;
        }
        if (!UIAQuery.Maps.RECENTS_TOOLBAR_BUTTON.isVisible()) {
            UIALogger.logMessage('Recents toolbar button not found.');
            results = false;
        }
        if (!UIAQuery.Maps.CONTACTS_TOOLBAR_BUTTON.isVisible()) {
            UIALogger.logMessage('Contacts toolbar button not found.');
            results = false;
        }
        UIAUtilities.assert(results, 'Favorites view toolbar verification failed. One or more buttons were not visible.');
    };

    /**
     * Verify there is a list underneath a given group name
     *
     * @param {string} group to verify a list underneath
     */
    maps.verifyGroupList = function verifyGroupList(group) {
        var groupQuery = UIAQuery.tableViews().andThen(UIAQuery.contains(group));
        UIAUtilities.assert(this.waitUntilPresent(groupQuery, 5), '"%0" not found'.format(group));
        // Finds and prints the results
        var results = this.inspectAll(UIAQuery.tableCells().below(groupQuery));
        var resultIndex = 0;
        while (resultIndex < results.length) {
            UIALogger.logMessage('Found result: %0'.format(results[resultIndex].name));
            resultIndex++;
        }
    };

    /**
     * Verifies that an query exists in map view
     *
     * @param {UIAQuery | string} query Query to wait for inside map view
     * @param {object} options An options dictionary
     * @param {number} [options.timeout=10] Any additional arguments for LaunchApp
     */
    maps.verifyMapElement = function verifyMapElement(query, options) {
        options = UIAUtilities.defaults(options, {
            timeout: 10,
        });
        // Assume in map view
        var q = UIAQuery.MAP_VIEW.andThen(query);
        if (!this.waitUntilPresent(q, options.timeout)) {
            throw new UIAError("Could not verify map element");
        }
    };

    /**
     * Verifies that current navigation is in given mode
     *
     * @param {string} navMode Navigation mode to verify, must be maps.NAVIGATIONMODE.*
     */
    maps.verifyNavigationMode = function verifyNavigationMode(navMode) {
        // Assumes in some navigation state
        // Verifies state matches whats given
        var currentState = this.currentUIState();
        if (navMode === maps.NAVIGATIONMODE.Live && (currentState === UIStateDescription.Maps.LIVE_NAVIGATION_FULL ||
                                                     currentState === UIStateDescription.Maps.LIVE_NAVIGATION)) {
            return;
        } else if (navMode === maps.NAVIGATIONMODE.Stepping &&
                   currentState === UIStateDescription.Maps.STEPPING_NAVIGATION) {
            return;
        }

        throw new UIAError("Could not verify navigation state as '" + navMode + "', currently in '" + currentState + "'");
    };

    /**
     * Verifies that a route has successfully been loaded
     *
     * @param {UIAQuery | string} start Query to look for start element in map view
     * @param {UIAQuery | string} destination Query to look for destination element in map view
     */
    maps.verifyRouteLoaded = function verifyRouteLoaded(start, destination) {
        // Verifies in loaded route state
        if (this.currentUIState() !== UIStateDescription.Maps.ROUTE_BEGIN) {
            throw new Error("Not in correct UI state for loaded route.");
        }
        if (!this.waitUntilPresent(UIAQuery.Maps.ROUTE_FROM_TO_PINS.andThen(UIAQuery.contains(start)))) {
            throw new Error("Could not find start element: " + start);
        }
        if (!this.waitUntilPresent(UIAQuery.Maps.ROUTE_FROM_TO_PINS.andThen(UIAQuery.contains(destination)))) {
            throw new Error("Could not find destination element: " + destination);
        }
    };

    /**
     * Verifies there is one or more search results and whether the results are relevant
     *
     * @param {object} options An options dictionary
     * @param {boolean} [options.multipleResults=false] Whether there will be possibly multiple results
     * @param {null | string} [options.verifyTermInCallout=null] term to verify in a callout
     * @param {null | string} [options.verifyTermInAnyResult=null] term to verify in any result in a list or callout
     * @param {null | string} [options.verifyTermInAllResults=null] term to verify in all results in a list or callout
     *          Set ONE verifyTerm* option at one time. They are mutually exclusive.
     *
     * This function covers the following use cases:
     *     1. Search "1 infinite loop, CA",
     *        expect a callout with "1 infinite loop"
     *          multipleResults=false, verifyTermInCallout="1 infinite loop"
     *     2. Search "coffee",
     *        expect one or more results
     *        verify "Starbucks" in any result
     *          multipleResults=true, verifyTermInAnyResult="Starbucks"
     *     3. Search "Apple Store",
     *        expect one or more results
     *        verify "Apple Store" in all results
     *          multipleResults=true, verifyTermInAllResults="Apple Store"
     */
    maps.verifySearchResults = function verifySearchResults(options) {
        options = UIAUtilities.defaults(options, {
            multipleResults: false,
            verifyTermInCallout: null,
            verifyTermInAnyResult: null,
            verifyTermInAllResults: null,
        });

        var searchResultQuery = UIAQuery.Maps.CALLOUT.orElse(UIAQuery.tableCells());
        UIAUtilities.assert(this.waitUntilPresent(searchResultQuery, maps.SEARCHTIMEOUT),
                'No callout or search results list found');
        // Verify single result vs multiple results
        if (this.exists(UIAQuery.Maps.CALLOUT.isVisible())) {
            UIALogger.logMessage('Single result. Callout found.');
            options.verifyTermInCallout = (options.verifyTermInCallout) ?
                                            options.verifyTermInCallout : options.verifyTermInAnyResult;
            options.verifyTermInCallout = (options.verifyTermInCallout) ?
                                            options.verifyTermInCallout : options.verifyTermInAllResults;
            maps.verifyTermInSingleResult(options);
        } else if (!options.multipleResults) {
            throw new UIAError('Callout not found');
        } else {
            // In case it's set as hide list, to show list
            this.tapIfExists(UIAQuery.Maps.SHOW_LIST_BUTTON);
            // Verify table view is present
            if (!this.waitUntilPresent(UIAQuery.tableCells(), 5)) {
                throw new UIAError('Results not found');
            }
            UIALogger.logMessage('Multiple search results found');
            maps.verifyTermInMultipleResults(options);
        }
    };

    /**
     * Verify the elements are present in the same table cell
     *
     * @param {array} array of elements to verify in a table
     *
     * @returns {boolean} Whether the elements are found in the same table cell
     */
    maps.verifyTableElementNames = function verifyTableElementNames(elements) {
        // Validate preconditions
        UIAUtilities.assert(elements instanceof Array, '"%0" should be an array'.format(elements));

        UIALogger.logMessage('Verifying element(s) "%0"'.format(elements.toString()));

        var found = true, elementIndex = 0;
        var predicateString = 'ANY children.name beginsWith "%0"'.format(elements[0]);
        var tableCellQuery = UIAQuery.tableCells().withPredicate(predicateString).orElse(
                UIAQuery.query('UITableViewSectionElement').withPredicate(predicateString));
        this.waitUntilPresent(tableCellQuery, 5);
        while (elementIndex < elements.length) {
            if (!this.exists(tableCellQuery.children().andThen(UIAQuery.beginsWith(elements[elementIndex])))) {
                UIALogger.logMessage('element "%0" not found'.format(elements[elementIndex]));
                found = false;
            }
            elementIndex++;
        }

        return found;
    };

    /**
     * Verifies any result or all results contain the expected term
     *
     * @param {object} options An options dictionary
     * @param {null | string} [options.verifyTermInAnyResult=null] term to verify in any result in a list
     * @param {null | string} [options.verifyTermInAllResults=null] term to verify in all results in a list
     */
    maps.verifyTermInMultipleResults = function verifyTermInMultipleResults(options) {
        options = UIAUtilities.defaults(options, {
            verifyTermInAnyResult: null,
            verifyTermInAllResults: null,
        });

        var resultsQuery = UIAQuery.tableCells();
        if (options.verifyTermInAnyResult) {
            // Asserts if none of results contains the term
            if (!this.exists(resultsQuery.contains(options.verifyTermInAnyResult))) {
                throw new UIAError('"%0" not found in any result'.format(options.verifyTermInAnyResult));
            }
        } else if (options.verifyTermInAllResults) {
            // Checks if all the results contain options.verifyTermInAllResults
            var resultsCount = this.count(resultsQuery);
            var matchedResultsCount = this.count(resultsQuery.contains(options.verifyTermInAllResults));
            if (resultsCount != matchedResultsCount) {
                throw new UIAError('One or more results not matched');
            }
        }
    };

    /**
     * Verifies the callout contains the expected term
     *
     * @param {object} options An options dictionary
     * @param {null | string} [options.verifyTermInCallout=null] term to verify in a callout
     */

    maps.verifyTermInSingleResult = function verifyTermInSingleResult(options) {
        options = UIAUtilities.defaults(options, {
            verifyTermInCallout: null,
        });

        var callout = UIAQuery.VISIBLE_POPOVERS;
        if (options.verifyTermInCallout &&
            !this.exists(callout.withPredicate('ANY descendants.name contains[c] "%0"'.format(options.verifyTermInCallout)))) {
            throw new UIAError('"%0" not found in callout'.format(options.verifyTermInCallout));
        }
    };

	/*******************************************************************************/
	/*                                                                             */
	/*   Mark: Helpers                                                             */
    /*                                                                             */
    /*      Helper functions                                                       */
	/*                                                                             */
	/*******************************************************************************/

    /**
     * Saves a screenshot of the current view with given name
     *
     * @param {string} identifier Identifier to tag the screenshot file name with
     */
    maps.captureMapsScreenshot = function captureMapsScreenshot(identifier) {
        if (maps.SCREENSHOTS.Enabled) {
            performTask('/bin/mkdir', [maps.SCREENSHOTS.Directory]);
            var now = new Date();
            var screenName = '%0Maps_%1_%2.png'.format(maps.SCREENSHOTS.Directory, identifier, now.getTime());
            UIATarget.localTarget().captureScreenWithName(screenName);
        }
    };

    /**
     * Removes all screenshots in the maps screenshots folder
     */
    maps.removeMapsScreenshots = function removeMapsScreenshots() {
        UIALogger.logMessage('Removing screenshots in directory %0'.format(maps.SCREENSHOTS.Directory));
        performTask("/bin/rm", ["-rf", maps.SCREENSHOTS.Directory]);
    };

	/*******************************************************************************/
	/*                                                                             */
	/*   Mark: Handlers                                                            */
    /*                                                                             */
    /*      Alert handlers for the app. e.g.Êsafari.accessContactsAlertHandler     */
	/*                                                                             */
	/*******************************************************************************/

    /**
     * Handle Help Improve Maps alert that appears nondeterministically
     *
     * @returns {None}
     */
    maps.improveMapsAlertHandler = function improveMapsAlertHandler() {
        var app = target.activeApp();
        var alertQuery = UIAQuery.Maps.Alerts.HELP_IMPROVE_MAPS;
        if (app.exists(alertQuery)) {
            var alert = app.inspect(alertQuery);
            if (alert && alert.label) {
                UIALogger.logMessage("Received '" + alert.label + "' Alert");
                UIALogger.logMessage("Trying to dismiss '" + alert.label + "' Alert");
            }
            return app.tapIfExists(UIAQuery.query('Don\u2019t Allow'));
        } else {
            return false;
        }
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Assertions                                                          */
    /*                                                                             */
    /*      Assertion functions for the app. e.g.Êsafari.assertActiveURL           */
    /*                                                                             */
    /*******************************************************************************/

}
