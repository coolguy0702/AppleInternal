load('UIATesting.js');
load('PerformanceMaps.js');
load('Mail.js');
load('SpringBoard.js');
load('UIAUtility.js');

if (typeof MapsTests === 'undefined') {
    /**
     * @namespace MapsTests
     * All the functions are in alphabetical order.
     */
    var MapsTests = {

		/**
		 * Launches the maps app (if not launched), go to map view and set map mode as maps.MAPMODE.Map.
		 *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
		 */
		_testCaseInit: function _testCaseInit(args) {
			args = UIAUtilities.defaults(args, {
				mapMode: maps.MAPMODE.Map,
			});

			maps.setMapMode(args.mapMode);
		},

        /**
         * Check alternate routes in route planning
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.startLocation="Cupertino, CA"] - Start location for the route
         * @param {string} [args.endLocation="San Francisco, CA"] - End location for the route
         * @param {string} [args.routeMode="Drive"] - Mode of the route to select, must be a maps.ROUTEMODE.*
         */
        alternateRoute: function alternateRoute(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                startLocation: 'Cupertino, CA',
                endLocation: 'San Francisco, CA',
                routeMode: maps.ROUTEMODE.Driving,
            });

            MapsTests.getDirections({
                mapMode: args.mapMode,
                startLocation: args.startLocation,
                endLocation: args.endLocation,
                routeModeToSet: args.routeMode,
                routeModeToVerify: args.routeMode,
            });
            maps.verifyAlternateRouteAvailable();
        },

        /**
         * Go to edit directions state by taping on Directions button and then clicking Cancel to make sure we come back to Map view.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         *
         * @alertHandlers springboard.standardAlertHandler, maps.improveMapsAlertHandler, maps.allowAccessToLocationAlertHandler
         */
        directionsOpenClose: function directionsOpenClose(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.goToState(UIStateDescription.Maps.DIRECTIONS_EDIT);
            maps.goToState(UIStateDescription.Maps.MAP);
        },

        /**
         * Drop and remove pin in the given mode
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         */
        dropRemovePin: function dropRemovePin(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.dropPinAndVerify();
            maps.removePinAndVerify();
        },

        /**
         * Launches maps from notification center
         *
         * @targetApps Maps, SpringBoard
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.notification="(Right now, it would take you about ([0-9]+ hours?,? )?([0-9]+ minutes? )?to drive to work.)|(Traffic is unusually heavy on the way to work. The driving time is ([0-9]+ hours? )?([0-9]+ minutes?)?.)"]
         *                  - Notification to verify in notification center
         * @param {string} [args.location="20330 Stevens Creek Blvd"] - Location to verify in loaded route as destination
         *
         * @alertHandlers springboard.standardAlertHandler, maps.allowAccessToLocationAlertHandler
         */
        frequentLocation: function frequentLocation(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                notification: '(Right now, it would take you about \
                    ([0-9]+ hours? )?([0-9]+ minutes? )?to drive to work.)|\
                    (Traffic is unusually heavy on the way to work. \
                    The driving time is ([0-9]+ hours?,? )?([0-9]+ minutes?)?.)',
                location: '20330 Stevens Creek Blvd',
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.launchFromNotificationCenter(args.notification);
            UIAUtilities.assert(maps.currentUIState() === UIStateDescription.Maps.ROUTE_BEGIN,
                                'Maps was launched but a route was not loaded');
            maps.verifyRouteLoaded(LocStrings.CURRENT_LOCATION, args.location);
        },

        /**
         * In a given view mode, browse maps with the following supported gestures without crash,
         * rotate and re-orient the compass, browse maps again without crash
         *              'i': zoom in
         *              'o': zoom out
         *              'u': pan up
         *              'd': pan down
         *              'l': pan left
         *              'r': pan right
         *              'f': pitch up
         *              'b': pitch down
         *              't': rotate
         *              'c': rotate and tap on compass
         *
         * @targetApps Maps
         *
         * @param {object}          args Test arguments
         * @param {string}          [args.mapMode="Map"] - Mode of the map to select, one of maps.MAPMODE.*
         * @param {string}          [args.searchTerm="Cupertino, CA"] - location to search for
         * @param {string}          [args.gestures="lurdfbioc"] - gestures to browse in map
         * @param {number}          [args.intervalBetweenGestures=2] wait time between the gestures in seconds
         *
         */
        gestures: function gestures(args) {
            args = UIAUtilities.defaults(args, {
                mapMode:                maps.MAPMODE.Map,
                searchTerm:             'Cupertino, CA',
                gestures:               'lurdfbioc',
                intervalBetweenGestures: 2,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapSearch(args.searchTerm);

            maps.performMapGestures(args.gestures, {intervalBetweenGestures: args.intervalBetweenGestures});
        },

        /**
         * Turns on tracking to get current location
         *
         * @param {object} args Test arguments
         * @param {boolean} [args.trackHeading=false] - Whether to track heading as well as location
         *
         * @alertHandlers springboard.standardAlertHandler, maps.improveMapsAlertHandler, maps.allowAccessToLocationAlertHandler
         */
        getCurrentLocation: function getCurrentLocation(args) {
            args = UIAUtilities.defaults(args, {
                trackHeading: false,
            });

            MapsTests._testCaseInit();

            if (args.trackHeading) {
                maps.setTrackingMode(maps.TRACKINGMODE.Heading);
            } else {
                maps.setTrackingMode(maps.TRACKINGMODE.Location);
            }
        },

        /**
         * Gets directions for the given start and end location. Then verify route is loaded.
         * It does not navigate to given end location.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.startLocation="Oakland, CA"] - Start location for the route
         * @param {string} [args.endLocation="San Francisco, CA"] - End location for the route
         * @param {boolean} [args.useQuickRoute=false] - Whether or not to use the quick route button (will override start locations to use Current Location)
         * @param {null | string} [args.routeModeToSet=null] - Mode of the route to set, must be maps.ROUTEMODE.*. If null, the current mode is used.
         * @param {string} [args.routeModeToVerify="Drive"] - Mode of the route to verify, must be a maps.ROUTEMODE.*
         *
         * @alertHandlers springboard.standardAlertHandler, maps.improveMapsAlertHandler, maps.allowAccessToLocationAlertHandler
         */
        getDirections: function getDirections(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                startLocation: ["Oakland, CA"],
                endLocation: ["San Francisco, CA"],
                useQuickRoute: false,
                routeModeToSet: null,
                routeModeToVerify: maps.ROUTEMODE.Driving,
            });

            if (args.useQuickRoute) {
                args.startLocation = LocStrings.CURRENT_LOCATION;
            }

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.loadRoute(args.startLocation, args.endLocation, args.routeModeToSet, {useQuickRoute: args.useQuickRoute});
            maps.verifyRouteLoaded(args.startLocation, args.endLocation);
        },

        /**
         * Launch and quit maps app.
         *
         * @targetApps Maps
         *
        **/
        launchQuit: function launchQuit() {
            MapsTests._testCaseInit();
            maps.quit();
        },

        /**
         * Gets directions for the given start and end location. Then verify route is loaded.
         * It does not navigate to given end location.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Transit"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.startLocation="Oakland, CA"] - Start location for the route
         * @param {string} [args.endLocation="San Francisco, CA"] - End location for the route
         *
         * @alertHandlers springboard.standardAlertHandler, maps.improveMapsAlertHandler, maps.allowAccessToLocationAlertHandler
         */
        getDirectionsPerf: function getDirectionsPerf(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Transit,
                startLocation: ["Oakland, CA"],
                endLocation: ["San Francisco, CA"],
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.loadRoute(args.startLocation, args.endLocation, null);
        },

        /**
         * Launch and quit maps app.
         *
         * @targetApps Maps
         *
        **/
        launchQuit: function launchQuit() {
            MapsTests._testCaseInit();
            maps.quit();
        },

        /**
         * Browses a category or keyword in the given mode. For example: Foods, Drinks,... when you tap search bar.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.searchTerm="1 Infinite Loop Cupertino, CA"] - location where to browse categories
         * @param {string} [args.browseTerm="Drinks"] - term to browse.
         * @param {boolean} [args.browseCategory=true] - whether browse category or keyword
         * @param {null | string} [args.verifyGroup=null] - group to verify in the drop list of category or keyword
         * @param {null | string} [args.subcategory=null] - Subcategory to browse
         * @param {null | string} [args.verifyTerm=null] - term to verify in results of subcategory
         */
        mapBrowse: function mapBrowse(args) {
            args = UIAUtilities.defaults(args, {
                mapMode:            maps.MAPMODE.Map,
                searchTerm:         '1 Infinite Loop Cupertino, CA',
                browseTerm:         'Drinks',
                browseCategory:     true,
                verifyGroup:        null,
                subcategory:        null,
                verifyTerm:         null,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapBrowse(args);
      },

        /**
         * Searches the map for given terms in order
         *
         * @targetApps Maps
         *
         * @param {object}          args Test arguments
         * @param {string}          [args.searchTerm="Cupertino, CA"] - Term to search for in map
         * @param {string}          [args.mapMode="Map"] - Mode of the map to select, one of maps.MAPMODE.*
         * @param {null | string}   [args.partialTermCompletion=null] - If set, an element that should be tapped to complete the search using suggestions
         * @param {boolean}         [args.multipleResults=false] Whether to expect multiple results
         * @param {null | string}   [args.verifyTermInCallout="Cupertino, CA"] - Term to use for verification of results in callout
         *                                                                        If null, do not verify the result.
         */
        mapSearch: function mapSearch(args) {
            args = UIAUtilities.defaults(args, {
                searchTerm:             'Cupertino, CA',
                mapMode:                maps.MAPMODE.Map,
                partialTermCompletion:  null,
                verifyTermInCallout:   'Cupertino, CA',
                multipleResults:        false,
            });

            var options = {
                partialTermCompletion:  args.partialTermCompletion,
                verifyTermInCallout:    args.verifyTermInCallout,
                multipleResults:        args.multipleResults,
            };

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapSearch(args.searchTerm, options);
            maps.verifySearchResults(options);
        },

        /**
         * Pans the view over the map in the given mode
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Satellite"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.term="Cupertino, CA"] - Search term to use to set the map view region
         */
        panMapView: function panMapView(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Satellite,
                term: "Cupertino, CA",
            });

            maps.setMapMode(args.mapMode);
            maps.performMapSearch(args.term);

            maps.panMapLeft();
            maps.panMapUp();
            maps.panMapRight();
            maps.panMapDown();
        },

        /**
         * Open URL in Safari. Verify the link will lead to a location or route in Maps.
         *
         * @targetApps Maps, Safari
         *
         * @param {object} args Test arguments
         * @param {array} [args.url="http://maps.apple.com/?q=1+Infinite+Loop+Cupertino"] - the url to input in Safari
         * @param {null | string}   [args.termToVerify="1 Infinite Loop"] - Term to use for verification of results in callout
         *                                     If null, instead of verifying the results verify route is loaded.
         * @param {null | string} [args.routeModeToVerify=null] - Mode of the route to verify, must be a maps.ROUTEMODE.*
         *                                     If null, it will not verify route loaded.
         *                                     Also if routeModeToVerify is set then termToVerify, endLocation and startLocation location must be provided.
         * @param {null | string} [args.startLocation=null] - Start location for the route. In case of quick route verification this would be overwritten to "Current Location"
         * @param {null | string} [args.endLocation=null] - End location for the route.
         *
         */
        processMapsUrl: function processMapsUrl(args) {
            args = UIAUtilities.defaults(args, {
                url: ["http://maps.apple.com/?q=1+Infinite+Loop+Cupertino"],
                termToVerify: ["1 Infinite Loop"],
                routeModeToVerify: null,
                startLocation: null,
                endLocation: null,
            });

            MapsTests._testCaseInit();
            maps.launchFromSafari(args.url);

            if (args.termToVerify) {
                maps.verifySearchResults({verifyTermInCallout: args.termToVerify});
            }
            else if (args.routeModeToVerify) {
                UIAUtilities.assert(maps.getRouteMode() === args.routeModeToVerify, 'Unmatched route mode');
                args.startLocation = args.startLocation ? args.startLocation : LocStrings.CURRENT_LOCATION;
                maps.verifyRouteLoaded(args.startLocation, args.endLocation);
            }
        },

        /**
         * Removes all screenshots in the maps screenshots folder
         *
         * @targetApps Maps
         *
         */
        removeMapsScreenshots: function removeMapsScreenshots() {
            maps.removeMapsScreenshots();
        },

        /**
         * Get to Report an Issue menu and verify if the given elements exist in the UI.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {array} [args.elementsToVerify=["Incorrect label on map","Location is missing"]] - array of elements to verify in the report an issue screen.
         * @param {null | string} [args.searchTerm=null] - OPTIONAL: the location to search to get to place card. If it's null, it will get to RAP via setting.
         * @param {null | string} [args.placecardName=null] - The placecard name to query for search result verification
         */
        reportAProblem: function reportAProblem(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                elementsToVerify: ['Incorrect label on map','Location is missing'],
                searchTerm: null,
                placecardName: null,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});

            // if searchTerm is provided then go to place card first
            if (args.searchTerm) {
                maps.performMapSearch(args.searchTerm)
                maps.verifySearchResults({verifyTermInCallout: args.placecardName});
                maps.goToPlacecardForMapElement();
            }
            maps.goToState(UIStateDescription.Maps.REPORT_A_PROBLEM);

            // verify each element one by one
            var results = true;
            for ( var index = 0; index < args.elementsToVerify.length; index++) {
                if (!maps.verifyTableElementNames([args.elementsToVerify[index]])) {
                    results = false;
                }
            }
            UIAUtilities.assert(results, 'One or more elements were not found.');
        },

        /**
         * Selects a single map mode from the settings menu
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Satellite"] - Mode of the map to select, one of maps.MAPMODE.*
         */
        selectMapMode: function selectMapMode(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Satellite,
            });

            maps.setMapMode(args.mapMode);
        },

        /**
         * Go to Maps and tap share button
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         */
        share: function share(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.goToState(UIStateDescription.Maps.SHARE_SHEET);
            maps.goToState(UIStateDescription.Maps.MAP);
        },

        /**
         * Shares a location result from a search via a given sharing method. Assumes that
         * appropriate accounts have been setup before test run.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.term="Cupertino, CA"] - Search term for the shared location
         * @param {string} [args.sharingMethod="Mail"] - Sharing method to use, must be maps.SHARINGMETHOD.*
         */
        shareLocation: function shareLocation(args) {
            args = UIAUtilities.defaults(args, {
                term: "Cupertino, CA",
                sharingMethod: maps.SHARINGMETHOD.Mail,
            });

            // Search for location
            maps.performMapSearch(args.term);
            // Tap share
            maps.performShareSheetAction(args.sharingMethod);

            var date = new Date();
            var shareSubject = "Mail Location at " + date.getTime();
            if (args.sharingMethod === maps.SHARINGMETHOD.Mail) {
                target.activeApp().composeEmail(springboard.appleID,
                                                {subject: shareSubject,
                                                body: "This is a test email sent for automation purposes.",});
            } else if (args.sharingMethod === maps.SHARINGMETHOD.Messages) {
                // TODO: Messages logic
            } else if (args.sharingMethod === maps.SHARINGMETHOD.Twitter) {
                // TODO: Twitter
            } else if (args.sharingMethod === maps.SHARINGMETHOD.Facebook) {
                // TODO: Facebook
            }
        },

        /**
         * Uses the 'Show Traffic' option to display traffic for a given location.
         *
         * @targetApps Maps
         *
         * @param {object}  args Test arguments
         * @param {string}  [args.mapMode="Map"] - Mode of the map to select, one of maps.MAPMODE.*
         * @param {string}  [args.searchTerm="Los Angeles, CA"] - term to search for in map
         */
        showTraffic: function showTraffic(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                searchTerm: 'Los Angeles, CA',
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapSearch(args.searchTerm);
            maps.setTrafficMode(maps.TRAFFICMODE.Show);
            maps.goToState(UIStateDescription.Maps.MAP);
            maps.captureMapsScreenshot('Show_Traffic_%0_%1'.format(args.mapMode, args.searchTerm).replace(/ |,/g, ''));
        },

        /**
         * Calls Siri with the recording and do a search, verify to return to maps
         *  with relevant results.
         * @param {string} [args.siriRecording="/var/mobile/Media/English_FindMeAnAppleStore.spx"]
         *                      - Siri recording file with its path to search a term
         * @param {string} [args.verifyTerm="Apple Store"] - Term to verify in Maps
         */
        siriSearch: function siriSearch(args) {
            args = UIAUtilities.defaults(args, {
                mapMode:        maps.MAPMODE.Map,
                siriRecording:  '/var/mobile/Media/English_FindMeAnAppleStore.spx',
                verifyTerm:     'Apple Store',
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.launchFromSiri(args.siriRecording);
            maps.verifySearchResults({multipleResults:true, verifyTermInAllResults:args.verifyTerm});
        },

        /**
         * Start navigation and verify live/stepping navigation state.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.startLocation="Current Location"] - Start location for the route
         * @param {string} [args.endLocation="Oakland, CA"] - End location for the route
         * @param {string} [args.routeMode="Drive"] - Mode of the route to select, must be a maps.ROUTEMODE.*
         * @param {boolean} [args.liveNavShouldStart=true] - Whether or not to confirm that live nav started. (Will override start location to use Current Location)
         */
        startNavigation: function startNavigation(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                startLocation: 'Current Location',
                endLocation: 'Oakland, CA',
                routeMode: maps.ROUTEMODE.Driving,
                liveNavShouldStart: true,
            });

            if (args.liveNavShouldStart) {
                args.startLocation = LocStrings.CURRENT_LOCATION;
            }

            MapsTests.getDirections({
                mapMode: args.mapMode,
                startLocation: args.startLocation,
                endLocation: args.endLocation,
                routeModeToSet: args.routeMode,
                routeModeToVerify: args.routeMode,
            });
            maps.startNavigation();
            var navMode = maps.NAVIGATIONMODE.Live;
            if (!args.liveNavShouldStart) {
                navMode = maps.NAVIGATIONMODE.Stepping;
            }
            maps.verifyNavigationMode(navMode);
        },

        /**
         * Launch, suspend and resume maps app.
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {number} [args.suspendDurationInSeconds=3] - seconds to wait before reactivating the app.
        **/
        suspendResume: function suspendResume(args) {
            args = UIAUtilities.defaults(args, {
                suspendDurationInSeconds: 3,
            });
            MapsTests._testCaseInit();

            // <TODO> rdar://problem/22387988 - Use deactivateForDuration() instead once this radar got fixed

            // Press home button
            target.clickMenu();

            // Wait before launching the app
            target.delay(args.suspendDurationInSeconds);

            maps.launch();
        },

        /**
         * Toggles on and off Traffic view on the given map view mode
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be either maps.MAPMODE.Map or maps.MAPMODE.Satellite
         */
        toggleTrafficMode: function toggleTrafficMode(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
            });

            if (args.mapMode !== maps.MAPMODE.Map && args.mapMode !== maps.MAPMODE.Satellite) {
                throw new UIAError("Traffic is only available in Map and Satellite modes.");
            }

            options = {};
            options.mapMode = args.mapMode;

            MapsTests._testCaseInit(options);
            maps.setTrafficMode(maps.TRAFFICMODE.Show);
            maps.setTrafficMode(maps.TRAFFICMODE.Hide);
        },

        /**
         * Verify the Favorites View
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         */
        verifyFavoritesView: function verifyFavoritesView(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.goToState(UIStateDescription.Maps.FAVORITES_LIST);
            maps.verifyFavoritesViewToolbar();
        },

        /**
         * Search a POI, open placecard, verify all the elements are present
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.mapMode="Map"] - Mode of the map to select, must be a maps.MAPMODE.*
         * @param {string} [args.searchTerm="Little sheep, Cupertino"] - term to search
         * @param {string} [args.placecardName="Little Sheep Mongolian Hot Pot"] - The placecard name to query for verification
         * @param {array} [args.elementsToVerify=[["Directions","Driving"],["Address","19062 Stevens Creek Blvd Cupertino"], ["Phone"]]]
         *                      - array of groups of elements to verify in the placecard.
         */
        verifyPlacecardElements: function verifyPlacecardElements(args) {
            args = UIAUtilities.defaults(args, {
                mapMode:        maps.MAPMODE.Map,
                searchTerm:     'Little sheep, Cupertino',
                placecardName:  'Little Sheep Mongolian Hot Pot',
                elementsToVerify:[['Directions', 'Driving'],
                                  ['Address', '19062 Stevens Creek Blvd Cupertino'],
                                  ['Phone'],
                                 ],
            });

            // Validate preconditions
            UIAUtilities.assert(args.elementsToVerify instanceof Array, '"%0" should be an array'.format(args.elementsToVerify));

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapSearch(args.searchTerm);
            maps.verifySearchResults({verifyTermInCallout: args.placecardName});
            maps.goToPlacecardForMapElement();

            var found = true, groupIndex = 0;
            while (groupIndex < args.elementsToVerify.length) {
                if(!maps.verifyTableElementNames(args.elementsToVerify[groupIndex])) {
                    found = false;
                }
                groupIndex++;
            }
            UIAUtilities.assert(found, 'One or more placecard elements not found');
        },

        /**
         * Sets a map mode, Searches the map for a given term, Verifies the map mode is correct
         *
         * @targetApps Maps
         *
         * @param {object}  args Test arguments
         * @param {string}  [args.mapMode="Map"] - Mode of the map to select, one of maps.MAPMODE.*
         * @param {string}  [args.searchTerm="Cupertino, CA"] - term to search for in map
         */
        verifyViews: function verifyViews(args) {
            args = UIAUtilities.defaults(args, {
                mapMode: maps.MAPMODE.Map,
                searchTerm: 'Cupertino, CA',
            });

            MapsTests._testCaseInit({mapMode: args.mapMode});
            maps.performMapSearch(args.searchTerm);
            maps.captureMapsScreenshot('Verify_Views_%0_%1'.format(args.mapMode, args.searchTerm).replace(/ |,/g, ''));
            UIAUtilities.assert(maps.getMapMode() === args.mapMode, 'Unmatched map mode');
        },

        /**
         * Open placecard for a given search term
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {string} [args.term="Cupertino, CA"] - Search term to get details on
         */
        viewMapPlacecard: function viewMapPlacecard(args) {
            args = UIAUtilities.defaults(args, {
                term: "Cupertino, CA",
            });

            maps.performMapSearch(args.term);
            maps.verifySearchResults({verifyTermInCallout: args.term});
            maps.goToPlacecardForMapElement();
        },

        /**
         * Zooms the map view in
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {number} [args.count=1] - Number of times to zoom in
         */
        zoomIn: function zoomIn(args) {
            args = UIAUtilities.defaults(args, {
                count: 1,
            });

            maps.goToState(UIStateDescription.Maps.MAP);

            for (var i = 0; i < args.count; i++) {
                maps.zoomMapIn();
            }
        },

        /**
         * Zooms the map view out
         *
         * @targetApps Maps
         *
         * @param {object} args Test arguments
         * @param {number} [args.count=1] - Number of times to zoom out
         */
        zoomOut: function zoomOut(args) {
            args = UIAUtilities.defaults(args, {
                count: 1,
            });

            maps.goToState(UIStateDescription.Maps.MAP);

            for (var i = 0; i < args.count; i++) {
                maps.zoomMapOut();
            }
        },

    }
}
