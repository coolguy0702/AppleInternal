App/Project/Feature: Maps Analytics
Maintainer(s): Yushu Li
Maintainer(s) Email: yushu_li@apple.com
Maintainer(s) Team: Maps Eval
Maintainer(s) Team Manger: Andy Jenness
Maintainer(s) Team Manger Email: ajenness@apple.com

Scripts include performing analytics UI tests for Maps.
The tests take the UI elements as parameters and eval them.
Pre-process and post-process are included in CAE.