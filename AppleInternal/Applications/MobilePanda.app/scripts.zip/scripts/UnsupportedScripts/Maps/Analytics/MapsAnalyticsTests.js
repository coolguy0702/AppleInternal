load('UIATesting.js');
load('MapsAnalytics.js');


UIAUtilities.assert(
    typeof MapsAnalyticsTests === 'undefined',
    'MapsAnalyticsTests has already been defined.'
);


/**
 * @namespace MapsAnalyticsTests
 */
var MapsAnalyticsTests = {

    /**
     * Launch from spotlight and perform the given actions.
     *
     * @targetApps Maps
     *
     * @param {object} args Test arguments
     * @param {string} [args.searchString="SFO Maps"] - the string to search for in spotlight
     * @param {array} [args.actions_params=["UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().below('MAPS').above('UITableViewSectionElement').orElse(UIAQuery.tableCells().below('MAPS'))).first()", "tap:UIAQuery.Maps.GET_DIRECTIONS_BUTTON:60"]]
     *                  - an array of actions and params to execute
     *                  if the action is missing, the default is "tap". */
    launchFromSpotlight: function launchFromSpotlight(args) {
        args = UIAUtilities.defaults(args, {
            searchString:   'SFO Maps',
            actions_params:        [{name: 'tap',
                              resultCategory: 'Maps',
                              resultPredicate: 'San Francisco International Airport',
                            }],
        });

        maps.launchFromSpotlightForAnalytics(args);
    },

    /**
     * Launch with URL and perform the given actions.
     *
     * @targetApps Maps
     *
     * @param {object} args Test arguments
     * @param {string} [args.url="http://maps.apple.com/?t=m"] - url to get to a specific maps UI
     * @param {array}  [args.actions_params=["tap:UIAQuery.Maps.SETTINGS_BUTTON", "tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON"]]
     *                  - an array of actions and params to execute
     *                  if the action is missing, the default is "tap".
     */
    launchWithUrl: function launchWithUrl(args) {
        args = UIAUtilities.defaults(args, {
            url:            'http://maps.apple.com/?t=m',
            actions_params: ['tap:UIAQuery.Maps.SETTINGS_BUTTON',
                             'tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON'],
        });

        maps.launchWithURLForAnalytics(args);
    },

    /**
     * Drop pin in the given mode and tap the dropped pin
     *
     * @targetApps Maps
     *
     * @param {object} args Test argument
     * @param {string} [args.url="http://maps.apple.com/?t=m"] - url to get to a specific maps UI
     */
    tapDroppedPin: function tapDroppedPin(args) {
        args = UIAUtilities.defaults(args, {
            url: 'http://maps.apple.com/?t=m',
        });

        maps.tapDroppedPin(args);
    },

    /**
     * Tear down the test. Get to search and quit maps.
     *
     * @targetApps Maps
     */
    tearDown: function tearDown() {
        maps.getToSearch();
        maps.quit();
    },
};
