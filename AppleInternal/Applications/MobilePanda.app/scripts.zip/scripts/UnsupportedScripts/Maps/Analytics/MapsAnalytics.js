load('Maps.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

// Analytics actions
maps.ANALYTICSACTION                = {};
maps.ANALYTICSACTION.exists         = 'target.activeApp().exists'
maps.ANALYTICSACTION.scroll         = 'target.activeApp().scrollToVisible'
maps.ANALYTICSACTION.scrollDown     = 'target.activeApp().scrollDown'
maps.ANALYTICSACTION.scrollUp       = 'target.activeApp().scrollUp'
maps.ANALYTICSACTION.tap            = 'target.activeApp().tap'
maps.ANALYTICSACTION.tapIfExists    = 'target.activeApp().tapIfExists'
maps.ANALYTICSACTION.wait           = 'target.delay'
maps.ANALYTICSACTION.exit           = 'target.activeApp().quit'
maps.ANALYTICSACTION.home           = 'target.clickMenu'
maps.ANALYTICSACTION.pullTray       = 'maps.setCardPosition'
maps.ANALYTICSACTION.panUp          = 'maps.panMapUp'
maps.ANALYTICSACTION.panDown        = 'maps.panMapDown'
maps.ANALYTICSACTION.panLeft        = 'maps.panMapLeft'
maps.ANALYTICSACTION.panRight       = 'maps.panMapRight'
maps.ANALYTICSACTION.pitchUp        = 'maps.pitchMapUp'
maps.ANALYTICSACTION.pitchDown      = 'maps.pitchMapDown'
maps.ANALYTICSACTION.rotate         = 'maps.rotateMap'
maps.ANALYTICSACTION.zoomIn         = 'maps.zoomMapIn'
maps.ANALYTICSACTION.zoomOut        = 'maps.zoomMapOut'
maps.ANALYTICSACTION.setControlOn   = 'maps.setControlOn'
maps.ANALYTICSACTION.setControlOff  = 'maps.setControlOff'

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. These take care of reaching */
/*      the appropriate views (e.g. - performMapSearch)                            */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Launch from spotlight and perform the given actions.
 *
 * @param {object} options An options dictionary
 * @param {string} [options.searchString="SFO Maps"] - the string to search for in spotlight
 * @param {array} [options.actions_params=["UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().below('MAPS').above('UITableViewSectionElement').orElse(UIAQuery.tableCells().below('MAPS'))).first()", "UIAQuery.Maps.GET_DIRECTIONS_BUTTON"]]
 *                  - an array of actions and params to execute
 *                  if the action is missing, the default is "tap".
 * @param {integer} [options.wait_timeout=10] - time out in seconds to wait for UI element to be present
 * @param {integer} [options.interval_between_operations=2] - time out in seconds as interval between UI operations
 */
maps.launchFromSpotlightForAnalytics = function launchFromSpotlightForAnalytics(options) {
    options = UIAUtilities.defaults(options, {
        searchString:   'SFO Maps',
        actions_params: ['UIAQuery.tableViews().isVisible().andThen(UIAQuery.tableCells().below("MAPS").above("UITableViewSectionElement").orElse(UIAQuery.tableCells().below("MAPS"))).first())',
                         'UIAQuery.Maps.GET_DIRECTIONS_BUTTON'],
        wait_timeout:   10,
        interval_between_operations: 2,
    });

    // launches maps from spotlight
    springboard.launch();
    springboard.parsecSearch(options.searchString);

    // parses and performs actions
    this.parseAndPerformActions(options);
};

/**
 * Launch with URL and perform the given actions.
 *
 * @param {object} options An options dictionary
 * @param {string} [options.url="http://maps.apple.com/?t=m"] - url to get to a specific maps UI
 * @param {array} [options.actions_params=["tap:UIAQuery.Maps.SETTINGS_BUTTON", "tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON"]]
 *                  - an array of actions and params to execute
 *                  if the action is missing, the default is "tap".
 * @param {integer} [options.wait_timeout=10] - time out in seconds to wait for UI element to be present
 * @param {integer} [options.interval_between_operations=2] - time out in seconds as interval between UI operations
 */
maps.launchWithURLForAnalytics = function launchWithURLForAnalytics(options) {
    options = UIAUtilities.defaults(options, {
        url:            'http://maps.apple.com/?t=m',
        actions_params: ['tap:UIAQuery.Maps.SETTINGS_BUTTON',
                         'tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON'],
        wait_timeout:   10,
        interval_between_operations: 2,
    });

    // launches maps with url
    this.quitAndLaunchWithURLForAnalytics(options);
    // parses and performs actions
    this.parseAndPerformActions(options);
};

/**
 * Quit maps and launch with URL.
 *
 * @param {object} options An options dictionary
 * @param {string} [options.url="http://maps.apple.com/?t=m"] - url to get to a specific maps UI
 */
maps.quitAndLaunchWithURLForAnalytics = function quitAndLaunchWithURLForAnalytics(options) {
    options = UIAUtilities.defaults(options, {
        url:  'http://maps.apple.com/?t=m',
    });

    // quits and re-launches maps with url
    if (options.url && options.url != '') {
        // quits maps and safari to initialize
        try {
            this.quit();
        } catch(e) {
            UIALogger.logMessage(e);
        }
        this.launchWithURL(options);
    }
};

/**
 * Drop pin in the given mode and tap the dropped pin
 *
 * @param {object} options Test argument
 * @param {string} [options.url="http://maps.apple.com/?t=m"] - url to get to a specific maps UI
 */
maps.tapDroppedPin = function tapDroppedPin(options) {
    options = UIAUtilities.defaults(options, {
        url: 'http://maps.apple.com/?t=m',
    });

    this.quitAndLaunchWithURLForAnalytics(options);
    this.dropPinAndVerify({mapViewOffsetX: 0.4, mapViewOffsetY: 0.6});
    this.tapIfExists(UIAQuery.Maps.CLOSE_BUTTON);
    this.tap(UIAQuery.query('VKMapView').andThen(UIAQuery.beginsWith(LocStrings.Maps.MARKED_LOCATION)));
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Parse and Perform the Given Actions
 *
 * @param {object} options An options dictionary
 * @param {array} [options.actions_params=["tap:UIAQuery.Maps.SETTINGS_BUTTON", "tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON"]]
 *                  - an array of actions and params to execute
 *                  if the action is missing, the default is "tap".
 * @param {integer} [options.wait_timeout=10] - time out in seconds to wait for UI element to be present
 * @param {integer} [options.interval_between_operations=2] - time out in seconds as interval between UI operations
 */
maps.parseAndPerformActions = function parseAndPerformActions(options) {
    options = UIAUtilities.defaults(options, {
        actions_params: ['tap:UIAQuery.Maps.SETTINGS_BUTTON',
                         'tap:UIAQuery.Maps.MODE_TRANSIT_BUTTON'],
        wait_timeout:   10,
        interval_between_operations: 2,
    });

    // parses and performs actions
    for (var i = 0; i < options.actions_params.length; i++) {
        var action = this.ANALYTICSACTION.tap;
        var param = '';
        var temp_action = '';
        var timeout = options.wait_timeout;
        var action_param_pairs = options.actions_params[i].split(':');
        if (action_param_pairs.length === 1) {
            param = action_param_pairs[0];
        } else if (action_param_pairs.length === 2) {
            temp_action = action_param_pairs[0];
            param = action_param_pairs[1];
        } else if (action_param_pairs.length === 3) {
            temp_action = action_param_pairs[0];
            param = action_param_pairs[1];
            timeout = parseInt(action_param_pairs[2], 10);
        } else {
            throw new UIAError('wrong format of action and param');
        }
        if (temp_action) {
            try {
                action = this.ANALYTICSACTION[temp_action];
            } catch (e) {
                throw new UIAError('"%0" is not supported'.format(temp_action));
            }
        }
        // peforms the actions
        if (action == this.ANALYTICSACTION.wait || action == this.ANALYTICSACTION.pullTray) {
            eval('%0(param)'.format(action));
        } else if (param == '') {
            eval('%0()'.format(action));
        } else {
            param = eval(param);
            target.activeApp().waitUntilPresent(param, timeout);
            eval('%0(param)'.format(action));
        }
        // delay a bit between operations
        if (i < options.actions_params.length) {
            target.delay(options.interval_between_operations);
        }
    }
};

/**
 * Set the given control off
 *
 * @param {object} options An options dictionary
 * @param {string} UIAQuery of a control to set off
 */
maps.setControlOff = function setControlOff(control) {
    this.setControl(control, false);
};

/**
 * Set the given control on
 *
 * @param {object} options An options dictionary
 * @param {string} UIAQuery of a control to set on
 */
maps.setControlOn = function setControlOn(control) {
    this.setControl(control, true);
};
