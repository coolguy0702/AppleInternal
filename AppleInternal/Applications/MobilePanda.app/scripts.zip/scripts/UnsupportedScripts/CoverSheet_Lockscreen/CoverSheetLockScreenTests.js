load('UIATesting.js');
load('CoverSheetLockScreen.js');
load('SpringBoard+InCallServices.js');
load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");

UIAUtilities.assert(typeof CoverSheetTests === 'undefined', 'CoverSheetTests has already been defined.')

/** @namespace */

CoverSheetTests = {
    /**
     * Navigates through the notificaiton center UI  from Lockscreen
     */
    navigateNotificationCenter: function navigateNotificationCenter() {
        coversheet.launch();

        if (!coversheet.getToNotifications()) {
            throw new UIAError("Did not get to notification center from Lockscreen");
        }

        target.clickMenu();
        
    },
    /**
     * Navigates through the Widgets view UI
     */
    navigateWidgetsView: function navigateWidgetsView() {
        coversheet.launch();

        if (!coversheet.getToWidgets()) {
            throw new UIAError("Did not get to Widgets view");
        }

        target.clickMenu();
    },
    /**
     * Navigates through the Camera view UI
     * @param {object} args  Test arguments
     * @param {string} [args.passcode="111111"] - Device Passcode
     */
    navigateCameraView: function navigateCameraView() {
        var args = UIAUtilities.defaults(args, {
            passcode: '111111',
        });

        coversheet.launch();

        if (!coversheet.getToCamera(args)) {
            throw new UIAError('Failed to navigate to Camera view');
        }
    },
    /**
     * Verify that a widget is enabled or disabled in the Today View
     * @param {object} args  Test arguments
     * @param {array} [args.widgets=["Up Next", "Siri App Suggestions", "Weather", "Maps destinations", "Tips"]] - Title of widget displayed in Today view
     * @param {boolean} [args.enabled=true] - Flag indicating whether the widget should be enabled.
     * @param {string} [args.passcode="111111"] - Device Passcode
     */
    verifyWidgetEnabledOrDisabled: function verifyWidgetEnabledOrDisabled() {
        var args = UIAUtilities.defaults(args, {
                widgets:[
                    "Up Next",
                    "Siri App Suggestions",
                    "Weather", 
                    "Maps destinations",  
                    "Tips",
                ],
                enabled : true,
                passcode: '111111',
        });
        
        var index;

        for (index = 0; index < args.widgets.length; index++) {
            UIAUtilities.assertEqual(args.enabled, coversheet.isWidgetEnabled(args.widgets[index]));

            UIALogger.logMessage('%0 Widget is enabled'.format(args.widgets[index]));
        }

        target.systemApp().unlock({passcode:args.passcode});
    },
}