load('UIAUtility.js');
load("UIAApp.js");
load("UIAApp+Parsec.js");

UIAUtilities.assert(typeof coversheet === 'undefined', 'CoverSheetTests has already been defined.')

/**
 @namespace
 @augments UIASystemApp
 */

var coversheet = target.systemApp();

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

UIAQuery.CoverSheet = {
    /** Notfiication Center */
    NOTIFICATION_CENTER:        UIAQuery.query('SBSearchEtceteraNotificationsLayoutContentView'),

    /** Today View */
    TODAY_VIEW:                 UIAQuery.query('SBSearchEtceteraTodayLayoutContentView').orElse('WGMajorListViewControllerView'),

    /** Cover Sheet */
    COVER_SHEET:                 UIAQuery.query("SBCoverSheetWindow"),

}

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */

var UIStates = {
    /** Root icon view */
    ROOT_ICON_VIEW: {
        Description: 'Root Icon View',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.query('SBRootIconListView').isVisible());
        },
    },

    /** Notification Center */
    NOTIFICATION_CENTER: {
        Description: 'Notification Center',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.CoverSheet.NOTIFICATION_CENTER);
        },
    },

    /** Today View */
    TODAY_VIEW: {
        Description: 'Today View',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.CoverSheet.TODAY_VIEW.isVisible());
        },
    },

    /** Bulletin Window */
    BULLETIN_WINDOW: {
        Description: 'Bulletin Window',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.CoverSheet.BULLETIN_WINDOW);
        },
    },

    /** Cover sheet */
    COVER_SHEET: {
        Description: 'Cover Sheet',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.CoverSheet.COVER_SHEET);
        },
    },
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State                                                    */
/*                                                                             */
/*      A function to determine which UI state the app is currently in         */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.  See UIStateDescription constants defined in UIAApp and SpringBoard for possible values.
*
* @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
coversheet.currentUIState = function currentUIState() {
    // Grab a snapshot to feed to the isCurrentState functions of the State objects
    var snapshot = this.inspect(UIAQuery.application());

    // List of all the state objects
    var states = Object.keys(UIStates).map(function (key) {
        return UIStates[key];
    });

    /*
    * For each state, check if we're in that state
    * using the isCurrentState function and the snapshot
    * If we are then log and return the State's description
    */
    for (i = 0; i < states.length; i++) {
        var state = states[i];
        if (state.isCurrentState(snapshot)) {
            var stateName = state.Description;
            UIALogger.logMessage('Currently in state "%0"'.format(stateName));
            return stateName;
        }
    }

    // if we got here, we don't have any idea where we are...
    throw new UIAError('Could not determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [state]                                                      */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Navigates to Notification Center from Lockacreen
 * @param {object} args
 * @param {string} [args.Passcode="111111"] - Device Passcode
 * @returns {boolean} true if Notification Center is active
 */
coversheet.getToNotifications = function getToNotifications() {
    var args = UIAUtilities.defaults(args, {
        passcode: '111111',
    });

    target.systemApp().lock();

    target.clickLock();

    target.systemApp().swipeUp(UIAQuery.query("SBPagedScrollView"));

    if (UIStates.TODAY_VIEW.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Got to Today View. Attempting to navigate to Notification Center');

        this.swipeFromRightEdge();

        target.activeApp().unlock(args);
    }
    if (UIStates.COVER_SHEET.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Successfully navigated to Notification Center from Lockscreen');

        target.activeApp().unlock(args);

        return true;
    } else {
        throw new UIAError ('Failed to navigate to Notification Center from Lockscreen');

        target.activeApp().unlock(args);
    }
}
/**
 * Navigates to Widget view
 * @param {object} args
 * @param {string} [args.Passcode="111111"] - Device Passcode
 * @returns {boolean} true if Notification Center is active
 */
coversheet.getToWidgets = function getToWidgets() {
    var args = UIAUtilities.defaults(args, {
        passcode: '111111',
    });

    target.systemApp().lock();

    target.clickLock();

    this.swipeFromLeftEdge();

    if (UIStates.TODAY_VIEW.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Successfully navigated to Widgets view from Lockscreen');

        target.activeApp().unlock(args);

        return true;
    } else {
        throw new UIAError ('Failed to navigate to Widgets view from Lockscreen');

        target.activeApp().unlock(args);
    }
}   

/**
 * Navigates to Camera view
 * @param {object} [args] - Test arguments
 * @param {string} [args.passcode] - Device's passcode 
 * @returns {boolean} true if successfully navigated to Camera view, false otherwise
 */
coversheet.getToCamera = function getToCamera(args) {
    target.systemApp().lock();

    target.clickLock();

    var cameraWaiter = UIAWaiter.waiter('CameraIrisOpened');
    this.swipeFromRightEdge();

    var waitRes = cameraWaiter.wait(10.0);
    var isCameraOpen = target.appWithBundleID('com.apple.camera').isCameraIrisOpen();
    UIALogger.logDebug('waitRes = %0; isCameraOpen = %1'.format(waitRes, isCameraOpen));

    // Clean up before returning to make sure that Camera is not running and the device is unlocked
    target.clickLock(); //Locking/Unlocking the phone here so workaround fail in unlocking the phone when target.clickmenu() is invoked
    target.systemApp().unlock({passcode: args.passcode});

    if (!waitRes && !isCameraOpen) {
        UIALogger.logError('Failed to navigate to Camera view');
        return false;
    } else {
        UIALogger.logMessage('Successfully navigated to Camera view');
        return true;
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation and helper functions                     */
/*      These will assume the devices is already in the required state         */
/*                                                                             */
/*******************************************************************************/

/**
 * Check if a widget is enabled in the Today View
 *
 * @param {string} widget - Title of widget displayed in Today Viewe
 *
 * @returns {boolean} true on success, false otherwise
 */
coversheet.isWidgetEnabled = function isWidgetEnabled(widget) {
    target.systemApp().lock();

    target.clickLock();

    this.swipeFromLeftEdge();

    // this function checks against the name of the widget is present in UI, in some trains the name of the widget is in a Button instead of
    // element that's why checking against buttons names as well
    return this.exists(UIAQuery.CoverSheet.TODAY_VIEW.andThen(widget.toUpperCase()).orElse(UIAQuery.buttons(widget.toUpperCase())) );
};