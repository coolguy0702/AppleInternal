App/Project/Feature: CoverSheet from Lockscreen
Maintainer(s): Wissam Alazzam
Maintainer(s) Email: walzzam@apple.com
Maintainer(s) Team: OSBQ - Cork 
Maintainer(s) Team Manager: John O'Hara
Maintainer(s) Team Manager Email: john_a_ohara@apple.com
Radar Component: OSBQ Automation | iOS
Scripts for Coversheet test case in OSBQ sanity checks.
