/**
 * Created by Reema on 11/06/17.
 */
load('Setup.js');
load('BuddyConstants.js');
load('iCloud+Buddy.js');



if (typeof pepsetup === 'undefined') {
    /**
     @namespace
     @augments UIAApp
     */
    var pepsetup = target.appWithBundleID("com.apple.purplebuddy");
}

/**
 * Goes through buddy until we see Privacy policy page
 * @param wifiNetwork
 * @param wifiPassword
 * @param {string} [args.passcode=""]
 */
pepsetup.getToPrivacyPage = function getToPrivacyPage (wifiNetwork, wifiPassword) {
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    targetState: UIStateDescription.Setup.PRIVACY_SPLASH
    };
    setup.navigateSetupBuddy(options);
}

/**
 * Goes through buddy until we see iCloud sign in page
 * @param wifiNetwork
 * @param wifiPassword
 * @param passcode
 */
pepsetup.getToiCloudPage = function getToiCloudPage (wifiNetwork, wifiPassword, passcode) {
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    targetState: UIStateDescription.Setup.APPLE_ID_SIGN_IN
    };
    setup.navigateSetupBuddy(options);
}


/**
 * Goes through buddy until we see iCloud sign in page
 * @param wifiNetwork
 * @param wifiPassword
 * @param passcode
 */
pepsetup.getToTermsAndConditionsPage = function getToTermsAndConditionsPage (wifiNetwork, wifiPassword, passcode){
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    targetState: UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS
    };
    setup.navigateSetupBuddy(options);
}

/**
 * Goes through buddy until we see iCloud sign in page
 * @param wifiNetwork
 * @param wifiPassword
 * @param passcode
 * @param enableLocationServices
 */
pepsetup.getToLocationServicePage = function getToLocationServicePage (wifiNetwork, wifiPassword, passcode, enableLocationServices){
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    enableLocationServices: enableLocationServices,
    targetState: UIStateDescription.Setup.LOCATION_SERVICES
    };
    UIALogger.logDebug("On Location service screen");
    setup.navigateSetupBuddy(options);
}

pepsetup.getToApplePay = function getToApplePay (wifiNetwork, wifiPassword, passcode) {
    
    UIALogger.logDebug("inside get to apple pay");
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    targetState: UIStateDescription.Setup.APPLE_PAY_DESC
    };
    setup.navigateSetupBuddy(options);
}


/**
 * Creates HSA2 account from Buddy
 * @param appleID
 * @param password
 * @param hsa2PhoneNumber
 * @param options
 */
pepsetup.pepCreateHSA2Account = function pepCreateHSA2Account (appleID, password, hsa2PhoneNumber, options) {
    options = UIAUtilities.defaults(options, {
        birthday: "April/1/1984", firstName: "SEAR", lastName: "Tester", emailUpdates: false, targetState: UIStateDescription.Setup.APPLE_PAY,
    });
    
    UIALogger.logDebug("Apple Id entered is - %0".format(appleID));
    UIALogger.logDebug("target State");
    UIALogger.logDebug(options.targetState);
    validateNonEmptyString(appleID,"Apple Id");
     validateNonEmptyString(password,"Password");
    validatePhoneNumber(hsa2PhoneNumber);
   validateNonEmptyString(options.firstName,"First name");
   validateNonEmptyString(options.lastName,"Last name");
    validateBirthday(options.birthday);
    var birthDay = options.birthday;
    
    app = target.activeApp();
    app.tap(UIAQueries.APPLE_ID_BUTTON);
    wait(20);
    app.tap("Create a Free Apple ID");
    wait(30);
    enterBirthday(birthDay);
  
    if(!app.waitUntilPresent(UIAQueries.NAME_SCREEN,60)){
        throw new UIAError("Page to enter name took longer than 1 minute to load.");
    }
    handleEnterNameScreen(options.firstName,options.lastName);

    this.waitUntilPresent(UIAQuery.Settings.FREE_NEW_APPLEID, 60);
    this.tap(UIAQuery.Settings.FREE_NEW_APPLEID);

    handleEnterEmailIdPageWhenCreatingNewAccount(appleID);
    //Focus is already on password text field. Enter password
    this.typeString(password);
    setup.enterText(UIAQuery.secureTextFields('retype password'), password);
    
    this.tap(UIAQueries.NEXT_BUTTON);
    
    if (this.waitUntilPresent(UIAQuery.staticTexts().contains("Enter a phone number"), 60)) {
        UIALogger.logDebug("On Enter phone number screen");
        setup.enterText(UIAQueries.REQUIRED_TEXTFIELD, hsa2PhoneNumber);
        UIALogger.logDebug("Entered phone number");
    }
    
    UIALogger.logDebug("Before calling handle2FA function");
    var verificationCode = handleTwoFA(hsa2PhoneNumber, function () {
        app.tap(UIAQueries.NEXT_BUTTON);
    });
    
    validate2FACode(verificationCode,6);
    
    UIALogger.logDebug("On Enter verification code screen");
    this.typeString(verificationCode);
    UIALogger.logDebug("Entered verification code- %0".format(verificationCode));
    
    if (this.waitUntilPresent(UIAQuery.Settings.TERMS_CONDITIONS, 30)) {
        this.tap(UIAQueries.AGREE_BUTTON);
    }
    
    if (this.waitUntilPresent(UIAQueries.APPLE_ID_SIGN_IN_PROCESSING_SCREEN, 300)) {
        if (!this.waitUntilAbsent(UIAQueries.APPLE_ID_SIGN_IN_PROCESSING_SCREEN, 600)) {
            throw new UIAError("Took longer than 10 minutes to sign into HSA2 account");
        }
    }
}



/**
 * Goes through buddy until we see iCloud sign in page
 * @param wifiNetwork
 * @param wifiPassword
 * @param passcode
 */
pepsetup.getToSiriPage = function getToSiriPage (wifiNetwork, wifiPassword, passcode) {
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    targetState: UIStateDescription.Setup.SIRI_ON_BOARDING
    };
    UIALogger.logDebug("On Siri screen");
    setup.navigateSetupBuddy(options);
}





pepsetup.getToAppAnalyticsPage = function getToAppAnalyticsPage (wifiNetwork, wifiPassword, passcode) {
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    targetState: UIStateDescription.Setup.APP_ANALYTICS
    };
    setup.navigateSetupBuddy(options);
}

pepsetup.getToiCloudAnalyticsScreen = function getToiCloudAnalyticsScreen (wifiNetwork, wifiPassword, passcode) {

    options = {
        wifiNetwork: wifiNetwork,
        wifiPassword: wifiPassword,
        passcode: passcode,
        targetState: UIStateDescription.Setup.APP_ANALYTICS
    };
    setup.navigateSetupBuddy(options);
}


pepsetup.getToFaceIDScreen = function getToFaceIDScreen (wifiNetwork, wifiPassword) {

    options = {
        wifiNetwork: wifiNetwork,
        wifiPassword: wifiPassword,
        targetState: UIStateDescription.Setup.PEARL_SPLASH
    };
    setup.navigateSetupBuddy(options);
}


pepsetup.getToNewHomeButtonIntro = function getToNewHomeButtonIntro (wifiNetwork, wifiPassword) {

    options = {
        wifiNetwork: wifiNetwork,
        wifiPassword: wifiPassword,
        targetState: UIStateDescription.NEW_HOME_BUTTON_INTRO
    };
    setup.navigateSetupBuddy(options);
}


pepsetup.getToSpringBoard= function getToSpringBoard (wifiNetwork, wifiPassword, passcode) {
    
    options = {
    wifiNetwork: wifiNetwork,
    wifiPassword: wifiPassword,
    passcode: passcode,
    passIfSetupDone: true,
    targetState: UIStateDescription.Setup.DONE
    };
    setup.navigateSetupBuddy(options);
}


pepsetup.verifyAndScreenShotFaceID = function verifyAndScreenShotFaceID() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.PEARL_SPLASH) {
        throw new UIAError("Expecting screen " + UUIStateDescription.Setup.PEARL_SPLASH);
        return false;
    }
    UIALogger.logDebug("On Face ID Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('2-FaceID.png');
    pepsetup.tap(SetupUIAQueries.ABOUTFACEID_BUTTON);
    pepsetup.delay(3);
    pepsetup.takeScreenShot('2.1-LearnMoreFaceID.png');
    pepsetup.containsMessages(FaceIdLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);

}


pepsetup.verifyAndScreenShotiCloud = function verifyAndScreenShotiCloud() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.APPLE_ID_SIGN_IN) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.APPLE_ID_SIGN_IN);
        return false;
    }
    UIALogger.logDebug("On iCloud Sign in Screen");
    pepsetup.delay(8);
    pepsetup.takeScreenShot('2-iCloudSignInScreen.png');
    pepsetup.tap(SetupUIAQueries.SEEHOWDATAISMANAGED_BUTTON);
    pepsetup.delay(3);
    pepsetup.takeScreenShot('2.1-AID-SeeHowDataIsManaged.png');
    pepsetup.containsMessages(AppleIDLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);

}


pepsetup.verifyAndScreenShotTandC = function verifyAndScreenShotTandC() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS);
        return false;
    }
    UIALogger.logDebug("On Terms & Conditions");
    pepsetup.logIfPresent(SetupUIAQueries.PRIVACY_POLICY_TEXT);
    pepsetup.takeScreenShot('3-TermsAndConditions.png');
    pepsetup.tap(SetupUIAQueries.AGREE_BUTTON);

}


pepsetup.verifyAndScreenShotLocationServices = function verifyAndScreenShotLocationServices() { 
    if (pepsetup.currentUIState() != UIStateDescription.Setup.LOCATION_SERVICES){
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.LOCATION_SERVICES);
        return false;
    }
    UIALogger.logDebug("On Location Services Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('4-LocationServices.png');
    pepsetup.tap(SetupUIAQueries.ABOUTLOCATIONSERVICES_BUTTON);
    pepsetup.takeScreenShot('4.1-AboutLocationServices.png');
    pepsetup.containsMessages(LocationServicesLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}

pepsetup.verifyAndScreenShotSiri = function verifyAndScreenShotSiri() { 
    if (pepsetup.currentUIState() != UIStateDescription.Setup.SIRI){
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.SIRI);
        return false;
    }
    UIALogger.logDebug("On Siri Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('5-Siri.png');
    pepsetup.tap(SetupUIAQueries.ABOUTSIRI_LINK);
    pepsetup.takeScreenShot('5.1-AboutSiri.png');
    pepsetup.containsMessages(SiriSuggestionsLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}


pepsetup.verifyAndScreenShotApplePayScreen = function verifyAndScreenShotApplePayScreen() { 
    if (pepsetup.currentUIState() != UIStateDescription.Setup.APPLE_PAY_DESC){
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.APPLE_PAY_DESC);
        return false;
    }
    UIALogger.logDebug("On Apple Pay Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('6-ApplePay.png');

    pepsetup.tap(SetupUIAQueries.APPLE_PAY_SEEHOWDATAISMANAGED_BUTTON);
    pepsetup.takeScreenShot('6.1-AboutApplePay.png');
    pepsetup.containsMessages(ApplePayLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}


pepsetup.verifyAndScreenShotiCloudKeychainScreen = function verifyAndScreenShotiCloudKeychainScreen() { 
    if (pepsetup.currentUIState() != UIStateDescription.Setup.ICLOUD_KEYCHAIN){
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.ICLOUD_KEYCHAIN);
        return false;
    }
    UIALogger.logDebug("On iCloud Keychain Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('7-iCLoudKeychain.png');
    pepsetup.tap(SetupUIAQueries.ABOUT_iCLOUD_KEYCHAIN_BUTTON);
    pepsetup.takeScreenShot('7.1-AboutiCloudKeychain.png');
    pepsetup.containsMessages(iCloudKeychainLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}

pepsetup.verifyAndScreenShotAppAnalytics = function verifyAndScreenShotAppAnalytics() { 
    if (pepsetup.currentUIState() != UIStateDescription.Setup.APP_ANALYTICS){
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.APP_ANALYTICS);
        return false;
    }
    UIALogger.logDebug("On App Analytics Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('6-App Analytics');
    pepsetup.tap(SetupUIAQueries.ABOUTAPPANALYTICSANDPRIVACY_BUTTON);
    pepsetup.takeScreenShot('6.1-AboutSiri.png');
    pepsetup.containsMessages(AppAnalyticsLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}


pepsetup.verifyAndScreenShotiCloudAnalytics = function verifyAndScreenShotiCloudAnalytics() { 
   
    UIALogger.logDebug("On iCloud Analytics Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('8-iCLoud Analytics');
    pepsetup.tap(SetupUIAQueries.ABOUTiCLOUDANALYTICSANDPRIVACY_BUTTON);
    pepsetup.takeScreenShot('8.1-iCLoudAnalyticsLearnMoreCopy.png');
    pepsetup.containsMessages(iCloudAnalyticsLearnMoreCopy);
    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);
}




pepsetup.verifyAndScreenShotPrivacyPage = function verifyAndScreenShotPrivacyPage() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.PRIVACY_SPLASH) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.PRIVACY_SPLASH);
        return false;
    }
    UIALogger.logDebug("On Privacy splash screen");
    pepsetup.logIfAbsent(SetupUIAQueries.DATAANDPRIVACY_TEXT);
    pepsetup.containsMessages(PrivacyCopy);
    pepsetup.takeScreenShot('1-PrivacySplash.png');
}

pepsetup.verifyAndScreenShotPrivacyLearnMorePage = function verifyAndScreenShotPrivacyPage() {
  
    UIALogger.logDebug("On Privacy Learn More screen");
    pepsetup.logIfAbsent(SetupUIAQueries.DATAANDPRIVACY_TEXT);
    pepsetup.containsMessages(PrivacyLearnMoreCopy);
    pepsetup.takeScreenShot('1.1-PrivacyLearnMore.png');
    pepsetup.delay(3);
    
    pepsetup.tap(SetupUIAQueries.ACTIVITY_SHARING_TEXT);
    pepsetup.containsMessages(ActivitySharingLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.1-ActivitySharingLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.ADVERTISING_TEXT);
    pepsetup.containsMessages(AdverstisingLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.2-AdverstisingLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APP_ANALYTICS_TEXT);
    pepsetup.containsMessages(AppAnalyticsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.3-AppAnalyticsLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3); 


  
    pepsetup.tap(SetupUIAQueries.APP_STORE_TEXT);
    pepsetup.containsMessages(AppStoreLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.4-AppStoreLearnMore.png');
    UIALogger.logDebug('App Store ScreenShot DONE');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_ID_TEXT);
    pepsetup.containsMessages(AppleIDLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.5-AppleIDLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_MUSIC_TEXT);
    pepsetup.containsMessages(AppleMusicLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.6-AppleMusicLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_PAY_TEXT);
    pepsetup.containsMessages(ApplePayLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.7-ApplePayLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_PAY_CASH_TEXT);
    pepsetup.containsMessages(ApplePayCashLearnMore);
    pepsetup.takeScreenShot('1.1.8-ApplePayCashLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_PODCASTS_TEXT);
    pepsetup.containsMessages(ApplePodcastLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.9-ApplePodcastLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.APPLE_TV_APP_TEXT);
    pepsetup.containsMessages(AppleTVLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.10-AppleTVLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.ASK_SIRI_AND_DICTATION_TEXT);
    pepsetup.containsMessages(AskSiriDictationLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.11-AskSiriDictationLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.DEVICE_ANALYTICS_TEXT);
    pepsetup.containsMessages(DeviceAnalyticsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.12-DeviceAnalyticsLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.DICTATION_TEXT);
    pepsetup.containsMessages(DictationLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.13-DictationLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.EMERGENCY_SOS_TEXT);
    pepsetup.containsMessages(EmergecnyLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.14-EmergecnyLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.FACE_ID_TEXT);
    pepsetup.containsMessages(FaceIdLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.15-FaceIdLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    /*pepsetup.tap(SetupUIAQueries.iBOOKS_TEXT);
    pepsetup.containsMessages(iBooksLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.16-iBooksLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3); */

    pepsetup.tap(SetupUIAQueries.iCLOUD_ANALYTICS_TEXT);
    pepsetup.containsMessages(iCloudAnalyticsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.17-iCLoudAnalyticsLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.iCLOUD_KEYCHAIN_TEXT);
    pepsetup.containsMessages(iCloudKeychainLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.18-iCLoudKeychainLearnMorenCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.IMPROVE_HEALTH_TEXT);
    pepsetup.containsMessages(ImproveHealthLearnMore);
    pepsetup.takeScreenShot('1.1.19-ImproveHealthLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.IMPROVE_HEALTH_RECORDS_TEXT);
    pepsetup.containsMessages(ImproveHealthRecordsLearnMore);
    pepsetup.takeScreenShot('1.1.20-ImproveHealthRecordsLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.IMPROVE_MAPS_TEXT);
    pepsetup.containsMessages(ImproveMapsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.21-ImproveMapsLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.iTUNES_STORE_TEXT);
    pepsetup.containsMessages(iBooksLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.22-iTunesStoreLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.iTUNES_U_TEXT);
    pepsetup.containsMessages(iBooksLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.23-iTunesULearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.LOCATION_SERVICES_TEXT);
    pepsetup.containsMessages(LocationServicesLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.24-LocationServicesLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.MAPS_REPORT_TEXT);
    pepsetup.containsMessages(MapsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.25-MapsLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.NEWS_TEXT);
    pepsetup.containsMessages(NewsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.26-NewsLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.SAFARI_TEXT);
    pepsetup.containsMessages(SafariLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.27-SafariLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.SAFARI_SEARCH_TEXT);
    pepsetup.containsMessages(SafariSearchLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.28-SafariSearchLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.SEARCH_TEXT);
    pepsetup.containsMessages(SearchLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.29-SearchLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.SIRI_SUGGESTIONS_TEXT);
    pepsetup.containsMessages(SiriSuggestionsLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.30-SiriSuggestionsLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.SPOTLIGHT_SEARCH_TEXT);
    pepsetup.containsMessages(SpotLightSearchLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.31-DictationLearnMore.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.TV_PROVIDER_TEXT);
    pepsetup.containsMessages(TVProviderLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.32-TVProviderLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.VIDEOS_TEXT);
    pepsetup.containsMessages(VideosLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.33-VideosLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.WHEEL_CHAIR_TEXT);
    pepsetup.containsMessages(WheelChairLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.34-WheelChairLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3);

    pepsetup.tap(SetupUIAQueries.WIFI_CALLING_TEXT);
    pepsetup.containsMessages(WiFiCallingLearnMoreCopy);
    pepsetup.takeScreenShot('1.1.35-WiFiCallingLearnMoreCopy.png');
    pepsetup.tap(SetupUIAQueries.PRIVACY_BUTTON);
    pepsetup.delay(3); 


    pepsetup.tap(SetupUIAQueries.DONE_BUTTON);



}


pepsetup.verifyAndScreenShotNewHomeScreen = function verifyAndScreenShotNewHomeScreen() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.NEW_HOME_BUTTON_INTRO) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.NEW_HOME_BUTTON_INTRO);
        return false;
    }
    UIALogger.logDebug("On New Home Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('10.NewHomeScreen.png');
    pepsetup.containsMessages(NewHomeScreenCopy);

}

pepsetup.verifyAndScreenShotSwitchApps = function verifyAndScreenShotSwitchApps() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.APP_SWITCHER_ON_BOARDING) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.APP_SWITCHER_ON_BOARDING);
        return false;
    }
    UIALogger.logDebug("On App Switcher Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('11.AppSwitcherScreen.png');
    pepsetup.containsMessages(AppSwitcherScreenCopy);

}


pepsetup.verifyAndScreenShotAccessControls = function verifyAndScreenShotAccessControls() {
    if (pepsetup.currentUIState() != UIStateDescription.Setup.CONTROL_CENTER_ON_BOARDING) {
        throw new UIAError("Expecting screen " + UIStateDescription.Setup.CONTROL_CENTER_ON_BOARDING);
        return false;
    }
    UIALogger.logDebug("On Access Controls Screen");
    pepsetup.delay(2);
    pepsetup.takeScreenShot('12.AccessControlsScreen.png');
    pepsetup.containsMessages(AccessControlCopy);

}




pepsetup.logIfAbsent = function logIfAbsent(uiquery) {
    if (!pepsetup.exists(uiquery)) {
       UIALogger.logDebug("Expecting text " + uiquery);
    }
}


pepsetup.logIfPresent = function logIfPresent(uiquery) {
    if (pepsetup.exists(uiquery)) {
        UIALogger.logDebug("Element Present " + uiquery);
    }
}


pepsetup.containsMessages = function containsMessages(messages) {
    for (var i = 0; i < messages.length; ++i) {
        pepsetup.logIfAbsent(UIAQuery.staticTexts().contains(messages[i]));
    }
}

pepsetup.takeScreenShot = function takeScreenShot(name, options) {
    options = UIAUtilities.defaults(options, {
                                    filePath : SCREENSHOT_DIRECTORY_FILE_PATH
                                    });
    UIALogger.logMessage('FUNCTION: takeScreenShot');
    var screen = UIAScreenIdentifier.MAIN;
    
    // Trim filePath
    options.filePath = options.filePath.trim();
    
    // Trim name and replace spaces with _
    name = name.trim().replace(/ /g, '_');
    
    // Add forward slash if needed
    if (options.filePath[options.filePath.length - 1] !== '/') {
        options.filePath = options.filePath + '/';
    }
    // Create directory if it doesn't exist
    UIAFileManagement.makeDirectory(options.filePath);
    var fullFilePath = UIAFileManagement.makeSafePath('%0%1'.format(options.filePath, name));
    
    try {
        UIALogger.logMessage(" before taking screenshot");
        //UIATarget.localTarget().screenWithIdentifier(UIAScreenIdentifier.MAIN);
        UIATarget.localTarget().captureScreenWithName(fullFilePath);
        UIALogger.logMessage("took screenshot");
        
    } catch (e) {
        UIALogger.logError(e);
    }
}



pepsetup.getAIDForAccountCreation = function getAIDForAccountCreation() {

    var d = new Date();
    var aid = "setup";
    aid += d.getFullYear();
    aid += d.getMonth();
    aid += d.getDate();
    aid += d.getHours();
    aid += d.getMinutes();
    aid += d.getSeconds();
    aid += "@icloud.com";
    
    return aid;
    
}