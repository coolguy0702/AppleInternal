/**
 * Created by Reema on 11/06/17.
 */

load('UIAApp.js');
load('UIATesting.js');
load('Buddy.js');
load('iCloud+Buddy.js');


UIAUtilities.assert(typeof iCloudBuddyTest === 'undefined', 'iCloudSettingsTest has already been defined.');

var buddyTests = {
    
    
    /**
     * @overrideID gdprskipAID
     * @param {object} args Test argument
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
     * @param {string} [args.passcode="111111"]
     */
     gdprskipAID: function gdprskipAID (args) {
        pepsetup.getToPrivacyPage(args.wifiNetwork, args.wifiPassword);
        pepsetup.delay(3);
        pepsetup.verifyAndScreenShotPrivacyPage();
        pepsetup.tap(SetupUIAQueries.LEARNMORE_BUTTON);
        pepsetup.verifyAndScreenShotPrivacyLearnMorePage();


        //verify and take screenshot of iCloud Sign In and learn More screen
        pepsetup.getToiCloudPage(args.wifiNetwork, args.wifiPassword, args.passcode);
        pepsetup.delay(3);
        pepsetup.verifyAndScreenShotiCloud();

        //verify and take screenshot of Terms & Conditions
        pepsetup.getToTermsAndConditionsPage(args.wifiNetwork, args.wifiPassword, args.passcode);
        pepsetup.delay(3);
        pepsetup.verifyAndScreenShotTandC();

        pepsetup.getToLocationServicePage(args.wifiNetwork, args.wifiPassword, args.passcode, true);

        pepsetup.verifyAndScreenShotLocationServices();
        pepsetup.tap(SetupUIAQueries.ENABLE_LOCATION_BUTTON);

        //verify and take screenshot of Siri
        pepsetup.verifyAndScreenShotSiri();

        pepsetup.getToAppAnalyticsPage(args.wifiNetwork, args.wifiPassword, args.passcode);
        pepsetup.verifyAndScreenShotAppAnalytics();
        pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode);

         // pkphotosctl asset --import /var/tmp/image_dir */

        
     },


     /**
     * @overrideID pearlHWTests
     * @param {object} args Test argument
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
     * @param {string} [args.passcode="111111"]
     */
     pearlHWTests: function pearlHWTests (args) {
        pepsetup.getToFaceIDScreen(args.wifiNetwork, args.wifiPassword);
        pepsetup.verifyAndScreenShotFaceID();
        pepsetup.getToNewHomeButtonIntro(args.wifiNetwork, args.wifiPassword);
        pepsetup.verifyAndScreenShotNewHomeScreen();
        pepsetup.tap(SetupUIAQueries.CONTINUE_BUTTON);
        pepsetup.verifyAndScreenShotSwitchApps();
        pepsetup.tap(SetupUIAQueries.CONTINUE_BUTTON);
        pepsetup.verifyAndScreenShotAccessControls();
        pepsetup.tap(SetupUIAQueries.CONTINUE_BUTTON);
       // pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode);

        
     },

    /**
     * @overrideID gdprCreateAID
     * @param {object} args Test argument
     * @param {string} [args.password="Apple123+"]
     * @param {string} [args.tfaPhoneNumber="6693334444"]
     * @param {string} [args.passcode="111111"]
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
     */
     gdprCreateAID: function gdprCreateAID (args) {
        pepsetup.getToiCloudPage(args.wifiNetwork, args.wifiPassword, args.passcode);

        var appleid = pepsetup.getAIDForAccountCreation();

        if (target.model()=='iPad'){
            setup.createHSA2Account(appleid, args.password, args.tfaPhoneNumber);
        }
        else {
             setup.createHSA2AccountSimInSameDevice(appleid, args.password);
        }
       
        pepsetup.getToApplePay(args.wifiNetwork, args.wifiPassword, args.passcode);
       

        pepsetup.verifyAndScreenShotApplePayScreen();
        pepsetup.tap(SetupUIAQueries.SETUP_LATER_IN_WALLET_BUTTON);

        pepsetup.verifyAndScreenShotiCloudKeychainScreen();

        pepsetup.tap(SetupUIAQueries.DONT_USE_iCLOUD_KEYCHAIN_BUTTON);
        pepsetup.tap(SetupUIAQueries.SETUP_LATER_IN_SETTINGS_BUTTON);

        pepsetup.verifyAndScreenShotiCloudAnalytics();
        pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode);

},




    
     /**
     * @overrideID buddyQuickPass
     * @param {object} args Test argument
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
      * @param {string} [args.passcode="111111"]
     */

     

    buddyQuickPass: function buddyQuickPass (args) {
        pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode);
        pepsetup.tap(SetupUIAQueries.GET_STARTED_BUTTON);
    },

    /**
     * @overrideID enableScreenTime
     * @param {object} args Test argument
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
     * @param {string} [args.passcode="111111"]
     * @param {bool} [args.enableScreentime=true]

     */

    enableScreenTime: function enableScreenTime (args) {
        pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode, args.enableScreentime);
    
    },

     /**
     * @overrideID disableScreenTime
     * @param {object} args Test argument
     * @param {string} [args.wifiNetwork="$$wifinetwork"]
     * @param {string} [args.wifiPassword="$$wifipassword"]
     * @param {string} [args.passcode="111111"]
     * @param {bool} [args.enableScreentime=false]

     */

    disableScreenTime: function disableScreenTime (args) {
        pepsetup.getToSpringBoard(args.wifiNetwork, args.wifiPassword, args.passcode, args.enableScreentime);
    
    },


}