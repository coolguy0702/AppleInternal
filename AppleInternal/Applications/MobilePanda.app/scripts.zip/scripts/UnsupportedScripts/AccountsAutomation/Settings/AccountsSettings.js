/*
    This file is for library functions associated with the AccountsUI framework.
    This corresponds to account actions under the 'Mail, Contacts, Calendars'
    view in the UI e.g. logging in and out of accounts such as iCloud, Yahoo,
    Exchange, etc.
*/

load('UIAApp.js');
load('SpringBoard.js');
load('Settings.js');
load('Settings+Accounts.js');

/**
 * Create a new iCloud account with the specified information.
 *
 * @param {string} appleID - Apple ID.
 * @param {string} password - AppleID password.
 * @param {string}    [options.birthday="April/1/1984"] - Birthday for age verification.
 * @param {string}    [options.firstName="John"] - First name.
 * @param {string}    [options.lastName="Galt"] - Last name.
 * @param {array}    [options.answers=["Apple", "Sam", "Venice"] - Answer  for security question, provide your dream job name, first boss, first beach.
 * @param {bool}      [options.emailUpdates=false] - Optional Whether to opt for email updates.
 * @param {bool}      [options.runTest=false] - Optional Whether to run this test or not as we can max out the number of burns if run by mistake.
 */
settings.createNewiCloudAccountInSettings = function createNewiCloudAccountInSettings(appleID, password, options) {
    options = UIAUtilities.defaults(options, {
        birthday:   "April/1/1984",
        firstName:  "John",
        lastName: "Galt",
        answer: ["Apple", "Sam", "Venice"],
        emailUpdates: false,
        runTest: false,
    });
    
    if (!options.runTest) {
        throw new UIAError('This test creates a fresh iCloud account (email address). We can only create three accounts per device. In order to create more account, you will need more number of burns for that device. In order to run this test set "runTest" parameter to true.');
    }
    
    var birthDay = options.birthday;
    UIAUtilities.assert(
        typeof birthDay === 'string' && birthDay.length > 0,
            "The parameter 'birthDay' must be a positive length string!"
    );
    
    if (!appleID) {
        UIALogger.logWarning('No Apple ID specified. Defaulting to persisted Apple ID.');
        appleID = springboard.appleID;
    }
    
    if (!password) {
        UIALogger.logWarning('No Apple ID password specified. Defaulting to persisted Apple ID password.');
        password = springboard.appleIDPassword;
    }
    
    var iCloudViewAppeared = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "RUIPage"',
        }
    );
    
    var bdayRegex = /^(?:(?:(?:0?[13578]|1[02]|(?:January|March|May|July|August|October|December))(\/|-|\.)31)\1|(?:(?:0?[1,3-9]|1[0-2]|(?:January|March|April|May|June|July|August|September|October|November|December))(\/|-|\.)(?:29|30)\2))(?:(?:186[6-9]|18[7-9]\d|19\d{2})|20[0-1][0-6]$)$|^(?:(?:0?2|(?:February))(\/|-|\.)(?:29)\3(?:(?:1868|18[79][26]|188[048]|19[0248][048]|19[13579][26]|2\d0[048]|2\d1[26])))$|^(?:(?:0?[1-9]|(?:January|February|March|April|May|June|July|August|September))|(?:1[0-2]|(?:October|November|December)))(\/|-|\.)(?:0?[1-9]|1\d|2[0-8])\4(?:(186[6-9]|18[7-9]\d|19\d{2})|20[0-1][0-6])$/;
    
    if (!bdayRegex.test(birthDay)) {
        throw new UIAError('Birthday string incorrectly entered. Expected: Month/DD/YYYY, Actual: %0'.format(birthDay));
    }
    
    this.navigateNavigationViews(['iCloud']);
    this.tap(UIAQuery.Settings.CREATE_NEW_APPLEID);
    var firstName = UIAQuery.textFields('first name');
    var lastName = UIAQuery.textFields('last name');
    var securityQuestions = [UIAQuery.Settings.DREAM_JOB, UIAQuery.Settings.FIRST_BOSS, UIAQuery.Settings.FIRST_BEACH];
    
    if (!iCloudViewAppeared.wait(3)) {
        UIALogger.logMessage('The "RUIPage" view took longer than 3 seconds to appear');
    }
    
    for (var i=2; i >= 0; i--) {
        UIALogger.logMessage("Attempting to adjust picker to '%0' on wheel %1...".format(birthDay.split("/")[i], i));
        this.setControl(UIAQuery.pickerWheels().atIndex(i), birthDay.split("/")[i]);
    }
    
    this.tap(UIAQuery.RIGHT_NAV_BUTTON);
    
    this.findFieldEnterText(firstName, options.firstName);
    this.enterText(lastName, options.lastName);
    
    this.tap(UIAQuery.RIGHT_NAV_BUTTON);
    this.tap(UIAQuery.Settings.FREE_NEW_APPLEID);
    
    this.findFieldEnterText(UIAQuery.textFields('name'), appleID.substring(0, appleID.lastIndexOf("@")));
    
    this.handlingAlertsInline(UIAQuery.Settings.CREATE_APPLE_ID_ALERT, function () {
        this.handlingAlertsInline(UIAQuery.Settings.EMAIL_TAKEN_ALERT,function () {
            this.handlingAlertsInline(UIAQuery.Settings.EMAIL_INVALID_ALERT, function () {
                this.tap(UIAQuery.RIGHT_NAV_BUTTON);
                if (this.waitUntilPresent(UIAQuery.Settings.CREATE_APPLE_ID_ALERT, 30)) {
                    this.tap(UIAQuery.DEFAULT_BUTTON);
                }
                if (this.waitUntilPresent(UIAQuery.Settings.EMAIL_TAKEN_ALERT, 10)) {
                    throw new UIAError('Email address is already taken.');
                }
                if (this.waitUntilPresent(UIAQuery.Settings.EMAIL_INVALID_ALERT, 10)) {
                    throw new UIAError('Email address is invalid.');
                }
            });
        });
    });
    
    this.findFieldEnterText(UIAQuery.secureTextFields('required'), password);
    this.enterText(UIAQuery.secureTextFields('retype password'), password);
    
    this.tap(UIAQuery.RIGHT_NAV_BUTTON);
    
//Expecting only 3 security questions
    
    for (var i=0; i < 3; i++) {
        UIALogger.logMessage("Providing answer '%0' to security question '%1'".format(options.answer[i], securityQuestions[i]));
        this.answerSecurityQuestion(securityQuestions[i], options.answer[i]);
    }
    
    if(options.emailUpdates && this.waitUntilPresent(UIAQuery.switches("Apple News"))) {
        this.setControl(UIAQuery.switches("Apple News"), true);
    }
    if (this.waitUntilPresent(UIAQuery.Settings.TERMS_CONDITIONS, 120)) {
        this.handlingAlertsInline(UIAQuery.Settings.TERMS_CONDITONS_ALERT, function () {
            this.handlingAlertsInline(UIAQuery.Settings.FMIP_ENABLED_ALERT, function () {
                this.tap(UIAQuery.Settings.AGREE);
                if (this.waitUntilPresent(UIAQuery.Settings.TERMS_CONDITONS_ALERT, 30)) {
                    this.tap(UIAQuery.DEFAULT_BUTTON);
                }
                //<rdar://problem/24878641> FMIP alert ~1 min to apper after creation of a new account.
                if (this.waitUntilPresent(UIAQuery.Settings.FMIP_ENABLED_ALERT, 60)) {
                    this.tap('OK');
                }
            });
        });
    }
    if(this.exists(UIAQuery.query('Sign Out'))) {
        UIALogger.logMessage('We are signed in');
    } else {
         throw new UIAError('Something went wrong and we are not signed in correctly.');
    }
}

/**
 * Helper function for creation of new account
 *
 *<rdar://problem/24878676> Some of the fields are not active while creationg of new iCloud account right away. Remove when fixed.
 *
 * Takes the query tag to look for and verifies if it is present and then uses enterText to avoid repition of code.
 * @param {string} queryTag - queryTag
 * @param {string} textToEnter - textToEnter
 */
settings.findFieldEnterText = function findFieldEnterText(queryTag, textToEnter) {
    if (this.waitUntilPresent(queryTag, 2)) {
        this.enterText(queryTag, textToEnter);
    } else {
        throw new UIAError("Could not find %0 field".format(queryTag));
    }
}

/**
 * Helper function for choosing security questions and answering
 *
 * @param {string} questionquery - Question UIA Query
 * @param {string} answer - answer
 */
settings.answerSecurityQuestion = function answerSecurityQuestion(questionquery, answer) {
    this.tap(UIAQuery.Settings.CHOOSE_QUESTION);
    this.tap(questionquery);
    this.findFieldEnterText(UIAQuery.Settings.ENTER_ANSWER , answer);
    this.tap(UIAQuery.RIGHT_NAV_BUTTON);
}
