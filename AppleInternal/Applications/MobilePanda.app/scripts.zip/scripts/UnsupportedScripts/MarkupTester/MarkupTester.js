load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof markupTester === 'undefined',
    'markupTester has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common clock queries */
UIAQuery.MarkupTester = {
    /** Root view */
    ROOT_VIEW: UIAQuery.beginsWith('UIView'),

    /** Cancel button in Markup toolbar */
    CANCEL_BUTTON: UIAQuery.beginsWith('Cancel'),

    /** Save button in Markup toolbar */
    SAVE_BUTTON: UIAQuery.beginsWith('Save'),

    /** Sketch toggle in Markup toolbar */
    TOGGLE_SKETCH_BUTTON: UIAQuery.beginsWith('Intelligent sketch'),

    /** Loupe Button in Markup toolbar */
    LOUPE_BUTTON: UIAQuery.beginsWith('Loupe'),

    /** Text box button in Markup toolbar */
    TEXT_BUTTON: UIAQuery.beginsWith('Text'),

    /** Undo button in Markup toolbar */
    UNDO_BUTTON: UIAQuery.beginsWith('Undo'),

    /** Page label in Markup toolbar. */
    PAGE_LABEL: UIAQuery.beginsWith('UIToolbar').beginsWith('Page:'),
}

/**
 * @namespace {UIAApp} markupTester
 */
var markupTester = target.appWithBundleID('com.apple.MarkupUI.MarkupTester');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Opens file using MarkupViewController
 *
 * Required Starting View: Document list view
 *
 * @param {string} filename - Name of document
 *
 * @returns none
 */
markupTester.openFile = function(filename)
{
    this.tap(UIAQuery.beginsWith(filename));
    this.waitUntilReady();

    // Wait for sketch button to take on final state.
    this.delay(2.0);
}

/**
 * Cancels editing and returns to document list view
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.cancelEditing = function()
{
    this.tap(UIAQuery.MarkupTester.CANCEL_BUTTON);
}

/**
 * Saves changes to file and returns to document list view
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.saveAndClose = function()
{
    this.tap(UIAQuery.MarkupTester.SAVE_BUTTON);
}

/**
 * Returns whether or not sketch tool is selected.
 *
 * Required Starting View: Markup view
 *
 * @returns {bool}
 */
markupTester.isDrawSelected = function()
{
    var results = this.inspectAll(UIAQuery.MarkupTester.TOGGLE_SKETCH_BUTTON.isSelected());
    return results.length > 0;
}

/**
 * Set sketch tool selected state.
 *
 * Required Starting View: Markup view
 *
 * @param {bool} state - End selected state of sketch button.
 *
 * @returns none
 */
markupTester.setDrawSelected = function(state)
{
    if (this.isDrawSelected() != state)
    {
        this.tap(UIAQuery.MarkupTester.TOGGLE_SKETCH_BUTTON)
    }
}

/**
 * Draws single stroke from `start` to `end`
 *
 * Required Starting View: Markup view
 *
 * @param {Point} start - Start point for stroke. Must have 'x' and 'y' properties. Coordinates range from 0.0 to 1.0.
 * @param {Point} end - end point for stroke.
 *
 * @returns none
 */
markupTester.drawStroke = function(start, end)
{
    // this.waitUntilReady();

    this.setDrawSelected(true);
    var viewQuery = UIAQuery.MarkupTester.ROOT_VIEW;
    var dragOptions = {};
    dragOptions.fromOffset = start;
    dragOptions.toOffset = end;
    this.drag(viewQuery, dragOptions)
}

/**
 * Adds loupe to file.
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.addLoupe = function()
{
    this.tap(UIAQuery.MarkupTester.LOUPE_BUTTON);
}

/**
 * Adds text box to file.
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.addTextBox = function()
{
    this.tap(UIAQuery.MarkupTester.TEXT_BUTTON);
}

/**
 * Undo last edit.
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.undo = function()
{
    this.tap(UIAQuery.MarkupTester.UNDO_BUTTON);
}

/**
 * Scroll PDF document forwards or backwards.
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.scrollPDF = function(shouldScrollDown)
{
    var direction = shouldScrollDown ? 1.0 : -1.0;
    var scrollDistance = 0.8;

    this.setDrawSelected(false);
    var viewQuery = UIAQuery.MarkupTester.ROOT_VIEW;
    var dragOptions = {};
    dragOptions.fromOffset = {'x': 0.5, 'y': 0.5 + direction * scrollDistance / 2.0};
    dragOptions.toOffset = {'x': 0.5, 'y': 0.5 - direction * scrollDistance / 2.0};
    dragOptions.flick = true;
    this.drag(viewQuery, dragOptions);

    var currPageNode = this.inspect(UIAQuery.MarkupTester.PAGE_LABEL);
    if (currPageNode) {
        return currPageNode.name;
    } else {
        return '';
    }
}

/**
 * Scroll PDF document to first page or last page.
 *
 * Required Starting View: Markup view
 *
 * @returns none
 */
markupTester.scrollAllPages = function(shouldScrollDown)
{
    var prevPage = 'prev';
    var currPage = 'curr';
    while (prevPage != currPage)
    {
        prevPage = currPage;
        currPage = this.scrollPDF(shouldScrollDown);
    }
}

