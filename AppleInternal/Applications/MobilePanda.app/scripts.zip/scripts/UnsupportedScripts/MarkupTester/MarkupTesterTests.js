load('UIATesting.js');
load('MarkupTester.js');

UIAUtilities.assert(
    typeof MarkupTests === 'undefined',
    'MarkupTests has already been defined.'
);

/**
 * @namespace MarkupTests
 */
var MarkupTests = {

    /**
     * Open document and either save or cancel editing.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.filename="NASA.jpg"] - filename
     * @param {boolean} [args.shouldSave=true] - Specifies whether markup should save the document or cancel editing.
     *
     */
    openDocument: function(args) {
        // Want this to iterate over all types of documents.
        args = UIAUtilities.defaults(args, {
                                     "filename": "NASA.jpg",
                                     "shouldSave": true,
                                     });

        markupTester.launch();
        markupTester.openFile(args.filename);

        if (args.shouldSave)
        {
            markupTester.saveAndClose();
        }
        else
        {
            markupTester.cancelEditing();
        }
    },

    /**
     * Open document, add all annotation types, and either save or cancel editing.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.filename="NASA.jpg"] - filename
     * @param {boolean} [args.shouldSave=true] - Specifies whether markup should save the document or cancel editing.
     *
     */
    editDocument: function(args)
    {
        args = UIAUtilities.defaults(args, {
                                     "filename": "NASA.jpg",
                                     "shouldSave": true,
                                     });

        markupTester.launch();
        markupTester.openFile(args.filename);

        markupTester.drawStroke({'x': 0.3, 'y': 0.3},
                              {'x': 0.7, 'y': 0.7});
        markupTester.addLoupe();
        markupTester.addTextBox();

        if (args.shouldSave)
        {
            markupTester.saveAndClose();
        }
        else
        {
            markupTester.cancelEditing();
        }
    },

    /**
     * Open document, add all annotation types, undo all edits, and either save or cancel editing.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.filename="NASA.jpg"] - filename
     * @param {boolean} [args.shouldSave=true] - Specifies whether markup should save the document or cancel editing.
     *
     */
    editUndoDocument: function(args)
    {
        args = UIAUtilities.defaults(args, {
                                     "filename": "NASA.jpg",
                                     "shouldSave": true,
                                     });

        markupTester.launch();
        markupTester.openFile(args.filename);

        markupTester.drawStroke({'x': 0.3, 'y': 0.3},
                              {'x': 0.7, 'y': 0.7});
        markupTester.addLoupe();
        markupTester.addTextBox();

        markupTester.undo();
        markupTester.undo();
        markupTester.undo();

        if (args.shouldSave)
        {
            markupTester.saveAndClose();
        }
        else
        {
            markupTester.cancelEditing();
        }
    },

    /**
     * Opens PDF document and scroll through all its pages. First it scroll to the last page, then back to the first page. Either save or cancel editing.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.filename="Apple SR 2013 Progress Report.pdf"] - filename
     * @param {boolean} [args.shouldSave=true] - Specifies whether markup should save the document or cancel editing.
     *
     */
    openScrollPDFDocument: function(args)
    {
        args = UIAUtilities.defaults(args, {
                                     "filename": "Apple SR 2013 Progress Report.pdf",
                                     "shouldSave": true,
                                     });
        markupTester.launch();
        markupTester.openFile(args.filename);

        // Scroll to last page
        markupTester.scrollAllPages(true);

        // Scroll to first page
        markupTester.scrollAllPages(false);

        if (args.shouldSave)
        {
            markupTester.saveAndClose();
        }
        else
        {
            markupTester.cancelEditing();
        }

    }
}
