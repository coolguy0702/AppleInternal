load('UIATesting.js');
load('Messages.js');
load('ResponseKit.js');
load('UIAUtility.js');
load("Settings.js");
load("Settings+Accounts.js");
load("SettingsTests.js");
load('FWInternational.js');


UIAUtilities.assert(
    typeof ResponseKitTests === 'undefined',
    'ResponseKitTests has already been defined.'
);

/** @namespace */

var ResponseKitTests = {

    /**
      * Add Keyboard for testing
      *
      * @targetApps Add Keyboards
      *
      * @param {object} args - Test arguments
      * @param {string} [args.languages = "Dutch"] - Required
      * @param {string} [args.types= " "] - Required
      * @param {string} [args.keyboards= "nl_NL@hw=Automatic;sw=QWERTY"] - Required
    */

       AddKeyboard: function AddKeyboard (args){
            args = UIAUtilities.defaults(args, {
                languages: "Dutch",
                types: '',
                keyboards:  'nl_NL@hw=Automatic;sw=QWERTY' });
                          
            var languages= ['English',
                            'German (Germany)',
                            'Italian',
                            'Spanish (Spain)',
                            'French',
                            'Portuguese (Portugal)',
                            'Turkish']; 
            var types = ['',
                         '',
                         '',
                         '',
                         '',
                         '',
                         ''];

            var keyboards= ['en_US@hw=Automatic;sw=QWERTY',
                            'de_DE@hw=Automatic;sw=QWERTZ-German',
                            'it_IT@hw=Automatic;sw=QWERTY',
                            'es_ES@hw=Automatic;sw=QWERTY-Spanish',
                            'fr_FR@hw=Automatic;sw=AZERTY-French',
                            'pt_PT@hw=Automatic;sw=QWERTY',
                            'tr_TR@hw=Automatic;sw=Turkish-Q'];

            /* add keyboards */

            for (var i = 0; i < languages.length; i++) {
                 settings.addKeyboard(languages[i], types[i], keyboards[i], null, true);
            }
            settings.tap("back-nav-button");
            settings.tap("back-nav-button");
            settings.tap("back-nav-button");

            ResponseKit.turnOffAutoCorrection();



        },//AddKeyboard

    /**
      * Sign into iCloud
      *
      * @CaptureCondition PASS
      *
      * @param {object}      args - Test arguments
      * @param {string}      [args.AppleID="PERSISTEDAPPLEID"]                   - AppleID
      * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"]   - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
    */

    iCloudSignIn: function iCloudSignIn() {

        args = { AppleID : 'vkolevcanned1@icloud.com', 
                 AppleIDPassword : 'veneta5Apple', 
                 passIfAlreadySignedIn: false, };

        settings.launch();
        settings.signInToiCloud('vkolevcanned1@icloud.com', 'veneta5Apple', args);
        UIALogger.logMessage('ResponseKit iCloudSignIn option is turned on');

    },//iCloudSignIn

    /**
        * Turn the iMessage on
        * @param {string} [options.passIfAlreadyLoggedIn = true] - Can pass a starting state.
        *
    */

    iMessageOn: function iMessageOn(options){
        options = UIAUtilities.defaults(options, {
                  passIfAlreadyLoggedIn : true
        });

        settings.navigateNavigationViews(['Messages']);
        settings.setControl(UIAQuery.switches("iMessage"), true);
        settings.signInToiMessage('vkolevcanned1@icloud.com', 'veneta5Apple', options.passIfAlreadyLoggedIn);
        UIALogger.logMessage('ResponseKit iMessage option is turned on');
        settings.tap("back-nav-button");
        settings.tap("back-nav-button");

    }, //iMessageOn
    

    /**
      * ResponseKitQL for testing
      *
      * @targetApps ResponseKit Test
      *
      * @param {object} args - Test arguments
      * @param {string} [args.languages = "English"] - Required
      * @param {string} [args.types= " "] - Required
      * @param {string} [args.keyboards= "en_US@hw=Automatic;sw=QWERTY"] - Required
      * @param {string} [args.languageString="Can you get me a glass of water ?"] - Required string
      * @param {array}  [args.languageArray=['Yes', 'No', 'Talk later?']] - Required array
    */

    myMainTest: function myMainTest(args) {

        var args = UIAUtilities.defaults(args, {
                languages: "Italian",
                keyboards: 'it_IT@hw=Automatic;sw=QWERTY',
                languageString: "Come stai?",
                languageArray: ['Bene', 'Male', 'Non troppo bene'],

        });

        var messages = target.appWithBundleID("com.apple.MobileSMS");
        //ResponseKit.turnOffAutoCorrection();


        // if(args.languages == "English"){
        //      ResponseKit.turnOffAutoCorrection();
        // }else{
        //     settings.addKeyboard(args.languages,args.types,args.keyboards, null, true);
        //     settings.tap("back-nav-button");
        //     settings.tap("back-nav-button");
        // }

        messages.getToComposeUI();
        FWInternational.findKeyboard(args.keyboards);
        ResponseKit.sendReceiveMessage(args.languageString);
        FWInternational.findKeyboard(args.keyboards);
        ResponseKit.compareArrays(args.languageArray);
         UIATarget.localTarget().delay(3);
        UIALogger.logPass(args.languages+" Pass");
        UIATarget.localTarget().delay(3);
        messages.tap("back-nav-button");
        UIATarget.localTarget().delay(3);
        ResponseKit.deleteThread("Cannedone test"); 
        UIATarget.localTarget().delay(3);

        
    },//responseKitTest

};