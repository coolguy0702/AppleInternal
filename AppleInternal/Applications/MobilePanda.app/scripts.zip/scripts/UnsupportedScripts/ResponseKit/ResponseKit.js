load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');
load('Notes.js');
load('UIAUtility.js');
load('Messages.js');
load('UIATesting.js');
load('International.js');
load('Settings.js');
load('UIAApp+Keyboard.js');
load('Notes+International.js');


UIAUtilities.assert(
    typeof responseKit === 'undefined',
    'Keyboard has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.ResponseKit = {

   /** Button to go back from a Conversation view to the Thread List view */
    CONVERSATION_BACK_BUTTON: UIAQuery.buttons('CKCanvasBackButtonView'), 

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to ResponsiveKit */
UIStateDescription.ResponseKit = {

};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/
var PUNCTUATION = ['?','.',',','!'];
var target = UIATarget.localTarget();



/**
 * @namespace {UIAApp} Keyboard
 */
 // LIKELY NOT NEEDED Predictive
//var safari = target.appWithBundleID('com.apple.mobilesafari');





/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

// LIKELY EMTPY FOR Predictive

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

var ResponseKit = {


    

    /**
     * Send a message and waits for a response.
     *
     * @targetApps MobileSMS
     *
     * @param {object} args Test arguments
     * @param {object} [args.sendOptions=null] - options to configure the message send
     *  (see [UIAApp+Message.sendMessage]{@link UIAApp+Message#sendMessage} for more details on options that can be passed through sendOptions)
     * @param {object} [args.receiveOptions=null] - options to configure the message reply
     *  (see [UIAApp+Message.receiveMessages]{@link UIAApp+Message#receiveMessages} for more details on options that can be passed through receiveOptions)
     * @param {array}  [args.minPercent=100] - the minimum percent of message count to expect
     * @param {number} [args.retryCount=0] - how many times to retry if minPercent condition is not met
     */
    sendReceiveMessage: function sendReceiveMessage(messageText) {
        var args = {
            sendOptions: {
                recipients: ['vkolevcanned1@icloud.com'],
                text:messageText,
                media: null,
            },
            receiveOptions: {
                messages: null,
                messageCount: 1,
                timeout: 60,
            },
            minPercent: 100,
            retryCount: 0,
        };

        if (!args.sendOptions.recipients) {
            args.sendOptions.recipients = [UIAUtilities.randomItem(messages.MessageBots)];
        }

        messages.sendReceiveMessage(args);
    },

    /**
     * Compare Arrays
     *
     * @targetApps MobileSMS
     *
     * @param {object} args - Test arguments
     * @param {array} [args.threadNames=[]] - Conversation Names to verify
     */

    compareArrays: function compareArrays(inputArray){

        var pcellArray = [];
            for ( var i = 1; i<4; i++){
                  var pcell = messages.inspect(UIAQuery.query("Typing Predictions").children().atIndex(i))
               if( pcell != null){
                   var pcellLabel = pcell.label;
             //var pcell = notes.inspect(UIAQuery.query("Typing Predictions").children().atIndex(i)).label
                 if ( typeof pcellLabel != undefined ) {
                     UIALogger.logMessage("String  : "+pcellLabel+", length : "+pcellLabel.length);
                     pcellArray.push(pcellLabel);
                }
              }
            }//for

        UIALogger.logMessage('Candidates: ' + pcellArray);

        var isEquals = true;

        if (inputArray.length != pcellArray.length){
            isEquals = false; 
            }else{

                for(var i = 0; i<pcellArray.length; i++){
                    if(pcellArray[i] != inputArray[i]){
                        isEquals = false;
                } 
            }
        }

        if (isEquals == true) {
            UIALogger.logPass("Input Array does MATCH predictive Array");
            UIALogger.logMessage('PASS ' +'"'+pcellArray+'"');
            UIALogger.logMessage('PASS ' +'"'+inputArray+'"');

        }else{
            UIALogger.logMessage('FAIL ' +'"'+pcellArray+'"');
            UIALogger.logMessage('FAIL ' +'"'+inputArray+'"');
            throw new Error("Input Array does NOT MATCH predictive Array");

        }

    },//compareArrays

   
    /**
     * Verify message threads exist
     *
     * @targetApps MobileSMS
     *
     * @param {object} args - Test arguments
     * @param {array} [args.threadNames=[]] - Conversation Names to verify
     */
    verifyThreadsExist: function verifyThreadsExist(args) {
        args = UIAUtilities.defaults(args, {
            threadNames: [],
        });
        messages.verifyThreadsExist(args.threadNames);
        UIALogger.logMessage('Thread names verified, all conversations exist');
    },

    /**
     * Verify that a message exists in the transcript history
     *
     * @param {object} args - test arguments
     * @param {string} [args.contact=null] - Optionally specify a contact as displayed in the UI
     * @param {string} [args.text=""] - Specify the text of the message
     */
    verifyMessageExists: function verifyMessageExists(args) {
        args = UIAUtilities.defaults(args, {
            contact: null,
            text: '',
            threadNames: [],
        });

        messages.verifyMessageExists(args);
    },

    /**
     *  Navigation function to get to the 'New Message' view.
     */

    getToComposeUI: function getToComposeUI() {
        this.getToThreadList();
        this.tapIfExists(UIAQuery.Messages.COMPOSE_BUTTON);

        this.assertExists(
            UIAQuery.MESSAGE_NEW_COMPOSE_NAVBAR,
            'Could not get to New Message view.'
        );
    },

    /**
     *  Navigation function to get to turn off Auto-Correction
     */

    turnOffAutoCorrection: function turnOffAutoCorrection() {
        settings.launch();
        settings.tap("General");
        settings.tap("Keyboard");
        settings.setControl(UIAQuery.switches("Auto-Correction"), false);
    },


    /**
    * Deletes specified message thread.
    *
    * @targetApps MobileSMS
    *
    * @param {string} [args.threadName=null] - the name of the thread to be deleted (allows partial matches, null deletes first thread)
    * @param {object} [args.deleteOptions=null] - additional options to configure the delete call
    *  (see [Messages.deleteThread]{@link Messages#deleteThread} for more details on options that can be passed through deleteOptions)
    */
    deleteThread: function deleteThread(name) {
        var args = UIAUtilities.defaults(args, {
            threadName: name,
            threadIndex: 0,
            deleteOptions: null,
        });

        if (args.threadName) {
            args.threadNames = [args.threadName];
        }

        if (args.deleteOptions) {
            args.useSwipe = args.deleteOptions.useSwipe;
        }

        messages.deleteThreads(args);
    },

    /**
      *Find right Keyboard
      *
      *
    */

  //   _findKeyboard: function _findKeyboard(keyboard) {
  //   var startKeyboardID = target.activeApp().getKeyboardID();
  //   var keyboardID = startKeyboardID;
  //   var loopCount = 0;

  //   // setup keyboard
  //   UIALogger.logMessage('setup keyboardID ' + keyboardID);
  //   while ( (keyboardID != keyboard) && loopCount < 2) { 
  //     // extra loopCount to get around sometime the globe key skip keyboard.
  //     target.activeApp().tap(UIAQuery.buttons('Next keyboard'));
  //     keyboardID = target.activeApp().getKeyboardID();
  //     if (keyboardID == startKeyboardID) {
  //       loopCount++;
  //     }
  //   }
  //   if( keyboardID != keyboard ) {
  //     throw new UIAError('-------------------> FAILED : ' + keyboard + ' not found');
  //     return; 
  //   }
  // }, //_findKeyboard
    
};