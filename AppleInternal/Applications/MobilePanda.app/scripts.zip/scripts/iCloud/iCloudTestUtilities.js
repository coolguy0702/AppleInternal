load("Help.js");

var iCloudTestUtilities = {
    CLOUDDOCS_CONTAINER_DIRECTORY: "/var/mobile/Library/Mobile Documents/com~apple~CloudDocs/",
    CLOUDBOX_CONTAINER_DIRECTORY: "/var/mobile/Library/Mobile Documents/com~iosframeworksqa~CloudBox/",
    CLOUDBOX_DOCUMENTS_DIRECTORY:  this.CLOUDBOX_CONTAINER_DIRECTORY + "Documents",

    _binExists: function _binExists(binPath) {
        return this._systemRun("/usr/bin/type " + binPath, 30).exitCode == 0;
    },

    _listProcesses: function _listProcesses() {
        var processes = [ "bird", "cloudd" ]
        for (var i in processes) { this._listProc(processes[i]); }
    },

    _listProc: function _listProc(proc) {
        UIALogger.logMessage( "PGREP FOR %0".format(proc) );
        UIALogger.logMessage( this._systemRun("/bin/ps -ax | grep \"%0\" | sed \'/grep %0/d\' ".format(proc), 5).stdout );
    },

    _collectBrctlLogs: function _collectBrctlLogs() {
        var BRCTL_PATH = "/usr/bin/brctl";
        var BIRD_DUMP_PATH = "/var/mobile/Library/Logs/CrashReporter/DiagnosticLogs/";
        if (this._binExists(BRCTL_PATH)) {
            UIALogger.logMessage( "Removing previous copies of brctl diagnose dumps in %0 to avoid radar attachment flooding".format(BIRD_DUMP_PATH) );
            UIALogger.logMessage( this._systemRun("/bin/rm -rf %0/clouddocs*".format(BIRD_DUMP_PATH)).stdout );
            UIALogger.logMessage( "Completed removing old brctl logs; proceeding to collect brctl dump..." );
            UIALogger.logMessage( this._systemRun("%0 diagnose".format(BRCTL_PATH)).stdout );
            UIALogger.logMessage( "Completed brctl diagnose!" );
        } else {
            UIALogger.logWarning(BRCTL_PATH + " does not exist or has moved to a different filesystem location; skipping!");
        }
    },

    _collectSwitchclInfo: function _collectSwitchclInfo() {
        var SWITCHCL_PATH = this._systemRun("/usr/bin/which switchcl").stdout;
        if (SWITCHCL_PATH) {
            UIALogger.logMessage( "Collecting iCloud environment information..." );
            UIALogger.logMessage( "\n\n%0".format(this._systemRun("%0 --report".format(SWITCHCL_PATH)).stdout) );
        }
    },

    _collectWifiLogs: function _collectWifiLogs() {
        var SCRIPT_PATH = "/usr/local/bin/collectWiFiDebugInfo.sh";
        var WIFI_DUMP_PATH = "/var/mobile/Library/Logs/CrashReporter/WiFi/";
        if (this._binExists(SCRIPT_PATH)) {
            UIALogger.logMessage( "Removing previous copies of wifi dumps in " + WIFI_DUMP_PATH + " to avoid radar attachment flooding" );
            UIALogger.logMessage( this._systemRun("/bin/rm -rf " + WIFI_DUMP_PATH + "*WiFiDebugInfo*", 300).stdout );
            UIALogger.logMessage( "Completed removing old wifi logs; proceeding to collect wifi dump..." );
            UIALogger.logMessage( this._systemRun(SCRIPT_PATH, 300).stdout );
            UIALogger.logMessage( "Completed wifi dump collection!" );
        } else {
            UIALogger.logWarning(SCRIPT_PATH + " does not exist or has moved to a different filesystem location; skipping!");
        }
    },

    _collectStackShot: function _collectStackShot() {
        var CRSTACKSHOT_PATH = "/usr/local/bin/crstackshot";
        if (this._binExists(CRSTACKSHOT_PATH)) {
            UIALogger.logMessage( "Taking stackshot of system..." );
            UIALogger.logMessage( this._systemRun(CRSTACKSHOT_PATH, 300).stderr );
            UIALogger.logMessage( "Completed taking stackshots!" );
        } else {
            UIALogger.logWarning(CRSTACKSHOT_PATH + " does not exist or has moved to a different filesystem location; skipping!");
        }
    },

    _collectPing: function _collectPing() {
        var PING_BIN = "/sbin/ping";
        var PING_DEST = "icloud.com";
        if (this._binExists(PING_BIN)) {
            UIALogger.logMessage( "Running ping test..." );
            UIALogger.logMessage( this._systemRun(PING_BIN + " -c 10 " + PING_DEST, 300).stdout );
            UIALogger.logMessage( "Completed ping test!" );
        } else {
            UIALogger.logWarning(PING_BIN + " does not exist or has moved to a different filesystem location; skipping!");
        }
    },

    _printFolderContents: function _printFolderContents(folder) {
        if (folder === undefined) return;
        UIALogger.logMessage( "Getting contents of %0:".format(folder) );
        var command = this._systemRun("/bin/ls -la '%0'".format(folder), 30);
        UIALogger.logMessage( "Contents of %0:\n%1\n".format(folder, command.exitCode == 0 ? command.stdout : command.stderr) );
    },

    _printDirectoryStats: function _printDirectoryStats() {
        var directories = [ this.CLOUDBOX_CONTAINER_DIRECTORY, this.CLOUDBOX_DOCUMENTS_DIRECTORY, this.CLOUDDOCS_CONTAINER_DIRECTORY, ];
        for (var i in directories) this._printFolderContents( directories[i] );
        UIALogger.logMessage("DISK USAGE:\n%0\n".format( this._systemRun("/bin/df -h", 30).stdout ));
    },

    _collectiCloudLogs: function _collectiCloudLogs() {
        var collectors = [ this._listProcesses, this._collectStackShot, this._collectSwitchclInfo, this._collectPing, this._collectWifiLogs, /*this._collectBrctlLogs,*/ this._printDirectoryStats, ];
        for (var i in collectors) { collectors[i].bind(this)(); }
    },

    _toBool: function _toBool(thunk) {
        // Accepts either string "1" or "0" or a boolean
        return (typeof thunk == 'string') ? parseInt(thunk) : Boolean(thunk);
    },

    _toInt: function _toInt(thunk) {
        var newThunk = parseInt(Number(thunk));
        if (isNaN(newThunk)) this._throwException("Could not parse %0 to int!".format(thunk), 'Failed to parse variable to int');
        return newThunk;
    },

    _systemRun: function _systemRun(command, timeout) {
        timeout = (timeout === undefined) ? 300 : this._toInt(timeout);
        return performTask("/bin/sh", ['-c', "%0".format(command)], timeout);
    },


    runTest: function runTest(app, appMethod, args) {
        try {
            this._listProcesses();
            appMethod.apply(app, args);

        } catch(e) {
            throw e;

        } finally {
            UIALogger.logMessage("Element tree of the app:\n");
            UIALogger.logMessage("\n\n%0\n".format( tree(UIAQuery.application(app.bundleID())) ));

            UIALogger.logMessage( "Proceeding to collect relevant logs..." );
            this._collectiCloudLogs();
            UIALogger.logMessage( "Log collection completed for iCloud test!" );
        }
    },
}
