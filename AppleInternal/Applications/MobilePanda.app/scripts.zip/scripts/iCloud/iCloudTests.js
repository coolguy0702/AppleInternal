load("UIATesting.js");
load("SpringBoard.js");
load("Settings.js");
load("Settings+Accounts.js");
load("iCloudTestUtilities.js");

var iCloudTests = {
    /**
     * Sets iCloud testing environment
     * @overrideID Set iCloud Environment
     *
     * @param {object}      args Test arguments
     * @param {string}      [args.iCloudEnvironment="Production"] - iCloud X Environment.  Legal argument values are defined inside settings.setiCloudEnvironment()
     */
    setiCloudEnvironment: function setiCloudEnvironment(args) {
        args = UIAUtilities.defaults(args, {
            iCloudEnvironment: 'Production',
        });

        settings.launch();
        iCloudTestUtilities.runTest(settings, settings.setiCloudEnvironment, [ args.iCloudEnvironment, ]);
    },

    /**
     * Sign into iCloud
     *
     * @CaptureCondition PASS
     *
     * @param {object}      args Test arguments
     * @param {string}      [args.AppleID="PERSISTEDAPPLEID"]                   - AppleID
     * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"]   - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
     */
    signIn: function signIn(args) {
        args = UIAUtilities.defaults(args, {
            AppleID: 'PERSISTEDAPPLEID',
            AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
        });

        if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
            UIALogger.logMessage('Using the persisted AppleID password to create email account...');
            args.AppleIDPassword = springboard.appleIDPassword;
        }

        var options = {
            type:                       settings.toAccountType('iCloud'),
            address:                    args.AppleID,
            password:                   args.AppleIDPassword,
            throwIfAccountAlreadyAdded: false,
            syncOptions:                {},
        };

        iCloudTestUtilities._listProc("akd");

        settings.launch();
        iCloudTestUtilities.runTest(settings, settings.createEmail, [ options, ]);
    },

    /**
     * Sign out of iCloud
     *
     * @param {object}      args Test arguments
     * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"]   - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
     */
    signOut: function signOut(args) {
        args = UIAUtilities.defaults(args, {
            AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
        });

        if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
            UIALogger.logMessage('Using the persisted AppleID password to create email account...');
            args.AppleIDPassword = springboard.appleIDPassword;
        }

        settings.launch();
        iCloudTestUtilities.runTest(settings, settings.deleteiCloudAccount, [ args.AppleIDPassword, ]);
    },


    /**
     * Turn on iCloud Drive
     * @overrideID Turn On iCloud Drive
     *
     * @param {object}      args Test arguments
     * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"]   - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
     */
    turnOniCloudDrive: function turnOniCloudDrive(args) {
        args = UIAUtilities.defaults(args, {
            AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
        });

        if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
            UIALogger.logMessage('Using the persisted AppleID password to create email account...');
            args.AppleIDPassword = springboard.appleIDPassword;
        }

        settings.launch();
        iCloudTestUtilities.runTest(settings, settings.turnOniCloudDrive, [ args.AppleIDPassword, ]);
    },
}
