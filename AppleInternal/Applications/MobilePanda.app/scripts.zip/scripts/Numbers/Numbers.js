load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');

if (typeof numbers !== 'undefined') throw new UIAError("Numbers has already been loaded!", {identifier:"UIA module already loaded"});

/*******************************************************************************/
/*                                                                             */
/*   Mark: Numbers Query Constants                                             */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIAQuery.Numbers = {
    // FIRST_LAUNCH_SPLASHSCREEN: UIAQuery.query("TIAFirstLaunchDocumentStackContainerView"),

    CONTINUE_BUTTON: UIAQuery.buttons("Continue"),

    USE_ICLOUD_BUTTON: UIAQuery.buttons("Use iCloud"),

    START_USING_BUTTON: UIAQuery.buttons("View My Spreadsheets").orElse(UIAQuery.buttons("Use Numbers")).orElse(UIAQuery.buttons("Spreadsheets")),

    // NAVIGATION BAR BUTTONS
    BACK_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Back")),

    DOCUMENTS_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Spreadsheets")),

    ADD_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Add")),

    DONE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Done")),

    EDIT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Edit")),

    DELETE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Delete")),

    CANCEL_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Cancel")),

    RENAME_DOCUMENT_TEXTFIELD: UIAQuery.textFields("Rename Spreadsheet").isVisible(),

    get EXIT_DOCUMENT_EDIT_BUTTON () { return this.DONE_BUTTON.orElse(this.DOCUMENTS_BUTTON).orElse(this.BACK_BUTTON); },

    DELETE_DOCUMENT_BUTTON: UIAQuery.beginsWith("Delete").withPredicate("name CONTAINS 'Spreadsheet' OR name CONTAINS 'All Devices'"),

    DOCUMENT_MANAGER_VIEW: UIAQuery.query("TSADocumentManagerView"),

    EMPTY_DOCUMENT_MANAGER_VIEW: UIAQuery.query("TSADocumentManagerNoDocView"),

    DOCUMENT_EDIT_VIEW: UIAQuery.query("TSDScrollView"),

    DOCUMENT_PAGE_SETUP_VIEW: UIAQuery.query("TPDocSetupScrollView"),

    FIRST_LAUNCH_VIEW: UIAQuery.query("TSAFirstLaunchView"),

    CREATE_DOCUMENT_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons("Create Spreadsheet")),

    SELECT_CREATE_DOCUMENT_BUTTON: UIAQuery.staticTexts().withPredicate('name contains[c] "Create Spreadsheet"').parent(),

    TEXT_KEYBOARD_BUTTON: UIAQuery.buttons("Text"),

    NEW_SHEET_BUTTON: UIAQuery.buttons("New sheet"),

    SHEETS_TAB: UIAQuery.query("TNTabNavigatorView"),
};



/*******************************************************************************/
/*                                                                             */
/*   Mark: Numbers UI State Constants                                          */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIStateDescription.Numbers = {
    FIRST_LAUNCH_VIEW:          'FIRST LAUNCH',
    DOCUMENT_MANAGER_VIEW:      'DOCUMENT MANAGER',
    EDIT_DOCUMENT_VIEW:         'EDIT DOCUMENT',
    CHOOSE_TEMPLATE_VIEW:       'CHOOSE TEMPLATE',
    DOCUMENT_EDIT_SELECTION:    'DOCUMENT EDIT SELECTION',
    DOCUMENT_COLLAB_SELECTION:  'DOCUMENT COLLAB SELECTION',
    DOCUMENT_PAGE_SETUP_VIEW:   'DOCUMENT PAGE SETUP',
}

/**
    @namespace
    @augments UIAApp
*/
var numbers = target.appWithBundleID("com.apple.Numbers");



/*******************************************************************************/
/*                                                                             */
/*   Mark: Numbers Constants and Enums                                         */
/*                                                                             */
/*      Enums used by the Numbers library, for internal and external API use   */
/*                                                                             */
/*******************************************************************************/



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Private UIAApp Extension Methods                 */
/*                                                                             */
/*      UIAApp extension methods that are specifically useful for Numbers      */
/*                                                                             */
/*******************************************************************************/

numbers._enterTextAndDismiss = function _enterTextAndDismiss(query, text, overwrite) {
    if (overwrite === undefined) overwrite = true;
    this.enterText(query, String(text), {clearTextBeforeTyping: Boolean(overwrite)});

    var keyboard = UIAQuery.keyboard();
    if (this.exists(keyboard)) {
        UIALogger.logMessage("Dismissing keyboard");
        this.dismissKeyboard()
        this.tapIfExists(keyboard.andThen(UIAQuery.buttons('Done').orElse(UIAQuery.buttons('Search'))));
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Numbers Navigation & Navigation Setup            */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

function isHorizontalCompactUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.COMPACT;
}

function isHorizontalRegularUI() {
    return target.activeApp().inspect(UIAQuery.windows().isVisible()).horizontalSizeClass === UIUserInterfaceSizeClass.REGULAR;
}

numbers._navigationBarValueIs = function _navigationBarValueIs(navigationBarValue) {
    var navigationBarInfo = this.inspect(UIAQuery.VISIBLE_POPOVERS.andThen(UIAQuery.TOP_NAVBAR.isVisible())) || this.inspect(UIAQuery.TOP_NAVBAR.isVisible());
    var navigationBarName = navigationBarInfo ? navigationBarInfo.name : null;
    return navigationBarName === navigationBarValue;
}

numbers.NAVIGATION_VIEW_TRANSITIONS = [
    { from: UIStateDescription.Numbers.EDIT_DOCUMENT_VIEW, to: UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW, transition:{action: function() { numbers.tap(UIAQuery.Numbers.EXIT_DOCUMENT_EDIT_BUTTON); numbers.tapIfExists(UIAQuery.Numbers.EXIT_DOCUMENT_EDIT_BUTTON); }} },
    { from: UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Numbers.DOCUMENT_EDIT_SELECTION, transition:{action:numbers.tap, options:UIAQuery.Numbers.EDIT_BUTTON} },
    { from: UIStateDescription.Numbers.DOCUMENT_EDIT_SELECTION, to: UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW, transition:{action:numbers.tap, options:UIAQuery.Numbers.DONE_BUTTON} },
    { from: UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW, to: UIStateDescription.Numbers.CHOOSE_TEMPLATE_VIEW, transition:{action:function() { numbers.tap(UIAQuery.Numbers.CREATE_DOCUMENT_BUTTON); numbers.tapIfExists(UIAQuery.Numbers.SELECT_CREATE_DOCUMENT_BUTTON); }} },
    { from: UIStateDescription.Numbers.DOCUMENT_PAGE_SETUP_VIEW, to: UIStateDescription.Numbers.EDIT_DOCUMENT_VIEW, transition:{action: function() { numbers.tap(UIAQuery.query("Done")); numbers.tapIfExists(UIAQuery.query("Done")); }} },
    { from: UIStateDescription.Numbers.FIRST_LAUNCH_VIEW, to: UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW, transition:{action: function () { numbers._walkThroughFirstLaunch(); }} },

];

// Define functions for determining current app's view state
numbers.NAVIGATION_VIEWS = {};
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW]          = {action:numbers.exists, options:UIAQuery.Numbers.DOCUMENT_MANAGER_VIEW};
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.EDIT_DOCUMENT_VIEW]             = {action:numbers.exists, options:UIAQuery.Numbers.DOCUMENT_EDIT_VIEW};
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.DOCUMENT_EDIT_SELECTION]        = {action: function() { return numbers._navigationBarValueIs('Select a Document') || (numbers.exists(UIAQuery.Numbers.DOCUMENT_MANAGER_VIEW) && numbers.exists(UIAQuery.Numbers.DONE_BUTTON)); } };
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.CHOOSE_TEMPLATE_VIEW]           = {action: function() { return numbers._navigationBarValueIs('Choose a Template') || numbers._navigationBarValueIs('Templates'); } };
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.DOCUMENT_PAGE_SETUP_VIEW]       = {action:numbers.exists, options:UIAQuery.Numbers.DOCUMENT_PAGE_SETUP_VIEW};
numbers.NAVIGATION_VIEWS[UIStateDescription.Numbers.FIRST_LAUNCH_VIEW]              = {action:numbers.exists, options:UIAQuery.Numbers.FIRST_LAUNCH_VIEW};

// Defines Numbers Navigation
numbers.navigation = new UIANavigation(numbers, numbers.NAVIGATION_VIEW_TRANSITIONS, numbers.NAVIGATION_VIEWS);



/*******************************************************************************/
/*                                                                             */
/*   Mark: Numbers Library Public API - Navigation                             */
/*                                                                             */
/*      This is where all public API methods for Numbers Navigation            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Safari for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
*/
numbers.currentUIState = function currentUIState() {
    var currentUIState = this.navigation.getCurrentState() || 'UNKNOWN STATE';
    UIALogger.logMessage("UI is currently on '%0'".format(currentUIState));
    return currentUIState;
}

/**
 * Launches Numbers.  This differs from numbers.launch() in that it will walk through the first-time splashscreen
 *
 * @throws If unable to launch Numbers or walk through the splashscreen to the Document Manager View
*/
numbers.launchApp = function launchApp() {
    this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Numbers Library Public API - Document Management                    */
/*                                                                             */
/*      This is where all public API methods for Numbers Navigation            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Create new document
 *
 * @param {string}   DocumentName           - Name of the document
 * @param {object}   DocumentOptions        - Name of the numbers
 *
 * @throws If unable to create a new document
 */
numbers.createDocument = function createDocument(DocumentName, DocumentOptions) {
    DocumentOptions = numbers._defaultDocumentOptions(DocumentOptions);

    this.navigation.goTo(UIStateDescription.Numbers.CHOOSE_TEMPLATE_VIEW);
    this.tap( UIAQuery.tableCells(DocumentOptions.TemplateType) );

    this.waitUntilPresent(UIAQuery.Numbers.DOCUMENT_EDIT_VIEW, 10);
    this._renameDocument(DocumentOptions.TemplateType, DocumentName);
    this.editDocument(DocumentName, DocumentOptions);
}

/**
 * Edit existing document
 *
 * @param {string}   DocumentName           - Name of the document to be edited
 * @param {object}   DocumentOptions        - Name of the numbers
 *
 * @throws If unable to find or edit document
 */
numbers.editDocument = function editDocument(DocumentName, DocumentOptions) {
    if (DocumentOptions.NewDocumentName) {
        this._renameDocument(DocumentName, DocumentOptions.NewDocumentName);
        DocumentName = DocumentOptions.NewDocumentName;
    }

    this._getToDocument(DocumentName);
    this._applyDocumentContents(DocumentOptions.DocumentContents);

    UIALogger.logMessage("Finished applying changes to document; exiting document");
    this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
}

/**
 * Deletes a list of existing documents.  Assumes all documents are uniquely named
 *
 * @param {string|string[]}    DocumentName         - Name(s) of the documents to be deleted
 *
 * @throws If unable to find or delete the listed documents
 */
numbers.deleteDocuments = function deleteDocuments(DocumentNames) {
    DocumentNames = this._toStringList(DocumentNames);
    var documents = DocumentNames.map( (function (dn) { return this._findDocument(dn); }).bind(this) );

    this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_EDIT_SELECTION);
    for (var i in documents) this.tap( documents[i] );

    this._tapDeleteDocument();

    var remainingFiles = DocumentNames.filter( (function (dn) { return this._findDocument(dn, true); }).bind(this) );
    if (remainingFiles.length > 0) throw new UIAError("The following files did not appear to be deleted: %0".format(JSON.stringify(remainingFiles)), {identifier:"Document(s) could not be deleted"});
    else UIALogger.logMessage("Successfully deleted the following files: %0".format(JSON.stringify(DocumentNames)));
}

numbers.deleteAllDocuments = function deleteAllDocuments() {
    this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_EDIT_SELECTION);
    var allDocuments = UIAQuery.Numbers.DOCUMENT_MANAGER_VIEW.andThen( UIAQuery.buttons().withPredicate("parent.name != 'UISegmentedControl' AND parent.name != 'TIADocumentManagerSearchBar'") );

    var buttonNames = this.inspectAll(allDocuments).map( function (n) {return n.name;} );
    for (var i in buttonNames) {
        this.tap( UIAQuery.buttons(buttonNames[i]).parent() );
    }

    this._tapDeleteDocument();

    if (this.exists( UIAQuery.Numbers.EMPTY_DOCUMENT_MANAGER_VIEW )) {
        UIALogger.logMessage("All documents appear to have been successfully deleted");
    } else {
        var remainingDocs = this.inspectAll(allDocuments).map( function (n) {return n.name;} )
                                                         .map( (function (n) {return this.inspect( UIAQuery.buttons(n).parent() ).name;}).bind(this) );
        throw new UIAError("The following files were not deleted:  %0".format(JSON.stringify(remainingDocs)), {identifier:"Some files were not deleted"});
    }
}

numbers.sendDocument = function sendDocument() {
    /* DocumentName, Format/Numbers, Word, ePub, PDF/, SendMethod/tons of options/ */
}

numbers.shareDocument = function shareDocument() {
    // DocumentName, ShareOptions/Allow editing, View only/, Password, PasswordHint
    // should return Share Link
}

numbers.stopSharingDocument = function stopSharingDocument() {
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Variable/Argument Sanitizers                     */
/*                            and Struct Defaults                              */
/*                                                                             */
/*      Sanitizes variables against types and Numbers-specific enums/structs   */
/*                                                                             */
/*******************************************************************************/

numbers._defaultDocumentOptions = function _defaultDocumentOptions(DocumentOptions) {
    DocumentOptions = UIAUtilities.defaults((typeof DocumentOptions !== "object") ? {} : DocumentOptions, {
        TemplateType:                       'Blank',
        NewDocumentName:                    undefined,
        DocumentContents:                   [],
    });

    DocumentOptions.TemplateType        = String(DocumentOptions.TemplateType);
    DocumentOptions.NewDocumentName     = (DocumentOptions.NewDocumentName == undefined) ? undefined : String(DocumentOptions.NewDocumentName);
    DocumentOptions.DocumentContents    = DocumentOptions.DocumentContents.map( (function (dc) {return this._cleanedDocumentContent(dc);}).bind(this) );

    return DocumentOptions;
}

numbers._cleanedDocumentContent = function _cleanedDocumentContent(DocumentContent) {
    DocumentContent = UIAUtilities.defaults((typeof DocumentContent !== "object") ? {} : DocumentContent, {
        Sheet:                              1,
        Row:                                1,
        Column:                             1,
        Contents:                           '',
        Overwrite:                          false,
    });
    DocumentContent.Sheet           = Number(DocumentContent.Sheet);
    DocumentContent.Row             = Number(DocumentContent.Row);
    DocumentContent.Column          = String(DocumentContent.Column);
    DocumentContent.Contents        = String(DocumentContent.Contents);
    DocumentContent.Overwrite       = Boolean(DocumentContent.Overwrite);
    return DocumentContent;
}


numbers._toStringList = function _toStringList(x) {
    if (x === undefined || x === null) throw new UIAError("List is null or empty!", {identifier:"Invalid list"});
    else if (x instanceof Array) return x.map( function (i) {return String(i);} );
    else return [ String(x) ];
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Navigation                                       */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigation in Numbers                                              */
/*                                                                             */
/*******************************************************************************/

/**
 * Asserts device is in a specified view in Numbers
 *
 * @param {enum} ExpectedView            - The expected view (enum UIStateDescription.Numbers)
 *
 * @throws If current view !== ExpectedView
 */
numbers._ensureCurrentViewIs = function _ensureCurrentViewIs(ExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView !== ExpectedView) throw new UIAError("UIA expected to be in the '%0' view but is currently in the '%1' view instead!".format(ExpectedView, ActualView), {identifier:"Device in unexpected view"});
    return true;
}

/**
 * Asserts device is NOT in a specified view in Numbers
 *
 * @param {enum} NotExpectedView            - The unexpected view (enum UIStateDescription.Numbers)
 *
 * @throws If current view === NotExpectedView
 */
numbers._ensureCurrentViewIsNot = function _ensureCurrentViewIsNot(NotExpectedView) {
    var ActualView = this.currentUIState();
    if (ActualView === NotExpectedView) throw new UIAError("UIA expected to not be in the '%0' view but currently is!".format(NotExpectedView), {identifier:"Device in unexpected view"});
    return true;
}

numbers._walkThroughFirstLaunch = function _walkThroughFirstLaunch() {
    var validQueries = [ UIAQuery.Numbers.CONTINUE_BUTTON, UIAQuery.Numbers.CONTINUE_BUTTON, UIAQuery.Numbers.USE_ICLOUD_BUTTON, UIAQuery.Numbers.START_USING_BUTTON, ];
    var button = validQueries.reduce(function (qA, qB, idx, arr) { return qA.orElse(qB.isVisible()); }, UIAQuery.withPredicate('FALSEPREDICATE'));
    while (this.exists(UIAQuery.Numbers.FIRST_LAUNCH_VIEW)) {
        this.waitUntilPresent(button, 60);
        this.tap(button);
        this.delay(2); // This is necessary b/c the taps enter a race condition otherwise
    }
}

/**
 * Walks to Manage Document View, and returns the UIAQuery to the document, if found.  Useful for building other Numbers library functions
 *
 * @param {string}      DocumentName         - Name of the document to be renamed
 * @param {bool}        DontThrow            - If set to true, will return false upon failure to find document (instead of throwing UIAError)
 *
 * @throws If unable to find the document, and DontThrow is set to false
 *
 * @returns Returns UIAQuery to the document if the document is found; false otherwise
 */
numbers._findDocument = function _findDocument(DocumentName, DontThrow) {
    DocumentName = String(DocumentName);
    this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);

    var documentQuery = UIAQuery.beginsWith("%0,".format(DocumentName)).leaves().parent();
    var numMatchingDocuments = this.count(documentQuery);

    var returnQuery = undefined;
    var msg = "";
    var errorID = "";

    if (numMatchingDocuments < 1) {
        msg = "Did not find a document named '%0'".format(DocumentName);
        errorID = "Didn't find the target document matching name";

    } else if (numMatchingDocuments > 1) {
        msg = "Found %0 documents with name matches the given name (beginsWith): '%1'".format(numMatchingDocuments, DocumentName);
        errorID = "Found multiple documents matching name";

    } else {
        msg = "One match found; will assume this is the target document!";
        returnQuery = documentQuery;
    }

    UIALogger.logMessage(msg);
    if (returnQuery === undefined) {
        if (DontThrow === true) return undefined;
        else throw new UIAError(msg, {identifier:errorID});
    } else return returnQuery;
}

/**
 * Opens the document
 *
 * @param {string}      DocumentName         - Name of the document to be renamed
 *
 * @throws If unable to find or open the document
 */
numbers._getToDocument = function _getToDocument(DocumentName) {
    var documentQuery = numbers._findDocument(DocumentName);
    this.tap(documentQuery);
    this.waitUntilPresent(UIAQuery.Numbers.DOCUMENT_EDIT_VIEW, 10);
}

/**
 * Tap the Delete Document while in Select Document view, and handles the Verify iCloud Document Delete alert that appears once
 *
 * @throws If unable to delete document
 */
numbers._tapDeleteDocument = function _tapDeleteDocument() {
    var _deleteDocumentAlertHandler = function() {
        var app = numbers;
        if (app.exists(UIAQuery.withPredicate("name CONTAINS[c] 'Deleting '"))) {
            app.tap(UIAQuery.alerts().andThen('Delete'));
            return true;
        } return false;
    };

    this.withAlertHandler(_deleteDocumentAlertHandler, function () {
        this.tap( UIAQuery.Numbers.DELETE_BUTTON );
        this.tap( UIAQuery.Numbers.DELETE_DOCUMENT_BUTTON );

        this.navigation.goTo(UIStateDescription.Numbers.CHOOSE_TEMPLATE_VIEW);
        this.navigation.goTo(UIStateDescription.Numbers.DOCUMENT_MANAGER_VIEW);
    });
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Editing Documents                                */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigating to specific documents in Numbers                        */
/*                                                                             */
/*******************************************************************************/

/**
 * Rename an existing document.  Assumes all documents are uniquely named
 *
 * @param {string}   DocumentName           - Name of the document to be renamed
 * @param {object}   NewDocumentName        - New name for the document
 *
 * @throws If unable to find or rename document
 */
numbers._renameDocument = function _renameDocument(DocumentName, NewDocumentName) {
    NewDocumentName = String(NewDocumentName);
    var documentQuery = this._findDocument(DocumentName);

    var newDocumentQuery = this._findDocument(NewDocumentName, true);
    if (newDocumentQuery !== undefined) {
        throw new UIAError("Cannot rename document to '%0' because another such document already exists!".format(NewDocumentName), {identifier:"Document rename conflict"});
    }

    this.tap( documentQuery.andThen(UIAQuery.beginsWith('Rename')) );
    this.waitUntilPresent(UIAQuery.Numbers.RENAME_DOCUMENT_TEXTFIELD, 10);
    this._enterTextAndDismiss(UIAQuery.Numbers.RENAME_DOCUMENT_TEXTFIELD, NewDocumentName);

    if (numbers._findDocument(NewDocumentName) !== undefined) UIALogger.logMessage("Successfully renamed document to '%0'".format(NewDocumentName));
}

/**
 * Apply a list of changes to a document.  Assumes device is currently in Edit Document View
 *
 * @param {DocumentContent[]}   DocumentContents           - List of changes to apply to a document.  Schema for DocumentContent is defined in the documentation for numbers._cleanedDocumentContent()
 *
 * @throws If unable to apply the specified changed to a document
 */
numbers._applyDocumentContents = function _applyDocumentContents(DocumentContents) {
    this.waitUntilPresent(UIAQuery.Numbers.DOCUMENT_EDIT_VIEW, 10);
    for (var i in DocumentContents) {
        var content = DocumentContents[i];
        UIALogger.logMessage("Attempting to write to document %0 [%1]:    %2".format(content.DocumentSection, content.Overwrite ? "OVERWRITE" : "APPEND", content.Contents));
        this._enterTextToDocumentSection(content.Sheet, content.Row, content.Column, content.Contents, content.Overwrite);
    }
}

/**
 * Enters text to page section.  Assumes device is currently in Edit Document View
 *
 * @param {int}         Sheet               - Sheet to add the text to
 * @param {int}         Row                 - Row to add the text to
 * @param {int}         Column              - Column to add the text to
 * @param {string}      Contents            - Content to add to the cell
 * @param {bool}        Overwrite           - If true; clear all text inside field prior to typing in Contents
 *
 * @throws If unable to add the specified contents into the specified document section
 */
numbers._enterTextToDocumentSection = function _enterTextToDocumentSection(Sheet, Row, Column, Contents, Overwrite) {
    var sheetQuery = UIAQuery.contains("Sheet %0".format(Sheet));
    var cellQuery = UIAQuery.contains("Row %0, Column: %1".format(Row, Column));

    if (! this.inspect(sheetQuery).isSelected) {
        this.tap(sheetQuery);
        this.delay(2);
    }
    this.tap(cellQuery, {tapCount:2});
    
    this._enterTextAndDismiss(cellQuery, Contents, Overwrite);

    this.tapIfExists(UIAQuery.query("Done").isVisible());
    this.tapIfExists(UIAQuery.query("Done").isVisible());
}

numbers._getDocumentContents = function _getDocumentContents(DocumentName) {
    this._getToDocument(DocumentName);
    this.waitUntilPresent(UIAQuery.Numbers.DOCUMENT_EDIT_VIEW, 10);
    return this.inspect(UIAQuery.textViews('Body')).value;
}
