load("UIATesting.js");
load("SpringBoard.js");
load("Numbers.js");

if (typeof NumbersTestUtilities !== 'undefined') throw new UIAError("NumbersTestUtilities has already been loaded!", {identifier:"UIA module already loaded"});
if (typeof NumbersTest !== 'undefined') throw new UIAError("NumbersTest has already been loaded!", {identifier:"UIA module already loaded"});

var NumbersTestUtilities = {
    _cleanedBool: function _cleanedBool(boolString) {
        return (typeof boolString == 'string') ? boolString.match(/^true$/i) :
               (typeof boolString == 'number' ) ? (boolString != 0) :
               (typeof boolString == 'boolean' ) ? boolString : undefined;
    },

    _cleanedString: function _cleanedString(string) {
        return string ? String(string) : undefined;
    },

    _cleanedStringArray: function _cleanedStringArray(thunk) {
        var arr = [];
        if (typeof thunk == 'undefined') return arr;
        else if (thunk === null) return arr;
        else if (thunk instanceof Array) {
            for (var i in thunk) {
                arr.push( this._cleanedString(thunk[i]) );
            }

        } else {
            arr.push( this._cleanedString(thunk) );
        }

        return arr;
    },

    defaultTestArgs: function defaultTestArgs(args, customDefaults) {
        // First override with custom defaults if available
        if (typeof customDefaults == 'object') args = UIAUtilities.defaults(args, customDefaults);

        return UIAUtilities.defaults(args, {
            DocumentName:               "",
            NewDocumentName:            "",
            TemplateType:               "",
            DocumentContents:           [],
            DocumentNames:              [],
        });
    },

    // Parses args dictionary into calendar test arguments
    parseOptions: function parseOptions(args) {
        // First do type-checking
        var options = {
            DocumentName:               this._cleanedString(args.DocumentName),
            NewDocumentName:            this._cleanedString(args.NewDocumentName),
            TemplateType:               this._cleanedString(args.TemplateType),
            DocumentContents:           args.DocumentContents.map( function(dc) {return numbers._cleanedDocumentContent(dc);} ),
            DocumentNames:              this._cleanedStringArray(args.DocumentNames),
        };

        UIALogger.logMessage("Numbers options passed in: %0".format(JSON.stringify(options)));
        return options;
    },
};


/**
 * @namespace NumbersTests
 */
var NumbersTests = {

/*******************************************************************************/
/*                                                                             */
/*   Mark: NumbersTests Public API - Navigation                                */
/*                                                                             */
/*      This is where test interfaces for handling Numbers navigation          */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Launches Numbers, and walks through the splashscreen if necessary
     * This test is an interface test to the Numbers library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    launchApp: function launchApp(args) {
        numbers.launchApp();
    },


/*******************************************************************************/
/*                                                                             */
/*   Mark: NumbersTests Public API - Documents                                 */
/*                                                                             */
/*      This is where test interfaces for handling events                      */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Creates a new document
     * This test is an interface test to the Numbers library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.TemplateType="Blank"]                                                                         - Document template to start with
     * @param {DocumentContent[]}   [args.DocumentContents=[{"Sheet":1,"Row":1,"Column":1,"Contents":"SAMPLE TEXT","Overwrite":false}]]         - Contents to add to document
     */
    createDocument: function createDocument(args) {
        args = NumbersTestUtilities.defaultTestArgs(args);
        var options = NumbersTestUtilities.parseOptions(args);

        numbers.createDocument(options.DocumentName, options);
    },

    /**
     * Edits an existing document in Numbers
     * This test is an interface test to the Numbers library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string}              [args.DocumentName="SAMPLE NAME"]                                                                   - (Required) Name of document
     * @param {string}              [args.NewDocumentName=""]                                                                           - New Name of document
     * @param {DocumentContent[]}   [args.DocumentContents=[{"Sheet":1,"Row":1,"Column":1,"Contents":"MODIFIED TEXT","Overwrite":true}]]        - Contents to add to document
     */
    editDocument: function editDocument(args) {
        args = NumbersTestUtilities.defaultTestArgs(args);
        var options = NumbersTestUtilities.parseOptions(args);

        numbers.editDocument(options.DocumentName, options);
    },

    /**
     * Delete existing document(s) in Numbers
     * This test is an interface test to the Numbers library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     * @param {string[]}      [args.DocumentNames=["SAMPLE NAME"]]      - (Required) Name of document
     */
    deleteDocuments: function deleteDocuments(args) {
        args = NumbersTestUtilities.defaultTestArgs(args);
        var options = NumbersTestUtilities.parseOptions(args);

        numbers.deleteDocuments(options.DocumentNames);
    },

    /**
     * Delete ALL existing document(s) in Numbers
     * This test is an interface test to the Numbers library function (single user action), not a specific QL test.
     *
     * @param {object} args Test arguments
     */
    deleteAllDocuments: function deleteAllDocuments(args) {
        numbers.deleteAllDocuments();
    },
};
