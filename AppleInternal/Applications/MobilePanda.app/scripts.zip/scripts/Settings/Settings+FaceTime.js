load('UIAApp.js');
load('UIASemaphore.js');

load('Settings.js');
load('SpringBoard.js');

/**
 * Set up Thumper on a primary device (iPhone).
 *
 * @overrideID Enable Thumper Primary
 *
 */
settings.enableThumperSettingsPrimary = function enableThumperSettingsPrimary() {
    UIALogger.logMessage('Navigate to top level and then descend into Calls on other devices to toggle settings');

    this.returnToTopLevel();
    this.navigateNavigationViews(['Phone', 'Calls on Other Devices']);

    var allowDeviceCallsSwitch = UIAQuery.switches('Allow Calls on Other Devices');
    if (this.inspect(allowDeviceCallsSwitch).value == 0) {
        this.setControl(UIAQuery.switches('Allow Calls on Other Devices'), true);
    } else {
        UIALogger.logMessage('Allowing calls on other devices already enabled');
        this.setControl(allowDeviceCallsSwitch, false);
        if (this.waitUntilAbsent(UIAQuery.query("ALLOW CALLS ON"))) {
             this.setControl(allowDeviceCallsSwitch, true);
        }
    }

    try {
        var WIFI_CALLING_ENABLED_ALERT = UIAQuery.alerts('Wi-Fi Calling for Other Devices');
        var WIFI_CALLING_ENABLED = UIAQuery.contains('Wi-Fi Calling for Other Devices');

        springboard.handlingAlertsInline(WIFI_CALLING_ENABLED, function() {
            settings.tap('Add Wi-Fi Calling For Other Devices');

            //wait for the alert that wifi calling has now been enabled for other devices
            if (!springboard.waitUntilPresent(WIFI_CALLING_ENABLED_ALERT,20)) {
                throw new UIAError('Timed out waiting for enabling of Wifi Calling for other Devices');
            } else {
                //dismiss alert
                this.tap('default-button');
                UIALogger.logMessage('Found Enabled Calling for Other Devices Alert');
            }
        });
    } catch (e) {
        UIALogger.logError(e);
        throw new UIAError('Could not turn on calls for other devices, because either iCloud or FaceTime were not signed in');
    }

    this.navigateNavigationViews(['Phone', 'Wi-Fi Calling']);

    var allowWiFiCallsSwitch = UIAQuery.switches('Wi-Fi Calling on This iPhone');
    if (this.inspect(allowWiFiCallsSwitch).value == 0) {
        this.handlingAlertsInline(UIAQuery.contains('Enable Wi-Fi Calling?'),  function() {

            //turn on Wi-Fi calls
            this.setControl(allowWiFiCallsSwitch, true);
            this.tap('Enable');

            //TODO: HANDLE EMERGENCY ADDRESS UI
        });
    } else {
        UIALogger.logMessage('Allow Wi-Fi Calls already enabled');
    }
}

/**
 * Set up Thumper on a secondary device and request passcode(iPad,  iPod Touch).
 *
 * @overrideID Thumper Pair Secondary Device
 * @param {string} semaphoreUUID - Semaphore UUID used to lock and unlock for transfer of passcode and phone information
 * @param {int} timeout          - Timeout used to wait for the semaphore change state
 */
settings.requestPairFromSecondayDevice = function requestPairFromSecondayDevice(semaphoreUUID,timeout) {

    if (semaphoreUUID !== null) {
        UIASemaphore.lock(semaphoreUUID);
    }

    //Navigate to settings -> FaceTime and enable calls from iPhone
    this.returnToTopLevel();
    this.navigateNavigationViews(['FaceTime']);

    var passcodePromptAppeared = false;
    var CALLS_FROM_PHONE_SWITCH = UIAQuery.switches('Calls from iPhone');
    var CALLS_FROM_PHONE_TABLE_CELL = UIAQuery.tableCells('Calls from iPhone');
    var UPGRADE_ALERT = UIAQuery.alerts('Upgrade to Wi-Fi Calling');
    var WIFI_CALLS_FROM_ALERT = UIAQuery.alerts().contains("Wi-Fi calls from");

    if (!this.waitUntilPresent(CALLS_FROM_PHONE_TABLE_CELL)) {
        throw new UIAError(
            '"Calls from iPhone" table cell was never present. \
            Could not tap to begin request for pair'
        );
    }

    this.tap(CALLS_FROM_PHONE_TABLE_CELL);

    //TODO: Ensure work flow of setting calls from iPhone
    if (this.exists(CALLS_FROM_PHONE_SWITCH)) {
        this.setControl(CALLS_FROM_PHONE_SWITCH, true);
    } else {
        throw new UIAError(
            'Could not find calls from iPhone switch, \
            In unknown Thumper setup state'
        );
    }

    if (!this.waitUntilPresent(UIAQuery.tableCells('Upgrade to Wi-Fi Calling'))) {
        throw new UIAError(
            '"Calls from iPhone" table cell was never present. \
            Could not tap to begin request for pair'
        );
    }

    this.tap('Upgrade to Wi-Fi Calling');

    springboard.handlingAlertsInline(UPGRADE_ALERT.orElse(WIFI_CALLS_FROM_ALERT), function() {

        UIALogger.logMessage('Attempting to handle Passcode Alerts In Line');
        var enableButton = UIAQuery.buttons('Enable');

        if (this.waitUntilPresent(enableButton,  20)) {
            this.tap(enableButton);
        }

        if (this.waitUntilPresent(WIFI_CALLS_FROM_ALERT,  20)) {
            passcodePromptAppeared = true;
            var label = this.inspect(WIFI_CALLS_FROM_ALERT).label;

            var labelDigits = label.match(/\d+/g);

            //passcode is the last number phrase of message
            passcode = labelDigits.pop();

            //build normalized phone number (without ',', '-', '+', ...)
            phoneNumber = labelDigits.join('');

            UIALogger.logMessage('Semaphore passcode given was: ' + passcode);

            var options = {};
            options.timeout = timeout;
            options.payload = {passcode: passcode, phoneNumber: phoneNumber};
            options.thowOnFail = new UIAError('Could not lock semaphore to send passcode');

            if (semaphoreUUID !== null) {
                UIASemaphore.unlock(semaphoreUUID,options);
            } else {
                //write semaphore data to logs or pull out other data
                data = {};
                data.client = 'Thumper';
                data.passcode = options.payload.passcode;
                data.phoneNumber = options.payload.phoneNumber;
                data.model = target.model();
                data.date = Date.now();
                var passcodeFile = '/tmp/thumper/thumperPasscode.json';
                var cmd = "echo '" +  JSON.stringify(data) + "' >" + passcodeFile
                UIALogger.logDebug(JSON.stringify(target.performTask('/bin/mkdir', ['-p', '/tmp/thumper'], 10)));
                UIALogger.logDebug(JSON.stringify(target.performTask('/bin/sh', ['-c', cmd], 10)));
            }
        }


    });



}

/**
* Have a Secondary Device verify the thumper pair to a primary device (wait until inactive)
*
* Expected starting states: Works for any In Call UI state.
*
* @param {int} timeout - Seconds to wait for hand-off to occur.
*
* @returns {boolean} If verify was successful.
*
* @throws If Validation activated prompt is not apparent. (Use your ** account to make and receive calls...)
* @throws If Timed out waiting for activation of wifi calling
*/
settings.validateThumperPairSecondary = function validateThumperPairSecondary() {
    var WIFI_CALLS_FROM_ALERT = UIAQuery.alerts().contains("Wi-Fi calls from");

    this.navigateNavigationViews(['FaceTime','Calls from iPhone']);

    springboard.handlingAlertsInline(WIFI_CALLS_FROM_ALERT, function() {
        if (!this.waitUntilAbsent(WIFI_CALLS_FROM_ALERT, 120)) {
            throw new UIAError('Timed out waiting for Thumper Activation Prompt to disappear');
        }

        var ACTIVATION_COMPLETE = UIAQuery.contains('Update Emergency Address').isVisible();
        var ACTIVATION_DIALOG = UIAQuery.contains('Upgrade to Wi-Fi Calling').isVisible().orElse(UIAQuery.contains('Waiting for Wi-Fi calling activation').isVisible());

        if (!settings.waitUntilAbsent(ACTIVATION_DIALOG, 60)) {
            throw new UIAError(
                'Could not find dismissal of activation dialog after enabling device with passcode'
            );
        }
        else if (!settings.exists(ACTIVATION_COMPLETE)) {
            throw new UIAError(
                'Could not find activation complete dialog'
            )
        }
        else {
            return true;
        }
    })

    return false;
}

/**
 * Set up Thumper on a secondary device (iPad,  iPod Touch).
 *
 * @overrideID Thumper Pair Primary With Secondary Passcode
 * @param {string} semaphoreUUID    - Semaphore UUID used to lock and unlock for transfer of passcode and phone information
 * @param {string} phoneNumber      - Phone number to be stored with semaphore
 */
settings.pairThumperPrimaryWithPasscode = function pairThumperPrimaryWithPasscode(semaphoreUUID,phoneNumber,passcode) {
    UIALogger.logMessage('Beginning pairing of passcode for primary device');

    var passcodePromptAppeared = false;

    var ENTER_PASSCODE_QUERY = UIAQuery.staticTexts("Wi-Fi Calling");

    if (springboard.waitUntilPresent(ENTER_PASSCODE_QUERY,20)) {
        UIALogger.logMessage('Waiting for passcode query.')
    }

    springboard.handlingAlertsInline(ENTER_PASSCODE_QUERY, function() {
        UIALogger.logMessage('Springboard: handling alerts in line')

        if (semaphoreUUID !== null && UIASemaphore.poll(semaphoreUUID) === UIASemaphore.States.UNLOCKED) {
            var payload = UIASemaphore.getPayload(semaphoreUUID);
            //validate the pairing
            if (!payload || !payload.phoneNumber || !payload.passcode) {
                UIASemaphore.lock(semaphoreUUID);
                throw new UIAError(
                    'Malformed payload: %0 \
                    for semaphore: %1.'.format(JSON.stringify(payload),semaphoreUUID)
                );
            } else if (payload.phoneNumber !== phoneNumber) {
                UIASemaphore.lock(semaphoreUUID);
                throw new UIAError(
                    'Mismatching device number for pair: \
                    (device: %0, payload: %1)'.format(number,payload.phoneNumber)
                );
            }

            if (this.exists(ENTER_PASSCODE_QUERY)) {
                passcodePromptAppeared = true;
                UIALogger.logMessage('Log springboard: found alerts')
                var passcodeField = UIAQuery.textFields().topmost();
                springboard.enterText(passcodeField, payload.passcode);
                springboard.tap('Allow');
            }
        } else {
            if (this.exists(ENTER_PASSCODE_QUERY)) {
                passcodePromptAppeared = true;
                UIALogger.logMessage('Log springboard: found alerts')
                var passcodeField = UIAQuery.textFields().topmost();
                springboard.enterText(passcodeField, passcode);
                springboard.tap('Allow');
            }
        }
    });

    var INCORRECT_PIN_QUERY = UIAQuery.contains('Incorrect pin entered');

    springboard.handlingAlertsInline(INCORRECT_PIN_QUERY, function() {
        if (this.waitUntilPresent(INCORRECT_PIN_QUERY, 20)) {
            throw new UIAError('Incorrect Pin was entered to pair with secondary Thumper device');
        }
    });

    if (!passcodePromptAppeared) {
        throw new UIAError('Passcode prompt never appeared');
    }
}

/**
 * Set up Thumper logging for a device.
 *
 * @overrideID Pair Primary With Secondary Passcode
 *
 */
settings.enableFaceTimeLogging = function enableFaceTimeLogging(passcode) {
    UIALogger.logMessage('Beginning enable of logging for faceTime');
    this.returnToTopLevel();

    this.navigateNavigationViews(['Internal Settings','FaceTime']);

    var callLogging = UIAQuery.switches('Call Logging');
    var registrationLogging = UIAQuery.switches('Registration Logging');

    if (this.inspect(callLogging).value == 0) {
        this.setControl(callLogging, true);
    }

    if (this.inspect(registrationLogging).value == 0) {
        this.setControl(registrationLogging, true);
    }

}

 /**
 * Sign in to FaceTime with the specified account.
 *
 * @overrideID Sign In To FaceTime
 *
 * @param {string} appleID          - Apple ID. Defaults to persisted AppleID if none is provided
 * @param {string} password         - AppleID password. Defaults to persisted AppleID password if none is provided
 * @param {int} registrationTimeOut - Number of seconds the call should stay active
 *
 */
settings.signInToFaceTime = function signInToFaceTime(appleID, password, registrationTimeOut) {
    if (!appleID) {
        UIALogger.logWarning('No Apple ID specified. Defaulting to persisted Apple ID.');
        appleID = springboard.appleID;
    }

    if (!password) {
        UIALogger.logWarning('No Apple ID password specified. Defaulting to persisted Apple ID password.');
        password = springboard.appleIDPassword;
    }

    this.navigateNavigationViews(['FaceTime']);

    var ACTIVATION_ALERT = UIAQuery.contains('FaceTime Activation');
    this.handlingAlertsInline(ACTIVATION_ALERT, function() {
        if (this.exists(UIAQuery.alerts().andThen(ACTIVATION_ALERT))) {
            throw new UIAError('Activation alert dialog with the following information: \n%0'.format(tree(ACTIVATION_ALERT)));
        }
    });

    var FACETIME_SWITCH = UIAQuery.switches("FaceTime");
    if (this.exists(FACETIME_SWITCH)) {
        this.setControl(FACETIME_SWITCH,1);
    }

    if (this.exists(UIAQuery.query("Apple ID:"))) {
        //we have a value for Apple ID
        UIALogger.logMessage('Some one is signed into FaceTime. Must Sign them out');
        this.signOutOfFaceTime();
    }

    var SIGN_IN_ALERT = UIAQuery.staticTexts().contains('Apple ID Sign In').orElse(UIAQuery.staticTexts('Sign In Using Your Apple ID'));
    this.handlingAlertsInline(SIGN_IN_ALERT, function() {
        this.tapIfExists(UIAQuery.contains('Use your Apple ID for'));

        this.enterText(UIAQuery.textFields(), appleID);
        this.enterText(UIAQuery.secureTextFields(), password);
        this.tap("Sign In");
    });

    var validationPredicate = "name contains[c] '%0'".format(appleID);
    var FaceTimeAccount = UIAQuery.staticTexts().withPredicate(validationPredicate).below(
        UIAQuery.query('YOU CAN BE REACHED BY FACETIME AT')
    );
    if (!this.waitUntilPresent(FaceTimeAccount, registrationTimeOut)) {
        throw new UIAError('Account not added to FaceTime, Timed out waiting to sign in.');
    }

    //Sign into facetime and wait for the activated text to become present and active
    var ACTIVATED_TEXT = UIAQuery.staticTexts('Your phone number and/or email address will be shared with people you call.').isVisible();
    if (!this.waitUntilPresent(ACTIVATED_TEXT, registrationTimeOut)) {
        if (this.exists(UIAQuery.staticTexts('Waiting for activation...'))) {
            throw new UIAError('Account timed out waiting for activation');
        }
        throw new UIAError('Account timed out into unknown state when waiting for activation');
    }

}


/**
 * Sign out of FaceTime with the specified account.
 *
 * @overrideID Sign Out of FaceTime
 *
 */
settings.signOutOfFaceTime = function signOutOfFaceTime() {
	var SIGN_OUT_ALERT = UIAQuery.alerts('FaceTime Account');
    var SIGN_OUT_BUTTON = SIGN_OUT_ALERT.andThen(UIAQuery.withPredicate("name == 'Sign Out' AND interactionEnabled == TRUE").isVisible().isEnabled());
    var APPLE_ID_CELL = UIAQuery.tableCells('Apple ID:');
    var APPLE_ID_SIGNIN_PROMPT = UIAQuery.contains('Use your Apple ID for');
    var SIGN_OUT_TRANSITION_VIEW = UIAQuery.query("UITransitionView");

    UIALogger.logMessage('Navigate to top level and then descend into FaceTime to log out user');
    this.returnToTopLevel();
    this.navigateNavigationViews(['FaceTime']);


    if (!this.exists(APPLE_ID_CELL)) {
        throw new UIAError('Already signed out.');
    }

	this.handlingAlertsInline(SIGN_OUT_ALERT, function () {
		UIALogger.logMessage('Tap Apple ID Cell wait for pop over and then sign out');
	    this.tap(APPLE_ID_CELL);

	    if (this.waitUntilPresent(SIGN_OUT_BUTTON)) {
	        this.tap(SIGN_OUT_BUTTON);
	    } else{
	        throw new UIAError('Could not find the "Sign Out" transitionView.  Failed to fully sign out.');
	    }

	    if (!this.waitUntilPresent(APPLE_ID_SIGNIN_PROMPT)){
	        if (!this.waitUntilPresent(UIAQuery.textFields('Apple ID'))) {
	            throw new UIAError('Error trying to sign out of FaceTime');
	        }
	    }
	});
}

