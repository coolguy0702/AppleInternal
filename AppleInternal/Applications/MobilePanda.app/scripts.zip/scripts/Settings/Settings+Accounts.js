/*
    This file is for library functions associated with the AccountsUI framework.
    This corresponds to account actions under the 'Mail, Contacts, Calendars'
    view in the UI e.g. logging in and out of accounts such as iCloud, Yahoo,
    Exchange, etc.
*/

load('UIAApp.js');
load('SpringBoard.js');
load('Settings.js');

load('UIASemaphore.js');
load('Settings+iCloud.js');

/**
 * Enumerated type for supported account types
 *
 * @typedef {number} AccountType
 * @type {AccountType}
 */
settings.accountType = UIAUtilities.toEnum(
    'iCloud',
    'Yahoo',
    'GMail',
    'MobileMe',
    'AOL',
    'Exchange',
    'Hotmail',
    'QQMail',
    'NetEase',
    'Mail',
    'LDAP',
    'CardDAV',
    'CalDAV',
    'macOSServer'
);

/**
 * Convert common string names for account types into an actual
 * settings.accountType or null
 *
 * @param {string} type - String convertible to settings.accountType
 * @returns {string} member of settings.accountType or null
 */
settings.toAccountType = function toAccountType(type) {
    switch (type.toLowerCase()) {
        case 'icloud':
            return settings.accountType.iCloud;
        case 'yahoo':
            return settings.accountType.Yahoo;
        case 'gmail':
        case 'g-mail':
            return settings.accountType.GMail;
        case 'me':
        case 'mobileme':
            return settings.accountType.MobileMe;
        case 'aol':
            return settings.accountType.AOL;
        case 'exchange':
        case 'eas':
            return settings.accountType.Exchange;
        case 'hotmail':
            return settings.accountType.Hotmail;
        case 'qqmail':
            return settings.accountType.QQMail;
        case 'netease':
            return settings.accountType.NetEase;
        case 'mail':
        case 'other':
        case 'imap':
            return settings.accountType.Mail;
        case 'ldap':
            return settings.accountType.LDAP;
        case 'carddav':
            return settings.accountType.CardDAV;
        case 'caldav':
            return settings.accountType.CalDAV;
        case 'macosserver':
            return settings.accountType.macOSServer;
        default:
            return null;
    }
}

/**
 * Return the localized cell name for the major account type
 *
 * @param {AccountType} type Major account type. Should be one of:
 *    iCloud
 *    Yahoo
 *    GMail
 *    MobileMe
 *    AOL
 *    Exchange
 *    Hotmail
 *    QQMail
 *    NetEase
 *
 * @returns {string} Localized cell name or null
 */
settings.localizedStringForMajorAccountType = function localizedStringForMajorAccountType(type) {
    var localize = UIAUtilities.bind(this, function(key) {
        return this.localizedString(key, {
            tableName: 'Accessibility',
            bundlePath: '/System/Library/AccessibilityBundles/PreferencesFramework.axbundle',
        });
    });
    switch (type) {
        case this.accountType.iCloud:
            return localize('mail.appleid.text');
        case this.accountType.Yahoo:
            return localize('mail.yahoo.text');
        case this.accountType.GMail:
            return localize('mail.gmail.text');
        case this.accountType.MobileMe:
            return localize('mail.mobileme.text');
        case this.accountType.AOL:
            return localize('mail.aol.text');
        case this.accountType.Exchange:
            return localize('mail.exchange.text');
        case this.accountType.Hotmail:
            return localize('mail.outlook.text');
        case this.accountType.QQMail:
            return localize('chinese.qq.mail.account');
        case this.accountType.NetEase:
            return localize('chinese.163.mail.account');
        default:
            return null;
    }
}

/**
 * Return the localized cell name for the 'Other' account type
 *
 * @param {AccountType} type Other account type. Should be one of:
 *    Mail
 *    LDAP
 *    CardDAV
 *    CalDAV
 *    macOSServer
 *
 * @returns {string} Cell name or null
 */
settings.stringForOtherAccountType = function stringForOtherAccountType(type) {
    switch (type) {
        case this.accountType.Mail:
            return 'Add Mail Account';
        case this.accountType.LDAP:
            return 'Add LDAP Account';
        case this.accountType.CardDAV:
            return 'Add CardDAV Account';
        case this.accountType.CalDAV:
            return 'Add CalDAV Account';
        case this.accountType.macOSServer:
            return 'Add macOS Server Account';
        default:
            return null;
    }
}

/**
 * Get to account create screen for specified account type
 *
 * @param {AccountType} type - Account type
 */
settings.getToAccountCreationView = function getToAccountCreationView(type) {
    if (!this.navigateNavigationViews([Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS])) {
        throw new UIAError('Could not get to "%0" view'.format(Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS));
    }

    this.tap('Add Account');

    var account = this.localizedStringForMajorAccountType(type);
    if (!account) {
        if ((account = this.stringForOtherAccountType(type))) {
            this.tap(UIAQuery.RIGHT_TABLE.andThen('Other'));
        } else {
            throw new UIAError('Unrecognized account type "' + type + '"');
        }
    }

    UIALogger.logMessage('Mapped %0 type to %1'.format(type, account));
    this.tap(UIAQuery.RIGHT_TABLE.andThen(account));

    // TODO: replace with better condition
    // some accounts will have activity indicators
    this.waitUntilAbsent(UIAQuery.activityIndicators(), 10);

    // Some accounts still require waiting. Radar: 23146388
    if (type === this.accountType.Yahoo || type === this.accountType.GMail || type === this.accountType.Hotmail) {
        UIALogger.logMessage('Type is yahoo, gmail, or hotmail. Delaying.');
        target.delay(7);
    }
}

/**
 * This will do a spin dump and sample akd if we encounter the icloud account issue
 * <rdar://problem/21642198> [Monarch] 13A294 - Verification Failed. There was an error connecting to the Apple ID server.
 */
settings.verificationFailedPostLogging = function verificationFailedPostLogging() {

    UIALogger.logMessage("Starting additional logging for <rdar://problem/21642198> after failure");

    UIALogger.logMessage('Starting spindump');
    // spindump samples user and kernel stacks for every process in the system
    var spin = target.performTask('/usr/sbin/spindump',['-file', '/tmp/taskspindump.txt'],100);

    if(spin['exitCode'] === 0){
        UIALogger.logMessage('Spindump was successful: %0'.format(spin['stderr']));
    } else {
        UIALogger.logMessage('Spindump failed: %0'.format(spin['stderr']));
    }

    UIALogger.logMessage('Starting sample');
    // sample is a command-line tool for gathering data about the running behavior of a process
    var sample = target.performTask('/usr/bin/sample',['-file', '/var/mobile/Library/Logs/CrashReporter/sample-akd.txt', 'akd'],100);

    if(sample['exitCode'] === 0){
        UIALogger.logMessage('Sample was successful: %0'.format(sample['stderr']));
    } else {
        UIALogger.logMessage('Sample failed: %0'.format(sample['stderr']));
    }

    UIALogger.logMessage("Finished additional logging for <rdar://problem/21642198> after failure");
}


/**

 * Sign in to iCloud with the specified account.
 *
 * @overrideID Sign In To iCloud
 *
 * @param {string}  appleID - Apple ID.
 * @param {string}  password - AppleID password.
 * @param {object}  options
 * @param {bool}    [options.passIfAlreadySignedIn=false] - true if the test should pass if already signed in with the same Apple ID.
 * @param {bool}    [options.throwIfAccountAlreadyAdded=true] - Set to true (default) if we want to throw when attempting to add an account that the device is already signed on to.
 * @param {boolean} [options.isHSA=false] - Is this a HSA2 account (true) or not (false)?
*  @param {object}  [options.hsaOptions] - options for HSA enrollment and verification
 * @param {bool}    [options.hsaOptions.useCDPApproval=false] - Optional Whether to opt for approval flow while enrolling into iCDP
 * @param {string}  [options.hsaOptions.cdpSemaphoreUUID=null] - Required in order to get HSA2 code from other device in a multi device suite
 * @param {boolean} [options.hsaOptions.getHsa2Code=false]  - If set to true then get HSA2 code from other device part of MD suite
 * @param {boolean} [options.hsaOptions.getHsa2TextCode=false]  - If set to true then get HSA2 sms verification code from other device part of MD suite
 * @param {string}  [options.hsaOptions.hsaCode] - two factor auth code for HSA2
 * @param {boolean} [options.hsaOptions.enrollHsa] - whether or not to enroll in HSA2
 * @param {string}  [options.hsaOptions.hsaTrustedNumber] - Phone number to use as trusted number for HSA2 enrollment
 * @param {string}  [options.hsaOptions.hsaCountryCode] - Country code for HSA2 trusted number
 * @param {string}  [options.hsaOptions.hsaVerifyMethod] - One of "Text Message", "Robo Call"
 * @param {string}  [options.hsaOptions.passcode="111111"] - passcode of the device used for enrolling into iCDP.
 * @param {string}  [options.hsaOptions.deviceName="Device000000"] - Optional device name to choose from list of parent devices to enroll into iCDP for second device
 * @param {string}  [options.hsaOptions.previousPasscode="000000"] - Optional parent device's passcode to enroll into iCDP
 * @param {object}  [options.mergeDataOptions] - Options for merging data already on device when signing into iCloud
 * @param {string}  [options.mergeDataOptions.safariData=false] - Whether or not to merge the safari data if it exists prior to signing in.
 */
settings.signInToiCloud = function signInToiCloud(appleID, password, options) {
    options = UIAUtilities.defaults(options, {
        passIfAlreadySignedIn: false,
        throwIfAccountAlreadyAdded:false,
        isHSA: false,
        hsaOptions: {
            getHsa2Code: false,
            getHsa2TextCode: false,
            enrollHsa: false,
            cdpSemaphoreUUID: null
        },
        mergeDataOptions: {
            safariData: false,
            otherData: false
        }
    });

    if (!appleID) {
        UIALogger.logWarning('No Apple ID specified. Defaulting to persisted Apple ID.');
        appleID = springboard.appleID;
    }
    if (!password) {
        UIALogger.logWarning('No Apple ID password specified. Defaulting to persisted Apple ID password.');
        password = springboard.appleIDPassword;
    }

    var APPLE_ID_SIGNIN_PROMPT = UIAQuery.contains('Use your Apple ID for');

    var validationPredicate = "name contains[c] '%0'".format(appleID);
    var iCloudAccount = UIAQuery.staticTexts()
                                .withPredicate(validationPredicate)
                                .below(UIAQuery.navigationBars('Apple ID'));

    this.returnToTopLevel();
    this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}]);

    if (options.passIfAlreadySignedIn && this.exists(UIAQuery.contains(appleID))) {
        UIALogger.logMessage('Already signed in as "%0"'.format(appleID));
        return true;
    }
    if (this.exists(UIAQuery.tableCells("Sign Out"))) {
        throw new UIAError('Some one is signed into iCloud. Must Sign them out');
    }


    // signInWithAppleIDAlert does not explicitly use hsaOptions like this function does, so
    // mergeDataOptions And HSAOptions must be merged for this function to not break other implementations.
    options.hsaOptions.mergeDataOptions = options.mergeDataOptions;
    var signInStatus = this.signInWithAppleIDAlert(appleID, password, options.throwIfAccountAlreadyAdded, options.hsaOptions);

    if (!signInStatus.SuccessfullySignedIn && !this.waitUntilPresent(iCloudAccount,140)) {
        throw new UIAError('Account could not be signed into iCloud, or Timed Out');
    }
}

/**
 * Deletes specified iCloud address
 *
 * @param {string} password Optional password used to dismiss iCloud approval
 *                 if 'Find My iPhone' is enabled
 *
 * @throws if address cannot be deleted
 */
settings.deleteiCloudAccount = function deleteiCloudAccount(password) {

    if (!this.navigateNavigationViews([Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS])) {
        throw new UIAError("Could not get to '%0' view".format(Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS));
    }

    var iCloudQuery = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.contains('iCloud'));
    if (this.exists(iCloudQuery)) {
        UIALogger.logMessage('Tapping "iCloud"');
        var waiter = UIAWaiter.withPredicate('ViewDidAppear', 'automationTitle == "Enter Password"');
        this.tap(iCloudQuery);
        if (waiter.wait(3)) {
            UIALogger.logMessage('Entering password');
            this.typeString(password);
            waiter = UIAWaiter.waiter('ViewDidAppear');
            this.tap('Done');
            if (!this.wait(240)) {
                throw new UIAError('Never got passed password screen');
            }
        } else {
            UIALogger.logMessage('Not entering password');
        }
    } else {
        UIALogger.logMessage('No iCloud account set up');
        return;
    }

    UIALogger.logMessage('Wating for activity indicator to settle down...');
    this.waitUntilPresent(UIAQuery.contains('Set Up Family Sharing'));

    var passwordHandler = function() {
        var app = target.activeApp();
        if (app.waitUntilPresent('Password Required', 1) || app.exists('Apple ID Password')) {
            UIALogger.logMessage('Found the Apple ID password alert, handling...')
            app.tap(UIAQuery.secureTextFields());
            app.typeString(password);
            app.tap('Turn Off');
            return true;
        } else {
            return false;
        }
    };

    var alertsHandled = [];

    var postSignOutHandler = function() {
        var app = target.activeApp();
        if (app.exists('Sign Out of iCloud')) {
            UIALogger.logMessage("Tapping confirm to sign out of iCloud...");
            app.tap(UIAQuery.alerts().andThen('Sign Out'));
            alertsHandled.push('Sign Out of iCloud');

        } else if (app.exists('Delete Account')) {
            UIALogger.logMessage("Tapping confirm to delete account...");
            app.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Delete')));
            alertsHandled.push('Delete Account');

        } else if (app.exists(UIAQuery.contains('Are you sure you want to turn off'))) {
            UIALogger.logMessage("Encountered the Turn Off Documents & Sharing alert...");
            app.tap(UIAQuery.alerts().andThen(UIAQuery.beginsWith('Delete from i')));
            alertsHandled.push('Turn Off Documents & Sharing');

        } else if (app.exists('Turn Off Safari')) {
            UIALogger.logMessage("Encountered the Turn Off Safari alert...");
            app.tap(UIAQuery.alerts().andThen(UIAQuery.beginsWith('Delete from My i')));
            alertsHandled.push('Turn Off Safari');

        } else if (app.exists('Password Required') || app.exists('Apple ID Password')) {
            UIALogger.logMessage("Encountered the FMIP signout alert...");
            app.tap(UIAQuery.secureTextFields());
            app.typeString(password);
            app.tap('Turn Off');
            alertsHandled.push('iCloud Password Required');
        } else if (app.exists('Turn Off Notes')) {
            UIALogger.logMessage('Tapping Delete to delete Notes...');
            app.tap(UIAQuery.alerts().andThen('Delete'));
            alertsHandled.push('Turn Off Notes');
        } else if (app.exists('Turn Off Reminders')) {
            UIALogger.logMessage('Tapping Delete to delete Reminders...');
            app.tap(UIAQuery.alerts().andThen(UIAQuery.beginsWith('Delete from My i')));
            alertsHandled.push('Turn Off Reminders');
        } else {
            return false;
        }
        return true;
    };


    if (target.model() === 'iPad') {
        this.withAlertHandler(postSignOutHandler, function () {
            this.tap('Sign Out');
            for (var i=0; i < 10; i++) {
                UIALogger.logMessage("Waiting for alerts...");
                target.delay(5);
                var length = alertsHandled.length;
                if (UIAAlertManager.handleAlerts()) {
                    if (alertsHandled.length !== length) {
                        UIALogger.logMessage("Handled alert: %0".format( alertsHandled[alertsHandled.length-1] ));
                    } else {
                        UIALogger.logMessage("Handled alert but not one we were looking for");
                    }
                } else {
                    UIALogger.logMessage("No alert handled");
                }
            }
        });
    } else {
        this.withAlertHandler(passwordHandler, function() {
            this.tap('Sign Out');
            var sheets = UIAQuery.actionSheets().isVisible();
            var button = sheets.andThen(UIAQuery.query('Sign Out')).orElse(sheets.andThen(UIAQuery.query('Delete Account'))).orElse(UIAQuery.contains('Delete from'));

            while (this.waitUntilPresent(sheets, 10)) {
                var sheetSnapshot = this.inspect(sheets.first());
                if (sheetSnapshot) {
                    var label = sheetSnapshot.label;
                    UIALogger.logMessage('Found action sheet with label: %0'.format(label));
                } else {
                    continue;
                }

                UIALogger.logMessage('Looking for button to tap');
                var buttonSnapshot = this.inspect(button);
                if (buttonSnapshot) {
                    var label = buttonSnapshot.label;
                    UIALogger.logMessage('Found button with label: %0'.format(label));
                }
                this.tap(button);
            }
        });
    }

    var title = UIAQuery.RIGHT_NAVBAR.contains('Accounts').contains('Passwords');
    if (!this.waitUntilPresent(title, 120)) { // Two minute limit to fail iCloud signout
        throw new UIAError("Failed to sign out of iCloud (either we failed to handle a post sign-out alert or the signing out is taking forever)", {identifier:"Failed to sign out of iCloud"});
    } else {
        UIALogger.logMessage("Correctly verified that we are back at the Add Account view.");
    }

    this.returnToTopLevel();
    if (this.exists(UIAQuery.staticTexts('Apple ID, iCloud, iTunes & App Store'))) {
        this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}]);
        if (this.exists(UIAQuery.staticTexts('Sign Out'))) {
            this.tap(UIAQuery.staticTexts('Sign Out'));
        }
    }
}

/**
 * Creates an email account with the specified options
 *
 * @param {object} options - Options dictionary
 * @param {AccountType} options.type - Type of mail account to create
 * @param {string} options.name - Username for Exchange accounts. First & last name for everything else.
 * @param {string} options.address - Email address.
 * @param {string} options.password - Password.
 * @param {string} options.description - Optional email description. Address is used if not provided.
 * @param {string} options.server - Server for use with Exchange or "Other" accounts. Defaults to server in address.
 * @param {bool}   options.throwIfAccountAlreadyAdded - Set to true (default) if we want to throw when attempting to add an account that the device is already signed on to.
 * @param {bool}   options.verify - Verify the email account was set up properly. Default is True.
 *
 * @param {object} options.syncOptions - Options for Sync settings
 * @param {bool} options.syncOptions.keepAlreadySynced - Option to keep data that's already synced
 * @param {null|bool} options.syncContacts - Option to enable Sync for Contacts
 * @param {null|bool} options.syncCalendars - Option to enable Sync for Calendars
 * @param {null|bool} options.syncDocuments - Option to enable Sync for Documents
 * @param {null|bool} options.syncMail - Option to enable Sync for Mail
 * @param {null|bool} options.syncNotes - Option to enable Sync for Notes
 * @param {null|bool} options.syncNews - Option to enable Sync for News
 * @param {null|bool} options.syncReminders - Option to enable Sync for Reminders
 * @param {null|bool} options.syncSafari - Option to enable Sync for bookmarks
 * @param {null|bool} options.syncWallet - Option to enable Sync for Wallet
 * @param {null|bool} options.setFindMy - Option to enable or disable "Find My iPhone/iPad"
 * @param {null|bool} options.setiCloudDrive - Option to enable or disable "iCloud Drive"
 *
 * @param {object} options.otherOptions - Options for "other" account settings
 * @param {bool} options.otherOptions.useAdvancedTable - Option to use advanced table
 * @param {bool} options.otherOptions.usePop - Option to use Pop instead of IMAP
 * @param {string} options.otherOptions.inHostName - Optional incoming host name for "Other" accounts
 * @param {string} options.otherOptions.inUserName - Optional incoming user name for "Other" accounts
 * @param {string} options.otherOptions.inPassword - Optional incoming password for "Other" accounts
 * @param {string} options.otherOptions.outHostName - Optional outcoming host name for "Other" accounts
 * @param {string} options.otherOptions.outUserName - Optional outcoming user name for "Other" accounts
 * @param {string} options.otherOptions.outPassword - Optional outcoming password for "Other" accounts
 * @param {object}  options.hsaOptions - options for hsa enrollment and verification
 * @param {string} options.hsaOptions.hsaCode - two factor auth code for HSA2
 * @param {boolean} options.hsaOptions.enrollHsa - whether or not to enroll in HSA2
 * @param {string} options.hsaOptions.hsaTrustedNumber - Phone number to use as trusted number for HSA2 enrollment
 * @param {string} options.hsaOptions.hsaCountryCode - Country code for hsa2 trusted number
 * @param {string} options.hsaOptions.hsaVerifyMethod - One of "Text Message", "Robo Call"
 */
settings.createEmail = function createEmail(options) {
    options = UIAUtilities.defaults(options, {
        throwIfAccountAlreadyAdded: true,
        verify: true,
        iCloudVerificationIssueLogging: false,
    });

    if (this.isEmailAccountLoggedIn(options)) {
        if (options.throwIfAccountAlreadyAdded) {
            throw new UIAError('Email account already signed in.');
        }

        return;
    }

    UIALogger.logMessage("Constructing Location Alert Handler");
    var locationHandler = function() {
        var app = target.activeApp();
        UIALogger.logMessage("Dismissing Location Alert");
        if (app.exists(UIAQuery.contains('Use the Location'))) {
            app.tap("Don’t Allow");
            return true;
        } else {
            return false;
        }
    };

    if (options.iCloudVerificationIssueLogging) {
        UIALogger.logMessage("iCloud Verification Logging is set to true. Grabbing additional logging for 21642198 and 24137189");
        settings.verificationFailedExtraLogging();
    }

    //iCloud account creation is handled separately in an alert,
    //which will be triggered by enteriCloudAccountInfo
    if (options.type !== this.accountType.iCloud) {
        this.getToAccountCreationView(options.type);
    }

    this.withAlertHandler(locationHandler, function() {
        switch(options.type) {
            case this.accountType.iCloud:
                var signInStatus = this.enteriCloudAccountInfo(options);
                if (! signInStatus.NeedToConfirmSyncOptions) {
                    UIALogger.logMessage("No need to confirm sync options (we're already signed in), skipping Tap Save...");
                    return;
                }
                break;
            case this.accountType.GMail:
                //Gmail description defaults to Gmail
                options.description = "Gmail";
                this.enterGmailAccountInfo(options);
                break;
            case this.accountType.Exchange:
                this.enterExchangeAccountInfo(options);
                break;
            case this.accountType.Hotmail:
                this.enterHotmailAccountInfo(options);
                break;
            default:
                this.enterEmailAccountInfo(options);
        }

        if (options.type >= this.accountType.Mail && options.useAdvancedTable) {
            this.enterInfoToSetupOtherEmailAccount(options.otherOptions);
        }

        options.syncOptions.password = options.password;
        this.setSyncOptions(options.syncOptions);

        var save = UIAQuery.BOTTOM_NAVBAR.andThen(UIAQuery.RIGHT_NAV_BUTTON).isVisible();
        if (this.waitUntilPresent(save, 20)) {
            UIALogger.logMessage('Tapping Save button in nav bar');
            var waiter = UIAWaiter.withPredicate('ViewDidAppear', "controllerClass != 'AAUIMCCSettingsViewController'");
            this.tap(save);
            if (!waiter.wait(240)) {
                throw new UIAError('Account (%0) did not get saved properly'.format(options.address), {identifier: 'Account did not get saved properly'});
            }
        }
    });

    // Tap the last Save button after setting Sync Options
    this.tapIfExists(UIAQuery.buttons('Save'));

    if (options.verify && !this.isEmailAccountLoggedIn(options)) {
        UIALogger.logWarning('Unable to log in email address: %0'.format(options.address))
        throw new UIAError('Unable to log in email address');
    }
}

/**
 * Checks to see if an email address has been setup
 *
 * @param {object} options - Options dictionary
 * @param {string} options.address - Email address.
 */
settings.isEmailAccountLoggedIn = function isEmailAccountLoggedIn(options) {
/*
    Please note, description/type is not a valid attempt at determining if an
    account is logged in. This is because if more then one account of the
    same type is logged in the listed description/type values can change.
*/
    // must enter the mail view before we can look at existing accounts
    if (!this.navigateNavigationViews([Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS])) {
        throw new UIAError("Could not get to '%0' view".format(Settings.CONSTANTS.PASSWORDS_AND_ACCOUNTS));
    }

    // check if account exists on first page
    if (this.exists(options.address)) {
        return true;
    }

    // could also desend via description first before attempting exhausive search... To be added later
    UIALogger.logMessage('Email address does not appear in the top level of the accounts page. Will search lower levels...');
    var tableCellsQuery = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.withPredicate('behavior == "TableCell" and name != "Website & App Passwords" and name != "AutoFill Passwords"'));

    for (var i = 0; this.inspectElementKey(tableCellsQuery.atIndex(i), 'name') !== 'Add Account'; i++) {
        UIALogger.logMessage('Checking account indexed at %0'.format(i));
        this.tap(tableCellsQuery.atIndex(i));

        if (this.exists(options.address)) {
            return true;
        }

        var waiter = UIAWaiter.withPredicate('ViewDidAppear', "navigationItemTitle == 'Passwords & Accounts'");

        // return to previous page
        this.tap(UIAQuery.BACK_NAV_BUTTON);

        if (!waiter.wait(5)) {
            throw new UIAError('Unable to navigate back to the Accounts view while verifying Email account');
        }
    }

    UIALogger.logMessage('Email account was not found');

    return false;
}

/**
 * Setup sync options for email account
 *
 * Each syncOption can have one of three values:
 *   null  - keep default setting
 *   false - disable syncing
 *   true  - enable syncing
 *
 * @param {object} options - Arguments dictionary
 * @param {string} options.password - Password to turn of "Find My iPhone/iPad"
 * @param {bool} options.keepAlreadySynced - Option to keep data that's already synced
 * @param {null|bool} options.syncContacts - Option to enable Sync for Contacts
 * @param {null|bool} options.syncCalendars - Option to enable Sync for Calendars
 * @param {null|bool} options.syncDocuments - Option tpo enable Sync for Documents
 * @param {null|bool} options.syncMail - Option to enable Sync for Mail
 * @param {null|bool} options.syncNotes - Option to enable Sync for Notes
 * @param {null|bool} options.syncNews - Option to enable Sync for News
 * @param {null|bool} options.syncReminders - Option to enable Sync for Reminders
 * @param {null|bool} options.syncSafari - Option to enable Sync for bookmarks
 * @param {null|bool} options.syncWallet - Option to enable Sync for Wallet
 * @param {null|bool} options.setFindMy - Option to enable or disable "Find My iPhone/iPad"
 * @param {null|bool} options.setiCloudDrive - Option to enable or disable "iCloud Drive"
 */
settings.setSyncOptions = function setSyncOptions(options) {
    options = UIAUtilities.defaults(options, {
        password: springboard.appleIDPassword,
        keepAlreadySynced:  true,
        syncContacts:       null,
        syncCalendars:      null,
        syncMail:           null,
        syncNotes:          null,
        syncNews:           null,
        syncReminders:      null,
        syncSafari:         null,
        syncWallet:         null,
        setFindMyDevice:    null,
        setiCloudDrive:     null,
        });

    var password = options.password;
    var keepAlreadySynced = options.keepAlreadySynced;

    var cells = [];
    var buttons = [];
    for (var key in options) {
        var value = options[key];
        if (value === null) {
            continue;
        } else if (key.beginsWith('sync')) {
            cells.push({
                name: key.slice(4),
                value: value,
            });
        } else if (key.beginsWith('set')) {
            // tried to do this with clever string splitting, but it's hard
            if (key.contains('FindMy')) {
                buttons.push({
                    name: 'Find My',
                    value: value,
                });
            } else if (key.contains('iCloudDrive')) {
                buttons.push({
                    name: 'iCloud Drive',
                    value: value,
                });
            } else {
                buttons.push({
                    name: key.slice(3),
                    value: value,
                });
            }

        }
    }

    var syncHandler = function() {
        UIALogger.logMessage('Hit syncHandler()');
        var fmipOffAlert = UIAQuery.beginsWith('Turn Off Find My').orElse('Password Required').orElse('Apple ID Password');
        var fmipOnAlert = UIAQuery.alerts().contains('Find My i');

        var signInAlert = UIAQuery.beginsWith('Sign In to iCloud');
        var securityCodeAlert = UIAQuery.contains('Create Security Code');
        var contactsAlert = UIAQuery.contains('Turn Off Contacts');
        var shareLocationAlert = UIAQuery.contains('Share Your Location');
        var deleteAlert = UIAQuery.contains('What would you like to do');
        var existingSafariAlert = UIAQuery.contains('Existing Local Safari');
        var existingContactsAlert = UIAQuery.contains('existing local contacts');
        var existingCalendarAlert = UIAQuery.contains('existing local calendars');

        var app = target.activeApp();
        if (app.exists(fmipOffAlert)) {
            app.tap(UIAQuery.secureTextFields());
            app.typeString(password);
            app.tap('Turn Off');
            return true;
        } else if (app.exists(fmipOnAlert)) {
            app.tap(UIAQuery.buttons().withPredicate('name contains "Don" and name contains "Allow"').orElse(UIAQuery.buttons('OK')));
            return true;
        } else if (app.exists(signInAlert)) {
            app.tap(UIAQuery.secureTextFields());
            app.typeString(password);
            app.tap('OK');
            return true;
        } else if (app.exists(securityCodeAlert)) {
            app.tap('Skip Code');
            return true;
        } else if (app.exists(shareLocationAlert)) {
            app.tap('Not Now');
            return true;
        } else if (app.exists(existingSafariAlert) || app.exists(existingContactsAlert) || app.exists(existingCalendarAlert)) {
            app.tap(keepAlreadySynced ? UIAQuery.buttons('Merge') : UIAQuery.buttons('Cancel'));
            return true;
        } else if (app.exists(deleteAlert)) {
            app.tapIfExists(keepAlreadySynced ? UIAQuery.buttons('Keep on My') : UIAQuery.buttons('Delete from My'));
            return true;
        } else {
            return false;
        }
    };

    /**
     * Workaround for waiting for UIProgressHUD to go away.
     * This is necessary because sometimes, changing settings will
     * show this UI but we have difficulty handling this event.
     *
     * This function mostly exists because of the following radars:
     * <rdar://problem/22381842> AX sending Alert notif when undismissable turn off notice appears
     * <rdar://problem/22381720> Request for Notification for when UIProgressHUD appears/disappears
     *
     * @param {UIAWaiter} waiter - the waiter for an "Alert" event that will symbolize UIProgressHUD appearing.
     */
    var handleUIProgressHUD = function handleUIProgressHUD(waiter) {
        // Wait for alert notification triggered by UIProgressHUD appearing, then handle it.
        // If 22381842 ends up removing this alert, then the fallback is to wait and check for the element itself.
        if (waiter.wait(5) || this.exists('UIProgressHUD')) {
            // In the end, this funciton just waits for the view to appear, and if it does, disappear.
            if (this.waitUntilPresent('UIProgressHUD', 3)) {
                UIALogger.logMessage('Found UIProgressHUD! Waiting for it to go away.');
                if (this.waitUntilAbsent('UIProgressHUD', 30)) {
                    UIALogger.logMessage('UIProgressHUD went away!  We can now interact with the UI.');
                } else {
                    UIALogger.logMessage('UIProgressHUD did not go away after waiting...');
                }
            } else {
                UIALogger.logMessage('UIProgressHUD not found.')
            }
        } else {
            UIALogger.logMessage('Neither did we receive an Alert event nor did we find a UIProgressHUD, so let us not handle it at all!');
        }
    }.bind(this);

    this.withAlertHandler(syncHandler, function() {
        // divided sections for switches and buttons since buttons could potentially have more options
        // will make it much easier to add code to handle those options in the future

        // switches
        for (var i = 0; i < cells.length; ++i) {
            var cell = cells[i];
            var switchQuery = UIAQuery.contains(cell.name).andThen(UIAQuery.switches());
            var waiter = UIAWaiter.waiter('Alert');

            UIALogger.logMessage("Setting switch containing '%0' to '%1'".format(cell.name, cell.value));
            if (this.exists(switchQuery)) {
                var oldValue = this.inspect(switchQuery).value;
                if (this.shouldFlipSwitch(oldValue, cell.value)) {
                    this.tap(switchQuery);
                    if (this.waitUntilPresent(UIAQuery.contains('What would you like to do')), 5) {
                        UIALogger.logMessage('Found keep data alert');
                        if (this.exists(UIAQuery.contains('Keep on My'))) {
                            this.tap(keepAlreadySynced ? UIAQuery.contains('Keep on My') : UIAQuery.contains('Delete from My'));
                        }
                        else if (this.exists(UIAQuery.contains('Merge'))) {
                            this.tap(keepAlreadySynced ? UIAQuery.contains('Merge') : UIAQuery.contains('Cancel'));
                        }
                    }

                    handleUIProgressHUD(waiter);
                }
            } else {
                UIALogger.logWarning("Cannot find switch for '%0'".format(cell.name));
            }
        }

        // buttons
        for (var i = 0; i < buttons.length; ++i) {
            var button = buttons[i];
            var name = button.name;
            var value = button.value;
            var buttonQuery = UIAQuery.contains(name);
            var waiter = UIAWaiter.waiter('Alert');

            if (this.exists(buttonQuery)) {
                this.tap(buttonQuery);
                var switchQuery = UIAQuery.switches().contains(name);
                if (this.exists(switchQuery)) {
                    // right now we just flip the switch; in the future we might set other things here too
                    if (this.shouldFlipSwitch(this.inspect(switchQuery).value, value)) {
                        this.tap(switchQuery);

                        handleUIProgressHUD(waiter);
                    }
                } else {
                    UIALogger.logWarning("Unable to find switch");
                }
                if (this.exists(UIAQuery.BACK_NAV_BUTTON.isVisible())) {
                    this.tap(UIAQuery.BACK_NAV_BUTTON.isVisible());
                }
            }
        }
    });
}

/**
 * Enter fields in email account window
 *
 * @param {object} options - Arguments dictionary
 * @param {AccountType} options.type - Type of mail account to create
 * @param {string} options.name - First and last name. Not used for some accounts like iCloud, MobileMe, and Hotmail
 * @param {string} options.address - Email address
 * @param {string} options.password - Password
 * @param {string} options.description - Optional email description. Address is used if not provided
 */
settings.enterEmailAccountInfo = function enterEmailAccountInfo(options) {
    UIALogger.logMessage('Creating a %(type) account with name %(name)'.format({
        type: this.accountType[options.type],
        name: options.name,
    }));

    // Fill out Name field
    if (options.name && this.exists(UIAQuery.textFields('Name'))) {
        UIALogger.logDebug('Attempting to fill out Name field.');
        this.enterText(UIAQuery.textFields('Name'), options.name);
    } else {
        // Some account types don't set have name field
        UIALogger.logMessage('Unable to set name. Either no name was set or the text field does not exist.');
    }

    // Add @blah.com if it's missing on non-MobileMe accounts
    if (!options.address.contains('@') && options.type !== this.accountType.MobileMe) {
        options.address = '%(prefix)@%(server).com'.format({
            prefix: options.address,
            server: this.accountType[options.type].toLowerCase(),
        });
    }

    // Fill out Email field
    UIALogger.logDebug('Filling out Address/Apple ID/Email field');
    this.enterText(UIAQuery.EMAIL_ADDRESS_FIELD, options.address);

    if (options.type === this.accountType.Yahoo) {
        this.tap(UIAQuery.buttons('Next'));

        if (!this.waitUntilPresent(UIAQuery.EMAIL_PASSWORD_FIELD, 5)) {
            throw new UIAError('Yahoo username view did not disappear. Could not login to account.')
        }
    }

    // Fill out password field
    UIALogger.logDebug('Filling out Password field');
    this.enterText(UIAQuery.EMAIL_PASSWORD_FIELD, options.password);

    // Fill out Description field
    if (options.description && this.exists(UIAQuery.textFields('Description'))) {
        UIALogger.logDebug('Attempting to fill out Description field');
        this.enterText(UIAQuery.textFields('Description'), options.description);
    } else {
        // Some account types don't set have name field
        UIALogger.logMessage('Unable to set description. Either no description was set or the text field does not exist.');
    }

    var waiter = UIAWaiter.waiter('ViewDidAppear');
    this.tap(UIAQuery.buttons('Sign In').orElse(UIAQuery.buttons('Sign in').orElse(UIAQuery.buttons('Next'))));

    //handle recovery phone number screen
    var link=UIAQuery.links('Cancel');
    if (this.waitUntilPresent(link, 5)){
        this.tap(link);
    }
    if (!waiter.wait(60)) {
        throw new UIAError('Login view did not disappear. Could not login to account.');
    }
}

/**
 * Enter fields in Exchange email account window
 *
 * @param {object} options - Options dictionary
 * @param {string} options.name - Exchange username
 * @param {string} options.address - Email address
 * @param {string} options.password - Password
 * @param {string} options.description - Optional email description
 * @param {string} options.server - Server to use if auto-discovery doesn't work
 */
settings.enterExchangeAccountInfo = function enterExchangeAccountInfo(options) {
    UIALogger.logMessage('Creating an Exchange account with name %0'.format(options.name));

    // Fill out Email field
    UIALogger.logDebug('Filling out Email field: %0'.format(options.address));
    this.enterText(UIAQuery.BOTTOM_TABLE.andThen('Email'), options.address);

    // Fill out Password field
    UIALogger.logDebug('Filling out Password field');
    this.enterText(UIAQuery.BOTTOM_TABLE.andThen('Password'), options.password);

    // Description
    if (options.description) {
        UIALogger.logDebug('Filling out Description field: %0'.format(options.description));
        this.enterText(UIAQuery.BOTTOM_TABLE.andThen('Description'), options.description);
    } else {
        UIALogger.logDebug('No description to set');
    }

    var alertWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerTitle = "Cannot Verify Server Identity"'
    );

    var usernameWaiter = UIAWaiter.withPredicate(
        'ViewDidDisappear',
        'controllerClass = "UICompatibilityInputViewController"'
    );

    this.handlingAlertsInline(UIAQuery.alerts().andThen('Cannot Verify Server Identity'), function() {
        // Tap Next/Sign-In button
        UIALogger.logDebug('Tapping next button');
        this.tap(UIAQuery.BOTTOM_NAVBAR.andThen(UIAQuery.RIGHT_NAV_BUTTON));

        if (alertWaiter.wait(10)) {
            UIALogger.logMessage('Cannot Verify Server Identity alert occurred');
            target.activeApp().tap(UIAQuery.DEFAULT_BUTTON);
        }
    });

    UIALogger.logMessage('Waiting for username text field...');
    usernameWaiter.wait(120);

    // May need to enter username/server
    var usernameQuery = UIAQuery.textFields('Username');
    if (this.exists(usernameQuery)) {
        usernameWaiter.discard();

        UIALogger.logMessage('Autodiscovery did not work; we need to enter user name and server');

        // Fill out Server field
        if (!options.server) {
            options.server = address.substring(options.address.indexOf('@') + 1);
        }
        UIALogger.logMessage('Entering in server %0'.format(options.server));
        this.enterText(UIAQuery.textFields('Server'), options.server);

        // Fill out Username field
        UIALogger.logMessage('Entering username "%0"'.format(options.name));
        this.enterText(usernameQuery, options.name);

        // Tap Next/Sign-In button
        waiter = UIAWaiter.waiter('ViewDidAppear');
        UIALogger.logDebug('Tapping next button');
        this.tap(UIAQuery.BOTTOM_NAVBAR.andThen(UIAQuery.RIGHT_NAV_BUTTON));

        this.handlingAlertsInline(UIAQuery.alerts().andThen('This account may not be able to send or receive emails. Are you sure you want to continue?'), function() {
            this.tap(UIAQuery.buttons('Save'));
            this.tapIfExists(UIAQuery.buttons('Save'));

            // Taps the Save button in this alert
            this.tapIfExists(UIAQuery.DEFAULT_BUTTON);
        });

        return waiter.wait(120);
    } else {
        UIALogger.logMessage('Autodiscovery worked; we do not need to enter any more information');
    }
}

/**
 * Enter fields in iCloud email account window
 *
 * @param {object} options - Options dictionary
 * @param {string} options.address - Email address
 * @param {string} options.password - Password
 * @param {object}  options.hsaOptions - options for hsa enrollment and verification
 * @param {string} options.hsaOptions.hsaCode - two factor auth code for HSA2
 * @param {boolean} options.hsaOptions.enrollHsa - whether or not to enroll in HSA2
 * @param {string} options.hsaOptions.hsaTrustedNumber - Phone number to use as trusted number for HSA2 enrollment
 * @param {string} options.hsaOptions.hsaCountryCode - Country code for hsa2 trusted number
 * @param {string} options.hsaOptions.hsaVerifyMethod - One of "Text Message", "Robo Call"
*/
settings.enteriCloudAccountInfo = function enteriCloudAccountInfo(options) {
    this.getToAccountCreationView(options.type);
    var signInStatus = this.signInWithAppleIDAlert(options.address, options.password, options.throwIfAccountAlreadyAdded, options.hsaOptions);

    if (!signInStatus.SuccessfullySignedIn && signInStatus.NeedToConfirmSyncOptions && !this.waitUntilPresent(UIAQuery.buttons("Save").isVisible(), 60)) {
        throw new UIAError("iCloud sync options page did not appear.");
    }

    return signInStatus;
}

/**
 * Enter fields in Gmail email account window
 *
 * @param {object} options - Options dictionary
 * @param {string} options.name - Exchange username
 * @param {string} options.address - Email address
 * @param {string} options.password - Password
 * @param {string} options.password - Password
 */
settings.enterGmailAccountInfo = function enterGmailAccountInfo(options) {
    this.enterText(UIAQuery.textFields("Enter your email"), options.address);
    this.tap(UIAQuery.buttons("NEXT"));

    if (this.waitUntilPresent(UIAQuery.staticTexts("Please enter an email address"), 5)) {
        throw new UIAError('No email address was entered');
    }

    if (this.waitUntilPresent(UIAQuery.staticTexts("Couldn't find your Google Account. Try again.").orElse("Please enter a valid email address or phone number"), 5)) {
        throw new UIAError('Incorrect Gmail account information entered');
    }

    this.enterText(UIAQuery.secureTextFields("Password"), options.password);
    this.tap(UIAQuery.buttons("NEXT"));

    if (this.waitUntilPresent(UIAQuery.staticTexts("Please enter your password").orElse("The email and password you entered don't match"), 5)) {
        throw new UIAError('Invalid password was entered');
    }

    var waiter = UIAWaiter.waiter('ViewDidAppear');
    this.tap("Save");

    if(!waiter.wait(10)) {
        throw new UIAError('Gmail account could not be saved');
    }

    if (!this.waitUntilPresent(UIAQuery.staticTexts("Gmail").orElse(options.address), 5)) {
        throw new UIAError('Gmail account could not be created');
    }

    // sync options should be set in caller
    // save button should be pressed in caller
}

/**
 * Enter fields in Hotmail email account window
 *
 * @param {object} options - Arguments dictionary
 * @param {AccountType} options.type - Type of mail account to create
 * @param {string} options.name - Hotmail username
 * @param {string} options.address - Hotmail address
 * @param {string} options.password - Password
 * @param {string} options.description - Optional email description. Address is used if not provided
 */
settings.enterHotmailAccountInfo = function enterHotmailAccountInfo(options) {
    UIALogger.logMessage('Creating a Hotmail account with name %(name)'.format({
        name: options.name,
    }));

    // Add @blah.com if it's missing on non-MobileMe accounts
    if (!options.address.contains('@') && options.type !== this.accountType.MobileMe) {
        options.address = '%(prefix)@%(server).com'.format({
            prefix: options.address,
            server: this.accountType[options.type].toLowerCase(),
        });
    }

    // Fill out Email field
    UIALogger.logDebug('Filling out Email address field');
    this.enterText(UIAQuery.EMAIL_ADDRESS_FIELD, options.address);

    // Fill out password field
    UIALogger.logDebug('Filling out Password field');
    this.enterText(UIAQuery.EMAIL_PASSWORD_FIELD, options.password);

    var syncWaiter = UIAWaiter.waiter('ViewDidAppear');
    this.tap(UIAQuery.buttons('Sign in'));

    syncWaiter.wait(60);

    var yesButton = UIAQuery.buttons('Yes');
    if (this.exists(yesButton)) {
        UIALogger.logMessage('Allowing Outlook to sync your info...');
        this.tap(yesButton);
        this.tapIfExists(yesButton);
    }
    else {
        var sendCodeQuery = UIAQuery.staticTexts().contains('Where should we send your code?');
        if (this.exists(sendCodeQuery)) {
            UIALogger.logMessage('Please update security info for your hotmail account, skipping for now...');
            this.tap(UIAQuery.links().beginsWith('Skip for now'));
        }
    }
}

/**
 * Enter fields in "other" email accounts window
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.useAdvancedTable - Option to use advanced table
 * @param {bool} options.usePop - Option to use Pop instead of IMAP
 * @param {string} options.inHostName - Optional incoming host name for "Other" accounts
 * @param {string} options.inUserName - Optional incoming user name for "Other" accounts
 * @param {string} options.inPassword - Optional incoming password for "Other" accounts
 * @param {string} options.outHostName - Optional outcoming host name for "Other" accounts
 * @param {string} options.outUserName - Optional outcoming user name for "Other" accounts
 * @param {string} options.outPassword - Optional outcoming password for "Other" accounts
 */
settings.enterInfoToSetupOtherEmailAccount = function enterInfoToSetupOtherEmailAccount(options) {
    if (!options) {
        throw new UIAError('Must specify options for this function');
    }

    if (options.usePop) {
        UIALogger.logMessage('Setting option to use "POP"');
        this.tap('POP');
    }

    if (options.inHostName) {
        UIALogger.logMessage('Adding Incoming Mail Server Host Name: %0'.format(options.inHostName));
        this.tap('Host Name');
        this.typeString(options.inHostName);
    }

    if (options.inUserName) {
        UIALogger.logMessage('Adding Incoming Mail Server User Name: %0'.format(options.inUserName));
        this.tap('User Name');
        this.typeString(options.inUserName);
    }

    if (options.inPassword) {
        UIALogger.logMessage('Adding Incoming Mail Server Password');
        this.tap('Password');
        this.typeString(options.inPassword);
    }

    if (options.outHostName) {
        UIALogger.logMessage('Adding Outgoing Mail Server Host Name: %0'.format(options.outHostName));
        this.tap(UIAQuery.query('Host Name').last());
        this.typeString(options.outHostName);
    }

    if (options.outUserName) {
        UIALogger.logMessage('Adding Outgoing Mail Server User Name: %0'.format(options.outUserName));
        this.tap(UIAQuery.query('User Name').last());
        this.typeString(options.outUserName);
    }

    if (options.outPassword) {
        UIALogger.logMessage('Adding Outgoing Mail Server Password');
        this.tap(UIAQuery.query('Password').last());
        this.typeString(options.outPassword);
    }

    var next = UIAQuery.query('Next').orElse('Save');
    var waiter = UIAWaiter.waiter('ViewDidAppear');
    this.tap(next);
    return waiter.wait(120);
}

/**
 * Navigates to Settings -> Calendar and choose calendar belonging to the specified account as the default.
 *
 * @param {object} options - Options dictionary
 * @param {string} options.accountName - Account name whose calendar to set as default (could contain partial account name).
 * @param {number} options.timeout - Number of seconds to wait for "Default Calendar" option.
 *
 * Raise UIAError if specified account is missing among existing accounts or on failure to navigate to Calendar view.
 */

settings.chooseDefaultCalendarForAccount = function chooseDefaultCalendarForAccount(options) {
    if (!options.accountName) {
        throw new UIAError('Specify account name to default calendar.');
    }

    if (!options.timeout) {
        options.timeout = 60;
    }

    if (!this.navigateNavigationViews(['Calendar'])) {
        throw new UIAError('Could not get to "Calendar" view.');
    }

    if (!this.waitUntilPresent(UIAQuery.staticTexts('Default Calendar'), options.timeout)) {
        throw new UIAError('No "Default Calendar" option available. Add account(s) first.');
    }

    this.tap(UIAQuery.staticTexts('Default Calendar'));

    var defaultCalendarPane = UIAQuery.query('CSDefaultCalendarPane');
    var calendarSections = defaultCalendarPane.andThen(UIAQuery.query('UITableViewSectionElement'));
    // Some accounts may have more than one default calendar available, e.g. 'Birthday' + 'Calendar'
    var subCalendarSections = defaultCalendarPane.andThen(UIAQuery.query('UITableViewCellAccessibilityElement'));

    var numOfCalendars = this.count(calendarSections);
    var numOfSubCalendars = this.count(subCalendarSections);
    UIALogger.logMessage(
        'Number of available calendars: %0. Searching for the one belonging to <%1>'
        .format(numOfCalendars, options.accountName));
    for (var i = 0; i < numOfCalendars; i++) {
        var thisAccountName = this.inspectElementKey(
            calendarSections.atIndex(i).andThen(UIAQuery.staticTexts()), 'name');

        if (thisAccountName.toUpperCase().indexOf(options.accountName.toUpperCase()) > -1) {
            UIALogger.logMessage('Target account found at index: %0'.format(i));

            for (var j = i; j < numOfSubCalendars; j++) {
                var subCalendarName = this.inspectElementKey(
                    subCalendarSections.atIndex(j).andThen(UIAQuery.staticTexts()), 'name');

                // Test only checks for 'Calendar' as a default name option.
                if (subCalendarName.indexOf('Calendar') > -1) {
                    this.tap(subCalendarSections.atIndex(j).andThen(UIAQuery.staticTexts('Calendar')));
                    this.tap(UIAQuery.buttons('Back'));
                    return;
                }
            }
        }
    }

    throw new UIAError('No calendar belonging to <%0> found'.format(options.accountName));
}

/**
 * Add a macOS Server account.
 *
 *
 * @param {string} hostname - macOS server hostname
 * @param {string} hostname - macOS username
 * @param {string} password - macOS user password
 *
 */
settings.addMacOSServerAccount = function addMacOSServerAccount(hostname, username, password) {
    if (!hostname) {
        throw new UIAError('Hostname not specified');
    }

    if (!username) {
        throw new UIAError('Username not specified');
    }

    if (!password) {
        throw new UIAError('Password not specified');
    }

    this.getToAccountCreationView(this.accountType.macOSServer);
    this.tap(UIAQuery.tableCells().andThen(UIAQuery.staticTexts().withPredicate('name contains "Other"')));
    this.enterText(UIAQuery.textFields("Host Name"), hostname);
    this.enterText(UIAQuery.textFields("User Name"), username);
    this.enterText(UIAQuery.secureTextFields("Password"), password);
    this.tap(UIAQuery.buttons('Next'));

    var connectionAlert = UIAQuery.alerts('Cannot Verify Server Identity');
    springboard.handlingAlertsInline(connectionAlert, function() {
        if(springboard.waitUntilPresent(connectionAlert)) {
            springboard.tapIfExists(UIAQuery.buttons('Continue'));
        }
    });
    this.waitUntilAbsent(UIAQuery.activityIndicators('In progress'));
    this.tap(UIAQuery.buttons('Save'));
}
