load('UIAApp.js');
load('SpringBoard.js');
load('Settings.js');
load('UIASemaphore.js');
load('Semaphore.js');
load('Settings+Accounts.js')

/** @namespace */
UIAQuery.iCloudSettings = {
    USERNAME_TEXTFIELD: UIAQuery.textFields().topmost(),
    PASSWORD_TEXTFIELD: UIAQuery.secureTextFields().bottommost(),
    DONE_BUTTON: UIAQuery.TOP_NAVBAR.andThen(UIAQuery.RIGHT_NAV_BUTTON.withPredicate("name == 'Done'")).isVisible().isEnabled(),
    USE_EXISTING_ACCOUNT_BOTTON: useExistingAccountButton = UIAQuery.buttons("Use Existing Apple ID"),
    // Can be a tableCell (Settings -> iCloud) or button (Settings -> Account -> Add Account -> iCloud)
    SIGNIN_BUTTON: UIAQuery.withPredicate("name == 'Sign In' AND interactionEnabled == TRUE").isVisible().isEnabled().orElse(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Next')).isVisible().isEnabled() ),
    SIGNOUT_BUTTON: UIAQuery.withPredicate("name == 'Sign Out' AND interactionEnabled == TRUE"),    // May be not in visible view if the device is a small-screen device
    SAVE_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Save')).isVisible().isEnabled(),
    AGREE_BUTTON: UIAQuery.buttons('Agree').isVisible().isEnabled(),
    TERMS_AND_CONDITIONS: UIAQuery.BOTTOM_NAVBAR.andThen("Terms and Conditions"),

    APPLE_ID_VERIFICATION_CODE_ALERT: UIAQuery.contains('Apple ID Verification Code'),
    DIDNT_GET_A_CODE_ALERT: UIAQuery.contains("Didn't get a code?"),
    TOO_MANY_CODES_SENT_ALERT: UIAQuery.contains("Too Many Codes Sent"),
    TWO_FACTOR_AUTHENTICATION_ALERT: UIAQuery.withPredicate('any identifiers contains "Two-Factor Authentication" and not label == "Turn on Two-Factor Authentication"'),
    DIDNT_GET_A_VERIFICATION_CODE_ALERT: UIAQuery.contains("Didn't get a verification code?"),
    SAFARI_MERGE_DATA_ALERT: UIAQuery.actionSheets().contains('Your Safari data'),
    GENERIC_MERGE_DATA_ALERT: UIAQuery.actionSheets().contains('will be uploaded and merged with iCloud'),
    TEXT_CODE_TO_BUTTON: UIAQuery.buttons().contains('Text Code to'),
    DIDNT_GET_A_CODE_BUTTON: UIAQuery.withPredicate("behavior == 'Button' && label like[c] 'Didn?t Get a Code?'"),
};

settings._enterText = function _enterText(query, text, timeout) {
    if (this.waitUntilPresent(query, timeout)) {
        this.enterText(query, String(text));
    } else {
        throw new UIAError('Could not find %0'.format(query.description()));
    }
}

settings._tapIfExists = function _tapIfExists(queryToTap, timeToWait) {
    if (Number(timeToWait) > 0) { this.waitUntilPresent(queryToTap, timeToWait); }
    return this.tapIfExists(queryToTap);
}

/**
 * Enter AppleID credentials to sign into iCloud.  Assumes the device is currently in the iCloud sign-in view (reached by [ Settings -> iCloud ] or [ Settings -> Account -> Add Account -> iCloud ])
 *
 * @param {string}  username                    - AppleID
 * @param {string}  password                    - Password
 * @param {boolean} throwIfAccountAlreadyAdded  - If set to true and the account is already added to the device, then this method will throw a UIAError
 * @param {object}  options
 * @param {string}  [options.passcode="111111"] - passcode of the device used for enrolling into iCDP.
 * @param {bool}    [options.useCDPApproval=false] - Optional Whether to opt for approval flow while enrolling into iCDP
 * @param {boolean} [options.getHsa2Code=false]  - If set to true then get HSA2 code from other device part of MD suite
 * @param {boolean} [options.getHsa2TextCode=false]  - If set to true then get HSA2 sms verification code from other device part of MD suite
 * @param {string}  [options.deviceName="Device000000"] - Optional device name to choose from list of parent devices to enroll into iCDP for second device
 * @param {string}  [options.previousPasscode="000000"] - Optional parent device's passcode to enroll into iCDP
 * @param {string}  [options.cdpSemaphoreUUID=null] - Required in order to get HSA2 code from other device in a multi device suite
 * @param {object}  [options.mergeDataOptions] - Options for merging data already on device when signing into iCloud
 * @param {string}  [options.mergeDataOptions.safariData=false] - Whether or not to merge the safari data if it exists prior to signing in.
 * @returns {object} signInStatus               - An object with 2 fields - whether we passed the iCloud login view, and whether we need to continue to confirm Sync Options
 * @throws if device cannot get past initial iCloud sign-in or if it is attempting to sign in to an account it is already signed in to, and throwIfAccountAlreadyAdded is set to true
 */
settings.signInWithAppleIDAlert = function signInWithAppleIDAlert(username, password, throwIfAccountAlreadyAdded, options) {
    var encounteredAccountAlreadyAddedAlert = false;
    var failedVerificationRetries = 3;
    var NUM_OF_TRIES = 90; //Please replace this to 60 once iCDP enrollment is optimized to lesser time.<rdar://problem/22476280> Need a strategy for avoiding overlong sync during iCDP signin & probably other times
    var tryCount = 0;
    var signInComplete = false;
    var signInError = false;
    var retryTwoFactorAuthentication = false;
    var retryTwoFactorAuthenticationCount = 0;
    var inTwoFactorAuthOtherDevice = false;
    var app = settings;

    options = UIAUtilities.defaults(options, {
        hsaCode: false,
        enrollHsa: false,
        useCDPApproval: false,
        navigationViews: ['iCloud'],
        hsaTrustedNumber: target.phoneNumber(),
        hsaCountryCode: "+1 (United States)",
        hsaVerifyMethod: "Text Message",
        passcode: '111111',
        getHsa2Code: false,
        getHsa2TextCode: false,
        previousPasscode: '000000',
        deviceName: 'Device000000',
        cdpSemaphoreUUID: null,
        mergeDataOptions: {
            safariData: false,
            otherData: false
        }
    });

    // Each handler_ detects a UI state that can be encountered during iCloud signin.
    // It then handles the flow for that iCloud signin path.

    // Verification Failed
    var handler_VerificationFailed = function() {
       if (app.exists(UIAQuery.alerts().andThen(UIAQuery.withPredicate('name CONTAINS[c] "Verification Failed" and isVisible == 1')))) {
           UIALogger.logMessage("Encountered Verification Failed alert; tapping retry. Retries left: %0".format(failedVerificationRetries));
           failedVerificationRetries--;
           if (failedVerificationRetries < 1) {
               app._tapIfExists(UIAQuery.alerts().andThen('cancel'), 5);
               throw new UIAError('Too many verification failures');
           } else {
               app._tapIfExists(UIAQuery.alerts().andThen('retry'), 5);
               return true;
           }
        }
        return false;
    };

    // FindMyiPhone dialog.
    var handler_FindMyiPhone = function() {
        if (app.exists(UIAQuery.alerts().andThen(UIAQuery.withPredicate('name CONTAINS[c] "Find My i" and name CONTAINS[c] "Enabled" and isVisible == 1')))) {
            UIALogger.logMessage("Encountered the Find My iPhone/Pad is Enabled alert; tapping OK");
            app._tapIfExists(UIAQuery.alerts().andThen('OK'), 5);
            return true;
        }
        return false;
    };

    // Terms and Conditions dialog.
    var handler_iCloudTermsAndConditions = function() {
        if (app.exists(UIAQuery.iCloudSettings.TERMS_AND_CONDITIONS)) {
            UIALogger.logMessage("Terms and Conditions alert; tapping 'Agree'");
            app.tap(UIAQuery.iCloudSettings.AGREE_BUTTON);
            return true;
        }
        return false;
    };

    // Two Factor Authentication SignIn.
    var handler_TwoFactorAuthentication = function() {
        var retVal = false;
        if (app.exists(UIAQuery.iCloudSettings.APPLE_ID_VERIFICATION_CODE_ALERT) || app.exists(UIAQuery.iCloudSettings.TWO_FACTOR_AUTHENTICATION_ALERT) || app.exists(UIAQuery.iCloudSettings.DIDNT_GET_A_CODE_ALERT)) {
            var hsaOpts = {
                username: username,
                password: password,
            };
            hsaCode = false;
            if(options.getHsa2Code) {
                hsaCode = app.getHsa2CodeMD(options.cdpSemaphoreUUID);
            } else if (options.getHsa2TextCode) {
                // Two-Factor Authentication Flow:
                // If an iOS device is signed-in somewhere the first alert will be:
                //     Apple ID Verification Code
                // If no device can present the code then the first alert will be:
                //     Two-Factor Authentication
                // Where we will request the code to be sent via SMS.
                // Other alerts can occur:
                //      Too Many Codes Sent - we tried unsuccessfully too many times where we didn't complete the sign-in flow yet had codes sent.
                //       others?
                var twoFactorAuthenticationAlerts = UIAQuery.alerts()
                                                    .andThen(UIAQuery.iCloudSettings.DIDNT_GET_A_CODE_ALERT)
                                                    .orElse(UIAQuery.iCloudSettings.TOO_MANY_CODES_SENT_ALERT)
                                                    .orElse(UIAQuery.iCloudSettings.DIDNT_GET_A_VERIFICATION_CODE_ALERT);
                app.handlingAlertsInline(twoFactorAuthenticationAlerts, function() {
                    if (app.exists(UIAQuery.iCloudSettings.APPLE_ID_VERIFICATION_CODE_ALERT)) {
                        UIALogger.logMessage('Apple ID Verification Code.');
                        app.tap(UIAQuery.iCloudSettings.DIDNT_GET_A_CODE_BUTTON);
                        retVal = true;
                        return retVal;
                    }
                    if (app.exists(UIAQuery.iCloudSettings.TOO_MANY_CODES_SENT_ALERT)) {
                        // We're asked to try the last code sent.
                        app.tap('OK');
                        // We'll throw here since we can't recover from this.
                        throw new UIAError('Too many codes sent for two-factor authentication.');
                    }
                    if (app.exists(UIAQuery.iCloudSettings.DIDNT_GET_A_CODE_ALERT) && !hsaCode) {
                        UIALogger.logMessage("Two-Factor Authentication: Alert: Didn't get a code?");
                        app._tapIfExists(UIAQuery.iCloudSettings.TEXT_CODE_TO_BUTTON, 30);
                        retVal = true;
                        return retVal;
                    }
                    if (app.exists(UIAQuery.iCloudSettings.TWO_FACTOR_AUTHENTICATION_ALERT)) {
                        hsaCode = app.getHsa2CodeMD(options.cdpSemaphoreUUID);
                        retVal = true;
                    }
                });
            } else {
                hsaCode = options.hsaCode || app.getHsa2CodeFromiCloudLoad(hsaOpts);
            }
            if (hsaCode) {
                app.typeString(hsaCode);
                if (UIAWaiter.withPredicate('ViewDidAppear', 'navigationItemTitle == "Incorrect Verification Code"').wait(10)) {
                    UIALogger.logMessage('Incorrect Verification Code detected.');
                    retryTwoFactorAuthentication = true;
                    retryTwoFactorAuthenticationCount+=1;
                    app.tapIfExists('OK');
                    signInError = true;
                    // We can only request the code once since the web service that gives us
                    // the code has no way to accept a retry.
                    // FUTURE: If UIA can signal coreautomationd then we can forward the notification
                    // to the web service to allow for a retry.
                    //if (retryTwoFactorAuthenticationCount > failedVerificationRetries) {
                        throw new UIAError('Too many Two-Factor Authentication failures');
                    //}
                }
                UIALogger.logMessage('Exit handler_TwoFactorAuthentication: %0'.format(retVal));
                return retVal;
            }
        }
        UIALogger.logMessage('Exit handler_TwoFactorAuthentication: %0'.format(retVal));
        return retVal;
    };

    // Two Factor Authentication - Validate from trusted device details
    var handler_TwoFactorAuthenticationTrustedDeviceDetails = function() {
        UIALogger.logMessage('Enter handler_TwoFactorAuthenticationTrustedDeviceDetails');
        if ( app.exists(UIAQuery.contains('Enter Passcode for Other')) && !inTwoFactorAuthOtherDevice) {
            UIALogger.logMessage('Encountered request to enter passcode for parent device to enroll into iCDP.');
            var thisViewDisappeared = UIAWaiter.waiter(
                'ViewDidDisappear', {
                    predicate: 'controllerClass == "PSSetupController"',
                }
            );
            var signinViewDisappeared = UIAWaiter.waiter(
                'ViewDidDisappear', {
                    predicate: 'controllerClass == "AAUISignInViewController"',
                }
            );
            if ((!options.previousPasscode && !options.deviceName) && !options.useCDPApproval) {
                throw new UIAError('Must provide previous parent passcode and its name. We are not choosing approval flow.');
            } else {
                UIALogger.logMessage('Passcode: %0'.format(options.passcode));
                app.typeString(options.passcode);
                inTwoFactorAuthOtherDevice = true; // This is a temp hack. When does this view disappear so we don't re-enter it??
                return true;
            }
            return true;
        }
        return false;
    };

    // Apple ID Security - Request that you turn on two-factor Authentication
    var handler_AppleIDSecurity = function() {
        UIALogger.logMessage('Enter handler_AppleIDSecurity');
        if (app.exists(UIAQuery.contains('When you sign in on any new device, you will verify your identity using either one of your other devices or your phone number'))) {
            UIALogger.logMessage('Encountered request to enable two-factor authentication');
            var appleIDSecurityAlert = UIAQuery.alerts().andThen(UIAQuery.contains('Two-factor authentication is the best way to keep your account secure'));
            app.handlingAlertsInline(appleIDSecurityAlert, function () {
                app.tap(UIAQuery.buttons('Other Options'));
                app.tap(UIAQuery.buttons("Do not upgrade"));
            });
            return true;
        }
        return false;
    };

    // Merge Data - Request that you merge data currently on the device with data in iCloud.
    var handler_mergeData = function() {
        UIALogger.logMessage('Enter handler_mergeData');
        if (app.exists(UIAQuery.iCloudSettings.SAFARI_MERGE_DATA_ALERT)) {
            UIALogger.logMessage('Encountered request to merge Safari data');
            app.handlingAlertsInline(UIAQuery.iCloudSettings.SAFARI_MERGE_DATA_ALERT, function () {
                if (options.mergeDataOptions.safariData) {
                    app.tap(UIAQuery.buttons('Merge'));
                } else {
                    app.tap(UIAQuery.buttons('Don’t Merge'));
                }
            });
            return true;
        }

        if (app.exists(UIAQuery.iCloudSettings.GENERIC_MERGE_DATA_ALERT)) {
            UIALogger.logMessage('Encountered request to merge mobile data to iCloud');
            app.handlingAlertsInline(UIAQuery.iCloudSettings.GENERIC_MERGE_DATA_ALERT, function () {
                if (options.mergeDataOptions.otherData) {
                    app.tap(UIAQuery.buttons('Merge'));
                } else {
                    app.tap(UIAQuery.buttons('Don’t Merge'));
                }
            });
            return true;
        }
        return false;
    };

    // All the handlers for signing into iCloud are defined above.
    var signInHandler = function() {
        // Chain together handler functions so they are "plug and play"
        var eventHandlers = [
            handler_FindMyiPhone,
            handler_iCloudTermsAndConditions,
            handler_TwoFactorAuthentication,
            handler_TwoFactorAuthenticationTrustedDeviceDetails,
            handler_VerificationFailed,
            handler_AppleIDSecurity,
            handler_mergeData
        ];
        UIALogger.logMessage('signInHandler Enter');
        for (var i = 0; i < eventHandlers.length; i++) {
            if (eventHandlers[i]()) {
                UIALogger.logMessage('signInHandler Exit: true');
                return true;
            }
        }
        UIALogger.logMessage('signInHandler Exit: false');
        return false;
    };

    var successfullySignedIn = this.withAlertHandler(signInHandler, function () {
        this._tapIfExists(UIAQuery.iCloudSettings.USE_EXISTING_ACCOUNT_BOTTON, 5);
        this._enterText(UIAQuery.iCloudSettings.USERNAME_TEXTFIELD, username + '\n', 60);
        this._enterText(UIAQuery.iCloudSettings.PASSWORD_TEXTFIELD, password, 60);
        this._tapIfExists(UIAQuery.iCloudSettings.SIGNIN_BUTTON, 60);

        // We are considered to have successfully gone past the sign in view if we landed
        // in an iCloud Sync Options view (signing in using path
        // Settings -> Account -> Add Account -> iCloud)
        // or found a Sign Out button (signing in using path Settings -> iCloud)
        while (!signInComplete && !signInError) {
            if (this.waitUntilPresent(UIAQuery.iCloudSettings.SAVE_BUTTON.orElse(UIAQuery.iCloudSettings.SIGNOUT_BUTTON), 2)) {
                signInComplete = true;
            }
            UIALogger.logMessage("Waiting for the iCloud sign-in completion. Iteration %0 of %1".format(tryCount, NUM_OF_TRIES));
            if (tryCount === NUM_OF_TRIES) {
                throw new UIAError("Took too long to sign in!", {identifier:"iCloud Sign-In Taking Too Long"});
            }
            // Call the signinHandler to look for possible state changes. These state changes might not trigger the Alert Handler.
            if (signInHandler()) {
                // A UI state change was detected and handled.
            }
            tryCount+=1;
        }
        return signInComplete;
    });
    // Return 2 bits of info - whether we passed the iCloud login view, and whether we need to continue to confirm Sync Options (this is not necessary if we were already signed in, and we encountered the Account Already Added alert)
    return { SuccessfullySignedIn: successfullySignedIn, NeedToConfirmSyncOptions: !encounteredAccountAlreadyAddedAlert };
}

/**
 * Uses semaphore helper function to fetch authCode for iCDP.
 * This uses semaphore.apple.com to create a semaphore that is used to fetch the iCloud HSA2
 * from another trusted device. The semaphore is created unlocked. When the locked state is
 * detected the trusted device is writing the authCode in to the payload of the semaphore.
 * Once unlocked the authCode content is fetched and returned.
 * Note: This method requires the device under test to be on CorpNet in order to connect to
 * semaphore.apple.com.
 * @param {string} semaphoreUUID - Required semaphore UUID
 * @param {boolean} getHsa2TextCode]  - If set to true then get HSA2 sms verification code from other device part of MD suite
 */
settings.getHsa2CodeMD = function getHsa2CodeMD(semaphoreUUID) {
    var semaphore;
    var authCode = 'authCode';
    if (semaphoreUUID !== undefined && semaphoreUUID !== null && semaphoreUUID !== '') {
        semaphore = new Semaphore.Semaphore(
            semaphoreUUID,
                {'transport': Semaphore.TransportMethods.NETWORK}
        );
    } else {
        throw new UIAError('You must specify semaphoreUUID');
    }
    semaphore.unlock(semaphoreUUID);
    // Wait for semaphore to be unlocked by Device 1
    UIALogger.logMessage("Unlocking semaphore and waiting for locked status.");
    semaphore.wait(Semaphore.States.LOCKED);
    UIALogger.logMessage("Semaphore in locked status by trusted device. Now waiting for unlocked status.");
    semaphore.wait(Semaphore.States.UNLOCKED);
    var payload = semaphore.fetchPayload();
    UIALogger.logMessage('Value of payload %0'.format(payload.authCode));
    if (!payload || !payload.authCode) {
        UIASemaphore.lock(semaphoreUUID);
        throw new UIAError(
            'Malformed payload: %0 \
                for semaphore: %1.'.format(JSON.stringify(payload),semaphoreUUID)
        );
    }
    UIASemaphore.lock(semaphoreUUID);
    semaphore.unlock(semaphoreUUID);
    UIALogger.logMessage("Returning hsa2 code to the calling function.");
    return payload.authCode;
}
