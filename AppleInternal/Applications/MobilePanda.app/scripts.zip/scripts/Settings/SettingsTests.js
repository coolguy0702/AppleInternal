load('UIATesting.js');
load('Settings.js');
load('Settings+FaceTime.js');
load('Settings+Keychain.js');
load('Settings+Accounts.js');
load('SpringBoard.js');

if (typeof SettingsTests === 'undefined') {
    /**
     * @namespace
     */
    var SettingsTests = {
        /**
         * Test follows a navigation-view path in Settings, taps a setting,
         * and optionally verifies that the setting has a checkmark.
         *
         * @targetApps Preferences
         * @note Default test (no arguments) sets Auto-Lock to Never.
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["General","Auto-Lock"]] - Views to navigate
         * @param {string} [args.checkItem="Never"] - Item to check
         * @param {boolean} [args.validate=true] - Should we validate that a checkmark appeared?
         */
        chooseCheckmarkedItem: function chooseCheckmarkedItem(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["Display & Brightness", "Auto-Lock"],
                checkItem: "Never",
                validate: true,
            });

            settings.launch();
            try {
                settings.chooseCheckmarkedItem(
                    args.navigationViews,
                    args.checkItem,
                    args.validate
                );
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Test follows a navigation-view path in Settings and sets a switch to
         * the specified value (or does nothing if it already has that value)
         *
         * @targetApps Preferences
         * @note Default test (no arguments) enables location services
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["Privacy","Location-Services"]] - Views to navigate
         * @param {string} [args.switchItem="Location Services"] - Item to switch on or off
         * @param {boolean} [args.shouldMatchExactly] - Should search for switches that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {object} [args.alertOptions] - args for optional inline alert handling
         * @param {object} [args.alertOptions.alertPredicate=""] - OPTIONAL NSPredicate-formatted string to identify an alert for inline alert handling
         * @param {object} [args.alertOptions.alertElementToTap=""] - OPTIONAL NSPredicate-formatted string to identify alert element to tap if performing inline alert handling
         */
        changeSingleSwitch: function changeSingleSwitch(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["Privacy", "Location Services"],
                switchItem: "Location Services",
                shouldMatchExactly: false,
                switchValue: true,
                alertOptions: {
                  alertPredicate: "",
                  alertElementToTap: "",
                }
            });
            var returnValue = true;
            settings.launch();
            try {
                if (args.alertOptions.alertElementToTap == ""){ // default behavior - no optional alert handling to be performed
                    settings.changeSingleSwitch(
                        args.navigationViews,
                        args.switchItem,
                        args.switchValue,
                        args.shouldMatchExactly
                    );
                } else { //include inline alert handling
                    var optionalAlertHandler = UIAQuery.withPredicate(args.alertOptions.alertPredicate);

                    UIAAlertManager.ignoringAlerts(optionalAlertHandler, function() {
                        var stateChanged = settings.changeSingleSwitch(
                            args.navigationViews,
                            args.switchItem,
                            args.switchValue,
                            args.shouldMatchExactly
                        );
                        if (stateChanged) {
                            if (!settings.exists(UIAQuery.withPredicate(args.alertOptions.alertElementToTap))) {
                                UIALogger.logError(
                                    'Failed to find alert with predicate "%0"'.format(args.alertOptions.alertElementToTap));
                                    returnValue = false;
                            }
                            else {
                                settings.tap(UIAQuery.withPredicate(args.alertOptions.alertElementToTap));
                            }
                        }
                    });
                }
            } finally {
                settings.returnToTopLevel();
                return returnValue;
            }
        },

        /**
         * Test changes the region of the device, if needed.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {string} [args.region="Canada"] - The region to change the device to.
         */
        changeRegion: function changeRegion(args) {
            args = UIAUtilities.defaults(args, {
                                         region: "Canada"
                                         });

            settings.launch();
            try {
                settings.waitToBecomeActive(60, function() {
                    settings.setDeviceRegion(args.region);
                });
            } finally {
                // Verify region is set
                var currentRegion = settings.getDeviceRegion();
                settings.returnToTopLevel();
                if (currentRegion ===  args.region) {
                    UIALogger.logMessage('Region is set to %0'.format(currentRegion));
                }
                else {
                    throw new UIAError('Failed to set region as %0'.format(args.region));
                }
            }
        },

        /**
         * Test will change switch Settings -> Privacy -> Location Services -> Location Services
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         */
        changeLocationServiceSwitch: function changeLocationServiceSwitch(args) {
            args = UIAUtilities.defaults(args, {
                switchValue: true,
            });

            settings.launch();
            try {
                settings.changeLocationServiceSwitch(args.switchValue);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Test follows a navigation-view path in Settings and taps a certain element and deals
         * with an alert window that pops up with the same name as the item and presses the button
         *
         * @targetApps Preferences
         * @note Default test (no arguments) removes all local photos
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["Internal Settings","Photos"]] - Views to navigate
         * @param {string} [args.item="Remove All Local Photos"] - Item to select
         * @param {boolean} [args.isSwitch] - Tells the function if it should be looking for a switch
         * @param {string} [args.alertButton="Remove"] - Text contained in the alert window button that should be pressed
         * @param {boolean} [args.shouldMatchExactly] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         */
        selectItemAndConfirmAlert: function selectItemAndConfirmAlert(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["Internal Settings","Photos"],
                item: "Remove All Local Photos",
                isSwitch: false,
                alertButton: "Remove",
                shouldMatchExactly: false,
                switchValue: null,
            });

            settings.launch();
            try {
                // Navigate to the item
                if (!settings.navigateNavigationViews(args.navigationViews)) {
                    throw new UIAError("Failed to navigate settings");
                }

                // Based on settings.setSwitchSetting()
                var query = null;
                if (args.isSwitch) {
                    query = args.shouldMatchExactly ? UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches()
                                                        .andThen(UIAQuery.query(args.item)
                                                        .withPredicate("isUserInteractionEnabled == 1")))
                                                   : UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches()
                                                        .andThen(UIAQuery.contains(args.item)
                                                        .withPredicate("isUserInteractionEnabled == 1")));
                } else {
                    query = args.shouldMatchExactly ? UIAQuery.RIGHT_TABLE.andThen(UIAQuery.query(args.item)
                                                        .withPredicate("isUserInteractionEnabled == 1"))
                                                   : UIAQuery.RIGHT_TABLE.andThen(UIAQuery.contains(args.item)
                                                        .withPredicate("isUserInteractionEnabled == 1"));
                }

                settings.scrollToVisible(query);

                // Wait for the target to be ready to be interacted with...
                // FIXME: The 'waitUntilPresent' function does not manage to work in all cases for the test 'UIA2_Hyperion->Disable iCloud Backup'.
                target.delay(1);
                // if (!settings.waitUntilPresent(query, 10)) {
                //     throw new UIAError("The item '" + query + "' never appeared!");
                // }

                // Only continue if the item is not a switch OR if the switch WILL be changed
                if(!args.isSwitch || (args.isSwitch && settings.shouldFlipSwitch(settings.inspect(query).value, args.switchValue))) {
                    settings.handlingAlertsInline(UIAQuery.contains(args.alertButton), function() {
                        // Change/Tap the item
                        if (args.isSwitch) {
                            settings.setControl(query, args.switchValue);
                        } else {
                            UIALogger.logMessage("Tapping item");
                            settings.tap(query);
                        }

                        // Deal with alert that popped up
                        if (settings.waitUntilPresent(UIAQuery.contains(args.alertButton), 3)) {
                            UIALogger.logMessage("Dealing with the alert that popped up");
                            if(args.isSwitch) {
                                // This will need to be changed to deal with all cases for alerts that popup for switches
                                settings.tap('OK');
                            } else {
                                // The 'orElse' part deals with the iPad popup that has an 'OK' button rather than repeating the item name for iPhones
                                settings.tap(UIAQuery.buttons().andThen(UIAQuery.contains(args.alertButton)).orElse(UIAQuery.query("OK")));
                            }
                        } else {
                            UIALogger.logMessage("Alert for '" + args.item + "' never appeared");
                        }
                    });

                    // Wait and check to make sure that the element actually stays set (Switches only)
                    if (args.isSwitch) {
                        target.delay(2);
                        if (settings.shouldFlipSwitch(settings.inspect(query).value, args.switchValue)) {
                            throw new UIAError("The switch (" + args.item + ") did not get set to the right value!");
                        }
                    }
                }
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Test follows a navigation-view path in Settings and sets a switch to
         * the specified value (or does nothing if it already has that value)
         *
         * @targetApps Preferences
         * @note Default test (no arguments) Enables Messages notifications and sets style to None
         *
         * @param {object} args - Test arguments
         * @param {string} [args.appName="Messages"] - App to set notifications for
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {string} [args.style="None"] - Notification style: "None", "Alerts", or "Banner"
         * @param {array} [args.appSubViews=[]] - Subviews of app to navigate
         */
        setNotification: function setNotification(args) {
            args = UIAUtilities.defaults(args, {
                appName: 'Messages',
                style: 'None',
                switchValue: true,
                appSubViews: [],
            });

            settings.launch();
            try {
                settings.setNotification(
                    args.appName,
                    args.style,
                    args.switchValue,
                    args.appSubViews
                );
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Test checks if the Version in Settings matches the expected build.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {string} [args.targetBuild=null] - Expected build in Settings
         */
        checkBuild: function checkBuild(args) {
            if (!args.targetBuild) {
                throw new UIAError('Must specifify args.targetBuild');
            }

            if (args.targetBuild === '$$buildtrigger_build') {
                UIALogger.logPass('No build trigger found - marking test a pass');
                return;
            }

            settings.launch();
            try {
                settings.checkBuild(args.targetBuild);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Test sets the wallpaper to the photo in the specified album and
         * index
         *
         * @targetApps Preferences
         * @note Default test (no arguments) Picks a random Still wallpaper
         *
         * @param {object} args - Test arguments
         * @param {string} [args.album="Still photo wallpapers"] - Album in which to find photo
         * @param {number} [args.index=null] - Index of photo to pick. If index === null, pick a random photo
         */
        setWallpaper: function setWallpaper(args) {
            args = UIAUtilities.defaults(args, {
                album: "Still photo wallpapers",
                index: null,
            });

            settings.launch();
            try {
                settings.setWallpaper(args.album, args.index);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Tests setting the passcode on a device
         *
         * @targetApps Preferences
         * @note Default test (no arguments) Assumes no current passcode and sets passcode to 111111
         *
         * @param {object} args - Test arguments
         * @param {string} [args.newPasscode="111111"] - Passcode to set
         * @param {number} [args.oldPasscode=null] - Current passcode if one exists
         * @param {string} [args.newPasscodeType=''] - Numeric or Alphanumeric, if empty, then the passcode is default 4/6 digit
         */
        setPasscode: function setPasscode(args) {
            args = UIAUtilities.defaults(args, {
                newPasscode: '111111',
                oldPasscode: null,
                newPasscodeType: '',
            });

            if (args.oldPasscode) {
                // FIXME: unlock() throws instead of returning true/false on
                // newer versions of scripter2. Support both for now.
                var unlocked = springboard.unlock({passcode: args.oldPasscode});
                if (typeof unlocked !== 'undefined' && !unlocked) {
                    throw new UIAError('Could not unlock with old passcode');
                }
            }

            settings.launch();
            try {
                settings.setPasscode(args.newPasscode, args.oldPasscode);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Tests disabling the passcode on a device
         *
         * @targetApps Preferences
         * @note Default test (no arguments) Assumes current passcode is 111111 and disables passcode
         *
         * @param {object} args - Test arguments
         * @param {string} [args.passcode="111111"] - Passcode needed to disable passcode
         */
        disablePasscode: function disablePasscode(args) {
            args = UIAUtilities.defaults(args, {passcode: '111111'});

            if (args.passcode) {
                // FIXME: unlock() throws instead of returning true/false on
                // newer versions of scripter2. Support both for now.
                var unlocked = springboard.unlock({passcode: args.oldPasscode});
                if (typeof unlocked !== 'undefined' && !unlocked) {
                    throw new UIAError('Could not unlock with old passcode');
                }
            }

            settings.launch();
            try {
                settings.disablePasscode(args.passcode);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Creates an email account with the specified options
         *
         * @targetApps Preferences, accountsd
         * @note Default test (no arguments) Creates an iCloud email for Jane Smith using the persisted AppleID
         *
         * @param {object}    args - Test arguments
         * @param {string}    [args.type="iCloud"] - Type of mail account to create
         * @param {string}    [args.name="Jane Smith"] - Username for Exchange accounts. First & last name for everything else.
         * @param {string}    [args.address="PERSISTEDAPPLEID"] - Email address. Use 'PERSISTEDAPPLEID' to retrieve persisted account from SpringBoard
         * @param {string}    [args.password="PERSISTEDAPPLEIDPASSWORD"] - Password. Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         * @param {string}    [args.server=null] - Server for use with Exchange or "Other" accounts. Defaults to server in address.
         * @param {string}    [args.description=null] - Optional email description. Address is used if not provided.
         *
         * @param {bool}      [args.throwIfAccountAlreadyAdded=true] - Option to throw if the account is already logged in. Default true.
         *
         * @param {bool}      [args.syncOptions.keepAlreadSynced=false] - Option to keep data that's already synced. Default false
         * @param {null|bool} [args.syncOptions.syncContacts] - Option to enable Sync for Contacts
         * @param {null|bool} [args.syncOptions.syncCalendars] - Option to enable Sync for Calendars
         * @param {null|bool} [args.syncOptions.syncDocuments] - Option tpo enable Sync for Documents
         * @param {null|bool} [args.syncOptions.syncMail] - Option to enable Sync for Mail
         * @param {null|bool} [args.syncOptions.syncNotes] - Option to enable Sync for Notes
         * @param {null|bool} [args.syncOptions.syncNews] - Option to enable Sync for News
         * @param {null|bool} [args.syncOptions.syncReminders] - Option to enable Sync for Reminders
         * @param {null|bool} [args.syncOptions.syncSafari] - Option to enable Sync for bookmarks
         * @param {null|bool} [args.syncOptions.syncWallet] - Option to enable Sync for Wallet
         * @param {null|bool} [args.syncOptions.setFindMyDevice] - Option to enable or disable "Find My iPhone/iPad"
         * @param {null|bool} [args.syncOptions.setiCloudDrive] - Option to enable or disable "iCloud Drive"
         *
         * @param {bool}      [args.otherOptions.useAdvancedTable=true] - Option to use advanced table. Default true
         * @param {bool}      [args.otherOptions.usePop=false] - Option to use Pop instead of IMAP. Default false
         * @param {string}    [args.otherOptions.inHostName=null] - Optional incoming host name for "Other" accounts
         * @param {string}    [args.otherOptions.inUserName=null] - Optional incoming user name for "Other" accounts
         * @param {string}    [args.otherOptions.inPassword=null] - Optional incoming password for "Other" accounts

         * @param {string}    [args.otherOptions.outHostName=null] - Optional outcoming host name for "Other" accounts
         * @param {string}    [args.otherOptions.outUserName=null] - Optional outcoming user name for "Other" accounts
         * @param {string}    [args.otherOptions.outPassword=null] - Optional outcoming password for "Other" accounts
         *
         * @param {object}    [args.hsaOptions] - args for hsa enrollment and verification
         * @param {string}    [args.hsaOptions.hsaCode] - two factor auth code for HSA2
         * @param {boolean}   [args.hsaOptions.enrollHsa=false] - whether or not to enroll in HSA2
         * @param {string}    [args.hsaOptions.hsaTrustedNumber] - Phone number to use as trusted number for HSA2 enrollment
         * @param {string}    [args.hsaOptions.hsaCountryCode] - Country code for hsa2 trusted number
         * @param {string}    [args.hsaOptions.hsaVerifyMethod] - One of "Text Message", "Robo Call"
         * @param {string}    [args.hsaOptions.passcode="111111"] - passcode of the device used for enrolling into iCDP.
         * @param {bool}      [args.hsaOptions.useCDPApproval=false] - Optional Whether to opt for approval flow while enrolling into iCDP
         * @param {string}    [args.hsaOptions.deviceName="Device000000"] - Optional device name to choose from list of parent devices to enroll into iCDP for second device
         * @param {string}    [args.hsaOptions.previousPasscode="000000"] - Optional parent device's passcode to enroll into iCDP
         */
        createEmailAccount: function createEmailAccount(args) {
            args = UIAUtilities.defaults(args, {
                // Required parameters
                type:                'iCloud',
                name:                'Jane Smith',
                address:             'PERSISTEDAPPLEID',
                password:            'PERSISTEDAPPLEIDPASSWORD',

                // Optional parameters
                server:              null,
                description:         null,

                // Throw if the account is already logged in
                throwIfAccountAlreadyAdded: true,

                // Sync options - not available for every account
                syncOptions: {
                    keepAlreadySynced:   false,
                    syncMail:            null,
                    syncContacts:        null,
                    syncCalendars:       null,
                    syncDocuments:       null,
                    syncMail:            null,
                    syncNotes:           null,
                    syncReminders:       null,
                    syncSafari:          null,
                    syncWallet:          null,
                    setFindMyDevice:     null,
                    setiCloudDrive:      null,
                },

                // "Other" account options
                otherOptions: {
                    useAdvanceTable:     true,
                    usePop:              false,
                    inHostName:          null,
                    inUserName:          null,
                    inPassword:          null,
                    outHostName:         null,
                    outUserName:         null,
                    outPassword:         null,
                },

                // "hsa" account options
                hsaOptions: {
                    enrollHsa:     false,
                },
            });

            if (args.address === 'PERSISTEDAPPLEID') {
                UIALogger.logMessage('Using the persisted AppleID to create email account');
                args.address = springboard.appleID;
            }

            if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password to create email account');
                args.password = springboard.appleIDPassword;
            }

            var accountType = settings.toAccountType(args.type);
            if (accountType === null) {
                throw new UIAError('Unsupported account type: "%0"'.format(args.type));
            } else {
                args.type = accountType;
                UIALogger.logMessage('Creating account of type %0'.format(settings.accountType[accountType]));
            }

            if (!args.description && args.type !== settings.accountType.iCloud) {
                UIALogger.logMessage('Using address as description for account');
                args.description = args.address;
            }

            settings.createEmail(args);
        },

        /**
         * Deletes iCloud account if one has been set up
         *
         * @targetApps Preferences
         * @note Default test (no arguments) Deletes the iCloud account using the persisted account info
         *
         * @overrideID Delete iCloud Account
         *
         * @param {object}    args - Test arguments
         * @param {string}    [args.password="PERSISTEDAPPLEIDPASSWORD"] - Password. Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         */
        deleteiCloudAccount: function deleteiCloudAccount(args) {
            args = UIAUtilities.defaults(args, {
                password: 'PERSISTEDAPPLEIDPASSWORD',
            });

            if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password to create email account');
                args.password = springboard.appleIDPassword;
            }

            settings.launch();
            try {
                settings.deleteiCloudAccount(args.password);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Sets iCloud testing environment
         * @overrideID Set iCloud Environment
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.iCloudEnvironment="Production"] - iCloud X Environment.  Legal argument values are defined inside settings.setiCloudEnvironment()
         */
        setiCloudEnvironment: function setiCloudEnvironment(args) {
            args = UIAUtilities.defaults(args, {
                iCloudEnvironment: 'Production',
            });

            settings.launch();
            try {
                settings.setiCloudEnvironment(args.iCloudEnvironment);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Turn on iCloud Drive
         * @overrideID Turn On iCloud Drive
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         */
        turnOniCloudDrive: function turnOniCloudDrive(args) {
            args = UIAUtilities.defaults(args, {
                AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
            });

            if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password to create email account');
                args.password = springboard.appleIDPassword;
            }

            settings.launch();
            try {
                settings.turnOniCloudDrive(args.AppleIDPassword);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Turn off iCloud Drive
         * @overrideID Turn Off iCloud Drive
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password. Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         */
        turnOffiCloudDrive: function turnOffiCloudDrive(args) {
            args = UIAUtilities.defaults(args, {
                AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
            });

            if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password');
                args.AppleIDPassword = springboard.appleIDPassword;
            }
            settings.turnOffiCloudDrive(args.AppleIDPassword);
        },


        /**
         * Turn on Show iCloud Drive on Home Screen
         * @overrideID Turn On Show iCloud Drive on Home Screen
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         */
        turnOnShowiCloudDriveOnHomeScreen: function turnOnShowiCloudDriveOnHomeScreen(args) {
            args = UIAUtilities.defaults(args, {
                AppleIDPassword: 'PERSISTEDAPPLEIDPASSWORD',
            });

            if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password to create email account');
                args.password = springboard.appleIDPassword;
            }

            settings.launch();
            try {
                settings.turnOnShowiCloudDriveOnHomeScreen(args.AppleIDPassword);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Turn on iCloud Photo Library
         * @overrideID Turn on iCloud Photo Library
         *
         * @targetApps Preferences
         *
         * @param {object} args Test arguments
         * @param {string}      [args.AppleID="PERSISTEDAPPLEID"] - Apple ID.  Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         */
        turnOniCloudPhotoLibrary: function turnOniCloudPhotoLibrary(args) {
            args = UIAUtilities.defaults(args, {
                AppleID : 'PERSISTEDAPPLEID',
                AppleIDPassword : 'PERSISTEDAPPLEIDPASSWORD',
            });

            if (args.AppleID === 'PERSISTEDAPPLEID') {
                UIALogger.logMessage('Using the persisted AppleID to create email account');
                args.AppleID = springboard.appleID;
            }

            if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using the persisted AppleID password to create email account');
                args.AppleIDPassword = springboard.appleIDPassword;
            }

            settings.launch();
            try {
                settings.turnOniCloudPhotoLibrary(args.AppleID, args.AppleIDPassword);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
         * Sign in to iMessage with the specified account.
         *
         * @overrideID Sign In To iMessage
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleID="PERSISTEDAPPLEID"] - Apple ID.  Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         * @param {boolean}      [args.passIfAlreadySignedIn=false] - Report pass if already signed in
         */			
        signInToiMessage: function signInToiMessage(args) {
            args = UIAUtilities.defaults(args, {
                AppleID : 'PERSISTEDAPPLEID',
                AppleIDPassword : 'PERSISTEDAPPLEIDPASSWORD',
                passIfAlreadySignedIn : false,
            });

            if (args.AppleID === 'PERSISTEDAPPLEID') {
                args.AppleID = springboard.appleID;
            }

            UIALogger.logMessage('Using the following account: ' + args.AppleID);

            if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                args.AppleIDPassword = springboard.appleIDPassword;
            }

            UIALogger.logMessage('Using the following password: ' + args.AppleIDPassword);

            settings.launch();
            try {
                settings.signInToiMessage(args.AppleID, args.AppleIDPassword, args.passIfAlreadySignedIn);
            } finally {
                settings.returnToTopLevel();
            }

        },
        /**
         * Sign Out iMessage
         *
         * @overrideID Sign Out iMessage
         *
         * @targetApps Preferences
         *
         */
        signOutiMessage: function signOutiMessage(args) {
            args = UIAUtilities.defaults(args, {
            });

            settings.launch();
            try {
                settings.signOutOfiMessage();
            } finally {
                settings.returnToTopLevel();
            }

        },

        /**
         * Sign in to FaceTime with the specified account.
         *
         * @overrideID Sign In To FaceTime
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.AppleID="PERSISTEDAPPLEID"] - Apple ID.  Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
         * @param {string}      [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         * @param {int}         [args.registrationTimeOut=120] - Number of seconds to wait before failing the registration
         */
        signInToFaceTime: function signInToFaceTime(args) {
            args = UIAUtilities.defaults(args, {
                AppleID             : 'PERSISTEDAPPLEID',
                AppleIDPassword     : 'PERSISTEDAPPLEIDPASSWORD',
                registrationTimeOut : 120,
            });

            if (args.AppleID === 'PERSISTEDAPPLEID') {
                args.AppleID = springboard.appleID;
            }

            UIALogger.logMessage('Using the following account: ' + args.AppleID);

            if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                args.AppleIDPassword = springboard.appleIDPassword;
            }

            UIALogger.logMessage('Using the following password: ' + args.AppleIDPassword);

            settings.launch();
            try {
                settings.signInToFaceTime(args.AppleID, args.AppleIDPassword, args.registrationTimeOut);
            } finally {
                settings.returnToTopLevel();
            }

        },

        /**
         * Sign in to iCloud with the specified account.
         *
         * @overrideID Sign In To iCloud
         *
         * @targetApps Preferences
         *
         * @param {object}  args Test arguments
         * @param {string}  [args.AppleID="PERSISTEDAPPLEID"] - Apple ID.  Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
         * @param {string}  [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
         * @param {string}  [args.passIfAlreadySignedIn=false] - true if the test should pass if already signed into the iCloud account.
         * @param {bool}    [args.throwIfAccountAlreadyAdded=true] - Set to true (default) if we want to throw when attempting to add an account that the device is already signed on to.
         * @param {boolean} [args.isHSA=false] - whether or not to enroll in HSA2
         * @param {object}  [args.hsaOptions] - args for hsa enrollment and verification
         * @param {string}  [args.hsaOptions.cdpSemaphoreUUID=null] - Required in order to get hsa2 code from other device in a multi device suite
         * @param {boolean} [args.hsaOptions.getHsa2Code=false]  - If set to true then get hsa2 code from other device part of MD suite
         * @param {boolean} [args.hsaOptions.getHsa2TextCode=false]  - If set to true then get hsa2 sms verification code from other device part of MD suite
         * @param {string}  [args.hsaOptions.hsaCode] - two factor auth code for HSA2
         * @param {boolean} [args.hsaOptions.enrollHsa=false] - whether or not to enroll in HSA2
         * @param {string}  [args.hsaOptions.hsaTrustedNumber] - Phone number to use as trusted number for HSA2 enrollment
         * @param {string}  [args.hsaOptions.hsaCountryCode] - Country code for hsa2 trusted number
         * @param {string}  [args.hsaOptions.hsaVerifyMethod] - One of "Text Message", "Robo Call"
         * @param {string}  [args.hsaOptions.passcode="111111"] - passcode of the device used for enrolling into iCDP.
         * @param {bool}    [args.hsaOptions.useCDPApproval=false] - Optional Whether to opt for approval flow while enrolling into iCDP
         * @param {string}  [args.hsaOptions.deviceName="Device000000"] - Optional device name to choose from list of parent devices to enroll into iCDP for second device
         * @param {string}  [args.hsaOptions.previousPasscode="000000"] - Optional parent device's passcode to enroll into iCDP
         */
        signInToiCloud: function signInToiCloud(args) {
            args = UIAUtilities.defaults(args, {
                AppleID : 'PERSISTEDAPPLEID',
                AppleIDPassword : 'PERSISTEDAPPLEIDPASSWORD',
                passIfAlreadySignedIn: false,
                throwIfAccountAlreadyAdded: true,
                isHSA: false,
                // "hsa" account options
                hsaOptions: {
                    getHsa2Code: false,
                    getHsa2TextCode: false,
                    enrollHsa: false,
                    cdpSemaphoreUUID: null,
                },
            });

            if (args.AppleID === 'PERSISTEDAPPLEID') {
                args.AppleID = springboard.appleID;
            }

            UIALogger.logMessage('Using the following account: ' + args.AppleID);

            if (args.AppleIDPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                args.AppleIDPassword = springboard.appleIDPassword;
            }

            UIALogger.logMessage('Using the following password: ' + args.AppleIDPassword);

            settings.launch();
            try {
                settings.signInToiCloud(args.AppleID, args.AppleIDPassword, args);
            } finally {
                settings.returnToTopLevel();
            }
        },

        /**
        * Sign into iTunes with the specified account
        *
        * @targetApps Preferences
        * @param {object}   args Test arguments
        * @param {string}   [args.AppleID="PERSISTEDAPPLEID"] - Apple ID. Use "PERSISTEDAPPLEID" to retrieve persisted password from Springboard
        * @param {string}   [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] - AppleID password.  Use 'PERSISTEDAPPLEIDPASSWORD' to retrieve persisted password from SpringBoard
        */
        signInToiTunes: function signInToiTunes(args) {
            args = UIAUtilities.defaults(args, {
                AppleID : springboard.appleID,
                AppleIDPassword : springboard.appleIDPassword,
            });

            UIALogger.logMessage('Using the following account: %0'.format(args.AppleID));
            UIALogger.logMessage('Using the following password: %0'.format(args.AppleIDPassword));

            settings.signInToiTunes(args.AppleID, args.AppleIDPassword);
        },

        /**
        * Sign out of iTunes
        *
        * @targetApps Preferences
        */
        signOutOfiTunes: function signOutOfiTunes() {
            settings.signOutOfiTunes();
        },

        /**
         * Simulate location.
         *
         * @targetApps Preferences
         *
         * @param {string}  [args.latitude="48.742361"] String representation of longitude in degrees.
         * @param {string}  [args.longitude="44.536944"] String representation of longitude in degrees.
         */
         simulateLocation: function simulateLocation(args) {
             args = UIAUtilities.defaults(args, {
                                      latitude : "48.742361",
                                      longitude : "44.536944"
                                      });

             settings.launch();

             try {
                 settings.navigateNavigationViews(["Internal Settings", "Location", "Location Simulation"]);

                 var LATITUDE_FIELD = UIAQuery.textFields('Latitude');
                 settings.enterText(LATITUDE_FIELD, args.latitude);

                 var LONGITUDE_FIELD = UIAQuery.textFields('Longitude');
                 settings.enterText(LONGITUDE_FIELD, args.longitude);
             } finally {
                 settings.returnToTopLevel();
             }
         },

        /**
         * Adds a new keyboard type. When tapping on world button in keyboard,
         * new keyboard should appear.
         *
         * @targetApps Preferences
         *
         * @param {object}  args Test arguments
         * @param {string}  [args.language="Arabic"] Language as it appears in the UI.
         *                      (e.g, Arabic, English, Japanese.)
         * @param {string}  [args.type="Arabic"] - Keyboard type as it appears in the UI. If no type
         *                      specified it is assumed that there are no type options for the langague.
         *                      (e.g, QWERTY, AZERTY, Romanji, Pinyin - QWERTY)
         * @param {string}  [args.keyboardID=null] - optional and used to verify the keyboard. If it is not provided the keyboard
         *                      can still be verified using language and type, however options will not be verified unless given an ID.
         *                      The format is the one give by keyboardID().
         *                      (e.g, "zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US", "ja_JP-Kana@sw=Kana-Flick;hw=US")
         * @param {array}   [args.switchOptions=null] - an array containing the name of a switch
         *                      followed by a boolean for the value it should be set to.
         *                      (e.g, ["Flick Only", true] or ["Auto-Capitalization", false, "Predictive", true]).
         * @param {bool}    [args.passOnAlreadyAdded=false] - true if the test should pass if the keyboard already exists. False if not adding it should
         *                      throw an error.
         */
        addKeyboard: function addKeyboard(args) {
            args = UIAUtilities.defaults(args, {
                language : 'Arabic',
                type : 'Arabic (PC)',
                keyboardID: null,
                switchOptions: null,
                passOnAlreadyAdded: false,
            });

            settings.addKeyboard(args.language, args.type, args.keyboardID, args.switchOptions, args.passOnAlreadyAdded);
        },


        /**
         * Adds new keyboard shortcuts
         *
         * @targetApps Preferences
         *
         * @param {object}  args                                - Test arguments
         * @param {string[]}      [args.Shortcuts=["SMPL"]]          - The list of keyboard shortcuts
         * @param {string[]}      [args.Phrases=["SAMPLE PHRASE"]]   - The list of phrase expansion
         */
        addKeyboardShortcuts: function addKeyboardShortcuts(args) {
            args = UIAUtilities.defaults(args, {
                Shortcuts    : ['SMPL',],
                Phrases     : ['SAMPLE PHRASE',],
            });
            settings.addKeyboardShortcuts(args.Shortcuts, args.Phrases);
        },


        /**
         * Modifies an existing keyboard shortcut.  Can choose to modify the shortcut, the phrase expansion, or both
         *
         * @targetApps Preferences
         *
         * @param {object}  args                                            - Test arguments
         * @param {string[]}      [args.Shortcuts=["SMPL"]]                      - The shortcuts
         * @param {string[]}      [args.NewPhrases=["MODIFIED SAMPLE PHRASE"]]   - (Optional) The list of new phrase expansion (may be null)
         * @param {string[]}      [args.NewShortcuts=[null]]                     - (Optional) The list of new shortcuts for the phrase expansion
         *
         */
        modifyKeyboardShortcuts: function modifyKeyboardShortcuts(args) {
            args = UIAUtilities.defaults(args, {
                Shortcut    : ['SMPL',],
                NewPhrase   : ['MODIFIED SAMPLE PHRASE',],
                NewShortcut : [null,],
            });
            settings.modifyKeyboardShortcuts(args.Shortcuts, args.NewPhrases, args.NewShortcuts);
        },


        /**
         * Deletes an existing keyboard shortcut.
         *
         * @targetApps Preferences
         *
         * @param {object}  args                               - Test arguments
         * @param {string[]}    [args.Shortcuts=["SMPL"]]      - The list of keyboard shortcuts to delete
         *
         * @throws if keyboard shortcut is not found
         */
        deleteKeyboardShortcuts: function deleteKeyboardShortcuts(args) {
            args = UIAUtilities.defaults(args, {
                Shortcuts   : ['SMPL',],
            });
            settings.deleteKeyboardShortcuts(args.Shortcuts);
        },

        /**
         * Verify sync for a set of keyboard shortcut-phrase pairs.
         *
         * @targetApps Preferences
         *
         * @param {object}  args                                                        - Test arguments
         * @param {object}      [args.ShortcutPhrasePairs={"SMPL":"SAMPLE PHRASE"}]     - The dictionary of keyboard shortcut-phrase pais to verify sync against
         *
         * @throws if a keyboard shortcut in the set did not sync
         */
        bulkVerifyKeyboardShortcutsSync: function bulkVerifyKeyboardShortcutsSync(args) {
            args = UIAUtilities.defaults(args, {
                ShortcutPhrasePairs   : {"SMPL":"SAMPLE PHRASE"},
            });
            settings.verifyKeyboardShortcutsSync(args.ShortcutPhrasePairs);
        },

        /**
         * Verify sync for a single keyboard shortcut-phrase pair.
         *
         * @targetApps Preferences
         *
         * @param {object}  args                                - Test arguments
         * @param {string}      [args.Shortcut="SMPL"]          - The shortcut
         * @param {string}      [args.Phrase="SAMPLE PHRASE"]   - The phrase expansion
         *
         * @throws if a keyboard shortcut in the set did not sync
         */
        verifyKeyboardShortcutSync: function verifyKeyboardShortcutSync(args) {
            args = UIAUtilities.defaults(args, {
                Shortcut    : "SMPL",
                Phrase      : "SAMPLE PHRASE",
            });
            var pair = {};
            pair[ args.Shortcut ] = args.Phrase;

            settings.verifyKeyboardShortcutsSync(pair);
        },

        /**
         * Verifying deletion of keyboard shortcust by checking the shorcut doesn't exist in the list.
         *
          * @targetApps Preferences
         * @param {object}  args  - Test arguments
         * @param {string[]} [args.shortcuts=["SMPL"]] - The keyboard shortcuts
         */
        verifyKeyboardShortcutsDeleted: function verifyKeyboardShortcutsDeleted(args) {
            args = UIAUtilities.defaults(args, {
                shortcuts: ['SMPL',],
            });
            settings.verifyKeyboardShortcutsDeleted(args.shortcuts);
        },

        /**
         * Enable 24-Hour Time in Date & Time Settings
         *
         * @targetApps Preferences
         *
         * @throws if unable to enable 24-Hour Time
         */
        enable24HourTime: function enable24HourTime() {
            settings.enable24HourTime();
        },

        /**
         * Enable an installed Developer Profile for an app
         *
         * @targetApps Preferences
         *
         * @param {object}  args                                - Test arguments
         * @param {string}      [args.ProfileTitle=""]          - The name of the profile
         *
         * @throws if unable to enable the developer profile
         */
        enableDeveloperProfile: function enableDeveloperProfile(args) {
            args = UIAUtilities.defaults(args, {
                ProfileTitle    : "",
            });

            settings.enableDeveloperProfile(args.ProfileTitle);
        },

        /**
         * Enable WiFi Logging by UI
         *
         * @targetApps Preferences
         *
         * @throws if unable to enable wifi logging
         */
        enableWifiLogging: function enableWifiLogging() {
            settings.enableWifiLoggingByUI();
        },

        /**
         * Sets the language on the device.
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.language="Chinese, Simplified"] Language to set device to.
         *                  String that appears in on device.
         *                  (e.g, French, French (Canada), Chinese, Traditional)
         */
        setDeviceLanguage: function setDeviceLanguage(args) {
            args = UIAUtilities.defaults(args, {
                language : 'Chinese, Simplified',
            });

            settings.setDeviceLanguage(args.language);
        },


        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it by creating a simple iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="111111"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=false] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=false] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=false] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainSimpleICSC: function enableKeychainSimpleICSC(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: [ "{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                item: 'iCloud Keychain',
                isSwitch: true,
                password: 'PERSISTEDAPPLEIDPASSWORD',
                passcode: '111111',
                phonenumber: '5555555555',
                shouldMatchExactly: false,
                switchValue: true,
                isICSC: false,
                isRandom: false,
                isComplex: false,
            });

            UIALogger.logMessage('Enabling iCloud Keychain using simple iCSC from Settings.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },

        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it using a complex iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="111111"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=false] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=false] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=true] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainComplexICSC: function enableKeychainComplexICSC(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                item: 'iCloud Keychain',
                isSwitch: true,
                password: 'PERSISTEDAPPLEIDPASSWORD',
                passcode: '111111',
                phonenumber: '5555555555',
                shouldMatchExactly: false,
                switchValue: true,
                isICSC: false,
                isRandom: false,
                isComplex: true,
            });

            UIALogger.logMessage('Enabling iCloud Keychain using complex iCSC from Settings.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },

        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it using a random iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="111111"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=false] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=true] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=false] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainRandomICSC: function enableKeychainRandomICSC(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                item: 'iCloud Keychain',
                isSwitch: true,
                password: 'PERSISTEDAPPLEIDPASSWORD',
                passcode: '111111',
                phonenumber: '5555555555',
                shouldMatchExactly: false,
                switchValue: true,
                isICSC: false,
                isRandom: true,
                isComplex: false,
            });

            UIALogger.logMessage('Enabling iCloud Keychain using random iCSC from Settings.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },


        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it using a Approve with Simple iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="111111"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=true] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=false] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=false] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainApproveWithSimpleICSC: function enableKeychainApproveWithSimpleICSC(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: [ "{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                item: 'iCloud Keychain',
                isSwitch: true,
                password: 'PERSISTEDAPPLEIDPASSWORD',
                passcode: '111111',
                phonenumber: '5555555555',
                shouldMatchExactly: false,
                switchValue: true,
                isICSC: true,
                isRandom: false,
                isComplex: false,
            });

            UIALogger.logMessage('Enabling iCloud Keychain via "Approve With Security Code" from Settings.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },

        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it using a Approve with Complex iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="PERSISTEDAPPLEIDPASSWORD"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=true] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=false] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=true] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainApproveWithComplexICSC: function enableKeychainApproveWithComplexICSC(args) {
            args = UIAUtilities.defaults(args, {
                navigationViews: ["{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                item: 'iCloud Keychain',
                isSwitch: true,
                password: 'PERSISTEDAPPLEIDPASSWORD',
                passcode: '11111',
                phonenumber: '5555555555',
                shouldMatchExactly: false,
                switchValue: true,
                isICSC: true,
                isRandom: false,
                isComplex: true,
            });

            UIALogger.logMessage('Enabling iCloud Keychain via "Approve With Security Code" from Settings using Complex ICSC.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },

        /**
         * Test follows a navigation-view path in Settings to iCloud Keychain, enables it using a Approve with Random iCSC and deals
         * with an alert window that pops up to sign into the iCloud account.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {array} [args.navigationViews=["iCloud","Keychain"]] - Views to navigate
         * @param {string} [args.item="iCloud Keychain"] - Item that needs to be switched.
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.passcode="111111"] - passcode of the device used for creating a security code.
         * @param {string} [args.phonenumber="5555555555"] - phone number of the device used for initiatibg a circle.
         * @param {boolean} [args.shouldMatchExactly=false] - Should search for items that are equivalent to
         *                                              switchItem (true) or contains switchItem (false)
         * @param {boolean} [args.switchValue=true] - Should switch be on (true) or off (false)?
         * @param {boolean} [args.isICSC=true] - Is this an ICSC approval flow (true) or not (false)?
         * @param {boolean} [args.isRandom=true] - Is the security code random type (true) or not (false)?
         * @param {boolean} [args.isComplex=false] - Is the security code complex type (true) or not (false)?
         */
        enableKeychainApproveWithRandomICSC: function enableKeychainApproveWithRandomICSC(args) {
            args = UIAUtilities.defaults(args, {
                 navigationViews: ["{query: UIAQuery.beginsWith('iCloud')}", "Keychain"],
                 item: 'iCloud Keychain',
                 isSwitch: true,
                 password: 'PERSISTEDAPPLEIDPASSWORD',
                 passcode: '111111',
                 phonenumber: '5555555555',
                 shouldMatchExactly: false,
                 switchValue: true,
                 isICSC: true,
                 isRandom: true,
                 isComplex: false,
            });

            UIALogger.logMessage('Enabling iCloud Keychain via "Approve With Security Code" from Settings using random ICSC.');
            settings.enableKeychainAndConfirmAlert(args.navigationViews, args.item, args.isSwitch, args.password, args.passcode, args.phonenumber, args);
        },



        /**
         * Test handles entering the sms verification code for enabling keychain device using the Approval with Security Code flow.
         *
         * @targetApps Preferences
         *
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sing in alert
         * @param {string} [args.vCode="123456"] - passcode of the device used for creating a security code.
         */
        smsVerificationHandlerKeychain: function smsVerificationHandlerKeychain(args) {
            args = UIAUtilities.defaults(args, {
                password: 'PERSISTEDAPPLEIDPASSWORD',
                vCode: '123456',
            });

            UIALogger.logMessage('Entering sms verification code for "Approve with Security Code" flow.');
            settings.smsVerificationHandlerKeychain(args.password, args.vCode);
        },

        /**
         * Test handles enabling keychain using HSA2 account for second device flow via settings, enrolling into iCDP.
         *
         * @targetApps Preferences
         *
         * @param {string} [args.password="PERSISTEDAPPLEIDPASSWORD"] - iCloud password to enter into the sign in alert
         */
        enableKeychainICDPHandler: function enableKeychainICDPHandler(args) {
            args = UIAUtilities.defaults(args, {
                password: 'PERSISTEDAPPLEIDPASSWORD',
            });

            UIALogger.logMessage('Enabling keychain to enroll into iCDP using HSA2 account.');
            settings.enableKeychainICDP(args.password);
        },

        /**
         * Selects a sound for a specified category/sub-category and verifies that new sound was chosen.
         * You need to pass either soundCategory and sound (i.e. 'Ringtone', 'Cosmic') for verification in main category or
         * soundCategory, sound, section, collection (i.e. 'Ringtone', 'Bell', 'ALERT TONES', 'Classic') for verificattion
         * in sub-category.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {string} [args.soundCategory="Ringtone"] - (Required) Category in 'Sound' menu.
         * @param {string} [args.sound="Cosmic"] - (Required) Sound in a category or section collection.
         * @param {string} [args.section=null] - (Optional) Section in category, e.g. 'ALERT TONES'.
         * @param {string} [args.collection=null] - (Optional) Collection within section, e.g. 'Classic'.
         */
        selectSound: function selectSound(args) {
            args = UIAUtilities.defaults(args, {
                soundCategory: 'Ringtone',
                sound: 'Cosmic',
                section: null,
                collection: null,
            });

            UIALogger.logMessage('Starting test.. Choosing %0 sound in %1 category'.format(args.sound, args.soundCategory));

            settings.selectSound(args.soundCategory, args.sound, args.section, args.collection);
        },

        /**
         * Set up QuickLook logging and internal settings
         * @targetApps Preferences
         */
        setQuickLookDefaults: function setQuickLookDefaults() {
            UIALogger.logMessage("enableBatteryLifeLogging");
            settings.enableBatteryLifeLogging();
            UIALogger.logMessage("enableWifiLogging");
            settings.enableWifiLogging();
            UIALogger.logMessage("enableiTunesStoreLogging");
            settings.enableiTunesStoreLogging();
            UIALogger.logMessage("enableHangTracer");
            settings.enableHangTracer();
            UIALogger.logMessage("run ctlog -g");
            settings.commCenterLogging();
            UIALogger.logMessage("enableCorruptCalendarDBLogging");
            settings.enableCorruptCalendarDBLogging();
            UIALogger.logMessage("disableCompassCalibration");
            settings.disableCompassCalibration();
        },

        /**
         * Navigate to Settings -> General and trigger OTA Software Update if one is available.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {string} [args.build="14A100"] - Destination OS build to compare with currently installed on the device.
         * @param {string} [args.passcode="1221"] - Passcode to input on Software Update page.
         */
        softwareUpdate: function softwareUpdate(args) {
            args = UIAUtilities.defaults(args, {
                build: '14A100',
                passcode: '1221',
            });

            UIALogger.logMessage('Navigating to Settings -> General and trigger OTA Software Update if one is available.');
            settings.softwareUpdate(args.build, args.passcode);
        },

        /**
         * Navigate to Settings -> Calendar and choose calendar belonging to the specified account as the default if available.
         *
         * @targetApps Preferences
         *
         * @param {object} args - Test arguments
         * @param {string} [args.accountName="On My iPad"] - Account name whose calendar to set as default.
         * @param {number} [args.timeout=60] - Number of seconds to wait for "Default Calendar" option.
         */
        chooseDefaultCalendar: function chooseDefaultCalendar(args) {
            args = UIAUtilities.defaults(args, {
                accountName: 'On My iPad',
                // customize timeout since different MS Exchange servers take different time for authentication response
                timeout: 60,
            });

            settings.chooseDefaultCalendarForAccount(args);
        },

        /**
         * Add macOS Server Account.
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.hostname=""] - macOS server hostname
         * @param {string}      [args.username=""] - macOS username
         * @param {string}      [args.password=""] - user password
         */
        addServerAccount: function addServerAccount(args) {
            args = UIAUtilities.defaults(args, {
                hostname : null,
                username : null,
                password : null,
            });

            settings.launch();
            try {
                settings.addMacOSServerAccount(args.hostname, args.username, args.password);
            } finally {
                settings.returnToTopLevel();
            }

        },

        /**
         * Sets the camera record settings
         *
         * @targetApps Preferences
         *
         * @param {object}      args Test arguments
         * @param {string}      [args.recordVideoSetting=null] - Which video record setting to use: "highest", "lowest", or custom string like "4K at 30 fps"
         * @param {string}      [args.recordSlomoSetting=null] - Which slo-mo record setting to use: "highest", "lowest", or custom string like "720p HD at 240 fps"
         */
        setCameraSettings: function setCameraSettings(args) {
            args = UIAUtilities.defaults(args, {
                recordVideoSetting: null,
                recordSlomoSetting: null,
            });

            settings.launch();
            settings.setRecordSettings(args);
        },

        /**
         * Check the auto-lock is invoked after the devices default auto-lock timeout period elapses
         *     
         * @targetApps Preferences
         *     
         */
        checkAutolock: function checkAutolock() {
            var timeout = settings.setDefaultAutoLockTimeout();
            var screenIsLocked = settings.verifyAutoLockTimeout(timeout);

            if (screenIsLocked == false) {
                throw new UIAError("Failed to invoke screen auto-lock after %0 seconds".format(timeout));   
            }
        },

		/**
		* Turns Find My iPhone on/off for the current iCloud account based
		* on specified options.
		*
		* @param {object} args
		* @param {string} [args.password="password"] -  Password for iCloud account
		* @param {boolean} [args.FMiPState=false] -  Find My iPhone on/off
		*
		* @returns none
		*/
		switchFMiPOnOff: function switchFMiPOnOff(args) {
		    args = UIAUtilities.defaults(args, {
		        password: null,
		        FMiPState: null,
		    });
			
			settings.switchFMiPOnOff(args);
		},
  
        /**
        * Allows USB Accessories access when locked with passcode
        *
        * @targetApps Preferences
        *
        * @param {object} args - Test arguments
        * @param {string} [args.passcode="1221"] - Passcode to input on Passcode page
        */
        allowUSBAccessoriesAccess: function allowUSBAccessoriesAccess(args) {
            args = UIAUtilities.defaults(args, {
                passcode: null,
            });

            settings.allowUSBAccessoriesAccess(args.passcode);
        },
	}
}		
