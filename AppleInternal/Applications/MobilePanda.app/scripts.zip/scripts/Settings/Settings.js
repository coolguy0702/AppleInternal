load('UIAApp.js');
load('SpringBoard.js');

if (typeof settings === 'undefined') {
    /**
        @namespace
        @augments UIAApp
    */
    var settings = target.appWithBundleID('com.apple.Preferences');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Settings Localized String Constants                                 */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*      To abstract the localized string constants for Maps                    */
/*                                                                             */
/*******************************************************************************/

LocStrings.Settings = {
    DATE_AND_TIME:
            // Date & Time
            target.localizedString('DATE_TIME_TITLE', {
                tableName:'Date & Time',
                bundlePath:'/System/Library/PrivateFrameworks/Settings/GeneralSettingsUI.framework'}),

    GENERAL:
            // General
           target.localizedString("General", {
                tableName:"Settings",
                bundlePath:"/System/Library/PrivateFrameworks/PreferencesUI.framework"}),

    KEYBOARD:
            // Keyboard
            target.localizedString("Keyboard", {
                tableName:"Keyboard",
                bundlePath:"/System/Library/PreferenceBundles/KeyboardSettings.bundle"}),

    KEYBOARDS_SETTINGS_TITLE:
            // Keyboards
            target.localizedString("KEYBOARDS", {
                tableName:"Keyboard",
                bundlePath:"/System/Library/PreferenceBundles/KeyboardSettings.bundle"}),

    KEYBOARD_LISTVIEW_TITLE:
            // Keyboards
            target.localizedString("KEYBOARDS_SHORT", {
                tableName:"Keyboard",
                bundlePath:"/System/Library/PreferenceBundles/KeyboardSettings.bundle"}),

    AUTOCORRECTION:
            // Auto-Correction
            target.localizedString("Auto-Correction", {
                tableName:"Keyboard",
                bundlePath:"/System/Library/PreferenceBundles/KeyboardSettings.bundle"}),

    RESET:
            // Reset
            target.localizedString("Reset", {
                tableName:"Localizable",
                bundlePath:"/Applications/Preferences.app"}),

    RESET_KEYBOARD_DICTIONARY_LABEL:
            // Reset Keyboard Dictionary
            target.localizedString("RESET_KEYBOARD_DICTIONARY_LABEL", {
                tableName:"Reset",
                bundlePath:"/System/Library/PrivateFrameworks/PreferencesUI.framework"}),

    RESET_KEYBOARD_DICTIONARY_TITLE:
            // Reset Dictionary
            target.localizedString("RESET_KEYBOARD_DICTIONARY_TITLE", {
                tableName:"Reset",
                bundlePath:"/System/Library/PrivateFrameworks/PreferencesUI.framework"}),

    TWENTY_FOUR_HOUR_TIME:
            // 24-Hour Time
            target.localizedString('24-Hour Time', {
                tableName:'Date & Time',
                bundlePath:'/System/Library/PrivateFrameworks/Settings/GeneralSettingsUI.framework'}),
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.Settings = {
    /** 'Sign in to iCloud' table cell */
    ICLOUD_TABLE_CELL: UIAQuery.tableCells().andThen(UIAQuery.beginsWith('Sign in to your iP'))
                               .orElse(UIAQuery.staticTexts('Apple ID, iCloud, iTunes & App Store')),

    /** 'iCloud Photo Library' button inside 'iCloud'->'Photos' */
    HYPERION_LIBRARY_TOGGLE: UIAQuery.switches("iCloud Photo Library").orElse(UIAQuery.switches("iCloud Photo Library (Beta)")),

    /** Keyboard selection page */
    KEYBOARDS_PAGE: UIAQuery.navigationBars().andThen(UIAQuery.staticTexts('Keyboards')),

    /** two factor authentication dismiss */
    TWO_FACTOR_AUTH: UIAQuery.buttons().withPredicate('name ==[c] "Don\'t use two-factor authentication"'),

    /** Enter current device passcode for enrolling to iCDP */
    ENTER_DEVICE_PASSCODE: UIAQuery.contains('Your passcode will be used to confirm your identity when signing in to iCloud on a new device.'),

    /** Enter other device passcode for enrolling to iCDP */
    ENTER_OTHER_DEVICE_PASSCODE: UIAQuery.contains('Your account and data are protected by the passcode for'),

    /** 'Turn Passcode On' element */
    TURN_ON_PASSCODE: UIAQuery.contains('Turn Passcode On'),

    /** 'Turn Passcode Off' element */
    TURN_OFF_PASSCODE: UIAQuery.contains('Turn Passcode Off'),

    /** 'Change Passcode' element */
    CHANGE_PASSCODE: UIAQuery.query('Change Passcode'),

    /** What is your dream job? */
    DREAM_JOB: UIAQuery.contains('What is your dream job?'),

    /** What was the first name of your first boss? */
    FIRST_BOSS: UIAQuery.contains('What was the first name of your first boss?'),

    /** What is the name of the first beach you visited? */
    FIRST_BEACH: UIAQuery.contains('What is the name of the first beach you visited?'),

    /** What is the name of your best friend in high school? */
    HIGHSCHOOL_BEST_FRIEND: UIAQuery.contains('What is the first name of your best friend in high school?'),

    /** In what city did your parents meet? */
    PARENTS_CITY_MEET: UIAQuery.contains('In what city did your parents meet?'),

    /** Choose a Question */
    CHOOSE_QUESTION: UIAQuery.contains('Choose a Question'),

    /** Answer security question */
    ENTER_ANSWER: UIAQuery.textFields('Enter an answer'),

    /** Create a new Apple ID */
    CREATE_NEW_APPLEID: UIAQuery.contains('Create a new Apple ID'),

    /** Apple News */
    APPLE_NEWS: UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches()).andThen(UIAQuery.query('Apple News Updates')),

    /** Create a new Apple ID */
    FREE_NEW_APPLEID: UIAQuery.contains('Get a free iCloud email address'),

    /** Terms and Conditions **/
    TERMS_CONDITIONS: UIAQuery.contains('Terms and Conditions'),

    /** Any alert containing 'Apple ID' **/
    APPLE_ID_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Apple ID')),

    /** Any alert containing 'Email Not Valid' **/
    EMAIL_INVALID_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Email Not Valid')),

    /** Any alert containing 'Terms and Conditions' **/
    TERMS_CONDITONS_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Terms and Conditions')),

    /** Any alert containing 'Email Address Taken' **/
    EMAIL_TAKEN_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Email Address Taken')),

    /** Any alert containing 'Find My iPhone Enabled' **/
    FMIP_ENABLED_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Find My iPhone Enabled')),

    /** Agree Button **/
    AGREE: UIAQuery.buttons('Agree'),

    /** Any alert containing 'create new' **/
    CREATE_APPLE_ID_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('You cannot change your iCloud email address after creating it.')),

    /** Apple ID sign in alert **/
    APPLE_ID_SIGNIN_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Apple ID Sign In')),

    /** Apple ID locked alert **/
    APPLE_ID_LOCKED_ALERT: UIAQuery.alerts().andThen(UIAQuery.contains('Apple ID Locked')),

    /** Sign into iTunes button **/
    ITUNES_SIGNIN_BUTTON: UIAQuery.withPredicate("name == 'Sign In' AND interactionEnabled == TRUE").isVisible().isEnabled(),

    /** Sign out of iTunes button **/
    ITUNES_SIGNOUT_BUTTON: UIAQuery.withPredicate("name == 'Sign Out' AND interactionEnabled == TRUE").isVisible().isEnabled(),

    /** Cancel signing intoout of iTunes button **/
    ITUNES_CANCEL_BUTTON: UIAQuery.withPredicate("name == 'Cancel' AND interactionEnabled == TRUE").isVisible().isEnabled(),

    /** Already signed into iTunes **/
    ITUNES_SIGNED_IN: UIAQuery.withPredicate("name beginsWith 'Apple ID' AND interactionEnabled == TRUE").isVisible().isEnabled(),

    /** The right-most visible tableView **/
    VISIBLE_RIGHT_TABLE: UIAQuery.RIGHT_TABLE.isVisible().orElse(UIAQuery.tableViews().isVisible().rightmost()),

    /** The right-most visible tableView **/
    VISIBLE_LEFT_TABLE: UIAQuery.LEFT_TABLE.isVisible().orElse(UIAQuery.tableViews().isVisible().leftmost()),

    /** The highest camera FPS setting for Record Video and Record Slo-mo **/
    HIGHEST_CAMERA_FPS_SETTING: UIAQuery.tableCells().contains('fps').last(),

    /** The lowest camera FPS setting for Record Video and Record Slo-mo **/
    LOWEST_CAMERA_FPS_SETTING: UIAQuery.tableCells().contains('fps').first(),

    /** Used for the the "Sounds" tableCell and "Sounds & Haptics" tableCell **/
    SOUNDS: UIAQuery.beginsWith('Sounds'),

    /** Control Center Options **/
    CONTROL_CENTER: UIAQuery.staticTexts('Control Center'),

    /** Used to customize options in Control Center **/
    CONTROL_CENTER_CUSTOMIZE: UIAQuery.staticTexts('Customize Controls'),

    /** Insert Screen Recording to Control Center **/
    INSERT_SCREEN_RECORDING: UIAQuery.buttons('Insert Screen Recording'),

    /** Current Region button **/
    REGION_BUTTON: UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells("Region")),

};

var Settings = {};
Settings.CONSTANTS = {
    PASSWORDS_AND_ACCOUNTS: {query: UIAQuery.tableCells().contains('Accounts').contains('Passwords')},
};


/**
 * Ensures that an item is checked in Settings
 *
 * @param {array}   views    - Array of query-compatible views to be passed to navigateNavigationViews()
 * @param {string}  item     - Query-compatible item to check
 * @param {boolean} validate - Should we validate that a checkmark appeared?
 *
 * @throws if item cannot be navigated to, checked, or verified
 */
settings.chooseCheckmarkedItem = function chooseCheckmarkedItem(views, item, validate) {
    if (!settings.navigateNavigationViews(views)) {
        throw new UIAError("Failed to navigate settings");
    }

    UIALogger.logMessage('Choosing ' + item);
    if (!settings.chooseSetting(item)) {
        throw new UIAError("Failed to choose item");
    }

    if (validate) {
        if (!settings.isMarkedWithCheckmark(item)) {
            throw new UIAError('Failed to mark item with checkmark');
        }
    }
}


/**
 * Change the value of 'Location Sevices' to the value want
 *
 * @param {boolean} value - Turn switch on if value is truthy, otherwise off
 *
 * @throws if item cannot be navigated to or set
 */
settings.changeLocationServiceSwitch = function changeLocationServiceSwitch(value) {
    var LOCATION_TURN_OFF_ALERT = UIAQuery.staticTexts().withPredicate('name contains "Location Services will be disabled"');
    this.handlingAlertsInline(LOCATION_TURN_OFF_ALERT, function() {
        var alertAppeared = UIAWaiter.waiter('Alert');
        settings.changeSingleSwitch(["Privacy", "Location Services"], "Location Services", value, false);
        if (alertAppeared.wait(5)){
            settings.tap('Turn Off');
        }
    });
}

/**
 * Ensures that a switch has (or can be set to) a specified setting
 *
 * @param {array}   views - Array of query-compatible views to be passed to navigateNavigationViews()
 * @param {string}  item  - Query-compatible switch to set
 * @param {boolean} value - Turn switch on if value is truthy, otherwise off
 *
 * @returns {boolean} - true if switch state changed, false otherwise
 *
 * @throws if item cannot be navigated to or set
 */
settings.changeSingleSwitch = function changeSingleSwitch(views, item, value, shouldMatchExactly) {
    var stateChanged = false;
    let itemQuery = UIAQuery.switches(item);
    if (!this.navigateNavigationViews(views)) {
        throw new UIAError('Failed to navigate settings');
    }

    if (!this.exists(itemQuery)) {
        UIALogger.logWarning('Navigated to desired location but switch does not exist. Taking stack shot.');
        target.stackshot();

        if (this.waitUntilPresent(itemQuery, 3)) {
            throw new UIAError('Switch did not appear. Did we navigate to the correct location?');
        }
    }

    if (this.getSwitchState(itemQuery) !== value) {
        if (!this.setSwitchSetting(item, value, shouldMatchExactly)) {
            throw new UIAError('Failed to set switch');
        }
        stateChanged = true;
    } else {
        UIALogger.logMessage('No need to do anything');
    }

    return stateChanged;
}

/**
 * Query iCloudLoad for an auth code for this account
 *
 * @param {string}  username - The account userid
 * @param {string}  password - The account password
 * @param {string}  url - Where we can reach the iCloudLoad service
 */
settings.getHsa2CodeFromiCloudLoad = function getHsa2CodeFromiCloudLoad(options)
{
    // do defaults
    options = UIAUtilities.defaults(options, {
        url: 'https://spectrum-icloudload-staging.apple.com:5000/', // not yet available in production
    });

    // real simple query
    var requestArgs = {};
    var postData = {
        username: options.username,
        password: options.password,
    };
    requestArgs.curlArgs = ['-k', '-d', JSON.stringify(postData)];
    var iclResponse = UIAUtilities.httpQueryUrl(options.url + "/verify", requestArgs);
    if (!iclResponse.success) {
        throw new UIAError('Unable to query iCloudLoad for HSA code: %0'.format(iclResponse.responseText));
    }
    UIALogger.logMessage('iCloudLoad response: %0'.format(iclResponse.responseText));

    var iclData = JSON.parse(iclResponse.responseText);
    return iclData['verification_code'];
}

/**
 * Choose the parent device to enter passcode for to enroll into iCDP
 * @param {null|string} [deviceName=["Device1"]] - Optional previous device name to choose for entering passcode
 * @param [boolean] [useCDPApproval=false] - Optional do we want approval method for enrolling into the iCDP
 * @throws if parent device name not provided when not choosing approval.
 */
settings.chooseCDPDevice = function chooseCDPDevice(deviceName, useCDPApproval) {
    if (useCDPApproval) {
        // Wait for the approval to finish on first previously logged in device.
        // This is work in progress <rdar://problem/22427013> Modify UIA2 Setup script to enable keychain iCDP via applicant flow.
        this.tap(UIAQuery.buttons('Approve from Another Device'));
        return false;
    } else if (!deviceName && !useCDPApproval) {
        throw new UIAError('Must provide parent device name.');
    } else {
        var cell_device = UIAQuery.tableCells().withPredicate("ANY children.name == '%0'".format(deviceName));

        if (!this.exists(cell_device)) {
            UIALogger.logError("It looks like the device has never logged into this account previously, can't use the passcode to enroll into iCDP!");
            return false;
        }

        this.tap(cell_device);
        return true;
    }
}


/**
 * Sets the notification style to None, Permanent, or Temporary.
 *
 * @param {string}  app   - Query-compatible app name
 * @param {string}  style - "None", "Permanent", or "Temporary"
 * @param {boolean} value - Show in Notification Center if value is truthy
 * @param {array} appSubView - List of additional views to navigate to get to notification dialog
 *
 * @throws if app notification settings cannot be navigated to or set
 */
settings.setNotification = function setNotification(app, style, value, appSubView) {
    appSubView = (appSubView === undefined) ? [] : appSubView;

    if (typeof style === 'string') {
        var validStyles = ['None', 'Permanent', 'Temporary'];
        if (validStyles.indexOf(style) === -1) {
            throw new UIAError('Style not one of ' + validStyles.join(', '));
        }
    }

    var views = ['Notifications', app];
    if (!settings.navigateNavigationViews(views)) {
        throw new UIAError("Failed to navigate settings");
    }

    if (!settings.setSwitchSetting('Allow Notifications', value)) {
        throw new UIAError("Failed to set switch");
    }

    // Calendar has notification views that are further down the tree
    for (var i=0; i<appSubView.length; i++) { views.push(appSubView[i]); }
    if (appSubView.length > 0  && !settings.navigateNavigationViews(views)) {
        throw new UIAError("Failed to navigate settings");
    }

    var currentStyle = settings.inspectElementKey('Select notification style', 'value');
    if (currentStyle) {
        UIALogger.logMessage('Current notification style: ' + currentStyle);
    } else {
        UIALogger.logMessage('No current notification style?');
    }

    var isToggled = settings.inspectElementKey(UIAQuery.switches('Show as Banners'), 'value') === '1';
    if(style === 'None') {
        if(isToggled) {
            settings.tap(UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches('Show as Banners')));
        }
    }
    else {
        if(!isToggled) {
            settings.tap(UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches('Show as Banners')));
        }

        if (!settings.waitUntilPresent(UIAQuery.buttons(style))) {
            throw new UIAError("'%0' button never appeared".format(style));
        }
        var newStyle = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.buttons(style));
        settings.tap(newStyle);
    }
}

/**
 * Ensures that the build matches what we expect
 *
 * @param {string}  targetBuild - Build that we expect to find in Settings
 *
 * @throws if build version cannot be navigated to or matched
 */
settings.checkBuild = function checkBuild(targetBuild) {
    if (!settings.navigateNavigationViews(['General', 'About'])) {
        throw new UIAError('Could not get to General -> About');
    }

    var version;
    var versionQuery = UIAQuery.RIGHT_TABLE.andThen('Version');
    if (!(version = settings.inspect(versionQuery).value)) {
        throw new UIAError('Could not find Version in Settings');
    }

    if (version.indexOf(targetBuild) === -1) {
        throw new UIAError('Could not find target build in version string');
    } else {
        UIALogger.logMessage('Target build "' + targetBuild + '" found in version "' + version + '"');
    }
}

/**
 * Sets wallpaper to photo from album
 *
 * @param {string} album - Name of album to pick photo from
 * @param {number} index - Index of photo to pick from album
 *                         If index === null, pick a random index
 *
 * @throws if wallpaper cannot be navigated to or set
 */
settings.setWallpaper = function setWallpaper(album, index) {
    var views = ['Wallpaper'];
    if (!settings.navigateNavigationViews(views)) {
        throw new UIAError('Could not navigate to "Chose a New Wallpaper"');
    }

    //<rdar://problem/21222796> 13A269: Race between "Still photo wallpapers" and choosing the photo
    this.waitForViewToAppear('navigationItemTitle == "Choose"', 5, function () {
        settings.tap('Choose a New Wallpaper');
    });

    if (!album) {
        throw new UIAError('Must specify album to choose photo from');
    }

    this.tap(UIAQuery.RIGHT_TABLE.andThen(album));
    var photos = UIAQuery.RIGHT_COLLECTION_VIEW.andThen(UIAQuery.tableCells());

    if (index === null) {
        index = UIAUtilities.randomInt(0, this.count(photos)-1);
        UIALogger.logMessage('Picked random index ' + index);
    }

    var photo = photos.atIndex(index);
    var info = this.inspect(photo);
    this.waitForViewToAppear('controllerClass == "SBSUIWallpaperPreviewViewController"', function() {
        this.tap(photo);
    });

    if (target.model() !== 'iPad') {
        var set = UIAQuery.buttons().andThen('Set');
        this.tap(set);
    }

    var setBoth = UIAQuery.buttons().andThen('Set Both');
    this.waitForViewToDisappear('controllerClass == "SBSUIWallpaperPreviewViewController"', function() {
        if (!this.waitUntilPresent(setBoth)) {
            throw new UIAError('\'Set Both\' button never appeared');
        }
        this.tap(setBoth);
    });

    if (info.label) {
        UIALogger.logMessage('Set wallpaper to photo "' + info.label + '"');
    } else {
        UIALogger.logMessage('Set wallpaper to photo at index ' + index);
    }
}

/**
 * Sets or changes the device passcode
 *
 * @param {string} newPasscode New passcode to set
 * @param {string} oldPasscode Old passcode if passcode has already been set
 *                             otherwise null
 * @param {object}       options - Options dictionary
 * @param {string}       options.newPasscodeType='' - Numeric or Alphanumeric, if empty, then the new passcode is 4 or 6 digits
 * @throws if passcode controls can't be found or passcode arguments are
 *         malformed
 */
settings.setPasscode = function setPasscode(newPasscode, oldPasscode, options) {
    options = UIAUtilities.defaults(options, {
        newPasscodeType: '',
    });
    function getPasscodeLength() {
        var passcodeQuery = UIAQuery.navigationBars().andThen(UIAQuery.contains('Passcode')).parent().andThen("Passcode");
        if (!settings.waitUntilPresent(passcodeQuery)) {
            throw new UIAError("Passcode field does not exist");
        }
        return parseInt(settings.valueOf(passcodeQuery).match(/^\d+ of (\d+) values entered$/)[1]);
    }

    var validDigit = /^\d{4,6}$/;

    if (!newPasscode) {
        throw new UIAError('Must provide new passcode');
    }

    if (!this.navigateNavigationViews([ {'query': UIAQuery.contains('Passcode')} ]) ) {
        throw new UIAError('Could not navigate to view');
    }

    var iPad = target.model() === 'iPad';

    if (this.exists('Enter Passcode')) {
        if (!oldPasscode) {
            throw new UIAError('Must provide old passcode when passcode is set');
        }

        if (!oldPasscode.match(validDigit)) {
            var oldPasscodeType = 'Custom';
        }
        else {
            var oldPasscodeType = 'NonCustom';
        }

        this.waitForViewToAppear('navigationItemTitle IN {"Passcode Lock", "Touch ID & Passcode", "Face ID & Passcode"}', function() {
            this.typeString(oldPasscode);
            if (oldPasscodeType === 'Custom') {
                this.tap('Done');
            }
        });
    }

    if (this.exists(UIAQuery.Settings.TURN_ON_PASSCODE) && this.inspect(UIAQuery.Settings.TURN_ON_PASSCODE).isEnabled) {
        this.scrollToVisible(UIAQuery.Settings.TURN_ON_PASSCODE);
        this.waitForViewToAppear('navigationItemTitle == "Set Passcode"', function() {
            this.tap(UIAQuery.Settings.TURN_ON_PASSCODE);
        });
    } else if (this.exists(UIAQuery.Settings.CHANGE_PASSCODE) && this.inspect(UIAQuery.Settings.CHANGE_PASSCODE).isEnabled) {
        this.scrollToVisible(UIAQuery.Settings.CHANGE_PASSCODE);
        this.waitForViewToAppear('navigationItemTitle == "Change Passcode"', function() {
            this.tap('Change Passcode');
        });
        if (!iPad) {
            this.waitForViewToAppear('controllerClass == "UICompatibilityInputViewController"', 5, function() {
                this.typeString(oldPasscode);
                if (oldPasscodeType === 'Custom') {
                    this.tap('Next');
                }
            });
        } else {
            this.typeString(oldPasscode);
            if (oldPasscodeType === 'Custom') {
                this.tap('Next');
            }
            target.delay(5);
        }
    } else {
        throw new UIAError('Could not find control to set or change password');
    }

    var passcodeLength = getPasscodeLength();
    var nextPasscode = null;
    if (passcodeLength != newPasscode.length) {
        var passcodeOptionsButton = UIAQuery.buttons("Passcode Options");
        if (this.waitUntilPresent(passcodeOptionsButton, 2)) {
            this.tap(passcodeOptionsButton);

            if (options.newPasscodeType === '') {
                var passwordOption = "%0-Digit Numeric Code".format(newPasscode.length);
            }
            else {
                var passwordOption = "Custom %0 Code".format(options.newPasscodeType);
            }
            var passwordQuery = UIAQuery.buttons(passwordOption);
            if (!this.exists(passwordQuery)) {
                throw new UIAError("Passcode option '%0' is not available".format(passwordOption));
            }
            if (!iPad) {
                this.waitForViewToAppear('controllerClass == "UICompatibilityInputViewController"', 5, function() {
                    this.tap(passwordQuery);
                });
            } else {
                this.tap(passwordQuery);
                target.delay(5);
            }
        }
        else {
            // Creating a temp passcode of
            nextPasscode = newPasscode;
            newPasscode = "1".repeat(passcodeLength);
            UIALogger.logMessage('Setting temp passcode of "%0"'.format(newPasscode));
        }
    }

    var simplePasscodeAlertName = 'This Passcode Can Be';

    var waitForSimplePasscodeAlert = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerTitle contains[c] "%0"'.format(simplePasscodeAlertName)
    );

    this.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.contains(simplePasscodeAlertName)), function() {
        if (!this.waitUntilPresent(UIAQuery.staticTexts('Enter your new passcode').orElse(UIAQuery.staticTexts('Enter a passcode')), 15)) {
            throw new UIAError('Enter passcode screen did not appear on screen');
        }

        this.typeString(newPasscode);
        if (options.newPasscodeType !== '') {
            this.tap('Next');
        }
        if (waitForSimplePasscodeAlert.wait(5)) {
            this.tap(UIAQuery.alerts().andThen(UIAQuery.buttons('Use Anyway')));
            UIALogger.logMessage('Passcode is simple or commonly used, dismissing alert');
        } else {
            UIALogger.logMessage('Passcode is not simple or commonly used, no alert to dismiss');
        }
    });

    this.waitForViewToDisappear('navigationItemTitle IN {"Set Passcode", "Change Passcode"}', 30, function() {
        this.typeString(newPasscode);
        if (options.newPasscodeType !== '') {
            this.tap('Done');
        }
    });

    UIALogger.logPass('Passcode updated.');

    if (nextPasscode) {
        UIALogger.logMessage('Change temp passcode of "%0" to specified passcode "%1"'.format(newPasscode, nextPasscode));
        this.setPasscode(nextPasscode, newPasscode);
    }
}

/**
 * Disables passcode on the device
 *
 * @param {string} passcode Passcode required to disable passcode
 *
 * @throws if passcode controls can't be found or passcode arguments are
 *         malformed
 */
settings.disablePasscode = function disablePasscode(passcode) {
    var validDigit = /^\d{4,6}$/;

    if (!passcode) {
        throw new UIAError('Must provide passcode');
    }

    if (!passcode.match(validDigit)) {
        var passcodeType = 'Custom';
    }
    else {
        var passcodeType = 'NonCustom';
    }

    if (!this.navigateNavigationViews([ {'query': UIAQuery.contains('Passcode')} ])) {
        throw new UIAError('Could not navigate to view');
    }

    if (this.exists('Enter your passcode')) {
        this.waitForViewToAppear('navigationItemTitle IN {"Passcode Lock", "Touch ID & Passcode", "Face ID & Passcode"}', function() {
            this.typeString(passcode);
            if (passcodeType === 'Custom') {
                this.tap('Done');
            }
        });
    }

    if (this.exists(UIAQuery.Settings.TURN_OFF_PASSCODE)) {
        var alertWaiter = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerTitle == "Turn Off Passcode?"'
        );
        var passcodePanelWaiter = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerName == "DevicePINController"'
        );
        this.handlingAlertsInline(UIAQuery.alerts().andThen('Turn Off Passcode?'), function() {
            this.tap(UIAQuery.Settings.TURN_OFF_PASSCODE);

            // Handle "Turn Off Passcode?" alert if it appears
            if (alertWaiter.wait(2)) {
                UIALogger.logMessage('Trying to dismiss "Turn Off Passcode?" alert');
                this.tap(UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Turn Off')));
            }

            // Check if "Enter your passcode" panel appeared
            if (passcodePanelWaiter.wait(2) || this.exists(UIAQuery.navigationBars('Turn Off Passcode'))) {
                UIALogger.logMessage('"Enter your passcode" panel appeared');
                if (target.model() === 'iPad') {
                    this.typeString(passcode);
                    if (passcodeType === 'Custom') {
                        this.tap('Done');
                    }
                    target.delay(10);
                } else {
                    this.waitForViewToAppear('navigationItemTitle IN {"Passcode Lock", "Touch ID & Passcode", "Face ID & Passcode"}', 30, function() {
                        this.typeString(passcode);
                        if (passcodeType === 'Custom') {
                            this.tap('Done');
                        }
                    });
                }
            } else {
                throw new UIAError('"Enter your passcode" panel did not appear');
            }
        });
        UIALogger.logPass('Disabled passcode');
    } else {
        UIALogger.logPass('Passcode already disabled');
    }
}

/**
 * Selects a cell at a given navigation path
 *
 * @param {array|string} path  - Either a single query-compatible item or a path of query-compatible items (for use in navigateNavigationViews())
 * @param {string}       value - true if switch should be set on, false if switch should be set off
 *
 * @returns {boolean} true if switch could be set otherwise false
 */
settings.setSwitchSetting = function setSwitchSetting(path, value, shouldMatchExactly) {
    var item = path instanceof Array ? path.pop() : path;
    if (!item) {
        var error = new UIAError('No item to set specified');
        UIALogger.logError(error);
        return false;
    }

    if (path && path instanceof Array) {
        if (!this.navigateNavigationViews(path)) {
            return false;
        }
    }

    // var current;
    // FIXME: Don't scroll directly to switches:
    // <rdar://problem/18590110> Switches in table cells become scrollable after scrolling to the enclosing table cell in Settings
    var query = shouldMatchExactly ? UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches(item))
                                   : UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches().contains(item));
    this.scrollToVisible(query.parent());

    UIALogger.logMessage("Tapping switch");
    this.setControl(query, value);

    return true;
}

/**
 * Check if we need to tap a switch based on its current value and expected new
 * value
 *
 * @param {int|bool|string} oldValue - Old value of switch
 * @param {bool}            newValue - New expected value of switch
 *
 * @returns {boolean} true if switch should be tapped otherwise false
 */
settings.shouldFlipSwitch = function shouldFlipSwitch(oldValue, newValue) {
    var offValues = [0, false, '0', 'off', 'Off', 'OFF'];
    var onValues = [1, true, '1', 'on', 'On', 'ON'];

    if (offValues.contains(oldValue) && newValue) {
        UIALogger.logMessage('Turning switch on');
        return true;
    } else if (onValues.contains(oldValue) && !newValue) {
        UIALogger.logMessage('Turning switch off');
        return true;
    } else {
        UIALogger.logMessage('Switch already has specified value');
        return false;
    }
}

/**
 * Selects a cell at a given navigation path
 *
 * @param {array|string} path - Either a single query-compatible item or a path of query-compatible items (for use in navigateNavigationViews())
 * @param {object}       options - Options dictionary
 * @param {string}       options.confirmation - Optional Query-compatible item to tap after cell is tapped
 *
 * @returns {boolean} true if setting could be selected otherwise false
 */
settings.chooseSetting = function chooseSetting(path, options) {
    options = options || {};
    var item = path instanceof Array ? path.pop() : path;
    if (!item) {
        var error = new UIAError('No item to set specified');
        UIALogger.logError(error);
        return false;
    }

    if (path && path instanceof Array) {
        if (!this.navigateNavigationViews(path)) {
            return false;
        }
    }

    // the table view we're navigating to may not always be RIGHT_TABLE (as when we're setting the device's region)
    var query = UIAQuery.Settings.VISIBLE_RIGHT_TABLE.andThen(item);

    try {
        if (options.confirmation && target.model() === 'iPad') {
            var confirmation = UIAQuery.alerts().andThen(options.confirmation);
            return this.withAlertHandler(
                function() {
                    var app = target.activeApp();
                    if (app.exists(confirmation)) {
                        app.tap(confirmation);
                        return true;
                    } else {
                        return false;
                    }
                }, function() {
                    this.tap(query);
                    return true;
                }
            );
        } else {
            // language & region settings have tables that are longer than the default limit rdar://problem/22011445
            this.withMaximumSnapshotBreadth(300, (function() {
                try{
                    this.tap(query);
                }
                catch(e){
                    UIALogger.logError(e);
                    this.tap(UIAQuery.Settings.VISIBLE_LEFT_TABLE.andThen(item));
                }
                if (options.confirmation && this.exists(options.confirmation)) {
                    this.tap(options.confirmation);
                }
            }).bind(this));
            return true;
        }
    } catch(e) {
        UIALogger.logError(e);
    }
    return false;
}

/**
 * Sets device environment up for iCloud testing.
 * Will run "killall -9 akd" afterwards for the iCloud environment change to go into effect.
 * Details are available at: {@link https://eightball.apple.com/wiki/index.php/Test_Server_Environment_Information}.
 * iCloud Environment details are available at {@link https://connectme.apple.com/docs/DOC-460721}
 *
 * @param {object} args Test arguments
 * @param {string} iCloudEnvironmentKey - The iCloud X Environment
 */
settings.setiCloudEnvironment = function setiCloudEnvironment(iCloudEnvironmentKey) {
    // The mappings of iCloud environments to IdMS points are defined in https://connectme.apple.com/docs/DOC-460721
    var iCloudEnvironmentMapping = {
        'Production'    : [ 'Reset to Production', ],

        'Internal1'     : [ 'iCloud 1', ],
        'Internal2'     : [ 'iCloud 2', ],
        'Internal3'     : [ 'iCloud 3', ],
        'Internal4'     : [ 'iCloud 4', ],

        'External1'     : [ 'iCloud 1 External', ],
        'External2'     : [ 'iCloud 2 External', ],
        'External3'     : [ 'iCloud 3 External', ],
        'External4'     : [ 'iCloud 4 External', ],
    }

    if (iCloudEnvironmentKey === 'Production') {
        UIALogger.logMessage("Resetting environments to Production...");
        this.chooseSetting([ "Internal Settings", "Server Environments", "Reset All to Production",]);

    } else {
        var mappingKeys = Object.keys(iCloudEnvironmentMapping);
        if (! mappingKeys.contains(iCloudEnvironmentKey)) {
            throw new UIAError("Invalid iCloud Environment Mapping key provided ('%0'); accepted enum keys are %1!".format(iCloudEnvironmentKey, JSON.stringify(mappingKeys)), {identifier:'Invalid iCloud Environment Mapping key'});
        }

        var iCloudEnv   = iCloudEnvironmentMapping[ iCloudEnvironmentKey ][0];

        UIALogger.logMessage("Setting the iCloud environment through Switch...");
        this.chooseSetting([ "Internal Settings", "Server Environments", "iCloud", ]);
        this.waitUntilPresent(UIAQuery.query(iCloudEnv).isVisible().isEnabled());

        this.handlingAlertsInline(UIAQuery.alerts(), function () {
            var alertPoppedUp = UIAWaiter.waiter('Alert');
            this.tap( iCloudEnv );
            alertPoppedUp.wait(3);

            this.waitUntilPresent( UIAQuery.contains('Related Environments') );
            UIALogger.logMessage("Tapping Switch All...");
            target.activeApp().tap('Switch All');
        });
    }

    UIALogger.logMessage("Running killall -9 akd for the iCloud environment changes to go into effect...");
    target.performTask('/usr/bin/killall',["-9", "akd"]);
}

/**
 * Sign in to iMessage with the specified account.
 *
 * @overrideID Sign In To iMessage
 *
 * @param {string} appleID - Apple ID. Defaults to persisted AppleID if none is provided
 * @param {string} password - AppleID password. Defaults to persisted AppleID password if none is provided
 * @param {boolean} passIfAlreadySignedIn - Report pass if already signed in
 */
settings.signInToiMessage = function signInToiMessage(appleID, password, passIfAlreadySignedIn) {
    if (!appleID) {
        UIALogger.logWarning('No Apple ID specified.  Defaulting to persisted Apple ID.');
        appleID = springboard.appleID;
    }

    if (!password) {
        UIALogger.logWarning('No Apple ID password specified.  Defaulting to persisted Apple ID password.');
        password = springboard.appleIDPassword;
    }

    var acceptableTimeout = 60; // seconds
    var SEND_AND_RECEIVE = UIAQuery.query('Send & Receive');
    var USE_APPLE_ID = UIAQuery.query('Use your Apple ID for iMessage');
    var SIGNED_IN_TO_IMESSAGE = UIAQuery.navigationBars().contains('Message').parent().andThen(UIAQuery.textFields('Apple ID'));
    var validationPredicate = "name contains[c] '%0'".format(appleID);
    var iMessageAccount = UIAQuery.staticTexts().withPredicate(validationPredicate).below(
        UIAQuery.query('YOU CAN BE REACHED BY IMESSAGE AT'));
    var USERNAME_FIELD = UIAQuery.textFields('Apple ID');
    var PASSWORD_FIELD = UIAQuery.secureTextFields('Password');
    var IMESSAGE_SWITCH = UIAQuery.switches("iMessage");

    this.returnToTopLevel();
    this.navigateNavigationViews(['Messages']);

    if (this.exists(USERNAME_FIELD) && this.exists(PASSWORD_FIELD)) {
        // This is the iPad code path, where logging in DOES NOT use the alert
        settings.enterText(USERNAME_FIELD, appleID);
        settings.enterText(PASSWORD_FIELD, password);
        settings.tap('Sign In');
        if (!this.waitUntilPresent(SEND_AND_RECEIVE, acceptableTimeout)) {
            throw new UIAError("Sign in did not occur within acceptable timeout");
        }

    } else {
        this.setControl(IMESSAGE_SWITCH, 1);

        // This is the iPhone code path, where we use the alert
        if (!this.waitUntilPresent(USE_APPLE_ID, 2)) {
            if (this.exists(SEND_AND_RECEIVE)) {
                UIALogger.logMessage("iMessage is already enabled with phone number");
                this.tap(SEND_AND_RECEIVE);
            } else {
                throw new UIAError("Could not locate sign in button for iMessage");
            }
        }

        if (!this.waitUntilPresent(USE_APPLE_ID, 5)) {
            if (!passIfAlreadySignedIn)
                throw new UIAError("Could not find Use Apple ID button, possibly already signed in");
            else {
                UIALogger.logMessage("Looks like iMessage has already been signed in");
                return;
            }
        }

        this.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.secureTextFields()), function() {
            var alertAppeared = UIAWaiter.waiter('Alert');
            this.tap(USE_APPLE_ID);
            if (alertAppeared.wait(5)) {
                settings.enterText(UIAQuery.textFields().last(), appleID);
                settings.enterText(UIAQuery.secureTextFields().last(), password);
                settings.tap(UIAQuery.buttons('Sign In'));
                if (!this.waitUntilAbsent(UIAQuery.alerts(), acceptableTimeout)) {
                    throw new UIAError("Sign in did not occur within acceptable timeout");
                }
            } else {
                throw new UIAError('Expected Apple ID iMessage Sign-In alert to appear');
            }
        })
    }

    // If the phone does not have a hot SIM we'll need to go into
    // the Send & Receive menu manually
    this.tapIfExists(SEND_AND_RECEIVE);

    if (!this.waitUntilPresent(iMessageAccount, 60)) {
        throw new UIAError('Account not added to iMessage');
    }
}


/**
 * Sign in to iTunes with the specified account.
 *
 * @param {string} appleID - Apple ID.
 * @param {string} password - AppleID password.
 *
 */
settings.signInToiTunes = function signInToiTunes(appleID, password) {
    if (!appleID) {
        UIALogger.logWarning('No Apple ID specified. Defaulting to persisted Apple ID.');
        appleID = springboard.appleID;
    }

    if (!password) {
        UIALogger.logWarning('No Apple ID password specified. Defaulting to persisted Apple ID password.');
        password = springboard.appleIDPassword;
    }

    // handle the Apple ID signin alert
    settings.handlingAlertsInline(UIAQuery.Settings.APPLE_ID_SIGNIN_ALERT, function () {
        if (!settings.navigateNavigationViews(['iTunes & App Store'])) {
            throw new UIAError('Could not navigate to iTunes & App Store');
        }

        if (settings.exists(UIAQuery.Settings.ITUNES_SIGNED_IN)) {
            UIALogger.logMessage("iTunes is already signed in");
        }
        else {
            if (!settings.tapIfExists(UIAQuery.Settings.ITUNES_SIGNIN_BUTTON)) {
                throw new UIAError("Could not tap the 'Sign In' table cell");
            }

            if (!settings.waitUntilPresent(UIAQuery.Settings.APPLE_ID_SIGNIN_ALERT, 5)) {
                throw new UIAError("Apple ID sign in alert did not appear");
            }

            settings.enterText(UIAQuery.textFields().topmost(), appleID);
            settings.enterText(UIAQuery.secureTextFields().bottommost(), password);

            // handle the Apple ID locked alert
            settings.handlingAlertsInline(UIAQuery.Settings.APPLE_ID_LOCKED_ALERT, function () {
                settings.tap(UIAQuery.Settings.ITUNES_SIGNIN_BUTTON);

                if (settings.waitUntilPresent(UIAQuery.Settings.APPLE_ID_LOCKED_ALERT, 5)) {
                    settings.tap(UIAQuery.Settings.ITUNES_CANCEL_BUTTON);
                    throw new UIAError("AppleID '%0' is locked".format(appleID));
                }
            });

            if (!settings.waitUntilAbsent(UIAQuery.Settings.APPLE_ID_SIGNIN_ALERT, 5)) {
                settings.tap(UIAQuery.Settings.ITUNES_CANCEL_BUTTON);
                throw new UIAError("Sign in failed for AppleID '%0'. iTunes sign in alert did not disappear after sign in attempt.".format(appleID));
            }
        }
    });
}

/**
 * Sign out of iTunes.
 */
settings.signOutOfiTunes = function signOutOfiTunes () {
    UIALogger.logDebug("Signing out of iTunes and App store");
    this.handlingAlertsInline(UIAQuery.Settings.APPLE_ID_ALERT, function () {
        if (!settings.navigateNavigationViews(['iTunes & App Store'])) {
            throw new UIAError('Could not navigate to iTunes & App Store');
        }

        if (!settings.exists(UIAQuery.Settings.ITUNES_SIGNED_IN)) {
            UIALogger.logMessage("No account is signed in to iTunes");
        }
        else {
            if (!settings.tapIfExists(UIAQuery.Settings.ITUNES_SIGNED_IN)) {
                throw new UIAError("Could not tap the Apple ID button to sign out");
            }

            if (!settings.waitUntilPresent(UIAQuery.Settings.APPLE_ID_ALERT, 5)) {
                throw new UIAError("Apple ID sign out alert did not appear");
            }

            if (!settings.tapIfExists(UIAQuery.Settings.ITUNES_SIGNOUT_BUTTON)) {
                throw new UIAError("Could not tap Sign Out button");
            }

            if (!settings.waitUntilAbsent(UIAQuery.Settings.APPLE_ID_ALERT, 5)) {
                settings.tap(UIAQuery.Settings.ITUNES_CANCEL_BUTTON);
                throw new UIAError("Apple ID prompt did not disappear");
            }

            if (!settings.waitUntilAbsent(UIAQuery.Settings.ITUNES_SIGNED_IN, 30)) {
                throw new UIAError("Sign out was not successful");
            }
        }
    });
}

settings.signOutOfiMessage = function signOutOfiMessage() {
    var IMESSAGE_ACCOUNT_ALERT = UIAQuery.query('iMessage Account');
    var SEND_AND_RECEIVE = UIAQuery.query('Send & Receive');
    var USE_APPLE_ID = UIAQuery.query('Use your Apple ID for iMessage');
    var APPLE_ID_CELL = UIAQuery.tableCells('Apple ID:');
    var SIGN_IN_TO_IMESSAGE = UIAQuery.navigationBars().contains('Message').parent().andThen(UIAQuery.textFields('Apple ID'));

    this.returnToTopLevel();
    this.navigateNavigationViews(['Messages']);

    if (this.exists(SIGN_IN_TO_IMESSAGE)) {
        throw new UIAError('Already signed out.');
    }

    this.tap(SEND_AND_RECEIVE);
    this.assertExists(APPLE_ID_CELL, "Could not find account name field, may not be logged in.");
    this.tap(APPLE_ID_CELL);

    this.handlingAlertsInline(IMESSAGE_ACCOUNT_ALERT, function() {
        var signoutButton = UIAQuery.buttons('Sign Out');
        if (this.waitUntilPresent(signoutButton)) {
            this.tap(signoutButton);
        }
    });

    if (!this.waitUntilPresent(USE_APPLE_ID, 5)) {
        // Possible on iPad, so let's check for Sign In button
        if (!this.exists('Sign In') && !this.exists('Use your Apple ID for iMessage')) {
            throw new UIAError('Failed to sign out of iMessage');
        }
    }
}

/**
 * Turns on iCloud Drive
 *
 * @param {object} args Test arguments
 * @param {string} appleIDPassword - AppleID password
 */
settings.turnOniCloudDrive = function turnOniCloudDrive(appleIDPassword) {
    this.navigateNavigationViews(['iCloud',]);

    if (this.exists(UIAQuery.query('Sign In'))) {
        throw new UIAError("Can't set iCloud Drive because we're not signed into iCloud!", {identifier: 'Not signed into iCloud'});
    }

    var iCloudDriveCell = UIAQuery.tableCells("iCloud Drive");
    this.assertExists(iCloudDriveCell);
    if (this.inspect(iCloudDriveCell).value.match(/ON/i)) {
        UIALogger.logMessage("It looks like iCloud Drive is already turned on! Skipping setting iCloud Drive");
        return;
    }

    this.tap(iCloudDriveCell);

    var iCloudDriveUpgradeButton = UIAQuery.beginsWith("Upgrade to").isVisible();
    var iCloudDriveToggleSwitch = UIAQuery.switches().beginsWith("iCloud Drive").isVisible();
    this.waitUntilPresent(iCloudDriveUpgradeButton.orElse(iCloudDriveToggleSwitch), 30);

    if (this.exists(iCloudDriveUpgradeButton)) {
        UIALogger.logMessage("Upgrading iCloud Drive for the first time...");
        var confirmUpgrade = UIAQuery.contains('Upgrading to iCloud Drive');
        this.handlingAlertsInline(confirmUpgrade, function () {
            this.tap( iCloudDriveUpgradeButton );
            this.waitUntilPresent(confirmUpgrade);
            UIALogger.logMessage("Tapping continue...");
            target.activeApp().tap('Continue');
        });

    } else if (this.exists(iCloudDriveToggleSwitch)) {
        UIALogger.logMessage("It looks like the account has upgraded to iCloud Drive already, but iCloud Drive is currently disabled; re-enabling iCloud Drive...");
        this.tap( iCloudDriveToggleSwitch );

    } else throw new UIAError("Could not find the Upgrade to iCloud Drive button nor the iCloud Drive toggle switch!", {identifier: "Could not turn on iCloud Drive"});

}

/**
 * Turns off iCloud Drive
 *
 * @param {string} appleIDPassword - AppleID password
 */
settings.turnOffiCloudDrive = function turnOffiCloudDrive(appleIDPassword) {
    if (!this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}])) {
            throw new UIAError("Could not get to user account view.");
    }
    if (!this.exists(UIAQuery.staticTexts("Sign Out"))) {
        throw new UIAError("Not signed into iCloud.");
    }
    this.tap(UIAQuery.tableCells('iCloud'));

    var iCloudDriveCell = UIAQuery.tableCells("iCloud Drive");
    this.scrollToVisible(iCloudDriveCell);
    var cellValue = this.inspectElementKey(iCloudDriveCell, 'value');
    UIALogger.logMessage("The value of the iCloudDriveCell is: %0".format(cellValue));
    if (cellValue === '1') {
        this.tap(iCloudDriveCell);
        var iCloudDriveToggleSwitch = UIAQuery.switches().beginsWith("iCloud Drive").isVisible();
        this.tap(iCloudDriveToggleSwitch);
    } else {
        UIALogger.logMessage("It looks like iCloud Drive is already turned off! Skipping turning off iCloud Drive");
    }
}

/**
 * Turns on Show iCloud drive on Home screen
 *
 * @param {object} args Test arguments
 * @param {string} appleIDPassword - AppleID password
 */
settings.turnOnShowiCloudDriveOnHomeScreen = function turnOnShowiCloudDriveOnHomeScreen(appleIDPassword) {
    this.navigateNavigationViews(['iCloud',]);


    if (this.exists(UIAQuery.withPredicate("name BEGINSWITH 'Sign In'"))) {
        throw new UIAError("Can't set iCloud Show on Home screen because we're not signed into iCloud!", {identifier: 'Not signed into iCloud'});
    }
    var iCloudDriveCell = UIAQuery.tableCells("iCloud Drive");
    this.assertExists(iCloudDriveCell);
    if (this.inspect(iCloudDriveCell).value.match(/ON/i)) {
        this.tap(iCloudDriveCell);
        var iCloudShowOnHomeScreenToggle = UIAQuery.switches().beginsWith("Show on Home Screen").isVisible();
        if (!(this.exists(iCloudShowOnHomeScreenToggle))) {
            throw new UIAError("Could not find the iCloud Show on home screen toggle switch!");
        }

        if (this.inspect(iCloudShowOnHomeScreenToggle).value == 1) {
            UIALogger.logMessage("The iCloud Show on home screen is already turned on!");
            return;
        }
        this.setControl(iCloudShowOnHomeScreenToggle, 1);

    } else throw new UIAError("iCloud Drive is not turned on")

}

/**
 * Turns on iCloud Photo Library (Hyperion)
 *
 * @param {object} args Test arguments
 * @param {string} appleIDPassword - AppleID password
 */
settings.turnOniCloudPhotoLibrary = function turnOniCloudPhotoLibrary(appleIDPassword) {
    this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}]);

    if (this.exists(UIAQuery.withPredicate("name BEGINSWITH 'Sign In'"))) {
        throw new UIAError("Can't set iCloud Photo Library because we're not signed into iCloud!", {identifier: 'Not signed into iCloud'});
    }

    this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}, 'iCloud', 'Photos']);

    if (!(this.exists(UIAQuery.Settings.HYPERION_LIBRARY_TOGGLE))) {
        throw new UIAError("Could not find the iCloud Photo Library toggle switch!", {identifier: "Could not turn on iCloud Photo Library"});
    }

    if (this.inspect(UIAQuery.Settings.HYPERION_LIBRARY_TOGGLE).value == 1) {
        UIALogger.logMessage("It looks like iCloud Photo Library is already turned on! Skipping setting iCloud Photo Library");
        return;
    }

    this.setControl(UIAQuery.Settings.HYPERION_LIBRARY_TOGGLE, 1);
}

/**
 * Verifies that an element has a checkmark (that is, it's selected)
 *
 * @param {string} item - Query-compatible item to look for
 *
 * @returns {boolean} true if element has a checkmark otherwise false
 */
settings.isMarkedWithCheckmark = function isMarkedWithCheckmark(item) {
    // the table view we're validating in may not always be RIGHT_TABLE (as when we're setting the device's region)
    var query = UIAQuery.Settings.VISIBLE_RIGHT_TABLE.andThen(item);
    var isMarked = false;

    // language & region settings have tables that are longer than the default limit rdar://problem/22011445
    this.withMaximumSnapshotBreadth(300, (function() {
        // item may be a child of the cell with only the cell showing the isSelected trait so check both
        isMarked = Boolean(this.exists(query.isSelected().orElse(query.parent().isSelected())));
    }).bind(this));

    return isMarked;
}

/**
 * Disable Compass Calibration
 */
settings.disableCompassCalibration = function disableCompassCalibration() {
    target.performTask('/usr/bin/defaults',["write", "/private/var/mobile/Library/Preferences/com.apple.compass.plist", "CalibrationDisabled", "-bool", "YES"]);
}

/**
 * Disable Group Messaging
 */
settings.disableGroupMessaging = function disableGroupMessaging() {
    target.performTask('/usr/bin/defaults',["write", "/private/var/mobile/Library/Preferences/com.apple.MobileSMS.plist", "MMSGroupModeOverride", "-bool", "NO"]);
}

/**
 *  Enable 24-Hour Time in Date & Time Settings
 *
 */
settings.enable24HourTime = function enable24HourTime() {
    this.launch();
    this.returnToTopLevel();
    this.navigateNavigationViews([LocStrings.Settings.GENERAL, LocStrings.Settings.DATE_AND_TIME]);
    this.setSwitchSetting(LocStrings.Settings.TWENTY_FOUR_HOUR_TIME, true);
}

/**
 * Enable Battery Life Logging
 */
settings.enableBatteryLifeLogging = function enableBatteryLifeLogging() {
    target.performTask('/usr/bin/defaults',["write", "/private/var/mobile/Library/Preferences/com.apple.powerlogd.plist", "FullMode", "-bool", "YES"]);
}

/**
 * Enable Wifi Logging
 */
settings.enableWifiLogging = function enableWifiLogging() {
    target.performTask('/usr/bin/defaults', ["write", "/private/var/mobile/Library/Preferences/com.apple.preferences.plist", "WiFiLogging", "-bool", "YES"]);
}

/**
 * Enable Wifi Logging through the UI
 */
settings.enableWifiLoggingByUI = function enableWifiLoggingByUI() {
    var profileWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'navigationItemTitle == "Install Profile"'
    );
    var warningWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'navigationItemTitle == "Warning"'
    );
    var actionSheetWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass = "UIAlertController"'
    );

    this.chooseCheckmarkedItem(['Internal Settings', 'WiFi', 'Logging Options'], 'Recommended Logging', false);
    if (!profileWaiter.wait(10)) {
        throw new UIAError('Install Profile for WiFi logging did not appear.');
    }

    this.handlingAlertsInline(UIAQuery.contains('Install Profile'), function() {
        this.tap('Install');
        this.tap('Next');

        if (!warningWaiter.wait(10)) {
            throw new UIAError('Warning page for Install Profile for WiFi logging did not appear.');
        }

        this.tap('Install');

        if (!actionSheetWaiter.wait(10)) {
            throw new UIAError('Action sheet/alert confirmation for Install Profile for WiFi logging did not appear.');
        }

        this.tap(UIAQuery.actionSheets().andThen('Install').orElse(UIAQuery.alerts().andThen('Install')));
    });

    this.tap('Done');
}

/**
 * Enable iTunes Store Logging
 */
settings.enableiTunesStoreLogging = function enableiTunesStoreLogging() {
    target.performTask('/usr/bin/defaults', ["write", "/private/var/mobile/Library/Preferences/com.apple.itunesstored.plist", "DebugLevel", "-int", "3"]);
}

/**
 * Enable Hang Tracer
 */
settings.enableHangTracer = function enableHangTracer() {
    target.performTask('/usr/bin/defaults', ["write", "/private/var/mobile/Library/Preferences/.GlobalPreferences.plist", "HangTracerEnabled", "-boolean", "YES"]);
    target.performTask('/usr/bin/defaults', ["write", "com.apple.da", "HangTracerLogLevel", "-int", "3"]);
}

/**
 * CommCenter Logging
 * rdar://problem/20133283
 */
settings.commCenterLogging = function commCenterLogging() {
    target.performTask("/usr/local/bin/ctlog",["-g"]);
}

/**
 * Enable corrupt calendar DB Logging
 * <rdar://problem/17638688>
 */
settings.enableCorruptCalendarDBLogging = function enableCorruptCalendarDBLogging() {
    target.performTask('/usr/bin/defaults', ["write", "-g", "CopyCorruptDatabases", "-bool", "YES"]);
}

/**
 * This will put decrypted logs in to our syslog
 * Restoring the device will undo all of this
 * so this will not affect the device on future testruns
 */
settings.verificationFailedExtraLogging = function verificationFailedExtraLogging() {
    UIALogger.logMessage("Adding additional logging for <rdar://problem/21642198>");

    // This will put CFNETWORK_DIAGNOSTICS=3 in to the environment variable
    // of the process that's writing data to a socket
    target.performTask('/bin/launchctl', ["setenv", "CFNETWORK_DIAGNOSTICS", "3"], 5);

    // Kills the akd process, when starting again the env var change will be reflected
    target.performTask('/usr/bin/killall', ["-9", "akd"], 5);

    // Starts it again
    target.performTask('/usr/local/bin/aktool', ["code"], 5);

    // Adding this logging from email thread
    var aktAni = target.performTask('/usr/local/bin/aktool', ['anisette', "--display"], 5);

    if (aktAni['exitCode'] === 0) {
        UIALogger.logMessage('aktool anisette --display succeeded: (%0)'.format(aktAni['stdout']));
    } else {
        UIALogger.logMessage('aktool anisette --display failed: (%0)'.format(aktAni['stderr']));
    }

    // Verify that the env var is present
    var ps = target.performTask('/bin/ps', ["-ef", "-Ewww"], 5);

    // This is in lieu of grepping the output of ps
    if (ps['exitCode'] === 0) {
        if (ps['stdout'].indexOf("CFNETWORK_DIAGNOSTICS") > -1) {
            UIALogger.logMessage("Additional logging for <rdar://problem/21642198> was successful and env var is present");
        } else {
            UIALogger.logMessage("Additional logging for <rdar://problem/21642198> was successful but env var is not present");
        }
    } else {
        UIALogger.logMessage("Additional logging for <rdar://problem/21642198> failed: (%0)".format(ps['stderr']));
    }

    // Collect the wifi logs for <rdar://problem/24137189> Add additional wifi logging for iCloud Verification issue

    var collectWiFiDebugInfo = target.performTask('/usr/local/bin/collectWiFiDebugInfo.sh', [], 100);

    if (collectWiFiDebugInfo['exitCode'] === 0) {
        UIALogger.logMessage('collectWiFiDebugInfo was successful: %0'.format(collectWiFiDebugInfo['stdout']));
    } else {
        UIALogger.logMessage('collectWiFiDebugInfo failed: %0'.format(collectWiFiDebugInfo['stderr']));
    }
}

/**
 * Adds a new keyboard type. When tapping on world button in keyboard,
 * new keyboard should appear.
 *
 * @param {string} language - Language as it appears in the UI.
 *                      (e.g, Arabic, English, Japanese.)
 * @param {string} type - Keyboard type as it appears in the UI. If no type
 *                      specified it is assumed that there are no type options for the langague.
 *                      (e.g, QWERTY, AZERTY, Romanji, Pinyin - QWERTY)
 * @param {string} keyboardID - optional and used to verify the keyboard. If it is not provided the keyboard
 *                      can still be verified using language and type, however options will not be verified unless given an ID.
 *                      The format is the one give by keyboardID().
 *                      (e.g, "zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US", "ja_JP-Kana@sw=Kana-Flick;hw=US")
 * @param {array} switchOptions - an array containing the name of a switch
 *                      followed by a boolean for the value it should be set to.
 *                      (e.g, ["Flick Only", true] or ["Auto-Capitalization", false, "Predictive", true]).
 * @param {bool} passOnAlreadyAdded - true if the test should pass if the keyboard already exists. False if not adding it should
 *                      throw an error.
 */
settings.addKeyboard = function addKeyboard(language, type, keyboardID, switchOptions, passOnAlreadyAdded) {
    var languageQuery = UIAQuery.tableViews().andThen(UIAQuery.contains(language));
    if (!settings.navigateNavigationViews([LocStrings.Settings.GENERAL,
                                           {query:LocStrings.Settings.KEYBOARD, title:LocStrings.Settings.KEYBOARDS_SETTINGS_TITLE},
                                           {query:LocStrings.Settings.KEYBOARDS_SETTINGS_TITLE, title:LocStrings.Settings.KEYBOARD_LISTVIEW_TITLE}])) {
        throw new UIAError('Could not navigate to \'Keyboards\'');
    }
    if (this.validateKeyboardsExist(false, language, type, keyboardID, switchOptions, passOnAlreadyAdded)) {
        if (passOnAlreadyAdded){
            return true;
        } else {
            throw new UIAError('This keyboard(s) already exist in keyboard list.');
        }
    }
    this.waitForViewToAppear('navigationItemTitle = "Add New Keyboard"', function () {
        this.tap('Add New Keyboard...');
    });
    if (!this.tapIfExists(languageQuery)) {
        throw new UIAError(
            'Language or language ID does not exists within keyboard list. language: \'%0\''
            .format(language)
        );
    }
    if (type && UIAQuery.KEYBOARDS_PAGE != null) {
        throw new UIAError('There is no option for a keyboard type/id for language: \'%0\''.format(language));
    }
    else if (type && UIAQuery.KEYBOARDS_PAGE == null) {
        if (this.tapIfExists(String(type))){

        } else {
            this.tap(languageQuery);
            this.tap(String(type));
        }
    }

    this.tapIfExists('Done');
    if (switchOptions){
        this.changeKeyboardOptions(switchOptions);
    }
    if (!settings.navigateNavigationViews(['General', 'Keyboard', 'Keyboards'])) {
        throw new UIAError('Could not navigate to \'Keyboards\'');
    }
    return this.validateKeyboardsExist(true, language, type, keyboardID, switchOptions, false);
}

/**
 * Changes switches for keyboard options on the keyboards page in settings.
 *
 * @param {array} switchOptions - an array containing the name of a switch
 *                      followed by a boolean for the value it should be set to.
 *                      (e.g, ["Flick Only", true] or ["Auto-Capitalization", false, "Predictive", true]).
 */
settings.changeKeyboardOptions = function changeKeyboardOptions(switchOptions) {
    for (var i = 0; i <= (switchOptions.length / 2); i = i + 2) {
        settings.changeSingleSwitch(["General", "Keyboard"], switchOptions[i], switchOptions[i+1], true);
    }
}

/**
 * Validates if a keyboard has been added to the list of keyboards. This validation can occur using
 * language and type or using a keyboardID.
 *
 * @param {string} language - Language as it appears in the UI.
 *                      (e.g, Arabic, English, Japanese.)
 * @param {string} type - Keyboard type as it appears in the UI. If no type
 *                      specified it is assumed that there are no type options for the langague.
 *                      (e.g, QWERTY, AZERTY, Romanji, Pinyin - QWERTY)
 * @param {string} keyboardID - optional and used to verify the keyboard. If it is not provided the keyboard
 *                      can still be verified using language and type, however options will not be verified unless given an ID.
 *                      The format is the one give by keyboardID().
 *                      (e.g, "zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US", "ja_JP-Kana@sw=Kana-Flick;hw=US")
 * @param {array} switchOptions - an array containing the name of a switch
 *                      followed by a boolean for the value it should be set to.
 *                      (e.g, ["Flick Only", true] or ["Auto-Capitalization", false, "Predictive", true]).
 */
settings.validateKeyboardsExist = function validateKeyboardsExist (throwOnFail, language, type, keyboardID, switchOptions, passOnAlreadyAdded) {
    var foundLanguage = true;
    var languageQuery = UIAQuery.tableViews().andThen(UIAQuery.beginsWith(language));

    if (keyboardID && !passOnAlreadyAdded) {
        if (this.inspect(String(keyboardID)) == null) {
            if (throwOnFail) {
                    throw new UIAError('Keyboard ID: \'%0\' does not appear in keyboard list. Keyboard was not added!.'.format(keyboardID));
            }
            foundLanguage = false;
        }
    } else if (type) {
        if (!settings.exists(languageQuery.andThen(UIAQuery.contains(type)))) {
            if (throwOnFail) {
                throw new UIAError('Language type: \'%0\' does not appear in keyboard list. Keyboard was not added!.'.format(type));
            }
            foundLanguage = false;
        }
    } else {
        if (!this.exists(languageQuery)) {
            if (throwOnFail) {
                throw new UIAError('Language: \'%0\' does not appear in keyboard list. Keyboard was not added!.'.format(language));
            }
           foundLanguage = false;
        }
    }
    return foundLanguage;
}

/**
 * Sets the language on the device.
 *
 * @param {string} language - Language. String that appears in on device.
 *                      (e.g, French, French (Canada), Chinese, Traditional)
 */
settings.setDeviceLanguage = function setDeviceLanguage(language) {
    var deviceLanguage = (target.model() === 'iPad') ? 'iPad Language' : 'iPhone Language';
    var changeQuery = UIAQuery.buttons().beginsWith('Change to').orElse(UIAQuery.buttons('Continue'));

    if (!settings.navigateNavigationViews(['General', 'Language & Region', deviceLanguage])) {
        throw new UIAError('Could not navigate to device \'Language\' setting.');
    }

    UIALogger.logMessage('Setting device language to: \'%0\''.format(language));
    this.tap(language);
    this.handlingAlertsInline(changeQuery, function() {
        this.tap('Done');
        this.tap(changeQuery);
    });
}

/**
 * Sets the region on the device.
 *
 * @param {string} region - Region. String that appears in on device.
 *                      (e.g, France, Canada, China, Taiwan, Japan, United States)
 */
settings.setDeviceRegion = function setDeviceRegion(region) {
    var changeQuery = UIAQuery.buttons().beginsWith('Would you like to change the region').orElse(UIAQuery.buttons('Continue')).orElse(UIAQuery.buttons().beginsWith('Keep'));

    UIALogger.logMessage('Setting device region to: \'%0\''.format(region));
    settings.chooseCheckmarkedItem(["General", "Language & Region", "Region"], region, false);

    this.handlingAlertsInline(changeQuery, function() {
        this.tapIfExists(changeQuery);
    });
    this.tap(UIAQuery.tableCells("Region"));
    if (!settings.isMarkedWithCheckmark(region)) {
            throw new UIAError('Failed to mark item with checkmark');
    }
}

/**
 * Navigates to Keyboard Shortcuts (Settings -> General -> Keyboard -> Shortcuts).  Method used by CAE scripts
 */
settings._goToKeyboardShortcuts = function _goToKeyboardShortcuts() {
    this.navigateNavigationViews([ "General", "Keyboard", "Text Replacement", ]);
}

/**
 * Sets a keyboard shortcut.  Assumes device is currently on Add/Edit Shortcut view (Settings -> General -> Keyboard -> Shortcuts -> Add)
 *
 * @param {string} shortcut         - The shortcut
 * @param {string} phrase           - The phrase expansion
 */
settings._setKeyboardShortcut = function _setKeyboardShortcut(shortcut, phrase) {
    UIALogger.logMessage("Setting the shortcut-phrase pair { \"%0\" : \"%1\" } ...".format(shortcut, phrase));
    if (phrase !== undefined && phrase !== null) {
        this.enterText(UIAQuery.textFields("Phrase"), String(phrase));
    }
    if (shortcut !== undefined && shortcut !== null) {
        this.enterText(UIAQuery.textFields("Shortcut"), String(shortcut));
    }
    this.tap( UIAQuery.navigationBars().andThen("Save") );
}

/**
 * Walks through Settings to add keyboard shortcuts
 *
 * @param {string[]} shortcuts         - The list of keyboard shortcuts
 * @param {string[]} phrases           - The list of phrase expansions
 */
settings.addKeyboardShortcuts = function addKeyboardShortcuts(shortcuts, phrases) {
    this._goToKeyboardShortcuts();
    for (var i=0; i < shortcuts.length; i++) {
        shortcuts[i] = String(shortcuts[i]);
        if (shortcuts[i].contains(" ")) {
            throw new UIAError("Cannot have a space in a shortcut string (got '%0')!".format(shortcuts[i]), {identifier:"Shortcut contains space(s)"});
        }
        this.tap( UIAQuery.navigationBars().andThen("Add") );
        this._setKeyboardShortcut(shortcuts[i], phrases[i]);
        this.dragDownInside(UIAQuery.tableViews().rightmost(), {duration: 1.0}); // Refreshes the shortcut sync
        }
}



/**
 * Walks through Settings to modify an existing keyboard shortcut-phrase pair.  Can choose to modify the shortcut, the phrase expansion, or both
 *
 * @param {string[]}      shortcuts         - The list of shortcuts
 * @param {string[]|null} newPhrases        - (Optional) The new list of phrase expansion
 * @param {string[]|null} newShortcuts      - (Optional) The new list of shortcuts for the phrase expansion
 *
 * @throws if keyboard shortcut is not found
 */
settings.modifyKeyboardShortcuts = function modifyKeyboardShortcuts(shortcuts, newPhrases, newShortcuts) {
    for (var i=0; i < newShortcuts.length; i++) {
        if (newShortcuts[i] !== undefined && newShortcuts[i] !== null && newShortcuts[i].contains(" ")) {
            throw new UIAError("Cannot have a space in a shortcut string (got '%0')!".format(newShortcuts[i]), {identifier:"Shortcut contains space(s)"});
        }
    }
   this._goToKeyboardShortcuts();
    for (var i=0; i < shortcuts.length; i++) {
        var shortcutQuery = UIAQuery.tableCells().andThen( UIAQuery.beginsWith("%0, ".format(shortcuts[i])).orElse("%0".format(shortcuts[i])) ).rightmost(); // First query is for iPhones; second is for iPads
        if (! this.exists(shortcutQuery)) {
            throw new UIAError("Could not find the shortcut '%0'!".format(shortcuts[i]), {identifier:"Keyboard shortcut does not exist"});
        }
        this.tap(shortcutQuery);
        this._setKeyboardShortcut(newShortcuts[i], newPhrases[i]);
    }


}

/**
 * Walks through Settings to delete an existing keyboard shortcut-phrase pair.
 *
 * @param {string[]} shortcuts         - The list of keyboard shortcuts to delete
 *
 * @throws if keyboard shortcut is not found
 */
settings.deleteKeyboardShortcuts = function deleteKeyboardShortcuts(shortcuts) {
    this._goToKeyboardShortcuts();
    this.tap("Edit");

    UIALogger.logMessage("Deleting shortcuts: %0".format(JSON.stringify(shortcuts)));
    var deleteButton = UIAQuery.tableCells().andThen("Delete");
    for (var i=0; i < shortcuts.length; i++) {
        var shortcutQuery = UIAQuery.tableCells().andThen(UIAQuery.beginsWith("Delete %0, ".format(shortcuts[i]))).orElse("%0".format(shortcuts[i])).rightmost();
        if (! this.exists(shortcutQuery)) {
            throw new UIAError("Could not find the shortcut '%0'!".format(shortcuts[i]), {identifier:"Keyboard shortcut does not exist"});

        }
        this.tap(shortcutQuery);
        this.tap(deleteButton);
        this.waitUntilAbsent(deleteButton); // This is necessary to prevent race conditions

        if (this.exists(shortcutQuery)) {
            throw new UIAError("Shorcut still exists: '%0'!".format(shortcuts[i]), {identifier:"Failed to delete keyboard shortcut"});
        }
    }
    this.tap("Done");
}

/**
 * Walks through Settings to collect existing keyboard shortcut-phrase pairs into a map.  Method used by CAE scripts
 *
 * @returns {boolean} a dictionary of shortcut-phrase mappings
 */
settings.getKeyboardShortcutsMap = function getKeyboardShortcutsMap() {
    this._goToKeyboardShortcuts();
    this.dragDownInside(UIAQuery.tableViews().rightmost(), {duration: 1.0}); // Refreshes the shortcut sync

    var shortcutCells = UIAQuery.query("UINavigationTransitionView").rightmost().andThen(UIAQuery.tableCells());
    var cellCount = this.count( shortcutCells );
    var shortcutMap = {};

    // Collect shortcut-phrase pairs into map
    for (var i=0; i < cellCount; i++) {
        this.tap( shortcutCells.atIndex(i) );
        this.waitUntilPresent(UIAQuery.textFields('Phrase'));
        var phrase = this.inspect( UIAQuery.textFields('Phrase') ).value;
        var shortcut = this.inspect( UIAQuery.textFields('Shortcut') ).value;
        shortcutMap[ shortcut ] = phrase;
        this.tap("Save");
    }

    return shortcutMap;
}

/**
 * Verify sync for a set of keyboard shortcut-phrase pairs
 *
 * @param {object} shortcutPhrasePairs         - The dictionary of keyboard shortcut-phrase pais to verify sync against
 *
 * @throws if a keyboard shortcut in the set did not sync
 */
settings.verifyKeyboardShortcutsSync = function verifyKeyboardShortcutsSync(shortcutPhrasePairs) {
    this._goToKeyboardShortcuts();
    errorIdentifier = {identifier:"Keyboard shortcut failed to sync"};

    var shortcuts = Object.keys(shortcutPhrasePairs);
    for (var i in shortcuts) {
        var shortcut = shortcuts[i];
        var phrase = shortcutPhrasePairs[shortcut];

        // The first is for iPhones and the latter two is for iPads
        var combinedShortcutPhraseQuery = UIAQuery.tableCells().andThen( "%0, %1".format(shortcut, phrase) );
        var shortcutQuery               = UIAQuery.tableCells().andThen( "%0".format(shortcut) ).rightmost();
        var phraseQuery                 = UIAQuery.tableCells().andThen( "%0".format(phrase) ).rightmost();

        // Refreshes the shortcut sync
        this.dragDownInside(UIAQuery.tableViews().rightmost(), {duration: 1.0});
        if (!(this.waitUntilPresent(shortcutQuery, 300) && this.waitUntilPresent(phraseQuery, 300))) {
            throw new UIAError("Keyboard shortcut-phrase pair { \"%0\" : \"%1\" } failed to sync!".format(shortcut, phrase), errorIdentifier);
        }

        UIALogger.logMessage("Keyboard shortcut-phrase pair { \"%0\" : \"%1\" } successfully synced!".format(shortcut, phrase));
    }
}

/**
 * Verifying deletion of keyboard shortcut by checking the shortcuts doesn't exist in the list.
 *
 *@param {string[]} shortcuts - The keyboard shortcut
*/
settings.verifyKeyboardShortcutsDeleted = function verifyKeyboardShortcutsDeleted(shortcuts) {
    this._goToKeyboardShortcuts();
    for (var i=0; i < shortcuts.length; i++) {
         var shortcutQuery = UIAQuery.tableCells().andThen( UIAQuery.beginsWith("%0, ".format(shortcuts[i])).orElse("%0".format(shortcuts[i]))).rightmost();
         if (this.exists(shortcutQuery)) {
             throw new UIAError("Shortcut still exists in the list '%0'!".format(shortcuts[i]), {identifier:"Keyboard shortcut still exists"});
         }
    }

}

/**
 * Selects a sound for a specified soundCategory and verifies that new sound was chosen.
 *
 * For verification in main category pass an soundCategory and sound strings, i.e.
 * soundCategory='Ringtone', sound='Cosmic'.
 * For verification in sub-category pass soundCategory, sound, section, collection strings,
 * i.e. soundCategory='Ringtone', sound='Bell', section='ALERT TONES', collection='Classic'.
 *
 * Make sure to provide sounds names as they appear in UI.
 *
 * @param {string} soundCategory - Category in 'Sound' menu.
 * @param {string} sound - Sound in a category or section collection.
 * @param {string|null} section - (Optional) Section in category.
 * @param {string|null} collection - (Optional) Collection within section.
 *
 */
settings.selectSound = function selectSound(soundCategory, sound, section, collection) {
    // Navigating to "Sounds" nav item if exists
    if (!this.navigateNavigationViews([{query: UIAQuery.Settings.SOUNDS}])) {
        throw new UIAError('Could not navigate to Sounds.');
    }

    if (collection && !section) {
        throw new UIAError('Collection provided without section: %0'.format(collection));
    } else if (section && !collection) {
        throw new UIAError('Section provided without collection: %0'.format(section));
    }

    if (!this.tapIfExists(soundCategory)) {
        throw new UIAError('Could not locate %0 sound category.'.format(soundCategory));
    }

    if (section && collection) {
        this.navigateToSubSoundCategory(section, collection);
    }

    this.tapSoundAndVerify(soundCategory, sound);
}

/**
 *
 * Helper function to navigate to sub sounds category
 *
 * @param {string} section - section within the main sound category, i.e. 'ALERT TONES' or 'RINGTONES'.
 * @param {string} collection - collection within section, i.e. 'Classic'.
 *
 */
settings.navigateToSubSoundCategory = function navigateToSubSoundCategory(section, collection) {
    if (!section || !collection) {
        throw new UIAError('Section and collection must be specified: %0, %1.'.format(section, collection));
    }

    UIALogger.logMessage("Navigating to section %0, collection %1".format(section, collection));
    if (section === "RINGTONES") {
        this.tap(UIAQuery.query(collection).first());
    } else if (section === "ALERT TONES") {
        this.tap(UIAQuery.query(collection).last());
    } else {
        throw new UIAError('Unknown section %0.'.format(section))
    }
}

/**
 *
 * Helper function to tap sound and verify it's name on the main screen
 *
 * @param {string} category - sound category, i.e. Ringtone.
 * @param {string} sound - sound value, i.e. 'Cosmic'.
 *
 */
settings.tapSoundAndVerify = function tapSoundAndVerify(category, sound){
    if (!sound) {
        throw new UIAError('Sound should be specified.');
    }

    if (!this.tapIfExists(sound)) {
        throw new UIAError('Could not locate %0 sound.'.format(sound));
    }

    this.navigateNavigationViews([{query: UIAQuery.Settings.SOUNDS}]);

    if (this.valueOf(category) === sound) {
        UIALogger.logMessage("Ringtone was successfully changed to %0.".format(sound));
    } else {
        throw new UIAError('We failed to choose a sound %0'.format(sound));
    }
}

/**
 * Enable an installed Developer Profile for an app.  Starting with iOS 9, enterprise app profiles are required to be trusted before the app can be successfully launched
 *
 * @param {string} ProfileTitle         - (Optional) The name of the profile to enable/trust (i.e. "Apple, Inc. - PEP").  Will proceed to enable the first profile if ProfileTitle is null.
 *
 * @throws if unable to enable the developer profile
 */
settings.enableDeveloperProfile = function enableDeveloperProfile(ProfileTitle) {
    // For iPads, if the first view we land on when Settings is launched is General, the Profile button will not have been loaded yet, so we force the view to reload by first going to a different view
    this.navigateNavigationViews(["Internal Settings", ]);
    var navigationViews = [
        {'query': UIAQuery.staticTexts('General'), 'title': 'General'},
        {'query': UIAQuery.contains('Device')},
    ];
    if (! this.navigateNavigationViews(navigationViews)) {
        throw new UIAError("Unable to go to app profile settings!");
    }

    if ((! this.exists( UIAQuery.RIGHT_TABLE.andThen(UIAQuery.tableCells()) )) || this.exists("No profiles are currently installed")) {
        throw new UIAError("There is no installed profile to enable!");
    }

    var profileButton;
    if (ProfileTitle) {
        profileButton = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.tableCells().contains(String(ProfileTitle)));
    } else {
        UIALogger.logMessage("No ProfileTitle passed in; defaulting to the first profile...");
        profileButton = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.tableCells().first());
    }

    if (! this.exists(profileButton)) {
        throw new UIAError("Developer Profile '%0' does not exist!");
    }
    this.tap( profileButton );

    var TRUST_AUTHOR = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.tableCells().withPredicate("ANY children.name BEGINSWITH 'Trust'")); // On iPads it is "Trust Author", but on iPhones it is "Trust <DEVELOPER>"
    if (! this.exists( TRUST_AUTHOR )) {
        UIALogger.logMessage("It looks like the profile has already been enabled!");
        return false;
    }

    var verifyTrustAlert = UIAQuery.withPredicate("name BEGINSWITH 'Trust' AND name CONTAINS[c] 'on This i'");
    this.handlingAlertsInline(verifyTrustAlert, function() {
        this.tap(TRUST_AUTHOR);
        this.waitUntilPresent(verifyTrustAlert, 5);
        this.tap("Trust");
    });

    if (this.waitUntilAbsent(TRUST_AUTHOR, 10)) {
        UIALogger.logMessage("Successfully enabled profile!");
        return true;
    } else {
        throw new UIAError("Failed to enable profile!");
    }
}

/**
  *  Sets the system date and time.  Be forewarned, setting the system date and time
  *           can have all kinds of weird side effects. We have tried to minimize these effects
  *           and have given the option to set the date and time via the Settings UI.
  *
  *  @param date ( Date object ) - The date and time to set
  **/
settings.setDateAndTime = function setDateAndTime(date) {
    // Conversion array for JS getMonth() method
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var twoDigitHours = date.getHours() >= 10 ? date.getHours() : "0" + date.getHours();
    var twoDigitMins = date.getMinutes() >= 10 ? date.getMinutes() : "0" + date.getMinutes();
    var date = '%0 %1'.format(months[date.getMonth()], date.getDate());

    settings.navigateNavigationViews(['General', 'Date & Time']);
    settings.setSwitchSetting('24-Hour Time', true);
    settings.setSwitchSetting('Set Automatically', false);

    settings.tap(UIAQuery.tableCells().last());

    settings.setPickerValues(UIAQuery.pickerWheels(), [date, twoDigitHours.toString(), twoDigitMins.toString()]);
}

/**
 * Sets contact as My Info
 *
 * @param {string} fullName - Full name of the contact to set as My Info
 */
settings.setContactAsMyInfo = function setContactAsMyInfo(fullName) {
    var contactQuery = UIAQuery.staticTexts(fullName).parent().isVisible();
    var meContactQuery = UIAQuery.staticTexts('me').parent().isVisible();

    settings.navigateNavigationViews(['Contacts', {query: 'My Info', title: 'Contacts'}]);

    UIAUtilities.assert(
        settings.exists(contactQuery),
        'Contact with full name "%0" not found'.format(fullName)
    );

    settings.tap(contactQuery);

    settings.navigateNavigationViews(['Contacts', {query: 'My Info', title: 'Contacts'}]);

    UIAUtilities.assert(
        settings.inspect(contactQuery).label.trim() === settings.inspect(meContactQuery).label.trim(),
        'Wrong contact was set as My Info!'
    );
}

/**
 * Navigate to Settings -> General and trigger OTA Software Update on the device.
 *
 * @param {string}          build         - Destination OS build to compare with currently installed on the device.
 * @param {string|null}     passcode      - (Optional) Passcode to input on Software Update page.
 *
 * @throws if OTA Software Update is not available or any error message is displayed.
 */
settings.softwareUpdate = function softwareUpdate(build, passcode) {

    var errorAlertCount = 0;

    UIAUtilities.assert(
        typeof build !== 'undefined',
        'Build is not provided in arguments'
    );

    var curBuild = UIATarget.localTarget().systemBuild();
    UIALogger.logMessage('The current build is %0'.format(curBuild));
    UIALogger.logMessage('Destination build: %0'.format(build));
    UIALogger.logMessage('passcode: %0'.format(passcode));

    if (curBuild === build) {
        UIALogger.logMessage('The device has already been updated to the correct build');
        UIALogger.logTAResults({'OTAupdateStatus': 'Installed'});
        return;
    }

    var otaAlertHandler = function() {
        var app = target.activeApp();
        // Create queries for alert matching
        var unableToCheckAlert = UIAQuery.alerts().andThen(UIAQuery.contains('Unable to Check for Update'));
        var verifyingUpdateAlert = UIAQuery.alerts().andThen(UIAQuery.contains('Verifying update'));
        var WLANalert = UIAQuery.alerts().andThen(UIAQuery.contains('WLAN'));

        // Alert buttons
        var tryAgainButton = UIAQuery.alerts().andThen(UIAQuery.buttons('Try Again'));
        var agreeButton = UIAQuery.alerts().andThen(UIAQuery.buttons('Agree'));
        var settingsButton = UIAQuery.alerts().andThen(UIAQuery.buttons('Settings'));
        var installButton = UIAQuery.alerts().andThen(UIAQuery.buttons().contains('Install'));
        var okButton = UIAQuery.alerts().andThen(UIAQuery.buttons().contains('OK'));
        var WLANbutton = UIAQuery.alerts().andThen(UIAQuery.buttons().contains('WLAN Only'));

        // make a app snapshot for inspections
        var appInfo = app.inspect(UIAQuery.application());
        if (!appInfo) {
            UIALogger.logMessage('Unable to get app snapshot with inspect.');
            return false;
        }
        // inspect the Alert and capture name/text
        if (appInfo.inspect(UIAQuery.alerts().isVisible())) {
            var alertName = appInfo.inspect(UIAQuery.alerts().isVisible()).name;
        } else {
            UIALogger.logMessage('Unable to get Alert Name from snapshot.');
            return false;
        }
        try {
            if (appInfo.inspect(UIAQuery.alerts().andThen(UIAQuery.staticTexts().atIndex(1)))) {
                var alertText = appInfo.inspect(UIAQuery.alerts().andThen(UIAQuery.staticTexts().atIndex(1))).name;
            } else {
                var alertText = 'No alert text';
            }
        } catch (e) {
            // For Alerts with label only. e.g. Verifying update... alert.
            UIALogger.logError('Exception reading alert text: %0'.format(e));
            var alertText = 'No alert text';
        }
        UIALogger.logMessage('Alert encountered during OTA update: %0 : %1'.format(alertName, alertText));

        if (appInfo.exists(verifyingUpdateAlert)) {
            UIALogger.logMessage('Verifying update... alert received; installing software');
            UIALogger.logTAResults({'OTAupdateStatus': 'Install'});
            return true;
        } else if (appInfo.exists(unableToCheckAlert) || appInfo.exists(tryAgainButton)) {
            if (errorAlertCount < 5) {
                errorAlertCount++;
                UIALogger.logMessage('Trying update again (attempt %0)'.format(errorAlertCount));
                app.tap(tryAgainButton);
                return true;
            } else {
                UIALogger.logError('Alert occurred more than 5 times. Error: %0 : %1'.format(alertName, alertText));
                throw new UIAError('Repeating Error during OTA update: %0 : %1'.format(alertName, alertText));
            }
        } else if (appInfo.exists(WLANalert)) {
            UIALogger.logMessage('WLAN access Alert');
            app.tapIfExists(WLANbutton);
            app.tapIfExists(okButton);
        } else if (appInfo.exists(settingsButton)) {
            UIALogger.logError('Hard error during OTA update; Tapping Setttings and exiting');
            app.tap(settingsButton);
            throw new UIAError('Error during OTA update: %0'.format(alertText));
        } else if (appInfo.exists(agreeButton)) {
            UIALogger.logMessage('Clicking Agree on popup');
            app.tap(agreeButton);
            return true;
        } else if (appInfo.exists(installButton)) {
            UIALogger.logMessage('Install alert received; installing software');
            app.tap(installButton);
            UIALogger.logTAResults({'OTAupdateStatus': 'Install'});
            return true;
        }
        return false;
    };

    if (target.activeApp().performTask) {
        // print disk statistics (we are insterested in free space left on the device). request from devs.
        dfOutput = target.performTask('/bin/df', ['-m']);
        if (!dfOutput || !(typeof dfOutput.stdout === 'string' && dfOutput.stdout.length > 0) || dfOutput.timedOut || dfOutput.exitCode !== 0 || (typeof dfOutput.stderr === 'string' && dfOutput.stderr.length > 0)) {
            UIALogger.logMessage('Unable to get df -m output: %0'.format(dfOutput.stderr));
        } else {
            UIALogger.logMessage('Device disk statistics(df -m): %0'.format(dfOutput.stdout));
        }
    }

    // launch Settings and return to top level(required during test retries)
    // <rdar://problem/25072863> "UIAError: App never became ready to receive events" if popup is present during app launch
    try {
        this.launch();
    } catch (error) {
        UIALogger.logError(error);
        if (!this.waitUntilPresent(UIAQuery.application())) {
            throw error;
        }
    }
    alertCounter = 0;
    // dismiss all alerts
    while (this.inspect(UIAQuery.alerts().isVisible()) && alertCounter <= 10) {
        UIALogger.logMessage('Dismissing alert: %0'.format(this.inspect(UIAQuery.alerts().isVisible()).name));
        this.tap('default-button');
        alertCounter++;
    }
    // if alert is still visible after 10 attempts to dismiss it, throw
    if (this.inspect(UIAQuery.alerts().isVisible()) && alertCounter >= 10) {
        throw new UIAError('Unable to dismiss alert: %0'.format(this.inspect(UIAQuery.alerts().isVisible()).name));
    }

    this.returnToTopLevel();

    this.withAlertHandler(otaAlertHandler, function() {

        // allow Settings to use WLAN on China devices.
        if (target.mobileGestaltQuery('green-tea') && this.waitUntilPresent(UIAQuery.contains('WLAN'))) {
            UIALogger.logMessage('Navigating to Settings -> WLAN');
            if (!this.navigateNavigationViews(['WLAN'])) {
                throw new UIAError('Could not get to WLAN');
            }
            if (!this.waitUntilPresent(UIAQuery.contains('Apps Using WLAN & Cellular'))) {
                throw new UIAError('"Apps Using WLAN & Cellular" not found');
            }
            UIALogger.logMessage('Tapping "Apps Using WLAN & Cellular"');
            this.scrollToVisible(UIAQuery.contains('Apps Using WLAN & Cellular'));
            this.tap(UIAQuery.contains('Apps Using WLAN & Cellular'));
            if (this.waitUntilPresent(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().contains('Settings')))) {
                UIALogger.logMessage('Tapping USE DATA FOR -> Settings');
                this.tap(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().contains('Settings')));
            }
            if (this.waitUntilPresent(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().contains('WLAN')))) {
                UIALogger.logMessage('Tapping WLAN & Cellular Data');
                this.tap(UIAQuery.tableCells().contains('WLAN & Cellular Data').orElse(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells().contains('WLAN'))));
            }
            this.returnToTopLevel();
        }

        UIALogger.logMessage('Trying to trigger OTA Update');
        UIALogger.logMessage('Navigating to General -> Software Update');
        if (!this.navigateNavigationViews(['General', 'Software Update'])) {
            throw new UIAError('Could not get to General -> Software Update');
        }

        var timetoWaitforDownload = 300000; // 5 minutes
        var start = new Date();
        UIALogger.logMessage('Start time is %0'.format(start.toString()));
        var cur = new Date();

        // Allow 5 minutes timeout to scan for the update
        while (cur - start < timetoWaitforDownload && errorAlertCount <= 5) {

            // Check for 'Checking for Update' text
            UIALogger.logMessage('Searching for Checking for Update text');
            if (this.waitUntilPresent(UIAQuery.contains('Checking for Update'), 1)) {
                UIALogger.logMessage('Still Checking for Update...');
            }

            // Check for iCloud download icon ('PurchaseButton' button)
            UIALogger.logMessage('Searching for iCloud download icon');
            if (this.waitUntilPresent(UIAQuery.buttons('PurchaseButton'), 1)) {
                UIALogger.logMessage('Tapping PurchaseButton');
                this.tap(UIAQuery.buttons('PurchaseButton'));

                // input passcode if needed, throw if passcode was not proovided in arguments
                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    if (passcode) {
                        this.typeString(passcode);
                    } else {
                        throw new UIAError('OTA required passcode but Passcode was not provided in arguments');
                    }
                }

                // Accept T&C if needed
                if (this.waitUntilPresent(UIAQuery.buttons().contains('Agree'), 30)) {
                    UIALogger.logMessage('Accepting T&C...');
                    this.tap(UIAQuery.buttons().contains('Agree'));
                }

                //wait for Update Requested or Downloading...
                if (!this.waitUntilPresent(UIAQuery.contains('Update Requested').orElse(UIAQuery.contains('Downloading')), 20)) {
                    UIALogger.logError('Update Requested or Downloading.. not found.');
                    throw new UIAError('Update Requested or Downloading.. not found.');
                }

                // pass info about which path was used to start update to wait script
                UIALogger.logMessage('Download is in progress');
                UIALogger.logTAResults({'OTAupdateStatus': 'Download'});
                return;
            }

            // Check for Download and Install button
            UIALogger.logMessage('Searching for Download and Install');
            if (this.waitUntilPresent(UIAQuery.contains('Download and Install'), 1)) {
                UIALogger.logMessage('Tapping Download and Install');
                this.tap(UIAQuery.contains('Download and Install'));

                // input passcode if needed, throw if passcode was not proovided in arguments
                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    if (passcode) {
                        settings.waitUntilPresent(UIAQuery.keyboard().isVisible(), 10.00);
                        this.typeString(passcode);
                    } else {
                        throw new UIAError('OTA required passcode but Passcode was not provided in arguments');
                    }
                }

                // Accept T&C if needed
                if (this.waitUntilPresent(UIAQuery.buttons().contains('Agree'), 30)) {
                    UIALogger.logMessage('Accepting T&C...');
                    this.tap(UIAQuery.buttons().contains('Agree'));
                }

                //wait for Update Requested or Downloading...
                if (!this.waitUntilPresent(UIAQuery.contains('Update Requested').orElse(UIAQuery.contains('Downloading')), 20)) {
                    UIALogger.logError('Update Requested or Downloading.. not found.');
                    throw new UIAError('Update Requested or Downloading.. not found.');
                }

                // pass info about which path was used to start update to wait script
                UIALogger.logMessage('Download is in progress');
                UIALogger.logTAResults({'OTAupdateStatus': 'Download'});
                return;
            }

            // Check for Downloading in progress
            UIALogger.logMessage('Searching for Downloading...');
            if (this.waitUntilPresent(UIAQuery.contains('Downloading'), 1)) {
                UIALogger.logMessage('Download In progress');
                UIALogger.logTAResults({'OTAupdateStatus': 'Download'});
                return;
            }

            // Check for Preparing Update...
            UIALogger.logMessage('Searching for Preparing Update...');
            if (this.waitUntilPresent(UIAQuery.contains('Preparing Update'), 1)) {
                UIALogger.logMessage('Prepare In progress');
                UIALogger.logTAResults({'OTAupdateStatus': 'Download'});
                return;
            }

            // Check if download is ready to install (with Install-PurchaseButton)
            UIALogger.logMessage('Searching for Install-PurchaseButton');
            if (this.waitUntilPresent(UIAQuery.contains('Downloaded'), 1) && this.waitUntilPresent(UIAQuery.contains('PurchaseButton'), 1)) {
                UIALogger.logMessage('OTA is Already Downloaded Just need to install ');
                UIALogger.logMessage('Tapping the Install-PurchaseButton button');
                this.tap(UIAQuery.buttons('PurchaseButton'))

                // input passcode if needed
                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    settings.waitUntilPresent(UIAQuery.keyboard().isVisible(), 10.00);
                    this.typeString(passcode);
                }

                // Accept T&C if needed
                if (this.waitUntilPresent(UIAQuery.buttons().contains('Agree'), 30)) {
                    UIALogger.logMessage('Accepting T&C...');
                    this.tap(UIAQuery.buttons().contains('Agree'));
                }
                // pass info about which path was used to start update to wait script
                UIALogger.logTAResults({'OTAupdateStatus': 'Install'});
                return;
            }

            // Check if download is ready to install
            UIALogger.logMessage('Searching for Install Now');
            if (this.waitUntilPresent(UIAQuery.contains('Install Now'), 1)) {
                UIALogger.logMessage('OTA is Already Downloaded Just need to install ');
                UIALogger.logMessage('Tapping the Install Now button');
                this.tap(UIAQuery.contains('Install Now'));

                // input passcode if needed
                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    settings.waitUntilPresent(UIAQuery.keyboard().isVisible(), 10.00);
                    this.typeString(passcode);
                }

                // Accept T&C if needed
                if (this.waitUntilPresent(UIAQuery.buttons().contains('Agree'), 30)) {
                    UIALogger.logMessage('Accepting T&C...');
                    this.tap(UIAQuery.buttons().contains('Agree'));
                }
                // pass info about which path was used to start update to wait script
                UIALogger.logTAResults({'OTAupdateStatus': 'Install'});
                return;
            }

            // Check for Up To Date
            UIALogger.logMessage('Searching for Up To Date...');
            if (this.waitUntilPresent(UIAQuery.contains('up to date'), 1)) {
                UIALogger.logError('Up To Date has been found');
                UIALogger.logTAResults({'OTAupdateStatus': 'UpToDate'});
                throw new UIAError('Up To Date has been found');
            }

            // Check for not enough storage.
            UIALogger.logMessage('Searching for Usage Settings (aka Not Enough Space)...');
            if (this.waitUntilPresent(UIAQuery.contains('Usage Settings'), 1)) {
                UIALogger.logError('Your device does not have enough space to install OTA update');
                UIALogger.logTAResults({'OTAupdateStatus': 'NotEnoughSpace'});
                throw new UIAError('Not enough space to install OTA update');
            }

            cur = new Date();
            UIALogger.logMessage('Current time is %0'.format(cur.toString()));
        }

        UIALogger.logError('Unable to start OTA update');
        throw new UIAError('Exceeded max attempts to complete OTA update');
    });
}


/**
  * Sets the camera record settings
  *
  * @targetApps Preferences
  *
  * @param {object} args Test arguments
  * @param {string} [args.recordVideoSetting=null] - Which video record setting to use: "highest", "lowest", or custom string like "4K at 30 fps"
  * @param {string} [args.recordSlomoSetting=null] - Which slo-mo record setting to use: "highest", "lowest", or custom string like "720p HD at 240 fps"
  */
settings.setRecordSettings = function setRecordSettings(options) {
    options = UIAUtilities.defaults(options, {
        recordVideoSetting: null,
        recordSlomoSetting: null,
    });

    highestSetting = 'highest';
    lowestSetting = 'lowest';

    if (options.recordVideoSetting) {
        this.navigateNavigationViews(["Camera", "Record Video"])
        if (options.recordVideoSetting === highestSetting) {
            UIALogger.logMessage('Going to tap '+ settings.nameOf(UIAQuery.Settings.HIGHEST_CAMERA_FPS_SETTING));
            settings.tap(UIAQuery.Settings.HIGHEST_CAMERA_FPS_SETTING)
            UIALogger.logMessage('Successfully tapped!')
        }
        else if (options.recordVideoSetting === lowestSetting) {
            UIALogger.logMessage('Going to tap '+ settings.nameOf(UIAQuery.Settings.LOWEST_CAMERA_FPS_SETTING));
            settings.tap(UIAQuery.Settings.LOWEST_CAMERA_FPS_SETTING);
            UIALogger.logMessage('Successfully tapped!')
        }
        else {
            settings.tap(UIAQuery.contains(options.recordVideoSetting));
        }
    }
    else {
        UIALogger.logMessage('Not setting record video setting because not defined!');
    }

    if (options.recordSlomoSetting){
        this.navigateNavigationViews(["Camera", "Record Slo-mo"])
        if (options.recordSlomoSetting === highestSetting) {
            UIALogger.logMessage('Going to tap '+ settings.nameOf(UIAQuery.Settings.HIGHEST_CAMERA_FPS_SETTING));
            settings.tap(UIAQuery.Settings.HIGHEST_CAMERA_FPS_SETTING);
            UIALogger.logMessage('Successfully tapped!')
        }
        else if (options.recordSlomoSetting === lowestSetting) {
            UIALogger.logMessage('Going to tap '+ settings.nameOf(UIAQuery.Settings.LOWEST_CAMERA_FPS_SETTING));
            settings.tap(UIAQuery.Settings.LOWEST_CAMERA_FPS_SETTING);
            UIALogger.logMessage('Successfully tapped!')
        }
        else {
            settings.tap(UIAQuery.contains(options.recordSlomoSetting));
        }
    }
    else {
        UIALogger.logMessage('Not setting record slo-mo setting because not defined!');
    }
}

/** Adds new item to control center
 *
 * @targetApps Preferences
 *
 * @param {object} options Test arguments
 * @param {string} [options.buttonToAdd='Insert Screen Recording'] - What customization you want to add to control center
 */
settings.customizeControlCenter = function customizeControlCenter(options) {
    options = UIAUtilities.defaults(options, {
        buttonToAdd: UIAQuery.Settings.INSERT_SCREEN_RECORDING,
    });

    this.launch();
    this.waitForViewToAppear('navigationItemTitle == "Control Center"', 5, function() {
        this.tap(UIAQuery.Settings.CONTROL_CENTER);
    });
    this.waitForViewToAppear('navigationItemTitle == "Customize"', 5, function() {
        this.tap(UIAQuery.Settings.CONTROL_CENTER_CUSTOMIZE);
    });

    this.tap(options.buttonToAdd);

    this.quit();
}


/**
 * Return the default Auto-Lock timeout for this device
 *
 * @targetApps Preferences
 */
settings.getMyDefaultAutolockTimeout = function getMyDefaultAutolockTimeout() {
    var defaultAutolockTimeout = {'iPad':'2 Minutes', 'iPhone':'1 Minute'};

    var deviceType = UIATarget.localTarget().model();

    if (deviceType in defaultAutolockTimeout) {
        return(defaultAutolockTimeout[deviceType]);
    }
    else {
        throw new UIAError('Requested autolock timeout for unknown device type');
    }
}

/**
 * Convert checkItem string in Auto-Lock setting to seconds
 *
 * @targetApps Preferences
 *
 * @param {string} item - checked item string in Auto-Lock settings
 */
settings.autolockTimeoutString2Seconds = function autolockTimeoutString2Seconds(item) {
    var autolockItemString2Seconds = {
        '30 Seconds': 30, '1 Minute'  : 60,  '2 Minutes' : 120,
        '3 Minutes' : 180,'4 Minutes' : 240, '5 Minutes' : 300,
        'Never'     : -1,
    };

    if (item in autolockItemString2Seconds) {
        return(autolockItemString2Seconds[item]);
    }
    else {
        throw new UIAError('Requested autolock timeout seconds for unknown string item');
    }
}


/**
 * Set the default auto-lock timeout for this device in Settings
 *
 * @targetApps Preferences
 *
 * @returns {number} - default auto-lock timeout in seconds
 */
settings.setDefaultAutoLockTimeout = function setDefaultAutoLockTimeout() {
    var args = {}
    args.checkItem = this.getMyDefaultAutolockTimeout();
    args.navigationViews = ["Display & Brightness", "Auto-Lock"];

    UIALogger.logMessage("Setting Default device autolock timeout: '%0'".format(args.checkItem));
    this.chooseCheckmarkedItem(args.navigationViews, args.checkItem, true);
    this.tap(UIAQuery.buttons().contains('Display & Brightness'));

    return (this.autolockTimeoutString2Seconds(args.checkItem));
}

/**
 * Verify that the device goes into auto-lock after the specified period
 *
 * @targetApps Preferences
 *
 * @param {number} timeout - auto-lock timeout value in seconds
 * @returns {boolean} - true if autolock period successfully verified otherwise false
 */
settings.verifyAutoLockTimeout = function verifyAutoLockTimeout(timeout) {
    if (timeout < 0) {
        throw new UIAError("Cannot verify negative auto-lock timeout %0".format(timeout));
    }

    var margin = 10;
    var timeGranularity = 5;
    var nWaits = timeout / timeGranularity;
    var sysApp = target.systemApp();
    var elapsedTime = 0;

    for (i = 1; i <= nWaits + 1; i++) {
        var waiter = UIAWaiter.waiter('ScreenLocked');
        elapsedTime = i * timeGranularity;
        if (!waiter.wait(timeGranularity)) {
            UIALogger.logMessage("ScreenLocked Event not received after %0s".format(elapsedTime));
        }
        else {
            if (sysApp.isLocked() == true) {
                if ( ((elapsedTime) - timeout) <= margin) {
                    UIALogger.logMessage("Screenlocked after: %0s".format(elapsedTime));
                    return (true);
                }
            }
        }
    }

    return (false);
}

/**
 * Set Mobile Data on/off as required
 *
 * @targetApps Preferences
 *
 * @param {boolean} mobileDataOn - set mobile data on/off
 */
 settings.setMobileData = function setMobileData(mobileDataOn) {
    var deviceName = UIATarget.localTarget().model();
    if (deviceName == 'iPhone') {
        settings.navigateNavigationViews(['Mobile Data']);
        settings.setSwitchSetting('Mobile Data', mobileDataOn);

    } else if (deviceName == 'iPad') {
        settings.launch();
        settings.navigateNavigationViews(['Cellular Data']);
        settings.setSwitchSetting('Cellular Data', mobileDataOn);

    } else {
        throw new UIAError('Setting mobile data is unsupported for this device.');
    }
 }

 /**
 * Set Wi-Fi on/off as required
 *
 * @targetApps Preferences
 *
 * @param {boolean} wifiOn - set Wi-Fi on/off
 *
 */
 settings.setWifi = function setWifi(wifiOn, wifiNetwork, wifiPassword) {
    settings.navigateNavigationViews(['Wi-Fi']);
    settings.waitUntilAbsent(UIAQuery.activityIndicators(), 60);
    settings.setSwitchSetting('Wi-Fi', wifiOn);

    if (wifiOn == true) {
        // wait for network list to appear.....
        settings.waitUntilAbsent(UIAQuery.activityIndicators(), 60);
        if (settings.count(UIAQuery.tableCells().contains(wifiNetwork).andThen(UIAQuery.images('UIPreferencesBlueCheck'))) == 0) {
            // the network hasn't been automatically selected for us so we must do it
            settings.tap(UIAQuery.staticTexts(wifiNetwork));
            settings.enterText(UIAQuery.secureTextFields().bottommost(),wifiPassword);
            settings.tap(UIAQuery.buttons().contains('Join'));
        }
    }
 }

 /**
 * Get the region on the device.
 *
 * @returns {string} currentRegion - Region string that appears on device.
 *                      (e.g, France, Canada, China, Taiwan, Japan, United States)
 */
settings.getDeviceRegion = function getDeviceRegion() {

    if (!settings.navigateNavigationViews(["General", "Language & Region"])) {
        throw new UIAError("Failed to navigate settings");
    }
    var currentRegion = settings.valueOf(UIAQuery.Settings.REGION_BUTTON);
    return currentRegion;
}

/**
 * Turns Find My iPhone on/off for the current iCloud account based
 * on specified options.
 *
 * @param {object} options
 * @param {string} [options.password="password"] -  Password for iCloud account
 * @param {boolean} [options.FMiPState=false] - Sets findMy to on/off
 *              depending on flag
 *
 * @returns none
 */
settings.switchFMiPOnOff = function switchFMiPOnOff(options) {
    options = UIAUtilities.defaults(options, {
        password: null,
        FMiPState: null,
    });
	var passwordHandler = function() {
        var app = target.activeApp();
        if (app.waitUntilPresent('Password Required', 1) || app.exists('Apple ID Password')) {
            UIALogger.logMessage('Found the Apple ID password alert, handling...')
            app.tap(UIAQuery.secureTextFields());
            app.typeString(options.password);
            app.tap('Turn Off');
            return true;
        } else {
            return false;
        }
	}
	this.navigateNavigationViews([{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}, 'iCloud']);
	this.scrollToVisible(UIAQuery.contains('Find My iP'));
	this.tap(UIAQuery.contains('Find My iP'));

    this.withAlertHandler(passwordHandler, function() {
	this.setSwitchSetting('Find My iP', options.FMiPState);
	});
	this.returnToTopLevel();
}

/**
 * Allows USB Accessories access when locked to deal with stringent USB hardening
 * outlined in <rdar://problem/45600699>
 *
 * @param {string} passcode Passcode required to disable passcode
 *
 * @throws if passcode controls can't be found or passcode arguments are
 *         malformed
 */
settings.allowUSBAccessoriesAccess = function allowUSBAccessoriesAccess(passcode) {
    var validDigit = /^\d{4,6}$/;

    if (!passcode) {
        UIALogger.logDebug('No Passcode provided: Only need to allow access when the device has a passcode');
        return;
    }

    if (!passcode.match(validDigit)) {
        var passcodeType = 'Custom';
    }
    else {
        var passcodeType = 'NonCustom';
    }

    if (!this.navigateNavigationViews([ {'query': UIAQuery.contains('Passcode')} ])) {
        throw new UIAError('Could not navigate to view');
    }

    if (this.exists('Enter your passcode')) {
        this.waitForViewToAppear('navigationItemTitle IN {"Passcode Lock", "Touch ID & Passcode", "Face ID & Passcode"}', function() {
            this.typeString(passcode);
            if (passcodeType === 'Custom') {
                this.tap('Done');
            }
        });
    }

    try {
        var toggleSwitch = UIAQuery.switches().beginsWith('USB Accessories');
        var isSwitchEnabled = settings.inspectElementKey(toggleSwitch, 'isEnabled');
        if (isSwitchEnabled) {
            var cellValue = settings.inspectElementKey(toggleSwitch, 'value');

            // Check if USB Accessories already allowed
            if (cellValue == 0) {
                UIALogger.logDebug('USB Accessories not currently allowed access- attempting to allow');
                settings.tap(toggleSwitch);
                if (settings.inspectElementKey(toggleSwitch, 'value') != 1) {
                    throw new UIAError('Did not allow USB Accessories after attempting to toggle')
                }
            }
            else {
                UIALogger.logDebug('USB Accessories already allowed access');
            }
        }
        else {
            UIALogger.logDebug('USB Accessories not enabled- cannot toggle');
        }
    }
    catch (error) {
        if (error.toString().contains('does not exist')) {
            UIALogger.logDebug('No USB Accessories toggle exists');
        }
        else {
            throw error;
        }
    }
}

/**
 * Get current switch state
 *
 * @param {string} item - query of switch to examine
 *
 * @returns {boolean} - true if the switch is "On", false otherwise
 */
settings.getSwitchState = function getSwitchState(item) {
    var currentState = (!!parseInt(this.inspect(item).value));
    UIALogger.logMessage('Current state of the switch: "%0"'.format(currentState));
    return currentState;
}
