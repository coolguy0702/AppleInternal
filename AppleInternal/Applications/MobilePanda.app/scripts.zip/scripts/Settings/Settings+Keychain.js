load('UIAApp.js');
load('UIASemaphore.js');

load('Settings.js');
load('SpringBoard.js');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common template queries */
UIAQuery.Keychain = {

    /** Alerts */
    Alerts:                     {

        /** 'Sign In to iCloud' alert */
        SIGN_INTO_ICLOUD:                     UIAQuery.beginsWith('Sign In to iCloud'),

        /** 'Use iPhone Passcode as iCloud Security Code?' alert */
        USE_PASSCODE_SECURITY_CODE:      UIAQuery.beginsWith('Use iPhone Passcode as iCloud Security Code?'),

        /** 'Are You Sure You Want to Use This Code?' alert */
        USE_SIMPLE_SECURITY_CODE:      UIAQuery.beginsWith('Are You Sure You Want to Use This Code?'),

        /** 'Sign In with Apple ID' alert */
        SIGN_WITH_APPLE_ID:      UIAQuery.beginsWith('Sign In with Apple ID'),

        /** 'Incorrect Security or Verification Code' alert */
        INCORRECT_SECURITY_CODE:      UIAQuery.contains('Incorrect Security or Verification Code'),

        /** 'Could Not Set Up iCloud Keychain' alert */
        NOT_SET_UP_KEYCHAIN:           UIAQuery.contains('Could Not Set Up iCloud Keychain'),

    },
};

/**
 * Test follows a navigation-view path in Settings to iCloud Keychain, enables it and deals
 * with an alert window that pops up to sign into the iCloud account.
 * @param {string}	navigationViews - Views to navigate
 * @param {string}  item - Item that needs to be switched.
 * @param {string}	password - iCloud password to enter into the sing in alert
 * @param {string}	passcode - passcode of the device used for creating a security code.
 * @param {string}	phonenumber - phone number of the device used for initiatibg a circle.
 * @param {boolean}	shouldMatchExactly - Should search for items that are equivalent to
 *                                       switchItem (true) or contains switchItem (false)
 * @param {boolean}	switchValue - Should switch be on (true) or off (false)?
 * @param {boolean}	isICSC - Is this an ICSC approval flow (true) or not (false)?
 * @param {boolean}	isRandom - Is the security code random type (true) or not (false)?
 * @param {boolean}	isICSC - Is the security code complex type (true) or not (false)?
 */


settings.enableKeychainAndConfirmAlert = function enableKeychainAndConfirmAlert(navigationViews, item, isSwitch, password, passcode, phonenumber, options) {

    options = UIAUtilities.defaults(options, {
        shouldMatchExactly: false,
        switchValue: true,
        isICSC: false,
        isRandom: true,
        isComplex: false,
    });

    var sixDigits = /^\d{6}$/;

    if (!passcode) {
        throw new UIAError('Must provide new passcode');
    }

    if (!options.isRandom && !options.isComplex && !passcode.match(sixDigits)) {
        throw new UIAError('New passcode must be 6 digits');
    }

    settings.launch();

    // Navigate to the item
    if (!settings.navigateNavigationViews(navigationViews)) {
        throw new UIAError('Failed to navigate settings');
    }

    // Based on settings.setSwitchSetting()
    var rightSwitches = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches());

    if (options.shouldMatchExactly) {
        var query = rightSwitches.andThen(UIAQuery.query(item));
    } else {
        var query = rightSwitches.andThen(UIAQuery.contains(item));
    }

    settings.scrollToVisible(query);

    // Only continue if the item is a switch OR if the switch WILL be changed
    if (isSwitch && settings.shouldFlipSwitch(settings.inspect(query).value, options.switchValue)) {
        var appleSignInAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.SIGN_INTO_ICLOUD);
        var createSecurityCodeAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.USE_PASSCODE_SECURITY_CODE);
        var useSameCodeAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.USE_SIMPLE_SECURITY_CODE);
        var notSetupKeychain = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.NOT_SET_UP_KEYCHAIN);
        var cell_ICSC = UIAQuery.tableCells().withPredicate("ANY children.name == 'Approve with Security Code'");

        UIALogger.logMessage('Before alert handler!!');
        settings.handlingAlertsInline(appleSignInAlert, function () {
            settings.handlingAlertsInline(createSecurityCodeAlert, function() {
                settings.handlingAlertsInline(useSameCodeAlert, function() {
                    settings.setControl(query, options.switchValue);
                    if (springboard.waitUntilPresent(appleSignInAlert, 30)) {
                        UIALogger.logMessage('We need to enter Apple ID password!');
                        springboard.enterText(UIAQuery.secureTextFields(), password);
                        springboard.tap('OK');
                        // Need to put delay unless we fix :<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                        //<rdar://problem/21367119> [UIA2] The Alert notification should really include the title of the alert
                        target.delay(20);
                    }
                    if (settings.waitUntilPresent(createSecurityCodeAlert, 30)) {
                        UIALogger.logMessage('We need to choose create different code!');
                        settings.tap('Create Different Code');
                        if ((options.isComplex || options.isRandom) && !options.isICSC) {
                            UIALogger.logMessage('We need to use complex or random security code, lets tap on advanced options!');
                            var waiter = UIAWaiter.waiter('ViewDidAppear');
                            settings.tap('Advanced Options');
                            if (!waiter.wait(5)) {
                                throw new UIAError('Something went wrong. Event did not appear.');
                            }
                            if (options.isComplex) {
                                settings.tap('Use a Complex Security Code');
                                settings.typeString(passcode);
                            } else if (options.isRandom) {
                                //<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                                target.delay(2);
                                settings.tap('Get a Random Security Code');
                                //<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                                target.delay(2);
                                var s = UIAQuery.contains('UIAccessibilityTextFieldElement');
                                var rCode = settings.inspect(s).value;
                                var rCodeFile = new UIAFile('/tmp/verificationcode.json');
                                rCodeFile.open('w', 'unicode');
                                rCodeFile.writeln(JSON.stringify({code: rCode}));
                                rCodeFile.close();
                                settings.tap('Random Code');
                                settings.tap(UIAQuery.RIGHT_NAV_BUTTON);
                                settings.typeString(rCode);
                            }
                            settings.tap(UIAQuery.RIGHT_NAV_BUTTON);
                        } else {
                            UIALogger.logMessage('Creating simple iCloud security Code.');
                            settings.typeString(passcode);
                            //<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                            target.delay(5);
                        }
                    }
                    if (settings.waitUntilPresent(useSameCodeAlert, 30)) {
                        settings.tap('Use Code');
                        //<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                        target.delay(5);
                    }
                });
            });
        if (options.isICSC && settings.exists(cell_ICSC)) {
            UIALogger.logMessage('We need to take care of ICSC flow!');
            settings.tap('Approve with Security Code');
            settings.typeString(passcode);
            if (options.isComplex || options.isRandom){
                settings.tap(UIAQuery.RIGHT_NAV_BUTTON);
            }
        } else if (!options.isRandom) {
            UIALogger.logMessage('Re-entering the iCloud security Code.');
            settings.typeString(passcode);
            //<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
            target.delay(5);
            if (options.isComplex){
                settings.tap(UIAQuery.RIGHT_NAV_BUTTON);
            }
            UIALogger.logMessage('We need to enter the phone number now!');
            settings.typeString(phonenumber);
            settings.tap(UIAQuery.RIGHT_NAV_BUTTON);
            }
        });

        if (settings.waitUntilPresent(notSetupKeychain, 30)) {
            throw new UIAError('Could Not Set Up iCloud Keychain!');
        }
    }
}


/**
 * Test handles entering the sms verification code for enabling keychain device using the Approval with Security Code flow.
 *
 * @targetApps Preferences
 *
 * @param {string} password - iCloud password to enter into the sing in alert
 * @param {string} vCode - passcode of the device used for creating a security code.
 */

settings.smsVerificationHandlerKeychain = function smsVerificationHandlerKeychain(password, vCode) {

    var sixDigits = /^\d{6}$/;

    if (!vCode) {
        throw new UIAError('No verification code provided!');
    }

    if (!password) {
        throw new UIAError('No password provided!');
    }

    if (!vCode.match(sixDigits)) {
        throw new UIAError('SMS verification code must be 6 digits!');
    }

    settings.launch();
    var appleSignInAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.SIGN_WITH_APPLE_ID);
    var iCloudSignInAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.SIGN_INTO_ICLOUD);
    var incorrectCodeAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.INCORRECT_SECURITY_CODE);
    UIALogger.logMessage('Using 6-digit verifcation code!');

    settings.handlingAlertsInline(appleSignInAlert, function () {
        settings.handlingAlertsInline(iCloudSignInAlert, function() {
            settings.handlingAlertsInline(incorrectCodeAlert, function() {
                settings.typeString(vCode);
                if (springboard.waitUntilPresent(appleSignInAlert, 30)) {
                    UIALogger.logMessage('We need to enter Apple ID password!');
                    springboard.enterText(UIAQuery.secureTextFields(), password);
                    springboard.tap('OK');
                    // Need to put delay unless we fix :<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                    //<rdar://problem/21367119> [UIA2] The Alert notification should really include the title of the alert
                    target.delay(20);
                }
                if (settings.waitUntilPresent(iCloudSignInAlert, 30)) {
                    UIALogger.logMessage('We need to enter iCloud password!');
                    springboard.enterText(UIAQuery.secureTextFields(), password);
                    springboard.tap('OK');
                }
                if (settings.waitUntilPresent(incorrectCodeAlert, 30)) {
                    UIALogger.logMessage('Tapping on Incorrect Security or Verification Code in alerts!');
                    settings.tap(UIAQuery.DEFAULT_BUTTON);
                }
            });
        });
    });
}

/**
 * Test handles enabling keychain to enroll into iCDP for second device flow HSA2 accounts.
 *
 * @targetApps Preferences
 * @param {string} password - iCloud password to enter into the sign in alert
 */

settings.enableKeychainICDP = function enableKeychainICDP(password, options) {
    options = UIAUtilities.defaults(options, {
            shouldMatchExactly: false,
            switchValue: true,
            isSwitch: true,
    });
    var navigationViews = [{query: UIAQuery.Settings.ICLOUD_TABLE_CELL}, "iCloud", "Keychain"];
    var item = 'iCloud Keychain';

    if (!password) {
        throw new UIAError('No password provided!');
    }

    settings.launch();

    // Navigate to the item
    if (!settings.navigateNavigationViews(navigationViews)) {
        throw new UIAError('Failed to navigate settings');
    }

    // Based on settings.setSwitchSetting()
    var rightSwitches = UIAQuery.RIGHT_TABLE.andThen(UIAQuery.switches());
    var query = rightSwitches.andThen(UIAQuery.contains(item));
    settings.scrollToVisible(query);

    if (options.isSwitch && settings.shouldFlipSwitch(settings.inspect(query).value, options.switchValue)) {
        var appleSignInAlert = UIAQuery.alerts().andThen(UIAQuery.Keychain.Alerts.SIGN_INTO_ICLOUD);
        settings.handlingAlertsInline(appleSignInAlert, function () {
            settings.setControl(query, options.switchValue);
            if (springboard.waitUntilPresent(appleSignInAlert, 30)) {
                UIALogger.logMessage('We need to enter Apple ID password!');
                springboard.enterText(UIAQuery.secureTextFields(), password);
                springboard.tap('OK');
                // Need to put delay unless we fix :<rdar://problem/21366613> [UIA2] Allow waiters to be paused or cancelled by returning a value in the callback
                //<rdar://problem/21367119> [UIA2] The Alert notification should really include the title of the alert
                target.delay(20);
            }
        });
    }

    if (!settings.setSwitchSetting(item, options.switchValue, options.shouldMatchExactly)) {
        throw new UIAError('Failed to enable keychain.');
    }
}
