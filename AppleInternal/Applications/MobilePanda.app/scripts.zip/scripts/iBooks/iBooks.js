load('UIAApp.js');
load('SpringBoard.js');
load('Settings.js');
load('iBooks+QueryGenerator.js');

UIAUtilities.assert(
    typeof ibooks === 'undefined',
    'ibooks undefined'
);

/**
*   @namespace {UIAApp} ibooks
*/
var ibooks = target.appWithBundleID('com.apple.iBooks');

/**
* Constants for tabs - we should only need to change these in one place if UI Changes 
* @namespace
*/
ibooks.TabBarTitles = {
    /** 'My Books' button within a TabBar */
    MY_BOOKS:                               'My Books',
    /** 'Featured' button within a TabBar */
    FEATURED:                               'Featured',
    /** 'Top Charts' button within a TabBar */
    TOP_CHARTS:                             'Top Charts',
    /** 'Search' button within a TabBar */
    SEARCH:                                 'Search',
    /** 'Purchased' button within a TabBar */
    PURCHASED:                              'Purchased',
    /** 'NYTimes' button within a TabBar */
    NYTIMES:                                'NYTimes',
    /** 'Top Authors' button within a TabBar */
    TOP_AUTHORS:                            'Top Authors',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/**
* Constants for common iBooks queries
* @namespace
*/
UIAQuery.iBooks = {

    /** @namespace */
    TabBarButtons: {
        /** 'My Books' button within a TabBar */
        MY_BOOKS:                                   UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.MY_BOOKS)),
        /** 'Featured' button within a TabBar */
        FEATURED:                                   UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.FEATURED)),
        /** 'Top Charts' button within a TabBar */
        TOP_CHARTS:                                 UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.TOP_CHARTS)),
        /** 'Search' button within a TabBar */
        SEARCH:                                     UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.SEARCH)),
        /** 'Purchased' button within a TabBar */
        PURCHASED:                                  UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.PURCHASED)),
        /** 'NYTimes' button within a TabBar */
        NYTIMES:                                    UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.NYTIMES)),
        /** 'Top Authors' button within a TabBar */
        TOP_AUTHORS:                                UIAQuery.tabBars().andThen(UIAQuery.buttons(ibooks.TabBarTitles.TOP_AUTHORS)),
    },

    /** Library Search */
    SEARCH_LIBRARY:                             UIAQuery.searchBars(),

    /** Library button */
    LIBRARY:                                    UIAQuery.buttons('Library'),

    /** List View button */
    LIST_VIEW:                                  UIAQuery.buttons('List view'),

    /** Grid View button */
    GRID_VIEW:                                  UIAQuery.buttons('Grid view').orElse(UIAQuery.buttons('Grid View')),

    /** Collections button: */
    COLLECTIONS:                                UIAQuery.buttons('Collection'),

    /** Collections Edit button: */
    COLLECTIONS_EDIT:                           UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Edit')),

    /********************************/
    /*
    /* Start Toolbar specific Queries
    /*
    /********************************/
    /** Bookmark button in a book */
    BOOK_BOOKMARK:                              UIAQuery.toolbars().andThen(UIAQuery.buttons('Bookmarks')),

    /** Search button in a book */
    BOOK_SEARCH:                                UIAQuery.toolbars().andThen(UIAQuery.buttons('Search')),

    /** Brightness button in a book */
    BOOK_BRIGHTNESS:                            UIAQuery.toolbars().andThen(UIAQuery.buttons('Brightness')),

    /** Font and brightness in a book */
    BOOK_FONT_BRIGHTNESS:                       UIAQuery.toolbars().andThen(UIAQuery.buttons('Font size and brightness')),

    /** Share button in a book */
    BOOK_SHARE:                                 UIAQuery.toolbars().andThen(UIAQuery.buttons('Share')),

    /** Table of contents button in a book */
    BOOK_TABLE_OF_CONTENTS:                     UIAQuery.toolbars().andThen(UIAQuery.buttons('Table of contents')),

    /** Table of contents + glossary in a book */
    BOOK_TABLE_OF_CONTENTS_AND_GLOSSARY:        UIAQuery.toolbars().andThen(UIAQuery.buttons('Table of contents and glossary')),

    /** Notes button in a book */
    BOOK_NOTES:                                 UIAQuery.toolbars().andThen(UIAQuery.buttons('Notes')),
    /********************************/
    /*
    /* End Toolbar specific Queries
    /*
    /********************************/
   
    /********************************/
    /*
    /* Start Audiobook specific Queries
    /*
    /********************************/
    /** Speed button in an audiobook */
    SPEED_BUTTON:                               UIAQuery.buttons().beginsWith('Speed'),

    /** Table of Contents button in an audiobook */
    TABLE_OF_CONTENTS_BUTTON:                   UIAQuery.buttons('Table of Contents'),

    //<rdar://problem/22318224> AX: Audiobooks: VO: Sleep timer isn't descriptive
    /** Sleep Timer button in an audiobook */
    SLEEP_TIMER:                                UIAQuery.buttons().beginsWith('Speed').siblings().rightmost(), //this is a total hack

    /** play button in an audiobook */
    PLAY_BUTTON:                                UIAQuery.buttons('Play'),

    /** pause button in an audiobook */
    PAUSE_BUTTON:                               UIAQuery.buttons('Pause'),

    /** rewind button in an audiobook */
    REWIND_BUTTON:                              UIAQuery.buttons('Rewind 15 seconds'),

    /** fast-forward button in an audiobook */
    FAST_FORWARD_BUTTON:                        UIAQuery.buttons('Fast forward 15 seconds'),
    /********************************/
    /*
    /* End Audiobook specific Queries
    /*
    /********************************/

    /** Generic Back button, We can't use the ones from UIAApp becuase ibooks does weird stuff*/
    BACK:                                       UIAQuery.buttons('Back'),

};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/**
* Constants for possible UI state names specific to iBooks
* @namespace
*/
UIStateDescription.iBooks = {
    /** Shelf in Grid View */
    SHELF_GRID_VIEW:                            'grid view',

    /** Shelf in List View */
    SHELF_LIST_VIEW:                            'list view',

    /** Series Grid View */
    SERIES_GRID_VIEW:                           'series grid view',

    /** Series List View */
    SERIES_LIST_VIEW:                           'series list view',

    /** Select mode in Grid View */
    SHELF_SELECT_GRID_VIEW:                     'select grid view',

    /** Select mode in List View */
    SHELF_SELECT_LIST_VIEW:                     'select list view',

    /** If the collection sheet is open on iPhones */
    COLLECTIONS_SHEET:                          'collection sheet',

    /********************************/
    /*
    /* Start Store specific states
    /*
    /********************************/
    /** Store Search */
    STORE_SEARCH:                               'store search',

    /** Store NYTimes */
    STORE_NYTIMES:                              'store nytimes',

    /** Store Featured */
    STORE_FEATURED:                             'store featured',

    /** Store Purchased */
    STORE_PURCHASED:                            'store purchased',

    /** Store Top Charts*/
    STORE_TOP_CHARTS:                           'store top charts',

    /** Store Authors */
    STORE_TOP_AUTHORS:                          'store top authors',
    /********************************/
    /*
    /* End Store specific states
    /*
    /********************************/

    /********************************/
    /*
    /* Start Audiobook specific states
    /*
    /********************************/
    /** In an audiobook */
    AUDIOBOOK:                                  'audiobook',

    /** Audiobook sleep timer */
    AUDIOBOOK_SLEEP_TIMER:                      'audiobook sleep timer',

    /** Audiobook Speed */
    AUDIOBOOK_SPEED:                            'audiobook speed',

    /** Audiobook Table of Contents */
    AUDIOBOOK_TOC:                              'audiobook toc',
    /********************************/
    /*
    /* End Audiobook specific states
    /*
    /********************************/

    /** Notes View */
    MY_NOTES:                                   'my notes',

    /** Study cards View */
    STUDY_CARDS:                                'study cards',

    /** Study options View */
    STUDY_OPTIONS:                              'study options',

    /** Study options: highlight and notes View */
    HIGHLIGHT_AND_NOTES:                        'highlight and notes',

    /** Chapter notes View */
    CHAPTER_NOTES:                              'chapter notes',

    /** iPhone only! Book search view */
    BOOK_SEARCH:                                'book search',

    /** Appearance Popover */
    APPEARANCE:                                 'book appearance',

    /** Fullscreen video in a book */
    FULLSCREEN_VIDEO:                           'fullscreen video',

    /********************************/
    /*
    /* Start ePub specific states
    /*
    /********************************/
    /** We are in an ePub */
    IN_BOOK_EPUB:                               'in book epub',

    /** ePub ToC */
    EPUB_TOC:                                   'epub toc',

    /** Multitouch ePub TOC */
    MT_EPUB_TOC:                                'mt epub toc',
    /********************************/
    /*
    /* End ePub specific states
    /*
    /********************************/

    /********************************/
    /*
    /* Start PDF specific states
    /*
    /********************************/
    /** We are in a PDF */
    IN_BOOK_PDF:                                'in book pdf',

    /** PDF ToC */
    PDF_TOC:                                    'pdf toc',

    /** PDF Bookmarks */
    PDF_BOOKMARKS:                              'pdf bookmarks',
    /********************************/
    /*
    /* End PDF specific states
    /*
    /********************************/

    /** We are in an MT book */
    IN_BOOK_MT:                                 'in book mt',

    /** In a MT ToC */
    MT_TOC:                                     'mt toc',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
*  Constants for iBooks
*/
ibooks.Constants = {
    IBOOKS:                                     'iBooks',
    LIST:                                       'list',
    GRID:                                       'grid',
    PURCHASED:                                  'purchased',
    ALL:                                        'All',
    NOT_ON_DEVICE:                              'Not on This',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state.
* See iBooks UIStateDescription constants for possible values.
* Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw
* if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in iBooks UIStateDescription.
*
* @throws If cannot determine state.
*/
ibooks.getCurrentUIState = function getCurrentUIState() {
    this.launch();

    // Start library view
    if (this.exists(UIAQuery.iBooks.LIST_VIEW)) {
        return UIStateDescription.iBooks.SHELF_GRID_VIEW;
    }

    if (this.exists(UIAQuery.iBooks.GRID_VIEW)) {
        return UIStateDescription.iBooks.SHELF_LIST_VIEW;
    }

    if (this.exists(UIAQuery.iBooks.BACK) && this.exists(UIAQuery.query('BKLibraryBookshelfView')) ) {
        return UIStateDescription.iBooks.SERIES_GRID_VIEW;
    }

    if (this.exists(UIAQuery.iBooks.BACK) && this.exists(UIAQuery.query('BKLibraryBooksListView')) ) {
        return UIStateDescription.iBooks.SERIES_LIST_VIEW;
    }
    // End library view
    
    // If a video is open in full screen
    if (this.exists('AVPlayerView')) {
        return UIStateDescription.iBooks.FULLSCREEN_VIDEO;
    }

    if (this.exists(UIAQuery.query('BKFlowingBookView')) && this.exists(UIAQuery.query('PaginatingWebView').isVisible())) {
        return UIStateDescription.iBooks.IN_BOOK_EPUB;
    }

    if (this.exists(UIAQuery.query('BKPDFPageView').isVisible())) {
        return UIStateDescription.iBooks.IN_BOOK_PDF;
    }

    if (this.exists(UIAQuery.query('THBookView').isVisible())) {
        if (this.exists(UIAQuery.buttons('Resume'))) {
            return UIStateDescription.iBooks.MT_EPUB_TOC;
        }
        if (this.exists(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS_AND_GLOSSARY.withPredicate('isEnabled == false'))
            ||
            this.exists(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS.withPredicate('isEnabled == false'))) {
            return UIStateDescription.iBooks.MT_TOC;
        }
        if (this.exists(UIAQuery.staticTexts('THWPTOCRep').isVisible())) {
            return UIStateDescription.iBooks.MT_TOC;
        }
        return UIStateDescription.iBooks.IN_BOOK_MT;
    }

    // @TODO optimize how we figure out if we are in shelf view
    if (this.exists(UIAQuery.query('BKLibraryBookshelfBackgroundView')) && this.exists(UIAQuery.buttons('Move'))) {
        return UIStateDescription.iBooks.SHELF_SELECT_GRID_VIEW;
    }

    if (this.exists(UIAQuery.query('BKLibraryBooksListView')) && this.exists(UIAQuery.buttons('Move'))) {
        return UIStateDescription.iBooks.SHELF_SELECT_LIST_VIEW;
    }

    if (this.exists(UIAQuery.navigationBars('Collections'))) {
        return UIStateDescription.iBooks.COLLECTIONS_SHEET;
    }

    if (this.exists(UIAQuery.query('AEImagePlayControl'))) {
        if (this.exists(UIAQuery.query('AEImagePlayControl').isVisible())) {
            return UIStateDescription.iBooks.AUDIOBOOK;
        }
        if (this.exists(UIAQuery.query('AEAudiobookTOCView'))) {
            return UIStateDescription.iBooks.AUDIOBOOK_TOC;
        }
        var nav = this.inspect(UIAQuery.navigationBars().isVisible());
        switch (nav.name) {
            case 'Sleep Timer':
                return UIStateDescription.iBooks.AUDIOBOOK_SLEEP_TIMER;
                break;
            case 'Speed':
                return UIStateDescription.iBooks.AUDIOBOOK_SPEED;
                break;
            default:
                //new audiobook state?
                UIALogger.logMessage('Unknown state in "Audiobook"');
        }
    }

    if (this.exists(UIAQuery.tableViews().andThen(UIAQuery.query('Recent Searches')))) {
        return UIStateDescription.iBooks.BOOK_SEARCH;
    }

    /**
    * Start Notes section
    */
    var navbars = this.inspect(UIAQuery.navigationBars());
    if (navbars) {
        switch (navbars.name) {
            case 'Study Options':
                return UIStateDescription.iBooks.STUDY_OPTIONS;
                break;
            case 'Highlights and Notes':
                return UIStateDescription.iBooks.HIGHLIGHT_AND_NOTES;
                break;
            case 'Chapters':
                return UIStateDescription.iBooks.CHAPTER_NOTES;
                break;
            case 'My Notes':
                if (this.exists(UIAQuery.navigationBars('My Notes').isVisible())) {
                    return UIStateDescription.iBooks.MY_NOTES;
                }

                if (this.exists(UIAQuery.buttons('Configure'))) {
                    return UIStateDescription.iBooks.STUDY_CARDS;
                }
                UIALogger.logMessage('Unknown state in "My Notes"');
                break;
            default:
        //keep lookin
        }
    }
    /**
    * End Notes section
    */

    /**
    * Start ePub ToC section
    */
    if (this.exists(UIAQuery.query('BKSwitcherContentContainerView'))) {
        return UIStateDescription.iBooks.EPUB_TOC;
    }
    /**
    * End ePub ToC section
    */

    /**
    * Start PDF section
    */

    if (this.exists(UIAQuery.query('BKSegmentedControl').andThen(UIAQuery.buttons('Bookmarks').isSelected()))) {
    //if (this.exists(UIAQuery.query("IMGridView").andThen(UIAQuery.query('BKTOCBookmarksDescription')))) {
        return UIStateDescription.iBooks.PDF_BOOKMARKS;
    }

    if (this.exists(UIAQuery.query('BKSegmentedControl').andThen(UIAQuery.buttons('Grid view').isSelected()))) {
    //if (this.exists(UIAQuery.query("IMGridView").andThen(UIAQuery.contains('BKThumbnailDirectoryCell')))) {
        return UIStateDescription.iBooks.PDF_TOC;
    }
    /**
    * End PDF section
    */
   
    if (this.exists(UIAQuery.sliders('BrightnessSlider'))) {
        return UIStateDescription.iBooks.APPEARANCE;
    }

    // Tab bar at the bootom of iBooks
    var tabBar = this.inspect(UIAQuery.tabBars('UITabBar').children().isSelected());
    if (tabBar) {
        switch (tabBar.name) {
            case ibooks.TabBarTitles.FEATURED:
                return UIStateDescription.iBooks.STORE_FEATURED;
                break;
            case ibooks.TabBarTitles.TOP_CHARTS:
                return UIStateDescription.iBooks.STORE_TOP_CHARTS;
                break;
            case ibooks.TabBarTitles.PURCHASED:
                return UIStateDescription.iBooks.STORE_PURCHASED;
                break;
            case ibooks.TabBarTitles.SEARCH:
                return UIStateDescription.iBooks.STORE_SEARCH;
                break;
            case ibooks.TabBarTitles.NYTIMES:
                return UIStateDescription.iBooks.STORE_NYTIMES;
                break;
            case ibooks.TabBarTitles.TOP_AUTHORS:
                return UIStateDescription.iBooks.STORE_TOP_AUTHORS;
                break;
            default:
        }
    }

    // if we get to here, we have no idea where we are...
    throw new UIAError('Cannot determine application state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Current UI State Helpers                                            */
/*                                                                             */
/*      Functions that help determine which UIState the app is currently in    */
/*                                                                             */
/*******************************************************************************/

/**
* Whether or not we are in library view
*
* @param {string} state optional state to pass in from {getCurrentUIState()}
*
* @return {bool|string} state string if we are in the library otherwise false
*/
ibooks.inLibrary = function inLibrary(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }
    if (state === UIStateDescription.iBooks.SHELF_GRID_VIEW || state === UIStateDescription.iBooks.SHELF_LIST_VIEW) {
        return state;
    }
    return false;
}

/**
* Determines if we are in a book
*
* @param {string} state optional state to pass in from {getCurrentUIState()}
*
* @return {bool|string} returns the state string if we are in a book otherwise false
*/
ibooks.inBook = function inBook(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }
    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_MT:
        case UIStateDescription.iBooks.IN_BOOK_PDF:
        case UIStateDescription.iBooks.IN_BOOK_EPUB:
            return state;

        default:
            return false;
    }
}

/**
* Determines if we are in the store
*
* @param {string} state optional state to pass in from {getCurrentUIState()}
*
* @return {bool|string} returns state string if we are in the store otherwise false
*/
ibooks.inStore = function inStore(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }
    switch (state) {
        case UIStateDescription.iBooks.STORE_SEARCH:
        case UIStateDescription.iBooks.STORE_NYTIMES:
        case UIStateDescription.iBooks.STORE_FEATURED:
        case UIStateDescription.iBooks.STORE_PURCHASED:
        case UIStateDescription.iBooks.STORE_TOP_CHARTS:
        case UIStateDescription.iBooks.STORE_TOP_AUTHORS:
            return state;

        default:
            return false;
    }
}

/**
 * Determines if we are in the Main View of iBooks
 * 
 * @param {string} state optional state to pass in from {getCurrentUIState()}
 * 
 * @return {bool|string} returns state string if we are in the store otherwise false
 */
ibooks.inMainView = function inMainView(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }
    switch (state) {
        case UIStateDescription.iBooks.SHELF_GRID_VIEW:
        case UIStateDescription.iBooks.SHELF_LIST_VIEW:
        case UIStateDescription.iBooks.STORE_SEARCH:
        case UIStateDescription.iBooks.STORE_NYTIMES:
        case UIStateDescription.iBooks.STORE_FEATURED:
        case UIStateDescription.iBooks.STORE_PURCHASED:
        case UIStateDescription.iBooks.STORE_TOP_CHARTS:
        case UIStateDescription.iBooks.STORE_TOP_AUTHORS:
            return state;

        default:
            return false;
    }

}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigate to a tab (tab bar at the bottom of iBooks)
* Assumes that you are in library view
*
* @param  {string} tab - Name of the tab to navigate to
*
* @throws throws when attempting to navigate to a tab that doesn't exist.
*/
ibooks.getToTab = function getToTab(tab) {
    switch (tab) {
        case ibooks.TabBarTitles.MY_BOOKS:
            this.tap(UIAQuery.iBooks.TabBarButtons.MY_BOOKS);
            break;
        case ibooks.TabBarTitles.FEATURED:
            this.tap(UIAQuery.iBooks.TabBarButtons.FEATURED);
            break;
        case ibooks.TabBarTitles.TOP_CHARTS:
            this.tap(UIAQuery.iBooks.TabBarButtons.TOP_CHARTS);
            break;
        case ibooks.TabBarTitles.PURCHASED:
            this.tap(UIAQuery.iBooks.TabBarButtons.PURCHASED);
            break;
        case ibooks.TabBarTitles.SEARCH:
            this.tap(UIAQuery.iBooks.TabBarButtons.SEARCH);
            break;
        case ibooks.TabBarTitles.NYTIMES:
            this.tap(UIAQuery.iBooks.TabBarButtons.NYTIMES);
            break;
        case ibooks.TabBarTitles.TOP_AUTHORS:
            this.tap(UIAQuery.iBooks.TabBarButtons.TOP_AUTHORS);
            break;
        default:
            // should never get here
            throw new UIAError("Could not get to unknown tab: '%0'.".format(tab));
    }
}

/**
* Attempt to get to the library view, launches iBooks if it isn't already open
*
* @param {string} view - Whether we should navigate to `list` or `grid` view or just leave it
*
* @throws if we can't make it back to the shelf :(
*/
ibooks.getToLibrary = function getToLibrary(view) {
    this.launch();

    var state = this.getCurrentUIState();

    if (this.inLibrary(state)) {
        this._switchLibraryView(view);
        return;
    }

    this._dismissBookItems();

    // @TODO this returns a true if successful
    this.returnToTopLevel();

    this.tapIfExists(UIAQuery.iBooks.BACK.isVisible());
    if (this.inBook()) {
        this.showBookToolbar();
    }
    
    state = this.getCurrentUIState();
    if (state === UIStateDescription.iBooks.MT_EPUB_TOC) {
        //we need to scroll to the top :/
        var has_thrown = false;
        var loop_of_fun = 1;
        while(!has_thrown) {
            try {
                this.scrollUp('TSWTableView');
                //if we scroll to fast then no exception is thrown
                //<rdar://problem/22192102> [UIA2] app.scrollUp() doesn't throw if called very fast
                this.delay(0.5);
                loop_of_fun++;
                if (loop_of_fun > 5) {
                    throw new UIAError('Scrolled up 5 times and did not hit an exception!');
                }
            } catch (e) {
                has_thrown = true;
            }
        }
        this.tap(UIAQuery.query("TSWTableView"), {offset: {x: 0.50, y: 0.10}})
        // <rdar://problem/21753712> UIA2: iBooks: No Notification when toolbar shows or hides.
        this.delay(1);
    }

    if (this.exists(UIAQuery.iBooks.LIBRARY.isVisible())) {
        var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "BKLibraryBookshelfViewController" OR controllerClass == "BKLibraryBooksListViewController"'});
        this.tap(UIAQuery.iBooks.LIBRARY.isVisible());
        if (!waiter.wait(10)) {
            throw new UIAError("Book didn't close");
        }
    }

    // @TODO add in a waiter here
    this.tapIfExists(UIAQuery.iBooks.BACK.isVisible());

    if (this.inStore()) {
        this.tap(UIAQuery.iBooks.TabBarButtons.MY_BOOKS);
    }

    if (!this.inLibrary()) {
        throw new UIAError('Could not make it back to library view.');
    }
    this._switchLibraryView(view);
}

/**
* Navigate to the "All Books" Collection
*
* @throws Throws if it can't get to the "All Books" Collection
*/
ibooks.getToAllBooks = function getToAllBooks() {
    this.goToCollection();

    //I don't think this exception is ever hit?
    if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) != 'All Books') {
        throw new UIAError('Could not navigate to "All Books"')
    }
}

/**
* Navigate to a collection of the specified name
*
* @param {object} options - Args Dictionary
* @param {string} [options.name="All Books"] - Name of the collection to navigate to
*
* @throws if unable to find collection
*/
ibooks.goToCollection = function goToCollection(args) {
    args = UIAUtilities.defaults(args, {
        name: 'All Books', //remember this is actually "All" in the popover
    });

    if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) != args.name) {
        if (args.name === 'All Books') {
            args.name = 'All';
        }
        UIALogger.logMessage('Change collection to "%0"'.format(args.name));
        var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
        this.tap(UIAQuery.iBooks.COLLECTIONS);
        if (!waiter.wait(2)) {
            throw new UIAError('Collections Sheet never appeared');
        }

        if (this.exists(args.name)) {
            waiter = UIAWaiter.waiter('ViewDidDisappear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
            this.tap(args.name);
            if (!waiter.wait(2)) {
                throw new UIAError('Collections Sheet never disappeared');
            }
        } else {
            throw new UIAError('Unable to find collection with name: %0'.format(args.name));
        }
    }
}

/**
 * Get to the default book state (you are looking at the contents of a book)
 * 
 * @return {bool} true on success
 *
 * @throws If you are not in a book, or it can't get back to the default state
 */
ibooks.getToDefaultBookState = function getToDefaultBookState() {
    var state = this.getCurrentUIState();
    if (this.inLibrary(state)) {
        throw new UIAError('You must be in a book to call this function!');
    }
    if (this.inBook(state)) {
        //have to make sure we do this
        this._dismissBookItems();
        return true;
    }
    if (state === UIStateDescription.iBooks.MT_EPUB_TOC) {
        //we need to scroll to the top :/
        var has_thrown = false;
        while(!has_thrown) {
            try {
                this.scrollUp('TSWTableView');
                //if we scroll to fast then no exception is thrown
                //<rdar://problem/22192102> [UIA2] app.scrollUp() doesn't throw if called very fast
                this.delay(0.5);
            } catch (e) {
                has_thrown = true;
            }
        }
        this.tap(UIAQuery.query("TSWTableView"), {offset: {x: 0.50, y: 0.10}})
        // <rdar://problem/21753712> UIA2: iBooks: No Notification when toolbar shows or hides.
        this.delay(1);
    } else {
        this.returnToTopLevel();
    }
    this.tapIfExists('Resume');
    this._dismissBookItems();
    if (this.inBook()) {
        return true;
    }
    throw new UIAError('Could not get back to default book state!');
}

/**
 * Navigates to the Purchased tab and optionally a sub tab
 * 
 * @param  {string} tab Tab to navigate to, either `ibooks.Constants.ALL` or `ibooks.Constants.NOT_ON_DEVICE`
 */
ibooks.goToPurchased = function goToPurchased(tab) {
    if (!this.inMainView()) {
        this.getToLibrary();
    }
    this.getToTab(ibooks.TabBarTitles.PURCHASED);
    switch(tab){
        case ibooks.Constants.ALL:
            this.tap(UIAQuery.segmentedControls().andThen(UIAQuery.buttons(ibooks.Constants.ALL)));
            break;
        case ibooks.Constants.NOT_ON_DEVICE:
            this.tap(UIAQuery.segmentedControls().andThen(UIAQuery.buttons().beginsWith(ibooks.Constants.NOT_ON_DEVICE)));
        default:
            //nothin
            break;
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
* Run a basic quick look test
*
* @throws on failure
*/
ibooks.verifyLibraryStatesAndOrientations = function verifyLibraryStatesAndOrientations() {
    var initial_orientation = target.deviceOrientation();
    try {
        this.getToLibrary(ibooks.Constants.GRID);

        //TEST GRID VIEW
        var state = this.getCurrentUIState();
        if (state === UIStateDescription.iBooks.SHELF_LIST_VIEW) {
            this.tap(UIAQuery.iBooks.GRID_VIEW);
        }

        target.setDeviceOrientation(UIAInterfaceOrientation.LANDSCAPE_RIGHT);

        state = this.getCurrentUIState();
        if (state !== UIStateDescription.iBooks.SHELF_GRID_VIEW) {
            throw new UIAError('Not in Grid View! Rotation changed UI State!');
        }

        target.setDeviceOrientation(UIAInterfaceOrientation.PORTRAIT);

        state = this.getCurrentUIState();
        if (state !== UIStateDescription.iBooks.SHELF_GRID_VIEW) {
            throw new UIAError('Not in Grid View! Rotation changed UI State!');
        }

        //TEST LIST VIEW
        state = this.getCurrentUIState();
        if (state === UIStateDescription.iBooks.SHELF_GRID_VIEW) {
            ibooks.tap(UIAQuery.iBooks.LIST_VIEW);
        }

        target.setDeviceOrientation(UIAInterfaceOrientation.LANDSCAPE_RIGHT);

        state = this.getCurrentUIState();
        if (state !== UIStateDescription.iBooks.SHELF_LIST_VIEW) {
            throw new UIAError('Not in List View! Rotation changed UI State!');
        }

        target.setDeviceOrientation(UIAInterfaceOrientation.PORTRAIT);

        state = this.getCurrentUIState();
        if (state !== UIStateDescription.iBooks.SHELF_LIST_VIEW) {
            throw new UIAError('Not in List View! Rotation changed UI State!');
        }

        //TEST Swiping in grid view
        var state = this.getCurrentUIState();
        if (state === UIStateDescription.iBooks.SHELF_LIST_VIEW) {
            this.tap(UIAQuery.iBooks.GRID_VIEW);
        }

        this.getToAllBooks();

        UIALogger.logMessage('Collections = ' + this.valueOf(UIAQuery.iBooks.COLLECTIONS));
        this.swipeLeft(UIAQuery.query('IMGridView'));
        if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) !== 'Books') {
            throw new UIAError('Could not navigate to "Books"');
        }
        UIALogger.logMessage('Collections = ' + this.valueOf(UIAQuery.iBooks.COLLECTIONS));
        this.swipeLeft(UIAQuery.query('IMGridView'));
        if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) !== 'Audiobooks') {
            throw new UIAError('Could not navigate to "Audiobooks"');
        }
        UIALogger.logMessage('Collections = ' + this.valueOf(UIAQuery.iBooks.COLLECTIONS));
        this.swipeLeft(UIAQuery.query('IMGridView'));
        if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) !== 'PDFs') {
            throw new UIAError('Could not navigate to "PDFs"');
        }
        UIALogger.logMessage('Collections = ' + this.valueOf(UIAQuery.iBooks.COLLECTIONS));

        // ADD NEW COLLECTION AND ADD A BOOK TO IT
        this.addNewCollection({
            name: 'Test Collection',
            unique: false,
        })

        UIALogger.logMessage('Go back to All Books');
        if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) !== 'All Books') {
            UIALogger.logMessage('Change collection to All Books');
            this.goToCollection();
        }

        this.moveToCollection({
            book: '', //first book
            collection: 'Test Collection',
        })

        if (this.valueOf(UIAQuery.iBooks.COLLECTIONS) !== 'Test Collection') {
            throw new UIAError('Did not navigate to test collection!');
        }
        if (this.getNumberOfBooksInColllection() === 0) {
            throw new UIAError('No Books in collection!')
        }
    } finally {
        target.setDeviceOrientation(initial_orientation);
    }
}

/**
* Check preferences and launch and quit iBooks
*
* @throws on failure
*/
ibooks.verifySettingsAndLaunch = function verifySettingsAndLaunch() {
    settings.launch();
    if (!settings.navigateNavigationViews(['iBooks'])) {
        throw new UIAError('Settings page for iBooks does not exist!');
    }
    if (!settings.exists(UIAQuery.navigationBars('iBooks'))) {
        throw new UIAError('iBooks panel is not named iBooks');
    }

    try {
        this.quit();
    } catch (e) {
        //Sometimes quit() doesn't work on smaller screened devices... so we go the dangerous way
        //<rdar://problem/20977838> New app switcher never returns pageIndex == 0 on N51
        UIALogger.logWarning('quit() failed, performing killall');
        target.performTask('/usr/bin/killall', ['iBooks']);
        target.clickMenu();
    }
    
    this.getToLibrary();
    if (!this.inLibrary()) {
        throw new UIAError('Not in grid or list view!');
    }

    // <rdar://problem/21770026> [UIA2] Launching with the app switcher doesn't work
    //this.deactivateForDuration(3);
    target.clickMenu();
    this.delay(3);
    this.launch();
    if (!this.inLibrary()) {
        throw new UIAError('Not in grid or list view!');
    }
}

/**
* Open iBooks and verify the tabs we want are there and work
*
* @throws on error
*/
ibooks.launchAndVerifyTabs = function launchAndVerifyTabs() {
    UIALogger.logMessage('Launch iBooks and get to library view');
    this.getToLibrary();

    UIALogger.logMessage('Navigate to Purchased Tab');
    this.getToTab(ibooks.TabBarTitles.PURCHASED);
    this.assertSelected(
        UIAQuery.iBooks.TabBarButtons.PURCHASED,
        'Purchased tab was not selected!'
    );

    UIALogger.logMessage('Navigate to Top Charts Tab');
    this.getToTab(ibooks.TabBarTitles.TOP_CHARTS);
    this.assertSelected(
        UIAQuery.iBooks.TabBarButtons.TOP_CHARTS,
        'Top Charts tab was not selected!'
    );

    if (target.model() !== 'iPad') {
        UIALogger.logMessage('Navigate to Search Tab');
        this.getToTab(ibooks.TabBarTitles.SEARCH);
        this.assertSelected(
            UIAQuery.iBooks.TabBarButtons.SEARCH,
            'Search tab was not selected!'
        );
    } else {
        UIALogger.logMessage('Navigate to NYTimes Tab');
        this.getToTab(ibooks.TabBarTitles.NYTIMES);
        this.assertSelected(
            UIAQuery.iBooks.TabBarButtons.NYTIMES,
            'NYTimes tab was not selected!'
        );

        UIALogger.logMessage('Navigate to Top Authors Tab');
        this.getToTab(ibooks.TabBarTitles.TOP_AUTHORS);
        this.assertSelected(
            UIAQuery.iBooks.TabBarButtons.TOP_AUTHORS,
            'Top Authors tab was not selected!'
        );
    }

    UIALogger.logMessage('Navigate to Featured Tab');
    this.getToTab(ibooks.TabBarTitles.FEATURED);
    this.assertSelected(
        UIAQuery.iBooks.TabBarButtons.FEATURED,
        'Featured tab was not selected!'
    );

    UIALogger.logMessage('Navigate to My Books Tab');
    this.getToTab(ibooks.TabBarTitles.MY_BOOKS);
    this.assertSelected(
        UIAQuery.iBooks.TabBarButtons.MY_BOOKS,
        'My Books tab was not selected!'
    );
}

/**
 * Open an audiobook then quit iBooks
 *
 * @param {object} options
 * @param {string} [options.name=""] - Optional parameter to filter book query by
 */
ibooks.openAudiobook = function openAudiobook(options) {
    options = UIAUtilities.defaults(options, {
        name: '',
    });

    ibooks.getToLibrary('list');

    var q = new iBooksQueryGenerator();
    q.isIniCloud(false);
    q.isAudioBook();
    q.isDownloading(false);
    if (options.name) {
        q.filter(options.name);
    }
    
    if (q.getCount() == 0) {
        throw new UIAError('Unable to find audiobook matching query!');
    }

    var query = q.getQuery();

    var booklabel = ibooks.inspect(query).label;
    UIALogger.logDebug('Opening audiobook "%0"'.format(booklabel));

    this.tap(query);
}

/**
 * Quit iBooks and then launch it again
 */
ibooks.quitAndLaunch = function quitAndLaunch() {

        var quit_waiter = UIAWaiter.waiter('ApplicationStateChanged', {predicate: 'bundleID == "com.apple.iBooks" AND state == "Terminated"'});
        
        try {
            this.quit();
        } catch (e) {
            //Sometimes quit() doesn't work on smaller screened devices... so we go the dangerous way
            //<rdar://problem/20977838> New app switcher never returns pageIndex == 0 on N51
            UIALogger.logWarning('quit() failed, performing killall');
            target.performTask('/usr/bin/killall', ['iBooks']);
            target.clickMenu();
        }

        // @TODO remove this waiter
        // <rdar://problem/22120767> UIA2: make app.quit() blocking
        quit_waiter.wait(10);

        this.launch();
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
* Creates a query of all books that are downloaded
*
* @return {UIAQuery} Query for books that are downloaded
*/
ibooks.getDownloadedBooks = function getDownloadedBooks() {
    var q = new iBooksQueryGenerator();
    q.isIniCloud(false);
    return q.getQuery();
}

/**
* Returns the number of items in the current collection that are on the device
*
* @returns {int}
*
* @throws if cannot determine UI state
*/
ibooks.getNumberOfBooksInCollection = function getNumberOfBooksInCollection() {
    var q = new iBooksQueryGenerator();
    return this.count(q.getQuery());
}

/**
* Open a book
*
* @targetApps iBooks
*
* @note Default test (no arguments) opens first book
*
* @param {object} options - Test arguments
* @param {string} [options.book=''] - Name of book
* @param {boolean} [options.allbooks=false] - Whether or not we should navigate to all books before trying to open a book
*
* @throws if there are no books in the collection
*/
ibooks.openBook = function openBook(options) {
    options = UIAUtilities.defaults(options, {
        book: '',
        allbooks: false,
    });

    if (!this.inLibrary()) {
        this.getToLibrary();
    }

    if (options.allbooks) {
        this.getToAllBooks();
    }

    if (!this.getNumberOfBooksInColllection()) {
        throw new UIAError('There are no valid items in the current collection')
    }

    var q = new iBooksQueryGenerator();
    q.isIniCloud(false);
    if (options.book) {
        q.filter(options.book);
    }

    this.tap(q.getQuery());
}

/**
* Show the toolbar if it isn't shown in a book
* @TODO: Maybe works
*
* @return {bool} - returns false if we didn't find the toolbar or true if it worked
*/
ibooks.showBookToolbar = function showBookToolbar() {
    if (this._toolbarVisible()) {
        return true;
    }
    UIALogger.logMessage('Toolbar is not visible.')

    var state = this.getCurrentUIState();
    var scrollview = this._getScrollviewNameFromState(state);
    if (scrollview) {
        var q_scrollview = UIAQuery.scrollViews(scrollview).isVisible();
        this.tap(q_scrollview, {offset: {x: 0.5, y: 0.05}});
        // <rdar://problem/21753712> UIA2: iBooks: No Notification when toolbar shows or hides.
        //
        // Use other waiter look at FAQ
        this.delay(1);
        if (this._toolbarVisible()) {
            return true;
        }
        return false;
    }
    return false;
}

/**
* Add a new collection of the specified name
*
* @param {object} options - Options Dictionary
* @param {string} [options.name="Test Collection"] - Name of the new collection to add
* @param {bool} [options.unique=true] - Whether or not we should add a collection if ones already exists with that name
* @param {bool} [options.check_state=true] - whether we should check where we are before trying to add stuff
*
* @throws if it hits any issues on the way
*/
ibooks.addNewCollection = function addNewCollection(options) {
    options = UIAUtilities.defaults(options, {
        name: 'Test Collection',
        unique: true,
        check_state: true,
    });
    if (options.check_state) {
        if (!this.inLibrary()) {
            this.getToLibrary();
        }
    }
    if (options.unique) {
        try {
            this.goToCollection({name: options.name});
            return;
        } catch (e) { //collection exists
            this.tapIfExists(UIAQuery.buttons('Done').isVisible());
        }
    }

    var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
    this.tap(UIAQuery.iBooks.COLLECTIONS);
    if (!waiter.wait(2)) {
        throw new UIAError('Collections Sheet never appeared');
    }

    waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "UICompatibilityInputViewController"'});
    this.tap(UIAQuery.staticTexts('New Collection'));
    if (!waiter.wait(2)) {
        throw new UIAError('Keyboard never appeared');
    }

    this.typeString(options.name);

    waiter = UIAWaiter.waiter('ViewDidDisappear', {predicate: 'controllerClass == "UICompatibilityInputViewController"'});
    this.tapIfExists("Done");
    if (!waiter.wait(2)) {
        throw new UIAError('Keyboard never disappeared');
    }
    var done = UIAQuery.buttons('Done').isVisible();
    if (this.exists(done)) {
        this.tap(done);
    } else { //popover
        this.dismissPopover();
    }
}

/**
* Moves the specified to a collection of the specified name
*
* @param {object} options - Args Dictionary
* @param {string} [options.book=""] - Name of the book to move
* @param {string} [options.collection=""] - Name of the colleciton to move the book to
*
* @throws if unable to find collection or book
*/
ibooks.moveToCollection = function moveToCollection(args) {
    args = UIAUtilities.defaults(args, {
        book: '',
        collection: false,
    });

    if (args.collection === false) {
        throw new UIAError('Collection arg is required.')
    }

    this.tap('Select');
    var book = this.findBook(args.book);
    if (!book) {
        throw new UIAError('Unable to find book: "%0"'.format(args.book))
    }
    this.tap(book);
    var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
    this.tap('Move');
    if (!waiter.wait(2)) {
        throw new UIAError('Collection sheet never appeared');
    }

    if (this.exists(args.collection)) {
        waiter = UIAWaiter.waiter('ViewDidDisappear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
        this.tap(args.collection);
        if (!waiter.wait(4)) {
            throw new UIAError('Collection sheet never disappeared');
        }
    } else {
        throw new UIAError('Unable to find collection with name: "%0"'.format(args.collection));
    }
}

/**
* Deletes a collection by name
*
* @param {object} options - Args Dictionary
* @param {bool} [options.deleteBooks=false] - Whether or not we should delete the books in the collection also.
* @param {string} [options.collection=false] - Name of the colleciton to delete
* @param {bool} [options.check_state] - Whether or not we should check the current UI state
*
* @throws if unable to find collection or delete fails
*/
ibooks.deleteCollection = function deleteCollection(options) {
    options = UIAUtilities.defaults(options, {
        deleteBooks: false,
        collection: false,
        check_state: true,
    });
    if (options.collection === false) {
        throw new UIAError('Collection option is required.');
    }
    if (options.check_state) {
        if (!this.inLibrary()) {
            this.getToLibrary();
        }
    }

    var waiter = UIAWaiter.waiter('ViewDidAppear', {predicate: 'controllerClass == "BKCollectionsListViewController"'});
    this.tap(UIAQuery.iBooks.COLLECTIONS);
    if (!waiter.wait(2)) {
        throw new UIAError('Collections Sheet never appeared');
    }
    //we use this later to verify that something was actually deleted
    var count = this.count(UIAQuery.tableCells().children().andThen(UIAQuery.staticTexts(options.collection)));
    if (count == 0) {
        throw new UIAError('Collection does not exist.');
    }

    this.tap(UIAQuery.iBooks.COLLECTIONS_EDIT);
    //var q = UIAQuery.buttons().withPredicate('label BEGINSWITH "Delete "').siblings().andThen(UIAQuery.staticTexts(options.collection));
    // @TODO need to strip extra whitespace from the collection name for some reason
    var q = UIAQuery.buttons('Delete %0'.format(options.collection));
    this.tap(q);
    this.tap(UIAQuery.buttons('Delete'));
    // Alert only pops up if there are books in the collection
    if (this.exists(UIAQuery.alerts())) {
        this.handlingAlertsInline(
            UIAQuery.alerts('Delete Collection?'),
            function() {
                if (options.deleteBooks) {
                    this.tap('Delete Collection and Content');
                } else {
                    this.tap('Delete Collection Only');
                }
            }
        );
    }

    this.tap('Done');
    var new_count = UIAQuery.tableCells().children().andThen(UIAQuery.staticTexts(options.collection));
    UIAUtilities.assertEqual(count - 1, this.count(new_count), 'Collection was not deleted');
}

/**
 * Swipe to the next page in a book
 *
 * @param {bool} [options.skip_check=false] Whether or not we should skip checking the UI state
 * @param {bool} [options.is_mt=false] this is only used if {@link skip_check} is true, if the book is a multi touch book
 * @param {bool} [options.verify_swipe=true] Whether we should verify that we changed pages
 * @param {bool} [options.allow_same_page=false] if true, we will not throw if we end up on the same page that we started
 *
 * @param {bool} Returns true if all is well or false if we don't go to the next page but don't throw
 * 
 * @throws if swipe fails or we aren't in a book or we can't get to the next page
 */
ibooks.swipeToNextPage = function swipeToNextPage(options) {
    options = UIAUtilities.defaults(options, {
        skip_check: false,
        state: this.getCurrentUIState(),
        verify_swipe: true,
        allow_same_page: false,
    });
    if (!options.skip_check) {
        var book_state = this.inBook(options.state);
        if (!book_state) {
            throw new UIAError('Unable to swipe, not in a book: %0'.format(book_state));
        }
    }

    var query = UIAQuery.application();
    if (options.state === UIStateDescription.iBooks.IN_BOOK_MT) {
        query = UIAQuery.scrollViews().isVisible();
    }
    if (options.verify_swipe) {
        var currentpage = this.getCurrentPageNumber(options.state);
        var pagecount = this.getLastPageNumber(options.state);
    }

    // we can't swipe in a straight line because the gesture recognizer is weird and doesn't always recognize that
    this.drag(query, {fromOffset:{x:0.95, y:0.5}, toOffset:{x:0.1, y:0.7}, duration:0.25});

    if (options.verify_swipe) {
        //we need these delays for MT books when we switch chapters :(
        if (options.state === UIStateDescription.iBooks.IN_BOOK_MT) {
            this.waitUntilPresent(UIAQuery.activityIndicators(), 1);
            this.waitUntilAbsent(UIAQuery.activityIndicators(), 1);
        }
        var next_currentpage = this.getCurrentPageNumber(options.state);
        var next_pagecount = this.getLastPageNumber(options.state);

        if (next_currentpage === currentpage + 1) {
            return true;
        }

        if (next_currentpage === currentpage) {
            if (!options.allow_same_page) {
                throw new UIAError('Swiped to same page!');
            }
            return false;
        }
        throw new UIAError('Swiping to next page failed! (did we go backwards?)');
    }
}

/**
 * Swipe to the previous page in a book
 *
 * @param {bool} [options.skip_check=false] Whether or not we should skip checking the UI state
 * @param {string} [options.state={getCurrentUIState()}] pass in the current UI state to speed up queries
 * @param {bool} [options.verify_swipe=true] Whether we should verify that we changed pages
 * @param {bool} [options.allow_same_page=false] if true, we will not throw if we end up on the same page that we started
 *
 * @param {bool} Returns true if all is well or false if we don't go to the previous page but don't throw
 * 
 * @throws if swipe fails or we aren't in a book or we can't get to the previous page
 */
ibooks.swipeToPreviousPage = function swipeToPreviousPage(options) {
    options = UIAUtilities.defaults(options, {
        skip_check: false,
        state: this.getCurrentUIState(),
        verify_swipe: true,
        allow_same_page: false,
    });
    if (!options.skip_check) {
        var book_state = this.inBook(options.state);
        if (!book_state) {
            throw new UIAError('Unable to swipe, not in a book: %0'.format(book_state));
        }
    }

    var query = UIAQuery.application();
    if (options.state === UIStateDescription.iBooks.IN_BOOK_MT) {
        query = UIAQuery.scrollViews().isVisible();
    }
    if (options.verify_swipe) {
        var currentpage = this.getCurrentPageNumber(options.state);
        var pagecount = this.getLastPageNumber(options.state);
    }

    // we can't swipe in a straight line because the gesture recognizer is weird and doesn't always recognize that
    this.drag(query, {toOffset:{x:0.95, y:0.5}, fromOffset:{x:0.1, y:0.7}, duration:0.25});

    if (options.verify_swipe) {
        //we need these delays for MT books when we switch chapters :(
        if (options.state === UIStateDescription.iBooks.IN_BOOK_MT) {
            this.waitUntilPresent(UIAQuery.activityIndicators(), 1);
            this.waitUntilAbsent(UIAQuery.activityIndicators(), 1);
        }
        var next_currentpage = this.getCurrentPageNumber(options.state);
        var next_pagecount = this.getLastPageNumber(options.state);

        if (next_currentpage === currentpage - 1) {
            return true;
        }

        if (next_currentpage === currentpage) {
            if (!options.allow_same_page) {
                throw new UIAError('Swiped to same page!');
            }
            return false;
        }
        throw new UIAError('Swiping to previous page failed! (did we go forwards?)');
    }
}

/**
 * Swipe to the last page in a book
 * 
 * @return {bool} true if we get to the last page
 *
 * @throws when we swipe backward (somehow)
 */
ibooks.swipeToLastPage = function swipeToLastPage() {
    var state = this.getCurrentUIState();

    while (true) {
        var res = this.swipeToNextPage({
            skip_check: true,
            state: state,
            allow_same_page: true,

        });

        // We made it to the last page!!!!
        if (!res) {
            return true;
        }
    }
}

/**
 * Swipe to the first page in a book
 * 
 * @return {bool} true if we get to the first page
 *
 * @throws when we swipe forward (somehow)
 */
ibooks.swipeToFirstPage = function swipeToFirstPage() {
    var state = this.getCurrentUIState();

    while (true) {
        var res = this.swipeToPreviousPage({
            skip_check: true,
            state: state,
            allow_same_page: true,

        });

        // We made it to the first page!!!!
        if (!res) {
            return true;
        }
    }
}

/**
* Finds a book by name/author and returns a query
*
* @param  {string} book - Name of the book or author
*
* @return {bool|UIAQuery} false if the book was not found or UIAQuery for the book
*/
ibooks.findBook = function findBook(book) {

    var q = new iBooksQueryGenerator().filter(book).getQuery();
    if (this.exists(q)) {
        return q;
    }
    return false;
}

/**
 * Get to a specific chapter in a book
 * @TODO only works in epubs and RMT right now
 * @TODO search subchapters in RMT
 * 
 * @param  {string|int} chapter Chapter name or number (for MT books)
 * @param  {string} subchapter Optional sub chapter name, only used in MT and MT ePubs
 *
 * @return {bool} Returns true if all is well, false if we are in an unknown state
 * 
 * @throws if an error is encountered or the chapter name is not valid.
 */
ibooks.goToChapter = function goToChapter(chapter, subchapter) {
    var state = this.getCurrentUIState();
    if (state !== UIStateDescription.iBooks.MT_EPUB_TOC || UIStateDescription.iBooks.MT_TOC) {
        this.getToDefaultBookState();

        if (!this.showBookToolbar()) {
            throw new UIAError('Could not get toolbar to show!');
        }
    }

    if (this.exists(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS)) {
        this.tap(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS);
        if (state === UIStateDescription.iBooks.IN_BOOK_EPUB) {
            this._getToTOCTab('Contents');
        }
    } else if (this.exists(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS_AND_GLOSSARY)) {
        this.tap(UIAQuery.iBooks.BOOK_TABLE_OF_CONTENTS_AND_GLOSSARY);
        if (this.exists(UIAQuery.query('Table of Contents').isVisible())) {
            this.tap(UIAQuery.query('Table of Contents').isVisible());
        }
    }

    state = this.getCurrentUIState();

    switch (state) {
        case UIStateDescription.iBooks.EPUB_TOC:
            var chapter_query = UIAQuery.staticTexts(chapter);
            if (this.exists(chapter_query)) {
                this.tap(chapter_query);
            } else {
                throw new UIAError('Invalid Chapter name!');
            }
            return true;
        case UIStateDescription.iBooks.MT_EPUB_TOC:
            var chapter_query = UIAQuery.staticTexts(chapter);
            if (subchapter) {
                chapter_query = UIAQuery.buttons('open.close.chapter.button').rightOf(chapter_query);
                var cell_count = this.count(UIAQuery.tableCells());
            }
            if (this.exists(chapter_query)) {
                this.tap(chapter_query);
                if (subchapter) {
                    //we need to make sure we don't accidentally close what we want
                    if (cell_count > this.count(UIAQuery.tableCells())) {
                        this.tap(chapter_query);
                    }
                    var subchapter_query = UIAQuery.staticTexts(subchapter).below(chapter);
                    if (this.exists(subchapter_query)) {
                        this.tap(subchapter_query);
                    } else {
                        throw new UIAError('Unknown sub chapter!');
                    }
                }
                return true;
            } else {
                throw new UIAError('Invalid Chapter name!');
            }
        case UIStateDescription.iBooks.MT_TOC:
            var num_chapters = this.getChapterPagesNumber(state);
            var current_chapter = this.getChapterPage(state);

            if (chapter > num_chapters) {
                throw new UIAError('Invalid Chapter! %0 of %1'.format(chapter, num_chapters));
            }
            if (chapter > current_chapter) {
                var cont = true;
                var loops = num_chapters;
                while (cont && loops > 0) {
                    this.swipeToNextPage({
                        state: state,
                        skip_check: true,
                        verify_swipe: false,
                    });
                    current_chapter = this.getChapterPage(state);
                    loops--;
                    if (chapter == current_chapter) {
                        cont = false;
                    }
                }
            } else if (chapter < current_chapter) {
                var cont = true;
                var loops = num_chapters;
                while (cont && loops > 0) {
                    this.swipeToPreviousPage({
                        state: state,
                        skip_check: true,
                        verify_swipe: false,
                    });
                    current_chapter = this.getChapterPage(state);
                    loops--;
                    if (chapter === current_chapter) {
                        cont = false;
                    }
                }
            }
            //when we get to here we are on the right page
            // on non-ipads we have a sheet
            if (target.model() !== 'iPad') {
                var waiter = UIAWaiter.waiter('ViewDidDisppear', {predicate: 'controllerClass == "THChapterBrowseriOSCanvasViewController"'});
                this.tap('THWViewportRep');
                waiter.wait(3);
                var subchapter_query = UIAQuery.staticTexts(subchapter);
                if (this.exists(subchapter_query)) {
                    this.tap(subchapter_query);
                } else {
                    throw new UIAError('Unknown sub chapter!');
                }
            } else {
                throw new UIAError('Unable to navigate to chapter on iPads!');
            }
            return true;

        default:
            break;
    }
    UIALogger.logWarning('Unknown state! Could not go to a chapter!');
    return false;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
* Internal function to switch library views
*
* @param  {string} view grid or list
*
* @throws if we can't get to where we want to be
*/
ibooks._switchLibraryView = function _switchLibraryView(view) {
    switch (view) {
        case ibooks.Constants.GRID:
            this.tapIfExists(UIAQuery.iBooks.GRID_VIEW.isVisible())
            if (this.getCurrentUIState() !== UIStateDescription.iBooks.SHELF_GRID_VIEW) {
                throw new UIAError('Could not get back to shelf grid view!');
            }
            break;
        case ibooks.Constants.LIST:
            this.tapIfExists(UIAQuery.iBooks.LIST_VIEW.isVisible())
            if (this.getCurrentUIState() !== UIStateDescription.iBooks.SHELF_LIST_VIEW) {
                throw new UIAError('Could not get back to shelf list view!');
            }
            break;
        default:
            //this is intended
    }
}

/**
* Internal function that determines if the toobar in a book is showing
*
* @return {bool}
*/
ibooks._toolbarVisible = function _toolbarVisible() {
    if (this.exists(UIAQuery.iBooks.LIBRARY.isVisible())) {
        return true;
    }
    return false;
}

/**
 * Get the name of a scroll view for the type of book that it is.
 * 
 * @param  {string} state state from getCurrentUIState()
 * 
 * @return {bool|string} String of the scrollview name or false
 */
ibooks._getScrollviewNameFromState = function _getScrollviewNameFromState(state) {
    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_PDF:
            return 'BKAccessibilityPDFElement';
        case UIStateDescription.iBooks.IN_BOOK_EPUB:
            return 'BKBookContainerView';
        case UIStateDescription.iBooks.IN_BOOK_MT:
            return 'THScrollView';
        default:
            return false;
    }
}

/**
 * Get to a specific tab in a ePub TOC
 * 
 * @param  {string} tab Tab name, either Contents, Bookmarks, or Notes
 * 
 * @return {bool} whether or not we tapped on anything
 *
 * @throws If `tab` is invalid
 */
ibooks._getToTOCTab = function _getToTOCTab(tab) {
    if (!tab) {
        tab = 'Contents';
    }
    switch(tab) {
        case 'Contents':
        case 'Bookmarks':
        case 'Notes':
            this.tap(UIAQuery.segmentedControls('BKSegmentedControl').children().andThen(UIAQuery.query(tab)));
            return true;
        default:
            throw new UIAError('Unknown TOC tab %0'.format(tab))
    }
}

/**
 * We dismiss certain book items like widgets, videos, and popovers
 */
ibooks._dismissBookItems = function _dismissBookItems() {
    var done = UIAQuery.buttons('Done');
    if (this.exists(done)) {
        if (!this.exists(done.isVisible())) {
            this.tap(UIAQuery.application());
        }
        this.tapIfExists(done);
    }
    this.tapIfExists('Close');
    this.dismissPopover();
}

/**
 * Get the current page number in a book
 * 
 * @param  {string} state optional {getCurrentUIState()}
 * 
 * @return {int|bool} page number on success false if not in a valid book
 *
 * @throws If the elements we derive the page number from don't exist
 */
ibooks.getCurrentPageNumber = function getCurrentPageNumber(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }

    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_MT:
            var page = UIAQuery.scrollViews().isVisible();
            var page_number_string = ibooks.inspect(UIAQuery.query("THPageNumberView").children()).name;
            var arr = page_number_string.split(' ');
            var ret = parseInt(arr[0]);
            break;
        case UIStateDescription.iBooks.IN_BOOK_EPUB:
            var page_number_string = this.inspect('Page number').value;
            var arr = page_number_string.split(' ');
            var ret = parseInt(arr[0]);
            break;
        default:
            UIALogger.logWarning('Could not determine page number! UI State: %0'.format(state));
            return false;
    }
    if (!Number.isInteger(ret)) {
        throw new UIAError('Unable to determine page number in this book!');
    }
    return ret;
}

/**
 * Get the page number of the last page (total pages)
 * 
 * @param  {string} state optional {getCurrentUIState()}
 * 
 * @return {int|bool} page number on success false if not in a valid book
 *
 * @throws If the elements we derive the page number from don't exist
 */
ibooks.getLastPageNumber = function getLastPageNumber(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }

    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_MT:
            var page = UIAQuery.scrollViews().isVisible();
            var page_number_string = ibooks.inspect(UIAQuery.query("THPageNumberView").children()).name;
            var arr = page_number_string.split(' ');
            var ret = parseInt(arr[2]);
            break;
        case UIStateDescription.iBooks.IN_BOOK_EPUB:
            var page_number_string = this.inspect('Page number').value;
            var arr = page_number_string.split(' ');
            var ret = parseInt(arr[2]);
            break;
        default:
            UIALogger.logWarning('Could not determine number of pages! UI State: %0'.format(state));
            return false;
    }
    if (!Number.isInteger(ret)) {
        throw new UIAError('Unable to determine page number in this book!');
    }
    return ret;
}

/**
 * In MT books we can sometimes get the page number relative to the current chapter
 * 
 * @param  {string} state optional {getCurrentUIState()}
 * 
 * @return {int|bool} page number on success false if not in a valid book
 */
ibooks.getChapterPage = function getChapterPage(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }

    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_MT:
        case UIStateDescription.iBooks.MT_TOC:
            var page = UIAQuery.scrollViews().isVisible();
            var currentpage = this.inspect(page).pageIndex;
            var ret = parseInt(currentpage);
            break;
        default:
            return false;
    }
    if (!Number.isInteger(ret)) {
        throw new UIAError('Unable to determine page number in this book!');
    }
    return ret;
}

/**
 * In MT books we can sometimes get the number of pages in the current chapter
 * 
 * @param  {string} state optional {getCurrentUIState()}
 * 
 * @return {int|bool} page number on success false if not in a valid book
 */
ibooks.getChapterPagesNumber = function getChapterPagesNumber(state) {
    if (!state) {
        state = this.getCurrentUIState();
    }

    switch (state) {
        case UIStateDescription.iBooks.IN_BOOK_MT:
        case UIStateDescription.iBooks.MT_TOC:
            var page = UIAQuery.scrollViews().isVisible();
            var currentpage = this.inspect(page).pageCount;
            var ret = parseInt(currentpage);
            break;
        default:
            return false;
    }
    if (!Number.isInteger(ret)) {
        throw new UIAError('Unable to determine page number in this book!');
    }
    return ret;
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Assertions                                                          */
/*                                                                             */
/*      Functions that perform validations and throw UIAErrors                 */
/*      These are App specific assertions only                                 */
/*                                                                             */
/*******************************************************************************/

/**
* Asserts that an item from a query is selected
*
* @param  {UIAQuery} query - Query to inspect
* @param  {string} message - message to throw if the assertion fails
*
* @throws Throws if the item is not selected
*/
ibooks.assertSelected = function assertSelected(query, message) {
    UIAUtilities.assertEqual(
        this.inspect(query).isSelected,
        true,
        message
    );
}