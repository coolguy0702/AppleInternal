/**
 * This is a file for Audiobook specific functions for iBooks
 */
load('iBooks.js');
load('CoreAutomation.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Get back to the default audiobook state
 * Assumes we are somwhere in an audiobook
 * 
 * @return {bool} returns true on success
 *
 * @throws if we are in the library or can't make it back to the right state
 */
ibooks.getToDefaultAudiobookState = function getToDefaultAudiobookState() {
    if (this.disableAudiobookStateChecking) {
        return true;
    }
    this.launch();
    var state = this.getCurrentUIState();
    if (this.inLibrary(state)) {
        throw new UIAError('You must be in an audiobook to call this function!');
    }
    if (state === UIStateDescription.iBooks.AUDIOBOOK) {
        return true;
    }
    this.dismissPopovers();
    this.tapIfExists('Done');
    state = this.getCurrentUIState();
    if (state === UIStateDescription.iBooks.AUDIOBOOK) {
        return true;
    }
    throw new UIAError('Could not get back to default audiobook state!');
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Verify that the track actually plays and track time passes
 * 
 * @return {bool} true if all is good
 *
 * @throws if No media is playing, or the track doesn't progress.
 */
ibooks.verifyAudiobookPlays = function verifyAudiobookPlays() {
    this.getToDefaultAudiobookState();
    
    // Tap play if we aren't already playing
    this.tapIfExists(UIAQuery.iBooks.PLAY_BUTTON);

    if (!CAMMediaRemote.isMediaPlaying()) {
        throw new UIAError('No Media is playing!');
    }

    var currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
    var elapsedTime = CAMMediaRemote.getNowPlayingElapsedTime();
    UIALogger.logMessage('Start time: %0'.format(elapsedTime));

    this.delay(3);

    // we went to the next chapter
    if (currentChapter < CAMMediaRemote.getNowPlayingChapterNumber()) {
        UIALogger.logMessage('Audiobook went to next chapter');
        return true;
    }

    // We need to pause before the elasped time updates
    // <rdar://problem/22347281> kMRMediaRemoteNowPlayingInfoElapsedTime doesn't update in realtime
    this.tap(UIAQuery.iBooks.PAUSE_BUTTON);

    var newElaspedTime = CAMMediaRemote.getNowPlayingElapsedTime();
    UIALogger.logMessage('Start time: %0    End time: %1'.format(elapsedTime, newElaspedTime));
    if (elapsedTime < newElaspedTime) {
        UIALogger.logPass('Audiobook track time progressed.');
        return true;
    }
    throw new UIAError('Media track time is not progressing (or went backwards)!')
}

/**
 * Verify that items in the UI match those in Now Playing 
 *
 * @param {object} options
 * @param {bool} [options.play=true] Whether or not we should tap play
 * @param {bool} [options.play_pause_button=true] Verify the Play button state
 * @param {bool} [options.author=true] Verify the author
 * @param {bool} [options.title=true] Verify the title
 * @param {bool} [options.chapter=true] verify the chapter
 * @param {bool} [options.speed=true] verify the speed
 * @param {bool} [options.timer=true] verify the timer exists
 */
ibooks.verifyAudiobookUI = function verifyAudiobookUI(options) {
    options = UIAUtilities.defaults(options, {
        play: true,
        play_pause_button: true,
        author: true,
        title: true,
        chapter: true,
        speed: true,
        timer: true,
    });

    this.getToDefaultAudiobookState();
    if (options.play) {
        // Play then pause so that we get into Now Playing
        if (this.exists(UIAQuery.iBooks.PLAY_BUTTON)) {
            this.tap(UIAQuery.iBooks.PLAY_BUTTON);
        }
        this.tap(UIAQuery.iBooks.PAUSE_BUTTON);
    }

    //Disable state checking for now
    this.disableAudiobookStateChecking = true;
    try {

        if (options.play_pause_button) {
            var ibPaused = this.isAudioPlaying();
            var camPaused = CAMMediaRemote.isMediaPlaying();
            UIAUtilities.assertEqual(ibPaused, camPaused, 'Audiobook is not paused! iBooks: "%0", CAM: "%1"'.format(ibPaused, camPaused));
            UIALogger.logMessage('Paused verified: "%0"'.format(ibPaused));
        }

        if (options.author) {
            var ibAuthor = this.getAuthor();
            var camAuthor = CAMMediaRemote.getNowPlayingArtist();
            UIAUtilities.assertEqual(ibAuthor, camAuthor, 'Audiobook Author not the same! iBooks: "%0", CAM: "%1"'.format(ibAuthor, camAuthor));
            UIALogger.logMessage('Author verified: "%0"'.format(ibAuthor));
        }

        if (options.title) {
            var ibTitle = this.getTitle();
            var camTitle = CAMMediaRemote.getNowPlayingAlbum();
            UIAUtilities.assertEqual(ibTitle, camTitle, 'Audiobook Title not the same! iBooks: "%0", CAM: "%1"'.format(ibTitle, camTitle));
            UIALogger.logMessage('Title verified: "%0"'.format(ibTitle));
        }

        if (options.chapter) {
            var ibChapter = this.getCurrentChapter();
            var camChapter = CAMMediaRemote.getNowPlayingTitle();
            UIAUtilities.assertEqual(ibChapter, camChapter, 'Audiobook Chapter not the same! iBooks: "%0", CAM: "%1"'.format(ibChapter, camChapter));
            UIALogger.logMessage('Chapter verified: "%0"'.format(ibChapter));
        }

        if (options.speed) {
            var ibSpeed = parseFloat(this.getSpeed());
            var camSpeed = CAMMediaRemote.getNowPlayingDefaultPlaybackRate();
            UIAUtilities.assertEqual(ibSpeed, camSpeed, 'Audiobook Speed not the same! iBooks: "%0", CAM: "%1"'.format(ibSpeed, camSpeed));
            UIALogger.logMessage('Speed verified: "%0"'.format(ibSpeed));
        }

        if (options.timer) {
            //the below throws if we get an invalid value
            var time = this.getTimeLeftOnTimer();
            // we can't do any other comparison really due to the fact
            // that the timer starts to count down immediately
            UIALogger.logMessage('Seconds left on sleep timer: "%0"'.format(time));
        }

        UIALogger.logPass('iBooks UI matches Now Playing data!');

    } finally {
        this.disableAudiobookStateChecking = false;
    }

}

/**
 * Verify that when we reach the end of a chapter, that we automatically go to the next
 */
ibooks.verifyAutoPlayNextChapter = function verifyAutoPlayNextChapter() {
    this.getToDefaultAudiobookState();

    this._pauseIfPlaying();

    //Disable state checking for now
    this.disableAudiobookStateChecking = true;
    try {
        var totalChapters =  CAMMediaRemote.getNowPlayingTotalChapterCount();
        if (totalChapters === 1) {
            throw new UIAError('Audiobook needs at least 2 chapters!');
        }

        if (this.getTimeLeftOnTimer() !== -1) {
            UIAMessage.logWarning('Timer is set! This may cause the test to fail!');
        }

        var currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
        if (totalChapters <= currentChapter) {
            UIALogger.logMessage('At the last chapter, switching to first chapter.');
            this.goToAudiobookChapter();
            currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
        }

        this.setBookPosition(99.9999);//as close to the end as possible so we don't have to wait...

        this.tap(UIAQuery.iBooks.PLAY_BUTTON);

        var rem = Math.round(this._getTimeRemaining());
        var wait = rem + 5; //a little extra just incase
        UIALogger.logMessage('Waiting %0 seconds for track to finish'.format(wait));
        this.delay(wait);

        UIAUtilities.assertEqual(currentChapter + 1, CAMMediaRemote.getNowPlayingChapterNumber(), 'Audiobook did not progress to next chapter!');

        this.assertExists(UIAQuery.iBooks.PAUSE_BUTTON, 'Audiobook pause playing!');
        
        UIALogger.logPass('Audiobook automatically progressed to next chapter!');

    } finally {
        this.disableAudiobookStateChecking = false;
        this.tap(UIAQuery.iBooks.PAUSE_BUTTON);
    }
}

/**
 * Verify that when we reach the end of an audiobook, the audiobook closes
 */
ibooks.verifyAudiobookAutoClose = function verifyAudiobookAutoClose() {
    this.getToDefaultAudiobookState();

    this._pauseIfPlaying();

    //Disable state checking for now
    this.disableAudiobookStateChecking = true;
    try {
        var totalChapters =  CAMMediaRemote.getNowPlayingTotalChapterCount();

        if (this.getTimeLeftOnTimer() !== -1) {
            UIAMessage.logWarning('Timer is set! This may cause the test to fail!');
        }

        var currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
        if (totalChapters != currentChapter) {
            UIALogger.logMessage('Not at the last chapter, switching to the last chapter');
            this.goToAudiobookChapter(true);
        }

        this.setBookPosition(99.9999);//as close to the end as possible so we don't have to wait...

        this.tap(UIAQuery.iBooks.PLAY_BUTTON);

        var rem = Math.round(this._getTimeRemaining());
        var wait = rem + 5; //a little extra just incase
        UIALogger.logMessage('Waiting %0 seconds for audiobook to finish'.format(wait));
        this.delay(wait);

        if (!ibooks.inLibrary()) {
            throw new UIAError('Audiobook did not auto close! State: %0'.format(ibooks.getCurrentUIState()));
        }
        
        UIALogger.logPass('Audiobook automatically closed after finishing!');

    } finally {
        this.disableAudiobookStateChecking = false;
    }
}

/**
 * Verify that the audiobook timer works
 *
 * @param {int|string} timer what timer to set and verify (same arguments as ibooks.setTimer())
 */
ibooks.verifyAudiobookSleepTimer = function verifyAudiobookSleepTimer(timer) {
    this.getToDefaultAudiobookState();

    this._pauseIfPlaying();

    //Disable state checking for now
    this.disableAudiobookStateChecking = true;
    try {

        var totalChapters =  CAMMediaRemote.getNowPlayingTotalChapterCount();
        var currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
        if (timer == 'end' && totalChapters === 1) {
            throw new UIAError('Audiobook only has 1 chapter, cannot tests "end" timer on an audiobook with 1 chapter.');
        }

        if (totalChapters <= currentChapter) {
            UIALogger.logMessage('At the last chapter, switching to first chapter.');
            this.goToAudiobookChapter();
            currentChapter = CAMMediaRemote.getNowPlayingChapterNumber();
        }

        this.setTimer(timer);
        this.delay(2); //the UI doesn't instantly update... there are no events that work for this right now

        var remaining = this._getTimeRemaining();//we do this right after setting it so its as close to the real value as possible
        var left = this.getTimeLeftOnTimer();

        var isOff = false;
        if (!Number.isInteger(timer) && timer != 'end') { //case insensitive since it is user supplied
            //if we get here, then we should have set it to off,
            isOff = true;
            if (left !== -1) {
                throw new UIAError('Timer was not set to off!');
            }
        } else {
            //its a number or the end
            if (timer == 'end') { //case insensitive since it is user supplied
                var diff = Math.abs(left - remaining);
                if (diff > 5) { // 5 second wiggle room, we shouldn't hit this since chapter end shouldn't increase if we are paused
                    throw new UIAError('Timer was set to "end" but timer was really set to "%0"'.format(this.getTimeLeftOnTimer(true)));
                }
            } else {
                //its a number!
                timer = parseInt(timer);
                var diff = Math.abs(left - (timer * 60));
                if (diff > 5) { 
                    throw new UIAError('Timer was set to "%0" but timer was really set to "%1". (5 second wiggle room)'.format((parseInt(timer) * 60), left));
                }
            }
        }

        // if we get here, it turns into a waiting game!
        if (isOff) {
            // @TODO we should do some test if the timer is off... just not sure what...
            UIALogger.logPass('Timer was set to off!');
            return;
        }
        if (timer == 'end') {
            var rem = Math.round(remaining);
            var wait = rem + 5; //a little extra just incase
            this.tap(UIAQuery.iBooks.PLAY_BUTTON);
            UIALogger.logMessage('Waiting %0 seconds for track to finish'.format(wait));
            this.delay(wait);
            var play = this.exists(UIAQuery.iBooks.PLAY_BUTTON);
            if (Math.floor(CAMMediaRemote.getNowPlayingElapsedTime()) !== 0 || !play) {
                var error = '';
                if (!play) {
                    error = "Play button does not exist! (we didn't auto pause) ";
                }
                var time = Math.floor(CAMMediaRemote.getNowPlayingElapsedTime());
                if (time !== 0) {
                    error += 'Current elapsed time: "%0"'.format(time);
                }
                throw new UIAError(error);
            }
            if (currentChapter >= CAMMediaRemote.getNowPlayingChapterNumber()) {
                throw new UIAError('Did not navigate to next chapter at the end of the track!');
            }
            UIALogger.logPass('Audiobook successfully stopped playing at the end of the track and progressed to the next chapter!');
            return;
        }
        //only time is left... time to wait :(
        this.tap(UIAQuery.iBooks.PLAY_BUTTON);

        // we are polling because we need to make sure we don't stop before we should.
        var loops = timer + 1; //timer minutes plus 1 minute (longest time)
        while (this.getTimeLeftOnTimer() !== -1 && loops > 0) {
            if (this.exists(UIAQuery.iBooks.PLAY_BUTTON)) {
                throw new UIAError('Audiobook paused before it was supposed to!');
            }
            loops--;
            UIALogger.logMessage('Audiobook is still playing. (%0 loops until timeout)'.format(loops));
            UIALogger.logMessage('Waiting 60 seconds before polling status');
            this.delay(60);//wait 60 seconds
        }
        if (loops === 0) {
            throw new UIAError('Audiobook timer did not expire after %0 minutes!'.format(timer));
        }
        if (this.exists(UIAQuery.iBooks.PAUSE_BUTTON)) {
            throw new UIAError('Timer expired but Audiobook did not pause!');
        }
        
        UIALogger.logPass('Audiobook stopped playing after finishing the timer!');

    } finally {
        this.disableAudiobookStateChecking = false;
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Go to a chapter in an audiobook
 * 
 * @param  {string|bool} chapter case in-sensitive partial or full chapter name, if false or empty, the first chapter, if true, last chapter
 *
 * @throws if the the chapter is not present/valid
 */
ibooks.goToAudiobookChapter = function goToAudiobookChapter(chapter) {
    this.getToDefaultAudiobookState();
    this.tap(UIAQuery.iBooks.TABLE_OF_CONTENTS_BUTTON);
    var query = UIAQuery.tableCells().first();
    if (chapter) {
        if (chapter === true) {
            query = UIAQuery.tableCells().last();
        } else {
            query = UIAQuery.staticTexts().withPredicate('label CONTAINS[c] "%0"'.format(chapter));
            this.assertExists(query, 'Invalid chapter!');
        }
    }
    this.tap(query);
}

/**
 * Get the number of chapters in an audiobook
 * 
 * @return {int}
 */
ibooks.getNumberOfChapters = function getNumberOfChapters() {
    this.getToDefaultAudiobookState();
    this.tap(UIAQuery.iBooks.TABLE_OF_CONTENTS_BUTTON);
    return this.count(UIAQuery.tableCells());
}

/**
 * Gets the current title
 * 
 * @return {string}
 */
ibooks.getTitle = function getTitle() {
    this.getToDefaultAudiobookState();
    var string =  this.inspect(UIAQuery.query("AETitlesContainer").andThen(UIAQuery.staticTexts().atIndex(1))).label;
    var arr = string.split(' - ');
    return arr[0];
}

/**
 * Gets the current author
 * 
 * @return {string}
 */
ibooks.getAuthor = function getAuthor() {
    this.getToDefaultAudiobookState();
    var string =  this.inspect(UIAQuery.query("AETitlesContainer").andThen(UIAQuery.staticTexts().atIndex(1))).label;
    var arr = string.split(' - ');
    return arr[1];
}

/**
 * Gets the current chapter name
 * 
 * @return {string}
 */
ibooks.getCurrentChapter = function getCurrentChapter() {
    this.getToDefaultAudiobookState();
    return this.inspect(UIAQuery.query("AETitlesContainer").andThen(UIAQuery.staticTexts().first())).label;
}

/**
 * Get the current time we are into a chapter 
 * THIS IS INACCURATE, it is usually about a second off
 * 
 * @return {string} a string of the current time eg: two minutes, twenty-eight seconds
 */
ibooks.getCurrentTime = function getCurrentTime() {
    this.getToDefaultAudiobookState();
    // this way doesn't always update properly right, and I don't really trust my hack below
    // var val = this.inspect('Book position').value;
    // var arr = val.split(' of ');
    // return arr[0];

    return this.inspect(UIAQuery.staticTexts().below(UIAQuery.sliders('Book position')).first()).label;
}

/**
 * Sets the current time position in the book
 *  
 * @param {int} time number betwwen 0 and 100
 */
ibooks.setCurrentTime = function setCurrentTime(time) {
    this.getToDefaultAudiobookState();
    time = time/100;
    this.setControl('Book position', time);
}

/**
 * Get the time left in the current chapter
 * THIS IS INACCURATE, it is usually about a second off
 * 
 * @return {string} a string of the current time eg: two minutes, twenty-eight seconds
 */
ibooks.getTimeLeftInChapter = function getTimeLeftInChapter() {
    this.getToDefaultAudiobookState();
    // this way doesn't always update properly right now, and I don't really trust my hack below
    // var val = this.inspect('Book position').value;
    // var arr = val.split(' of ');
    // return arr[1];

    return this.inspect(UIAQuery.staticTexts().below(UIAQuery.sliders('Book position')).atIndex(1)).label;
}

/**
 * Get the current speed of the track
 * 
 * @return {string} eg: 1x, 2x
 */
ibooks.getSpeed = function getSpeed() {
    this.getToDefaultAudiobookState();
    var label = this.inspect(UIAQuery.iBooks.SPEED_BUTTON).label;
    var arr = label.split(': ');
    return arr[1];
}

/**
 * Set the speed of the timer
 * 
 * @param {int|float|string} speed The speed that we want the audiobook to run at
 */
ibooks.setSpeed = function setSpeed(speed) {
    this.getToDefaultAudiobookState();
    this.tap(UIAQuery.iBooks.SPEED_BUTTON);
    var q = '1x';
    switch (parseFloat(speed)) {
        case 0.75:
            q = '0.75x';
            break;
        case 1:
            q = '1x';
            break;
        case 1.25:
            q = '1.25x';
            break;
        case 1.5:
            q = '1.5x';
            break;
        case 2:
            q = '2x';
            break;
        default:
            break;
    }
    this.tap(UIAQuery.staticTexts(q));
}

/**
 * Get the current state/value of the timer
 * 
 * @param  {bool} as_string whether you want the value returned as a string or not
 * 
 * @return {int|string|bool}
 */
ibooks.getTimerState = function getTimerState(as_string) {
    this.getToDefaultAudiobookState();
    this.tap(UIAQuery.iBooks.SLEEP_TIMER);
    var label = this.inspect(UIAQuery.tableCells().isSelected().children()).label;
    if (as_string) {
        return label;
    }
    switch (label) {
        case 'Off':
            return 'Off';
        case 'When current track ends':
            return 'end';
        case '5 minutes':
            return 5;
        case '10 minutes':
            return 10;
        case '15 minutes':
            return 15;
        case '30 minutes':
            return 30;
        case '45 minutes':
            return 45;
        case '1 hour':
            return 60;
        default:
            UIALogger.logWarning('Unknown selected item "%0"'.format(label));
            return false;
    }
}

/**
 * Get the time left on the timer
 * 
 * @param  {bool} as_string whether the result should be retured as a string, eg: 1:45
 * 
 * @return {int|string} If {as_string} is false then the seconds left on the timer or -1 if it is off
 *                      if {as_string} is true then a string like "2:34" or "Off"
 */
ibooks.getTimeLeftOnTimer = function getTimeLeftOnTimer(as_string) {
    this.getToDefaultAudiobookState();
    var time = this.inspect(UIAQuery.iBooks.SLEEP_TIMER).label;
    if (time.indexOf('Off') !== -1) {
        time = 'Off';
    }
    if (as_string) {
        return time;
    }
    if (time === 'Off') {
        return -1;
    }
    return this._timeToSeconds(time);
}

/**
 * Set the sleep timer
 * 
 * @param {int|string} timer Allowed values (all times in minutes):
 *                           5, 10, 15, 30, 45, 60, end, or anything else to disable the timer 
 */
ibooks.setTimer = function setTimer(timer) {
    this.getToDefaultAudiobookState();
    this.tap(UIAQuery.iBooks.SLEEP_TIMER);
    var q = 'Off';
    switch (timer) {
        case 5:
            q = '5 minutes';
            break;
        case 10:
            q = '10 minutes';
            break;
        case 15:
            q = '15 minutes';
            break;
        case 30:
            q = '30 minutes';
            break;
        case 45:
            q = '45 minutes';
            break;
        case 60:
        case 1:
            q = '1 hour';
            break;
        case 'end':
            q = 'When current track ends';
            break;
        default:
            break;
    }
    this.tap(UIAQuery.staticTexts(q));
}

/**
 * Set the book position
 * 
 * @param {int} number between 0 and 100
 */
ibooks.setBookPosition = function setBookPosition(pos) {
    this.getToDefaultAudiobookState();
    pos = pos/100;
    this.setControl('Book position', pos);
}

/**
 * Get the current volume level
 * 
 * @return {int} number between 0 and 100
 */
ibooks.getVolume = function getVolume() {
    this.getToDefaultAudiobookState();
    var str = this.inspect(UIAQuery.sliders('Volume')).value;
    str = str.substring(0, str.length - 1);
    return parseInt(str);
}

/**
 * Set the volume for the audiobook
 * 
 * @param {int} vol number between 0 and 100
 */
ibooks.setVolume = function setVolume(vol) {
    this.getToDefaultAudiobookState();
    vol = vol/100;
    this.setControl('Volume', vol);
}

/**
 * Whether or not we are playing audio
 * 
 * @return {Boolean}
 */
ibooks.isAudioPlaying = function isAudioPlaying() {
    this.getToDefaultAudiobookState();
    if (this.exists(UIAQuery.iBooks.PAUSE_BUTTON)) {
        return true;
    }
    return false;

}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Whether or not we should really check the current UI state
 * 
 * @type {Boolean}
 */
ibooks.disableAudiobookStateChecking = false;

/**
 * Takes stuff like 12:34 and turns it into seconds
 * 
 * @param  {string} str something like 12:34:56
 * 
 * @return {int} time in seconds
 */
ibooks._timeToSeconds = function timeToSeconds(str) {
    var p = str.split(':');
    var s = 0;
    var m = 1;

    while (p.length > 0) {
        s += m * parseInt(p.pop(), 10);
        m *= 60;
    }
    if (!Number.isInteger(s)) {
        throw new UIAError('Invalid value supplied to _timeToSeconds! "%0"'.format(str));
    }
    return s;
}

/**
 * Pause playback
 */
ibooks._pauseIfPlaying = function _pauseIfPlaying() {
    this.tapIfExists(UIAQuery.iBooks.PAUSE_BUTTON);
}

/**
 * get the time remaining in an audiobook
 * @return {float}
 */
ibooks._getTimeRemaining = function _getTimeRemaining() {
    return CAMMediaRemote.getNowPlayingDuration() - CAMMediaRemote.getNowPlayingElapsedTime();
}

/**
 * Try and get the elapsed time if media is playing since the begining of the track
 * 
 * @return {float} Time elapsed since the begining of the track
 */
ibooks._getLiveElapsedTime = function _getLiveElapsedTime() {
    //if we aren't playing anything then the elapsed time should be up to date
    if (!CAMMediaRemote.isMediaPlaying()) {
        return CAMMediaRemote.getNowPlayingElapsedTime();
    }

    var lastElapsed = CAMMediaRemote.getNowPlayingElapsedTime();
    var ts = CAMMediaRemote.getNowPlayingTimestamp();
    ts = ts.split(' ');
    var timestamp = new Date(ts[0] + 'T' + ts[1]).getTime();
    var now = Date.now();
    var timeSinceElapsed = (now - timestamp) / 1000;

    var elapsed = lastElapsed + timeSinceElapsed;
    return elapsed;
}