load('UIATesting.js');
load('iBooks.js');
load('iBooks+Audiobooks.js');

UIAUtilities.assert(
    typeof iBooksTests === 'undefined',
    'iBooksTests has already been defined.'
);

/**
 * @namespace
 */
var iBooksTests = {

    /**
     * Launch iBooks and Verify Tabs are present
     *
     * @targetApps iBooks
     */
    launchAndVerifyTabs: function launchAndVerifyTabs() {
      ibooks.launchAndVerifyTabs();
    },

    /**
     * Verify that the settings page for iBooks exists,
     * Cold Launch iBooks,
     * Warm Launch iBooks
     *
     * @targetApps iBooks, Preferences
     */
    launchQuickLook: function launchQuickLook() {
      ibooks.verifySettingsAndLaunch();
    },

    /**
     * Make sure list/grid buttons work,
     *
     * @targetApps iBooks
     */
    libraryQuickLook: function libraryQuickLook() {
      ibooks.verifyLibraryStatesAndOrientations();
    },

    /*******************************************************************************/
    /*                                                                             */
    /*   Audiobook related tests                                                   */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Verify that the Audiobooks UI is correct after launch
     * 
     * Test will fail until the below radars are fixed:
     * rdar://problem/22016454 Audiobooks: Auto-open doesn't load correct book scrubber info
     * rdar://problem/22017007 Audiobooks: Sleep label is wrong after auto-open
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     */
    verifyAudiobookUIAfterLaunch: function verifyAudiobookUIAfterLaunch(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
        });
        ibooks.openAudiobook(options.audiobook);
        UIALogger.logMessage('Waiting 15 seconds.');
        ibooks.delay(15);//wait for a while so the audiobook auto opens
        ibooks.quitAndLaunch();
        ibooks.verifyAudiobookUI({play: false,author: false,title: false,chapter: false,speed: false});
    },
    
    /**
     * Verify that audio from an audiobook actually plays
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     * @param {string} [options.collection=""] - Collection we should navigate to
     * @param {string} [options.library_view="list"] - What library state we should be in
     */
    verifyAudiobookPlays: function verifyAudiobookPlays(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
            collection: '',
            library_view: 'list',
        });

        ibooks.getToLibrary(options.library_view);

        if (options.collection) {
            ibooks.goToCollection(options.collection);
        }

        var q = new iBooksQueryGenerator();
        q.isAudioBook();
        if (options.audiobook) {
            q.filter(options.audiobook);
        }
        var query = q.getQuery();

        if (!ibooks.count(query)) {
            throw new UIAError('Invalid audiobook!');
        }

        ibooks.tap(query);
        ibooks.verifyAudiobookPlays();
    },

    /**
     * Verify that the Audiobooks UI matches that of Now Playing
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     * @param {string} [options.collection=""] - Collection we should navigate to
     * @param {string} [options.library_view="list"] - What library state we should be in
     */
    verifyAudiobookUI: function verifyAudiobookUI(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
            collection: '',
            library_view: 'list',
        });

        ibooks.getToLibrary(options.library_view);

        if (options.collection) {
            ibooks.goToCollection(options.collection);
        }

        ibooks.openAudiobook(options.audiobook);
        ibooks.verifyAudiobookUI();
    },

    /**
     * Verify that when iBooks finishes a chapter, it plays the next chapter.
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     * @param {string} [options.collection=""] - Collection we should navigate to
     * @param {string} [options.library_view="list"] - What library state we should be in
     */
    verifyAutoPlayNextChapter: function verifyAutoPlayNextChapter(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
            collection: '',
            library_view: 'list',
        });

        ibooks.getToLibrary(options.library_view);

        if (options.collection) {
            ibooks.goToCollection(options.collection);
        }

        var q = new iBooksQueryGenerator();
        q.isAudioBook();
        if (options.audiobook) {
            q.filter(options.audiobook);
        }
        var query = q.getQuery();

        if (!ibooks.count(query)) {
            throw new UIAError('Invalid audiobook!');
        }

        ibooks.tap(query);
        ibooks.verifyAutoPlayNextChapter();
    },

    /**
     * Verify that when an audiobook finishes it returns to the library.
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     * @param {string} [options.collection=""] - Collection we should navigate to
     * @param {string} [options.library_view="list"] - What library state we should be in
     */
    verifyAudiobookAutoClose: function verifyAudiobookAutoClose(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
            collection: '',
            library_view: 'list',
        });

        ibooks.getToLibrary(options.library_view);

        if (options.collection) {
            ibooks.goToCollection(options.collection);
        }

        var q = new iBooksQueryGenerator();
        q.isAudioBook();
        if (options.audiobook) {
            q.filter(options.audiobook);
        }
        var query = q.getQuery();

        if (!ibooks.count(query)) {
            throw new UIAError('Invalid audiobook!');
        }

        ibooks.tap(query);
        ibooks.verifyAudiobookAutoClose();
    },

    /**
     * Verify audiobook sleep timer.
     *
     * @targetApps iBooks
     * 
     * @param {object} options - Test Agruments
     * @param {string} [options.audiobook=""] - Audiobook name to open
     * @param {string} [options.collection=""] - Collection we should navigate to
     * @param {string} [options.library_view="list"] - What library state we should be in
     * @param {string|int} [options.sleep_timer="end"] - What to set the sleep timer to.
     *                                                 Allowed values (all times in minutes):
     *                                                 5, 10, 15, 30, 45, 60, end, or anything else to disable the timer 
     */
    verifyAudiobookSleepTimer: function verifyAudiobookSleepTimer(options) {
        options = UIAUtilities.defaults(options, {
            audiobook: '',
            collection: '',
            library_view: 'list',
            sleep_timer: 'end',
        });

        ibooks.getToLibrary(options.library_view);

        if (options.collection) {
            ibooks.goToCollection(options.collection);
        }

        var q = new iBooksQueryGenerator();
        q.isAudioBook();
        if (options.audiobook) {
            q.filter(options.audiobook);
        }
        var query = q.getQuery();

        if (!ibooks.count(query)) {
            throw new UIAError('Invalid audiobook!');
        }

        ibooks.tap(query);
        ibooks.verifyAudiobookSleepTimer(options.sleep_timer);
    },
    
}