/**
 * iBooksQueryGenerator is used to generate a {@link UIAQuery} that will return books for use in other functions/tests
 * Generator functions can be chained together
 * When using the QueryGenerator you must be in a library/series view or purchased page, you may also not switch between two views without creating a new query
 *
 * @example
 * var q = new iBooksQueryGenerator();
 * q.isNew(); // find books that have the `New` tag
 * q.isSample(false); // find books that are not samples
 * var query = q.getQuery(); // get the full UIAQuery
 *
 * @example
 * var query = new iBooksQueryGenerator().filter(book).getQuery();
 * 
 * @constructor
 * 
 * @return {iBooksQueryGenerator}
 */
function iBooksQueryGenerator() {
    var state = ibooks.getCurrentUIState();
    if (state === UIStateDescription.iBooks.SHELF_LIST_VIEW || state === UIStateDescription.iBooks.SERIES_LIST_VIEW) {
        this.UIstate = ibooks.Constants.LIST;
    } else if (state === UIStateDescription.iBooks.SHELF_GRID_VIEW || state === UIStateDescription.iBooks.SERIES_GRID_VIEW) {
        this.UIstate = ibooks.Constants.GRID;
        UIALogger.logWarning("iBooks uses a custom scrollview for grid view that doesn't work well with automation, use list view instead for accurate results");
    } else if (state === UIStateDescription.iBooks.STORE_PURCHASED) {
        this.UIState = ibooks.Constants.PURCHASED;
    } else {
        throw new UIAError('Not in a view that supports book queries: "%0"'.format(state));
    }
    this.parts = [];
    this.additionalQuery = false;
    this.parts.push('(label != nil)');
    if (state === UIStateDescription.iBooks.SERIES_GRID_VIEW) {
        this.parts.push('NOT (label ENDSWITH " Purchased")'); // This is to filter out a static text in grid view with series
    }
    if (state === UIStateDescription.iBooks.STORE_PURCHASED) {
        this.parts.push('behavior == "Link" OR behavior == "Button"');
    }
    UIALogger.logMessage('State determined as "%0" starting with predicate "%1"'.format(state, this.parts.join(' AND ')));
    return this;
}

iBooksQueryGenerator.prototype = {
    /**
    * Array of predicates to join
    *
    * @type string[]
    */
    parts: [],

    /**
    * Additional queries that we may need
    *
    * @type {Boolean|UIAQuery}
    */
    additionalQuery: false,

    /**
    * UI state that we are in (grid or list)
    *
    * @type {String}
    */
    UIstate: '',

    /**
     * Get the number of items that will be returned by a query
     * 
     * @return {int} number of items that match the query
     */
    getCount: function() {
        return ibooks.count(this.getQuery());
    },

    /**
    * Returns a UIAQuery that is built from a iBooksQueryGenerator
    *
    * @return {UIAQuery} The complete iBooksQueryGenerator
    */
    getQuery: function() {
        var fullPred = this.parts.join(' AND ');
        UIALogger.logDebug('Full Predicate for query: %0'.format(fullPred));
        var query;
        if (this.UIstate === ibooks.Constants.LIST) {
            query = UIAQuery.tableViews().andThen(UIAQuery.tableCells().withPredicate(fullPred));
        } else if (this.UIState === ibooks.Constants.PURCHASED) {
            query = UIAQuery.query('WebAccessibilityObjectWrapper').children().withPredicate(fullPred);
        } else {
            query = UIAQuery.query('IMGridView').children().withPredicate(fullPred);
        }
        if (this.additionalQuery) {
            query = query.andThen(this.additionalQuery);
        }
        return query;
    },

    /**
    * Filter iBooksQueryGenerator by case insensitive string
    *
    * @param  {string} val Book name or author
    *
    * @return {iBooksQueryGenerator}
    */
    filter: function(val) {
        if (this.UIstate === ibooks.Constants.PURCHASED) {
            if (val) {
                var pred = '(children.behavior == "Link" AND label CONTAINS[c] "%0")'.format(val);
            }
        } else {
            if (val) {
                var pred = '(label CONTAINS[c] "%0")'.format(val);
                this.parts.push(pred);
            }
        }
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is new
    *
    * @param  {bool} val Whether or not we should filter by if the book is new or not
    *
    * @return {iBooksQueryGenerator}
    */
    isNew: function(val) { //this doesn't need to account for states
        var pred = '(label CONTAINS "New,")';
        if (val === false) {
            pred = 'NOT (label CONTAINS "New,")';
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is a sample
    *
    * @param  {bool} val Whether or not we should filter by if the book is a sample or not
    *
    * @return {iBooksQueryGenerator}
    */
    isSample: function(val) { //this doesn't need to account for states
        var pred = '(label CONTAINS "Sample,")';
        if (val === false) {
            pred = 'NOT (label CONTAINS "Sample,")';
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is a series
    *
    * @param  {bool} val Whether or not we should filter by if the book is a series or not
    *
    * @return {iBooksQueryGenerator}
    */
    isSeries: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label CONTAINS "Series,")';
            if (val === false) {
                pred = 'NOT (label CONTAINS "Series,")';
            }
        } else {
            pred = '(label CONTAINS "Series book,")';
            if (val === false) {
                pred = 'NOT (label CONTAINS "Series book,")';
            }
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is a PDF
    *
    * @param  {bool} val Whether or not we should filter by if the book is a PDF or not
    *
    * @return {iBooksQueryGenerator}
    */
    isPDF: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label CONTAINS ", PDF")';
            if (val === false) {
                pred = 'NOT (label CONTAINS ", PDF")';
            }
        } else {
            pred = '(value CONTAINS "PDF")';
            if (val === false) {
                pred = 'NOT (value CONTAINS "PDF")';
            }
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is a book
    *
    * @param  {bool} val Whether or not we should filter by if the book is a book or not
    *
    * @return {iBooksQueryGenerator}
    */
    isBook: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label CONTAINS ", Book")';
            if (val === false) {
                pred = 'NOT (label CONTAINS ", Book")';
            }
        } else {
            pred = '(value CONTAINS "Book")';
            if (val === false) {
                pred = 'NOT (value CONTAINS "Book")';
            }
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is an audiobook
    *
    * @param  {bool} val Whether or not we should filter by if the book is an audiobook or not
    *
    * @return {iBooksQueryGenerator}
    */
    isAudioBook: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label CONTAINS ", Audiobook")';
            if (val === false) {
                pred = 'NOT (label CONTAINS ", Audiobook")';
            }
        } else {
            pred = '(value CONTAINS "Audiobook")';
            if (val === false) {
                pred = 'NOT (value CONTAINS "Audiobook")';
            }
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is a proof
    *
    * @param  {bool} val Whether or not we should filter by if the book is a proof or not
    *
    * @return {iBooksQueryGenerator}
    */
    isProof: function(val) { //this doesn't need to account for states
        var pred = '(label CONTAINS "Proof,")';
        if (val === false) {
            pred = 'NOT (label CONTAINS "Proof,")';
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is new
    *
    * @param  {bool} val Whether or not we should filter by if the book is in iCloud or not
    *
    * @return {iBooksQueryGenerator}
    */
    isIniCloud: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label CONTAINS "In iCloud,")';
            if (val === false) {
                pred = 'NOT (label CONTAINS "In iCloud,")';
            }
        } else if (this.UIState === ibooks.Constants.PURCHASED) {
            if (val === false) {
                pred = '(behavior == "Button" AND label BEGINSWITH "DOWNLOADED")';
            } else {
                pred = '(behavior == "Button" AND label BEGINSWITH "DOWNLOAD" AND (NOT (label BEGINSWITH "DOWNLOADED") AND NOT (label BEGINSWITH "DOWNLOADING")))';
            }
        } else {
            if (val !== false) {
                this.additionalQuery = UIAQuery.buttons('CloudDownloadButton');
                return this;
            }
            pred = '(ALL children.behavior != "Button")';
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is downloading
    *
    * @param  {bool} val Whether or not we should filter by if the book is downloading or not
    *
    * @return {iBooksQueryGenerator}
    */
    isDownloading: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(value CONTAINS "Downloaded ")';
            if (val === false) {
                pred = 'NOT (value CONTAINS "Downloaded ")';
            }
        } else if (this.UIState === ibooks.Constants.PURCHASED) {
            if (val === false) {
                pred = '(behavior == "Button" AND NOT (label BEGINSWITH "DOWNLOADING"))';
            } else {
                pred = '(behavior == "Button" AND label BEGINSWITH "DOWNLOADING")';
            }
        } else {
            if (val !== false) {
                this.additionalQuery = UIAQuery.buttons('Download progress');
                return this;
            }
            pred = '(ALL children.behavior != "Button")';
        }
        this.parts.push(pred);
        return this;
    },

    /**
    * Filter iBooksQueryGenerator by if the book is available for purchase (series stuff)
    * @TODO Add checking in grid view for price
    *
    * @param  {bool} val Whether or not we should filter by if the book is available for purchase
    *
    * @return {iBooksQueryGenerator}
    */
    isPurchasable: function(val) {
        var pred = '';
        if (this.UIstate === ibooks.Constants.GRID) {
            pred = '(label ENDSWITH ", GET") OR (label ENDSWITH ", BUY")';
            if (val === false) {
                pred = 'NOT (label ENDSWITH ", GET") AND NOT (label ENDSWITH ", BUY")';
            }
        } else {
            pred = '(label ENDSWITH ", Not yet purchased")';
            if (val === false) {
                pred = 'NOT (label ENDSWITH ", Not yet purchased")';
            }
        }
        this.parts.push(pred);
        return this;
    },

}