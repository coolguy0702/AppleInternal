load('UIATesting.js');
load('Siri.js');

if (typeof SiriTests === 'undefined') {
    /**
     * @namespace SiriTests
     */
    var SiriTests = {

        /**
         * This a generic Siri test. It inputs one or more files and then
         * looks for a string (or strings) if one (or more) are specified.
         *
         * @param {object} args - Test arguments
         * @param {string | array} [args.inputVoiceCommand] - Required input speech file paths
         * @param {array} [args.verficationArray] - Specify strings to use for test result verification. Each string must be present for the test to pass.
         * @param {string | array} [args.endVerification] - Specify one or more strings to look for that mark the end of text input. Only one of the strings must be found for the test to pass.
         * @param {string} [args.revertToTextOnFail] - A string to use for the Siri command as a backup, in case Siri doesn't recognize the voice command. E.g.: 'revertToTextOnFail:what time is it in Washington'
         * @param {boolean} [args.noReset] - If true, Siri will not be reset before running the test. If the Siri client is already active, it will not exit before running the test.
         * @param {int} [args.timeout] - number of seconds to wait for verification strings to appear on-screen
         * @param {boolean} [args.noSync] - If true, 'assistant_tool sync' will not be run to sync with the Siri server.
         * @param {boolean} [args.scrollUp] - Specify true if you want to scroll up after launching Siri. (This will use persistent conversation)
         * @param {boolean} [args.useSiriFromLockScreen] - Specify true if you want to use siri while the device is locked.
         */
        genericTest: function genericTest(args) {
            args = UIAUtilities.defaults(args, {
                inputVoiceCommand: [],
                verficationArray: [],
                endVerification: [],
                noReset: false,
                timeout: 60,
                noSync: false,
                scrollUp: false,
                useSiriFromLockScreen: false,
                revertToTextOnFail: null,
            });

            // Check if we're in a time window where Siri might get confused about time.
            var skipTestValidation = siri.addVerificationStringForSiriTimeConfusion(args.endVerification, args);

            // If we are, then skip the verification array.
            if (skipTestValidation === true) {
                UIALogger.logMessage('We are in the time window where Siri gets confused. Skip the verification array');
                options.verficationArray = [];
            }

            if (args.noreset === false) {
                // The Siri client must exit before we can run assistant_tool to sync
                siri.resetAssistant();

                if (args.noSync === false) {
                    UIALogger.logMessage('Running assistant_tool sync');
                    synchronizeAssistant();
                }
            }

            siri.issueVoiceCommand(args.inputVoiceCommand, args);
            if (args.endVerification) {
                UIALogger.logMessage('Waiting for string in siri');
                var waitOptions = {
                    timeout: args.timeout,
                    logicalOperation: siri.LogicalOperations.OR,
                    ignoreCase: true,
                };
                if (!siri.waitForMultipleStringsInAssistant(args.endVerification, waitOptions)) {
                    UIALogger.logMessage('Could not find the string for which we were waiting');
                    siri.throwErrorWithAssistantInfo('Could not find endVerification string: %0'.format(args.endVerification));
                }
            }

            if (siri.isAssistantErrorOnScreen()) {
                siri.throwErrorWithAssistantInfo('ErrorIdentifier is on-screen');
            }
            if (args.useSiriFromLockScreen) {
                siri.throwErrorIfDeviceNotLocked();
            }

            return UIATestResult.PASS;
        },

        /**
         * Launch Siri and verify that it's actively listening
         * 
         * @param {object} args - Test arguments
         * @param {int} [args.timeout = 120] - number of seconds to wait for Siri Listening Mode to go away
         */
        launchAndVerifySiriActive: function launchAndVerifySiriActive(args) {
            args = UIAUtilities.defaults(args, {
                timeout: 120,
            });
            siri.launchAndVerifySiriActive(args);
        },

        /**
         * Ask Siri a query (text) and verify UI Elements
         * 
         * @param {object} args - Test arguments
         * @param {int} [args.timeout = 30] - number of seconds to wait for command to complete
         * @param {string} [args.query = "What time is it?"] - the query for Siri
         * @param {array} [args.verficationArray = ["clock#showTimeInCurrentLocation"]] - Specify strings to use for test result verification. Each string must be present for the test to pass.
         */
        askSiri: function askSiri(args) {
            args = UIAUtilities.defaults(args, {
                timeout: 30,
                query: 'What time is it?',
                verficationArray: ['clock#showTimeInCurrentLocation']
            });
             
             var waitOptions = {
                timeout: args.timeout,
                logicalOperation: siri.LogicalOperations.AND,
                ignoreCase: true,
            };

            siri.askSiri(args);

            if (!siri.waitForMultipleStringsInAssistant(args.verficationArray, waitOptions)) {
                UIALogger.logMessage('Could not all the expected strings');
                siri.throwErrorWithAssistantInfo('Could not verify all the elements in the verification array %0'.format(args.verficationArray));
            }
        }
    }
}
