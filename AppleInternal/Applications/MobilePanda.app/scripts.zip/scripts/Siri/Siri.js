load('UIAApp.js');
load('SpringBoard.js');
load('Phone.js');

if (typeof template === 'undefined') {

    /**************************************************************************/
    /*                                                                        */
    /*   Mark: Query Constants                                                */
    /*                                                                        */
    /*      App specific queries that will be made frequently                 */
    /*                                                                        */
    /**************************************************************************/

    /** Constants for common template queries */
    UIAQuery.Siri = {
        /** Microphone button */
        MICROPHONE_BUTTON: UIAQuery.buttons('Listen'),

        /** Listening element - active if Siri is currently listening */
        LISTENING_ELEMENT: UIAQuery.query('Listening'),

        /** User utterance element */
        USER_UTTERANCE_ELEMENT: UIAQuery.query('SiriUserUtteranceView').bottommost(),

        /** Speech edit element */
        SPEECH_EDIT_ELEMENT: UIAQuery.textViews('SiriSpeechRecognizedCorrectionTextView'),

        /** Siri window */
        SIRI_WINDOW: UIAQuery.windows('SBAssistantWindow'),
    };

    /** Siri collection view */
    UIAQuery.Siri.SIRI_COLLECTION_VIEW = UIAQuery.Siri.SIRI_WINDOW.andThen(UIAQuery.collectionViews());


    /**************************************************************************/
    /*                                                                        */
    /*   Mark: UI State Constants                                             */
    /*                                                                        */
    /*      A dictionary of strings describing the possible UI states of      */
    /*      the app                                                           */
    /*                                                                        */
    /**************************************************************************/

    /** Constants for possible UI state names specific to Siri */
    UIStateDescription.Siri = {
    /** Favorites */
        FAVORITES:              'favorites',
    };


    /**
     * @namespace {UIAApp} siri
     */
    var siri = target.appWithBundleID('com.apple.siri');


    /**************************************************************************/
    /*                                                                        */
    /*   Mark: Other Constants                                                */
    /*                                                                        */
    /*      Any other app specific constants                                  */
    /*                                                                        */
    /**************************************************************************/

    /**
     *  Constants for possible states
     *
     *  @namespace
     */

    States = {

    /**  active */
        ACTIVE: 'Active',

    /**  inactive */
        INACTIVE: 'Inactive',

    /**  unknown */
        UNKNOWN: 'Unknown',
    };

    Strings = {
        /** String at the end of user speech cells */
        TAP_TO_EDIT: ', tap to edit',
    }

    /**
     *  Constants for logical operations
     */
    siri.LogicalOperations = {
        /** AND */
        AND: 'AND',

        /** OR */
        OR: 'OR',
    }


    /**************************************************************************/
    /*                                                                        */
    /*   Mark: Get The Current UI State                                       */
    /*                                                                        */
    /*      A function to determine which UIState the app is currently in     */
    /*                                                                        */
    /**************************************************************************/

    /**
     * Return description of current UI state. See UIStateDescription constants
     * defined in UIAApp and Template for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
     **/
    siri.currentUIState = function currentUIState() {
        if (springboard.exists(UIAQuery.Siri.SIRI_WINDOW)) {
            return States.ACTIVE;
        } else {
            return States.INACTIVE;
        }
    }


    /**************************************************************************/
    /*                                                                        */
    /*   Mark: Tasks                                                          */
    /*                                                                        */
    /*      A high-level goal we are trying to accomplish. E.g. -             */
    /*      composeAndSendEmail. These will be comprised of multiple Action   */
    /*      functions                                                         */
    /*                                                                        */
    /**************************************************************************/

    /**
     * Goes to the screen with the microphone button if we're not already there,
     * submits the voice control file to the Assistant and taps the
     * microphone button.
     *
     * @param {string|array} path - A string or an array of strings to specify the path(s) of the input speech file(s).
     * @param {object} options
     * @param {array} [options.verficationArray] - Specify strings to be used for verification. All items must be present for the test to pass.
     * @param {int} [options.timeout=90] - Amount of time to allow for each verification string to be found
     * @param {boolean} [options.scrollUp=false] - Specify true if you want to scroll up after launching Siri. (This will use persistent conversation)
     * @param {int|string} [options.orientation=1] - Sets the device to the orientation specified. Note that the device will stay in this orientation, unless this is is called again with a different orientation.
     * @param {boolean} [options.useSiriFromLockScreen=false] - Specify true if you want to use siri while the device is locked.
     * @param {string} [options.revertToTextOnFail=null] - A string to use for the command as backup, in case Siri does not recognize the voice command.
     *
     * @throws Throws UIAError if an error occurs
     **/
    siri.issueVoiceCommand = function issueVoiceCommand(path, options) {
        if (!path) {
            throw new UIAError('No path specified--must supply a string or array of strings as the path');
        }
        if (typeof path === 'string') {
            path = [path];
        }
        if (typeof path !== 'object') {
            throw new UIAError('Must enter a string or array of strings');
        }

        options = UIAUtilities.defaults(options, {
            verificationArray: [],
            timeout: 90,
            scrollUp: false,
            orientation: 1,
            useSiriFromLockScreen: false,
            revertToTextOnFail: null
        });

        // Ensure the input paths exist
        UIALogger.logDebug('Verifying %0 input path(s)'.format(path.length));
        for (var i = 0; i < path.length; i++) {
            if (!UIAFile.fileExists(path[i])) {
                UIALogger.logMessage('Verifying input path: %0'.format(path[i]));
                throw new UIAError('Input path does not exist', {identifier:'Input user utterance does not exist'});
            }
        }

        // Ensure there are no active phone calls
        if (target.activeCallCount() > 0) {
            UIALogger.logMessage('Ending an active phone call');
            phone.endCall();
        }

        // Set the device orientation if we pass in the correct parameter
        target.setDeviceOrientation(options.orientation);

        if (options.scrollUp === true) {
            // Launch Assistant and then scroll end of last conversation into view. Allows us to do persistent conversation tests.
            springboard.getToAssistant();
            springboard.scrollUp(UIAQuery.Siri.SIRI_COLLECTION_VIEW);
        }

        if (options.useSiriFromLockScreen === true) {
            UIALogger.logMessage('Locking device to run lock screen tests on Siri');
            UIATarget.localTarget().lock();
        }

        UIALogger.logDebug('Issuing voice command');
        target.setVoiceRecognitionAudioInputPaths(path);

        // Make sure Siri is active and listening
        if (springboard.exists(UIAQuery.Siri.MICROPHONE_BUTTON)) {
            // If microphone button exists, tap it
            springboard.tap(UIAQuery.Siri.MICROPHONE_BUTTON);
        } else if (this.isListening()) {
            // Else if listening, do nothing
            UIALogger.logDebug('Already listening');
        } else {
            // Else, bring up assistant
            springboard.getToAssistant();
        }

        // Needs to go through all elements in the verification array
        if (options.verificationArray.length > 0) {
            try {
                this.waitForMultipleStringsInAssistant(options.verificationArray, options);
            } catch (e) {
                UIALogger.logMessage('Caught Error: %0'.format(e.message));

                if (!this.isAssistantActive()) {
                    throw new UIAError('Siri is no longer frontmost');
                }

                // Make sure Siri is up
                if (!UIATarget.localTarget().isVoiceControlRunning()) {
                    throw new UIAError('Siri is not running');
                }
                // If we still can't find our verification strings then we either fail,
                // or revert to using text command instead.
                // If the "revertToTextOnFail" option is provided then we'll parse Siri's response to compare the command it understood with what was provided with the revertToTextOnFail option.
                // If they match, then the failure is caused by something else and we simply fail. If they don't, then use our string and see if we still get the same failure.
                if (options.revertToTextOnFail !== null) {

                    // Save the text command as string, instead of an object
                    var siriCommandText = options.revertToTextOnFail;
                    var speechCommandInterpretedBySiri = springboard.nameOf(UIAQuery.endsWith(Strings.TAP_TO_EDIT)).replace(Strings.TAP_TO_EDIT, '');

                    UIALogger.logMessage('Actual speech interpreted by Siri is %0'.format(speechCommandInterpretedBySiri));

                    // Compare both strings, and edit if they don't match
                    if (siriCommandText.toLowerCase() !== speechCommandInterpretedBySiri.toLowerCase()) {
                        this.editSiriCommandAndRun(siriCommandText);
                    }

                    // Try looking for the verification strings one more time. If not found then this'll simply throw an error as it did before.
                    UIALogger.logMessage('Check one more time for verification strings');
                    this.waitForMultipleStringsInAssistant(options.verificationArray, {timeout: 5});
                } else {
                    throw e;
                }
            }
        }

        if (options.useSiriFromLockScreen) {
            this.throwErrorIfDeviceNotLocked();
        }
    }


    /**************************************************************************/
    /*                                                                        */
    /*   Mark: Actions                                                        */
    /*                                                                        */
    /*      Atomic units of UI automation. E.g. - dialPhoneNumber             */
    /*      Other helper functions. E.g. - returnCleanedNumber                */
    /*                                                                        */
    /**************************************************************************/

    /**
     * Resets Siri.
     */
    siri.resetAssistant = function resetAssistant() {
        UIALogger.logMessage('Resetting Assistant');
        springboard.unlock();

        // Ensure there are no active phone calls
        if (target.activeCallCount() > 0) {
            UIALogger.logMessage('Ending an active phone call');
            phone.endCall();
        }

        // If we are in assistant, exit out of it so we have a fresh start
        if (this.isAssistantActive()) {
            target.clickMenu();
        }
    }

    /**
     * Checks to see if Siri is active.
     *
     * @returns {boolean} true if Siri is active, false otherwise.
     */
    siri.isAssistantActive = function isAssistantActive() {
        return this.currentUIState() === States.ACTIVE;
    }

    /**
     * Syncronizes Assistant with the server.
     *
     * @param {object} options
     * @param {int} [options.timeout=20] - Specify a timeout for the sync command
     *
     * @returns {boolean} true on success, false on failure
     */
    siri.synchronizeAssistant = function synchronizeAssistant(options) {
        options = UIAUtilities.defaults(options, {
            timeout: 20
        });

        var result = target.performTask('/usr/local/bin/assistant_tool', ['sync'], options.timeout);

        if (result.timedOut === true) {
            UIALogger.logError('assistant_tool sync timed out');
            return false;
        } else if (result.exitCode !== 0) {
            UIALogger.logError('assistant_tool sync returned code %0'.format(result.exitCode));
            UIALogger.logDebug('stdout: %0'.format(result.stdout));
            UIALogger.logDebug('stderr: %0'.format(result.stderr));
            return false;
        }

        return true;
    }

    /**
     * This function parses the args for the Siri test, searching for a "ambiguousHourRange" argument. If it finds it, it parses the string to check the time constraints during which Siri might behave differently, and adds the provided verification string to the list of acceptable speech identifiers.
     *
     * @param {array} verificationStringArray - specify the list of verification strings
     * @param {object} args - arguments passed to the Siri test
     *
     * @returns true if we find the "ambiguousHourRange" argument, false otherwise
     **/
    siri.addVerificationStringForSiriTimeConfusion = function addVerificationStringForSiriTimeConfusion(verificationStringArray, args) {

        // Get the current hour in 24 hour time (0-23)
        var date = new Date();
        var currentHour = date.getHours();

        UIALogger.logMessage('Current hour in which test is running: %0'.format(currentHour));

        // Check for a provided "ambiguousHourRange" argument. If this argument is provided then we suspect Siri might be confused about what we mean by "today", "tomorrow" or a certain time.
        // Here are a couple of examples:
        // Example A: We're giving a command that involves performing some action tomorrow. The term "tomorrow" confuses Siri whenever the test is running past midnight, so it asks for clarification whether we meant tomorrow as in "today" since it's past midnight or the next day. This clarification is in the form of asking the user to pick a date.

        // Example B: We ask Siri about an event time (reminder, calendar appointment, etc..) that is around the time we ask that question. Ex: At 6:05pm we ask Siri if we have any meetings, while we have one at 6pm. In this case, Siri currently ignores the 6pm meeting (since it's in the past as far as it's concerned) and checks for meetings later.

        // For both of these cases we have no choice but to acknowledge the response and pass the test. The argument defined in the ptest should be in the format "ambiguousHourRange:[fromTime]-[toTime],[verificationStringToHaveTheTestAcceptIncaseOfDateConfusion]".

        // So for example, if we have a device with a meeting scheduled at 6pm, and have a test that asks Siri if we have any meetings but that test might run between midnight and 4am, the following argument should be passed: ambiguousHourRange:0-4,Common#disambiguateRelativeDateInWitchingHour.
        // This will have our test check if we're running between 12am and 4am. If we are then add the verification string to our list of passing strings and count this as a pass.

        for (var i=1; i < args.length; i++) {

            // If we find a string matching "ambiguousHourRange", then start parsing the string to get the time windows and verification string out of it.
            // DISCLAIMER: this assumes the string matches the format we expect
            if (args[i].contains('ambiguousHourRange:')) {
                UIALogger.logMessage('Found "ambiguousHourRange" in args. Parsing value for time window and verification string');
                var splittingIndex = args[i].indexOf(':');

                // Get the string to parse values out of.
                // Ex: argumentValueToSplit would be 0-4,Common#disambiguateRelativeDateInWitchingHour
                var argumentValueToSplit = args[i].substr(splittingIndex + 1);

                // Value of timeWindowString would be 0-4
                var timeWindowString = argumentValueToSplit.substr(0, argumentValueToSplit.indexOf(','));
                UIALogger.logMessage('Time string to parse: %0'.format(timeWindowString));


                var timeFrom = timeWindowString.substr(0, timeWindowString.indexOf('-'));
                UIALogger.logMessage('Hour window start: %0'.format(timeFrom));
                var timeTo = timeWindowString.substr(timeWindowString.indexOf('-') + 1);

                UIALogger.logMessage('Hour window end: %0'.format(timeTo));

                // Value of disambiguationVerficationString would be Common#disambiguateRelativeDateInWitchingHour
                var disambiguationVerficationString = argumentValueToSplit.substr(argumentValueToSplit.indexOf(',') + 1);

                if (currentHour >= timeFrom && currentHour <= timeTo) {
                    UIALogger.logWarning('The test is running in a time window where Siri might be confused about time. Adding "%0" to verfication strings. The test now might pass even though Siri does not fully perform the action requested!'.format(disambiguationVerficationString));

                    if (!verificationStringArray) {
                        verificationStringArray = new Array();
                    }

                    verificationStringArray.push(disambiguationVerficationString);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Checks to see if Siri is actively listening.
     *
     * @returns {boolean} Returns true if Siri is listening, false otherwise.
     **/
    siri.isListening  = function isListening() {
        return springboard.exists(UIAQuery.Siri.LISTENING_ELEMENT);
    }

    /**
     * This function waits for the 'listening' mode to go away.  Assumes the siri window is up.
     *
     * @param {object} options
     * @param {int} [options.timeout=120] - Specify a timeout
     *
     * @returns {float} Returns the number of seconds it took for listening mode to go away
     **/
    siri.waitForListeningModeToGoAway  = function waitForListeningModeToGoAway(options) {
        options = UIAUtilities.defaults(options, {
            timeout: 120
        });

        UIALogger.logMessage('Waiting up to %0 seconds for listening mode to end'.format(options.timeout));
        var startTime = UIAUtilities.getCurrentTimeInSeconds();
        springboard.waitUntilAbsent(UIAQuery.Siri.LISTENING_ELEMENT, options.timeout);

        var currentTime = UIAUtilities.getCurrentTimeInSeconds();
        UIALogger.logMessage('No longer in listening mode');
        return (currentTime - startTime);
    }

    /**
     * This function looks in the siri window, waiting for the input string to be found.
     *
     * @param {string} theString - the string for which to look
     * @param {object} options
     * @param {int} [options.timeout=120] - max time to look for the string
     * @param {boolean} [options.ignoreCase=false] - specify true for a case-insensitive search
     *
     * @returns {boolean} true if the string is found, false otherwise
     **/
    siri.waitForStringInSiri = function waitForStringInSiri(theString, options) {
        options = UIAUtilities.defaults(options, {
            timeout: 120,
            ignoreCase: false
        });

        UIALogger.logMessage('Waiting %0 seconds for the following string to appear: %1'.format(options.timeout, theString));

        var containsModifier = '';
        if (options.ignoreCase) {
            containsModifier = '[c]';
            UIALogger.logMessage('Using case-insensitive search for string verification');
        }

        var startTime = UIAUtilities.getCurrentTimeInSeconds();
        this.waitForListeningModeToGoAway(options.timeout);

        do {
            var query = UIAQuery.withPredicate('name contains%0 "%1"'.format(containsModifier, theString));
            try {
                if (springboard.waitUntilPresent(query, 1)) {
                    var element = springboard.inspect(query);
                    UIALogger.logMessage('Found element: %0'.format(element));
                    return true;
                } else {
                    var errorElement = this.assistantErrorOnScreen();
                    if (errorElement !== null) {
                        UIALogger.logMessage('Error element name: %0'.format(errorElement.name));
                        if (errorElement.name.toLowerCase().contains('error#inputprocessingdelay')) {
                            UIALogger.logMessage('Found an error element, but it was an inputProcessingDelay; continuing');
                        } else {
                            UIALogger.logMessage('Found an error element');
                            return false;
                        }
                    }
                }
            } catch (e) {
                UIALogger.logError('Caught exception: %0'.format(e));
                return false;
            }
        } while (UIAUtilities.getCurrentTimeInSeconds() < options.timeout + startTime);

        UIALogger.logMessage('String not found');
        return false;
    }

    /**
     * Looks for an error string on the current page and returns whatever it can find.
     *
     * @returns {string} the element if there is one or null if there isn't one.
     **/
    siri.assistantErrorOnScreen = function assistantErrorOnScreen() {
        var errorStrings = [
            'error#',
            'phoneCall#networkUnavailable',
            'common#',
            'microblog#errorNoAccountSetup',
            'microblog#errorPostingBlog',
            'microblog#authenticationFailure',
            'sportsUnsure#serviceHadAnError',
            'sportsStats#athleteStatUnavailable',
            'createSms#iMessageNotAvailable',
            'stock#serviceNotAvailable',
            'take any requests right now',
            'take any requests at the moment',
            'Leider kann ich gerade keine Anfragen beantworten. Versuche es bitte sp',
            'Je ne peux pas donner suite à vos requêtes pour le moment. Veuillez réessayer dans un instant.',
            '申し訳ありませんが、現在リクエストをお受けできません。もう少ししてからやり直してくださ',
            'al momento non posso accettare richieste',
            'siento mucho pero ahora mismo no puedo ayudarte',
            '잠시 후에 다시 시도하십시오',
            'Connect to the Internet',
        ];

        for (var i = 0; i < errorStrings.length; i++) {
            var query = UIAQuery.withPredicate('name contains[c] "%0"'.format(errorStrings[i]));
            var errorElement = springboard.inspect(query);
            if (errorElement !== undefined) {
                return errorElement;
            }
        }

        return null;
    }

    /**
     * Looks for an error string on the current page and returns true if one is found.
     *
     *  @returns {boolean} true if there is an error on screen, false otherwise.
     **/
    siri.isAssistantErrorOnScreen = function isAssistantErrorOnScreen() {
        var errorElement = this.assistantErrorOnScreen();

        if (errorElement === null) {
            UIALogger.logDebug('No error element found on-screen');
            return false;
        } else {
            UIALogger.logMessage('Error element found on-screen');
            return true;
        }
    }

    /**
     * Waits for an element with a specified string to appear in assistant. If an array of strings are passed in, it returns only after it finds all of them.
     *
     * @param {array|string} theStrings - string or array of strings to wait for.
     * @param {object} options
     * @param {int} [options.timeout] - max number of seconds to wait for string to appear.
     * @param {string} [options.logicalOperation] - specify the logical operation
     * @param {boolean} [options.ignoreCase=false] - specify true for a case-insensitive search
     *
     * @throws if one of the expected strings is not found
     **/
    siri.waitForMultipleStringsInAssistant = function waitForMultipleStringsInAssistant(theStrings, options) {
        options = UIAUtilities.defaults(options, {
            timeout: 90,
            logicalOperation: this.LogicalOperations.AND,
            ignoreCase: false
        });

        var absoluteTimeout = options.timeout;
        if (options.logicalOperation === this.LogicalOperations.OR) {
            options.timeout = 1;
        }

        if (typeof theStrings === 'string') {
            theStrings = [theStrings];
        }

        if (typeof theStrings === 'object') {
            UIALogger.logMessage('looking for %0 strings with logical operation: %1'.format(theStrings.length, options.logicalOperation));

            if (options.logicalOperation === this.LogicalOperations.AND) {
                for (var i = 0; i < theStrings.length; i++) {
                    var theString = theStrings[i];
                    var theResult = this.waitForStringInSiri(theString, options);
                    if (theResult === false) {
                        this.throwErrorWithAssistantInfo('Could not find string in Assistant: %0'.format(theString));
                    }
                    UIALogger.logDebug('Found string string in Assistant: %0'.format(theString));
                }
            } else if (options.logicalOperation === this.LogicalOperations.OR) {
                var startTime = UIAUtilities.getCurrentTimeInSeconds();
                do {
                    for (var i = 0; i < theStrings.length; i++) {
                        var theString = theStrings[i];
                        var theResult = this.waitForStringInSiri(theString, options);
                        if (theResult === true) {
                            UIALogger.logDebug('Found string string in Assistant: %0'.format(theString));
                            return true;
                        }
                    }
                } while (UIAUtilities.getCurrentTimeInSeconds() <= startTime + absoluteTimeout);

                this.throwErrorWithAssistantInfo('Could not find strings in Assistant: %0'.format(theStrings));
            } else {
                throw new UIAError('Invalid argument for logicalOperation');
            }

            return true;
        } else {
            throw new UIAError('Invalid argument passed in; first parameter should be either a string or array of strings');
        }
    }

    /**
     * Throws an error with the relevant assistant info. This is intended to be
     * called when an error occurs in a Siri test.
     *
     * @param {string} theError - specify a string describing the error
     *
     * @throws Always throws a UIAError
     **/
    siri.throwErrorWithAssistantInfo = function throwErrorWithAssistantInfo(theError) {
        UIALogger.logMessage('Error encountered: %0'.format(theError));

        // Check for an error and set the error ID
        var errorElement = this.assistantErrorOnScreen();
        var errorID = null;
        if (errorElement !== null) {
            UIALogger.logMessage('Found error element with name: %0'.format(errorElement.name));
            errorID = errorElement.name;
        } else {
            UIALogger.logMessage('Setting error ID to theError');
            errorID = theError;
        }

        throw new UIAError(theError, {identifier:errorID});
    }

    /**
     * Taps the command bubble in Siri's response, and replaces the command text with the argument string.
     * It then taps done in the keyboard, letting Siri pick up the modified command and run it.
     *
     * @param {string} siriCommandText - Specify the string to enter
     **/
    siri.editSiriCommandAndRun = function editSiriCommandAndRun(siriCommandText) {

        // Tap the user utterance to enable editing
        springboard.tap(UIAQuery.Siri.USER_UTTERANCE_ELEMENT);

        // Enter the new text
        springboard.enterText(UIAQuery.Siri.SPEECH_EDIT_ELEMENT, siriCommandText);

        // Dismiss the keyboard
        springboard.tap(UIAQuery.DONE_BUTTON);
    }

    /**
     * Throws an error if the device is not locked.
     *
     * @throws UIAError
     **/
    siri.throwErrorIfDeviceNotLocked = function throwErrorIfDeviceNotLocked() {
        if(!target.isLocked()) {
            throw new UIAError('Device was unlocked when it was expected to be locked');
        }
    }

    /**
     * Launch Siri and verify that it's actively listening
     *
     * @param {object} args - Test arguments
     * @param {int} [args.timeout] - number of seconds to wait for Siri Listening Mode to go away
     **/
    siri.launchAndVerifySiriActive = function launchAndVerifySiriActive(args) {
        springboard.getToAssistant();
        if (this.isAssistantActive()) {
            UIALogger.logMessage('Siri has launched and is active');
            this.waitForListeningModeToGoAway(args.timeout);
        }
    }

    /**
     * Ask Siri a query using assistant_tool
     *
     * @param {object} options - Test arguments
     * @param {int} [options.timeout] - number of seconds to wait for Siri Listening Mode to go away
     * @param {string} [options.query] - the query for Siri
     **/
    siri.askSiri = function askSiri(options) {
        options = UIAUtilities.defaults(options, {
            query: 'What time is it?',
            timeout: 30,
        });

        target.performTask('/usr/local/bin/assistant_tool', ['startUIRequest', options.query], options.timeout);
    }
}
