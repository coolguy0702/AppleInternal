load('UIATesting.js');
load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof SystemTests === 'undefined',
    'SystemTests has already been defined.'
);

var SystemTests = {
    /**
     * Lock the device, wait for the specified amount of time, then unlock the device
     *
     * @note Default test (no arguments) waits for 5 seconds
     *
     * @param {object} args - Test arguments
     * @param {number} [args.lockTime=5] - Number of seconds to stay locked
     * @param {string} [args.passcode=null] - Passcode to use if set
     */
    lockAndUnlockDevice: function lockAndUnlockDevice(args) {
        args = UIAUtilities.defaults(args, {
            lockTime: 5,
            passcode: null,
        });

        // FIXME: lock() and unlock() throw instead of returning true/false
        // on newer versions of scripter2. Support both for now.
        var locked = target.systemApp().lock();
        if ((typeof locked === 'undefined' || locked) && target.isLocked()) {
            target.delay(args.lockTime);
        } else {
            throw new UIAError('Could not lock device');
        }

        var dict = (args.passcode !== null) ? {passcode: args.passcode} : {}
        var unlocked = target.systemApp().unlock(dict);
        if (typeof unlocked === 'undefined' || unlocked) {
            UIALogger.logPass('Successfully locked and unlocked device');
        } else if (args.passcode) {
            throw new UIAError('Could not unlock device with passcode');
        } else {
            throw new UIAError('Could not unlock device');
        }

    },
};
