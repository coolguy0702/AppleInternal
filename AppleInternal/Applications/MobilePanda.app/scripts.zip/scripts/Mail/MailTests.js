load('UIATesting.js');
load('Mail.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof MailTests === 'undefined',
    'MailTests has already been defined.'
);

/**
 * @namespace
 */
var MailTests = {
    /**
     * Compose and send an email
     *
     * @targetApps MobileMail
     *
     * @note Default test (no arguments) sends an email to the persisted email address
     *
     * @param {object} args - Test arguments
     * @param {string} [args.recipient="PERSISTEDAPPLEID"] - Required email recipient address
     * @param {string} [args.subject="This is a test subject"] - Optional email subject
     * @param {string} [args.text="This is a test message body text"] - Optional email body text
     * @param {string} [args.sender=null] - Optional email sender address, used for backwards compatibility
     * @param {string} [args.account=null] - Optional email sender address, replaces sender when both are specified
     *
     * @param {object} [args.attachOptions={}] - Optionals to add attachments
     * @param {boolean} [args.attachOptions.attachPhoto=false] - Optional attach a photo to emails
     * @param {string|null} [args.attachOptions.collectionName="Camera Roll"] - Optional name of collection
     *                          to attach photo from. Use with attachOptions.attachPhoto.
     */
    composeAndSendEmail: function composeAndSendEmail(args) {
        args = UIAUtilities.defaults(args, {
            recipient: 'PERSISTEDAPPLEID',
            subject: 'This is a test subject',
            text: 'This is a test message body text',
            sender: null,
            account: null,
            // attach options
            attachOptions: {
                attachPhoto: false,
                collectionName: 'Camera Roll',
            },
        });

        if (args.recipient === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as recipient');
            args.recipient = springboard.appleID;
        }

        if (args.account) {
            args.sender = args.account;
        }

        if (args.sender === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as sender');
            args.sender = springboard.appleID;
        }

        mail.launch();
        mail.composeAndSendEmail(args);
    },

    /**
     * Find and Respond to an email
     *
     * @targetApps MobileMail
     *
     * @note Default test (no arguments) sends an email to the persisted email address
     *
     * @param {object} args - Test arguments
     * @param {string} [args.search="This is a test subject"] - String to search for
     * @param {string} [args.account="PERSISTEDAPPLEID"] - Address or account description
     * @param {string} [args.folder="Sent"] - Folder in which to search
     * @param {bool}   [args.shouldOpenEmail=true] - Whether email should be opened
     * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
     * @param {string} [args.text="This is a test response body text"] - Response body text
     * @param {string} [args.action="reply"] - Response type: reply, 'reply all', or forward
     * @param {string} [args.recipient="PERSISTEDAPPLEID"] - Email to send for forward responding
     */
    respondToEmail: function respondToEmail(args) {
        args = UIAUtilities.defaults(args, {
            search: 'This is a test subject',
            account: 'PERSISTEDAPPLEID',
            folder: 'Sent',
            shouldOpenEmail: true,
            timeout: 60,
            text: 'This is a test response body text',
            action: 'reply',
            recipient: 'PERSISTEDAPPLEID',
        });

        if (args.recipient === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as recipient');
            args.recipient = springboard.appleID;
        }

        if (args.account === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as sender');
            args.account = springboard.appleID;
        }

        mail.respondToEmail(args);
    },

    /**
     * Verify that an email exists in folder
     *
     * @targetApps MobileMail
     *
     * @note Default test (no arguments) Looks for email that was just sent to persisted email account
     *
     * @param {object} args - Test arguments
     * @param {string} [args.subject="This is a test subject"] - Email subject to match
     * @param {string} [args.account="PERSISTEDAPPLEID"] - Address or account description
     * @param {string} [args.folder="Inbox"] - Folder in which to look for email
     * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
     */
    verifyEmailInFolder: function verifyEmailInFolder(args) {
        args = UIAUtilities.defaults(args, {
            subject: 'This is a test subject',
            account: 'PERSISTEDAPPLEID',
            folder: 'Inbox',
            timeout: 60,
        });

        if (args.account === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as account');
            args.account = springboard.appleID;
        }

        if (mail.verifyEmailExists(args)) {
            UIALogger.logMessage('Found email with subject "%0"'.format(args.subject));
        } else {
            throw new UIAError('Could not find email with subject "%0"'.format(args.subject));
        }
    },

    /**
     * Search for mail matching search string
     *
     * @targetApps MobileMail
     *
     * @note Default test (no arguments) Looks for email that was just sent to persisted email account
     *
     * @param {object} args - Test arguments
     * @param {string} [args.search="This is a test subject"] - String to search for
     * @param {string} [args.account="PERSISTEDAPPLEID"] - Address or account description
     * @param {string} [args.folder="Inbox"] - Folder in which to search
     * @param {bool}   [args.shouldOpenEmail=false] - Whether email should be opened
     * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
     */
    searchForMail: function searchForMail(args) {
        args = UIAUtilities.defaults(args, {
            search: 'This is a test subject',
            account: 'PERSISTEDAPPLEID',
            folder: 'Inbox',
            shouldOpenEmail: false,
            timeout: 60,
        });

        if (args.account === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as account');
            args.account = springboard.appleID;
        }

        if (!mail.searchForMail(args)) {
            throw new UIAError('Could not find email searching for "%0"'.format(args.search), {identifier:'Could not find email matching search'});
        }
    },

    /**
     * Respond to calendar invite
     *
     * @targetApps MobileMail
     *
     * @note Default test (no arguments) Looks for email that was just sent to persisted email account
     *
     * @param {object} args - Test arguments
     * @param {string} [args.search="This is a test subject"] - String to search for
     * @param {string} [args.account="PERSISTEDAPPLEID"] - Address or account description
     * @param {string} [args.folder="Inbox"] - Folder in which to search
     * @param {string} [args.response="Accept"] - Response to invite
     * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
     */
    respondToCalendarInvite: function respondToCalendarInvite(args) {
        args = UIAUtilities.defaults(args, {
                                     search: 'This is a test subject',
                                     account: 'PERSISTEDAPPLEID',
                                     folder: 'Inbox',
                                     response: 'Accept',
                                     timeout: 60,
                                     });

        mail.launch();
        try{
            mail.respondToInvite(args);
        }
        catch (e) {
            UIALogger.logError(e);
            throw e;
        }
    },


    /**
     * Performs an Orb peek gesture on an email and verifies that the peek view appears.
     *
     * @targetApps MobileMail
     *
     * @param {object} args Test arguments
     * @param {string} [args.emailIdentifier=""] - email name to search for; first email in folder by default
     * @param {string} [args.peekValidation="Message"] - a string to search for within the peek view
     */
    peekAtEmail: function peekAtEmail(args) {
        args = UIAUtilities.defaults(args, {
            emailIdentifier: null,
            peekValidation: 'Message',
        });

        mail.getToEmailFolder();

        var emailQuery;
        if (args.emailIdentifier) {
            emailQuery = UIAQuery.Mail.MAIL_TABLEVIEW.andThen(UIAQuery.tableCells().withPredicate("name contains[c] '" + args.emailIdentifier + "'"));
        } else {
            emailQuery = UIAQuery.Mail.MAIL_TABLEVIEW.andThen(UIAQuery.tableCells().first());
        }

        try {
            mail.touchDownForPeekGesture(emailQuery);

            UIAUtilities.assert(
                mail.currentUIState() === UIStateDescription.PEEK_VIEW,
                'We are not in mail peek view.'
            );

            UIAUtilities.assert(
                mail.exists(UIAQuery.ORB_PEEK_VIEW.andThen(UIAQuery.query(args.peekValidation))),
                "Peek view doesn't contain the expected message info"
            );
        } finally {
            mail.releaseTouches();
        }
    },

    /**
     * Performs an Orb pop gesture on an email and verifies that the detail view appears.
     *
     * @targetApps MobileMail
     *
     * @param {object} args Test arguments
     * @param {string} [args.emailIdentifier=""] - email name to search for; first email in folder by default
     * @param {string} [args.popValidation=""] - a string to search for within the detail view; first part of
     *                  name of tapped cell by default
     */
    popForEmailDetails: function popForEmailDetails(args) {
        args = UIAUtilities.defaults(args, {
            emailIdentifier: null,
            popValidation: null,
        });

        mail.getToEmailFolder();

        var emailQuery;
        if (args.emailIdentifier) {
            emailQuery = UIAQuery.Mail.MAIL_TABLEVIEW.andThen(UIAQuery.tableCells().withPredicate("name contains[c] '" + args.emailIdentifier + "'"));
        } else {
            emailQuery = UIAQuery.Mail.MAIL_TABLEVIEW.andThen(UIAQuery.tableCells().first());
        }

        var popQuery;
        if (args.popValidation) {
            popQuery = UIAQuery.withPredicate("name contains[c] '" + arg.popValidation + "'");
        } else {
            var queryStr = mail.inspect(emailQuery).name.split(',');
            UIALogger.logDebug("Cell name is " + queryStr);

            var predicate = [];
            for (var i = 0; i < queryStr.length; i++) {
                predicate.push("value beginswith '" + queryStr[i].trim().replace(/['"]/g, "\\$&") + "'");
            }
            predicate = predicate.join(' OR ');
            popQuery = UIAQuery.withPredicate("name == 'Subject' AND (" + predicate + ")");
        }

        mail.touchForPopGesture(emailQuery);

        UIAUtilities.assert(
            mail.currentUIState() === UIStateDescription.Mail.EMAIL_CONTENT,
            'We are not in mail details view.'
        );

        UIAUtilities.assert(
            mail.exists(popQuery),
            "Pop view doesn't contain the expected email info"
        );
    },

    /**
     * Searches for email, taps it, and prints that email.
     * Requires: The account exists, the item to be searched for exists and some AirPrintPrinter can be found by the device.
     *
     *  @targetApps MobileMail
     *
     *  @param {object} args Test arguments
     *  @param {string} [args.search=null] - the string to be searched for.  If no string is specified a random email will be printed.
     *  @param {string} [args.account=null] - the address or description of the account to be searched
     *  @param {string} [args.folder=null] - folder to search
     *  @param {boolean} [args.shouldOpenEmail=true] - the email will be selected.
     *  @param {int} [args.timeout=60] - the time alotted for a search.
     *  @param {int} [args.emailIndex=0] - the index of the email to be selected if no search criteria are specified.
     *  @param {string} [args.printerName=null] - the name of the printer. If no value is specified, a random printer is selected
     *  @param {number} [args.numberOfCopies=1] - the number of print copies. If no value is specified, the default value is not changed.
     *  @param {boolean} [args.doubleSided=null] - true if the double sided swith is set to print the document double sided. If null the default value is not changed.
     *  @param {boolean} [args.blackWhite=null] - true if the document is to be printed in black and white. If null the default value is not changed.
     *
     **/
    printEmail: function printEmail(args) {
        args = UIAUtilities.defaults(args, {
            //search for email options
            search: null,
            account: null,
            folder: null,
            shouldOpenEmail: true,
            timeout: 60,
            emailIndex: 0,

            //printing options
            printerName:null,
            numberOfCopies:1,
            doubleSided: null,
            blackWhite: null,
        });

        mail.openAnEmail(args);
        mail.printEmail(args);
    },

    /**
     * Open and view random emails.
     *
     * @targetApps MobileMail
     *
     * @param {object} args - Test arguments
     * @param {string} [args.folder="Inbox"] - Folder in which to view emails
     * @param {string} [args.emailCount=5] - Number of emails to view
     */
    viewRandomEmails: function viewRandomEmails(args) {
        args = UIAUtilities.defaults(args, {
            emailCount: 5,
            folder: 'Inbox',
        });

        mail.viewEmails(args);
    },

    /**
     * Download an attachment from email. The email chosen is based on passed search string.
     * If no search infomation is given, we open the first email.
     *
     * @targetApps MobileMail
     *
     * @param {object} args - Test arguments
     * @param {string} [args.type="image"] - Attachment type
     * @param {string} [args.search="This is a test subject"] - String to search for
     * @param {string} [args.account="PERSISTEDAPPLEID"] - Address or account description
     * @param {string} [args.folder="Inbox"] - Folder in which to email resides
     * @param {bool}   [args.shouldOpenEmail=true] - Whether email should be opened
     * @param {int}    [args.timeout=60] - Number of seconds to wait for search match to appear. Default 1 minute
     */
    downloadAttachment: function downloadAttachment(args) {
        args = UIAUtilities.defaults(args, {
            type: 'Image',
            search: 'This is a test subject',
            account: 'PERSISTEDAPPLEID',
            folder: 'Inbox',
            shouldOpenEmail: true,
            timeout: 60,
        });

        if (args.account === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID as account');
            args.account = springboard.appleID;
        }

        mail.downloadAttachment(args);
    },
}
