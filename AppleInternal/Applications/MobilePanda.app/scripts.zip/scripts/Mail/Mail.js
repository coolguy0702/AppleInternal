load('UIAApp.js');
load('UIAApp+Mail.js');
load('SpringBoard.js');

if (typeof mail !== 'undefined') {
    if (!(mail instanceof UIAApp)) {
        throw new UIAError("mail has already been defined to something not an instance of UIAApp! Value: %0".format(mail));
    }
    if (mail.bundleID() !== 'com.apple.mobilemail') {
        var oldDefinition = mail.bundleID();
        var mail = target.appWithBundleID('com.apple.mobilemail');
        UIALogger.logWarning("'mail' was redefined from '%0' to '%1'".format(oldDefinition, mail.bundleID()));
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Mail queries */
UIAQuery.Mail = {
    /** Common buttons **/

    /** Compose new email button */
    COMPOSE_BUTTON: UIAQuery.buttons('Compose'),

    /** Reply to email button */
    REPLY_BUTTON: UIAQuery.buttons('Reply'),

    /** Reply All button */
    REPLY_ALL_BUTTON: UIAQuery.buttons('Reply All'),

    /** Forward button */
    FORWARD_BUTTON: UIAQuery.buttons('Forward'),

    /** See More button */
    SEE_MORE_BUTTON: UIAQuery.buttons().andThen(UIAQuery.beginsWith('See More').first()),

    /** Navigation bar with 'New Message' title */
    NEW_MESSAGE_NAVBAR: UIAQuery.navigationBars('New Message'),

    /** Navigation bar with 'Thread' title */
    THREAD_NAVBAR: UIAQuery.staticTexts('Thread'),

    /** Navigation bar with '# Messages' title */
    MULTIPLE_MESSAGES_NAVBAR: UIAQuery.staticTexts().withPredicate('name MATCHES "^[0-9]+ Messages$"'),

    /** Navigation bar with 'Mailboxes' title */
    MAILBOXES_NAVBAR: UIAQuery.staticTexts('Mailboxes'),

    /** Button with 'Mailboxes' name */
    MAILBOXES_BUTTON: UIAQuery.buttons('Mailboxes'),

    /** Navigation bar with reply title */
    REPLY_MESSAGE_NAVBAR: UIAQuery.navigationBars().contains('Re:'),

    /** Navigation bar with forward title */
    FORWARD_MESSAGE_NAVBAR: UIAQuery.staticTexts().contains('Fwd:').orElse(UIAQuery.navigationBars().contains('Fwd:')),

    CANCEL_BUTTON: UIAQuery.buttons('Cancel').isVisible(),

    DONE_BUTTON: UIAQuery.buttons('Done').isVisible(),

    BACK_BUTTON: UIAQuery.BACK_NAV_BUTTON.isVisible(),

    /** Mail messages table – this was renamed from MailMessagesTableView in 14A222 to MFSwipableTableView in 14A223 */
    MAIL_TABLEVIEW: UIAQuery.tableViews('MailMessagesTableView').orElse(UIAQuery.tableViews('MFSwipableTableView')),

    /** Mail detail view */
    EMAIL_CONTENT_VIEW: UIAQuery.contains('MFConversationView'),

    /** Trash All button */
    TRASH_ALL_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Trash All')),

    /** Image attachment within a message */
    MESSAGE_IMAGE_ATTACHMENT: UIAQuery.query('WebAccessibilityObjectWrapper').andThen(UIAQuery.images()),

    /** Large image email prompt small button used to recognize prompt*/
    SMALL_IMAGE_SIZE: UIAQuery.buttons().contains('Small'),

    /** Save draft button on prompt after cancelling an unsent email */
    SAVE_DRAFT_BUTTON: UIAQuery.buttons('Save Draft'),

    /** Search Bar at top of a mail box */
    SEARCH_BAR: UIAQuery.searchBars('MailSearchBar'),

    SWITCH_TO_FULL_SCREEN_BUTTON: UIAQuery.buttons("Switch to full screen mode"),

    CELL_STATIC_VIEW:"_CellStaticView",
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Mail */
UIStateDescription.Mail = {
    /** 'Welcome to Mail' page when no account is signed in */
    WELCOME_TO_MAIL:            'welcome page (no account signed in)',

    /** Mailboxes */
    MAILBOXES_VIEW:             'mailboxes',

    /** Mailboxes (edit) */
    MAILBOXES_VIEW_EDIT:        'mailboxes (edit)',

    /** Email folder view (email folder view, EXCLUDING predefined views such as drafts, sent, VIP) */
    MAIL_FOLDER:                'mail folder',

    /** Edit view for any mail folder INCLUDING predefined views such as drafts, sent, VIP) */
    MAIL_FOLDER_EDIT:           'mail folder (edit)',

    /** Thread view of mail messages */
    MAIL_THREAD:                'mail thread',

    /** Drafts folder */
    DRAFTS_FOLDER:              'drafts folder',

    /** Sent folder */
    SENT_FOLDER:                'sent folder',

    /** Flagged folder */
    FLAGGED_FOLDER:             'flagged folder',

    /** VIP folder */
    VIP_FOLDER:                 'vip folder',

    /** Email content */
    EMAIL_CONTENT:              'email content',

    /** Search View */
    SEARCH_VIEW:                'search view',

    /** Search View */
    ACCOUNT_FOLDER:             'account folder',

    /** Image size prompt */
    IMAGE_SIZE_PROMPT:          'image size prompt',

    /** Save draft prompt when cancelling an unsent email */
    SAVE_DRAFT_PROMPT:          'save draft prompt',

    /** Prompt - Share menu/delete dialogue/ect */
    PROMPT:                     'prompt view',

    /** Expanded email view after tapping 'See More' */
    SEE_MORE:                   'see more view',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var mail = target.appWithBundleID('com.apple.mobilemail');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.
 * See UIStateDescription constants defined in UIAApp and Mail for possible values.
 *
 * @returns {string} Description of current UI state from a list of
 *                      possible constants contained in UIStateDescription.
 */
mail.currentUIState = function currentUIState() {

    var currentUIState =  this.__proto__.currentUIState.apply(this);
    if (currentUIState !== UIStateDescription.UNKNOWN
        && currentUIState !== UIStateDescription.MAIL_COMPOSITION) {
            return currentUIState;
    }

    var appInfo = this.inspect(UIAQuery.application());
    var navbar = appInfo.inspect(UIAQuery.navigationBars().isVisible());
    var navbarName = navbar ? navbar.name : null;

    switch(navbarName) {
        case 'Welcome to Mail':
            return UIStateDescription.Mail.WELCOME_TO_MAIL;
        case 'Mailboxes':
            if (appInfo.exists(UIAQuery.NAV_BAR_DONE_BUTTON)) {
                return UIStateDescription.Mail.MAILBOXES_VIEW_EDIT;
            } else if (!appInfo.exists(UIAQuery.Mail.BACK_BUTTON.isVisible())) {
                return UIStateDescription.Mail.MAILBOXES_VIEW;
            }
            break;
        case 'Drafts':
            return UIStateDescription.Mail.DRAFTS_FOLDER;
        case 'Sent':
            return UIStateDescription.Mail.SENT_FOLDER;
        case 'VIP List':
            return UIStateDescription.Mail.VIP_FOLDER;
        case 'Flagged':
            return UIStateDescription.Mail.FLAGGED_FOLDER;
        default:
            // continue
    }


    if (appInfo.exists(UIAQuery.Mail.SEARCH_BAR.isVisible())
        && appInfo.exists(UIAQuery.tableViews('Search results').isVisible())) {
        return UIStateDescription.Mail.SEARCH_VIEW;
    }

    if (appInfo.exists(UIAQuery.Mail.THREAD_NAVBAR)
        || appInfo.exists(UIAQuery.Mail.MULTIPLE_MESSAGES_NAVBAR)) {
        return UIStateDescription.Mail.MAIL_THREAD;
    }

    // this will match on 'Drafts', 'Sent', 'VIP', 'Flagged' as well
    // which is why we do them first
    if (appInfo.exists(UIAQuery.Mail.MAIL_TABLEVIEW.isVisible())) {
        if (appInfo.exists(UIAQuery.Mail.TRASH_ALL_BUTTON)) {
            return UIStateDescription.Mail.MAIL_FOLDER_EDIT;
        }

        return UIStateDescription.Mail.MAIL_FOLDER;
    }

    if (appInfo.exists(UIAQuery.Mail.EMAIL_CONTENT_VIEW)
        && !appInfo.exists(UIAQuery.Mail.SEE_MORE_BUTTON)
        && appInfo.exists(UIAQuery.DONE_BUTTON)) {
        return UIStateDescription.Mail.SEE_MORE_VIEW;
    }

    if (appInfo.exists(UIAQuery.Mail.EMAIL_CONTENT_VIEW)
        && !appInfo.exists(UIAQuery.popovers())) { // ipad view
        return UIStateDescription.Mail.EMAIL_CONTENT;
    }

    if (appInfo.exists(UIAQuery.Mail.MAILBOXES_BUTTON.isVisible())
        && appInfo.exists(UIAQuery.tableViews().andThen(UIAQuery.tableCells('Inbox')))) {
            return UIStateDescription.Mail.ACCOUNT_FOLDER;
    }

    if (appInfo.exists(UIAQuery.MAIL_COMPOSE_VIEW.isVisible())
        && !appInfo.exists(UIAQuery.VISIBLE_POPOVERS)) {
        return UIStateDescription.MAIL_COMPOSITION;
    }

    if (appInfo.exists(UIAQuery.Mail.SMALL_IMAGE_SIZE)) {
        return UIStateDescription.Mail.IMAGE_SIZE_PROMPT;
    }

    if (appInfo.exists(UIAQuery.Mail.SAVE_DRAFT_BUTTON)) {
        return UIStateDescription.Mail.SAVE_DRAFT_PROMPT;
    }

    // last case catch for any prompt view like share menu, draft dialog, etc
    if (appInfo.exists(UIAQuery.Mail.CANCEL_BUTTON)) {
        return UIStateDescription.Mail.PROMPT;
    }

    throw new UIAError('Could not determine Mail state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigation function to get to a mail folder. If no folder and or account
* is specified we default to the inbox or all inboxes in the case of multiple
* accounts.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired state.
*/
mail.getToEmailFolder = function getToEmailFolder(options) {
    options = UIAUtilities.defaults(options, {
        folder: 'Inbox',
        account: null,
    });

    this.getToMailboxesPage();

    UIALogger.logMessage('Attempting to get to folder %0 of account %1'.format(options.folder, options.account));
    if (options.account) {
        if (this.waitUntilPresent(UIAQuery.tableViews().andThen('ACCOUNTS'), 0.5)) {
            UIALogger.logMessage('Looking for account %0'.format(options.account));
            // Note: as of 2015-08-24 this fails for off-screen elements, see rdar://problem/22311834
            this.tap(UIAQuery.tableViews().andThen(UIAQuery.beginsWith(options.account)).andThen(UIAQuery.tableCells().bottommost()));
        } else {
            UIALogger.logMessage('No account listing to choose from: only one email account on device.');
        }
    }

    UIALogger.logMessage('Tapping folder with name containing %0'.format(options.folder));
    this.waitForViewToAppear("controllerClass == 'MailboxContentViewController'", function() {
        this.tap(UIAQuery.tableViews().andThen(UIAQuery.contains(options.folder)))
    });

    var folderNamePred = 'any identifiers contains[c] "%0" or any identifiers contains[c] "Inbox"'.format(options.folder);
    if (!this.exists(UIAQuery.navigationBars().withPredicate(folderNamePred))) {
        throw new UIAError('Unable to get to email folder: %0 of account: %1'.format(options.folder, options.account));
    }
}

/**
* Navigation function to get to top level of the mail app i.e. the 'Mailboxes'
* view.
* Any critia for defining a transition from a state to another state
* should be very exact. Navigation function should always get to where
* they are meant to go or throw.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired state.
*/
mail.getToMailboxesPage = function getToMailboxesPage() {
    this.launch();

    var currentState = this.currentUIState();
    if (!this.isAccountLoggedIn({currentState:currentState})) {
        throw new UIAError('No mail account logged in.');
    }

    // will loop for max 5 times.
    // This should be max supported depth from top level + 1
    UIALogger.logMessage('Attempting to get to Mailboxes view...');
    for (var i = 0; i < 5; i++, currentState = this.currentUIState()) {
        UIALogger.logMessage("Current state: '%0'".format(currentState));

        if (currentState === UIStateDescription.Mail.MAILBOXES_VIEW) {
            return;
        }

        switch (currentState) {
            case UIStateDescription.Mail.MAILBOXES_VIEW_EDIT:
            case UIStateDescription.Mail.MAIL_FOLDER_EDIT:
            case UIStateDescription.Mail.SEE_MORE_VIEW:
                this.tap(UIAQuery.DONE_BUTTON.orElse(UIAQuery.CANCEL_BUTTON));
                break;
            case UIStateDescription.Mail.EMAIL_CONTENT:
                this.goBack();
                break;
            case UIStateDescription.Mail.MAIL_THREAD:
                this.goBack();
                break;
            case UIStateDescription.Mail.MAIL_FOLDER:
            case UIStateDescription.Mail.DRAFTS_FOLDER:
            case UIStateDescription.Mail.SENT_FOLDER:
            case UIStateDescription.Mail.VIP_FOLDER:
            case UIStateDescription.Mail.FLAGGED_FOLDER:
            case UIStateDescription.Mail.ACCOUNT_FOLDER:
                this.goBack();
                break;
            case UIStateDescription.MAIL_COMPOSITION:
                this.goBack();
                break;
            case UIStateDescription.Mail.SEARCH_VIEW:
                this.tap(UIAQuery.Mail.CANCEL_BUTTON);
                break;
            case UIStateDescription.Mail.IMAGE_SIZE_PROMPT:
                this.tap(UIAQuery.Mail.SMALL_IMAGE_SIZE);
                break;
            case UIStateDescription.Mail.SAVE_DRAFT_PROMPT:
                this.tap(UIAQuery.Mail.SAVE_DRAFT_BUTTON);
                break;
            case UIStateDescription.Mail.PROMPT:
                this.tap(UIAQuery.Mail.CANCEL_BUTTON);
        }
    }

    if (currentState !== UIStateDescription.Mail.MAILBOXES_VIEW) {
        throw new UIAError(
            "Did not get to expected state. Current state: '%0', Expected state: '%1'"
            .format(currentState, UIStateDescription.Mail.MAILBOXES_VIEW)
        );
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Compose and send an email to the specified recipient
 *
 * @param {object} options
 * @param {string} options.recipient - Email recipient address
 * @param {string} options.subject - Email subject
 * @param {string} options.text - Email body text
 * @param {string} options.sender - Email sender address
 */
mail.composeAndSendEmail = function composeAndSendEmail(options) {
    if (options.sender) {
        mail.getToEmailFolder({account:options.sender});
    } else {
        mail.getToEmailFolder();
    }

    // Get rid of Popover on iPad
    if (target.model() === 'iPad' && this.waitUntilPresent('PopoverDismissRegion', 0.5)) {
        this.tap('PopoverDismissRegion');
    }

    // Tap compose button
    UIALogger.logMessage('Tapping Compose');
    var composeButton = UIAQuery.Mail.COMPOSE_BUTTON.isVisible();
    if (!this.waitUntilPresent(composeButton)) {
        throw new UIAError('Compose button is not tappable');
    }
    this.tap(composeButton);

    if (!this.waitUntilPresent(UIAQuery.Mail.NEW_MESSAGE_NAVBAR)) {
        throw new UIAError('Composition view never appeared');
    }

    this.typeAndSendMessage(options);
}

/** Respond to a specified email
 *
 * @param {object} options
 * @param {string} options.search - String to search for
 * @param {string} options.account - Address or account description
 * @param {string} options.folder - Folder in which to search
 * @param {bool}   options.shouldOpenEmail - Whether email should be opened
 * @param {int}    options.timeout - Number of seconds to wait for search match to appear
 * @param {string} options.text - Email body text
 * @param {string} [args.action="reply"] - Response type: reply or forward
 * @param {string} options.recipient - Email recipient address for forward responses
 */
mail.respondToEmail = function respondToEmail(options) {
    options.shouldOpenEmail = true;
    if (!this.searchForMail(options)) {
        throw new UIAError('Could not find email searching for "%0"'.format(options.search), {identifier:'Could not find email matching search'});
    }

    // Check if we are in a message thread rather than an individual message
    // these next two lines exist for backwards compatibility
    if (this.exists(UIAQuery.Mail.THREAD_NAVBAR)) {
        this.tap(UIAQuery.tableCells().contains(options.search));
    }

    UIALogger.logMessage('Tapping Reply');
    var replyButton = UIAQuery.Mail.REPLY_BUTTON.isVisible();
    if (!this.waitUntilPresent(replyButton)) {
        throw new UIAError('Reply button did not become visible');
    }

    // Tapping on 'See More' to work around the reply button issue: 27259727
    // We don't need to do this if 'See More' isn't there
    this.waitUntilAbsent(UIAQuery.activityIndicators(), 1);
    this.waitUntilPresent(UIAQuery.Mail.SEE_MORE_BUTTON, 1);

    this.tapIfExists(UIAQuery.Mail.SEE_MORE_BUTTON);
    this.tap(UIAQuery.Mail.REPLY_BUTTON);

    var navBarQuery;
    if (options.action === 'reply') {
        this.tap(UIAQuery.actionSheets().andThen(UIAQuery.Mail.REPLY_BUTTON));
        navBarQuery = UIAQuery.Mail.REPLY_MESSAGE_NAVBAR;
    } else if (options.action === 'reply all') {
        this.tap(UIAQuery.Mail.REPLY_ALL_BUTTON);
        navBarQuery = UIAQuery.Mail.REPLY_MESSAGE_NAVBAR;
    } else if (options.action === 'forward') {
        this.tap(UIAQuery.Mail.FORWARD_BUTTON);
        navBarQuery = UIAQuery.Mail.FORWARD_MESSAGE_NAVBAR;
    } else {
        throw new UIAError('action argument must be "reply" "reply all" or "forward"');
    }

    if (!this.waitUntilPresent(navBarQuery)) {
        throw new UIAError('Reply composition view never appeared');
    }

    this.typeAndSendMessage(options);
}

/** fills out a message and sends it, checking for possible points of failure along the way
 *
 * @param {object} options
 * @param {string} options.recipient - Email recipient address
 * @param {string} options.text - Email body text
 * @param {string} options.subject - Email subject
 * @param {string} [args.action="reply"] - Response type: reply or forward
 */
mail.typeAndSendMessage = function typeAndSendMessage(options) {
    options = UIAUtilities.defaults(options, {
        recipient: null,
        subject: null,
        text: null,
        attachOptions: {
            attachPhoto: false,
            collectionName: 'Camera Roll',
        },
    });

    if (options.recipient) {
        // Enter address in To field (keyboard should come up with focus on this field)
        UIALogger.logMessage('Entering recipient');
        this.typeString(options.recipient);
        this.tap(UIAQuery.keyboard().andThen(UIAQuery.buttons('Return')));
        // Tap return again if there are recipient suggestions
        if (this.waitUntilPresent(UIAQuery.tableViews('MessageRecipientSearchTable'), 5)) {
            this.tap(UIAQuery.keyboard().andThen(UIAQuery.buttons('Return')));
        }
    }

    if (options.subject) {
        // Enter subject in Subject field
        UIALogger.logMessage('Entering subject');
        this.tap('subjectField');
        this.typeString(options.subject);
    }

    if (options.text) {
        // Enter text in 'Message body' field
        UIALogger.logMessage('Entering message body');
        // This workaround has to be removed once rdar://problem/38888637 is fixed
        messageBodyQuery = UIAQuery.textViews('Message body')
        if(mail.inspect(messageBodyQuery) == null){
            UIALogger.logMessage('Message body label not present. Using workaround query');
            mail.tap(UIAQuery.staticTexts().contains("Sent from my").parent(),{'offset':{'x':0,'y':0}})
        }
        else{
            this.tap('Message body');
        }
        // The workaround for rdar://problem/38888637 ends here
        this.typeString(options.text);
    }

    if (options.attachOptions && options.attachOptions.attachPhoto) {
        this.attachPhoto(options.attachOptions);
    }

    // Check that Send button is enabled
    var send = UIAQuery.buttons('Send').isEnabled();
    if (!this.waitUntilPresent(send, 2)) {
        this.getToMailboxesPage();
        throw new UIAError('Send button never became enabled');
    }

    // Set up waiter to make sure the message gets sent
    var viewDisappearWaiter = UIAWaiter.withPredicate('ViewDidDisappear', "controllerClass == 'ComposeNavigationController'");

    // Hit send
    UIALogger.logMessage('Tapping Send');
    this.tap(send);

    // Handle image size prompt if it appears
    if (this.exists(UIAQuery.Mail.SMALL_IMAGE_SIZE)) {
        this.tap(UIAQuery.Mail.SMALL_IMAGE_SIZE);
    }

    var viewDisappeared = viewDisappearWaiter.wait(5);
    if (!viewDisappeared) {
        this.getToMailboxesPage();
        throw new UIAError('Composition view never disappeared after sending message');
    }

    if (this.waitUntilPresent(UIAQuery.alerts('Cannot Send Mail'))) {
        throw new UIAError('Cannot Send Mail');
    }
}

/**
 * Verify email exists in folder
 *
 * @param {object} options
 * @param {string} options.subject - Email subject to match
 * @param {string} options.account - Address or account description
 * @param {string} options.folder - Folder in which to look for email
 * @param {int}    options.timeout - Number of seconds to wait for search match to appear
 * @returns {bool} Whether email exists in folder
 */
mail.verifyEmailExists = function verifyEmailExists(options) {
    UIALogger.logMessage('Looking for email with subject "%(subject)" in %(folder) folder of account %(account)'.format(options));
    this.getToEmailFolder(options);

    var subject = UIAQuery.tableViews().andThen(UIAQuery.withPredicate("name contains[c] ('%0')".format(options.subject)));

    var started = new Date().getTime();
    var found = false;
    do {
        // Drag down to refresh
        if (this.exists(UIAQuery.tableCells())) {
            this.drag(UIAQuery.tableCells().isVisible().first(), {fromOffset: {x: 0.50, y: 0.15}, toOffset: {x: 0.50, y: 4.00}, duration: 1.00});
        } else {
            // Refresh if "No Mail"
            this.drag(UIAQuery.Mail.MAIL_TABLEVIEW, {fromOffset: {x: 0.50, y: 0.20}, toOffset: {x: 0.50, y: 1.00}, duration: 1.00});
        }

        // Wait for subject to appear in table
        if (this.waitUntilPresent(subject, 5)) {
            found = true;
            break;
        }
        var elapsed = (new Date().getTime() - started) / 1000;
        UIALogger.logMessage('elapsed: %0, timeout: %1'.format(elapsed, options.timeout));
    } while (elapsed < options.timeout);
    UIALogger.logMessage('elapsed: %0, timeout: %1'.format(elapsed, options.timeout));

    return found;
}

/**
 * Search for mail matching search string
 *
 * @param {object} options
 * @param {string} options.search - String to search for
 * @param {string} options.account - Address or account description
 * @param {string} options.folder - Folder in which to search
 * @param {bool}   options.expectResult - whether email is expected to be found
 * @param {bool}   options.shouldOpenEmail - Whether email should be opened
 * @param {int}    options.timeout - Number of seconds to wait for search match to appear
 */
mail.searchForMail = function searchForMail(options) {
    if (options.expectResult === undefined) options.expectResult = true;

    UIALogger.logMessage('Searching for email using string "%(search)" in %(folder) folder of account %(account)'.format(options));
    this.getToEmailFolder(options);

    // Enter query in search bar
    UIALogger.logMessage('Tapping search bar');
    var iteration = 0;
    if (!this.exists(UIAQuery.Mail.SEARCH_BAR)) {
        // Tap on the status bar, in the left quarter of the screen (for widescreen layouts), to scroll to the top of the inbox
        this.tap(UIAQuery.application(), {offset: {x: .25, y: .01}})
    }

    this.tap(UIAQuery.Mail.SEARCH_BAR);
    this.typeString(options.search);

    // Tap Search
    UIALogger.logMessage('Tapping Search key');
    var searchKey = UIAQuery.keyboard().andThen('Search');
    this.tap(searchKey);

    // Wait for result
    UIALogger.logMessage('Waiting up to %0 seconds for match to appear'.format(options.timeout));
    var result = UIAQuery.tableViews().andThen(UIAQuery.contains(options.search));
    if (this.waitUntilPresent(result, options.timeout)) {
        UIALogger.logMessage('Successfully found email matching %0'.format(options.search))
        if (options.shouldOpenEmail) {
            UIALogger.logMessage('Tapping search result');
            this.tap(result);
        }
        return true;
    } else {
        if (options.expectResult) {
            UIALogger.logError('No results for %0'.format(options.search));
        } else {
            UIALogger.logMessage('No results for %0 (this is expected)'.format(options.search));
        } return false;
    }
}

/**
 * Prints the email that the mail app is currently on.
 *
 *  @param {object} options
 *  @param {string} options.printerName - the name of the printer. If no value is specified, a random printer is selected
 *  @param {number} options.numberOfCopies - the number of print copies. If no value is specified, the default value is not changed.
 *  @param {boolean} options.doubleSided - true if the double sided swith is set to print the document double sided.
 *  @param {boolean} options.blackWhite - true if the document is to be printed in black and white.
 **/
mail.printEmail = function printEmail(options) {
    options = UIAUtilities.defaults(options, {
        printerName: null,
        numberOfCopies: null,
        doubleSided: null,
        blackWhite: null,
    });

    this.tap("Reply");
    this.tap("Print");
    this.tap("Printer");

    this.waitUntilAbsent(UIAQuery.tableViews("Looking for Printers..."), 60);
    if (UIAQuery.staticTexts("No AirPrint Printers Found").isVisible() == "YES") {
        throw new UIAError("No Printers were found.");
    }

    var printers = UIAQuery.tableCells();

    if (options.printerName) {
        if (this.tapIfExists(options.printerName)) {
            UIALogger.logMessage("The specified printer was selected.");
            this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        } else if (this.tapIfExists(printers)) {
            UIALogger.logMessage("A printer was selected.");
            this.tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        } else {
            throw new UIAError("Could not select a printer.");
        }
    }
    //waits until a printer is actually selected and back on printer options page.
    if (!this.waitUntilAbsent(UIAQuery.BACK_NAV_BUTTON, 60)) {
        throw new UIAError("Could not select a printer.");
    }
    if (options.numberOfCopies != null && options.numberOfCopies > 1) {
        var i = options.numberOfCopies;
        while (i-- > 1) {
            this.tap("Increment");
        }
    }
    this.tap("Options");
    if (options.doubleSided != null) {
        this.setControl(UIAQuery.switches("Double-sided"), options.doubleSided);
    }
    if (options.blackWhite != null) {
        this.setControl(UIAQuery.switches("Black & White"), options.blackWhite);
    }
    if (UIAQuery.buttons('Print').isEnabled()) {
        this.tap("Print");
    } else {
        throw new UIAError("Unable to tap print.");
    }
}

/**
 * Respond to event invite matching search string
 *
 * @param {object} options
 * @param {string} options.search - String to search for
 * @param {string} options.account - Address or account description
 * @param {string} options.folder - Folder in which to search
 * @param {string} options.response - Respond to invite with "Accept", "Maybe", or "Decline"
 * @param {int}    options.timeout - Number of seconds to wait for search match to appear
 */
mail.respondToInvite = function respondToInvite(options) {
    UIALogger.logMessage('Searching for invite using string "%(search)" in %(folder) folder of account %(account)'.format(options));

    // Search for email and tap to load it
    options.shouldOpenEmail = true;
    options.expectResult = true;
    if (! this.searchForMail(options)) {
        throw new UIAError('Could not find email with search term %0'.format(options.search), {identifier: 'Could not find email'});
    }

    // Drag the invite button up to full view and tao it
    var inviteButton = UIAQuery.query("WebAccessibilityObjectWrapper").andThen(UIAQuery.buttons());
    this.dragUpInside(inviteButton.ancestors().withPredicate("behavior == 'ScrollView'"))
    this.tap(inviteButton);

    // Tap the desired response to the event invite
    if ( this.exists(UIAQuery.navigationBars("Event Details")) ) {
        this.tap(UIAQuery.buttons(options.response));
    } else {
        throw new UIAError('Unable to select invite details');
    }

    // Search for the event again and make sure it is gone from the Inbox; otherwise throw
    // After replying to event, the mail is still searchable (i.e. "Accepted: TestEvent"), so we cannot use mail.searchForMail()
    // Instead we check the inbox to make sure the email is gone.
    this.getToEmailFolder(options);
    if (this.exists( UIAQuery.tableViews('MailMessagesTableView').andThen(UIAQuery.contains(options.search)) )) {
        throw new UIAError('Mail was still found in mailbox after responding to invite!!');
    }
}

/**
 * Goes to a folder and views random emails
 *
 * @param {object} options
 * @param {string} options.emailCount - Number of emails to view
 * @param {string} options.folder - Folder in which to view emails
 *
 * @returns None
 *
 * @throws If not emails in folder or unable to view a email.
 */
mail.viewEmails = function viewEmails(options) {
    options = UIAUtilities.defaults(options, {
        emailCount: 5,
        folder: 'Inbox',
    });

    mail.getToEmailFolder(options);

    var count = this.count(UIAQuery.Mail.MAIL_TABLEVIEW.andThen(UIAQuery.tableCells()));
    UIALogger.logMessage('Counting %0 messages in current folder'.format(count));
    UIAUtilities.assert(
        count !== 0,
        'Unable to open email. No emails in folder.'
    );
    for (var i = 0; i < options.emailCount; i++) {
        var index = UIAUtilities.randomInt(0, count-1);
        UIALogger.logMessage('Attempting to view the %0th/st/rd message.'.format(index+1));

        // Waiter that waits until the email page is completely loaded before
        // trying to hit the back button agian. This is an iPad event
        var EmailViewWaiteriPad = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            "bundleID = 'com.apple.WebKit.WebContent' AND state = 'Suspended'"
        );

        // Waiter that waits until the email page is completely loaded before
        // trying to hit the back button agian. This is an iPhone event
        var EmailViewWAiteriPhone = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            "bundleID = 'com.apple.WebKit.WebContent' AND state = 'Foreground'"
        );

        this.openEmailAtIndex({emailIndex:index});
        if (this.exists(UIAQuery.navigationBars('Thread').isVisible())) {
            // open first email in thread
            this.tap(UIAQuery.tableCells().first());
        }

        // Throws an error after 8 seconds if either of the events
        // don't occur.
        if (!EmailViewWaiteriPad.wait(4) && !EmailViewWAiteriPhone.wait(4)) {
            throw new UIAError('Something went wrong. Event did not appear.');
        }

        UIAUtilities.assert(
            this.currentUIState() === UIStateDescription.Mail.EMAIL_CONTENT,
            'Unable to open mail message.'
        );

        this.goBack();
        if (this.exists(UIAQuery.navigationBars('Thread').isVisible())) {
            this.goBack();
        }
    }
}

/**
 * Downloads an attachment from an email. The email choosen is based
 * on passed search stirng. If no search infomation is given, we open
 * the first email.
 *
 * @param {object} options
 * @param {string} options.type - Attachment type
 * @param {string} options.search - String to search for
 * @param {string} options.account - Address or account description
 * @param {string} options.folder - Folder in which to email resides
 * @param {bool}   options.shouldOpenEmail - Whether email should be opened
 * @param {int}    options.timeout - Number of seconds to wait for search match to appear. Default 1 minute
 *
 * @returns None
 *
 * @throws If unable to determine type of attachemnt to download
 */
mail.downloadAttachment = function downloadAttachment(options) {
    options = UIAUtilities.defaults(options, {
        type: 'image',
        search: null,
        account: null,
        folder: 'Inbox',
        shouldOpenEmail: true,
        timeout: 60,
    });

    this.openAnEmail(options);
    if (this.exists(UIAQuery.navigationBars('Thread').isVisible())) {
        // open first email in thread
        this.tap(UIAQuery.tableCells().first());
    }

    UIAUtilities.assert(
        this.currentUIState !== UIStateDescription.Mail.EMAIL_CONTENT,
        'Unable to open email to view attachment'
    );

    switch (options.type) {
        case 'image':
            this.downloadImage(options);
            break;
        default:
            throw new UIAError('Attachment type not definded. Please update library with new attachemnt type.');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Selects an email and opens it. If no index is specified the first email will be chosen.
 *
 * @param {object} options
 * @param {int} options.emailIndex - the index of the email to be selected in the mailbox list.
 */
mail.openEmailAtIndex = function openEmailAtIndex(options) {
    if (options.emailIndex) {
        this.tap(UIAQuery.tableCells().atIndex(options.emailIndex));
    } else {
        this.tap(UIAQuery.tableCells().atIndex(0));
    }
}

/**
 * If a search string is specified it will be found, selected and opened. If no string is specified the first email
 * in the specified email folder will opened.
 *
 *  @param {object} options
 *  @param {string} [options.search=null] - the string to be searched for.  If no string is specified a random email will be printed.
 *  @param {string} [options.account=null] - the address or description of the account to be searched
 *  @param {string} [options.folder='Inbox'] - folder to search
 *  @param {boolean} [options.shouldOpenEmail=true] - the email will be selected.
 *  @param {int} [options.timeout=60] - the time alotted for a search.
 *  @param {int} [options.emailIndex=0] - the index of the email to be selected if no search criteria are specified.
 **/
mail.openAnEmail = function openAnEmail(options) {
    options = UIAUtilities.defaults(options, {
        search: null,
        account: null,
        folder: 'Inbox',
        shouldOpenEmail: true,
        timeout: 60,
        emailIndex: 0,
    });

    if (!options.search) {
        this.getToEmailFolder(options);
        this.openEmailAtIndex(options);
    } else {
        if (mail.searchForMail(options)) {
            UIALogger.logMessage('Found email searching for "%0"'.format(options.search));
        } else {
            throw new UIAError('Could not find email searching for "%0"'.format(options.search), {identifier:'Could not find email matching search'});
        }
    }
}

/**
 * Determines if an email account is already signed in. This is done
 * by checking the current state of Mail.
 *
 * @param {object} options
 * @param {string} options.currentState - current UI state
 *
 * @returns {bool} True if an account is logged in. False otherwise
 **/
mail.isAccountLoggedIn = function isAccountLoggedIn(options) {
    options = UIAUtilities.defaults(options, {
        currentState: this.currentUIState(),
    });

    if (options.currentState === UIStateDescription.Mail.WELCOME_TO_MAIL) {
        return false;
    }

    return true;
}

/**
 * Attaches a photo to the current email. If there is more then one photo in
 * collection, attaches first one.
 *
 * Expected starting states: UIStateDescription.Mail.EMAIL_CONTENT
 *
 * @param {object} options
 * @param {string} options.collectionName - Name of collection to grab photo from
 *
 * @returns None
 *
 * @thorw If unable to attach photo
 **/
mail.attachPhoto = function attachPhoto(options) {
    options = UIAUtilities.defaults(options, {
        collectionName: 'Camera Roll',
    });

    UIALogger.logMessage('Attaching photo');
    // This workaround has to be removed once rdar://problem/38888637 is fixed
    messageBodyQuery = UIAQuery.textViews('Message body')
        if(mail.inspect(messageBodyQuery) == null){
            UIALogger.logMessage('Message body label not present. Using workaround query');
            mail.tap(UIAQuery.staticTexts().contains("Sent from my").parent(),{'offset':{'x':0,'y':0},'tapCount':2})
        }
        else{
            this.doubleTap('Message body');
        }
    // The workaround for rdar://problem/38888637 ends here

    if (!this.exists(UIAQuery.query('Insert Photo or Video').isVisible())) {
        this.tap(UIAQuery.query('Show more items'));
    }
    this.tap(UIAQuery.query('Insert Photo or Video'));

    // choose collection
    this.tap(options.collectionName);
    UIAUtilities.assert(
        !this.exists(UIAQuery.staticTexts('No Photos or Videos')),
        'No photos in collection: %0. Unable to attach photo.'.format(options.collectionName)
    );

    // choose first photo
    this.waitForViewToAppear('controllerClass == "PLPhotoTileViewController"', 5, function () {
        this.tap(UIAQuery.collectionViews('PhotosGridView').andThen(UIAQuery.CELLS));
    });
    this.tap(UIAQuery.buttons('Choose').orElse(UIAQuery.buttons('Use')));

    // no acceesibilty elements to determine if an photo was attached
    // lets just check we are back at the email compose view
    UIAUtilities.assert(
        this.currentUIState !== UIStateDescription.MAIL_COMPOSITION,
        'Unable to attach photo'
    );
}

/**
 * Downloads an image attachment from an open mail message
 *
 * Expected starting states: UIStateDescription.Mail.EMAIL_CONTENT
 *
 * @returns None
 *
 * @throws If unable to download image
 */
mail.downloadImage = function downloadImage() {
    var downloadingQuery = UIAQuery.query('WebAccessibilityObjectWrapper').andThen(UIAQuery.contains('Downloading'));

    // attachment could have already downloaded by now
    if (this.exists(UIAQuery.Mail.MESSAGE_IMAGE_ATTACHMENT)) {
        UIALogger.logMessage('Image attachment appears to have downloaded.');
        return;
    }

    // if attachment didn't auto download, lets try to do it explicitly
    this.tapIfExists(UIAQuery.withPredicate('value contains[c] "Tap to Download"'));

    this.waitUntilPresent(downloadingQuery, 5);

    if (this.exists(downloadingQuery)
        && !this.waitUntilAbsent(downloadingQuery, 60)) {
            throw new UIAError('Image attachment did not download within the allotted time.');
    }

    // attachment should definitely be there now
    if (!this.exists(UIAQuery.Mail.MESSAGE_IMAGE_ATTACHMENT)) {
        throw new UIAError('Unable to download image attachment.');
    }
    UIALogger.logMessage('Image attachment appears to have downloaded.');
}

/**
 * Attempt to go back a page first by tapping the back button then by swiping
 *
 * Expected starting states: Any
 *
 * @returns None
 */
mail.goBack = function goBack() {
    UIALogger.logMessage('Attempting to go back a page');
    if (this.exists(UIAQuery.Mail.SWITCH_TO_FULL_SCREEN_BUTTON.isVisible())) { // Helpful for Google account on N69 sized device
        UIALogger.logMessage("The 'Switch to full screen mode' button exists so we're tapping that");
        this.tap(UIAQuery.Mail.SWITCH_TO_FULL_SCREEN_BUTTON);
    } else if (this.exists(UIAQuery.Mail.BACK_BUTTON.isVisible())) {
        UIALogger.logMessage("The back button exists so we're tapping the back button");
        this.tap(UIAQuery.Mail.BACK_BUTTON);
    } else {
        UIALogger.logMessage("The back button didn't exist so we're attempting to go back by swiping");
        mail.drag(UIAQuery.application(), {fromOffset: {x: 0.00, y: 0.50}, toOffset: {x: 1.00, y: 0.5}, duration: 0.25});
    }
}
