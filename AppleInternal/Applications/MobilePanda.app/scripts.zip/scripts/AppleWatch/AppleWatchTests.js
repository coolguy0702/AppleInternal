load('UIATesting.js');
load('AppleWatch.js');

UIAUtilities.assert(
    typeof AppleWatchTests === 'undefined',
    'AppleWatchTests has already been defined.'
);

/** @namespace */

var AppleWatchTests = {
    /**
      * Pair with Watch
      * 
      *  @targetApps Apple Watch
      *
      *  @param {object}  args - Test arguments
      *  @param {boolean} [args.useUnhappyPath=false] - Flag to indicate whether to use default pairing mode or the unhappy version
      *  @param {string}  [args.gizString=null] - Gizmo device string used in UHP and Engineering UI pairing
      *  @param {string}  [args.btString=null] - BlueTooth device string used in Engineering UI pairing
      *  @param {string}  [args.appleAccountID=null] - Account name to confirm in post-pairing setup flow when signing in
      *  @param {string}  [args.appleAccountPassword=null] - Account password to sign in in post-pairing setup flow
      *  @param {boolean} [args.installWatchKitApps=false] - Flag to indicate whether to install all watchkit apps or skip to later.
      *  @param {boolean} [args.isFirstWatch=true] - Flag to indicate whether this is the first watch to pair with, or if it's a QuickSwitch
      *                                              NOTE: isFirstWatch is only applicable starting in Coral/Eagle
      *  @param {boolean} [args.forcedOTAPhase1=false] - Flag to initiate UHP pairing process for rev-lock changes (SkiHill/Bucket) Watches with Eagle+
      *  @param {boolean} [args.forcedOTAPhase2=false] - Flag to complete the post pairing setup after OTA update for rev-lock (SkiHill/Bucket Watches) with Eagle+
    */
    pair: function pair(args) {
        args = UIAUtilities.defaults(args, {
            useUnhappyPath: false,
            btString: null,
            gizString: null,
            installWatchKitApps: false,
            gizmoPasscode: null,
            appleAccountID: null,
            appleAccountPassword: null,
            isFirstWatch: true,
            forcedOTAPhase1: false,
            forcedOTAPhase2: false,
        });

        appleWatch.pairViaSetup(args);
    },

    /**
      * Unpair from Watch
      * 
      *  @targetApps Apple Watch
      *
      *  @param {object}  args - Test arguments
      *  @param {string}  [args.appleAccountPassword=null] - Account password to disable activation lock when unpairing
      *  @param {string}  [args.watchName=null] - Name of watch to unpair with. This is mainly used in scenario where we have multiple paired watches.
     */
    unpair: function unpair(args) {
        args = UIAUtilities.defaults(args, {
            appleAccountPassword: null,
            watchName: null,
        });

        appleWatch.unpair(args);
    },

    /**
     * Adds the given contact name as a friend on watch
     *
     *  @targetApps Apple Watch
     *
     * @param {object} args - test arguments
     * @param {string} [args.friendName='Janie iCloud'] - the name of the friend to add from contacts
     */
    addFriend: function addFriend(args) {
        args = UIAUtilities.defaults(args, {
            friendName: 'Janie iCloud',
        });

        appleWatch.addFriend(args.friendName);
    },

    /**
     * Removes the given contact name as a friend on watch
     *
     *  @targetApps Apple Watch
     *
     * @param {object} args - test arguments
     * @param {string} [args.friendName='Janie iCloud'] - the name of the friend to remove from friends list
     */
    removeFriend: function removeFriend(args) {
        args = UIAUtilities.defaults(args, {
            friendName: 'Janie iCloud',
        });

        appleWatch.removeFriend(args.friendName);
    },
    
        
   /**
     *  Check to see if there is an OTA update available.   If so it triggers download and install.
     *  @param {string} [args.passcodeOnCompanion=null] - Passcode on the phone required to accept T & C before watch OTA Update.
     *  @param {bool}   [args.scanOnlyForBadgeVerification=false] - Scan for update to verify badges on Watch Icon, General and Software Update screens.
     *  @param {number} [args.badgeNumber=null] - the number to be shown on the icon
     *  @param {number} [args.buildNumberToOTA=null] - the build number for the watch to update
     *  @targetApps Apple Watch
     *  @overrideID OTAUpdate
     */
    OTAUpdate: function OTAUpdate(args) {
        args = UIAUtilities.defaults(args, {
            passcodeOnCompanion: null,
            scanOnlyForBadgeVerification: false,
            badgeNumber: null,
            buildNumberToOTA: null,
        });
        
        appleWatch.OTAUpdate(args);
    },

    /**
     *  Verify the build number after the OTA Update is successful.
     *  @targetApps Apple Watch
     *  @param {object} args - test arguments
     *  @param {string} [args.buildNumber=null] - Build number to be verified post OTA Update.
     *  @overrideID Build Post OTAUpdate
     */
    buildPostOTAUpdate: function buildPostOTAUpdate(args) {    
        args = UIAUtilities.defaults(args, {
            buildNumber: null,
        });    

        appleWatch.buildPostOTAUpdate(args);
    },

    /**
     *  Sync photos and music to the gizmo.
     *  @targetApps Apple Watch
     */
    syncMedia: function syncMedia() {

      appleWatch.syncMedia();
    },

    /** 
     *  Verify if OTA profile installed on the watch.
     *  @param {string} [args.profileName=null] - Name of the profile to be verified.
     *  @overrideID Verify OTA Profile
     *  @targetApps Apple Watch
     */
    verifyOTAProfile: function verifyOTAProfile(args) {
      
        appleWatch.verifyOTAProfile(args);
    },

    /**
     * Launch Watch app, start pairing, verify Camera is running 
     * 
     * @targetApps Apple Watch
     */
    startPairing: function startPairing() {
        appleWatch.startPairing();
    },
}