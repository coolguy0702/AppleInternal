load('UIAApp.js');

// SpringBoard allows us to use persisted account info
load('SpringBoard.js');

UIAUtilities.assert(
    typeof appleWatch === 'undefined',
    'AppleWatch has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common Apple Watch queries */
UIAQuery.AppleWatch = {

    /** Pair manually Button */
    PAIR_MANUALLY_BUTTON:           UIAQuery.buttons().withPredicate('name contains[c] "manually"'),

    /** OTA Update Apple Watch */
    UPDATE_APPLE_WATCH:             UIAQuery.buttons('Update Now'),

    /** Default Setup Watch Button */
    SETUP_WATCH_BUTTON:             UIAQuery.buttons().withPredicate('name contains[c] "set up"'),

    /** Setup as-new Watch Button */
    SETUP_AS_NEW_WATCH_BUTTON:      UIAQuery.buttons('SetupNewButton'),

    /** Restore from backup button */
    RESTORE_FROM_BACKUP:            UIAQuery.buttons('RestoreBackupButton'),

    /** Left Wrist Button */
    LEFT_WRIST_BUTTON:              UIAQuery.beginsWith('Left'),

    /** Right Wrist Button */
    RIGHT_WRIST_BUTTON:             UIAQuery.beginsWith('Right'),

    /** Left crown option when navigating pairing view with right wrist option */
    LEFT_CROWN_BUTTON:              UIAQuery.buttons('Left'),

    /** Right crown option when navigating pairing view with right wrist option */
    RIGHT_CROWN_BUTTON:             UIAQuery.buttons('Right'),

    /** 'Dont Send' button for post-scan options */
    DONT_SEND_BUTTON:               UIAQuery.buttons("Don't Send"),

    /** Enable Siri on Watch Button */
    USE_SIRI_BUTTON:                UIAQuery.buttons('Use Siri'),

    /** Disable Siri on Watch Button */
    DONT_USE_SIRI_BUTTON:           UIAQuery.buttons("Don't Use Siri").orElse('Don’t Use Siri'),

    /** Text Field for pasting gizmo string */
    GIZMO_NAME_TEXTFIELD:           UIAQuery.query('DeviceNameField'),

    /** Text Field for pasting Bluetooth pairing string */
    BLUETOOTH_ID_TEXTFIELD:         UIAQuery.query('BTDataField'),

    /** Button for skipping passcode creation */
    SKIP_PASSCODE_CREATION_BUTTON:  UIAQuery.buttons().andThen(UIAQuery.beginsWith("Don’t").orElse(UIAQuery.beginsWith("Don't"))),

    /** The button to enable activation lock when initially pairing a watch and a phone with iCloud signed in */
    ENABLE_ACTIVATION_LOCK_BUTTON:  UIAQuery.buttons().beginsWith('Enable'),

    /**
     * The button to disable activation lock when initially pairing a watch and a phone with iCloud signed in.
     * The unicode is a smart quote... <rdar://problem/23585940>
     */
    DISABLE_ACTIVATION_LOCK_BUTTON: UIAQuery.buttons().beginsWith("Don\u2019t Enable"),

    /** More info button for watch options */
    MORE_INFO_BUTTON:               UIAQuery.buttons().withPredicate("name contains[c] 'more info'"),

    /** Button for skipping creating passcode */
    CREATE_PASSCODE_BUTTON:         UIAQuery.buttons().andThen(UIAQuery.beginsWith('Create')),

    /** Button for skipping AppleID login */
    SKIP_LOGIN_BUTTON:              UIAQuery.withPredicate('name contains[c] "skip this step"'),

    /** Button for skipping Watchkit app installation */
    SKIP_WATCHKIT_BUTTON:           UIAQuery.buttons().withPredicate('name contains[c] "later"'),

    /**
    * SyncTrap completion
    * Added orElse because of <rdar://problem/26518215, rdar://problem/26527468 to remove original logic
    * */
    SYNC_COMPLETE_LABEL:            UIAQuery.contains('Sync complete').orElse(UIAQuery.contains('COSSetupFinishedFeatureView')),

    /** An indicator that we are on the Friends list view */
    FRIENDS_LIST_TITLE:             UIAQuery.navigationBars().andThen(UIAQuery.staticTexts('Friends')),

    /** The tab button at the bottom of the screen to get to "My Watch" though we may end up at a subview */
    MY_WATCH_TAB_BUTTON:            UIAQuery.tabBars().andThen(UIAQuery.buttons('My Watch')),

    /** The Add friend button that you can press to add a friend to the friends list */
    FRIENDS_ADD_PERSON_BUTTON:      UIAQuery.buttons('Add person'),

    /** The remove friend button that you can press to remove the selected person from the friends list */
    FRIENDS_REMOVE_PERSON_BUTTON:   UIAQuery.buttons('Remove Friend'),

    /** Watch Settings table */
    WATCH_PAIRING_OPTIONS_BUTTON:   UIAQuery.withPredicate('name beginswith "PairedWatch:"'),

    /** Unpair Apple Watch button in Apple Watch settings */
    UNPAIR_BUTTON:                  UIAQuery.tableViews().andThen(
                                        UIAQuery.tableCells().withPredicate('name contains[c] "Unpair"')),

    /** Unpair confirmation button */
    UNPAIR_CONFIRMATION_BUTTON:     UIAQuery.actionSheets().beginsWith('You will need to re-pair')
                                        .andThen(UIAQuery.buttons().beginsWith('Unpair')),

    SETUP_ACTIVITY_BUTTON:          UIAQuery.buttons('SuggestedChoiceButton'),

    DONE_BUTTON:                    UIAQuery.buttons('Done'),

    /** Static text on the 'Verifying Apple Watch software...' view */
    VERIFYING_APPLE_WATCH_SOFTWARE: UIAQuery.staticTexts('Verifying Apple Watch software…'),

    /** Button to continue past the wallet pane */
    WALLET_NEXT_BUTTON:             UIAQuery.buttons('Next').orElse(UIAQuery.buttons('Continue')),

    /** Start Pairing button */
    START_PAIRING_BUTTON:           UIAQuery.query('COSGetStartedView').andThen(UIAQuery.buttons('StartPairingButton')),

    /** Cancel button on Pairing screen */
    CANCEL_PAIRING_BUTTON:          UIAQuery.navigationBars('UINavigationBar').andThen(UIAQuery.buttons('Cancel')),

    /** Button to set up watch for myself on the Tinker view **/
    SET_UP_FOR_MYSELF_BUTTON:       UIAQuery.buttons('[Set up for myself]'),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to setup */
UIStateDescription.AppleWatch = {
    /** RUI */
    RUIPAGE:                         'RUIPage',

    /** T&C */
    TERMS_AND_CONDITIONS:            'Terms and Conditions',

    /* OLD Apple ID login view for watch registration. Keeping this around for pairing with legacy watches*/
    LEGACY_LOGIN_VIEW:               'COSAppleIDLoginView',

    /* iCloud login view */
    LOGIN_VIEW:                      'COSiCloudLoginView',

    /* iTunes Store Login View */
    ITUNES_LOGIN_VIEW:               'COSiTunesStoreLoginView',

    /* New UI introduced to Cinar and Emet  */
    SKIPPED_BENEFITS_VIEW:           'COSAppleIDSkippedBenefitsView',

    /* Activation-lock opt-in page that only shows when signing into iCloud */
    ACTIVATION_LOCK:                 'COSFMIPOptinView',

    /* Enable Siri page */
    SIRI_OPT_IN:                     'COSSiriOptinView',

    /* Set Up Activity page */
    SET_UP_ACTIVITY:                 'COSHealthChoiceView',

    /* Activity Health Stats page */
    ACTIVITY_HEALTH_STATS:           'COSHealthStatsTableView',

    /* Daily Move Goal Page */
    HEALTH_GOAL_TABLE:               'COSHealthGoalTableView',

    /* Send Diagnostics page */
    DIAGNOSTICIS_OPT_IN:             'COSDiagnosticsOptinView',

    /* Location sharing page */
    LOCATION_OPT_IN:                 'COSLocationOptinView',

    /* Shared Settings page */
    SHARED_SETTINGS:                 'COSUnifiedOptinFYIView',

    /* Passcode choice page */
    PASSCODE_CHOICE:                 'COSPasscodeChoiceView',

    /* Watchkit installation page */
    WATCHKIT_INSTALLATION:           'COSWatchKitAppsChoiceView',

    /* Unlock using watch confirmation page */
    UNLOCK_CONFIRMATION:             'COSUnlockConfirmationView',

    /* N64/N65 now supports standalone cellular, this is the view that helps us set it up */
    SET_UP_CELLULAR:                 'COSAkashiChoiceView',

    /* Info/landing page for SOS emergency beacon */
    EMERGENCY_SOS_INFO:              'COSSOSSetupChoiceGettingStartedView',

    /* Info/landing page for SOS emergency beacon and fall detection */
    EMERGENCY_SOS_FALL_INFO:         'COSSOS',

    /* Renaming of EMERGENCY_SOS_INFO in Peace16A283 */
    LEGACY_SOS_INFO:                 'COSLegacySOS',

    /* Prompts the user to add an emergency contact to notify when emitting
    SOS signal. Seen on builds before Whitetail14A292.  To be removed with
    <rdar://problem/26950850> Remove legacy Emergency SOS identifier */
    EMERGENCY_SOS_CONTACT_LEGACY:    'COSSOSSetupAddContactView',

    /* Prompts the user to add an emergency contact to notify when emitting
    SOS signal.  Seen on builds Whitetail14A292 and later. */
    EMERGENCY_SOS_CONTACT:           'Emergency SOS',

    /* Page to enable/disable workout route tracking.  Apple Watch uses GPS and Wi-Fi
    to track routes and local weather for outdoor workouts using the Workout app. */
    WORKOUT_ROUTE_TRACKING:          'COSFitnessRouteOptinView',

    /* Landing page for apple pay that shows up if you sign
     * into iCloud and set a passcode on the watch */
    APPLE_PAY_LANDING_PAGE:          'PKPaymentSetupAssistantRegistrationView',

    /** The COSSpinnerPage view that occurs occasionally during pairing. The view has the text '
     *  'Preparing your account. This may take a few minutes.' */
    PREPARING_YOUR_ACCOUNT:          'COSSpinnerPage',

    /** Intro page for the unusual heart rate detection alert */
    HEART_RATE_ALERT:                'COSCliftonIntroView',

    // Appears if Dictation is disabled or something <rdar://problem/42611361>
    // Pairing UI Script cannot handle COSDictationOptinView
    DICTATION_VIEW:                  'COSDictationOptinView',

    // Nike Run Club intro page
    NIKE_RUN_CLUB_VIEW:              'COSVictoryChoiceView',
};
/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

var appleWatch = UIATarget.localTarget().appWithBundleID('com.apple.Bridge');

/** Actions possible on the internal-only controls, or during post-scan buddy flow */
appleWatch.Controls = {

    /** Start Pairing button */
    START_PAIRING:                  'StartPairingButton',

    /**
     * Automation Button at the start pairing view
     *
     * The workaround with the "below" query is for the following radar
     * <rdar://problem/24133437> Watch Pairing fails on apple.com.Bridge launch
     *
     * Since the workaround has been here a long time and was added for other people,
     * I didn't want to change it, but I suspect it doesn't work anymore because the
     * Automation button is now physically above the StartPairingButton
     * as of rdar://problem/48575702.
     **/
    AUTOMATION:                     UIAQuery.buttons().beginsWith('Automation').orElse(UIAQuery.buttons().below('StartPairingButton')),

    /** Done entering pairing codes */
    DONE:                          'DONE',

    /** Install App Watchkit Apps */
    INSTALLALL:                    'Install All',

    /** Skip */
    SKIP:                          'skip',

    /** OK */
    OK:                            'OK',

    /** Agree */
    AGREE:                         'Agree',

    /** Start Pairing Additional watch */
    PAIR_ADDITIONAL_WATCH:         UIAQuery.tableCells('Pair a new Apple Watch').orElse(UIAQuery.tableCells('Pair New Watch')),

    /** General button on My Watch screen */
    GENERAL:                       'General',

    /** About button on My Watch screen */
    ABOUT:                         'About',

    /** Software Update button in My Watch -> General Screen */
    SOFTWARE_UPDATE:               'Software Update',

    /** Download and Install OTA update button */
    DOWNLOAD_AND_INSTALL:          UIAQuery.tableViews().andThen(UIAQuery.tableCells('Download and Install')),

    /** Install OTA update button */
    INSTALL:                       UIAQuery.tableViews().andThen(UIAQuery.tableCells('Install')),

    /** 'Downloading OTA Update' */
    DOWNLOADING_TO_WATCH:          UIAQuery.tableViews().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "Downloading to Watch"')),

    /** 'Installing OTA Update' */
    INSTALLING:                    UIAQuery.tableViews().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "Installing"')),

    /** 'Preparing OTA Update' */
    PREPARING:                     UIAQuery.tableViews().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "Preparing"')),

    /** 'Verifying OTA Update' */
    VERIFYING:                     UIAQuery.tableViews().andThen(UIAQuery.tableCells().withPredicate('name contains[c] "Verifying"')),

    /** 'Your software is up to date text' */
    SOFTWARE_UPTODATE:             UIAQuery.tableViews().withPredicate('name contains[c] "Your software is up to date."'),

    /** 'Try Again Alert' */
    TRY_AGAIN:                     UIAQuery.alerts().andThen(UIAQuery.buttons('Try Again')),

    /** 'Tap CLOSE on COULD_NOT_CONNECT_APPLE_WATCH Alert' */
    OK_ALERT:                      UIAQuery.alerts().andThen(UIAQuery.buttons('OK')), //'OK',

    /** 'Tap CLOSE on SOFTWARE_UPDATE_FAILED Alert' */
    CLOSE:                         UIAQuery.alerts().andThen(UIAQuery.buttons('Close')), //'Close',

    /** 'Tap CLOSE on UNABLE_TO_CHECK_FOR_UPDATE Alert' */
    CANCEL:                        UIAQuery.alerts().andThen(UIAQuery.buttons('Cancel')), //'Cancel',

    /** Version on About screen OTA update button */
    VERSION:                       UIAQuery.tableViews().andThen(UIAQuery.tableCells('Version')),

    /** Software Update button in My Watch -> General Screen */
    APP_INSTALL:                   'App Install',

    /** Photos button on My Watch screen */
    PHOTOS:                       'Photos',

    /** Photos Limit button on My Watch screen */
    PHOTOS_LIMIT:                 UIAQuery.tableViews().andThen(UIAQuery.tableCells('Photos Limit')),

    /** Photos Limit on Photos -> Photos Limit screen*/
    NUMBER_OF_PHOTOS:             UIAQuery.tableViews().andThen(UIAQuery.staticTexts("500 Photos")),

    /** Synced Album*/
    SYNCED_ALBUM:                 UIAQuery.tableViews().andThen(UIAQuery.tableCells('Synced Album')),

    /** Camera Roll or All Photos in Synced Album*/
    CAMERA_ROLL_OR_ALL_PHOTOS:    UIAQuery.tableViews().andThen(UIAQuery.tableCells('Camera Roll')).orElse(UIAQuery.tableViews().andThen(UIAQuery.tableCells('All Photos'))),

    /** Automatic App Install Switch*/
    AUTOMATIC_APP_INSTALL:        UIAQuery.tableViews().andThen(UIAQuery.tableCells('Automatic App Install')),

    /** An indicator that we are on the Photos view */
    PHOTOS_NAV:                   UIAQuery.navigationBars().andThen(UIAQuery.buttons('Photos')),

    /** Music button on My Watch screen */
    MUSIC:                       'Music',

    /** Storage Limit table cell for Storage Limit */
    STORAGE_LIMIT:                UIAQuery.tableViews().andThen(UIAQuery.tableCells('Storage Limit')),

    /** Storage Limit table cell for Storage Limit By */
    STORAGE_LIMIT_BY:             UIAQuery.tableViews().andThen(UIAQuery.staticTexts('Storage')),

    /** Storage Limit number for Storage Limit number*/
    STORAGE_LIMIT_NUMBER:         UIAQuery.tableViews().andThen(UIAQuery.staticTexts("2.0 GB")),

    /** Synced Music*/
    SYNCED_MUSIC:                 UIAQuery.tableViews().andThen(UIAQuery.tableCells('Synced Music')),

    /** Purchased in Synced Music*/
    PURCHASED_MUSIC:              UIAQuery.tableViews().andThen(UIAQuery.tableCells('Purchased')),

    /** An indicator that we are on the Music view */
    MUSIC_NAV:                    UIAQuery.navigationBars().andThen(UIAQuery.buttons('Music')),

    /** Profiles */
    PROFILE:                      'Profiles',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Looking at "My Watch" is defined as whether or not we can see the root My Watch view.
 * Viewing any subview of My Watch such as OTA updates or Friends does not count.
 * @returns true if we are looking at "My Watch", false if not.
 */
appleWatch.isInMyWatchRootView = function isInMyWatchRootView() {
    return this.exists(UIAQuery.navigationBars().endsWith('Watch')) && !this.exists(UIAQuery.BACK_NAV_BUTTON);
};

/**
 * Friends is defined as the list of friends view, not list of contacts when adding
 * a friend or the friend detail view when clicking on a specific friend.
 * @returns true if we are looking at the Friends list, false if we are not
 */
appleWatch.isInFriendsView = function isInFriendsView() {
    return this.exists(UIAQuery.AppleWatch.FRIENDS_LIST_TITLE);
};

/**
 * Goes to the root view of the My Watch tab.
 */
appleWatch.getToMyWatchRootView = function getToMyWatchRootView() {
    this.launch();

    // First get to the My Watch tab
    this.tap(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON);

    // Then navigate up the view hierarchy until we get to the root
    var attempts = 5;
    while (attempts >= 0 && !this.isInMyWatchRootView()) {
        var rootViewDidAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerTitle == "Settings"');
        this.tap(UIAQuery.BACK_NAV_BUTTON);
        if (!rootViewDidAppear.wait(2)) {
            UIALogger.logMessage('Root view did not appear after pressing the back button.');
        }
        attempts -= 1;
    }

    // Then validate our attempts
    UIAUtilities.assert(
        this.isInMyWatchRootView(),
        'Failed to get to My Watch page.'
    );
};

/**
 * Goes to the Friends list as defined in appleWatch.isInFriendsView()
 */
appleWatch.getToFriendsView = function getToFriendsView() {
    // This ensures that we close friends and reopen it because there is a weird bug
    // with accessability not refreshing when we remove friends and add friends
    // This also happens when we select a friend
    // <rdar://problem/22364136> VoiceOver Accessibility for Friends view in Watch App breaks when going from no friends to one friend
    this.getToMyWatchRootView();

    if (this.isInFriendsView()) {
        UIALogger.logMessage('Already at Friends. Taking no more action to getToFriendsView.');
        return;
    }

    // Actions to get to friends
    this.getToMyWatchRootView();
    var friendsDidAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerTitle == "Friends"');
    this.tap(UIAQuery.staticTexts('Friends'));

    // Validation that we succeeded
    UIAUtilities.assert(
        friendsDidAppear.wait(2),
        'Friends view did appear event was not received fast enough or at all.'
    );
    UIAUtilities.assert(
        this.isInFriendsView(),
        'Failed to get to Friends even after seeing the window pop up?'
    );
};

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Add a friend to the circle of friends (list of friends).
 * @param {string} friendName - the name of the contact to add to the friend wheel
 */
appleWatch.addFriend = function addFriend(friendName) {
    // Sanity check
    UIAUtilities.assert(
        typeof friendName === 'string' && friendName.length > 0,
        "The parameter 'friendName' must be a positive legnth string!"
    );

    this.getToFriendsView();

    // TODO: <rdar://problem/22441301> Support multiple pages of friends on Watch

    UIAUtilities.assert(
        this.exists(UIAQuery.AppleWatch.FRIENDS_ADD_PERSON_BUTTON),
        "'Add Person' button was not visible on screen"
    );

    var contactPickerDidAppear = UIAWaiter.withPredicate('ViewDidAppear', 'controllerTitle == "All Contacts"');
    this.tap(UIAQuery.AppleWatch.FRIENDS_ADD_PERSON_BUTTON);

    if (contactPickerDidAppear.wait(2)) {
        UIALogger.logMessage('Add contact as friend view appeared on first tap, suggesting that it was already pre-selected.');
    } else {
        UIALogger.logMessage('Add contact as friend view did not appear on first tap, suggesting that it was not already pre-selected and the first tap selected it for us.');
        UIALogger.logMessage('We will now attempt a second tap assuming the first tap was a selection tap.');

        // This ensures that we close friends and reopen it because there is a weird bug
        // with accessability not refreshing when we remove friends and add friends
        // <rdar://problem/22364136> VoiceOver Accessibility for Friends view in Watch App breaks when going from no friends to one friend
        this.getToFriendsView();

        var contactPickerDidAppearOnSecondTry = UIAWaiter.withPredicate('ViewDidAppear', 'controllerTitle == "All Contacts"');
        this.tap(UIAQuery.AppleWatch.FRIENDS_ADD_PERSON_BUTTON);
        UIAUtilities.assert(
            contactPickerDidAppearOnSecondTry.wait(2),
            'Add friend view did not appear in time.'
        );
    }

    this.tap(UIAQuery.tableCells(friendName));
};

/**
 * Removes a friend to the friend wheel (circle of friends)
 * @param {string} friendName - the name of the friend to remove to the friend wheel
 */
appleWatch.removeFriend = function removeFriend(friendName) {
    // Sanity check
    UIAUtilities.assert(
        typeof friendName === 'string' && friendName.length > 0,
        "The parameter 'friendName' must be a positive length string!"
    );

    this.getToFriendsView();

    var firstName = friendName.split(' ')[0];
    var triggerRemoveFriendQuery = UIAQuery.buttons('Remove %0'.format(firstName));

    // A lot of the times, you the friend you want to remove isn't "selected".
    // If the big center button isn't focused on the right person, we should
    // tap on the right person to focus and then tap on the big remove button.
    if (!this.exists(triggerRemoveFriendQuery)) {
        this.tap(UIAQuery.buttons(firstName));

        // This ensures that we close friends and reopen it because there is a weird bug
        // with accessability not refreshing when we remove friends and add friends
        // <rdar://problem/22364136> VoiceOver Accessibility for Friends view in Watch App breaks when going from no friends to one friend
        this.getToFriendsView();
    }

    // Tap the big button that triggers the alert to confirm you want to remove this friend
    this.tap(triggerRemoveFriendQuery);

    // Confirm that you want to remove this friend via the alert
    this.tap(UIAQuery.AppleWatch.FRIENDS_REMOVE_PERSON_BUTTON);
};

/**
 *  Fills in the appropriate Health information for the COSHealthStatsTableView pickers
 *
 *  @param {object} stats - an options dictionary containing Health Stats to set
 *  @param {string} [stats.birthday='2000-04-24'] - an ISO 8601 date string
 *  @param {string} [stats.sex='Female'] - String either 'Male', 'Female', or 'Other'
 *  @param {number} [stats.height=160] - Height in centimeters
 *  @param {number} [stats.weight=55] - Weight in kilograms
 *  @param {bool}   [stats.wheelchair=false] - Flag to indicate if wheelchair user
 *
 * @returns None.
 *
 **/
appleWatch.enterHealthStats = function enterHealthStats (stats) {
    var stats = UIAUtilities.defaults(stats, {
        birthday: '2000-04-24',
        sex: 'Female',
        height: 160,
        weight: 55,
        wheelchair: false,
    });

    // Birthday
    var birthday = new Date(stats.birthday);
    this.tap(UIAQuery.staticTexts().contains('Birthdate'));
    var picker_children = this.inspectElementKey(UIAQuery.pickers(), 'children');
    if (isNaN(picker_children[0].value)) {
        // if first column is a month
        var calendar_months = picker_children[0].values;
        // Months is a list of text months, days are an explicit list of text dates, and years is an int range
        var picker_values = [calendar_months[birthday.getUTCMonth()], birthday.getUTCDate().toString(), birthday.getUTCFullYear()];
    } else {
        // if first column is a number (Euro)
        var calendar_months = picker_children[1].values;
        var picker_values = [birthday.getUTCDate().toString(), calendar_months[birthday.getUTCMonth()], birthday.getUTCFullYear()];
    }
    this.setPickerValues(UIAQuery.pickers(), picker_values);
    this.tap(UIAQuery.AppleWatch.DONE_BUTTON);

    // Sex
    this.tap(UIAQuery.staticTexts().contains('Sex'));
    this.setPickerValues(UIAQuery.pickers(), [stats.sex]);
    this.tap(UIAQuery.AppleWatch.DONE_BUTTON);

    // Height
    this.tap(UIAQuery.staticTexts().contains('Height'));
    var picker_children = this.inspectElementKey(UIAQuery.pickers(), 'children');
    if (picker_children.length == 1) {
        // Metric
        this.setPickerValues(UIAQuery.pickers(), [[stats.height, 'cm'].join(' ')]);
    } else if (picker_children.length == 2) {
        // Imperial
        var feet = Math.floor(stats.height / 2.54 / 12);
        var inches = Math.round(stats.height / 2.54 % 12);
        this.setPickerValues(
            UIAQuery.pickers(),
            [[feet, 'ft'].join(' '), [inches, 'in'].join(' ')]
        );
    }
    this.tap(UIAQuery.AppleWatch.DONE_BUTTON);

    // Weight
    this.tap(UIAQuery.staticTexts().contains('Weight'));
    var picker_children = this.inspectElementKey(UIAQuery.pickers(), 'children');
    var units = picker_children.values().next().value.value.split(' ')[1]; // Either 'lb' or 'kg'
    if (units == 'lb') {
        stats.weight = Math.round(stats.weight * 2.2);
    }
    this.setPickerValues(UIAQuery.pickers(), [[stats.weight, units].join(' ')]);
    this.tap(UIAQuery.AppleWatch.DONE_BUTTON);

    // Wheelchair Support
    this.handlingAlertsInline(UIAQuery.alerts('Help Improve Wheelchair Mode?'), function() {
        // trigger alert
        this.tap(UIAQuery.staticTexts().contains('Wheelchair'));
        var wheelchair = stats.wheelchair ? 'Yes' : 'No';
        this.setPickerValues(UIAQuery.pickers(), [wheelchair]);
        this.tap(UIAQuery.AppleWatch.DONE_BUTTON);
        // handle alert
        if (stats.wheelchair) {
            this.tap(UIAQuery.buttons('Don’t Allow')); // Unicode apostrophe inside
        }
    });
    // Robust way to tap Continue button <rdar://problem/27685175>
    this.tap(UIAQuery.buttons('Continue').orElse(UIAQuery.buttons().atIndex(3)));
};

/**
 *  This function handles the flow by COSAppleIDSkippedBenefitsView which
 #  prompts the user to sign into Messages, Mail, and Calendar on the watch.
 *
 *  @param {string} password - the password for the Apple ID to sign in as, or
 *  null to skip this flow entirely
 **/
appleWatch.handleSkippedBenefits = function handleSkippedBenefits(password) {
    var skipped_benefits_waiter = UIAWaiter.waiter(
        'ViewDidDisappear',
        {
            predicate: 'controllerClass == "COSAppleIDSkippedBenefitsViewController"',

            // This view will disappear twice when we sign in and only once if
            // we skip.  This is because another view comes up when we sign in
            count: password != null && password.length > 0 ? 2 : 1,
        }
    );

    if (password) {
        this.tap('Sign in with Apple ID');
        this.handlingAlertsInline(
            UIAQuery.alerts().beginsWith('Set up Messages as'),
            function() {
                this.tap('Continue');
            }
        );
        this.handlingAlertsInline(
            UIAQuery.alerts('AuthKit Login'),
            function() {
                this.enterText(UIAQuery.secureTextFields(), password);
                this.tap('Sign In');
            }
        );
    } else {
        UIALogger.logMessage('Skipping skipped Benifits view');
        this.tap(UIAQuery.query('Next').orElse('Skip This Step'));
    }

    if (!skipped_benefits_waiter.wait(30)) {
        this._throwPairingError('Stuck at the skipped benefits view');
    }
};

/**
 *  This function handles the Apple Pay view.
 *  This function can be overridden by users who want to handle the Apple Pay view differently than default.
 *  Be careful when changing.
 *
 *  @param {object} options - options dictionary
 **/
appleWatch.handleApplePayView = function handleApplePayView(options) {
    // Tap next takes us from the landing page to the setup page
    // The setup page is where you can scan the card and add it
    // The landing page is just text explaining Apple Pay
    this.tap(UIAQuery.AppleWatch.WALLET_NEXT_BUTTON);

    // Do not use full string here: 'Set Up Later in the Apple Watch App'
    // There is a special character between 'Apple' and 'Watch'
    // u'Set Up Later in the Apple\xa0Watch App'
    // Fun fact, it's a non-breaking space so Apple Watch are always one word
    this.tap(UIAQuery.beginsWith('Set Up Later in the Apple'));
};



/**
 *  Launches gizmo setup in Apple Watch app, retrieves and enters pairing codes to connect both devices,
 *  then navigates through gizmo setup till end.
 *
 *  @param {object}  options - Pairing options dictionary
 *  @param {boolean} [options.useUnhappyPath=false] - Flag to indicate whether to use default pairing mode or the unhappy version
 *  @param {string}  [options.gizString=null] - Gizmo device string used in Engineering UI pairing
 *  @param {string}  [options.btString=null] - BT device string used in Engineering UI pairing
 *  @param {string}  [options.appleAccountID="PERSISTEDAPPLEID"] - Account name to confirm in post-pairing setup flow when signing in,
 *  or "PERSISTEDAPPLEID" to use the device's persisted account id.  Use null or empty string to skip signing into iCloud when prompted.
 *  @param {string}  [options.appleAccountPassword="PERSISTEDAPPLEIDPASSWORD"] - Account password to sign in in post-pairing setup flow,
 *  or "PERSISTEDAPPLEIDPASSWORD" to use the device's persisted account password.  Use null or empty string to skip signing into iCloud when prompted.
 *  @param {boolean} [options.installWatchKitApps=false] - Flag to indicate whether to install all watchkit apps or skip to later.
 *  @param {string}  [options.gizmoPasscode=null] - Passcode string that will be created in gizmo
 *  @param {boolean} [options.isFirstWatch=true] - Flag to indicate whether this is the first watch to pair with, or if it's a QuickSwitch device that supports multiple pairings.
 *                                                 NOTE: isFirstWatch is only applicable starting in Coral/Eagle
 *  @param {boolean} [options.wearOnRightWrist=false] - Flag to indicate which
 *  wrist to wear the watch on.  True for right, false for left.  If setting to
 *  true, you should consider setting options.wearOnRightWrist explicitly
 *  because that is part of the pairing flow.
 *  @param {boolean} [options.crownOnRightSide=false] - Flag to indicate which
 *  side to set the crown on.  True for right, false for left.  This option is
 *  only used if options.wearOnRightWrist is set to true
 *
 *  @param {boolean} [options.forcedOTAPhase1=false] - Flag to initiate UHP pairing process for rev-lock changes (SkiHill/Bucket) Watches with Eagle+
 *  @param {boolean} [options.forcedOTAPhase2=false] - Flag to complete the post pairing setup after OTA update for rev-lock (SkiHill/Bucket Watches) with Eagle+
 *
 *  @param {object} [options.healthStats=null] - an object containing Health Stats to set
 *  @param {object} [options.restoreFromBackup=false] - true to go down restore from backup flow, false to setup as new apple watch.
 *
 * @returns None.
 *
 * @throws If we fail to pair for whatever reason: BT connection failures,
 * activation failures, etc..
 **/
appleWatch.pairViaSetup = function pairViaSetup(options) {
    // Use the springboard standard alert handler to dismiss Finish Seting Up iPhone alert.
    // <rdar://problem/36752918> to remove
    appleWatch.withAlertHandler(springboard.standardAlertHandler, function () {
        options = UIAUtilities.defaults(options, {
            btString: null,
            gizString: null,
            useUnhappyPath: false,
            isFirstWatch: true,
            installWatchKitApps: false,
            gizmoPasscode: null,
            appleAccountID: 'PERSISTEDAPPLEID',
            appleAccountPassword: 'PERSISTEDAPPLEIDPASSWORD',
            wearOnRightWrist: false,
            crownOnRightSide: false,
            forcedOTAPhase1: false,
            forcedOTAPhase2: false,
            healthStats: null,
            restoreFromBackup: false,
        });

        // Scanning options
        var gizString, btString;
        // Post scan options
        var gizmoPasscode = null, appleAccountID = null, appleAccountPassword = null, installWatchKitApps = false;

        if (options.useUnhappyPath) {
            if (!options.gizString) {
                throw new UIAError('Gizmo string not provided for UHP flow pairing');
            }
        } else {
            if ((!options.btString) || (!options.gizString)) {
                throw new UIAError('Gizmo and BT strings not provided for engineering flow pairing!');
            }
        }

        btString = options.btString;
        gizString = options.gizString;

        if (options.gizmoPasscode) {
            gizmoPasscode = options.gizmoPasscode;
        }

        // We are only going to support signing into Apple ID account if both ID and password are provided
        if (options.appleAccountID && options.appleAccountPassword) {
            appleAccountID = options.appleAccountID;
            appleAccountPassword = options.appleAccountPassword;
        }

        if (options.installWatchKitApps) {
            installWatchKitApps = true;
        }

        // During the initial stages of pairing, if we don't have
        // BT or internet connectivity, an alert will appear saying
        // so, and we should fail when that happens
        this.withAlertHandler(this.getConnectedAlertHandler, function() {
            this.launch();

            // If this is not the first watch we're pairing with (i.e. we're in QuickSwitch mode),
            // then start by making sure we're at the general Watch Settings view, then navigate to Magic Switch options.
            if (options.isFirstWatch === false) {
                this.getToMyWatchRootView();
                this.tap(UIAQuery.AppleWatch.WATCH_PAIRING_OPTIONS_BUTTON);
            } else {
                // For first watch, we must tap the 'My Watch' tab to get to the pairing view from whatever tab view we are currently in.
                this.tap(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON);
            }

            UIALogger.logMessage('Retrieved the following strings for nanobuddy: GIZ => %0 - BT => %1'.format(gizString, btString));

            if (options.useUnhappyPath === true) {
                // Call the manual (a.k.a unhappy, a.k.a pincode-based) flow
                this.initiateUHPPairingFlow(gizString);
            } else {
                // Call the engineering flow
                this.initiateDefaultPairingFlow(btString, gizString);
            }
        });

        // Sometimes the engineering UI is still visible after tapping done.
        // At this point we've officially started the post-scan flow so it's safe to just dismiss the view.
        // Since the UI has another 'Cancel' button that's engineering UI,
        // we're just going to reference it by the bottommost. No point making this more accessible if it's internal.

        if (this.count(UIAQuery.buttons('Cancel')) > 1) {
            this.tap(UIAQuery.buttons('Cancel').bottommost());
        }

        // Make sure the engineering UI has been dismissed
        if (!this.waitUntilAbsent(UIAQuery.buttons('DONE'), 60)) {
            throw new UIAError('Stuck at the BT/Gizmo codes form');
        }

        // We still have a possible race because the underlying Setup Watch button reports as visible
        // even though obscured by the non-AX friendly internal UI. The waitUntilAbsent check for Done button covers
        // the UI but won't cover the animation delay during the dismissal. Till we figure out a solution in <rdar://problem/22665290>
        // we have no other option but to wait a couple of seconds.

        // We currently need to delay longer due to <rdar://problem/22811246>
        UIATarget.localTarget().delay(40);

        UIALogger.logMessage('forcedOTAPhase1 is: %0'.format(options.forcedOTAPhase1));

        if (options.forcedOTAPhase1) {
            var currentView = this.nameOf(UIAQuery.contains('NavigationBar'));
            if(currentView === 'COSGizmoCaptureView') {
                UIALogger.logMessage('currentView is: %0'.format(currentView));
                this.assertExists(UIAQuery.AppleWatch.UPDATE_APPLE_WATCH, 'Did not find Update Now button in appleWatch');
                this.tap(UIAQuery.AppleWatch.UPDATE_APPLE_WATCH);
                return;
            }
            throw new UIAError('Failed to navigate to Update your Apple Watch view');
        }

        this.postPairViaSetup(options);
    });
};

/**
 *  Launches activation setup on the gizmo setup in Apple Watch app.
 *  This function is used by iOS Update/Restore team to test rev-lock functionality for forcedOTA arguments.
 *
 * @returns None.
 *
 * @throws Did not land on My Watch View after completing Pairing Flow!
 **/
appleWatch.postPairViaSetup = function postPairViaSetup(options) {

    var postActivationWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "RUIPage" OR controllerClass == "BuddySimpleTCController"',
    });

    if (options.restoreFromBackup) {
        UIALogger.logMessage('Restoring from backup');
        this.tap(UIAQuery.AppleWatch.RESTORE_FROM_BACKUP);

        // Tap the first option for restoring from backup
        this.tap(UIAQuery.tableCells());

        // Note that we skip wrist selection when restoring from backup
    } else {
        // Check if 'Verifying Apple Watch' view is present and wait 2 minutes for it to disappear
        if (this.exists(UIAQuery.AppleWatch.VERIFYING_APPLE_WATCH_SOFTWARE)) {
            if (!this.waitUntilAbsent(UIAQuery.AppleWatch.VERIFYING_APPLE_WATCH_SOFTWARE, 120)) {
                this._throwPairingError('Timed out after waiting 2 minutes for "Verifying Apple Watch software..." view to disappear');
            }
        }

        UIALogger.logMessage('Setting up as new apple watch');
        if (this.exists(UIAQuery.AppleWatch.SETUP_AS_NEW_WATCH_BUTTON.isVisible())) {
            this.tap(UIAQuery.AppleWatch.SETUP_AS_NEW_WATCH_BUTTON);
        } else if (this.exists(UIAQuery.AppleWatch.SETUP_WATCH_BUTTON)) {
            this.tap(UIAQuery.AppleWatch.SETUP_WATCH_BUTTON);
        } else {
            this._throwPairingError('Stuck at "Your Apple Watch is Paired", unable to continue by tapping "Setup Watch"');
        }

        if (options.wearOnRightWrist) {
            this.tap(UIAQuery.AppleWatch.RIGHT_WRIST_BUTTON);

            // Note, the crown selection screen is only available if you select to wear the watch on the right wrist
            if (options.crownOnRightSide) {
                this.tap(UIAQuery.AppleWatch.RIGHT_CROWN_BUTTON);
            } else {
                this.tap(UIAQuery.AppleWatch.LEFT_CROWN_BUTTON);
            }
        } else {
            this.tap(UIAQuery.AppleWatch.LEFT_WRIST_BUTTON);
        }
    }


    if(!postActivationWaiter.wait(180)) {
        this._throwPairingError('Stuck after selecting wrist preference, Terms and Conditions failed to appear in a timely manner');
    }

    this.navigatePostPairingFlow(options);

    this.assertExists('My Watch', 'Did not land on My Watch View after completing Pairing Flow!');
};

/**
 *  Launches gizmo setup in Apple Watch app, navigates to device pairing options
 *  and unpairs.
 *  NOTE: Depending on whether the device has FindMy enabled or not, we may or may not get
 *  an alert asking us to disable activation lock. In other words, if a password is provided,
 *  we assume we should expect an alert and fail if we don't. Alternatively, we fail if we receive an
 *  alert with no password provided.
 *
 *  @param {object}  options - Pairing options dictionary
 *  @param {string}  [options.appleAccountPassword=null] - Account password to disable activation lock on watch.
 *  @param {string}  [options.watchName=null] - Name of watch to unpair with. This is mainly used in scenario where we have multiple paired watches.
 *
 * @returns None.
 *
 * @throws If phone was not paired to a watch or failed to unpair for whatever reason (activation lock, navigation, etc..)
 **/
appleWatch.unpair = function unpair(options) {
    // Why have an options dictionary with just one option?
    // Because this will be tweaked later to support specifying which device to unpair.
    options = UIAUtilities.defaults(options, {
        appleAccountPassword: null,
        watchName: null,
    });

    this.launch();

    var unpairingOptionsWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "COSPairedDeviceListViewController"',
    });

    // If we see the Pairing button visible then we're not even paired to a device
    if (this.exists(appleWatch.Controls.START_PAIRING)) {
        throw new UIAError('Companion does not seem to be paired with any watches!');
    }

    // Make sure we're at the My Watch Settings tab at the root view of the navigation stack
    this.getToMyWatchRootView();

    // Get to the unpair view
    this.tap(UIAQuery.AppleWatch.WATCH_PAIRING_OPTIONS_BUTTON);

    if (!unpairingOptionsWaiter.wait(3)) {
        throw new UIAError(
            'Stuck at "My Watch" root view, could not navigate to watch pairing settings!'
        );
    }


    // with a more info button for each one. If no device name specified we assume there's only one watch to pick.
    var watchInfoButtonPredicate = UIAQuery.AppleWatch.MORE_INFO_BUTTON;

    if (options.watchName) {
        // If we're here then we'll need to narrow it down further than just using UIAQuery.AppleWatch.MORE_INFO_BUTTON.
        watchInfoButtonPredicate = UIAQuery.withPredicate('name contains[c] "%0"'.format(options.watchName)).andThen(UIAQuery.AppleWatch.MORE_INFO_BUTTON);
    }

    this.tapIfExists(watchInfoButtonPredicate);

    this.tap(UIAQuery.AppleWatch.UNPAIR_BUTTON);

    // At this point we're getting the confirmation action for unpairing.
    // Depending on whether FindMy is enabled on the companion we might be asked
    // for password to disable activation lock.
    // So, if an account password is provided then activation lock is enabled, and
    // so we should expect an alert asking us to enter that password
    if (options.appleAccountPassword) {
        // Waiter so we can be informed once the alert is dismissed
        var loginAlertDisappearedWaiter = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "AKBasicLoginAlertController"',
        });
        this.handlingAlertsInline(UIAQuery.alerts().andThen(UIAQuery.withPredicate("name ==[c] 'Apple ID password'")), function() {
            this.tap(UIAQuery.AppleWatch.UNPAIR_CONFIRMATION_BUTTON);
            UIALogger.logMessage('Encountered activation lock alert. Entering password');
            if (options.appleAccountPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                UIALogger.logMessage('Using persisted account password');
                options.appleAccountPassword = springboard.appleIDPassword;
            }
            this.enterText(UIAQuery.secureTextFields(), options.appleAccountPassword);
            this.tap(UIAQuery.alerts().andThen('Unpair'));

            if (!loginAlertDisappearedWaiter.wait(3)) {
                throw new UIAError(
                    'Activation-lock alert still visible after entering provided password and tapping unpair.'
                );
            }
        });
    } else {
        var passwordAlert = UIAQuery.alerts();
        this.handlingAlertsInline(passwordAlert, function() {
            this.tap(UIAQuery.AppleWatch.UNPAIR_CONFIRMATION_BUTTON);

            // check if iCloud password alert pops open. If not, we were never signed into iCloud and a null password is okay
            if (this.exists(passwordAlert)) {
                throw new UIAError('Received an Activation Lock alert without a provided password to unlock!');
            }
        });
    }

    // With the addition of N111, watches can now have e-sims or cellular plans provisioned for them
    // On unpairing, if there is a plan, the user will be prompted to keep or remove it from the watch
    var keep_esim_plan_button = UIAQuery.buttons('Keep Plan');
    this.handlingAlertsInline(keep_esim_plan_button, function() {
        if (this.waitUntilPresent(keep_esim_plan_button)) {
            this.tap(keep_esim_plan_button);
        } else {
            UIALogger.logMessage('Prompt to remove cellular plan did not appear and may not have been expected');
        }
    });

    if (!this.waitUntilAbsent('Unpairing', 600)) {
        this._throwPairingError('Timed out waiting to finish unpairing!');
    }
};

/**
* Post-Scan function that navigates through Setup buddy for Watch till we're done setting up the Watch.
* We tweak all the different options per options specified, and
* wait 30 mins for initial sync to complete (if applicable).
* This assumes we've just called initiateDefaultPairingFlow and returned successfully.
* Expected starting state: Past activation, which is as of watchOS2.0 after Wrist Selection view.
*
*  @param {object}  options - Pairing options dictionary
*  @param {string}  [options.appleAccountID="PERSISTEDAPPLEID"] - Account name to confirm in post-pairing setup flow when signing in
*  or "PERSISTEDAPPLEID" to use the device's persisted account id.  Use null or empty string to skip signing into iCloud when prompted.
*  @param {string}  [options.appleAccountPassword="PERSISTEDAPPLEIDPASSWORD"] - Account password to sign in in post-pairing setup flow
*  or "PERSISTEDAPPLEIDPASSWORD" to use the device's persisted account password.  Use null or empty string to skip signing into iCloud when prompted.
*  @param {boolean} [options.installWatchKitApps=false] - Flag to indicate whether to install all watchkit apps or skip to later.
*  @param {string}  [options.gizmoPasscode=null] - Passcode string that will be created in gizmo
*  @param {number}  [options.iCloudLoginTimeout=30] - The amount of seconds to wait for iCloud login to succeed before timing out and failing.
*  @param {number}  [options.syncTrapTimeout=1800] - The amount of seconds to wait for sync trap to complete before timing out and failing.
*  @param {boolean} [options.enableActivationLock=false] - True to enable activation lock, false to disable activation lock.
*                                                          This option is only used when the Activation Lock screen is prompted.
*                                                          The prompt only occurs when the user signs in with an appleAccountID
*                                                          and appleAccountPassword.
*  @param {boolean} [options.enableWorkoutRouteTracking=true] - Sets whether to enable or disable workout route tracking
*  @param {boolean} [options.useSiri=false] - True to enable Siri, false to disable Siri.
*
*  @param {object} [options.healthStats=null] - an object containing Health Stats to set
*
* @returns None.
*
* @throws If we don't get past a certain view after performing the action associated with it.
*         If we get an unexpected view (e.g. a new Setup page).
*         If we time out waiting for SyncTrap to finish.
*         If we time out waiting for iCloud to sign in.
*/
appleWatch.navigatePostPairingFlow = function navigatePostPairingFlow (options) {
    options = UIAUtilities.defaults(options, {
        installWatchKitApps: false,
        gizmoPasscode: null,
        appleAccountID: 'PERSISTEDAPPLEID',
        appleAccountPassword: 'PERSISTEDAPPLEIDPASSWORD',
        iCloudLoginTimeout: 180,
        syncTrapTimeout: 1800,
        enableActivationLock: false,
        enableWorkoutRouteTracking: true,
        useSiri: false,
        healthStats: null,
    });
    var startTimeInSec = new Date().getTime()/1000;
    var currentTimeInSec = startTimeInSec;
    var invalidViewCount = 0;

    // Navigate gizmo setup till the end. Use navigation bar titles as our reference point.
    var currentView = this.nameOf(UIAQuery.contains('NavigationBar'));

    while (currentView !== 'COSSetupFinishedView'  && currentTimeInSec - startTimeInSec < 600) {
        UIALogger.logMessage('currentView is: %0'.format(currentView));

        // Perform the appropriate action per view (determined by view name on nav bar).
        // For some of these we'll have a waiter confirm the view has disappeared once ation is performed.
        // Why not do this for all views? Most of the views take less than a second to surpass so it seems to be overkill.
        // We only care about the ones where there would be a delay (due to background activation, passcode creation, etc..)
        switch(currentView) {
            case UIStateDescription.AppleWatch.RUIPAGE:
            case UIStateDescription.AppleWatch.TERMS_AND_CONDITIONS:
                this.acceptAndDismissTermsAndConditions();
                break;
            case UIStateDescription.AppleWatch.LOGIN_VIEW:
            case UIStateDescription.AppleWatch.LEGACY_LOGIN_VIEW:
            case UIStateDescription.AppleWatch.ITUNES_LOGIN_VIEW:
                var accountLoginWaiter = UIAWaiter.waiter(
                    'ViewDidDisappear', {
                        predicate: 'controllerClass == "COSiCloudLoginViewController" OR controllerClass == "COSiTunesStoreLoginViewController"',
                });
                var skippedBenefitsWaiter = UIAWaiter.waiter(
                    'ViewDidAppear', {
                        predicate: 'controllerClass == "COSAppleIDSkippedBenefitsViewController"',
                });
                // Sign into account
                if (options.appleAccountID && options.appleAccountPassword) {
                    UIALogger.logMessage('At the Apple ID page. Confirming and entering credentials...');
                    this.enterAppleIDCredentials(options.appleAccountID, options.appleAccountPassword);
                } else {
                    UIALogger.logMessage('At the Apple ID page for IDS. Skipping...');
                    this.tap(UIAQuery.AppleWatch.SKIP_LOGIN_BUTTON);
                }

                var loginStartTime = new Date().getTime()/1000;
                if (!accountLoginWaiter.wait(options.iCloudLoginTimeout)) {
                    this._throwPairingError('Stuck at the iCloud sign in view!');
                }
                var loginEndTime = new Date().getTime()/1000;
                this._logMetaData('Time In iCloud Sign In', loginEndTime - loginStartTime);

                UIALogger.logMessage("We're past the credentials page");

                if (skippedBenefitsWaiter.wait(10)) {
                    UIALogger.logMessage('Skipped Benefits view appeared');
                    if (options.appleAccountPassword === 'PERSISTEDAPPLEIDPASSWORD') {
                        UIALogger.logMessage('Using persisted account password');
                        this.handleSkippedBenefits(springboard.appleIDPassword);
                    } else {
                        this.handleSkippedBenefits(options.appleAccountPassword);
                    }
                } else {
                    UIALogger.logMessage('Skipped Benefits view did not appear');
                }
                break;
            case UIStateDescription.AppleWatch.SKIPPED_BENEFITS_VIEW:
                // If we get this view stand-alone, it implies we did not get the Apple ID
                // login view previously and that we should just skip signing in because
                // we didn't log in on the phone yet.
                this.handleSkippedBenefits(null);
                break;
            case UIStateDescription.AppleWatch.ACTIVATION_LOCK:
                UIALogger.logMessage('At activation lock opt-in page.');

                if (options.enableActivationLock) {
                    UIALogger.logMessage('Enabling Activation Lock');
                    this.handlingAlertsInline(UIAQuery.alerts('Enable Activation Lock?'), function() {
                        this.tap(UIAQuery.AppleWatch.ENABLE_ACTIVATION_LOCK_BUTTON);
                        this.tap(UIAQuery.alerts('Enable Activation Lock?').andThen(UIAQuery.buttons('OK')));
                    });
                } else {
                    UIALogger.logMessage('Disabling Activation Lock');
                    this.tap(UIAQuery.AppleWatch.DISABLE_ACTIVATION_LOCK_BUTTON);
                }
                break;
            case UIStateDescription.AppleWatch.SIRI_OPT_IN:
                UIALogger.logMessage('At the Siri Opt-in page. Enabling/Confirming...');

                // In this view we're either being prompted to enable Siri (if companion doesn't already have it enabled,
                // or Siri is already enabled, in which case we just hit OK to confirm.
                if (options.useSiri) {
                    this.handlingAlertsInline(UIAQuery.alerts().contains('Siri'), function() {
                        this.tap(UIAQuery.AppleWatch.USE_SIRI_BUTTON);
                        UIALogger.logMessage('Encountered Siri alert. Tapping OK...');
                        this.tap(UIAQuery.alerts().andThen('OK'));
                    });
                } else {
                    this.tap(UIAQuery.AppleWatch.DONT_USE_SIRI_BUTTON);
                }
                break;
            case UIStateDescription.AppleWatch.SET_UP_ACTIVITY:
                UIALogger.logMessage('At the Set Up Activity page.');
                if (options.healthStats == null) {
                    UIALogger.logMessage('Skipping Set Up Activity.');
                    var activityViewWaiter = UIAWaiter.waiter(
                        'ViewDidDisappear', {
                            predicate: 'controllerClass == "COSHealthChoiceViewController"',
                    });
                    this.tap(UIAQuery.buttons('Skip This Step'));
                    UIAUtilities.assert(
                        activityViewWaiter.wait(60),
                        'Set Up Activity view did not disappear.  We tapped \
                        Skip This Step and waited 60 seconds.'
                    );
                } else {
                    this.tap(UIAQuery.AppleWatch.SETUP_ACTIVITY_BUTTON);
                }
                break;
            case UIStateDescription.AppleWatch.ACTIVITY_HEALTH_STATS:
                this.enterHealthStats(options.healthStats);
                break;
            case UIStateDescription.AppleWatch.HEALTH_GOAL_TABLE:
                this.tap(UIAQuery.buttons("Set Move Goal"));
                break;
            case UIStateDescription.AppleWatch.DIAGNOSTICIS_OPT_IN:
                UIALogger.logMessage("At the Diag page. Hitting Don't Send...");
                this.tap(UIAQuery.AppleWatch.DONT_SEND_BUTTON);
                break;
            case UIStateDescription.AppleWatch.LOCATION_OPT_IN:
                // This view appears when Location Services are not enabled on the phone
                UIALogger.logMessage('At the Location/Shared Settings page. Enabling now.');
                this.handlingAlertsInline(UIAQuery.alerts().andThen('Turn on Location Services?'), function() {
                    this.tap(UIAQuery.buttons('Enable Location Services'));
                    this.tap(UIAQuery.alerts().andThen('OK'));
                });
                break;
            case UIStateDescription.AppleWatch.SHARED_SETTINGS:
                // This view appears when Location Services are already
                // enabled on the phone.  Really, there's nothing for the user
                // to do here other than to read the text and press OK.
                this.tap('OK');
                break;
            case UIStateDescription.AppleWatch.PASSCODE_CHOICE:
                this.setupPasscodeSettings(options.gizmoPasscode);
                break;
            case UIStateDescription.AppleWatch.WATCHKIT_INSTALLATION:
                this.setupWatchkitSettings(options.installWatchKitApps);
                break;
            case UIStateDescription.AppleWatch.SET_UP_CELLULAR:
                this.setupCellular();
                break;
            case UIStateDescription.AppleWatch.UNLOCK_CONFIRMATION:
                UIALogger.logMessage('Waiting for gizmo to confirm iPhone unlocking');
                break;
            case UIStateDescription.AppleWatch.EMERGENCY_SOS_INFO:
            case UIStateDescription.AppleWatch.EMERGENCY_SOS_FALL_INFO:
            case UIStateDescription.AppleWatch.LEGACY_SOS_INFO:
                UIALogger.logMessage('Landed on the Emergency S.O.S. getting started page.');
                var sosWaiter = UIAWaiter.withPredicate(
                    'ViewDidDisappear',
                    [
                        'controllerClass == "COSSOSSetupChoiceGettingStartedViewController"',
                        'controllerClass == "COSLegacySOSController"',
                        'controllerClass == "COSSOSController"',
                    ].join(" OR "));
                // The 'Get Started' button was changed to 'Continue' in WhitetailSeed14A5297b
                // However, the button remains as 'Get Started' in Whitetail14A298
                // Thus, we should probably support both if we are not branching for Seed trains
                this.tap(UIAQuery.buttons('Get Started').orElse(UIAQuery.buttons('Continue')));
                UIAUtilities.assert(
                    sosWaiter.wait(60),
                    'Emergency SOS getting started page did not go away after confirming'
                );
                break;
            case UIStateDescription.AppleWatch.EMERGENCY_SOS_CONTACT_LEGACY:
            case UIStateDescription.AppleWatch.EMERGENCY_SOS_CONTACT:
                UIALogger.logMessage('Landed on the Emergency Contact enrollment page.');
                this.tap(UIAQuery.buttons('Skip'));
                break;
            case UIStateDescription.AppleWatch.WORKOUT_ROUTE_TRACKING:
                UIALogger.logMessage('Landed on the Workout Route Tracking enrollment page.');
                if (options.enableWorkoutRouteTracking) {
                    this.tap(UIAQuery.buttons('Enable Route Tracking'));
                } else {
                    this.tap(UIAQuery.buttons('Disable Route Tracking'));
                }
                break;
            case UIStateDescription.AppleWatch.APPLE_PAY_LANDING_PAGE:
                UIALogger.logMessage('Landed on the Apple Pay landing page.');
                this.handleApplePayView(options);
                break;
            case UIStateDescription.AppleWatch.PREPARING_YOUR_ACCOUNT:
                // This view occasionally appears after the Terms & Conditions view. We wait for
                // the COSSpinnerPage view to disappear and continue the UI flow.
                var preparingYourAccountWaiter = UIAWaiter.waiter(
                    'ViewDidDisappear', {
                        predicate: 'controllerClass == "COSSpinnerPageController"',
                });

                // Since the view can disappear on it's own and can take a
                // very short amount of time, we should check that the view
                // still exist on screen.  The waiter might miss the
                // ViewDidDisappear notification if it disappears between us
                // reading the nav-bar and us creating the waiter.
                currentView = this.inspect(UIAQuery.contains('NavigationBar')).name;
                if (currentView != UIStateDescription.AppleWatch.PREPARING_YOUR_ACCOUNT) {
                    UIALogger.logMessage('Preparing Your Accounts went away before waiting');
                    break;
                }

                // Since this view is associated with iCloud and in the past we waited 10 minutes for
                // the iCloud view to disappear, we'll wait 10 minutes here for this view to disappear
                UIAUtilities.assert(
                    preparingYourAccountWaiter.wait(600),
                    'Preparing your account spinner view did not disappear after 10 minutes of waiting.'
                );
                break;
            case UIStateDescription.AppleWatch.HEART_RATE_ALERT:
                UIALogger.logMessage('Landed on the Heart Rate Alert information page.');

                // Tap the continue button to move to the next view.
                this.tap(UIAQuery.buttons('Continue'));
                break;
            case UIStateDescription.AppleWatch.DICTATION_VIEW:
                UIALogger.logMessage('Got Dictation View');
                this.handlingAlertsInline(UIAQuery.alerts().andThen('Turn on Dictation?'), function() {
                    this.tap(UIAQuery.buttons('Use Dictation'));
                    this.tap('OK');
                });
                break;
            case UIStateDescription.AppleWatch.NIKE_RUN_CLUB_VIEW:
                UIALogger.logMessage('Landed on the Nike Run Clube View. Tapping Download Later');

                // Tap the 'Download Later' button to continue
                this.tap(UIAQuery.buttons('Download Later'));
                break;
            default:
                if (invalidViewCount >= 3) {
                    throw new UIAError('Unrecognized view: %0'.format(currentView));
                } else {
                    invalidViewCount++;
                    UIALogger.logWarning('Invalid view %0 so waiting and trying again...'.format(currentView));
                }
                break;
        }
        currentView = this.inspect(UIAQuery.contains('NavigationBar')).name;
        currentTimeInSec = new Date().getTime()/1000;
    }

    startTimeInSec = new Date().getTime()/1000;
    currentTimeInSec = startTimeInSec;
    var syncCompleted = false;
    var syncTimeoutStr = 'Timed out waiting %0 minutes for SyncTrap to complete'.format(options.syncTrapTimeout/60);

    // It seems new hardware can sometimes remove indicators on screen because
    // they are disclosure sensitive <rdar://problem/43252705>.  Thus, we rely
    // on two separate indicators.  The second one uses .endsWith because
    // there is a non-breaking space between "Apple Watch" and I feel it's
    // easier to maintain code that doesn't randomly have unicode in it
    if (this.exists(UIAQuery.query('Sync progress').orElse(UIAQuery.endsWith('Watch Is Syncing')))) {
        UIALogger.logMessage('In SyncTrap. Waiting for completion...');

        // Unfortunately we currently need to just wait and check again due to <rdar://problem/22271992>
        // Since waitUntilPresent is an expensive polling operation, we're better off running it once every minute
        // than every second until we decide it's taken too long and timeout/giveup.
        while (!syncCompleted && currentTimeInSec - startTimeInSec < options.syncTrapTimeout) {
            syncCompleted = this.waitUntilPresent(UIAQuery.AppleWatch.SYNC_COMPLETE_LABEL);
            UIATarget.localTarget().delay(60);
            currentTimeInSec = new Date().getTime()/1000;
        }
        if (!syncCompleted) {
            UIALogger.logMessage('idstool dump-logs output: '.format(target.performTask('/usr/local/bin/idstool', ['dump-logs']).stdout));
            this._throwPairingError(syncTimeoutStr);
        }
    }

    if (!this.exists(UIAQuery.AppleWatch.SYNC_COMPLETE_LABEL)) {
        UIALogger.logMessage('idstool dump-logs output: '.format(target.performTask('/usr/local/bin/idstool', ['dump-logs']).stdout));
        this._throwPairingError(syncTimeoutStr);
    }

    this._logMetaData('Time In Sync Trap', currentTimeInSec - startTimeInSec);

    var setupFinishedWaiter = UIAWaiter.waiter(
        'ViewDidDisappear', {
            predicate: 'controllerClass == "COSSetupFinishedViewController"',
    });

    // At this point we're at the finished page. Tap and make sure we land in Watch Settings.
    // 'OK' was changed to GoToBridgeButton in 14A204.  Both are kept for backwards
    // compatibility reasons as other teams are not always testing against the latest builds.
    this.tap(UIAQuery.buttons('GoToBridgeButton').orElse(appleWatch.Controls.OK));

    if (!setupFinishedWaiter.wait(30)) {
        this._throwPairingError('Did not move past Setup Finished View!');
    }
};


/**
* Pre-Scan function that starts the default path for pairing flow. It leverages an internal-only UI flow,
* where it taps the automation button and injects the BT pairing code and gizmo name string into the
* text fields.
* This assumes the 'Automation' button is already visible (by setting the nanobuddy default to enable it)
*
* Expected starting state: At the "Start Pairing" view when launching unpaired watch app for first time.
* OR at watch settings view where we can pair an additional watch.
*
*  @param {string} [btString] - BT device string used in Engineering UI pairing
*  @param {string} [gizString] - Gizmo device string used in Engineering UI pairing
*
* @returns None.
*
* @throws If we don't get the internal view for injecting the pairing codes
*         If we don't find the internal Automation button
*/
appleWatch.initiateDefaultPairingFlow = function initiateDefaultPairingFlow(btString, gizString) {
    var tinkerViewWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "COSPairingTypeSelectionViewController"',
    });

    // Tap on the "Automation" button to get to Engineering UI for Pairing
    UIALogger.logMessage('Tapping on Automation button...');
    this.assertExists(appleWatch.Controls.AUTOMATION, 'Did not find Automation button in intial pairing view');

    var postScanWaiter = UIAWaiter.waiter(
        'Announcement', {
            predicate: 'announcement == "Started pairing"',
    });

    var manualPairingViewWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "COSInternalManualPairingViewController"',
    });

    this.tap(appleWatch.Controls.AUTOMATION);

    // If the Tinker view comes up, we should handle it
    if (tinkerViewWaiter.wait(10)) {
        this.tap(UIAQuery.AppleWatch.SET_UP_FOR_MYSELF_BUTTON)
    }

    if (!manualPairingViewWaiter.wait(3)) {
        throw new UIAError(
            "Gizmo/BT codes form not visible after tapping automation."
        );
    }

    this.setControl(UIAQuery.AppleWatch.GIZMO_NAME_TEXTFIELD, gizString);
    this.setControl(UIAQuery.AppleWatch.BLUETOOTH_ID_TEXTFIELD, btString);
    this.tap(appleWatch.Controls.DONE);

    // We chose two minutes in timeout because pairing team suggested BT connect can take a minute and a half
    // <rdar://problem/23580105> Automation: Pairing happy path stuck at Giz and BT forms
    if (!postScanWaiter.wait(120)) {
        UIALogger.logMessage(
            'idstool dump-logs output: %0'.format(
                target.performTask('/usr/local/bin/idstool', ['dump-logs']
                ).stdout)
        );
        throw new UIAError('Stuck at the scanning/connecting phase!');
    }

};


/**
* Pre-Scan function that starts the manual (a.k.a unhappy) path pairing flow.
* It mimicks the user flow by initiating the manual flow, and looking for the watch to pair with
* within a list of bluetooth devices. Once selected, it waits for a pin code to enter,
* which would be generated by another process and written to a file.
* NOTE: This CANNOT run on its own! It requires the host executing this script to run the gizmo equivalent
* in parallel, and create a file with the pin code to enter.
*
* This assumes the following Apple Watch app has already been launched.
*
* Expected starting state: At the "Start Pairing" view, OR, for Coral and later, at watch settings view (to pair multiple watches)
*
*  @param {string} gizmoIdentifierString - Gizmo device string used in Engineering UI pairing
*
* @returns None.
*
* @throws If we don't get the list of devices to pair with when initiating pairing
*         If we don't get the pin code to enter once we've selected the device to pair with
*/
appleWatch.initiateUHPPairingFlow = function initiateUHPPairingFlow(gizmoIdentifierString) {
    UIAUtilities.assert(gizmoIdentifierString, 'Must specify gizmo ID string!');
    var cameraViewWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "COSGizmoCaptureViewController"',
    });

    var tinkerViewWaiter = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "COSPairingTypeSelectionViewController"',
    });

    // If the pair additional watch button is visible, then this ain't the first watch
    // we're pairing with. Tapping either that button or the "Start Pairing" button will
    // lead us to the same camera finder view though
    if (this.exists(appleWatch.Controls.PAIR_ADDITIONAL_WATCH)) {
        UIALogger.logMessage('Going through unhappy path to pair an additional watch..');
        this.tap(appleWatch.Controls.PAIR_ADDITIONAL_WATCH);
    } else {
        UIALogger.logMessage('Going through unhappy path, tapping on Start Pairing button...');
        this.tap(appleWatch.Controls.START_PAIRING);
    }

    // If the Tinker view comes up, we should handle it
    if (tinkerViewWaiter.wait(10)) {
        this.tap(UIAQuery.AppleWatch.SET_UP_FOR_MYSELF_BUTTON)
    }

    if (!cameraViewWaiter.wait(10)) {
        throw new UIAError('COSGizmoCaptureViewController not visible after tapping the Start Pairing button!');
    }

    UIALogger.logMessage('Tapping on help button to trigger UHP...');

    // At this point we're at the Camera view finder. Tap on the 'setup watch manually' button
    this.tap(UIAQuery.AppleWatch.PAIR_MANUALLY_BUTTON);

    // The gizmo identifier is an alphanumeric string that follows a certain format.
    // The numberic portion is what we care about for matching on list of device.
    // Example: gizmoDeviceString = '50647BDC'. What appears to the user: '5064'
    var gizmoDisplayString = String(gizmoIdentifierString.match(/[\d]+/));
    var deviceInBluetoothListPredicateString = 'name contains[c] "%0"'.format(gizmoDisplayString);

    // Allow up to 5 seconds for gizmo to show up on that bluetooth list.
    // This is a bit hacky till we have a proper notification: <rdar://problem/22405381>
    this.withMaximumSnapshotBreadth(20, function() {
        if (!this.waitUntilPresent(UIAQuery.withPredicate(deviceInBluetoothListPredicateString), 20)) {
            throw new UIAError('Did not find gizmo in companion bluetooth list');
        }
    });

    this.tap(UIAQuery.withPredicate(deviceInBluetoothListPredicateString));

    // At this point we have selected the device we want to pair with, and we should have a visible keyboard
    // to enter a pin code. We are waiting for gizmo to generate that pin and pass it along.
    // For doing so we'll be using a file as a lock to tell us what that pin is.

    // The unique name of the file. Since the host this device is attached to follows the same format
    // for the file name, and is highly unlikely to change, we don't need to worry about just passing
    // this along.

    // NOTE: semaphore is used strictly as a term. It's neither a UIASemaphore nor
    // does it leverage the common semaphore usage.
    var semaphoreUUID = 'semaphore-%0-UHP'.format(gizmoIdentifierString);

    // full file path
    var filepath = '/tmp/%0'.format(semaphoreUUID);

    UIALogger.logMessage('Looking for %0 ...'.format(filepath));

    // Start blocking till we find the file with that pin code.
    // For now, make it 45seconds, per <rdar://problem/23376796>
    this.waitForFileToExist(filepath, 45);

    // Grab the pin code and enter it in the popup keyboard
    var pinCode = target.performTask('/bin/cat',[filepath]).stdout.trim();

    UIALogger.logMessage('Found pin: %0'.format(pinCode));
    UIAUtilities.assert(pinCode.length === 6, 'Invalid pin code from gizmo found in file!');

    // We don't need the file anymore.
    target.performTask('/bin/rm', [filepath]);

    // Start the actual pair
    var keyboard = UIAQuery.keyboard();
    if (!this.exists(keyboard)) {
        throw new UIAError('6-digit pin code view not visible in UHP!');
    }

    var unhappyPathPairingViewControllerWaiter = UIAWaiter.waiter(
        'ViewDidDisappear', {
            predicate: 'controllerClass == "COSSecurePairingFlowViewController"',
    });

    this.typeString(pinCode);

    if (!unhappyPathPairingViewControllerWaiter.wait(60)) {
        UIALogger.logMessage('idstool dump-logs output: %0'.format(target.performTask('/usr/local/bin/idstool', ['dump-logs']).stdout));
        throw new UIAError('Stuck after entering 6-digit pin from gizmo in UHP!');
    }
};

/**
 * Launch Watch app, start pairing, verify camera is running
 */
appleWatch.startPairing = function startPairing() {
    var cameraWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass = "COSGizmoCaptureViewController"'
    );

    this.launch();

    this.tapIfExists(UIAQuery.AppleWatch.START_PAIRING_BUTTON);
    UIAUtilities.assert(
        (cameraWaiter.wait(5.0)),
        'Failed to reach Camera view state'
    );

    // Verify Camera is running
    UIAUtilities.assert(
        (this.isCameraIrisOpen()),
        'Failed to get Camera ready for pairing Apple Watch'
    );

    this.delay(2); // Fix the view for 2 sec to make it look more natural
    this.tapIfExists(UIAQuery.AppleWatch.CANCEL_PAIRING_BUTTON);
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
* Post-Scan function that handles password entering when presented with the Login option during
* buddy flow. This should only be called when we're at the "Sign In" page in watch setup buddy.
* It verifies first that the account name the view is asking password for in fact matches what the caller
* thinks it is.
*
* Expected starting state: At the "Sign In" page in watch setup buddy.
*
*  @param {string} [appleAccountID] - Account name to confirm in post-pairing setup flow when signing in,
*  or "PERSISTEDAPPLEID" to use the device's persisted account id.  Use null or empty string
*  to skip signing into iCloud when prompted.
*  @param {string} [appleAccountPassword] - Account password to sign in in post-pairing setup flow, or
*  "PERSISTEDAPPLEIDPASSWORD" to use the device's persisted account password.  Use null or empty string
*  to skip signing into iCloud when prompted.
*
* @returns None.
*
* @throws If we don't transition from the AppleIDLogin view after entering the password.
*         If we did not find the account name in that view matching the value of appleAccountID
*/
appleWatch.enterAppleIDCredentials = function enterAppleIDCredentials(appleAccountID, appleAccountPassword) {
    if (appleAccountID === 'PERSISTEDAPPLEID') {
        UIALogger.logMessage('Using persisted account ID');
        appleAccountID = springboard.appleID;
    }
    if (appleAccountPassword === 'PERSISTEDAPPLEIDPASSWORD') {
        UIALogger.logMessage('Using persisted account password');
        appleAccountPassword = springboard.appleIDPassword;
    }

    this._logMetaData('iCloud Login ID', appleAccountID);
    this._logMetaData('iCloud Login Passcode', appleAccountPassword);

    if (this.exists(UIAQuery.withPredicate('name contains[c] "%0"'.format(appleAccountID)))) {
        this.tap(UIAQuery.secureTextFields());
        this.typeString(appleAccountPassword);
        this.typeString('\n');
    } else {
        throw new UIAError('Could not find element with %0 as account name.'.format(appleAccountID));
    }
};

/**
* Post-Scan function that accepts and moves past the Terms and Conditions page during the buddy flow.
*
* Expected starting state: At the T&C view.
*
* @returns None.
*
* @throws If we don't transition past T&C.
*/
appleWatch.acceptAndDismissTermsAndConditions = function acceptAndDismissTermsandConditions() {
    var tAndCAlertWaiter = UIAWaiter.waiter(
        'ViewDidDisappear', {
            predicate: 'controllerClass == "RUIPage" OR controllerClass == "BuddySimpleTCController"',
    });
    UIALogger.logMessage('At the T&C view. Hitting accept...');

    this.handlingAlertsInline(UIAQuery.alerts().andThen('Terms and Conditions'), function() {
        this.tap(appleWatch.Controls.AGREE);
        UIALogger.logMessage('Encountered T&C confirmation alert. Tap agree...');
        appleWatch.tapIfExists(UIAQuery.alerts().andThen('Agree'));
    });

    if (!tAndCAlertWaiter.wait(120)) {
        throw new UIAError('Stuck at Terms and Conditions view');
    }
};

/**
* Post-Scan function that enables or disables passcode creation on watch during buddy flow.
* If no value provided for gizmoPasscode (or if it's set to null), then we're skipping passcode creation
*
* Expected starting state: At the Create Passcode Options page.
*
*  @param {string} [gizmoPasscode] - Optional passcode string that will be created in gizmo.
*
* @returns None.
*
* @throws If we're not in passcode settings, or if we don't move past it 60 seconds later.
*/
appleWatch.setupPasscodeSettings = function setupPasscodeSettings(gizmoPasscode) {
    // We're currently using gizmoPasscode merely as a flag till we add validation support.
    if (gizmoPasscode) {
        var passcodeCreationViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "COSPasscodeCreateViewController"',
        });
        var passcodeCreationViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "COSPasscodeCreateViewController"',
        });
        this.tap(UIAQuery.AppleWatch.CREATE_PASSCODE_BUTTON);

        if (!passcodeCreationViewAppeared.wait(3)) {
            throw new UIAError('Companion is not in Create a Passcode view as expected!');
        }
        UIALogger.logMessage('At the passcode page. Waiting for gizmo to enter new passcode');

        if(!passcodeCreationViewDisappeared.wait(60)) {
            throw new UIAError('Companion waited more than 60 seconds for gizmo to finish creating passcode');
        }
    } else {
        UIALogger.logMessage('At the passcode page. Skipping...');
        this.tap(UIAQuery.AppleWatch.SKIP_PASSCODE_CREATION_BUTTON);
    }
};

/**
* Post-Scan function that sets up cellular for the watch during buddy flow.
*
* Expected starting state: At the Set Up Cellular page.
*
* @returns None.
*
* @throws If we don't transition past the Set Up Cellular page.
*/
appleWatch.setupCellular = function setupCellular() {
    var setupCellularWaiter = UIAWaiter.withPredicate(
        'ViewDidDisappear',
        'controllerClass == "COSAkashiChoiceViewController"'
    );
    UIALogger.logMessage('For now, this script will always skip cellular activation.');

    // Set Up Later was confirmed working in 14A195a
    // Skip This Step replaced Set Up Later in 14A200.
    // Both queries persist to maintain some backwards compatibility for other teams
    var skipQuery = UIAQuery.buttons().contains('Set Up Later')
        .orElse(UIAQuery.buttons().contains('Skip This Step'))
        .orElse(UIAQuery.buttons().contains('Continue'));

    // Wait then tap because it can take a few seconds for the
    // cellular page to show the skip button.  rdar://problem/34558387
    UIAUtilities.assert(
        this.waitUntilPresent(skipQuery, 120),
        'Skip Cellular Setup button did not appear'
    );
    this.tap(skipQuery);

    if (!setupCellularWaiter.wait()) {
        throw new UIAError('Set Up Cellular view is still visible.');
    }
};

/**
* Post-Scan function that enables or disables Watchkit app installation during buddy flow.
*
* Expected starting state: At the Watchkit app installation page.
*
*  @param {boolean} [installWatchKitApps] - Flag to indicate whether to install all watchkit apps or skip to later.
*
* @returns None.
*
* @throws If we don't transition past Watchkit app installation page.
*/
appleWatch.setupWatchkitSettings = function setupWatchkitSettings(installWatchKitApps) {
    var watchkitOptionsWaiter = UIAWaiter.waiter(
        'ViewDidDisappear', {
            predicate: 'controllerClass == "COSWatchKitAppsChoiceViewController"',
    });
    if (installWatchKitApps) {
        UIALogger.logMessage('At the installing apps page. Hitting Install All...');
        this.tap(appleWatch.Controls.INSTALLALL);
    } else {
        UIALogger.logMessage('At the installing apps page. Hitting Choose Later...');
        this.tap(UIAQuery.AppleWatch.SKIP_WATCHKIT_BUTTON);
    }

    if (!watchkitOptionsWaiter.wait(60)) {
        throw new UIAError('Watchkit Installation options view still visible!');
    }
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: File management                                                     */
/*                                                                             */
/*      Helper functions for file management/lock synchronization              */
/*                                                                             */
/*******************************************************************************/

/**
* Helper function that lets companion wait for a file path to be created
* (in this case by another script in parallel or the calling wrapper)
*
* This is currently only used during the manual pairing flow
*
*  @param {string} [filepath] - File path waiting to be created.
*  @param {integer} [timeoutInSeconds] - Seconds to wait for path creation before timing out.
*
* @returns None.
*
* @throws If we timeout.
*/
appleWatch.waitForFileToExist = function waitForFileToExist(filepath, timeoutInSeconds) {
    UIAUtilities.assert(filepath, 'Must specify filepath');

    if (!timeoutInSeconds) {
        timeoutInSeconds = 30;
    }

    var timeChecked = 0;
    while (timeChecked < timeoutInSeconds && !UIAFile.fileExists(filepath)) {
        UIATarget.localTarget().delay(1);
        timeChecked += 1;
    }

    if (!UIAFile.fileExists(filepath)) {
        throw new UIAError('Target file did not exist within timeout period');
    }

    return true;
};

/**
* Launches Watch and handles the splash page if present
* For <rdar://problem/27579499> Atlantic/Bahar with Genoa -> Daytona/Whitetail : Need to accommodate for 'Welcome to Apple Watch App' post ota update to Daytona
**/

appleWatch.launch = function launch() {
    this.__proto__.launch.apply(this);
    UIALogger.logMessage('Launch bridge and handle the splash page if present');
     if (this.exists(UIAQuery.navigationBars('COSSetupFinishedView'))) {
        if (this.waitUntilPresent(UIAQuery.buttons('GoToBridgeButton').orElse(appleWatch.Controls.OK)), 10) {
            this.tap(UIAQuery.buttons('GoToBridgeButton').orElse(appleWatch.Controls.OK));
        }
    }

    if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
        this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Cancel')));
    }
};

appleWatch.forceQuit = function forceQuit() {

    if (appleWatch.isActive()) {
        var quit_waiter = UIAWaiter.waiter('ApplicationStateChanged', {predicate: 'bundleID == "com.apple.Bridge" AND state == "Terminated"'});
        appleWatch.quit();
        quit_waiter.wait(10);
    }

    /*if (!quit_waiter.wait(30)) {
        UIALogger.logMessage('Bridge app is still not terminated');
        throw new UIAError('Bridge app is still not terminated');
    }*/
};

/**
 *   Function: OTAUpdate
 *       Check to see if there is an OTA update available.   If so it triggers download and install.
 *
 *   Returns: None
 *   @param {object}  options - OTA Update dictionary
 *   @param {string}  [options.passcodeOnCompanion=null] - Passcode on the phone required to accept T & C before watch OTA Update.
 *   @param {bool}    [options.scanOnlyForBadgeVerification=false] - Scan for update to verify badges on Watch Icon, General and Software Update screens.
 *   @param {number}  [options.badgeNumber=null] - the number to be shown on the icon
 *   @param {number}  [options.buildNumberToOTA=null] - the build number for the watch to update
 *   Throws:
 *       An exception if an update is not available
 **/
appleWatch.OTAUpdate = function OTAUpdate(options) {

    options = UIAUtilities.defaults(options, {
        passcodeOnCompanion: null,
        scanOnlyForBadgeVerification: false,
        badgeNumber: null,
        buildNumberToOTA: null,
    });

    var errorAlertEncountered = 0;
    var MAX_RETRIES = 5;
    var watchOSBuild;

    var alertHandlerOTAUpdate = function() {

        var app = target.activeApp();

        if (app.exists(UIAQuery.alerts('Could Not Connect to Apple Watch'))) {
            var alert = app.inspect(UIAQuery.alerts('Could Not Connect to Apple Watch'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                app.tapIfExists(appleWatch.Controls.OK_ALERT);
            }

            // Watch test suite has a sysdiagnose test that will run only if sysdiagnose is set to true in the variable set
            UIALogger.logTAResults({'sysdiagnose': true});

            throw new UIAError('Error connecting to Apple Watch during scanning for OTA update; Received "%0" Alert'.format(alert.label));
        }

        if (app.exists(UIAQuery.alerts('Unable to Verify Update'))) {
            var alert = app.inspect(UIAQuery.alerts('Unable to Verify Update'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                app.tapIfExists(appleWatch.Controls.CLOSE);
            }

            // Watch test suite has a sysdiagnose test that will run only if sysdiagnose is set to true in the variable set
            UIALogger.logTAResults({'sysdiagnose': true});

            throw new UIAError('Error Unable to verify update; Received "%0" Alert'.format(alert.label));
        }

        if (app.exists(UIAQuery.alerts('Software Update Failed'))) {
            var alert = app.inspect(UIAQuery.alerts('Software Update Failed'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                app.tapIfExists(appleWatch.Controls.CLOSE);
            }

            // Watch test suite has a sysdiagnose test that will run only if sysdiagnose is set to true in the variable set
            UIALogger.logTAResults({'sysdiagnose': true});

            throw new UIAError('Error Downloading the update to the watch; Received "%0" Alert'.format(alert.label));
        }

        if (app.exists(UIAQuery.alerts('Installation Paused'))) {
            var alert = app.inspect(UIAQuery.alerts('Installation Paused'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                throw new UIAError('Error installing the update to the watch; Received "%0" Alert'.format(alert.label));
            }
        }

        if (app.exists(UIAQuery.alerts('Unable to Check for Update'))) {
            var alert = app.inspect(UIAQuery.alerts('Unable to Check for Update'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                if (errorAlertEncountered < MAX_RETRIES) {
                    errorAlertEncountered++;
                    UIALogger.logMessage('Trying update again attempt %0'.format(errorAlertEncountered));
                    app.tapIfExists(appleWatch.Controls.TRY_AGAIN);
                    return true;
                }
            }

            // Watch test suite has a sysdiagnose test that will run only if sysdiagnose is set to true in the variable set
            UIALogger.logTAResults({'sysdiagnose': true});

            throw new UIAError('Error unable to scan for software update; Received "%0" Alert'.format(alert.label));
        }

        if (app.exists(UIAQuery.alerts('Sign In'))) {
            var alert = app.inspect(UIAQuery.alerts('Sign In'));
            if (alert && alert.label) {
                UIALogger.logMessage("Received '%0' Alert".format(alert.label));
                app.tapIfExists(appleWatch.Controls.CANCEL);
            }
        }
    };

    this.withAlertHandler(alertHandlerOTAUpdate, function() {

        // Quit watch is necessary for customer install automation (post installing OTA Profile)
        this.forceQuit();

        // Start - Use below combination instead of getToMyWatchRootView() to support rev-lock OTA updates.
        this.launch();

        if (this.exists(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON)){
            UIALogger.logMessage('Tapping My Watch');
            this.tap(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON);

            if (this.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons('My Watch')))) {
                UIALogger.logMessage('Tapping My Watch button on the navigation bar');
                this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('My Watch')));
            }
        }

        // Made changes per rdar://problem/25197057
        UIALogger.logMessage('Trying to trigger OTA Update');
        if (this.exists(appleWatch.Controls.GENERAL)) {
            UIALogger.logMessage('Navigating to General -> Software Update');

            // the cell can may move if something pops up on the menu, let defend against this
            if (this.waitUntilAbsent(appleWatch.Controls.GENERAL), 5) {
                this.scrollToVisible(appleWatch.Controls.GENERAL);
            }

            this.waitForViewToAppear('controllerClass == "COSGeneralSettingsController"', 10, function () {
                this.tap(appleWatch.Controls.GENERAL);
            });

            this.tap(appleWatch.Controls.SOFTWARE_UPDATE);
        }

        var timetoWaitforDownload = 300000; // 5 minutes
        var start = new Date();
        UIALogger.logMessage('Start time is %0'.format(start.toString()));

        var cur = new Date();
        UIALogger.logMessage('Current time is %0'.format(cur.toString()));

        // Allow 5 minutes timeout to scan for the update
        while (cur - start < timetoWaitforDownload && errorAlertEncountered <= MAX_RETRIES) {
            // Check for 'Checking for Update' text
            UIALogger.logMessage('Searching for Checking for Update text');
            if (this.waitUntilPresent(UIAQuery.contains('Checking for Update'), 1)) {
                UIALogger.logMessage('Still Checking for Update...');
            }

            if (this.waitUntilPresent(appleWatch.Controls.DOWNLOAD_AND_INSTALL, 1)) {
                UIALogger.logMessage('Searching for Download and Install');

                if (options.scanOnlyForBadgeVerification) {
                    this.verifyBadgeNumber(options.badgeNumber);
                }
                this.tap(appleWatch.Controls.DOWNLOAD_AND_INSTALL);

                // For <rdar://problem/26948208> [P1] - Passcode Types: Update with passcode on Companion and NOT on Gizmo
                // input passcode if needed, throw if passcodeOnCompanion was not provided in arguments
                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    if (options.passcodeOnCompanion) {
                        this.typeString(options.passcodeOnCompanion);
                    } else {
                        throw new UIAError('Watch OTA required passcode on phone but passcode was not provided in arguments');
                    }
                }
                // End of Changes for <rdar://problem/26948208>

                if (this.waitUntilPresent(appleWatch.Controls.AGREE, 5)) {
                    UIALogger.logMessage('Accepting EULA...');
                    this.tap(appleWatch.Controls.AGREE);
                }

                UIALogger.logMessage('Searching for Downloading to Watch...');
                if (!this.waitUntilPresent(appleWatch.Controls.DOWNLOADING_TO_WATCH, 30)) {
                    UIALogger.logMessage('Downloading to watch... not found');
                    throw new UIAError('Downloading to watch... not found');
                }

                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Download'});
                return;
            }

            UIALogger.logMessage('Searching for Downloading to Watch...');
            if (this.waitUntilPresent(appleWatch.Controls.DOWNLOADING_TO_WATCH, 1)) {
                UIALogger.logMessage('OTA Update is Downloading');
                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Download'});
                return;
            }

            UIALogger.logMessage('Searching for Preparing...');
            if (this.waitUntilPresent(appleWatch.Controls.PREPARING, 1)) {
                UIALogger.logMessage('OTA update is preparing');
                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Download'});
                return;
            }

            UIALogger.logMessage('Searching for Verifying...');
            if (this.waitUntilPresent(appleWatch.Controls.VERIFYING, 1)) {
                UIALogger.logMessage('OTA update is Verifying');
                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Install'});
                return;
            }

            UIALogger.logMessage('Searching for Installing...');
            if (this.waitUntilPresent(appleWatch.Controls.INSTALLING, 1)) {
                UIALogger.logMessage('OTA update is installing');
                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Installing'});
                return;
            }

            // Check if download is ready to install
            UIALogger.logMessage('Searching for Install');
            if (this.waitUntilPresent(appleWatch.Controls.INSTALL, 1)) {
                UIALogger.logMessage('Update asset is already downloaded, tap install');
                this.tap(appleWatch.Controls.INSTALL);

                if (this.waitUntilPresent(UIAQuery.contains('Enter Passcode'), 3)) {
                    if (options.passcodeOnCompanion) {
                        this.typeString(options.passcodeOnCompanion);
                    } else {
                        throw new UIAError('Watch OTA required passcode on phone but passcode was not provided in arguments');
                    }
                }

                if (this.waitUntilPresent(appleWatch.Controls.AGREE, 5)) {
                    UIALogger.logMessage('Accepting Terms and Conditions');
                    this.tap(appleWatch.Controls.AGREE);
                }

                UIALogger.logMessage('Searching for Verifying...');
                if (!this.waitUntilPresent(appleWatch.Controls.VERIFYING, 20)) {
                    UIALogger.logMessage('"Verifying..." control not found');
                    throw new UIAError('"Verifying..." control not found');
                }

                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                UIALogger.logTAResults({'OTAUpdateStatus': 'Install'});
                return;
            }

            UIALogger.logMessage('Searching for build number and UptoDate');
            if (this.waitUntilPresent(appleWatch.Controls.SOFTWARE_UPTODATE, 1)) {
                UIALogger.logMessage('Watch OS is up to date');
                try {
                    watchOSBuild = (this.inspect(UIAQuery.staticTexts().contains('Watch')) || this.inspect(UIAQuery.staticTexts().contains('watch')));
                    watchOSBuild = watchOSBuild.name.split("(")[1];
                    watchOSBuild = watchOSBuild.substring(0,watchOSBuild.lastIndexOf(')'));
                    UIALogger.logDebug ('watchOSBuild %0'.format(watchOSBuild));

                } catch (e) {
                    UIALogger.logDebug ('Exception trying to get the build number from Software Update screen: %0'.format(e));
                }
                //Pass info from appleWatch.OTAUpdate function in JS script to consecutive python tests OTA_wait about which path was used to start ota update and track progress of the update
                if (options.buildNumberToOTA != null) {
                    if (watchOSBuild == options.buildNumberToOTA) {
                        UIALogger.logMessage('Watch OS is up to date with build number %0'.format(options.buildNumberToOTA));
                        UIALogger.logTAResults({'OTAUpdateStatus': 'UpToDate %0'.format(watchOSBuild)});
                    } else {
                        UIALogger.logMessage('Companion failed to see update to build number %0'.format(options.buildNumberToOTA));
                        throw new UIAError('Companion failed to see update to build number %0'.format(options.buildNumberToOTA));
                    }
                }
                UIALogger.logTAResults({'OTAUpdateStatus': 'UpToDate %0'.format(watchOSBuild)});
                return;
            }
            cur = new Date();
            UIALogger.logMessage('Current time is %0'.format(cur.toString()));
        }
        UIALogger.logMessage('Unable to start OTA install');
        throw new UIAError('Exceeded max attempts to complete OTA update');
    });
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Useful functions that are not effectful on the app in any way          */
/*                                                                             */
/*******************************************************************************/

/**
* This function throws a UIAError as message and the title of any alerts on screen
* appended to it. This is suitable for generating errorIDs. Beware that this may
* leave an alert onscreen that will never be handled by the base alert handler.
*
*  @param{string} [message] - Base string for the error ID
*  @throws{UIAError} - Message argument plus the alert title if an alert was visible
*
*/
appleWatch._throwPairingError = function _throwPairingError(message) {
    UIALogger.logMessage('Pairing failed with "%0"'.format(message));
    var modifiedMessage = message;

    // Read on-screen alerts and add to error message
    this.handlingAlertsInline(UIAQuery.alerts(), function() {
        if (this.exists(UIAQuery.alerts())) {
            var alert = this.inspect(UIAQuery.query(UIAQuery.alerts()));
            if (alert === undefined) {
                UIALogger.logMessage("We detected an alert but it dissapeared before we could read it, this shouldn't have happened");
                throw new UIAError(message);
            }

            var alertTitle = alert['name'];
            if (alertTitle === undefined) {
                UIALogger.logMessage("We detected an alert but it doesn't have a name attribute");
                throw new UIAError('%0 (an unnamed alert appeared)'.format(message));
            }
            UIALogger.logMessage('%0 alert was detected on screen'.format(alertTitle));

            modifiedMessage = '%0 ("%1" alert appeared)'.format(
                message, alertTitle);
        }
    });

    throw new UIAError(modifiedMessage);
};


appleWatch.getConnectedAlertHandler = function getConnectedAlertHandler() {
    if (target.activeApp().exists(UIAQuery.alerts('Get Connected'))) {
        throw new UIAError('Cannot start pairing without connectivity');
    } else {
        return false;
    }
};

/**
 * Utility function to serialize metadata in the form of key-value pairs to log.
 */
appleWatch._logMetaData = function _logMetaData(key, value) {
    var dict = {};
    dict[key] = value;
    var json_serialization = JSON.stringify(dict);
    UIALogger.logDebug('MetaData: %0'.format(json_serialization));
};

/**
* Verify build number post OTA Update.
*
* Expected starting state: Bridge App.
* @param {object}  options - OTA update options dictionary
* @param {string} [options.buildNumber=null] - Build number to be verified post OTA Update.
*
* @returns None.
* @throws If unable to read Version from About screen.
*/
appleWatch.buildPostOTAUpdate = function buildPostOTAUpdate(options) {

    options = UIAUtilities.defaults(options, {
        buildNumber: null,
    });

    var watchOSBuild;
    var versionValue;

    this.getToMyWatchRootView();

    if (this.exists(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON)){
        UIALogger.logMessage('Tapping My Watch');
        this.tap(UIAQuery.AppleWatch.MY_WATCH_TAB_BUTTON);

        if (this.exists(UIAQuery.navigationBars().andThen(UIAQuery.buttons('My Watch')))) {
            UIALogger.logMessage('Tapping My Watch button on the navigation bar');
            this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('My Watch')));
        }
    }

    // Tapping General -> About
    UIALogger.logMessage('Trying to get Version from OTA Update');
    if (this.exists(appleWatch.Controls.GENERAL)) {
        UIALogger.logMessage('Navigating to General -> About');

        // the cell can may move if something pops up on the menu, let defend against this
        if (this.waitUntilAbsent(appleWatch.Controls.GENERAL), 5) {
            this.scrollToVisible(appleWatch.Controls.GENERAL);
        }

        this.waitForViewToAppear('controllerClass == "COSGeneralSettingsController"', 10, function () {
            this.tap(appleWatch.Controls.GENERAL);
        });

        if(this.exists(appleWatch.Controls.ABOUT)) {
            this.tap(appleWatch.Controls.ABOUT);
        }

        try {
            versionValue = this.inspect(appleWatch.Controls.VERSION).value;
            watchOSBuild = versionValue.split("(")[1];
            watchOSBuild = watchOSBuild.substring(0,watchOSBuild.lastIndexOf(')'));
            UIALogger.logDebug ('watchOSBuild %0'.format(watchOSBuild));
        } catch (e) {
            throw new UIAError('Unable to read Version from About Screen: %0'.format(e));
        }
    }

    if (options.buildNumber != null) {

        // Create regex with optional digit inserted after first 3 characters of build number
        var re = new RegExp(watchOSBuild.substr(0,3) + '\\d?' + watchOSBuild.substr(3, watchOSBuild.length-3));

        if (options.buildNumber == watchOSBuild || re.test(options.buildNumber)) {
            UIALogger.logMessage('Bridge shows correct build number post OTA Update: %0'.format(watchOSBuild));
            return;
        } else {
        UIALogger.logMessage('Bridge shows incorrect build number post OTA Update: %0'.format(watchOSBuild));
        throw new UIAError('Bridge shows incorrect build number post OTA Update');
    }}
    UIALogger.logMessage('Build Number in the options is null. Please specify the build number in the test arguments.');
    throw new UIAError('Build Number in the options is null. Please specify the build number in the test arguments.');
};

/**
 * Verify the badge number on Watch icon, Watch -> General, Watch -> General -> Software Update
 *
 * @param {number}      [badgeNumber] - the number to be shown on the icon
 *
 * @returns: None
 * @throws If unable to read badge number from any of Watch icon, Watch -> General, Watch -> General -> Software Update.
 */
appleWatch.verifyBadgeNumber = function verifyBadgeNumber(badgeNumber) {

    var bridgeTerminatedWaiter = UIAWaiter.withPredicate(
            'ApplicationStateChanged',
            'state = "Suspended" AND bundleID = "com.apple.Bridge"'
    );

    // Return to top level after scanning for update so that it helps with badge verification
    this.returnToTopLevel();
    target.clickMenu();

    if (!bridgeTerminatedWaiter.wait(30)) {
            UIALogger.logMessage('Bridge app is still not suspended');
            throw new UIAError('Bridge app is still not suspended');
    }

    UIALogger.logMessage('Bridge app is suspended, Checking badge on Watch icon');
    var valueOnIcon = target.activeApp().inspect(UIAQuery.icons().withPredicate('bundleID == "com.apple.Bridge"').onScreen('Main')).value;
    if (valueOnIcon && valueOnIcon.trim().length != 0) {
        UIALogger.logMessage('valueOnIcon is %0'.format(valueOnIcon));
        var numberOnIcon = parseInt(valueOnIcon.split(' ')[0]);
        UIALogger.logMessage('Badge Number on Watch icon is [%0]'.format(numberOnIcon));

        if (numberOnIcon != badgeNumber) {
            UIALogger.logMessage('Expected badge number [%0] but got [%1]'.format(badgeNumber, numberOnIcon));
        } else {
            UIALogger.logMessage('Watch icon shows expected badge number [%0]'.format(numberOnIcon));
        }
    }
    //Log a warning and continue with the OTA update , workaround for <rdar://problem/28414387> Badge not shown on Watch icon, Watch -> General, Watch -> General -> Software Update after SU scan
    //Created self-assigned radar to remove workaround <rdar://problem/28547224> Remove workaround for rdar://problem/28414387 from AppleWatch.js
    UIALogger.logWarning('No badge found on the watch icon, value is [%0]'.format(valueOnIcon));

    this.getToMyWatchRootView();
    UIALogger.logMessage('Checking badge on Watch -> General');

    if (this.exists(appleWatch.Controls.GENERAL)) {
        // the cell can may move if something pops up on the menu, let defend against this
        if (this.waitUntilAbsent(appleWatch.Controls.GENERAL), 5) {
            this.scrollToVisible(appleWatch.Controls.GENERAL);
        }

        var numberOnGeneral = appleWatch.inspect((UIAQuery.tableCells('General').children().last())).name;
        if (numberOnGeneral && numberOnGeneral.length !=0 ) {
            UIALogger.logMessage('numberOnGeneral is [%0]'.format(numberOnGeneral));
            if (numberOnGeneral != badgeNumber) {
                UIALogger.logMessage('Expected badge number [%0] but got [%1] '.format(badgeNumber, numberOnGeneral));
            }
            UIALogger.logMessage('Watch -> General shows expected badge number [%0]'.format(numberOnGeneral));
        } else {
            UIALogger.logWarning('No badge found on the Watch -> General, value is [%0]'.format(numberOnGeneral));
        }

        this.waitForViewToAppear('controllerClass == "COSGeneralSettingsController"', 10, function () {
            this.tap(appleWatch.Controls.GENERAL);
        });

        var numberOnSoftwareUpdate = appleWatch.inspect((UIAQuery.tableCells('Software Update').children().last())).name;
        if (numberOnSoftwareUpdate && numberOnSoftwareUpdate.length != 0) {
            UIALogger.logMessage('numberOnSoftwareUpdate is [%0]'.format(numberOnSoftwareUpdate));
            if (numberOnSoftwareUpdate != badgeNumber) {
                UIALogger.logMessage('Expected badge number [%0] but got [%1]'.format(badgeNumber, numberOnSoftwareUpdate));
            }
            UIALogger.logMessage('Watch -> General-> Software Update shows expected badge number [%0]'.format(numberOnSoftwareUpdate));
        } else {
            UIALogger.logWarning('No badge found on the Watch -> General -> Software Update, value is [%0]'.format(numberOnSoftwareUpdate));
        }
    }

    UIALogger.logMessage('Badge Number verified on Watch icon, Watch -> General, Watch -> General - Software Update screen.');
    // original function continues from tapping 'Download and Install', hence tap Software Update here to get to the proper flow.
    this.tapIfExists(appleWatch.Controls.SOFTWARE_UPDATE);
    // Wait until Download and Install button appears on the screen
    UIALogger.logMessage('Searching for Checking for Update text');
    if (this.waitUntilPresent(UIAQuery.contains('Checking for Update'), 1)) {
        UIALogger.logMessage('Still Checking for Update...');
    }

    this.waitUntilPresent(appleWatch.Controls.DOWNLOAD_AND_INSTALL, 1);
};

/**
* Sync Photos and Music to the gizmo
* Expected starting state: Bridge App.
* @returns None.
*
* @throws If unable to read Version from About screen.
*/
appleWatch.syncMedia = function syncMedia() {

    this.getToMyWatchRootView();

    // the cell can may move if something pops up on the menu, let defend against this
    if (this.waitUntilAbsent(appleWatch.Controls.GENERAL), 5) {
        this.scrollToVisible(appleWatch.Controls.GENERAL);
    }

    this.waitForViewToAppear('controllerClass == "COSGeneralSettingsController"', 30, function () {
        this.tap(appleWatch.Controls.GENERAL);
    });

    if (this.exists(appleWatch.Controls.APP_INSTALL)) {
        this.tap(appleWatch.Controls.APP_INSTALL);
    }

    if (!this.waitUntilPresent(appleWatch.Controls.AUTOMATIC_APP_INSTALL, 3)) {
        throw new UIError('Unable to find Automatic App Install toggle switch');
    }

    enabledInstall = this.inspect(appleWatch.Controls.AUTOMATIC_APP_INSTALL).value;
    if (enabledInstall == 1) {
        UIALogger.logMessage('Automatic App Install is already enabled');
    } else {
        this.tap(appleWatch.Controls.AUTOMATIC_APP_INSTALL);
    }

    // Navigating to top level
    this.returnToTopLevel();

    // Tapping Photos -> Photos Limit
    UIALogger.logMessage('Trying to update photos limit');
    UIALogger.logMessage('Navigating to Photos -> Photos Limit');

    // the cell can may move if something pops up on the menu, let defend against this
    if (this.waitUntilAbsent(appleWatch.Controls.PHOTOS), 5) {
        this.scrollToVisible(appleWatch.Controls.PHOTOS);
    }

    this.waitForViewToAppear('controllerClass == "NPTOBridgeSettingsController"', 10, function () {
        this.tap(appleWatch.Controls.PHOTOS);
    });

    if (!this.waitUntilPresent(appleWatch.Controls.PHOTOS_LIMIT, 3)) {
        throw new UIAError('Unable to find Photos Limit');
    }
    this.tap(appleWatch.Controls.PHOTOS_LIMIT);

    if (!this.waitUntilPresent(appleWatch.Controls.NUMBER_OF_PHOTOS, 3)) {
        throw new UIAError('Unable to find Number of Photos');
    }
    this.tap(appleWatch.Controls.NUMBER_OF_PHOTOS);

    if (this.waitUntilPresent(UIAQuery.BACK_NAV_BUTTON, 3)) {
        this.tap(UIAQuery.BACK_NAV_BUTTON);
    }

    if (this.waitUntilPresent(UIAQuery.navigationBars('Photos'), 3)) {
        if(!this.waitUntilPresent(appleWatch.Controls.SYNCED_ALBUM, 3)) {
            throw new UIAError('Unable to find Synced Album');
        }
        this.tap(appleWatch.Controls.SYNCED_ALBUM);

        if (!this.waitUntilPresent(appleWatch.Controls.CAMERA_ROLL_OR_ALL_PHOTOS, 3)) {
            throw new UIAError('Unable to find Camera Roll');
        }
        this.tap(appleWatch.Controls.CAMERA_ROLL_OR_ALL_PHOTOS);
    }
    this.returnToTopLevel();

    // Tapping Music -> Storage Limit
    UIALogger.logMessage('Trying to update music limit');
    // the cell can may move if something pops up on the menu, let defend against this
    if (this.waitUntilAbsent(appleWatch.Controls.MUSIC), 5) {
        this.scrollToVisible(appleWatch.Controls.MUSIC);
    }

    this.waitForViewToAppear('controllerClass == "NMBridgeSettingsController"', 10, function () {
        this.tap(appleWatch.Controls.MUSIC);
    });

    if (!this.waitUntilPresent(appleWatch.Controls.STORAGE_LIMIT, 3)) {
        throw new UIAError('Unable to find Storage Limit');
    }

    this.tap(appleWatch.Controls.STORAGE_LIMIT);

    if (!this.waitUntilPresent(appleWatch.Controls.STORAGE_LIMIT_BY, 3)) {
        throw new UIAError('Unable to find Storage Limit by');
    }

    this.tap(appleWatch.Controls.STORAGE_LIMIT_BY);

    if (!this.waitUntilPresent(appleWatch.Controls.STORAGE_LIMIT_NUMBER, 3)) {
        throw new UIAError('Unable to find storage limit number');
    }
    this.tap(appleWatch.Controls.STORAGE_LIMIT_NUMBER);

    if (this.waitUntilPresent(UIAQuery.BACK_NAV_BUTTON, 3)) {
        this.tap(UIAQuery.BACK_NAV_BUTTON);
    }

    if (this.waitUntilPresent(UIAQuery.navigationBars('Music'), 3)) {
        if (!this.waitUntilPresent(appleWatch.Controls.SYNCED_MUSIC, 3)) {
            throw new UIAError('Unable to find Synced Music');
        }
        this.tap(appleWatch.Controls.SYNCED_MUSIC);

        // Warning because Purchased Music May not necessarily be present.
        if (this.waitUntilPresent(appleWatch.Controls.PURCHASED_MUSIC, 3)) {
            this.tap(appleWatch.Controls.PURCHASED_MUSIC);
        } else {
            UIALogger.logWarning('Unable to find Purchased Music');
        }

    }
    this.returnToTopLevel();
};

/**
* Verify if OTA profile is installed on the watch via the phone
* @param {string} [options.profileName=null] - Name of the profile to be verified.
*
* @returns None.
*
* @throws If unable to verify the profile.
*/
appleWatch.verifyOTAProfile = function verifyOTAProfile(options) {

    options = UIAUtilities.defaults(options, {
        profileName: null,
    });

    this.forceQuit();
    this.getToMyWatchRootView();

    // Made changes per rdar://problem/25197057
    UIALogger.logMessage('Trying to verify if OTA Profile is installed on the watch');
    if (this.exists(appleWatch.Controls.GENERAL)) {

        // the cell can may move if something pops up on the menu, let defend against this
        if (this.waitUntilAbsent(appleWatch.Controls.GENERAL), 5) {
            this.scrollToVisible(appleWatch.Controls.GENERAL);
        }

        this.waitForViewToAppear('controllerClass == "COSGeneralSettingsController"', 10, function () {
            this.tap(appleWatch.Controls.GENERAL);
        });

        this.tapIfExists(appleWatch.Controls.PROFILE);
        var otaProfile = UIAQuery.query('UITableViewSectionElement').andThen(UIAQuery.query('CONFIGURATION PROFILE'));
        if (!this.waitUntilPresent(otaProfile, 60)) {
            throw new UIAError("OTA Profile is not installed on the watch");
        }

        UIALogger.logMessage("options.profileName is %0".format(options.profileName));

        if (options.profileName != null) {
            UIALogger.logMessage("Locating %0 Profile".format(options.profileName));
            if (!this.waitUntilPresent(UIAQuery.tableCells().withPredicate('name == "%0"'.format(options.profileName)), 5)) {
                throw new UIAError("%0 profile is not present".format(options.profileName));
            } else {
                UIALogger.logMessage('Profile %0 is installed on the watch'.format(options.profileName));
                return;
            }
        }
    }
};
