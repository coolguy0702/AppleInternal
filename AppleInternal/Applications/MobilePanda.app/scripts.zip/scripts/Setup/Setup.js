load('UIAApp.js');
load('Semaphore.js');
load('Phone.js');
load('Settings.js');
load('SpringBoard.js');
load('TopHatSpeaker');

if (typeof setup === 'undefined') {

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for common setup queries */
    UIAQuery.Setup = {
        /** 'Favorites' button within a TabBar */
        FAVORITES_TABBAR:           UIAQuery.tabBars().andThen(UIAQuery.buttons('Favorites')),

        /** 'Start Over' button */
        START_OVER:                 UIAQuery.buttons('Start Over'),

        /** 'NavigationBar' */
        NAV_BAR:                    UIAQuery.contains('NavigationBar'),

        /** 'Enter Password' navigate bar */
        ENTER_WIFI_PASSWORD:        UIAQuery.contains('Enter Password'),

        /** 'Join' button */
        JOIN:                       UIAQuery.buttons('Join'),

        /** 'Trust' button */
        TRUST_BUTTON:               UIAQuery.buttons('Trust'),

        /** 'Enable Location Services' cell */
        ENABLE_LOCATION_SERVICES:   UIAQuery.contains('Enable Location Services'),

        /** 'Disable Location Services' cell */
        DISABLE_LOCATION_SERVICES:  UIAQuery.contains('Disable Location Services'),

        /** 'OK' */
        OK:                         UIAQuery.buttons('OK'),

        /** 'Connect to Address' */
        CONNECT_TO_ADDRESS:         UIAQuery.buttons('Connect to Address...'),

        /** 'Connect' */
        CONNECT:                    UIAQuery.buttons('Connect'),

        /** 'Try Again' */
        TRY_AGAIN:                  UIAQuery.contains('Try Again'),

        /** 'TextField' */
        TEXT_FIELD:                 UIAQuery.beginsWith('TextField'),

        /** 'SecureTextField' */
        SECURE_TEXT_FIELD:          UIAQuery.contains('SecureTextField'),

        /** 'Don’t Have an Apple ID or Forgot It?' button */
        DONT_HAVE_APPLE_ID:         UIAQuery.contains('Don\u2019t have an Apple ID or forgot it?').orElse(UIAQuery.contains('Forgot password or don\u2019t have an Apple ID?')),

        /** 'Set Up Later in Settings' button */
        SET_UP_LATER_IN_SETTINGS:   UIAQuery.contains('Set Up Later in Settings'),

        /** 'Set Up as New [device]' cell */
        SET_UP_AS_NEW:              UIAQuery.staticTexts().contains('Set Up as New'),

        /** 'Restore from iCloud Backup' button */
        RESTORE_FROM_ICLOUD:        UIAQuery.staticTexts().contains('Restore from iCloud Backup'),

        /** 'Restore from iTunes Backup' cell */
        RESTORE_FROM_ITUNES:        UIAQuery.staticTexts().contains('Restore from iTunes Backup'),

        /** 'Move from Android' cell */
        MOVE_FROM_ANDROID:          UIAQuery.staticTexts().contains('Move Data from Android'),

        /** 'appleInternal: wifi info' image */
        ANDROID_MIGRATE_INTERNAL:   UIAQuery.images().bottommost(),

        /** Android transfer code **/
        ANDROID_TRANSFER_CODE:      UIAQuery.staticTexts().below(UIAQuery.query('Move from Android')),

        /** Passcode element **/
        PASSCODE_LENGTH:            UIAQuery.withPredicate('name MATCHES "Passcode"').isVisible(),

        /** 'Transfer Complete' static text */
        TRANSFER_COMPLETE:          UIAQuery.contains('Transfer Complete'),

        /** 'Sign In with Your Apple ID' cell */
        SIGN_IN_WITH_APPLE_ID:      UIAQuery.tableCells().andThen(UIAQuery.contains('Sign In with Your Apple ID')),

        /** 'Create a Free Apple ID' cell */
        CREATE_FREE_APPLE_ID:       UIAQuery.tableCells().andThen(UIAQuery.contains('Create a Free Apple ID')),

        /** 'Add Security Questions' cell */
        ADD_SECURITY_QUESTIONS:     UIAQuery.tableCells().andThen(UIAQuery.contains('Add Security Questions')),

        /** 'Not Now' cell */
        NOT_NOW_CELL:               UIAQuery.tableCells().andThen(UIAQuery.contains('Not Now')),

        /** 'Not Now' button */
        NOT_NOW_BUTTON:             UIAQuery.buttons('Not Now'),

        /** 'Next' button */
        NEXT:                       UIAQuery.buttons('Next'),

        /** 'Back' button */
        BACK:                       UIAQuery.buttons('Back'),

        /** 'Use iCloud' cell */
        USE_ICLOUD:                 UIAQuery.tableCells('Use iCloud'),

        /** 'Upgrade to iCloud Drive' cell */
        UPGRADE_ICLOUD_DRIVE:       UIAQuery.buttons('Upgrade to iCloud Drive'),

        /** 'Turn off iCloud Drive' button */
        TURN_OFF_ICLOUD_DRIVE:      UIAQuery.buttons('Turn off iCloud Drive'),

        /** 'Don’t Use iCloud' cell */
        DONT_USE_ICLOUD:            UIAQuery.tableCells('Don’t Use iCloud'),

        /** 'Customize Settings' cell */
        CUSTOMIZE_SETTINGS:         UIAQuery.query('Customize Settings'),

        /** 'Don’t Use Two-Factor Auth'  */
        DONT_USE_TWO_FACTOR:        UIAQuery.buttons('Don\'t use two-factor authentication'),

        /** 'Use Find My [Device]' cell */
        USE_FIND_MY:                UIAQuery.tableCells().andThen(UIAQuery.contains('Use Find My')),

        /** 'Don’t Use Find My' cell */
        DONT_USE_FIND_MY:           UIAQuery.tableCells().andThen(UIAQuery.contains('Don’t Use Find My')),

        /** 'Skip This Step' button */
        SKIP_THIS_STEP:             UIAQuery.buttons('Skip This Step'),

        /** 'Don't Use' alert button */
        DONT_USE:                   UIAQuery.buttons('Don’t Use'),

        /** 'Agree' button */
        AGREE:                      UIAQuery.buttons('Agree'),

        /** 'Set Up Touch ID Later' button */
        SKIP_TOUCH_ID:              UIAQuery.buttons('Set Up Touch ID Later'),

        /** 'Continue' button */
        CONTINUE:                   UIAQuery.buttons('Continue'),

        /** 'Continue Setting Up <device>' button */
        CONTINUE_SETTING_UP:        UIAQuery.buttons().withPredicate('name beginswith "Continue Setting Up"'),

        /** 'Don’t Use Passcode' button */
        // <rdar://problem/32654495> Remove code for old passcode flow
        SKIP_PASSCODE:              UIAQuery.buttons('Don’t Use Passcode').orElse(UIAQuery.buttons('Don’t Add Passcode')),

        /** 'Passcode Options' button */
        PASSCODE_OPTIONS:           UIAQuery.buttons('Passcode Options'),

        /** 'Custom Alphanumeric Code' to enroll into CDP'  */
        ALPHA_NUMERIC_PASSCODE:     UIAQuery.buttons('Custom Alphanumeric Code'),

        /** '4-Digit Numeric Code' to enroll into CDP'  */
        FOUR_DIGIT_NUMERIC_PASSCODE:        UIAQuery.buttons('4-Digit Numeric Code'),

        /** '6-Digit Numeric Code' to enroll into CDP'  */
        SIX_DIGIT_NUMERIC_PASSCODE:        UIAQuery.buttons('6-Digit Numeric Code'),

        /** 'Use Code' button */
        USE_CODE:                   UIAQuery.buttons('Use Code').orElse(UIAQuery.buttons('Use Anyway')),

        /** 'Change' button */
        CHANGE:                     UIAQuery.buttons('Change'),

        /** 'Set Up iCloud Keychain' cell */
        SET_UP_ICLOUD_KEYCHAIN:     UIAQuery.tableCells().andThen(UIAQuery.contains('Set Up iCloud Keychain')),

        /** 'Set Up Later' cell */
        SET_UP_LATER:               UIAQuery.tableCells().andThen(UIAQuery.contains('Set Up Later')),

        /** 'Set Up Later' button */
        SET_UP_LATER_BUTTON:        UIAQuery.buttons().andThen(UIAQuery.contains('Set Up Later')),

        /** 'Use Siri' cell */
        USE_SIRI:                   UIAQuery.tableCells('Use Siri').orElse(UIAQuery.buttons('Set Up Siri')).orElse(UIAQuery.buttons('Turn On Siri')),

        /** 'Set up "Hey Siri" later' button */
        SET_UP_HEY_SIRI_LATER:      UIAQuery.buttons().withPredicate('name contains[c] "Siri" and name contains[c] "Later"'),

        /** 'Share with App Developers' cell */
        SHARE_WITH_DEVS:            UIAQuery.query('Share with App Developers'),

        /** 'Don't Share' with App Developers cell */
        DONT_SHARE:                 UIAQuery.query('Don\'t Share').orElse(UIAQuery.query('Donʼt Share')),

        /** 'Choose a View' button */
        CHOOSE_A_VIEW:              UIAQuery.buttons('Choose a View'),

        /** 'Enter Card Details Manually' cell */
        ADD_NEW_CREDIT_CARD:        UIAQuery.buttons('Enter Card Details Manually'),

        /** 'Skip Apple Pay' button */
        SKIP_APPLE_PAY:             UIAQuery.buttons('Set Up Later in Wallet'),

        /** 'Standard' button */
        STANDARD:                   UIAQuery.buttons('Standard'),

        /** 'Zoomed' button */
        ZOOMED:                     UIAQuery.buttons('Zoomed'),

        /** 'Get Started' button */
        GET_STARTED:                UIAQuery.buttons('Get Started'),

        /** 'Cancel' button */
        CANCEL:                     UIAQuery.buttons('Cancel'),

        /** 'Activate' static text */
        ACTIVATION_LOCKED:          UIAQuery.query('Activation Lock'),

        /** 'Activation Error' static text */
        ACTIVATION_ERROR:           UIAQuery.staticTexts().andThen(UIAQuery.contains('Activation Error')),

        /** 'Verification Failed' static text */
        VERIFICATION_FAILED:        UIAQuery.query('Verification Failed'),

        /** 'currently linked' element */
        CURRENTLY_LINKED:           UIAQuery.contains('linked'),

        /** 'Apple ID Security' element */
        APPLE_ID_SECURITY:          UIAQuery.contains('Apple ID Security'),

        /** 'Don’t Upgrade' button on Apple ID Security Page */
        DONT_UPGRADE:               UIAQuery.buttons('Don\'t Upgrade'),

        /** 'Other Options' button on Apple ID Security Page */
        OTHER_OPTIONS:              UIAQuery.buttons('Other Options'),

        /** 'Apple ID Two-Factor Security' static text */
        APPLE_ID_TWO_FACTOR_AUTH:   UIAQuery.staticTexts().andThen(UIAQuery.contains('Two-Factor Authentication')),

        /** 'Forgot Apple ID or Password' static text */
        FORGOT_APPLE_ID:            UIAQuery.staticTexts().andThen(UIAQuery.contains('Forgot Apple ID or Password')),

        /** 'Proximity Account' static text */
        PROXIMITY_ACCOUNT:          UIAQuery.staticTexts().andThen(UIAQuery.contains('BuddyProximityCloud')),

        /** 'Use Passcode' button */
        USE_PASSCODE:               UIAQuery.buttons('Use Passcode'),

        /** 'Create Different Code' button */
        CREATE_DIFFERENT_CODE:      UIAQuery.buttons('Create Different Code'),

        /** 'Use iCloud Security Code' button */
        USE_ICSC:                   UIAQuery.tableCells('Use iCloud Security Code'),

        /** 'Advanced Options' button */
        ADVANCED_OPTIONS:           UIAQuery.buttons('Advanced Options'),

        /** 'Use a Complex Security Code' */
        COMPLEX_SECURITY_CODE:      UIAQuery.tableCells('Use a Complex Security Code'),

        /** 'Get a Random Security Code' */
        RANDOM_SECURITY_CODE:       UIAQuery.tableCells('Get a Random Security Code'),

        /** 'Don’t Create Security Code' */
        DONT_CREATE_SECURITY_CODE:  UIAQuery.tableCells('Don\u2019t Create Security Code'),

        /** 'Skip Code' button */
        SKIP_CODE:                  UIAQuery.buttons('Skip Code'),

        /** 'Don’t Use iCloud' cell */
        DONT_USE_ICLOUD_KEYCHAIN:   UIAQuery.buttons('Don’t use iCloud Keychain'),

        /** 'Don’t Restore Passwords' cell */
        DONT_RESTORE_PASSWORDS:     UIAQuery.query('Don’t Restore Passwords'),

        /** Apply enterprise configuration */
        APPLY_CONFIGURATION:        UIAQuery.staticTexts('Apply configuration'),

        /** Skip enterprise configuration */
        SKIP_CONFIGURATION:         UIAQuery.staticTexts('Skip configuration'),

        /** Query for identifying that alternate Apple ID sign-in page */
        ALTERNATE_APPLE_ID:         UIAQuery.contains('different Apple ID'),

        /** 'Terms and Conditions' */
        TERMS_AND_CONDITIONS:       UIAQuery.contains('Terms and Conditions'),

        /** 'Device Ready' */
        DEVICE_READY:               UIAQuery.staticTexts('Device Ready'),

        /** 'iPhone/iPad/ect Activated' */
        DEVICE_ACTIVATED:           UIAQuery.staticTexts().contains(' Activated').beginsWith('i'),

        /** 'Device Unknown' */
        DEVICE_UNKNOWN:             UIAQuery.staticTexts('Device Unknown'),

        /** 'SIM Required' */
        SIM_REQUIRED:               UIAQuery.staticTexts('SIM Required'),

        /** Skip */
        SKIP:                       UIAQuery.buttons('Skip'),

        /** Light home button choice */
        LIGHT_HOME_BUTTON:          UIAQuery.buttons('Light'),

        /** Medium home button choice */
        MEDIUM_HOME_BUTTON:         UIAQuery.buttons('Medium'),

        /** Strong home button choice */
        STRONG_HOME_BUTTON:         UIAQuery.buttons('Strong'),

        /** Activation Page Query. */
        ACTIVATION_PAGE:            UIAQuery.beginsWith('Activate'),

        /** Shared iPad Create Password Query. */
        SHAREDIPAD_CREATE_PASSCODE:    UIAQuery.beginsWith('Create'),

        /** Shared iPad Change Password Query. */
        SHAREDIPAD_CHANGING_PASSCODE:    UIAQuery.beginsWith('Changing'),

        /** 'Send to Apple' button */
        SEND_TO_APPLE:              UIAQuery.buttons('Send to Apple'),

        /** 'Send to Apple' button */
        SHARE_WITH_APPLE:           UIAQuery.buttons('Share with Apple'),

        /** "Don't Send" button */
        DONT_SEND:                  UIAQuery.buttons("Donʼt Send"),

        /** Set Up Manually button */
        SET_UP_MANUALLY:            UIAQuery.buttons('Set Up Manually'),

        /** Customize Home button later in Settings */
        CUSTOMIZE_HOME_BUTTON_LATER:  UIAQuery.buttons('Customize Later in Settings').orElse(UIAQuery.buttons('Customise Later in Settings')),

        /** 'code has been sent to your' (other device) */
        TFA_OTHER_DEVICE_PAGE:          UIAQuery.staticTexts().withPredicate("name contains[c] 'code has been sent to your'").orElse(UIAQuery.staticTexts().withPredicate("name contains[c] 'Enter the code sent to your'")),

        /** 'verification code' button */
        VERIFICATION_CODE_BUTTON:       UIAQuery.buttons().withPredicate("name contains[c] 'verification code'"),
        
        /** Device-To-Device Source 'Done' button */
        D2D_DONE:            UIAQuery.buttons('DONE'),

        /** Device-To-Device Target 'Start Transfer' button */
        D2D_START:            UIAQuery.buttons('Start Transfer').orElse(UIAQuery.buttons('Continue')),

        /** Device-To-Device Target 'Other options' button */
        D2D_OTHER:            UIAQuery.buttons('Other Options'),

        /** Alerts */
        Alerts:                     {
            /** '[device] is Not Set Up' */
            NOT_SET_UP:                     UIAQuery.contains('Not Set Up'),

            /** 'Disable Location Services' alert */
            DISABLE_LOCATION_SERVICES:      UIAQuery.contains('Disable Location Services?'),

            /** 'Terms and Conditions' alert */
            TERMS_AND_CONDITIONS:           UIAQuery.contains('Terms and Conditions'),

            /** 'Set Up Touch ID Later?' alert */
            TOUCH_ID:                       UIAQuery.contains('Are you sure you don’t want to use Touch ID?').orElse(UIAQuery.contains('Set Up Touch ID Later?')),

            /** 'Are you sure you don’t want to use a Passcode?' alert */
            // <rdar://problem/32654495> Remove code for old passcode flow
            SKIP_PASSCODE:                  UIAQuery.contains('Are you sure you don\u2019t want to use a Passcode?').orElse(UIAQuery.contains('Using a Passcode is Highly Recommended')),

            /** 'Are You Sure You Want to Use This Code?' alert */
            USE_CODE:                       UIAQuery.withPredicate('label CONTAINS[c] "Are You Sure You Want to Use This Code?" OR label CONTAINS[c] "This Passcode Can Be Easily Guessed"'),

            /** 'Are you sure you don’t want to use iCloud?' alert */
            DONT_USE_ICLOUD:                UIAQuery.contains('Are you sure you don’t want to use iCloud?'),

            /** 'Are you sure you don’t want to use an Apple ID?' alert */
            DONT_USE_APPLE_ID:              UIAQuery.contains('Are you sure you don’t want to use an Apple ID?'),

            /** 'Are you sure?' alert appears when skipping signing into iCloud in the Buddy upgrade flow */
            ARE_YOU_SURE:                   UIAQuery.alerts('Are you sure?'),

            /** 'Are you sure you don’t want to upgrade to iCloud Drive?'' */
            DONT_USE_ICLOUD_DRIVE:          UIAQuery.contains('Are you sure you don’t want to upgrade to iCloud Drive?'),

            /** 'Caneling Hey Siri' alert */
            HEY_SIRI:                       UIAQuery.contains('Canceling Hey Siri'),

            /** 'Setting Language' alert */
            SETTING_LANGUAGE:               UIAQuery.contains('Setting Language'),

            /** 'Use iPhone/iPad Passcode as iCloud Security Code?' alert */
            ICLOUD_SECURITY_CODE:           UIAQuery.contains('Passcode as iCloud Security Code?'),

            /** 'Don’t Create Security Code?' alert */
            DONT_CREATE_SECURITY_CODE:      UIAQuery.contains('Don\u2019t Create Security Code?'),

            /** 'wifi info' password */
            WIFI_INFO:                      UIAQuery.contains('WiFi Info'),

            /** 'Connect to Address' alert */
            CONNECT_TO_ADDRESS:             UIAQuery.contains('Connect to Address'),

            /** unable to migrate alert */
            UNABLE_TO_MIGRATE:              UIAQuery.contains('Unable to migrate'),

            /** 'Couldn't communicate with a helper application' alert */
            NO_COMMUNICATION:               UIAQuery.contains("Couldn't communicate with a helper application"),

            /** Request for HSA2 code */
            VERIFICATION_CODE:              UIAQuery.contains('Verification Code'),

            /** 'Don’t Restore Passwords?' alert */
            DONT_RESTORE_PASSWORDS:         UIAQuery.contains('Don’t Restore Passwords?'),

            /** 'Apple ID Security' alert */
            APPLE_ID_SECURITY:              UIAQuery.alerts('Apple ID Security'),

            /** 'Restore from iPhone Backup' alert */
            DONT_RESTORE_SETTINGS:          UIAQuery.contains('Restore from iPhone Backup'),

            /** "Didn't get a code?" alert */
            DIDNT_GET_CODE_ALERT:           UIAQuery.alerts().andThen(UIAQuery.contains("Didn't get a code?")),

        },

    };

    /**
     * Constants for possible passcode regex patterns.
     */

    PasscodePatterns = {

        /** Six Digit Passcode **/
        SIX_DIGITS:        /^\d{6}$/,

        /** Four Digit Passcode **/
        FOUR_DIGITS:       /^\d{4}$/,
    };

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: UI State Constants                                                  */
    /*                                                                             */
    /*      A dictionary of strings describing the possible UI states of the app   */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for possible UI state names specific to setup */
    UIStateDescription.Setup = {
        /** Language */
        LANGUAGE:                   'language',

        /** Locale */
        LOCALE:                     'locale',

        /** Express Language Setup */
        EXPRESS_LANGUAGE_SETUP:     'express language set up',

        /** Preferred language Order */
        PREFERRED_LANGUAGE_ORDER:   'preferred language order',

        /** Wi-Fi network */
        WIFI_NETWORK:               'Wi-Fi network',

        /** Wi-Fi other network */
        WIFI_OTHER_NETWORK:         'Wi-Fi network (other)',

        /** Wi-Fi security */
        WIFI_SECURITY:              'Wi-Fi security',

        /** Pearl Splash */
        PEARL_SPLASH:               'Pearl Splash',

        /** Enter Password */
        ENTER_PASSWORD:             'password entry',

        /** Location Services */
        LOCATION_SERVICES:          'location services',

        /** Set Up Device */
        DEVICE_RESTORE_CHOICE:      'device restore',

        /** State for choosing a backup version */
        RESTORE_FROM_BACKUP:        'restore from backup',

        /** Backup restore in process */
        RESTORE_IN_PROGRESS:        'restore in progress',

        /** Buddy Restore Finished */
        RESTORE_FINISHED:           'restore finished',

        /** Buddy Restore Finished */
        RESTORE_FINISHED:           'restore finished',

        /** Restore or Activate  from iTunes */
        RESTORE_FROM_ITUNES:        'restore / activate from iTunes', // rdar://problem/20887494

        /** Apple ID choice */
        APPLE_ID_CHOICE:            'AppleID (choice)',

        /** Buddy Proximity Setup */
        BUDDY_PROXIMITY_SETUP:      'Buddy Proximity Setup',

        /** Finish setting up iCloud */
        UPGRADE_ICLOUD:             'iCloud (upgrade signin)',

        /** New Apple ID Sign In */
        APPLE_ID_SIGN_IN:           'AppleID sign in',

        /** Alternate Apple ID sign-in */
        ALTERNATE_APPLE_ID:         'alternate apple id',

        /** Move data from android device */
        MOVE_FROM_ANDROID:          'android migration',

        /** Apple ID Security */
        APPLE_ID_SECURITY:          'Apple ID (security)',

        /** Apple ID Security */
        APPLE_ID_TWO_FACTOR_AUTH:   'Two-Factor',

        /** Apple ID Security */
        FORGOT_APPLE_ID:            'forgot Apple ID or password',

        /** Apple ID Spinner page */
        APPLE_ID_SPINNER:           'Apple ID (spinner)',

        /** Proximity Accounts */
        PROXIMITY_ACCOUNT:          'Proximity account sign in',

        /** Apple ID FaceTime Registration Page */
        APPLE_ID_FACETIME:          'Facetime (registration)',

        /** iCloud */
        ICLOUD:                     'AppleID ',

        /** iCloud Drive */
        ICLOUD_DRIVE:               'AppleID (iCloud drive)',

        /** Welcome Page */
        WELCOME:                    'Welcome',

        /** Find My [Device] */
        UPGRADE_FIND_MY:            'Find My iPhone (upgrade)',

        /** AppleID Find My Phone Page */
        FIND_MY:                    'Find My iPhone',

        /** iCloud Keychain */
        ICLOUD_KEYCHAIN:            'keychain',

        /** iCloud Security Code */
        CREATE_ICLOUD_SECURITY_CODE: 'keychain (security code)',

        /** Advanced Security Code Options */
        ADVANCED_SECURITY_CODE:     'keychain (advanced security code)',

        /** Keychain Phone Number */
        KEYCHAIN_PHONE_NUMBER:      'keychain (phone number)',

        /** Offline Terms and Conditions */
        OFFLINE_TERMS_CONDITIONS:   'offline terms and conditions',

        /** Combined iCloud and device Terms and Conditions */
        COMBINED_TERMS_CONDITIONS:  'combined terms and conditions',

        /** Touch ID */
        TOUCH_ID:                   'Touch ID',

        /** Face ID */
        FACE_ID:                     "Face ID",

        /** Create a Passcode */
        PASSCODE:                   'passcode creation',

        /** Apple Pay */
        APPLE_PAY_DESC:             'Apple Pay (registration)',

        /** Apple Pay */
        APPLE_PAY:                  'Apple Pay',

        /** Hey Siri */
        SIRI:                       'Siri',

        /** App Analytics */
        APP_ANALYTICS:              'application analytics',

        /** Display Zoom */
        ZOOM:                       'zoom',

        /** Display Zoom */
        DISPLAY_ZOOM:               'zoom (display zoom)',

        /** Activation */
        ACTIVATE:                   'activate',

        /** Buddy Finished */
        FINISHED:                   'setup complete',

        /** Device Ready (not really "ready" but that's what the label says) */
        DEVICE_READY:               'device ready',

        /** iPhone/iPad/ect Activated (not really "activated" but that's what the label says) */
        DEVICE_ACTIVATED:           'device activated',

        /** Device Unknown */
        DEVICE_UNKNOWN:             'device unknown',

        /** Sim Require */
        SIM_REQUIRED:               'sim card required',

        /** Buddy Update Finished */
        UPDATE_FINISHED:            'update complete',

        /** Verification Failed */
        VERIFICATION_FAILED:        'verification failed',

        /** Enterprise configuration disclosure */
        ENT_CONFIG_DISCLOSURE:      'enterprise configuration (disclosure)',

        /** Enterprise configuration login */
        ENT_CONFIG_LOGIN:           'enterprise configuration (login)',

        /** Enterprise configuration installation */
        ENT_CONFIG_INSTALL:         'enterprise configuration (installation)',

        /** Cloud Configuration Retrieval */
        CLOUD_CONFIG_RETRIEVAL:   'Retrieving configuration',

        /** Could Not Activate ... */
        ACTIVATION_FAILURE:         'activation failure',

        /** iPhone/iPad activation locked */
        ACTIVATION_LOCKED_PAGE:     'activation locked',

        /** Slide to Setup */
        SLIDE_TO_SETUP:             'slide to setup',

        /** Profile Picture */
        PROFILE_PICTURE_SETUP:      'profile picture setup',

        /** Profile Picture Intro */
        PROFILE_PICTURE_INTRO:      'profile picture intro',

        /** Profile Picture type selection */
        PROFILE_PICTURE_SELECTION:  'profile picture type selection',

        /** Monogram Customization */
        MONOGRAM_CUSTOMIZATION:     'monogram customization',

        /** Profile Picture ready */
        PROFILE_PICTURE_READY:      'profile picture ready',

        /** True Tone Display */
        TRUE_TONE_DISPLAY:          'true tone display',

        /** Meet the New Home Button */
        NEW_HOME_BUTTON_INTRO:      'new home button',

        /** Customize the home button */
        CUSTOMIZE_HOME_BUTTON:      'customize home button',

        /** Diagnostics ("Help Apple improve its products...") */
        BUDDY_DIAGNOSTICS:          'buddy diagnostics',

        /** Developer iPhone Analytics */
        BUDDY_SEED_DIAGNOSTICS:     'buddy seed diagnostics',

        /** SpringBoard (complete) */
        DONE:                       'SpringBoard',

        /** iMessage & FaceTime setup */
        IMESSAGE_FACETIME:          'iMessage & FaceTime',

        /** Activate iPhone setup */
        ACTIVATE_IPHONE:            'Activate iPhone',

        /** Activate iPad setup */
        ACTIVATE_IPAD:              'Activate iPad',

        /** Inline software update */
        INLINE_SOFTWARE_UPDATE:     'inline software update',

        /** Apple Watch migration */
        APPLE_WATCH_MIGRATION:      'apple watch migration',

        /** Cover Sheet On-Boarding */
        COVER_SHEET_ON_BOARDING:    'cover sheet on-boarding',

        /** Multitasking On-Boarding */
        MULTITASKING_ON_BOARDING:   'multitasking on-boarding',

        /** Dock On-Boarding */
        DOCK_ON_BOARDING:           'dock on-boarding',

        /** Go Home On-Boarding */
        GO_HOME_ON_BOARDING:        'go home on-boarding',

        /** Apple Pay On-Boarding */
        APPLE_PAY_ON_BOARDING:      'apple pay on-boarding',

        /** Siri On-Boarding */
        SIRI_ON_BOARDING:           'siri on-boarding',

        /** App Switcher On-Boarding */
        APP_SWITCHER_ON_BOARDING:   'app switcher on-boarding',

        /** Control Center On-Boarding */
        CONTROL_CENTER_ON_BOARDING: 'control center on-boarding',

        /** Privacy Splash */
        PRIVACY_SPLASH:             'privacy splash',

        /** Shared iPad Create Passcode */
        SHAREDIPAD_CREATE_PASSCODE: 'shared ipad create passcode',

        /** Shared iPad Changing Passcode */
        SHAREDIPAD_CHANGING_PASSCODE: 'shared ipad changing passcode in progress',

        /** Auto Update Setting */
        AUTO_UPDATE: 'auto update',

        /** Screen Time Setting */
        SCREEN_TIME: 'screen time',

        /** Set Up Cellular */
        SET_UP_CELLULAR: 'set up cellular',

        /** Set Cellular Choice */
        SET_CELLULAR_CHOICE: 'set cellular choice',

        /** Cellular Plan Labels */
        CELLULAR_PLAN_LABELS: 'cellular plan labels',

        /** Cellular Plan iMessage Options */
        CELLULAR_PLAN_IMESSAGE: 'cellular plan iMessage',
       
        /** D2D Target Migration Start */
        D2D_TARGET_MIGRATION_CHOICE: 'd2d target migration start',

        /** D2D Target Migration Preparation */
        D2D_TARGET_PREP: 'd2d target migration preparation',

        /** D2D Source Migration Finished */
        D2D_SOURCE_MIGRATION_FINISHED: 'd2d source migration finished',

        /** D2D Target Migration Progress */
        D2D_TARGET_PROGRESS: 'd2d target migration progress'
    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/


    /** Constants for the name of restoreRoutes */
    RestoreRoute = {
        /** 'new' */
        NEW:                'new',
        /** 'icloud' */
        ICLOUD:             'icloud',
        /** 'itunes' */
        ITUNES:             'itunes',
        /** 'android' */
        ANDROID:            'android',
    }

    /** Constants that are used throughout the Setup library */
    SetupConstants = {}

    /** Constants for the names of the profile picture selection options */
    SetupConstants.ProfilePictureSelection = {
        /** use a monogram */
        MONOGRAM:           'monogram',

        /** create an avatar */
        AVATAR:             'avatar',

        /** use a photo */
        PHOTO:              'photo',
    }

    /** Map from home button options to queries */
    SetupConstants.HomeButtonChoiceMap = {
        /** light home button */
        'light':            UIAQuery.Setup.LIGHT_HOME_BUTTON,

        /** medium home button */
        'medium':           UIAQuery.Setup.MEDIUM_HOME_BUTTON,

        /** strong home button */
        'strong':           UIAQuery.Setup.STRONG_HOME_BUTTON,
    }

    /** Map Device Migration Options */
    SetupConstants.d2dChoiceMap = {
        /** Start D2D migration */
        'start':            UIAQuery.Setup.D2D_START,

        /** Choose another setup path */
        'other':           UIAQuery.Setup.D2D_OTHER,
    }

    /** Constants for cellular plan options */
    SetupConstants.CellularChoiceMap = {
        'primaryDefault': UIAQuery.staticTexts().andThen(UIAQuery.contains('Primary')),
        'secondaryDefault': UIAQuery.staticTexts().andThen(UIAQuery.contains('Secondary')),
    }

    /**
        @namespace
        @augments UIAApp
    */
    var setup = target.appWithBundleID('com.apple.purplebuddy');

    /**
     * A mapping between navigation bar titles / controller name to UI state used by currentUIState below
     *
     * (only use this approach for titles that have 1-1 mapping to state)
     */
    setup._navigationBarToUIStateMap = {
        /** Internationalization Setup */
        'BuddyLanguage': UIStateDescription.Setup.LANGUAGE,
        'BuddyLocale': UIStateDescription.Setup.LOCALE,
        'BuddyMultilingualExpressView': UIStateDescription.Setup.EXPRESS_LANGUAGE_SETUP,
        'BuddyPreferredLanguageOrderSelector': UIStateDescription.Setup.PREFERRED_LANGUAGE_ORDER,

        /** Network Setup */
        'WFBuddyView': UIStateDescription.Setup.WIFI_NETWORK,
        'APNetworks': UIStateDescription.Setup.WIFI_NETWORK,
        'APOtherNetwork': UIStateDescription.Setup.WIFI_OTHER_NETWORK,
        'Other Network': UIStateDescription.Setup.WIFI_OTHER_NETWORK,
        'WFOtherNetworkView': UIStateDescription.Setup.WIFI_OTHER_NETWORK,
        'Security': UIStateDescription.Setup.WIFI_SECURITY,
        'Enter Password': UIStateDescription.Setup.ENTER_PASSWORD,

        /** Pearl Setup */
        'PearlSplash': UIStateDescription.Setup.PEARL_SPLASH,

        /** Location Services Setup */
        'BuddyLocationServices': UIStateDescription.Setup.LOCATION_SERVICES,

        /** Proximity Setup */
        'BuddyProximityPairing': UIStateDescription.Setup.BUDDY_PROXIMITY_PIN_DISPLAY,

        /** Device To Device Migration */
        'BuddyDeviceMigration': UIStateDescription.Setup.D2D_TARGET_MIGRATION_CHOICE,
        'BuddyMigrationPreparation': UIStateDescription.Setup.D2D_TARGET_PREP,
        'BuddyMigrationProgress': UIStateDescription.Setup.D2D_TARGET_PROGRESS,

        /** Device Restore */
        'DeviceRestoreChoice': UIStateDescription.Setup.DEVICE_RESTORE_CHOICE,
        'RestoreFromBackup': UIStateDescription.Setup.RESTORE_FROM_BACKUP,
        'BackupRestoreProgress': UIStateDescription.Setup.RESTORE_IN_PROGRESS,
        'BuddyRestoreFinished': UIStateDescription.Setup.RESTORE_FINISHED,
        'RestoreFromiTunes': UIStateDescription.Setup.RESTORE_FROM_ITUNES,
        'ActivateUsingiTunes': UIStateDescription.Setup.RESTORE_FROM_ITUNES,

        /** Apple ID */
        'BuddyAppleIDChoice': UIStateDescription.Setup.APPLE_ID_CHOICE,
        'BuddyProximitySetup': UIStateDescription.Setup.BUDDY_PROXIMITY_SETUP,

        /** Welcome */
        'BuddyExpressWelcome': UIStateDescription.Setup.WELCOME,

        /** iTunes */
        'iTunes Login': UIStateDescription.Setup.ITUNES_SIGN_IN,
        'WLWelcomeView': UIStateDescription.Setup.MOVE_FROM_ANDROID,

        /** Security */
        'AppleIDSecurity': UIStateDescription.Setup.APPLE_ID_SECURITY,
        'Two-Factor': UIStateDescription.Setup.APPLE_ID_TWO_FACTOR_AUTH,
        'BuddyAppleIDSpinnerPage': UIStateDescription.Setup.APPLE_ID_SPINNER,
        'BuddyAppleIDFacetimeRegistrationPage': UIStateDescription.Setup.APPLE_ID_FACETIME,
        'BuddyProximityCloud': UIStateDescription.Setup.PROXIMITY_ACCOUNT,


        /** Cloud Services */
        'BuddyUpgradeiCloudSignInPage': UIStateDescription.Setup.UPGRADE_ICLOUD,
        'BuddyAppleIDCastlePage': UIStateDescription.Setup.ICLOUD,
        'BuddyAppleIDiCloudDrivePage': UIStateDescription.Setup.ICLOUD_DRIVE,
        'BuddyAppleIDFindMyPhoneUpgradePage': UIStateDescription.Setup.UPGRADE_FIND_MY,
        'BuddyAppleIDFindMyPhonePage': UIStateDescription.Setup.FIND_MY,
        'BuddyAppleIDKeychainSyncPage': UIStateDescription.Setup.ICLOUD_KEYCHAIN,
        'PSKeychainSyncSecurityCode': UIStateDescription.Setup.CREATE_ICLOUD_SECURITY_CODE,
        'KeychainSyncAdvancedSecurityCode': UIStateDescription.Setup.ADVANCED_SECURITY_CODE,
        'KeychainSyncPhoneNumber': UIStateDescription.Setup.KEYCHAIN_PHONE_NUMBER,
        'BuddyPhoneNumberPermission': UIStateDescription.Setup.IMESSAGE_FACETIME,
        'BuddyChinaPhoneNumberPermission': UIStateDescription.Setup.IMESSAGE_FACETIME,
        'BuddyAutoUpdate': UIStateDescription.Setup.AUTO_UPDATE,

        /** Terms and Conditions */
        'BuddyiOSTC': UIStateDescription.Setup.OFFLINE_TERMS_CONDITIONS,
        'Terms and Conditions': UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS,

        /** Touch ID */
        'BuddyMesaEnrollment': UIStateDescription.Setup.TOUCH_ID,                              // All Touch ID screens use this controller

        /** Passcode */
        'BuddyPasscode': UIStateDescription.Setup.PASSCODE,

        'PKPaymentSetupAssistantRegistrationView': UIStateDescription.Setup.APPLE_PAY_DESC,
        'PKPaymentCameraCaptureView': UIStateDescription.Setup.APPLE_PAY,
        'VTUIEnrollTrainingView': UIStateDescription.Setup.SIRI,
        'AssistantChoice': UIStateDescription.Setup.SIRI,
        'BuddyAppActivity': UIStateDescription.Setup.APP_ANALYTICS,
        'BuddyMagnify': UIStateDescription.Setup.ZOOM,
        'Display Zoom': UIStateDescription.Setup.DISPLAY_ZOOM,
        'PSMagnify': UIStateDescription.Setup.DISPLAY_ZOOM,                                     // rdar://problem/21261531
        'DBSMagnify': UIStateDescription.Setup.DISPLAY_ZOOM,
        'BuddyHarmony': UIStateDescription.Setup.TRUE_TONE_DISPLAY,
		'STSetupAssistantView': UIStateDescription.Setup.SCREEN_TIME,

        /** Activation */
        'Activation': UIStateDescription.Setup.ACTIVATE,
        'BuddyFinished': UIStateDescription.Setup.FINISHED,
        'BuddyUpdateFinished': UIStateDescription.Setup.UPDATE_FINISHED,
        'Verification Failed': UIStateDescription.Setup.VERIFICATION_FAILED,
        'BuddyCloudConfigDisclosureView': UIStateDescription.Setup.ENT_CONFIG_DISCLOSURE,
        'BuddyCloudConfigLoginView': UIStateDescription.Setup.ENT_CONFIG_LOGIN,
        'BuddyCloudConfigInstallation': UIStateDescription.Setup.ENT_CONFIG_INSTALL,
        'CloudConfigurationRetrieval': UIStateDescription.Setup.CLOUD_CONFIG_RETRIEVAL,

        /** Activation Failure */
        'Could Not Activate iPad': UIStateDescription.Setup.ACTIVATION_FAILURE,
        'Could Not Activate iPhone': UIStateDescription.Setup.ACTIVATION_FAILURE,
        'Could Not Activate iPod touch': UIStateDescription.Setup.ACTIVATION_FAILURE,
        'ActivationFailurePage': UIStateDescription.Setup.ACTIVATION_FAILURE,
        'Activate': UIStateDescription.Setup.ACTIVATION_LOCKED_PAGE,

        /** Profile Picture */
        'PRLikenessIntroView': UIStateDescription.Setup.PROFILE_PICTURE_INTRO,
        'PRLikenessTypeSelectionView': UIStateDescription.Setup.PROFILE_PICTURE_SELECTION,
        'PRMonogramCustomizationView': UIStateDescription.Setup.MONOGRAM_CUSTOMIZATION,
        'PRLikenessReadyView': UIStateDescription.Setup.PROFILE_PICTURE_READY,

        /** New Home Button */
        'BuddyHomeButton': UIStateDescription.Setup.NEW_HOME_BUTTON_INTRO,
        'PSUIHomeButtonCustomize': UIStateDescription.Setup.CUSTOMIZE_HOME_BUTTON,

        /** Buddy Diagnostics */
        'BuddyDiagnostics': UIStateDescription.Setup.BUDDY_DIAGNOSTICS,
        'BuddySeedDiagnostics': UIStateDescription.Setup.BUDDY_SEED_DIAGNOSTICS,

        /** Software Update */
        'BuddyInlineSoftwareUpdate': UIStateDescription.Setup.INLINE_SOFTWARE_UPDATE,

        /** Apple Watch */
        'BPSWatchMigration': UIStateDescription.Setup.APPLE_WATCH_MIGRATION,

        /** On-Boarding */
        'BuddyCoverSheetOnBoarding': UIStateDescription.Setup.COVER_SHEET_ON_BOARDING,
        'BuddyMultitaskingOnBoarding': UIStateDescription.Setup.MULTITASKING_ON_BOARDING,
        'BuddyDockOnBoarding': UIStateDescription.Setup.DOCK_ON_BOARDING,
        'BuddyGoHomeOnBoarding': UIStateDescription.Setup.GO_HOME_ON_BOARDING,
        'BuddyApplePayOnBoarding': UIStateDescription.Setup.APPLE_PAY_ON_BOARDING,
        'BuddySiriOnBoardingSplash': UIStateDescription.Setup.SIRI_ON_BOARDING,
        'BuddyApplicationSwitcherOnBoardingSplash': UIStateDescription.Setup.APP_SWITCHER_ON_BOARDING,
        'BuddyControlCenterOnBoardingSplash': UIStateDescription.Setup.CONTROL_CENTER_ON_BOARDING,

        /** Privacy */
        'OBPrivacySplash': UIStateDescription.Setup.PRIVACY_SPLASH,

        /** Shared iPad */
        'BuddyAppleIDPasswordChange': UIStateDescription.Setup.SHAREDIPAD_CREATE_PASSCODE,
        'BuddyAppleIDPasswordChanging': UIStateDescription.Setup.SHAREDIPAD_CHANGING_PASSCODE,

        /** Cellular */
        'TSAddCellularPlanView': UIStateDescription.Setup.SET_UP_CELLULAR,
        'TSCellularPlanUsesView': UIStateDescription.Setup.SET_CELLULAR_CHOICE,
        'TSCellularPlanLabelsView': UIStateDescription.Setup.CELLULAR_PLAN_LABELS,
        'TSCellularPlanIMessageView': UIStateDescription.Setup.CELLULAR_PLAN_IMESSAGE,

        /** Face ID */
        'BKUIPearlEnroll': UIStateDescription.Setup.FACE_ID,
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get The Current UI State                                            */
    /*                                                                             */
    /*      A function to determine which UIState the app is currently in          */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and setup for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
     */
    setup.currentUIState = function currentUIState() {
        // workaround until we have rdar://problem/35040757
        target.systemApp().unlock({passcode:setup.passcode});

        var currentUIState = UIStateDescription.UNKNOWN;

        if (setup.state() != UIAAppState.FOREGROUND_RUNNING) {
            if (!setup.needsToRun) {
                currentUIState = UIStateDescription.Setup.DONE;
            } else if (target.activeApps()[0].bundleID() === 'com.apple.springboard') {
                if (springboard.exists("SlideToSetup")) {
                    currentUIState = UIStateDescription.Setup.SLIDE_TO_SETUP;
                }
            }
            if (target.activeApp().name() === 'LoginUI') {
                currentUIState = UIStateDescription.Setup.DONE;
            }
            if (currentUIState === UIStateDescription.UNKNOWN) {
                var appName = target.activeApp().name();
                var errorMsg = 'Setup is incomplete but "%0" is active'.format(appName);
                var errorID = 'Unknown UI state encountered during setup; "%0"'.format(appName);
                throw new UIAError(errorMsg, {identifier: errorID});
            }
        } else {
            var appInfo = this.inspect(UIAQuery.application());
            var navbar = appInfo.inspect(UIAQuery.Setup.NAV_BAR);
            if (navbar) {
                var navBarName = navbar.name;

                if (navBarName === "UIAlert") {
                    // action sheets will interfere with the navigation bar name
                    // dismiss the action sheet and re-fetch the name
                    setup.dismissActionSheet();
                    appInfo = this.inspect(UIAQuery.application());
                    navbar = appInfo.inspect(UIAQuery.Setup.NAV_BAR);
                    if (navbar) {
                        navBarName = navbar.name;
                    }
                }

                UIALogger.logMessage('Current navigation bar is "%0".'.format(navBarName));

                switch(navBarName) {
                    case 'RUIPage':
                        if (this.isActivationLocked()) {
                            currentUIState = UIStateDescription.Setup.ACTIVATION_LOCKED_PAGE;
                        } else if (setup.activationError()) {
                            throw new UIAError('Activation Error', {identifier: 'Activation Error'});
                        } else if (appInfo.exists(UIAQuery.Setup.APPLE_ID_SECURITY)) {
                            currentUIState = UIStateDescription.Setup.APPLE_ID_SECURITY;
                        } else if (appInfo.exists(UIAQuery.Setup.APPLE_ID_TWO_FACTOR_AUTH)) {
                            currentUIState = UIStateDescription.Setup.APPLE_ID_TWO_FACTOR_AUTH;
                        } else if (appInfo.exists(UIAQuery.Setup.VERIFICATION_FAILED)) {
                            currentUIState = UIStateDescription.Setup.VERIFICATION_FAILED;
                        } else if (appInfo.exists(UIAQuery.Setup.PROXIMITY_ACCOUNT)) {
                            currentUIState = UIStateDescription.Setup.PROXIMITY_ACCOUNT;
                        } else if (appInfo.exists(UIAQuery.Setup.TERMS_AND_CONDITIONS)) {
                            currentUIState = UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS;
                        } else if (appInfo.exists(UIAQuery.Setup.FORGOT_APPLE_ID)) {
                            currentUIState = UIStateDescription.Setup.FORGOT_APPLE_ID;
                        } else if (appInfo.exists(UIAQuery.Setup.DEVICE_READY)) {
                            currentUIState = UIStateDescription.Setup.DEVICE_READY;
                        } else if (appInfo.exists(UIAQuery.Setup.DEVICE_ACTIVATED)) {
                            currentUIState = UIStateDescription.Setup.DEVICE_ACTIVATED;
                        } else if (appInfo.exists(UIAQuery.Setup.DEVICE_UNKNOWN)) {
                            currentUIState = UIStateDescription.Setup.DEVICE_UNKNOWN;
                        } else if (appInfo.exists(UIAQuery.Setup.SIM_REQUIRED)) {
                            currentUIState = UIStateDescription.Setup.SIM_REQUIRED;
                        } else if (appInfo.exists(UIAQuery.Setup.ACTIVATION_PAGE)) {
                            currentUIState = UIStateDescription.Setup.ACTIVATION_LOCKED_PAGE;
                        }  else if (appInfo.exists(UIAQuery.Setup.SHAREDIPAD_CHANGING_PASSCODE)) {
                            currentUIState = UIStateDescription.Setup.SHAREDIPAD_CHANGING_PASSCODE;
                        }  else if (appInfo.exists(UIAQuery.Setup.SHAREDIPAD_CREATE_PASSCODE)) {
                            currentUIState = UIStateDescription.Setup.SHAREDIPAD_CREATE_PASSCODE;
                        }
                        break;

                    case 'BKUIPearlEnroll':
                        currentUIState = UIStateDescription.Setup.FACE_ID;
                        break;
                    case 'BuddyAppleIDSignIn':
                    case 'AKBuddySignIn':
                        if (appInfo.exists(UIAQuery.Setup.ALTERNATE_APPLE_ID)) {
                            currentUIState = UIStateDescription.Setup.ALTERNATE_APPLE_ID;
                        } else {
                            currentUIState = UIStateDescription.Setup.APPLE_ID_SIGN_IN;
                        }
                        break;
                    default:
                        // at this point we have a unique mapping between a navigation name and state as reflected in the map above
                        currentUIState = this._navigationBarToUIStateMap[navBarName] || UIStateDescription.UNKNOWN;
                }

                if (currentUIState === UIStateDescription.UNKNOWN) {
                    var appName = target.activeApps()[0].name();
                    var errorMessage = 'Got to unknown navigation bar "%0" in application "%1"'.format(navBarName, appName);
                    throw new UIAError(errorMessage, {identifier: 'Unknown UI state encountered during setup; %0 - %1'.format(appName, navBarName)});
                }
            }
        }

        UIALogger.logMessage('Currently displaying %0 UI'.format(currentUIState));

        return currentUIState;
    }

    /**
     * Extra logging for <rdar://problem/23472149> Automation: 'UIA2_Setup_Setup Device' failed with 'Setup stuck in Wi-Fi network UI'
     * Will remove when issue is fixed: <rdar://problem/23569757> Remove extra logging added for wifi issue
     */
    setup.extraLoggingForWifiPageIssue = function extraLoggingForWifiPageIssue() {
        var collectWiFiDebugInfo = target.performTask('/usr/local/bin/collectWiFiDebugInfo.sh', [], 100);

        if(collectWiFiDebugInfo['exitCode'] === 0){
            UIALogger.logMessage('collectWiFiDebugInfo was successful: %0'.format(collectWiFiDebugInfo['stdout']));
        }else{
            UIALogger.logMessage('collectWiFiDebugInfo failed: %0'.format(collectWiFiDebugInfo['stderr']));
        }
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get To [page] functions                                             */
    /*                                                                             */
    /*      Helper functions for navigating to different pages within the app      */
    /*                                                                             */
    /*******************************************************************************/


    /***********************************************************************************/
    /*                                                                                 */
    /*   Mark: Tasks                                                                   */
    /*                                                                                 */
    /*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
    /*      These will be comprised of multiple Action functions                       */
    /*                                                                                 */
    /***********************************************************************************/

    /**
     * Navigate SetupBuddy
     *
     * @param {object} options - Options dictionary
     * @param {string} options.language - language to choose (default to English)
     * @param {string} options.country - Optional country to choose (default to United States)
     * @param {bool} options.usePhoneNumber - Use phone number to register for iMessage & FaceTime (China SKU only, default to false)
     * @param {string} options.wifiNetwork - Required name of the Wi-Fi network to connect to
     * @param {string} options.wifiPassword - Optional password of the Wi-Fi network to connect to
     * @param {string} options.wifiUsername - Optional user of the Wi-Fi network to connect to
     * @param {bool} options.isWiFiHiddenNetwork - Optional hidden flag of the Wi-Fi network to connect to
     * @param {string} options.wifiSecurityType - Optional security of the Wi-Fi network to connect to
     * @param {string} options.d2dChoice - Optional perform Device to Device Migration or choose other options
     * @param {int} options.d2dTimeout - Optional timeout for D2D
     * @param {string} options.restoreRoute - Optional how to restore the device
     * @param {string} options.androidHostIPAddress - Optional hostIPAddress if migrating from android using data on a Mac
     * @param {string} options.androidSemaphoreUUID - Required in order to transfer from an android device
     * @param {string} options.passcode - Optional passcode to set
     * @param {string} options.appleID - Optional Apple ID account name
     * @param {string} options.appleIDPassword - Optional Apple ID password
     * @param {bool} options.customizeSettings - Whether to customize settings or use defaults that share location and app developer info
     * @param {string} options.configurationUsername - Optional the enterprise username
     * @param {string} options.configurationPassword - Optional the enterprise password
     * @param {bool} options.skipEnterpriseConfiguration - Whether or not to skip enterprise configuration
     * @param {string} options.icsc - Optional iCloud Security Code
     * @param {string} options.icscOptions - Optional iCloud Security Code advanced options
     * @param {string} options.passcodeChoice - Optional 'passcode' to use the device passcode as icsc
     * @param {int} options.androidTransferTimeout - Optional timeout time for android file transfer
     * @param {int} options.appleIDTimeout - Optional timeout for Apple ID
     * @param {bool} options.proximityAccount - Optional - Whether to enter SA account required for proximity setup
     * @param {int} options.verificationTimeout - Optional timeout for verification retries
     * @param {bool} options.useSiri - Whether to use Siri
     * @param {bool} options.enableLocationServices - Whether to enable Location Services
     * @param {bool} options.shareAppAnalytics - Whether to share App Analytics
     * @param {bool} options.useFindMyiPhone - Whether to use Find My iPhone/iPad
     * @param {bool} options.useiCloudKeychain - Whether to set up iCloud Keychain
     * @param {bool} options.useApplePay - Whether to use Apple Pay
     * @param {bool} options.useZoom - Whether to use Display Zoom
     * @param {bool} options.useiCloud - Whether to use iCloud
     * @param {bool} options.useiCloudDrive - Whether to use iCloud Drive
     * @param {string} options.profilePictureSelection - Optional - Whether to use a monogram, avatar, or photo as a profile picture
     * @param {string} options.homeButtonChoice - Optional - Which home button sensitivity level to use
     * @param {string} options.allowAppleDiagnostics - Optional - Whether to allow sending diagnostic reports to Apple (Customer install only)
     * @param {string} options.targetState - Optional - UIState on which to return, should match a UIStateDescription.Setup constant
     * @param {string} options.sharedCurrentPasscode - Optional - Shared iPad MAID current passcode
     * @param {string} options.sharedNewPasscode - Optional - Shared iPad MAID new passcode being set
     * @param {string} options.autoUpdate - Optional - Whether automatic software updates are enabled
     * @param {bool} options.enableScreenTime - Whether to enable Screen Time
     * @param {string} options.cellularChoice - Optional - Default cellular plan
     */
    setup.navigateSetupBuddy = function navigateSetupBuddy(options) {
        options = UIAUtilities.defaults(options, {
            language: 'English',
            country: 'United States',
            restoreRoute: 'new',
            appleIDTimeout: 60,
            verificationTimeout: 30,
            targetState: 'SpringBoard',
            whitelistedPanes:[],
            blacklistedPanes: [],
            failForUnknownPanes: false,
            sequencedPanes:[],
            autoUpdate: false,
        });

        var resultingPanes = []

        if (!options.wifiNetwork) {
            throw new UIAError('No Wi-Fi network supplied');
        }
        if (options.passcode) {
            UIALogger.logMessage('Setting setup.passcode = %0'.format(options.passcode));
            this.passcode = options.passcode;
        }

        var helloScreenTimeout = 5;
        var helloScreenControllerClass = 'SBDashBoardSetupViewController';
        var helloScreenDisappearedWaiter = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass = "%0"'.format(helloScreenControllerClass)
        );

        target.systemApp().unlock({passcode:setup.passcode});

        if (!helloScreenDisappearedWaiter.wait(helloScreenTimeout)) {
            UIALogger.logWarning('%0 controllerClass did not disappear within %1 seconds'.format(
                helloScreenControllerClass, helloScreenTimeout));
        }

        // tracks the iteration number(s) for each state as we visit them
        // stores the history of the states as we attempt to navigate buddy
        // each new state(page)/attempt will be add as we progress
        var stateHistory = {};
        stateHistory.ACTIVATION_LOCK_APPEAR = false;

        var _maxRepeatsForUIState = function _maxRepeatsForUIState(currentUIState) {
            // this is here so that we can easily conditionalize the
            // number of times we might visit a UI state in the future
            switch (currentUIState) {
                default:
                    return 5;
            }
        }

        // Increased maxAttempts from 30 to 100 to fix <rdar://problem/48196324>
        var maxAttempts = 100;
        for (var attempt = 0; attempt < maxAttempts; attempt++) {
            UIALogger.logMessage('Beginning attempt #%0'.format(attempt+1));

            var currentUIState = setup.currentUIState();
            (stateHistory[currentUIState] || (stateHistory[currentUIState] = [])).push(attempt);

            // return if we've reached the desired state
            if (currentUIState == options.targetState) {
                UIALogger.logMessage('Got to %0 page'.format(currentUIState));
                this.logStateHistory(stateHistory);
                setup.verifyPanes(options,resultingPanes)
                return;
            }
            // limit the number of times we repeat a UI state
            var repeatCount = stateHistory[currentUIState].length;
            if (repeatCount > _maxRepeatsForUIState(currentUIState)) {
                var errorMessage = 'Setup appears to be stuck in %0 UI (previously encountered %1 times; %2)'.format(currentUIState, repeatCount, stateHistory[currentUIState]);
                UIALogger.logDebug(errorMessage);
                this.logStateHistory(stateHistory);
                if (currentUIState === 'Wi-Fi network') {
                    setup.extraLoggingForWifiPageIssue();
                }
                throw new UIAError(errorMessage, {identifier:'Setup stuck in %0 UI'.format(currentUIState)});
            }

            // add buddy pane for buddy pane validation
            if (resultingPanes.indexOf(currentUIState) !== -1 ){
                UIALogger.logWarning('Adding a duplicate pane: %0'.format(currentUIState))
                resultingPanes.push(currentUIState)
            } else {
                resultingPanes.push(currentUIState)
            }

            switch (currentUIState) {
                case UIStateDescription.Setup.SLIDE_TO_SETUP:
                    this.summonBuddy();
                    break;
                case UIStateDescription.Setup.LANGUAGE:
                    this.chooseLanguage(options.language);
                    break;
                case UIStateDescription.Setup.LOCALE:
                    this.chooseCountry(options.country);
                    break;
                case UIStateDescription.Setup.EXPRESS_LANGUAGE_SETUP:
                    this.expressLanguageSetup();
                    break;
                case UIStateDescription.Setup.PREFERRED_LANGUAGE_ORDER:
                    this.preferredLanguageOrder();
                    break;
                case UIStateDescription.Setup.WIFI_NETWORK:
                    this.setWifi(options.wifiNetwork, options.wifiPassword, options.wifiUsername, options.isWiFiHiddenNetwork, options.wifiSecurityType);
                    break;
                case UIStateDescription.Setup.ENTER_PASSWORD:
                case UIStateDescription.Setup.WIFI_OTHER_NETWORK:
                    this.cancelNetwork();
                    break;
                case UIStateDescription.Setup.PEARL_SPLASH:
                    this.pearlSplash();
                    break;
                case UIStateDescription.Setup.FACE_ID:
                    this.faceID();
                    break;
                case UIStateDescription.Setup.LOCATION_SERVICES:
                    this.chooseLocationServices(options.enableLocationServices);
                    break;
                case UIStateDescription.Setup.DEVICE_RESTORE_CHOICE:
                    this.setUpDeviceRestoreRoute(options.restoreRoute);
                    break;
                case UIStateDescription.Setup.ALTERNATE_APPLE_ID:
                    this.signIntoiTunes(options.iTunesPassword, options.tfaPhoneNumberiTunes);
                    break;
                case UIStateDescription.Setup.ACTIVATION_LOCKED_PAGE:
                    UIALogger.logDebug(options.failIfActivationLock);
                    if (!options.failIfActivationLock) {
                        UIALogger.logDebug('Handle activation Lock');
                        this.handleActivationLock(options.appleID, options.appleIDPassword, stateHistory);
                    } else {
                        UIALogger.logDebug('REPORT FAILURE MAN`');
                        this.reportActivationLockFailure();
                    }
                    break;
                case UIStateDescription.Setup.APPLE_ID_SIGN_IN:
                    this.setUpAppleID(options.appleID, options.appleIDPassword);
                    break;
                case UIStateDescription.Setup.APPLE_ID_CHOICE:
                    this.buddyAppleIDChoice();
                    break;
                case UIStateDescription.Setup.WELCOME:
                    this.welcomeView(options.customizeSettings);
                    break;
                case UIStateDescription.Setup.BUDDY_PROXIMITY_SETUP:
                    this.buddyProximitySetup();
                    break;
                case UIStateDescription.Setup.RESTORE_FROM_ITUNES:
                    this.restoreFromiTunes();
                    break;
                case UIStateDescription.Setup.MOVE_FROM_ANDROID:
                    this.moveFromAndroid(
                        options.androidHostIPAddress,
                        options.androidTransferTimeout,
                        options.androidSemaphoreUUID
                    );
                    break;
                case UIStateDescription.Setup.ACTIVATE:
                    this.activationPage();
                    break;
                case UIStateDescription.Setup.ACTIVATION_FAILURE:
                    this.tryAgain();
                    break;
                case UIStateDescription.Setup.COMBINED_TERMS_CONDITIONS:
                    this.combinedTermsAndConditions();
                    break;
                case UIStateDescription.Setup.OFFLINE_TERMS_CONDITIONS:
                    this.offlineTermsAndConditions();
                    break;
                case UIStateDescription.Setup.APPLE_ID_SECURITY:
                    this.appleIDSecurityDoNotUpdate();
                    break;
                case UIStateDescription.Setup.APPLE_ID_TWO_FACTOR_AUTH:
                    this.appleIDTwoFactorAuth();
                    break;
                case UIStateDescription.Setup.PROXIMITY_ACCOUNT:
                    this.proximityAccount(options.proximityAccount, options.appleIDTimeout, options.appleIDPassword);
                    break;
                case UIStateDescription.Setup.TOUCH_ID:
                    this.touchID();
                    break;
                case UIStateDescription.Setup.PASSCODE:
                    this.setPasscode(options.passcode);
                    break;
                case UIStateDescription.Setup.SIRI:
                    this.chooseSiri(
                                    options.useSiri,
                                    options.heySiriSetup
                                    );
                    break;
                case UIStateDescription.Setup.APP_ANALYTICS:
                    this.chooseAppAnalytics(options.shareAppAnalytics);
                    break;
                case UIStateDescription.Setup.ZOOM:
                    this.chooseView(options.useZoom);
                    break;
                case UIStateDescription.Setup.DISPLAY_ZOOM:
                    this.chooseDisplayZoom(options.useZoom);
                    break;
                case UIStateDescription.Setup.TRUE_TONE_DISPLAY:
                    this.handleTrueToneDisplayPage();
                    break;
                case UIStateDescription.Setup.FIND_MY:
                case UIStateDescription.Setup.UPGRADE_FIND_MY:
                    this.chooseFindMyiPhone(options.useFindMyiPhone);
                    break;
                case UIStateDescription.Setup.ICLOUD:
                    this.chooseiCloud(options.useiCloud);
                    break;
                case UIStateDescription.Setup.ICLOUD_DRIVE:
                    this.chooseiCloudDrive(options.useiCloudDrive);
                    break;
                case UIStateDescription.Setup.ICLOUD_KEYCHAIN:
                    this.chooseiCloudKeychain(options.useiCloudKeychain,options.passcodeChoice);
                    break;
                case UIStateDescription.Setup.CREATE_ICLOUD_SECURITY_CODE:
                    this.createiCloudSecurityCode(options.icsc, options.icscOptions);
                    break;
                case UIStateDescription.Setup.ADVANCED_SECURITY_CODE:
                    this.advancedSecurityCode(options.icsc, options.icscOptions);
                    break;
                case UIStateDescription.Setup.KEYCHAIN_PHONE_NUMBER:
                    this.keychainPhoneNumber();
                    break;
                case UIStateDescription.Setup.APPLE_ID_SPINNER:
                    this.waitForAppleIDSetup(options.appleIDTimeout);
                    break;
                case UIStateDescription.Setup.APPLE_ID_FACETIME:
                    this.chooseFaceTime();
                    break;
                case UIStateDescription.Setup.UPGRADE_ICLOUD:
                    this.upgradeiCloud(options.appleIDPassword, options.appleID);
                    break;
                case UIStateDescription.Setup.APPLE_PAY_DESC:
                    this.applePayDesc(options.useApplePay);
                    break;
                case UIStateDescription.Setup.APPLE_PAY:
                    this.chooseApplePay(options.useApplePay);
                    break;
                case UIStateDescription.Setup.FORGOT_APPLE_ID:
                    this.reportAccountLockedFailure();
                    break;
                case UIStateDescription.Setup.UPDATE_FINISHED:
                    UIALogger.logMessage('setupDevice (update) completed');
                case UIStateDescription.Setup.DEVICE_READY:
                    this.continueThroughDeviceReady();
                    break;
                case UIStateDescription.Setup.DEVICE_ACTIVATED:
                    this.continueThroughDeviceActivated();
                    break;
                case UIStateDescription.Setup.DEVICE_UNKNOWN:
                    this.deviceUnknown();
                case UIStateDescription.Setup.SIM_REQUIRED:
                    this.simRequired();
                    break;
                case UIStateDescription.Setup.IMESSAGE_FACETIME:
                    this.iMessageAndFacetime(options.usePhoneNumber);
                    break;
                case UIStateDescription.Setup.PROFILE_PICTURE_INTRO:
                    this.profilePictureIntro(options.profilePictureSelection);
                    break;
                case UIStateDescription.Setup.PROFILE_PICTURE_SELECTION:
                case UIStateDescription.Setup.MONOGRAM_CUSTOMIZATION:
                case UIStateDescription.Setup.PROFILE_PICTURE_READY:
                    this.profilePictureSetup(options.profilePictureSelection);
                    break;
                case UIStateDescription.Setup.FINISHED:
                    if (this.getStarted()) {
                        UIALogger.logMessage('setupDevice completed');
                        this.logStateHistory(stateHistory);
                        setup.verifyPanes(options,resultingPanes);
                        return;
                    } else {
                        UIALogger.logError('Setup failed to complete Get Started step.');
                    }
                    break;
                case UIStateDescription.Setup.VERIFICATION_FAILED:
                    this.retryVerification(options.verificationTimeout);
                    break;
                case UIStateDescription.Setup.ENT_CONFIG_DISCLOSURE:
                    this.enterpriseConfiguration(options.skipEnterpriseConfiguration);
                    break;
                case UIStateDescription.Setup.ENT_CONFIG_LOGIN:
                    this.enterpriseLogin(options.configurationUsername, options.configurationPassword);
                    break;
                case UIStateDescription.Setup.CLOUD_CONFIG_RETRIEVAL:
                    this.cloudConfigRetrievalPage();
                    break;
                case UIStateDescription.Setup.RESTORE_FROM_BACKUP:
                    this.restoreFromiCloudBackup(options.backupVersion);
                    break;
                case UIStateDescription.Setup.RESTORE_FINISHED:
                    setup.miniBuddyContinue();
                    break;
                case UIStateDescription.Setup.NEW_HOME_BUTTON_INTRO:
                    setup.newHomeButtonIntro(options.homeButtonChoice);
                    break;
                case UIStateDescription.Setup.CUSTOMIZE_HOME_BUTTON:
                    setup.customizeHomeButton(options.homeButtonChoice);
                    break;
                case UIStateDescription.Setup.BUDDY_DIAGNOSTICS:
                    setup.allowAppleDiagnostics(options.allowAppleDiagnostics);
                    break;
                case UIStateDescription.Setup.BUDDY_SEED_DIAGNOSTICS:
                    setup.allowAppleSEEDDiagnostics();
                    break;
                case UIStateDescription.Setup.RESTORE_IN_PROGRESS:
                    UIALogger.logMessage('Restore in progress.');
                    setup.waitForRestoreCompletion();
                    this.logStateHistory(stateHistory);
                    setup.verifyPanes(options,resultingPanes)
                    return;
                case UIStateDescription.Setup.INLINE_SOFTWARE_UPDATE:
                    this.inlineSoftwareUpdate();
                    break;
                case UIStateDescription.Setup.APPLE_WATCH_MIGRATION:
                    this.appleWatchMigration();
                    break;
                case UIStateDescription.Setup.COVER_SHEET_ON_BOARDING:
                    this.coverSheetOnBoarding();
                    break;
                case UIStateDescription.Setup.MULTITASKING_ON_BOARDING:
                    this.multitaskingOnBoarding();
                    break;
                case UIStateDescription.Setup.DOCK_ON_BOARDING:
                    this.dockOnBoarding();
                    break;
                case UIStateDescription.Setup.GO_HOME_ON_BOARDING:
                    this.goHomeOnBoarding();
                    break;
                case UIStateDescription.Setup.APPLE_PAY_ON_BOARDING:
                    this.applePayOnBoarding();
                    break;
                case UIStateDescription.Setup.SIRI_ON_BOARDING:
                    this.siriOnBoarding();
                    break;
                case UIStateDescription.Setup.APP_SWITCHER_ON_BOARDING:
                    this.appSwitcherOnBoarding();
                    break;
                case UIStateDescription.Setup.CONTROL_CENTER_ON_BOARDING:
                    this.controlCenterOnBoarding();
                    break;
                case UIStateDescription.Setup.PRIVACY_SPLASH:
                    this.privacySplash();
                    break;
                case UIStateDescription.Setup.SHAREDIPAD_CHANGING_PASSCODE:
                    this.sharediPadChangingPasscode();
                    break;
                case UIStateDescription.Setup.SHAREDIPAD_CREATE_PASSCODE:
                    this.sharediPadCreatePasscode(options.sharedCurrentPasscode, options.sharedNewPasscode);
                    break;
                case UIStateDescription.Setup.AUTO_UPDATE:
                    this.handleAutoUpdate(options.autoUpdate);
                    break;
                case UIStateDescription.Setup.SCREEN_TIME:
                    this.setupScreenTime(options.enableScreenTime);
                    break;
                case UIStateDescription.Setup.SET_UP_CELLULAR:
                    this.setUpCellular();
                    break;
                case UIStateDescription.Setup.SET_CELLULAR_CHOICE:
                    this.setCellularChoice(options.cellularChoice);
                    break;
                case UIStateDescription.Setup.CELLULAR_PLAN_LABELS:
                    this.cellularPlanLabels();
                    break;
                case UIStateDescription.Setup.CELLULAR_PLAN_IMESSAGE:
                    this.cellularPlaniMessage();
                    break;
                case UIStateDescription.Setup.D2D_TARGET_MIGRATION_CHOICE:
                    this.d2dTargetChoice(options.d2dChoice);
                    break;
                case UIStateDescription.Setup.D2D_TARGET_PREP:
                    this.d2dTargetWaiter(options.d2dTimeout);
                    break;
                case UIStateDescription.Setup.D2D_TARGET_PROGRESS:
                    this.d2dTargetWaiter(options.d2dTimeout);
                    break;
                case UIStateDescription.Setup.BUDDY_PROXIMITY_PIN_DISPLAY:
                    this.proxPinDisplayWaiter();
                    break;
                default:
                    UIALogger.logMessage('Unhandled state encountered in navigation');
            }
            UIALogger.logMessage('Attempt #%0 complete'.format(attempt+1));
        }

        var errorMessage = 'Stuck in %0 UI for %1 attempts'.format(currentUIState, maxAttempts);
        UIALogger.logDebug(errorMessage);
        this.logStateHistory(stateHistory);

        throw new UIAError(errorMessage);
    }


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Actions                                                             */
    /*                                                                             */
    /*      Atomic units of UI automation. E.g. - dialsetupNumber                  */
    /*      Other helper functions. E.g. - returnCleanedNumber                     */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Handle a page of Buddy with a waiter
     */
    setup.handleBuddyPageWithWaiter = function handleBuddyPageWithWaiter(controllerClass, stateDescription, timeout, buddyPageHandler) {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "%0"'.format(controllerClass),
            }
        );

        buddyPageHandler();

        if (!thisViewDisappeared.wait(timeout)) {
            UIALogger.logError('The %0 page took longer than %1 seconds to disappear'.format(stateDescription, timeout));
        }
    }

    /**
     * Unlock the device and wait for buddy to be Foreground
     */
    setup.summonBuddy = function summonBuddy() {
        if (this.stateDescription() != 'Foreground Running') {
            var buddyWaiter = UIAWaiter.waiter('ApplicationStateChanged', {
                predicate: "bundleID = 'com.apple.purplebuddy' AND state = 'Foreground'",
            });
            try {
                target.systemApp().unlock({passcode:setup.passcode});
            } catch (e) {
                UIALogger.logError(e);
                return false;
            }
            return buddyWaiter.wait(10);
        } else {
            return true;
        }
    }

    /**
     * Start Buddy Setup Over again
     */
    setup.startOver = function startOver() {
        target.clickMenu();
        this.tap(UIAQuery.Setup.START_OVER);
    }

    /**
     * Choose a Language
     *
     * @param {string} language - Required language to choose
     */
    setup.chooseLanguage = function chooseLanguage(language) {
        var nextViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "BuddyLocaleController"',
            }
        );
        try {
            this.tap(UIAQuery.contains(language));
        } catch (e) {
            UIALogger.logWarning("Failed to tap on %0".format(language));
            return;
        }
        if (!nextViewAppeared.wait(10)) {
            UIALogger.logWarning("'BuddyLocaleController' never appeared after 10s");
        }
    }

    /**
     * Choose a Country
     *
     * @param {string} country - Required country to choose
     */
    setup.chooseCountry = function chooseCountry(country) {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyLocaleController"',
            }
        );

        UIALogger.logMessage('Tapping Country now...');
        setup.withMaximumSnapshotBreadth(400, function() {
            setup.tap(UIAQuery.contains(country));
        });
        UIALogger.logMessage('Waiting (30 seconds) for the next page to show up');
        if (!thisViewDisappeared.wait(30)) {
            UIALogger.logWarning('Country selection page failed to disappear after 30 seconds');
        } else {
            UIALogger.logMessage('Successfully moved on to the next page of Buddy');
        }

    }

    /**
     * Handle the Express Language Set Up page, which allows users to
     * establish multiple languages and keyboards before reaching SpringBoard
     */
    setup.expressLanguageSetup = function expressLanguageSetup() {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyMultilingualExpressViewController"',
            }
        );
		this.tap(UIAQuery.Setup.CONTINUE);

		if (!thisViewDisappeared.wait(10)) {
            UIALogger.logError('Buddy Express Language Setup page failed to disappear after 10 seconds');
        }
    }

    /**
     * Handle the Preferred Language Order page of Buddy
     */
    setup.preferredLanguageOrder = function preferredLanguageOrder() {
        this.handleBuddyPageWithWaiter(
            'BuddyPreferredLanguageOrderSelector',
            UIStateDescription.Setup.PREFERRED_LANGUAGE_ORDER,
            5,
            function() {
                this.tap(UIAQuery.CONTINUE_BUTTON);
            }.bind(this)
        );
    }

    /**
     * Fill in all hidden WiFi network parameters for join
     */
    setup.wifiHiddenNetworkSetup = function wifiHiddenNetworkSetup(wifiNetwork, wifiPassword, wifiUsername, wifiSecurityType) {
        numberOfScroll = 0;
        while (!this.exists(UIAQuery.query("Choose Another Network").isVisible()) && numberOfScroll < 10) {
            this.dragUpInside(UIAQuery.application("Setup"));
        }
        // Occasionally tap on 'Choose Another Network' fails and it taps incorrect wifi. So,trying 3 times.
        for (let i = 3; i > 0; i--) {
            try {
                this.tap(UIAQuery.query("Choose Another Network"));
            }
            catch(e) {
                UIALogger.logError(e);
            }
            if (!setup.exists(UIAQuery.query("Other Network"))) {
                if (this.exists(UIAQuery.Setup.CANCEL)) {
                    setup.cancelNetwork();
                }
                UIALogger.logError('Not on Choose Another Network UI, test might have tapped wrong element. %0 attempts remaining.'.format(i));
            }
            else {
                UIALogger.logMessage('Successfully tapped on Choose Another Network UI ');
                break;
            }
        }
        this.enterText(UIAQuery.Setup.TEXT_FIELD, wifiNetwork);
        if (wifiSecurityType && wifiSecurityType !== "None") {
            if (!wifiPassword) {
                throw new UIAError('Password is required for a secure network');
            }
            this.tap(UIAQuery.tableCells().andThen(UIAQuery.contains('Security')));
            this.tap(UIAQuery.tableCells().andThen(UIAQuery.contains(wifiSecurityType)));
            this.tap(UIAQuery.buttons('Other Network'));
            if (wifiSecurityType === "WPA Enterprise" || wifiSecurityType === "WPA2 Enterprise") {
                if (!wifiUsername || wifiUsername === "" || wifiUsername === null) {
                    throw new UIAError('Username is required for an enterprise network');
                }
                this.tap(UIAQuery.textFields("Username"))
                this.typeString(wifiUsername);
            }
            this.tap(UIAQuery.secureTextFields("Password"))
            this.typeString(wifiPassword);
        }
        this.tap(UIAQuery.Setup.JOIN);
    }

    /** Choose a Wi-Fi Network
     *
     * @param {string} wifiNetwork - Required name of the wifi network to connect to
     * @param {string} wifiPassword - Optional password of the wifi network to connect to
     * @param {string} wifiUsername - Optional username of the wifi network to connect to
     * @param {bool} isWiFiHiddenNetwork - Optional hidden flag of the wifi network to connect to
     * @param {string} wifiSecurityType - Optional security of the wifi network to connect to
     */
    setup.setWifi = function setWifi(wifiNetwork, wifiPassword, wifiUsername, isWiFiHiddenNetwork, wifiSecurityType) {
        var timeout;
        var nextViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass IN {"BuddyLocationServicesController", "DeviceRestoreChoiceController", "RUIPage", "BuddyHomeButtonController"}',
            }
        );
        var trustWaiter = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerClass = "CertificateViewController"'
        );
        if (isWiFiHiddenNetwork) {
            this.wifiHiddenNetworkSetup(wifiNetwork, wifiPassword, wifiUsername, wifiSecurityType)
        } else {
            setup.waitUntilPresent(UIAQuery.query(wifiNetwork).isVisible(), 20)
            this.tap(UIAQuery.tableCells().andThen(UIAQuery.query(wifiNetwork)));
        }
        if (wifiPassword && setup.waitUntilPresent(UIAQuery.Setup.ENTER_WIFI_PASSWORD.isVisible(), 5)) {
            if (wifiUsername && (wifiUsername !== "" || wifiUsername !== null)) {
                this.tap(UIAQuery.textFields("Username"))
                this.typeString(wifiUsername);
            }
            this.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD,wifiPassword);
            this.tap(UIAQuery.Setup.JOIN);
            timeout = 10;
            UIALogger.logMessage('Waiting up to %0 seconds for next view to appear...'.format(timeout));
            if (!setup.waitUntilAbsent(UIAQuery.contains('Enter Password'), timeout)) {
                UIALogger.logError('Enter Password page failed to disappear within %0 second timeout'.format(timeout));
            }
        } else {
            // password may not be required if we have already recently authenticated
            this.tapIfExists(UIAQuery.DONE_BUTTON);
        }
        if (wifiSecurityType && wifiSecurityType !== 'None' && trustWaiter.wait(15)) {
            this.tapIfExists(UIAQuery.Setup.TRUST_BUTTON);
        }
        timeout = 30;
        UIALogger.logMessage('Waiting up to %0 seconds for next view to appear...'.format(timeout));
        if (!setup.waitUntilAbsent(UIAQuery.contains('Other Network'), timeout)) {
            UIALogger.logError('Other Network page failed to disappear within %0 second timeout'.format(timeout));
        }
        if (!setup.waitUntilAbsent(UIAQuery.contains('Choose a Wi-Fi'), timeout)) {
            UIALogger.logError('Wi-Fi network page failed to disappear within %0 second timeout'.format(timeout));
        }
    }

    /**
     * Cancel out of the current WiFi password entry view
     */
    setup.cancelNetwork = function cancelNetwork() {
        setup.tap(UIAQuery.Setup.CANCEL);
    }

    /**
    * Skip pearl setup
    */
    setup.pearlSplash = function pearlSplash() {
        setup.tap(UIAQuery.Setup.SET_UP_LATER_IN_SETTINGS);
    }

      /**
    * Skip Face ID
    */
    setup.faceID = function faceID() {
        setup.tap(UIAQuery.Setup.CANCEL);
    }

    /**
     * Enable or disable Location Services
     *
     * @param {bool} enable - Required if true enable location services, else disable
     */
    setup.chooseLocationServices = function chooseLocationServices(enable) {
        var timeout = 60;
        var locationServicesViewDisappearedWaiter = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass = "BuddyLocationServicesController"'
        );

        UIALogger.logMessage('choose location services - %0'.format(enable));
        if (enable) {
            this.tap(UIAQuery.Setup.ENABLE_LOCATION_SERVICES);
        } else {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.DISABLE_LOCATION_SERVICES, function() {
                this.tap(UIAQuery.Setup.DISABLE_LOCATION_SERVICES);
                //<rdar://problem/20476611> remove me when fixed!!!
                this._dismissAlertWithQuery(UIAQuery.Setup.OK.isVisible());
            });
        }

        if (!locationServicesViewDisappearedWaiter.wait(timeout)) {
            throw new UIAError('The Location Services page took longer than %0 seconds to disappear.'.format(timeout));
        }
    }

    /**
     * Choose to setup a new device or restore from iCloud or iTunes
     *
     * @param {string} restoreRoute - Required how to setup the device
     */
    setup.setUpDeviceRestoreRoute = function setUpDeviceRestoreRoute(restoreRoute) {
        setup.handleBuddyPageWithWaiter(
            'DeviceRestoreChoiceController',
            UIStateDescription.Setup.DEVICE_RESTORE_CHOICE,
            5,
            function() {
                UIALogger.logMessage('Determing which route from which to restore device')
                switch (restoreRoute) {
                    case RestoreRoute.ICLOUD:
                        setup.tap(UIAQuery.Setup.RESTORE_FROM_ICLOUD);
                        break;
                    case RestoreRoute.ITUNES:
                        setup.tap(UIAQuery.Setup.RESTORE_FROM_ITUNES);
                        break;
                    case RestoreRoute.ANDROID:
                        setup.tap(UIAQuery.Setup.MOVE_FROM_ANDROID);
                        break;
                    case RestoreRoute.NEW:
                    default:
                        setup.tap(UIAQuery.Setup.SET_UP_AS_NEW);
                        break;
                }
            }.bind(this)
        );
    }

    /**
     * Restore a device via iTunes
     */
    setup.restoreFromiTunes = function restoreFromiTunes() {
        UIALogger.logMessage("Backing out, since we don't support restores from iTunes yet.");
        setup.tapIfExists(UIAQuery.Setup.BACK);
    }

    /**
     * Set up an Apple ID
     *
     * @param {string} appleID - Optional Apple ID to sign in with
     * @param {string} appleIDPassword - Optional password for the Apple ID
     */
    setup.setUpAppleID = function setUpAppleID(appleID, appleIDPassword) {
        this.handleBuddyPageWithWaiter(
            'BuddyAppleIDSignInController',
            UIStateDescription.Setup.APPLE_ID_SIGN_IN,
            5,
            function() {
                if (this.exists(UIAQuery.Setup.SKIP_THIS_STEP)) {
                    UIALogger.logMessage('Navigating Apple ID sign in upgrade flow');
                    if (!appleID || !appleIDPassword) {
                        UIALogger.logMessage('Apple ID username or password is missing, skipping sign in');
                        this.handlingAlertsInline(UIAQuery.Setup.Alerts.ARE_YOU_SURE, function() {
                            this.tap(UIAQuery.Setup.SKIP_THIS_STEP);
                            this.tap(UIAQuery.Setup.SKIP);
                        });
                    } else {
                        this.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD, appleIDPassword);
                        this.tap(UIAQuery.Setup.NEXT);
                    }
                } else {
                    if (!appleID) {
                        this.tap(UIAQuery.Setup.DONT_HAVE_APPLE_ID);
                    } else {
                        if (this.exists(UIAQuery.Setup.TEXT_FIELD)) {
                            UIALogger.logMessage('The text field for an Apple ID exists.');
                            // "+ '\n" is a workaround for rdar://problem/35953824
                            this.enterText(UIAQuery.Setup.TEXT_FIELD, appleID + '\n');
                        }
                        this.upgradeiCloud(appleIDPassword, appleID);
                    }
                }
            }.bind(this)
        );
    }

    /**
     * Enters password for the iTunes/AppStore/iBooksStore login page
     *
     * @param {string} iTunesPassword - Password for iTunes/AppStore/iBooks account
     * @param {string} tfaPhoneNumberiTunes - optional phone number for iTunes/AppStore/iBooks account
     */
    setup.signIntoiTunes = function signIntoiTunes(iTunesPassword, tfaPhoneNumberiTunes) {
        var restoreProgressPageAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "BackupRestoreProgressController"',
            }
        );

        setup.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD, iTunesPassword);

        if (!tfaPhoneNumberiTunes) { //If SA
            UIALogger.logDebug("tfaPhoneNumberiTunes is None");
            UIALogger.logDebug("Phone number - %0".format(tfaPhoneNumberiTunes));
            setup.tap(UIAQuery.Setup.NEXT);
        }

        if (!restoreProgressPageAppeared.wait(60)) {
            UIALogger.logWarning('Unable to log into iTunes account.');
        }
    }

    /**
     * Set Up Apple ID later in Settings
     */
    setup.buddyAppleIDChoice = function buddyAppleIDChoice() {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyAppleIDChoiceController"',
            }
        );
        this.handlingAlertsInline(UIAQuery.Setup.Alerts.DONT_USE_APPLE_ID, function() {
            setup.tap(UIAQuery.Setup.SET_UP_LATER_IN_SETTINGS);
            //<rdar://problem/20476611> remove me when fixed!!!
            this._dismissAlertWithQuery(UIAQuery.buttons().isVisible().rightmost().orElse(UIAQuery.Setup.DONT_USE));
        });
        if (!thisViewDisappeared.wait(60)) {
            UIALogger.logWarning('The "BuddyAppleIDChoiceController" view took longer than 60 seconds to disappear');
        }
    }

    /**
     * Choose from default sharing options or customize your settings yourself
     *
     * @param {bool} customizeSettings - Whether to customize settings or use defaults that share location and app developer info
     */
    setup.welcomeView = function welcomeView(customizeSettings) {
        var timeout = 60;
        var welcomeViewDisappearedWaiter = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass = "BuddyExpressWelcomeController"'
        );

        if (!customizeSettings) {
            setup.tap(UIAQuery.Setup.CONTINUE);
        } else {
            setup.tap(UIAQuery.Setup.CUSTOMIZE_SETTINGS);
        }

        if (!welcomeViewDisappearedWaiter.wait(timeout)) {
            throw new UIAError('The Welcome View page took longer than %0 seconds to disappear.'.format(timeout));
        }
    }

    /**
     * Migrate from an Android device
     *
     * @param {string} hostIPAddress - Optionally specify an IP address of a hosted android backup
     * @param {int} timeout - Specify a timeout for the transfer
     * @param {string} semaphoreUUID - Specify a UUID for the semaphore service if transferring from a physical Android device
     */
    setup.moveFromAndroid = function moveFromAndroid(hostIPAddress, timeout, semaphoreUUID) {
        // If a semaphore UUID was specified, wait until the semphore is
        // unlocked, signaling that the android device is ready
        var semaphore;
        if (semaphoreUUID !== undefined && semaphoreUUID !== null) {
            semaphore = new Semaphore.Semaphore(
                semaphoreUUID,
                {'transport': Semaphore.TransportMethods.HOST}
            );
            semaphore.wait(Semaphore.States.UNLOCKED);
        }

        var viewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "WLIntroViewController"',
            }
        );

        setup.tap(UIAQuery.Setup.CONTINUE);

        if (!viewDisappeared.wait(30)) {
            throw new UIAError('Android intro view failed to disappear after 30 seconds');
        }

        // Wait for activity indicator to appear and then disappear
        setup.waitUntilPresent(UIAQuery.activityIndicators(), 5);
        setup.waitUntilAbsent(UIAQuery.activityIndicators(), 5);

        // After transfer, migration completed view appears
        var nextViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "WLMigrationCompletedViewController"',
            }
        );

        setup.handlingAlertsInline(UIAQuery.Setup.Alerts.UNABLE_TO_MIGRATE, function () {
            if (hostIPAddress !== undefined && hostIPAddress !== null && hostIPAddress !== '') {
                // Transfer from a specific IP address
                setup.handlingAlertsInline(UIAQuery.Setup.Alerts.WIFI_INFO, function() {
                    // <rdar://problem/21595591> delete me when fixed!
                    setup.tap(UIAQuery.tableViews(), {offset: {x: 0.5, y:1}});

                    setup.handlingAlertsInline(UIAQuery.Setup.Alerts.CONNECT_TO_ADDRESS, function() {
                        //<rdar://problem/20476611> remove me when fixed!!!
                        this._dismissAlertWithQuery(UIAQuery.Setup.CONNECT_TO_ADDRESS);
                        this.typeString(hostIPAddress);
                        //<rdar://problem/20476611> remove me when fixed!!!
                        this._dismissAlertWithQuery(UIAQuery.Setup.CONNECT);
                    });
                });
            } else if (semaphoreUUID !== undefined && semaphoreUUID !== null && semaphoreUUID !== '') {
                // Transfer from a nearby android device
                // Get the transfer code
                var code = setup.inspectElementKey(UIAQuery.Setup.ANDROID_TRANSFER_CODE, 'name');
                UIALogger.logDebug('Got transfer code: %0'.format(code));

                // Strip everything but numbers from the code
                code = code.replace(/[\D]/g, '');

                // Unlock the semaphore and store the code in the payload
                semaphore.lock({'code': code});

            } else {
                throw new UIAError('You must specify hostIPAddress or semaphoreUUID');
            }

            UIALogger.logMessage('Waiting to see if "unable to migrate" alert immediately appears');
            if (!this.waitUntilPresent(UIAQuery.Setup.Alerts.UNABLE_TO_MIGRATE.orElse(UIAQuery.Setup.Alerts.NO_COMMUNICATION), 3)) {
                throw new UIAError('Migration immediately terminated, no data transferred');
            }

            UIALogger.logMessage('Waiting up to %0 second(s) for migration completed view'.format(timeout));
            if (!nextViewAppeared.wait(timeout)) {
                throw new UIAError('Migration completed view failed to appear after %0 second(s)'.format(timeout));
            }
            if (!setup.exists(UIAQuery.Setup.TRANSFER_COMPLETE)) {
                throw new UIAError('Failed to find transfer complete button after migration completed view appeared');
            }

            setup.tap(UIAQuery.Setup.CONTINUE_SETTING_UP);
        });
    }

    /**
     * Finish setting up an Apple ID
     *
     * @param {string} appleIDPassword - Optional password for the Apple ID
     * @param {string} appleID - Optional appleID; necessary for HSA2 sign in with iCloudLoad
     * @param {string} hsa2Code - Optional hsa2 code; if not provided, will try to use iCloudLoad to retrieve one
     */
    setup.upgradeiCloud = function upgradeiCloud(appleIDPassword, appleID, hsa2Code) {
        var nextViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "RUIPage"',
            }
        );
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyAppleIDSignInController"',
            }
        );

        this.handlingAlertsInline(UIAQuery.Setup.Alerts.VERIFICATION_CODE, function() {
            setup.waitUntilPresent(UIAQuery.Setup.SECURE_TEXT_FIELD,120);
            setup.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD, appleIDPassword);
            setup.tap(UIAQuery.Setup.NEXT);
            if (this.waitUntilPresent(UIAQuery.contains('Verification Code'),20)) {
                var hsaOpts = {
                    username: appleID,
                    password: appleIDPassword,
                };
                hsaCode = hsa2Code || settings.getHsa2CodeFromiCloudLoad(hsaOpts);
                this.typeString(hsaCode);
            }
        });

        UIALogger.logMessage('Waiting up to 30 seconds for the BuddyAppleIDSignInController to disappear...');
        if (!thisViewDisappeared.wait(30)) {
            UIALogger.logMessage('The "BuddyAppleIDSignInController" view took longer than 30 seconds to disappear');
        } else {
            if (this.currentUIState() === UIStateDescription.Setup.APPLE_ID_SECURITY) {
                setup.appleIDSecurityDoNotUpdate();
            }
        }

        // updating iCloud settings...
        UIALogger.logMessage('Waiting up to 30 seconds for the next view to appear...');
        if (!nextViewAppeared.wait(30)) {
            UIALogger.logMessage('Terms and Conditions view failed to appear after signing in with an Apple ID');
        }
    }

    /**
     * Answer Apple ID Security questions (defaults to selecting 'Not Now')
     */
    setup.appleIDSecurity = function appleIDSecurity() {
        // TODO: Refactor to accept parameters to handle non-default security options.
        // Use appleIDSecurityDoNotUpdate() as a default flow so far to ignore suggested auth update.
        if (setup.tapIfExists(UIAQuery.Setup.NOT_NOW_CELL, {timeout: 10})) {
            setup.tap(UIAQuery.Setup.NEXT);
        } else {
            UIALogger.logMessage('Do not see the "Not Now" table cell');
        }
    }

    /**
     * Ignore an option to update to 2-factor authentication on Apple ID Security Page.
     */
    setup.appleIDSecurityDoNotUpdate = function appleIDSecurity() {
        var waiter = UIAWaiter.withPredicate(
            "ViewDidDisappear",
             "controllerClass == 'BuddyAppleIDSpinnerPage'"
        );

        UIALogger.logMessage("Choosing not to upgrade to 2-factor auth.");
        this.handlingAlertsInline(UIAQuery.Setup.Alerts.APPLE_ID_SECURITY, function() {
            var alertWaiter = UIAWaiter.waiter("Alert");

            setup.tap(UIAQuery.Setup.OTHER_OPTIONS);
            alertWaiter.wait(5);
            setup.tap(UIAQuery.Setup.DONT_UPGRADE);
        });

        UIALogger.logMessage('Waiting up to 30 seconds for next view to appear...');
        if (!waiter.wait(30)) {
            UIALogger.logError('Failed to handle Apple ID Security Options');
            // Since the nature of this page is non deterministic
            // (it may appear at different setup phases),
            // capture current tree state for possible debugging.
            UIALogger.logMessage(tree());
        }
    }

    /**
     * Apple ID Two Factor Authentication (defaults to selecting 'Don't Use')
     */
    setup.appleIDTwoFactorAuth = function appleIDTwoFactorAuth() {
        UIALogger.logMessage('Not using two-factor authentication. Selecting \'Don\'t use\'');
        setup.tap(UIAQuery.Setup.DONT_USE_TWO_FACTOR);
    }

    /**
     * Wait for the Apple ID to be set up
     *
     * @param {int} timeout - number of seconds to wait for the apple ID to be set up
     */
    setup.waitForAppleIDSetup = function waitForAppleIDSetup(appleIDTimeout) {
        // device screen might sleep here
        var nextViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass == "BuddyAppleIDCastlePage" or controllerClass == "BuddyAppleIDKeychainSyncPage"',
            }
        );
        UIALogger.logMessage('Waiting up to %0 seconds for the next view to appear...'.format(appleIDTimeout));
        if (!nextViewAppeared.wait(appleIDTimeout)) {
            UIALogger.logMessage('Terms and Conditions view failed to appear after signing in with an Apple ID');
        }
    }

    /**
     * Enter password for Proximity SA Account
     *
     * @param {int} timeout - number of seconds to wait for the apple ID to be set up
     */
    setup.proximityAccount = function proximityAccount(proximityAccount, appleIDTimeout, appleIDPassword) {
        if (proximityAccount){
            var iCloudPasswordAlertTitle = 'Apple ID Password';
            var waiter = UIAWaiter.waiter(
                'ViewDidAppear', {
                    predicate: 'controllerClass == "AKBasicLoginContentViewController"',
                }
            );
            this.handlingAlertsInline(UIAQuery.alerts(iCloudPasswordAlertTitle), function() {
                if (!waiter.wait(appleIDTimeout)) {
                    throw new UIAError("iCloud password alert did not appear");
                }
                target.keyboard().typeString(appleIDPassword);
            });
        }
    }

    /**
     * Retry the verification step
     *
     * @param {int} timeout - number of seconds to wait for verification
     */
    setup.retryVerification = function retryVerification(verificationTimeout) {
        // We're just gonna check if the title text disappears
        setup.tapIfExists(UIAQuery.Setup.TRY_AGAIN);
        UIALogger.logMessage('Waiting up to %0 seconds for verification to pass...'.format(verificationTimeout));

        if (!setup.waitUntilAbsent(UIStateDescription.Setup.VERIFICATION_FAILED, verificationTimeout)) {
            var errorMessage = 'Failed verification twice in a row'
            UIALogger.logMessage(errorMessage);
            throw new UIAError(errorMessage, {identifier: 'Verification Error'});
        }
    }

    /**
     * Agree to the combined iCloud and device terms and conditions
     */
    setup.combinedTermsAndConditions = function combinedTermsAndConditions() {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "RUIPage"'
        );

        // When device region is China, need to handle double-confirmation alert
        this.handlingAlertsInline(UIAQuery.Setup.Alerts.TERMS_AND_CONDITIONS, function() {
            this.tap(UIAQuery.Setup.AGREE);
            this.tapIfExists(UIAQuery.alerts().andThen(UIAQuery.Setup.AGREE));
        });

        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('The combined Terms and Conditions page took longer than 5 seconds to disappear.');
        }
    }

    /**
     * Agree to the offline terms and conditions
     */
    setup.offlineTermsAndConditions = function offlineTermsAndConditions() {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "BuddyiOSTCController"'
        );

        // Handle double-confirmation alert
        this.handlingAlertsInline(UIAQuery.Setup.Alerts.TERMS_AND_CONDITIONS, function() {
            this.tap(UIAQuery.Setup.AGREE);
            this.tap(UIAQuery.alerts().andThen(UIAQuery.Setup.AGREE));
        });

        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('The offline Terms and Conditions page took longer than 5 seconds to disappear.');
        }
    }

    /**
     * Check if device is Activation locked
     */
    setup.isActivationLocked = function isActivationLocked() {
        return setup.exists(UIAQuery.Setup.ACTIVATION_LOCKED) && setup.exists(UIAQuery.Setup.CURRENTLY_LINKED);
    }

    /**
     * Check if there was an activation error
     */
    setup.activationError = function activationError() {
        return setup.exists(UIAQuery.Setup.ACTIVATION_ERROR);
    }

    /**
     * Don't setup Touch ID
     */
    setup.touchID = function touchID() {
        var touchIDPageDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "BuddyMesaEnrollmentController"'
        );

        this.handlingAlertsInline(UIAQuery.Setup.Alerts.TOUCH_ID, function() {
            setup.tap(UIAQuery.Setup.SKIP_TOUCH_ID.isVisible());
            setup.tapIfExists(
                UIAQuery.alerts().andThen(UIAQuery.buttons().leftmost())
                    .orElse(UIAQuery.Setup.DONT_USE)
                    .orElse(UIAQuery.alerts().andThen(UIAQuery.Setup.CONTINUE))
                )
        });

        UIALogger.logMessage('Waiting up to 5 seconds for the Touch ID page to disappear');
        if (!touchIDPageDisappeared.wait(5)) {
            UIALogger.logError('Touch ID page failed to disappear after 5 seconds');
        }
    }

    /**
     * Set a passcode
     *
     * @param {string} passcode - Optional passcode to set on the device
     */
    setup.setPasscode = function setPasscode(passcode) {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "BuddyPasscodeController"'
        );

        var sixDigitsFlag = true;

        if (!passcode) {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.SKIP_PASSCODE, function() {
                setup.tap(UIAQuery.Setup.SKIP_PASSCODE.orElse(UIAQuery.Setup.PASSCODE_OPTIONS));
                setup.tapIfExists(UIAQuery.actionSheets().andThen(UIAQuery.buttons().atIndex(3))
                    .orElse(UIAQuery.Setup.SKIP_PASSCODE)
                );

                //<rdar://problem/20476611> remove me when fixed!!!
                // <rdar://problem/32654495> Remove code for old passcode flow
                this._dismissAlertWithQuery(UIAQuery.buttons().isVisible().topmost().orElse(UIAQuery.Setup.SKIP_PASSCODE.orElse(UIAQuery.Setup.CONTINUE)));
            });
        } else {
            var node = setup.inspectElementKey(UIAQuery.Setup.PASSCODE_LENGTH, 'value');

            // workaround for rdar://problem/22116203 (if the passcode options are left on screen we should dismiss them)
            if (this.exists(UIAQuery.popovers()) && !this.dismissPopover()) {
                // workaround for rdar://problem/22295811 (dismissPopover fails with keyboard present)
                this.tap(UIAQuery.query(UIAQuery.Setup.PASSCODE_OPTIONS));
            }
            var nextKeyboardAppeared = UIAWaiter.waiter(
                'Announcement', {
                    predicate: 'announcement == "AXAnnouncementTypeKeyboardAppearSound"',
                }
            );
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.USE_CODE, function() {
                if (node.contains('6')) {
                    UIALogger.logMessage('6 digit default passcode type device.');
                    setup.resolvePasscode(PasscodePatterns.SIX_DIGITS, passcode, sixDigitsFlag);
                } else {
                    sixDigitsFlag = false;
                    UIALogger.logMessage('4 digit default passcode type device.');
                    setup.resolvePasscode(PasscodePatterns.FOUR_DIGITS, passcode, sixDigitsFlag);
                }
                setup.enterPasscode(passcode);
                // <rdar://problem/20476611> remove me when fixed!!!
                this._dismissAlertWithQuery(UIAQuery.Setup.USE_CODE);
            });
            UIALogger.logMessage('Waiting up to 5 seconds for next keyboard to appear');
            if (!nextKeyboardAppeared.wait(5)) {
                UIALogger.logMessage('Next keyboard never signalled arrival');
            }
            setup.enterPasscode(passcode);
        }

        UIALogger.logMessage('Waiting up to 10 seconds for passcode view to disappear');
        if (!thisViewDisappeared.wait(10)) {
            UIALogger.logError('Passcode view did not disappear after 10 seconds');
        }
    }


    /**
     * Dynamic resolution of passcode for H4/H6 devices
     *
     * @param {string} defaultPasscodeDigits - Required default number of digits in passcode for the given device
     * @param {string} passcode - Required provided number of digits in passcode to the given device
     * @param {bool} sixDigitsFlag - Required if default passcode type is six digit
     */
    setup.resolvePasscode = function resolvePasscode(defaultPasscodeDigits, passcode, sixDigitsFlag) {
        if (!passcode.match(defaultPasscodeDigits)) {
            this.tap(UIAQuery.query(UIAQuery.Setup.PASSCODE_OPTIONS));
            if (sixDigitsFlag && passcode.match(PasscodePatterns.FOUR_DIGITS)) {
                this.tap(UIAQuery.query(UIAQuery.Setup.FOUR_DIGIT_NUMERIC_PASSCODE));
            } else if (!sixDigitsFlag && passcode.match(PasscodePatterns.SIX_DIGITS)) {
                this.tap(UIAQuery.query(UIAQuery.Setup.SIX_DIGIT_NUMERIC_PASSCODE));
            } else {
                this.tap(UIAQuery.query(UIAQuery.Setup.ALPHA_NUMERIC_PASSCODE));
            }
        }
    }

    /**
     * Enter passcode and click on next button if alphanumeric passcode
     * @param {string} passcode - Required provided number of digits in passcode to the given device
     */
    setup.enterPasscode = function enterPasscode(passcode) {
        var nextButton = UIAQuery.TOP_NAVBAR.andThen(UIAQuery.RIGHT_NAV_BUTTON.withPredicate("name == 'Next'")).isVisible().isEnabled();
        setup.typeString(passcode);
        //<rdar://problem/23073216> enterText() function fails when entering 6 digit/4 digit passcode as it first taps.
        //setup.enterText(passcode);
        if (isNaN(passcode)) {
            if (!this.waitUntilPresent(nextButton, 20)) {
                throw new UIAError('Next button never appeared after re-typing passcode for the device.');
            }
            this.tap(nextButton);
        }
    }

    /**
     * Use or don't use Siri
     *
     * @param {bool} useSiri - Optional if true use Siri, else don't
     * @param {object} heySiriSetup - Optional if true use Personalized Hey Siri, else don't
     * @param {string} heySiriSetup.tophatSpeakerIP - external audio speaker IP address
     * @param {integer} heySiriSetup.tophatSpeakerPort - external audio speaker port
     */
    setup.chooseSiri = function chooseSiri(useSiri, heySiriSetup) {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "VTUIEnrollTrainingViewController"'
        );
        if (useSiri) {
            setup.tap(UIAQuery.Setup.CONTINUE);
            // some older builds have a hey siri page (before 13A318)
            setup.setupPersonalizedHeySiri(heySiriSetup);
        } else {
            setup.tap(UIAQuery.Setup.SET_UP_LATER_BUTTON);
        }
        UIALogger.logMessage('Waiting up to 5 seconds for Siri view to disappear');
        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('Siri view did not disappear after 10 seconds');
        }
    }

    /**
     * Setup Personalized Hey Siri - REQUIRES SPECIAL SETUP WITH A SPEAKER COMPONENT
     *
     * @param {object} heySiriSetup - Optional if true use Personalized Hey Siri, else don't
     * @param {string} heySiriSetup.tophatSpeakerIP - external audio speaker IP address
     * @param {integer} heySiriSetup.tophatSpeakerPort - external audio speaker port
     */

    setup.setupPersonalizedHeySiri = function setupPersonalizedHeySiri(heySiriSetup) {
        utterances = [
                      'hey_siri.wav',
                      'hey_siri.wav',
                      'hey_siri.wav',
                      'hey_siri_whats_the_weather_like.wav',
                      'hey_siri_its_me.wav',
                      ]
        if (heySiriSetup && heySiriSetup.tophatSpeakerIP != '') {
            tophatspeaker.ip = heySiriSetup.tophatSpeakerIP;
            tophatspeaker.port = heySiriSetup.tophatSpeakerPort;
            for (step = 1; step <= 5; step++){
                    UIAUtilities.assert(
                                        setup.waitUntilPresent(UIAQuery.contains('%0 of 5'.format(step)), 10),
                                        'failed to enter expected PHS step %0'.format(step)
                                        )
                    target.delay(0.5);
                    tophatspeaker.speak(utterances[step-1]);
            }
            UIAUtilities.assert(
                setup.waitUntilPresent(
                    UIAQuery.contains('Hey Siri').andThen(UIAQuery.contains('Is Ready')), 10),
                    'failed to succesfully train hey siri'
            )


            setup.tapIfExists(UIAQuery.Setup.CONTINUE)
        }else{
            setup.tapIfExists(UIAQuery.Setup.SET_UP_HEY_SIRI_LATER);
        }
    }

    /**
     * Share or don't share App Analytics
     *
     * @param {bool} shareAppAnalytics - Optional if true share App Analytics with App Developers
     */
    setup.chooseAppAnalytics = function chooseAppAnalytics(shareAppAnalytics) {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "BuddyAppActivityController"'
        );

        this.handlingAlertsInline(UIAQuery.Setup.Alerts.DONT_RESTORE_SETTINGS, function() {
            if (shareAppAnalytics) {
                setup.tap(UIAQuery.Setup.SHARE_WITH_DEVS);
            } else {
                setup.tap(UIAQuery.Setup.DONT_SHARE);
            }
            this._dismissAlertWithQuery(UIAQuery.Setup.OK.isVisible());
        });

        var timeout = 20;
        UIALogger.logMessage('Waiting up to %0 seconds for the next view to appear...'.format(timeout));
        if (!thisViewDisappeared.wait(timeout)) {
            throw new UIAError('App Analytics page failed to disappear after %0 seconds'.format(timeout));
        }
    }

    /**
     * Choose a View
     *
     * @param {bool} useZoom - Optional if true use Display Zoom
     */
    setup.chooseView = function chooseView(useZoom) {
        setup.tap(UIAQuery.Setup.CHOOSE_A_VIEW);
        setup.chooseDisplayZoom(useZoom);
    }

    /**
     * Choose a Display Zoom
     *
     * @param {bool} useZoom - Optional if true use Display Zoom
     */
    setup.chooseDisplayZoom = function chooseDisplayZoom(useZoom) {
        this.handleBuddyPageWithWaiter(
            'PSMagnifyController',
            UIStateDescription.Setup.DISPLAY_ZOOM,
            20,
            function() {
                if (useZoom) {
                    this.tap(UIAQuery.Setup.ZOOMED);
                } else {
                    this.tap(UIAQuery.Setup.STANDARD);
                }
                this.tap(UIAQuery.Setup.NEXT);
            }.bind(this)
        );

    }

    /**
     * Use or don't use Find My iPhone/iPad
     *
     * @param {bool} chooseUseFindMyiPhone - Optional if true use Find My iPhone/iPad
     */
    setup.chooseFindMyiPhone = function chooseFindMyiPhone(chooseUseFindMyiPhone) {
        var hitNext = setup.tapIfExists(UIAQuery.Setup.NEXT, {timeout: 2});
        if (!hitNext) {
            if (chooseUseFindMyiPhone) {
                setup.tap(UIAQuery.Setup.USE_FIND_MY);
            } else {
                setup.tap(UIAQuery.Setup.DONT_USE_FIND_MY);
            }
        }
    }

    /**
     * Use or don't use iCloud
     *
     * @param {bool} chooseiCloud - Optional if true use iCloud
     */
    setup.chooseiCloud = function chooseiCloud(useiCloud) {
        if (useiCloud) {
            setup.tap(UIAQuery.Setup.USE_ICLOUD);
            setup.tap(UIAQuery.Setup.NEXT); //find my
        } else {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.DONT_USE_ICLOUD, function() {
                setup.tap(UIAQuery.Setup.DONT_USE_ICLOUD);
                setup.tap(UIAQuery.Setup.DONT_USE.isVisible());
            });

        }
    }

    /**
     * Use or don't use iCloud Drive
     *
     * @param {bool} chooseiCloudDrive - Optional if true use iCloud Drive
     */
    setup.chooseiCloudDrive = function chooseiCloudDrive(useiCloudDrive) {
        if (useiCloudDrive) {
            setup.tap(UIAQuery.Setup.UPGRADE_ICLOUD_DRIVE);
        } else {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.DONT_USE_ICLOUD_DRIVE, function() {
                setup.tap(UIAQuery.Setup.NOT_NOW_CELL.orElse(UIAQuery.Setup.TURN_OFF_ICLOUD_DRIVE));
                setup.tap(UIAQuery.Setup.CONTINUE);
            });
        }
    }

    /**
     * Use or don't use iCloud Keychain
     *
     * @param {bool} chooseiCloudKeychain - Optional if true use iCloud Keychain
     * @param {string} passcodeChoice - Optional "passcode" to use device passcode, creates different code by default
     */
    setup.chooseiCloudKeychain = function chooseiCloudKeychain(useiCloudKeychain, passcodeChoice) {
        var waiter = UIAWaiter.waiter('ViewDidDisappear');

        UIALogger.logMessage("Choose iCloud Keychain");
        if (useiCloudKeychain) {
            // setup.tapIfExists(UIAQuery.Setup.USE_ICSC);// saw this on non-fresh accounts
            // Use iPhone Passcode as iCloud Security Code?
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.ICLOUD_SECURITY_CODE, function() {
                setup.tap(UIAQuery.Setup.CONTINUE);
                // choice
                if (passcodeChoice && passcodeChoice === 'passcode') {
                    //<rdar://problem/20476611> remove me when fixed!!!
                    this._dismissAlertWithQuery(UIAQuery.Setup.USE_PASSCODE);
                } else if (passcodeChoice !== 'continue') {
                    //<rdar://problem/20476611> remove me when fixed!!!
                    this._dismissAlertWithQuery(UIAQuery.Setup.CREATE_DIFFERENT_CODE);
                }
            });
        } else {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.DONT_RESTORE_PASSWORDS, function() {
                setup.tapIfExists(UIAQuery.Setup.DONT_USE_ICLOUD_KEYCHAIN.orElse(UIAQuery.Setup.DONT_RESTORE_PASSWORDS));
                //<rdar://problem/20476611> remove me when fixed!!!
                this._dismissAlertWithQuery(UIAQuery.Setup.CONTINUE);
            });
        }

        if (!waiter.wait(5)) {
            throw new UIAError('Unable to proceed past iCloud keychain page.');
        }
    }

    /**
     * Create iCloud Security Code
     * @param {string} icsc - iCloud Security Code
     * @param {string} icscOptions - iCloud Security Code Advanced options. ("complex","random","don't use")
     *
     */
    setup.createiCloudSecurityCode = function createiCloudSecurityCode(icsc, icscOptions) {
        if (!icscOptions) {
            UIALogger.logMessage("Create iCloud security code");
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.USE_CODE, function() {
                setup.typeString(icsc);
                this.tap(UIAQuery.Setup.USE_CODE);
            });
            setup.typeString(icsc);
        } else {
            setup.tap(UIAQuery.Setup.ADVANCED_OPTIONS);
            setup.advancedSecurityCode(icsc,icscOptions);
        }
    }

    /**
     * Create an Advanced iCloud Security Code
     * @param {string} icsc - iCloud Security Code
     * @param {string} icscOptions - iCloud Security Code Advanced options. ("complex","random","don't use")
     *
     */
    setup.advancedSecurityCode = function advancedSecurityCode(icsc, icscOptions) {

        UIALogger.logMessage("Create Advanced iCloud security code");
        var appAnalyticsWaiter = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass CONTAINS "BuddyAppActivity"',
            }
        );
        if (icscOptions === 'complex') {
            // complex
            setup.tap(UIAQuery.Setup.COMPLEX_SECURITY_CODE);
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.USE_CODE, function() {
                setup.typeString(icsc);
                setup.tap(UIAQuery.Setup.NEXT);
                //<rdar://problem/20476611> remove me when fixed!!!
                this._dismissAlertWithQuery(UIAQuery.Setup.USE_CODE);
            });
            setup.typeString(icsc);
            setup.tap(UIAQuery.Setup.NEXT);
        } else if (icscOptions == 'random') {
            // random
            setup.tap(UIAQuery.Setup.RANDOM_SECURITY_CODE);
            var securityCode = setup.inspect(UIAQuery.contains('UIAccessibilityTextFieldElement')).value
            var codeFile = new UIAFile('/tmp/verificationcode.json');
            codeFile.open('w','unicode');
            codeFile.write(JSON.stringify({code: securityCode}));
            codeFile.close();
            setup.tap(UIAQuery.Setup.NEXT);

            setup.typeString(securityCode);
            setup.tap(UIAQuery.Setup.NEXT);
        } else {
            this.handlingAlertsInline(UIAQuery.Setup.Alerts.USE_CODE, function() {
                setup.tap(UIAQuery.Setup.DONT_CREATE_SECURITY_CODE);
                //<rdar://problem/20476611> remove me when fixed!!!
                this._dismissAlertWithQuery(UIAQuery.Setup.SKIP_CODE);
            });
        }
        UIALogger.logMessage('Waiting up to 30 seconds for the App Analytics page to appear...');
        if (!appAnalyticsWaiter.wait(30)) {
            UIALogger.logMessage('The App Analytics page failed to appear after 30 seconds');
        }
    }

    /**
     * Enter Keychain Phone Number
     *
     */
    setup.keychainPhoneNumber = function keychainPhoneNumber() {
        UIALogger.logMessage("Keychain Phone Number");
        var phoneNumber = target.phoneNumber();
        UIALogger.logMessage("Device phone number: %0".format(phoneNumber));
        var number = phone.returnCleanedNumber(phoneNumber);
        setup.enterText(UIAQuery.textFields(),number);
        setup.tap(UIAQuery.Setup.NEXT);
    }

    /**
     * Choose how people contact you with FaceTime
     */
    setup.chooseFaceTime = function chooseFaceTime() {
        // should eventually handle "Let Other People Reach You At:" selection
        setup.tap(UIAQuery.Setup.NEXT);
    }

    /**
     * Description page for Apple Pay
     */
    setup.applePayDesc = function applePayDesc(useApplePay) {
        this.handleBuddyPageWithWaiter(
            'PKPaymentSetupAssistantRegistrationViewController',
            UIStateDescription.Setup.APPLE_PAY_DESC,
            15,
            function() {
                if (useApplePay) {
                    this.tap(UIAQuery.Setup.CONTINUE);
                } else {
                    this.tap(UIAQuery.Setup.SET_UP_LATER_BUTTON);
                }
            }.bind(this)
        );

    }

    /**
     * Use or don't use Apple Pay
     *
     * @param {bool} chooseApplePay - Optional if true use Apple Pay
     */
    setup.chooseApplePay = function chooseApplePay(useApplePay) {
        if (useApplePay) {
            setup.tap(UIAQuery.Setup.ADD_NEW_CREDIT_CARD);
            return;
        }

        var thisViewDisappeared = UIAWaiter.withPredicate(
            "ViewDidDisappear",
             "controllerClass == 'PKPaymentCameraCaptureViewController'"
        );

        setup.tap(UIAQuery.Setup.SKIP_APPLE_PAY.orElse(UIAQuery.Setup.SET_UP_LATER_IN_SETTINGS));
        UIALogger.logMessage('Waiting up to 10 seconds for the next view to appear...');
        if (!thisViewDisappeared.wait(10)) {
            throw new UIAError('Failed to handle Apple Pay Page.');
        }
    }

    /**
     * Configuration page for Enterprise
     */
    setup.enterpriseConfiguration = function enterpriseConfiguration(skipConfiguration) {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass contains "%0"'.format(UIStateDescription.Setup.ENT_CONFIG_DISCLOSURE),
            }
        );

        // Wait for the next button to appear
        setup.waitUntilPresent(UIAQuery.Setup.NEXT, 10);

        if (skipConfiguration === false) {
            setup.tapIfExists(UIAQuery.Setup.APPLY_CONFIGURATION);
        } else {
            setup.tapIfExists(UIAQuery.Setup.SKIP_CONFIGURATION);
        }

        setup.tap(UIAQuery.Setup.NEXT);

        if (!thisViewDisappeared.wait(300)) {
            UIALogger.logError('Waited for 300 seconds at the enterprise disclosure page');
        } else {
            UIALogger.logMessage('Made it past the enterprise disclosure page');
        }
    }

    /**
     * Configuration login page for Enterprise
     *
     * @param {string} configurationUsername - Enterprise username
     * @param {string} configurationPassword - Enterprise password
     */
    setup.enterpriseLogin = function enterpriseLogin(configurationUsername, configurationPassword) {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass contains "%0"'.format(UIStateDescription.Setup.ENT_CONFIG_LOGIN),
            }
        );

        var installationViewAppeared = UIAWaiter.waiter(
            'ViewDidAppear', {
                predicate: 'controllerClass contains "%0"'.format(UIStateDescription.Setup.ENT_CONFIG_INSTALL),
            }
        );

        var installationViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass contains "%0"'.format(UIStateDescription.Setup.ENT_CONFIG_INSTALL),
            }
        );

        setup.enterText(UIAQuery.Setup.TEXT_FIELD, configurationUsername);
        setup.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD, configurationPassword);
        setup.tap(UIAQuery.Setup.NEXT);

        if (!thisViewDisappeared.wait(300)) {
            UIALogger.logError('Waited for 300 seconds at the enterprise login page');
        } else {
            UIALogger.logMessage('Made it past the enterprise login page');
        }

        if (installationViewAppeared.wait(1)) {
            if (!installationViewDisappeared.wait(300)) {
                UIALogger.logError('Waited for 300 seconds at the enterprise installation page');
            } else {
                UIALogger.logMessage('Made it past the enterprise installation page');
            }
        }
    }

    /**
     * Handle the Cloud Configuration Retrieval Page
     */
    setup.cloudConfigRetrievalPage = function cloudConfigRetrievalPage() {
        UIALogger.logMessage("We are now on the Cloud Retrieval Page.");
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
            predicate: 'controllerClass == "CloudConfigurationRetrievalController"',
            }
        );
        if (!thisViewDisappeared.wait(30)) {
            UIALogger.logError('Waited for 30 seconds on Cloud Retrieval Page, with no progress. Tapping "Back" to try again.');
            setup.tap(UIAQuery.Setup.BACK);
        } else {
            UIALogger.logMessage('Made it past the ActivationController');
        }
    }

    /**
     * Handle the Activation Page
     */
    setup.activationPage = function activationPage() {
        UIALogger.logMessage("We are now on the Activation Page.");
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "ActivationController"',
            }
        );
        if (!thisViewDisappeared.wait(120)) {
            UIALogger.logError('Waited for 120 seconds on Activation Page, with no progress. Tapping "Back" to try again.');
            setup.tap(UIAQuery.Setup.BACK);
        } else {
            UIALogger.logMessage('Made it past the ActivationController');
        }
    }


    /**
     * Dismiss the alert presented when you press the menu button.
     */
    setup.dismissActionSheet = function dismissActionSheet() {
        if (this.exists(UIAQuery.actionSheets())) {
            UIALogger.logMessage('Dismissing action sheet');
            //<rdar://problem/20476611> remove me when fixed!!!
            this._dismissAlertWithQuery(UIAQuery.Setup.CONTINUE.orElse(UIAQuery.Setup.CANCEL));
        } else if (this.exists(UIAQuery.alerts())) {
            UIALogger.logMessage('Dismissing alert titled: "%0"'.format(this.inspect(UIAQuery.alerts().isVisible()).controllerTitle));
            this._dismissAlertWithQuery(UIAQuery.Setup.CONTINUE.orElse(UIAQuery.Setup.CANCEL).orElse(UIAQuery.Setup.OK));
        }
    }

    /**
     * Could not Activate Device - Try Again
     */
    setup.tryAgain = function tryAgain() {
        setup.tap(UIAQuery.Setup.TRY_AGAIN);
    }

    /**
     * Continue pass Device Ready
     */
    setup.continueThroughDeviceReady = function continueThroughDeviceReady() {
        var deviceReadyPageDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "RUIPage"',
            }
        );
        // tracking iPads with no SIM detected during setup <rdar://problem/23471122>
        var simInfo = this.inspect(UIAQuery.contains('After inserting a new SIM'));
        if (simInfo) {
            // we don't want to fail setup but we would like to track this as an error
            UIALogger.logError(new UIAError('SIM message found, "%0"'.format(simInfo.name)));
        }
        this.tap(UIAQuery.Setup.CONTINUE);

        if (!deviceReadyPageDisappeared.wait(5)) {
            UIALogger.logError('The Device Ready page took longer than 5 seconds to disappear.');
        }
    }

    /**
     * Continue pass iPhone/iPad/ect Activated
     */
    setup.continueThroughDeviceActivated = function continueThroughDeviceActivated() {
        var pageInfo = this.inspect(UIAQuery.application());

        if (pageInfo.exists(UIAQuery.Setup.DEVICE_ACTIVATED)
            && pageInfo.exists(UIAQuery.contains('Device is activated on'))) {
                UIALogger.logError(
                    new UIAError('Unexpected page. Likely lab issue. Check activation policy on device."%0"')
                );
        }

        this.tap(UIAQuery.Setup.CONTINUE);
    }

    /**
     * Throw an error on the Device Unknown page
     */
    setup.deviceUnknown = function deviceUnknown() {
        throw new UIAError('Landed on "Device Unknown" page of Buddy');
    }

    /**
     * Sim Required
     */
    setup.simRequired = function simRequired() {
        throw new UIAError(
            'No Sim detected on device. Likely lab issue. Get device name and physically check for sim.'
        );
    }

    /**
     * iMessage and FaceTime setup (China specific)
     */
    setup.iMessageAndFacetime = function iMessageAndFacetime(usePhoneNumber) {
        var thisViewDisappeared = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "BuddyPhoneNumberPermissionController"'
        );

        UIALogger.logMessage('usePhoneNumber value is : [%0]'.format(usePhoneNumber));
        //Wait for Continue button in iMessage & FaceTime pane to appear
        setup.waitUntilPresent(UIAQuery.Setup.CONTINUE.isVisible(), 5)
        if (usePhoneNumber) {
            this.tap(UIAQuery.Setup.CONTINUE);

        } else {
            this.tap(UIAQuery.Setup.NOT_NOW_BUTTON);
        };

        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('The iMessage & FaceTime setup page took longer than 5 seconds to disappear.');
        }
    }

    /**
     * Step through the Profile Picture setup pages of Buddy
     *
     * @param {string} profilePictureSelection – If nothing is passed, we skip the profile picture section
     *                                           If 'monogram' is passed, we use the default monogram
     *                                           'avatar' and 'photo' are not yet supported configruations
     */
    setup.profilePictureSetup = function profilePictureSetup(profilePictureSelection) {
        if (!profilePictureSelection) {
            throw new UIAError('Failed to skip Profile Picture setup in Buddy');
        } else if (profilePictureSelection === SetupConstants.ProfilePictureSelection.MONOGRAM) {
            this.tap(UIAQuery.buttons('Use a Monogram').orElse(UIAQuery.Setup.NEXT));
        } else {
            throw new UIAError('The only supported profile picture configuration is a monogram');
        }
    }

    /**
    * Profile Picture Intro page of Buddy – tap either 'Set Up Later' or 'Continue'
    *
    * @param {string} profilePictureSelection – If nothing is passed, we skip the profile picture section
    *                                           Otherwise, we tap 'Continue'
    */
    setup.profilePictureIntro = function profilePictureIntro(profilePictureSelection) {
        this.handleBuddyPageWithWaiter(
            'PRLikenessIntroViewController',
            UIStateDescription.Setup.PROFILE_PICTURE_INTRO,
            5,
            function() {
                if (!profilePictureSelection) {
                    this.tap(UIAQuery.Setup.SET_UP_LATER_BUTTON);
                } else {
                    this.tap(UIAQuery.Setup.CONTINUE);
                }
            }.bind(this)
        );
    }

    /**
    * Tap 'Continue' on the True Tone Display page of Buddy
    */
    setup.handleTrueToneDisplayPage = function handleTrueToneDisplayPage() {
        var timeout = 60;
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyHarmonyController"',
            }
        );

        this.tap(UIAQuery.Setup.CONTINUE);

        if (!thisViewDisappeared.wait(timeout)) {
            throw new UIAError('The True Tone Display page took longer than %0 seconds to disappear.'.format(timeout));
        }
    }

    /**
     * Handle the 'new home button' intro page of Buddy
     */
    setup.newHomeButtonIntro = function newHomeButtonIntro(homeButtonChoice) {
        this.handleBuddyPageWithWaiter(
            'BuddyHomeButtonController',
            UIStateDescription.Setup.NEW_HOME_BUTTON_INTRO,
            5,
            function() {
                if (homeButtonChoice) {
                    this.tap(UIAQuery.Setup.GET_STARTED);
                } else {
                    this.tap(UIAQuery.Setup.CUSTOMIZE_HOME_BUTTON_LATER);
                }
            }.bind(this)
        );
    }

    /**
     * Handle the home button customization page of Buddy
     */
    setup.customizeHomeButton = function customizeHomeButton(homeButtonChoice) {
        this.handleBuddyPageWithWaiter(
            'PSUIHomeButtonCustomizeController',
            UIStateDescription.Setup.CUSTOMIZE_HOME_BUTTON,
            5,
            function() {
                var homeButtonChoiceQuery = SetupConstants.HomeButtonChoiceMap[homeButtonChoice] || null
                if (homeButtonChoiceQuery) {
                    this.tap(homeButtonChoiceQuery);
                    this.tap(UIAQuery.Setup.NEXT);
                } else if (homeButtonChoice) {
                    throw new UIAError('Invalid home button choice - valid options are "light, medium, strong"');
                } else {
                    throw new UIAError('Failed to skip the home button customization page in Buddy');
                }
            }.bind(this)
        );
    }

    /**
     * Handle the "Help Apple improve its products and services by automatically
     * sending diagnostic and usage data" page. Note that this only exists on
     * non-internal installs.
     */
    setup.allowAppleDiagnostics = function allowAppleDiagnostics(shouldAllowDiagnostics) {
        this.handleBuddyPageWithWaiter(
            'BuddyDiagnosticsController',
            UIStateDescription.Setup.BUDDY_DIAGNOSTICS,
            5,
            function() {
                if (shouldAllowDiagnostics) {
                    this.tap(UIAQuery.Setup.SEND_TO_APPLE.orElse(UIAQuery.Setup.SHARE_WITH_APPLE));
                } else {
                    this.tap(UIAQuery.Setup.DONT_SEND.orElse(UIAQuery.Setup.DONT_SHARE));
                }
            }.bind(this)
        );
    }

    /**
     * Handle the "iPhone Analytics" page. Note that this only exists on
     * Developer installs.
     */
    setup.allowAppleSEEDDiagnostics = function allowAppleSEEDDiagnostics() {
        this.handleBuddyPageWithWaiter(
            'BuddySeedDiagnosticsController',
            UIStateDescription.Setup.BUDDY_SEED_DIAGNOSTICS,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Get Started
     */
    setup.getStarted = function getStarted() {
        var predicate = 'bundleID == "%0" AND state == "Terminated"'.format(
            this.bundleID()
        );
        var setupTerminated = UIAWaiter.waiter(
            'ApplicationStateChanged', {
                predicate: predicate,
        });

        if (!this.tapIfExists(UIAQuery.Setup.GET_STARTED.orElse(UIAQuery.Setup.CONTINUE))) {
            UIALogger.logWarning("Failed to tap buttons to end Buddy. Trying last resort...");
            this.swipeFromBottomEdge();
        }
        UIALogger.logMessage('Waiting up to 10 seconds for setup to terminate');
        if (setupTerminated.wait(10)) {
            return true;
        } else {
            // workaround rdar://problem/20099207
            UIALogger.logError('Setup failed to suspend after tapping "Get Started"');
            UIALogger.logMessage('Wait up to 30 seconds for us to get to SpringBoard');
            return springboard.waitUntilPresent(UIAQuery.query('SBRootIconListView'), 0.30);
        }
    }

    /**
     * Chooses a iCloud restore backup.
     *
     * @param {string} backupVersion - Backup version. If nothing is passed, we use the
     *                      first backup version listed. If a value is passed, a contains
     *                      predicate is made out of it.
     *                      e.g. 'October 29, 2013, at 5:57 AM' would match on 'October 29, 2013, at 5:57 AM'
     *                      but so would: 'October', 'October 29', '5:57', ect.
     */
    setup.restoreFromiCloudBackup = function restoreFromiCloudBackup(backupVersion) {
        var waiter = UIAWaiter.withPredicate(
            'ViewDidDisappear',
            'controllerClass == "RestoreFromBackupController"'
        );

        // check if any backups exist first
        if (this.exists(UIAQuery.withPredicate('any identifiers contains[c] "No backups available"'))) {
            throw new UIAError('No restore backup exists to choose from.');
        }

        if (!backupVersion) {
            // if no backup version is given, we will choose the first one
            UIALogger.logMessage('No back version was passed. Using first version listed.');
            this.tap(UIAQuery.tableCells().first().below(UIAQuery.withPredicate('any identifiers contains[c] "Choose backup"')));
        } else if (this.tapIfExists(UIAQuery.tableCells().andThen(UIAQuery.contains(backupVersion)))) {
            // no-op
        } else {
            // catch all case
            throw new UIAError("Unable to choose a backup restore verion with version: '%0'.".format(backupVersion));
        }

        if (!waiter.wait(60)) {
            throw new UIAError('Failed to choose backup.');
        }
    }

    /**
     * Waits for a device to finish restoring from backup.
     */
    setup.waitForRestoreCompletion = function waitForRestoreCompletion() {
        // Wait 30 seconds to see if the "Cannot Backup" alert appears
        var cannotBackup = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerTitle == "Cannot Backup"'
        );

        this.handlingAlertsInline(UIAQuery.alerts("Cannot Backup"), function() {
            if (cannotBackup.wait(30)) {
                throw new UIAError('Unable to restore from backup.');
            } else {
                UIALogger.logMessage('Trusting that the restore will continue. Exiting Setup Device test to avoid errors when CAM drops during restore.');
            }
        })
    }

    /**
     * Continue with mini buddy after backup and restore
     */
    setup.miniBuddyContinue = function miniBuddyContinue() {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
            predicate: 'controllerClass == "BuddyRestoreFinishedController"',
            }
        );
        UIALogger.logMessage('Restore Finished. Continue.');
        this.tap(UIAQuery.Setup.CONTINUE);

        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('Waited for 5 seconds on Mini-Buddy Restore Finish Page, with no progress. Tapping "Back" to try again.');
        }
    }

    /**
     * Shared iPad create new password
     *
     * @param {string} sharedCurrentPasscode - Required current passcode of MAID account
     * @param {string} sharedNewPasscode - Required new passcode of MAID account
     */
    setup.sharediPadCreatePasscode = function sharediPadCreatePasscode(sharedCurrentPasscode, sharedNewPasscode) {
        var waiter = UIAWaiter.withPredicate(
             'ViewDidDisappear',
             'controllerClass == "BuddyAppleIDPasswordChangeController"'
        );
        this.enterText(UIAQuery.secureTextFields().atIndex(1), sharedCurrentPasscode);
        this.enterText(UIAQuery.secureTextFields().atIndex(3), sharedNewPasscode);
        this.enterText(UIAQuery.secureTextFields().atIndex(5), sharedNewPasscode);
        this.tap("right-nav-button");
   }

    /**
     * Shared iPad changing new password appears when setting the new password is in progress
     */
    setup.sharediPadChangingPasscode = function sharediPadChangingPasscode() {
        var thisViewDisappeared = UIAWaiter.withPredicate(
              'ViewDidDisappear',
              'controllerClass == "RUIPage"'
        );
        if (!thisViewDisappeared.wait(30)) {
            UIALogger.logError('Changing the passcode took longer than 30 seconds.');
        }
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Helpers                                                             */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Throws error for activation with relavant info.
     */
    setup.reportActivationLockFailure = function reportActivationLockFailure() {
        var link = this.inspect(UIAQuery.Setup.CURRENTLY_LINKED);
        var linkName = link ? link.name : '(unknown)';
        var errorMessage = 'Device is activation locked for account %0'.format(linkName);
        throw new UIAError(errorMessage, {identifier: 'Device is Activation Locked'});
    }

    /**
     *  Handles activation lock by entering appleID and appleIDPassword
     *
     * @param {string} appleID - Required appleID
     * @param {string} appleIDPassword - Required password for the Apple ID
     */
    setup.handleActivationLock = function handleActivationLock(appleID, appleIDPassword, stateHistory) {
        // Sanity check
        UIAUtilities.assert(
            typeof appleID === 'string' && appleID.length > 0,
                "The parameter 'appleID' must be a positive length string!"
        );
        UIAUtilities.assert(
            typeof appleIDPassword === 'string' && appleIDPassword.length > 0,
                "The parameter 'appleIDPassword' must be a positive length string!"
        );

        UIALogger.logMessage('Device is activation locked. Entering credentials: %0 %1'.format(appleID, appleIDPassword));
        var waiter = UIAWaiter.withPredicate(
            'ViewDidAppear',
            'controllerClass = "BuddyLocationServicesController"'
        );
        this.enterText(UIAQuery.Setup.TEXT_FIELD, appleID);
        this.enterText(UIAQuery.Setup.SECURE_TEXT_FIELD, appleIDPassword);
        this.tap(UIAQuery.Setup.NEXT);

        if (!waiter.wait(60)) {
            UIALogger.logWarning('Unable to bypass activation lock.');
        }

        stateHistory.ACTIVATION_LOCK_APPEAR = true;
    }

    /**
     * Throws error for activation with relavant info.
     */
    setup.reportAccountLockedFailure = function reportAccountLockedFailure() {
        throw new UIAError('Apple ID is locked');
    }

    setup.logStateHistory = function logStateHistory(stateHistory) {
        var stateStrings = Object.keys(stateHistory).map(
            function (key) {
                return '\t%0:%1'.format(key, stateHistory[key]);
            }
        );
        UIALogger.logDebug('Visited states:\n%0'.format(stateStrings.join('\n')));
    }

    /**
     * Handle Buddy Proximity Setup page, which asks whether you'd like to transfer settings from an old iOS device using physical proximity
     */
    setup.buddyProximitySetup = function buddyProximitySetup() {
        var thisViewDisappeared = UIAWaiter.waiter(
            'ViewDidDisappear', {
                predicate: 'controllerClass == "BuddyProximitySetupController"',
            }
        );
        this.tap(UIAQuery.Setup.SET_UP_MANUALLY);

        if (!thisViewDisappeared.wait(5)) {
            UIALogger.logError('Buddy Proximity Setup page failed to disappear after 5 seconds');
        }
    }

    /**
     * Handle Buddy Inline Software Udate, which asks whether you'd like to update to a newer version of iOS from within Buddy
     */
    setup.inlineSoftwareUpdate = function inlineSoftwareUpdate() {
        this.handleBuddyPageWithWaiter(
            'BuddyInlineSoftwareUpdateController',
            UIStateDescription.Setup.INLINE_SOFTWARE_UPDATE,
            5,
            function() {
                this.tap(UIAQuery.Setup.NOT_NOW_BUTTON);
            }.bind(this)
        );
    }

    /**
     * Handle Apple Watch migration page, which asks whether you'd like to pair your phone with a previously pared Apple Watch
     */
    setup.appleWatchMigration = function appleWatchMigration() {
        this.handleBuddyPageWithWaiter(
            'BPSWatchMigrationController',
            UIStateDescription.Setup.APPLE_WATCH_MIGRATION,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Cover Sheet On-Boarding page, which explains how to use the
     * Cover Sheet and Control Center features
     */
    setup.coverSheetOnBoarding = function coverSheetOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyCoverSheetOnBoardingController',
            UIStateDescription.Setup.COVER_SHEET_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Multitasking On-Boarding page, which explains how to use the
     * Multitasking and Control Center features
     */
    setup.multitaskingOnBoarding = function multitaskingOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyMultitaskingOnBoardingController',
            UIStateDescription.Setup.MULTITASKING_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Dock On-Boarding page, which explains how to use the Dock
     */
    setup.dockOnBoarding = function dockOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyDockOnBoardingController',
            UIStateDescription.Setup.DOCK_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Go Home On-Boarding page, which explains how to use the
     * Go Home features
     */
    setup.goHomeOnBoarding = function goHomeOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyGoHomeOnBoardingController',
            UIStateDescription.Setup.GO_HOME_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Apple Pay On-Boarding page, which explains how to use the
     * Apple Pay features
     */
    setup.applePayOnBoarding = function applePayOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyApplePayOnBoardingController',
            UIStateDescription.Setup.APPLE_PAY_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle Siri On-Boarding page, which explains how to use the
     * Siri features
     */
    setup.siriOnBoarding = function siriOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddySiriOnBoardingSplashController',
            UIStateDescription.Setup.SIRI_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle App Switcher On-Boarding page
     */
    setup.appSwitcherOnBoarding = function appSwitcherOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyApplicationSwitcherOnBoardingSplashController',
            UIStateDescription.Setup.APP_SWITCHER_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Handle App Switcher On-Boarding page
     */
    setup.controlCenterOnBoarding = function controlCenterOnBoarding() {
        this.handleBuddyPageWithWaiter(
            'BuddyControlCenterOnBoardingSplashController',
            UIStateDescription.Setup.CONTROL_CENTER_ON_BOARDING,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /** Handle Privacy Splash page */
    setup.privacySplash = function privacySplash() {
        this.handleBuddyPageWithWaiter(
            'OBPrivacySplashController',
            UIStateDescription.Setup.PRIVACY_SPLASH,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * All Pane Verification
     * Setup Assistant Pane Verification
     */
    setup.verifyPanes = function verifyPanes(options, resultingPanes) {

        var blacklistedPanesPresentList = setup.verifyBlacklistPanesDontExist(options, resultingPanes);

        var whitelistedPanesNotPresentList = setup.verifyWhitelistPanesExist(options, resultingPanes);

        if (options.failForUnknownPanes) {
            var unknownPanesPresentList = setup.getUnknownPanes(options, resultingPanes);
        } else {
            var unknownPanesPresentList = ""
        }

        var sequencedPanesIncorrectList = setup.verifyPaneSequence(options, resultingPanes);

        UIALogger.logMessage('The blacklisted panes are: %0'.format(options.blacklistedPanes));
        UIALogger.logMessage('The whitelisted panes are: %0'.format(options.whitelistedPanes));
        UIALogger.logMessage('The sequenced panes are: %0'.format(options.sequencedPanes));
        UIALogger.logMessage('The resulting panes are: %0'.format(resultingPanes));

        var paneVerificationFailure = false;

        var summary = ""

        if (blacklistedPanesPresentList.length > 0) {
            summary += '\n' + '***ERROR*** Blacklisted panes appeared: ' + blacklistedPanesPresentList + '\n'
            paneVerificationFailure = true;
        } else {
            summary += '\n' + '***SUCCESS*** Blacklist successful for: ' + options.blacklistedPanes + '\n'
        }

        if (whitelistedPanesNotPresentList.length > 0) {
            summary += '\n' + '***ERROR*** The following Whitelisted panes did not appear: ' + whitelistedPanesNotPresentList + '\n'
            paneVerificationFailure = true;
        } else {
            summary += '\n' + '***SUCCESS*** Whitelist successful for: ' + options.whitelistedPanes + '\n'
        }

        if (unknownPanesPresentList.length > 0) {
            summary += '\n' + '***ERROR*** Unknown panes appeared: ' + unknownPanesPresentList + '\n'
            paneVerificationFailure = true;
        } else {
            summary += '\n' + '***SUCCESS*** Unknown panes successful ' + '\n'
        }

        if (sequencedPanesIncorrectList.length > 0) {
            summary += '\n' + '***ERROR*** The sequence in which these panes appeared are incorrect: ' + sequencedPanesIncorrectList + '\n'
            paneVerificationFailure = true;
        } else {
            summary += '\n' + '***SUCCESS*** Sequence of panes successfully appeared for: ' + options.sequencedPanes + '\n'
        }

        if (resultingPanes.length > 0) {
            summary += '\n' + 'Panes that actually appeared:' + resultingPanes + '\n'
        }

        if (paneVerificationFailure == true) {
            throw new UIAError('Pane validation failed due to: \n %0'.format(summary));
        } else {
            UIALogger.logMessage('Successfully passed buddy pane validations completely');
        }
    }

    /**
     * Blacklist Pane Verification, which verifies blacklisted panes do not appear
     * Setup Assistant Pane Verification
     */
    setup.verifyBlacklistPanesDontExist = function verifyBlacklistPanesDontExist(args, resultingPanes) {
        var blacklistedPanesPresentList = ""
        for (pane in args.blacklistedPanes) {
            if (resultingPanes.indexOf(args.blacklistedPanes[pane]) !== -1) {
                UIALogger.logWarning('Blacklisted pane appeared: %0'.format(args.blacklistedPanes[pane]))
                blacklistedPanesPresentList += args.blacklistedPanes[pane] + ',';
            } else {
                UIALogger.logMessage('Did not find blacklisted pane: %0'.format(args.blacklistedPanes[pane]))
            }
        }
        return blacklistedPanesPresentList
    }

    /**
     * Whitelist Pane Verification, which verifies whitelisted panes do appear
     * Setup Assistant Pane Verification
     */
    setup.verifyWhitelistPanesExist = function verifyWhitelistPanesExist(args, resultingPanes) {
        var whitelistedPanesNotPresentList = ""
        for (pane in args.whitelistedPanes) {
            if (resultingPanes.indexOf(args.whitelistedPanes[pane]) !== -1) {
                UIALogger.logMessage('Successfully found whitelisted pane: %0'.format(args.whitelistedPanes[pane]))
            } else {
                UIALogger.logWarning('Whitelisted pane did not appear: %0'.format(args.whitelistedPanes[pane]))
                whitelistedPanesNotPresentList += args.whitelistedPanes[pane] + ',';
            }
        }
        return whitelistedPanesNotPresentList
    }

    /**
     * Unknown Pane Verification, which gets all unknown panes that are not in the whitelist
     * Setup Assistant Pane Verification
     */
    setup.getUnknownPanes = function getUnknownPanes(args, resultingPanes) {
        var unknownPanesPresentList = ""
        for (pane in resultingPanes) {
            if (resultingPanes[pane] == UIStateDescription.Setup.CLOUD_CONFIG_RETRIEVAL){
                UIALogger.logMessage('Skipping over retrieving configuration pane for identifying unknown panes since this appears intermittently')
            } else if (args.whitelistedPanes.indexOf(resultingPanes[pane]) == -1) {
                UIALogger.logWarning('Pane appeared and was not in whitelist: %0'.format(resultingPanes[pane]))
                unknownPanesPresentList += resultingPanes[pane] + ',';
            } else {
                UIALogger.logMessage('Pane appeared and was in whitelist: %0'.format(resultingPanes[pane]))
            }
        }
        return unknownPanesPresentList
    }

    /**
     *Sequence Pane Verification, which verifies order panes appear is correct
     * Setup Assistant Pane Verification
     */
    setup.verifyPaneSequence = function verifyPaneSequence(args, resultingPanes) {
        var sequencedPanesIncorrectList = ""
        var lastPaneNumber = 0
        var valid = true
        for (i = 0; i < args.sequencedPanes.length; i++) {
            for (j=lastPaneNumber; j <= resultingPanes.length; j++) {
                if (args.sequencedPanes[i] == resultingPanes[j]) {
                    UIALogger.logMessage('Found a match for: %0'.format(args.sequencedPanes[i]))
                    lastPaneNumber = j+1
                    break
                } else if (j >= resultingPanes.length) {
                    UIALogger.logWarning('Sequence of pane incorrect or did not find it at all for %0'.format(args.sequencedPanes[i]))
                    sequencedPanesIncorrectList += args.sequencedPanes[i] + ','
                    break
                }
            }
        }
        return sequencedPanesIncorrectList
    }

    /**
     * Handle whether we should enable automatic software updates
     */
    setup.handleAutoUpdate = function handleAutoUpdate(autoUpdate) {
        //<rdar://problem/43578250> Remove Workaround for <rdar://problem/42504154> when it gets fixed
        this.handleBuddyPageWithWaiter(
            'BuddyAutoUpdateController',
            UIStateDescription.Setup.AUTO_UPDATE,
            60,
            function() {
                if (autoUpdate) {
                    this.tap(UIAQuery.Setup.CONTINUE);
                } else {
                    this.tap(UIAQuery.buttons().contains('Manually'));
                }
            }.bind(this)
        );
    }
    /**
     * Enable or setup later ScreenTime
     * @param {bool} enableScreenTime - Required if true enable Screen services, else disable
     */
    setup.setupScreenTime = function setupScreenTime(enableScreenTime) {
        this.handleBuddyPageWithWaiter(
            'STSetupAssistantViewController',
            UIStateDescription.Setup.SCREEN_TIME,
            5,
            function() {
                if (enableScreenTime) {
                    // <rdar://problem/41438149> Remove Workaround in ScreenTime function in Setup.js when 41426218 is fixed
                    this.tap(UIAQuery.Setup.CONTINUE.orElse(UIAQuery.buttons().contains("Continue")));
                } else {
                    this.tap(UIAQuery.Setup.SET_UP_LATER_IN_SETTINGS);
                }
            }.bind(this)
        );
    }

    /**
     * Set up cellular
     */
    setup.setUpCellular = function setUpCellular() {
        this.handleBuddyPageWithWaiter(
            'TSAddCellularPlanViewController',
            UIStateDescription.Setup.SET_UP_CELLULAR,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /**
     * Set cellular choice
     */
    setup.setCellularChoice = function setCellularChoice(cellularChoice) {
        this.handleBuddyPageWithWaiter(
            'TSCellularPlanUsesViewController',
            UIStateDescription.Setup.SET_CELLULAR_CHOICE,
            5,
            function() {
                if (!cellularChoice) {
                    UIALogger.logMessage('No argument given for the default cellular line, defaulting to "Primary"');
                    this.tap(SetupConstants.CellularChoiceMap['primaryDefault']);
                }
                else {
                    this.tap(SetupConstants.CellularChoiceMap[defaultCellularChoice]);
                }
                this.tap(UIAQuery.CONTINUE_BUTTON);
            }.bind(this)
        );
    }

    /**
     * Cellular plan labels
     */
    setup.cellularPlanLabels = function cellularPlanLabels() {
        this.handleBuddyPageWithWaiter(
            'TSCellularPlanLabelsViewController',
            UIStateDescription.Setup.CELLULAR_PLAN_LABELS,
            5,
            function() {
                this.tap(UIAQuery.Setup.CONTINUE);
            }.bind(this)
        );
    }

    /** Cellular plan iMessage options */
    setup.cellularPlaniMessage = function cellularPlaniMessage() {
        this.handleBuddyPageWithWaiter(
            'TSCellularPlanIMessageViewController',
            UIStateDescription.Setup.CELLULAR_PLAN_LABELS,
            5,
            function() {
                this.tap(UIAQuery.buttons("Don't Add"));
            }.bind(this)
        );
    }

    /**  Select D2D choice on target device */
    setup.d2dTargetChoice = function d2dTargetChoice(d2dChoice) {
        this.handleBuddyPageWithWaiter(
            'BuddyDeviceMigrationController',
            UIStateDescription.Setup.D2D_TARGET_MIGRATION_CHOICE,
            30,
            function() {
                var d2dChoiceQuery = SetupConstants.d2dChoiceMap[d2dChoice] || null
                if (d2dChoiceQuery) {
                    this.tap(d2dChoiceQuery);
                } else if (d2dChoice) {
                    throw new UIAError('Invalid D2D migration choice - your only options are "start" or "other"');
                } else {
                    this.tap(UIAQuery.Setup.D2D_OTHER);
                }
            }.bind(this)
        );
    }

    /** Waiter for D2D migration with optional timeout */

    setup.d2dTargetWaiter = function d2dTargetWaiter(d2dTimeout) {
    // device screen might sleep here
    var nextViewAppeared = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "BuddyDeviceMigrationFinished" or controllerClass == "BuddyAppleIDKeychainSyncPage"',
        }
        );
        UIALogger.logMessage('Waiting up to %0 seconds for the next view to appear...'.format(d2dTimeout));
        if (!nextViewAppeared.wait(d2dTimeout)) {
            UIALogger.logMessage('Function timeout since the migration took a long time');
        }
    }

    /** Waiter for manual proximity pin code until D2D pane */

    setup.proxPinDisplayWaiter = function proxPinDisplayWaiter() {
    // device screen might sleep here
    var nextViewAppeared = UIAWaiter.waiter(
        'ViewDidAppear', {
            predicate: 'controllerClass == "BuddyDeviceMigrationController"'
        }
        );
    }
}
