load('UIATesting.js');
load('Setup.js');

if (typeof SetupTests === 'undefined') {
    /**
    * @namespace SetupTests
    */
    var SetupTests = {
        /**
         * Step the device through Setup Buddy
         *
         * @timeout 1200
         * @targetapps Setup
         * @eligibleResource deviceClass == 'iPhone' or deviceClass == 'iPad' or deviceClass == 'iPod'
         *
         * @param {object} args - Test arguments
         * @param {string} [args.language="English"] - language to choose (default to English)
         * @param {string} [args.country="United States"] - Optional country to choose (default to United States)
         * @param {bool} [args.usePhoneNumber=false] - Enable or Disable phone number to regiester iMessage&FaceTime (China SKU only, default to false)
         * @param {string} [args.wifiNetwork="AppleWiFi"] - Required name of the Wi-Fi network to connect to
         * @param {string} [args.wifiPassword=""] - Password of the Wi-Fi network to connect to (for secure networks)
         * @param {string} [args.wifiUsername=""] - User of the Wi-Fi network to connect (for enterprise networks)
         * @param {bool} [args.isWiFiHiddenNetwork=false] - Hidden setting of the Wi-Fi network (for non-broadcasting networks)
         * @param {string} [args.wifiSecurityType="None"] - WiFi network security (for non-broadcasting networks)
         * @param {string} [args.d2dChoice="other"] - Optional perform Device to Device Migration or choose other options
         * @param {int} [args.d2dTimeout=null] - Optional timeout for D2D
         * @param {string} [args.restoreRoute="new"] - Optional how to restore the device
         * @param {string} [args.backupVersion=null] - Optional - Backup version. Used in conjuncion with a 'iCloud' restore route.
         *                          If nothing is passed, we use the first backup version listed.
         *                          If a value is passed, a contains predicate is made out of it.
         *                              e.g. 'October 29, 2013, at 5:57 AM' would match on 'October 29, 2013, at 5:57 AM'
         *                              but so would: 'October', 'October 29', '5:57', ect.
         * @param {string} [args.iTunesPassword=null] - Optional Password for iTunes/AppStore/iBooksStore
         * @param {string} [args.tfaPhoneNumberiTunes=""] - Optional phone number for iTunes/AppStore/iBooksStore
         * @param {string} [args.androidHostIPAddress=null] - Optional hostIPAddress if migrating from android using data on a Mac
         * @param {string} [args.androidSemaphoreUUID=null] - Required in order to transfer from an android device
         * @param {string} [args.passcode=""] - Optional passcode to set
         * @param {string} [args.appleID=""] - Optional Apple ID account name
         * @param {string} [args.appleIDPassword=""] - Optional Apple ID password
         * @param {bool} [args.proximityAccount=false] - options.proximityAccount - Optional - Whether to enter SA account required for proximity setup
         * @param {bool} [args.customizeSettings=true] - Whether to customize settings or use defaults that share location and app developer info
         * @param {string} [args.configurationUsername=""] - Optional enterprise username
         * @param {string} [args.configurationPassword=""] - Optional enterprise password
         * @param {bool} [args.skipEnterpriseConfiguration=true] - Whether or not to skip enterprise configuration
         * @param {string} [args.icsc=""] - Optional iCloud Security Code
         * @param {string} [args.icscOptions=""] - Optional iCloud Security Code Advanced Options
         * @param {string} [args.passcodeChoice=""] - Optional Keychain passcode choice
         * @param {int} [args.androidTransferTimeout=600] - Optional timeout time for android file transfer
         * @param {bool} [args.useSiri=false] - Whether to use Siri. Default false
         * @param {object} [args.heySiriSetup=null] - whether to train hey siri. Default null (Requires an external tophat speaker)
         * @param {string} [args.heySiriSetup.tophatSpeakerIP=""] - tophat speaker IP address to use for hey siri training. Default null
         * @param {integer} [args.heySiriSetup.tophatSpeakerPort=8888] - tophat speaker port to use for hey siri training. Default 8888
         * @param {bool} [args.enableLocationServices=true] - Whether to enable Location Services. Default true
         * @param {bool} [args.shareAppAnalytics=false] - Whether to share App Analytics. Default false
         * @param {bool} [args.failIfActivationLock=true] - Fail setup when encounter device activation locked
         * @param {bool} [args.useFindMyiPhone=true] - Whether to use Find My iPhone/iPad
         * @param {bool} [args.useiCloudKeychain=false] - Whether to set up iCloud Keychain
         * @param {bool} [args.useiCloud=true] - Whether to use up iCloud
         * @param {bool} [args.useiCloudDrive=true] - Whether to use up iCloud Drive
         * @param {bool} [args.useApplePay=false] - Whether to use Apple Pay
         * @param {bool} [args.useZoom=false] - Whether to use Display Zoom
         * @param {bool} [args.passIfSetupDone=true] - Should pass if we are already through Setup Buddy
         * @param {string} [args.profilePictureSelection=null] - Optional - Whether to use a monogram, avatar, or photo as a profile picture
         * @param {string} [args.homeButtonChoice=null] - Optional - Which home button sensitivity level to use
         * @param {string} [args.sharedCurrentPasscode=""] - Optional - Shared iPad current Managed Apple ID (MAID) account passcode
         * @param {string} [args.sharedNewPasscode=""] - Optional - Shared iPad new Managed Apple ID (MAID) account passcode
         * @param {string} [args.targetState="SpringBoard"] - Optional - UIState on which to return, should match a UIStateDescription.Setup constant
         * @param {array} [args.whitelistedPanes=[]] - Validate these panes appear. Options are listed in Setup.js under UIStateDescription.Setup
         * @param {array} [args.blacklistedPanes=[]] - Validate these panes do not appear.  Options are listed in Setup.js under UIStateDescription.Setup
         * @param {bool} [args.failForUnknownPanes=false] - Fail the test if panes appear that are not whitelisted
         * @param {array} [args.sequencedPanes=[]] - Validate if the sequence of these panes match the actual panes run through. Options are listed in Setup.js under UIStateDescription.Setup
         * @param {bool} [args.autoUpdate=false] - Whether automatic software updates are enabled
         * @param {bool} [args.enableScreenTime=true] - Whether to enable screen time. Default true
         *
         */
        setupDevice: function setupDevice(args) {
            args = UIAUtilities.defaults(args, {
                language: "English",
                country: "United States",
                usePhoneNumber: false,
                wifiNetwork: "AppleWiFi",
                wifiPassword: "",
                wifiUsername: "",
                isWiFiHiddenNetwork: false,
                wifiSecurityType: "None",
                d2dChoice: "other",
                d2dTimeout: null,
                restoreRoute: "new",
                backupVersion: null,
                iTunesPassword: null,
                tfaPhoneNumberiTunes: null,
                appleID: null,
                appleIDPassword: null,
                proximityAccount: false,
                customizeSettings: true,
                configurationUsername: null,
                configurationPassword: null,
                skipEnterpriseConfiguration: true,
                passcode: null,
                useSiri: false,
                heySiriSetup: null,
                enableLocationServices: true,
                shareAppAnalytics: false,
                useFindMyiPhone: true,
                useiCloudKeychain: false,
                useiCloud: true,
                useiCloudDrive: true,
                enableScreenTime: true,
                useApplePay: false,
                failIfActivationLock: true,
                useZoom: false,
                passIfSetupDone: true,
                icsc: null,
                icscOptions: null,
                passcodeChoice: null,
                androidHostIPAddress: null,
                androidSemaphoreUUID: null,
                androidTransferTimeout: 600,
                profilePictureSelection: null,
                sharedCurrentPasscode: "",
                sharedNewPasscode: "",
                targetState: "SpringBoard",
                whitelistedPanes:[],
                blacklistedPanes: [],
                failForUnknownPanes: false,
                sequencedPanes:[],
                autoUpdate: false,
            });

            if (args.wifiNetwork.indexOf('$$') === 0 && args.wifiPassword.indexOf('$$') === 0) {
                args.wifiNetwork = 'AppleWiFi';
                args.wifiPassword = '';
                args.wifiUsername = '';
            }
            // let's check if we have already made it through buddy rdar://problem/20489535
            if (!setup.needsToRun) {
                UIALogger.logMessage("Setup is already done. We are on SpringBoard.");
                if (!args.passIfSetupDone) {
                    throw new UIAError("setupDevice failed because we are already through setup buddy, setup.needsToRun is set to 0.");
                } else {
                    resultingPanes=[]
                    setup.verifyPanes(args, resultingPanes)
                    return;
                }
            } else {
                UIALogger.logMessage("setup.needsToRun is set to 1. Navigating Setup Buddy now...");
            }
            setup.navigateSetupBuddy(args);

            // Springboard will not come up for a backup restore/enterprise/edu,
            // rather we end in a loading screen/edu login screen
            if (args.restoreRoute === 'icloud' || args.restoreRoute === 'enterprise') {
                return;
            }

            if (args.targetState == "SpringBoard") {
                UIAUtilities.assertEqual(target.activeApps()[0].name(), "SpringBoard");
            } else {
                UIAUtilities.assertEqual(target.activeApps()[0].name(), "Setup");
            }
        }
    }
}
