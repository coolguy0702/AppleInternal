/**
* TopHatSpeaker module for Testing Siri with external Audio source.
*
* Requires DUT to be on internal network
**/
if (typeof tophatspeaker === 'undefined') {
    var tophatspeaker = {
        ip: null,
        port: 8888
    };
    
    tophatspeaker.speak = function speak(utterance) {
        result = target.performTask("/usr/local/bin/curl",
                        [
                         '%0:%1/speaker/speak/%2'.format(
                                                         tophatspeaker.ip,
                                                         tophatspeaker.port,
                                                         utterance
                                                         )
                        ],
                        5
                        );
        UIALogger.logMessage(result.stdout);
        return result.exitCode == 0;
    }
}
