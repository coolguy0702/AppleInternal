load('UIATesting.js');
load('Clock.js'); // load the library file

UIAUtilities.assert(
    typeof ClockTests === 'undefined', 
    'ClockTests has already been defined.'
);


/**
 * @namespace ClockTests
 */
var ClockTests = {

    /**
      * Adds a new clock to the world clock list. If we are not adding via a
      * search, then a city and country must be specified.
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string} [args.city="New Delhi"] - (Required) City where clock is used.
      *             This is required because clocks are listed via city.
      *             We passed/fail based on if clock in this list.
      * @param {string} [args.country=""] - (Optional) Country where clock is used.
      *             A country must be given if no search is made.
      * @param {boolean} [args.viaSearch=true] - (Optional) Search with descriptor
      */
    addWorldClock: function addWorldClock(args) {
        args = UIAUtilities.defaults(args, {
            city: 'New Delhi',
            country: '',
            viaSearch: true,
        });

        if (!args.viaSearch && !(args.city && args.country)) {
            throw new UIAError('A city and country is required if we are not adding via a search.');
        }

        args.clockName = clock.setClockName(args.city, args.country);

        UIAUtilities.assert(
            !clock.doesClockExist(args.city),
            'World clock already exists. Cannot add clock.'
        );

        clock.addWorldClock(args);

        UIAUtilities.assert(
            clock.doesClockExist(args.city),
            'World clock was not added.'
        );
    },

    /**
      * Deletes a clock to the world clock list. If no clock name is specified
      * we delete the first clock.
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string} [args.city="New Delhi"] - (Optional) City where clock is used.
      */
    deleteWorldClock: function deleteWorldClock(args) {
        args = UIAUtilities.defaults(args, {
            city: null,
        });

        UIAUtilities.assertNotEqual(
            clock.getNumClocks(),
            0,
            'No world clocks exist. Cannot delete clock.'
        );

        if (args.city) {
            UIAUtilities.assert(
                clock.doesClockExist(args.city),
                'Clock specified to delete (%0) does not exist. Cannot delete clock.'.format(args.city)
            );
        }

        /** If we are not given a clock name then lets delete the first clock. */
        var clockName = args.city ? args.city : clock.getClockName();
        clock.deleteWorldClock(clockName);

        UIAUtilities.assert(
            !clock.doesClockExist(clockName),
            'World clock still exists! Could not delete clock.'
        );
    },

    /**
      * Add new alarm.
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string} [args.time="09:34:AM"] - (Required) A string in format hh:mm:period.
      *             Where period is 'AM' or 'PM'.
      * @param {string[]} [args.repeat=[]] - (Optional) The repeat string as shown in UI
      *             (i.e. "Every Monday", "Every Tuesday" ...). Can specify multiple repeat strings.
      * @param {string} [args.label=""] - (Optional) Label/nickname for alarm
      * @param {string} [args.sound=""] - (Optional) Name of the sound as shown in UI (i.e. "Marimba", "Alarm"....)
      * @param {boolean} [args.snooze=true] - (Optional) Flag for if snooze should be set.
      * @param {boolean} [args.strongValidation=false] - (Optional) If set, checks that a new alarm was
      *             created and verifies each part of the alarm (time, label, sound, snooze) is correct.
      *             If not set, test just confirms one new alarm was created.
      */
    addAlarm: function addAlarm(args) {
        args = UIAUtilities.defaults(args, {
            time: '09:34:AM',
            repeat: [],
            label: '',
            sound: '',
            snooze: true,
            strongValidation: false,
        });

        var count = clock.getNumAlarms();

        // need to validate repeat! should validate name depend params
        clock.validateTimeString(args.time);
        clock.addAlarm(args);

        UIAUtilities.assertEqual(count+1, clock.getNumAlarms());

        if (args.strongValidation) {
            clock.validateAlarmExists();
        }
    },

    /**
      * Create alarm, lock device and verify alarm triggers after given number of minutes
      *      
      * @targetApps MobileTimer
      *
      * @param {object} args - Options dictionary
      * @param {string} [args.alarmPeriod="2"] - number minutes after alarm should trigger
      *
      * @returns {boolean} - true if alarm triggers as expected, false otherwise
      */
    verifyAlarmAction: function verifyAlarmAction(args) {
        args = UIAUtilities.defaults(args, {
            alarmPeriod: '2', 
        });
    
        timeValues = clock.setAlarm(args.alarmPeriod);
        target.systemApp().lock();
        if (!clock.verifyAlarmTriggers(timeValues)) {
          throw new UIAError('verifyAlarmTriggers failed');
        }
    },

    /**
      * Navigate to each specified clock view (used for App History search).
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string[]} [args.views=["Alarm", "Timer"]] - The clock views to navigate to.
      */
    navigateViews: function navigateViews(args) {
        args = UIAUtilities.defaults(args, {
            views: ['Alarm', 'Timer'],
        });

        for (var i = 0; i < args.views.length; i++) {
          clock.getToView(args.views[i]);
          target.delay(1); // User must stay in the app view for one second in order to register the activity with spotlight
        }
    },

    /**
      * Set Up Bedtime 
      *
      * @targetApps MobileTimer
      *
      * @param {object} args - Test arguments
      * @param {string} [args.time="12:00:PM"] - A string in format hh:mm:period (where period is 'AM' or 'PM').
      * @param {string[]} [args.repeat=["Every day"]] - Days of week when Bedtime will go off.
      * @param {string} [args.sleep="8 hours"] - Hours to sleep. 
      * @param {string} [args.reminder="At bedtime"] - Bedtime reminder. 
      * @param {string} [args.sound="Early Riser"] - Wake Up Sound.
      */
    setUpBedtime: function setUpBedtime(args) {
        args = UIAUtilities.defaults(args, {
            time: '12:00:PM', 
            repeat: ['Every day'], 
            sleep: '8 hours', 
            reminder: 'At bedtime', 
            sound: 'Early Riser', 
        });

        clock.setupAndValidateBedtime(args);
    },
}
