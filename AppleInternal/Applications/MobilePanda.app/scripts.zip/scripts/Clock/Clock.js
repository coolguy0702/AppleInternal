load('UIAApp.js');
load('UIAUtility.js');
load('SpringBoard.js');

if (typeof clock !== 'undefined') {
    if (!(clock instanceof UIAApp)) {
        throw new UIAError("clock has already been defined to something not an instance of UIAApp! Value: %0".format(clock));
    }
    if (clock.bundleID() !== 'com.apple.clock') {
        var oldDefinition = clock.bundleID();
        var clock = target.appWithBundleID('com.apple.clock');
        UIALogger.logWarning("'clock' was redefined from '%0' to '%1'".format(oldDefinition, clock.bundleID()));
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common clock queries */
UIAQuery.Clock = {
    /** Visible navigation bars. */
    VISIBLE_NAV_BARS: UIAQuery.navigationBars().last().isVisible(),

    /** Add element buttons. For adding alarms and clocks. TODO: simplify query */
    ADD_NAV_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Add')).orElse(UIAQuery.query('UINavigationTransitionView').andThen(UIAQuery.query('Add'))),

    /** Edit element buttons. For editing alarms and clocks. */
    EDIT_NAV_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Edit')),

    /** Done buttons. For when done editing alarms and clocks. */
    DONE_NAV_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Done')),

    /** Next navigation bar button */
    NEXT_NAV_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Next')), 

    /** Cancel Buttons. */
    CANCEL_NAV_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Cancel')),

    /** Back Button. Seems to be an invisible extra. Therefore, grab first one. */
    BACK_NAV_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back').atIndex(0)),

    /** Save button */
    SAVE_NAV_BUTTON: UIAQuery.navigationBars().andThen(UIAQuery.buttons('Save')),

    /** Bedtime navigation bar */
    BEDTIME_NAV_BAR: UIAQuery.navigationBars('Bedtime').isVisible(),

    /** Bedtime Options navigation bar */
    BEDTIME_OPTIONS_NAV_BAR: UIAQuery.navigationBars('Bedtime Options').isVisible(), 

    /** Bedtime Options navigation bar button */
    BEDTIME_NAV_BAR_OPTIONS_BUTTON: UIAQuery.navigationBars('Bedtime').isVisible().andThen(UIAQuery.buttons('Options')), 

    /** Bedtime Switch */
    BEDTIME_SWITCH: UIAQuery.withPredicate('behavior == "Switch" AND name BEGINSWITH "Bedtime"'), 

    /** Bedtime Clock Control */
    BEDTIME_CLOCK: UIAQuery.query('MTABedtimeClockView').isVisible(),  

    /** Bedtime Reminder table cell */
    BEDTIME_REMINDER_CELL: UIAQuery.tableCells().andThen(UIAQuery.staticTexts('Bedtime Reminder')), 

    /** Value set for Bedtime Reminder */
    BEDTIME_REMINDER_CELL_VALUE: UIAQuery.tableCells().andThen(UIAQuery.staticTexts('Bedtime Reminder')).siblings().andThen(UIAQuery.staticTexts()), 

    /** Bedtime Wake Up Sound table cell */
    BEDTIME_WAKEUP_SOUND_CELL: UIAQuery.tableCells().andThen(UIAQuery.staticTexts('Wake Up Sound')),

    /** Value set for Bedtime Wake Up Sound */
    BEDTIME_WAKEUP_SOUND_CELL_VALUE: UIAQuery.tableCells().andThen(UIAQuery.staticTexts('Wake Up Sound')).siblings().andThen(UIAQuery.staticTexts()),

    /** Page view nagivation button to World Clock view. */
    WORLD_CLOCK_VIEW_BUTTON: UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons('World Clock')),

    /** Page view nagivation button to Alarm view. */
    ALARM_VIEW_BUTTON: UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons('Alarm')),

    /** Page view nagivation button to Bedtime view. */
    BEDTIME_VIEW_BUTTON: UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons('Bedtime')), 

    /** Bedtime Welcome Page background image */
    BEDTIME_GET_STARTED_BUTTON: UIAQuery.buttons('Get Started'), 

    /** Page view nagivation button to Stopwatch view. */
    STOPWATCH_VIEW_BUTTON: UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons('Stopwatch')),

    /** Page view nagivation button to Timer view. */
    TIMER_VIEW_BUTTON: UIAQuery.tabBars().isVisible().andThen(UIAQuery.buttons('Timer')),

    /** Container for the main content in a clock page view. */
    MAIN_CONTENT_CONTAINER: UIAQuery.query('UINavigationTransitionView'),
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to Clock */
UIStateDescription.Clock = {
    /** World Clock State */
    WORLD_CLOCK:              'World Clock',

    /** Add Clock State */
    ADD_CLOCK_VIEW:           'AddClockView',

    /** Alarm State */
    ALARM:                    'Alarm',

    /** Add Alarm State */
    ADD_ALARM:                'Add Alarm',

    /** Bedtime Welcome Page */
    BEDTIME_WELCOME_PAGE:     'Bedtime Welcome Page',

    /** Bedtime State */
    BEDTIME:                  'Bedtime',

    /** Bedtime Options State */
    BEDTIME_OPTIONS:          'Bedtime Options', 

    /** Stopwatch State */
    STOPWATCH:                'Stopwatch',

    /** Timer */
    TIMER:                    'Timer',
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 *  Constants for possible states
 *
 *  @namespace
 */
// States = {

// /**  active */
//     ACTIVE: "Active",

// /**  unknown */
//     UNKNOWN: "Unknown",
// };

Labels = {
    /** Snooze */
    SNOOZE:                     'Snooze',

    /** Repeat */
    REPEAT:                     'Repeat',

    /** Label */
    LABEL:                      'Label',

    /** Sound */
    SOUND:                      'Sound',
};

/**
 * @namespace {UIAApp} clock
 */
var clock = target.appWithBundleID('com.apple.mobiletimer');


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Clock for possible values.
 *
 * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
 */
clock.currentUIState = function currentUIState() {
    UIAUtilities.assert(
        (this.count(UIAQuery.Clock.VISIBLE_NAV_BARS) === 1), 
        'Unexpected number of navigation bars. Cannot determine UI clock state.'
    );

    var navigationBarInfo = this.inspect(UIAQuery.Clock.VISIBLE_NAV_BARS).name;

    switch (navigationBarInfo) {
        case UIStateDescription.Clock.WORLD_CLOCK:
            return UIStateDescription.Clock.WORLD_CLOCK;
        case UIStateDescription.Clock.ALARM:
            return UIStateDescription.Clock.ALARM;
        case UIStateDescription.Clock.BEDTIME:
            if (this.exists(UIAQuery.Clock.BEDTIME_GET_STARTED_BUTTON)) {
                return UIStateDescription.Clock.BEDTIME_WELCOME_PAGE;
            } else {
                return UIStateDescription.Clock.BEDTIME;
            }
        case UIStateDescription.Clock.BEDTIME_OPTIONS:
            return UIStateDescription.Clock.BEDTIME_OPTIONS;
        case UIStateDescription.Clock.STOPWATCH:
            return UIStateDescription.Clock.STOPWATCH;
        case UIStateDescription.Clock.TIMER:
            return UIStateDescription.Clock.TIMER;
        default:
            throw new UIAError('Could not determine current UI clock state.');
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets to a specified view in the clock application.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} viewName - Name of view/UI state.
 *
 * @returns none
 */
clock.getToView = function getToView(viewName) {
    this.launch();

    if (this.currentUIState() === viewName) {
        return;
    }

    //TODO: what about edits/cancels/backs
    //this is working, may have to revamp as needed
    this.tapAllCancelOrDoneButtons();

    switch (viewName) {
        case UIStateDescription.Clock.WORLD_CLOCK:
            this.tap(UIAQuery.Clock.WORLD_CLOCK_VIEW_BUTTON);
            break;
        case UIStateDescription.Clock.ALARM:
            this.tap(UIAQuery.Clock.ALARM_VIEW_BUTTON);
            break;
        case UIStateDescription.Clock.BEDTIME:
            this.tap(UIAQuery.Clock.BEDTIME_VIEW_BUTTON);
            break;
        case UIStateDescription.Clock.STOPWATCH:
            this.tap(UIAQuery.Clock.STOPWATCH_VIEW_BUTTON);
            break;
        case UIStateDescription.Clock.TIMER:
            this.tap(UIAQuery.Clock.TIMER_VIEW_BUTTON);
            break;
        default:
            throw new UIAError('View %0 is not a reconized view. Could not navigate to it.'.format(viewName));
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


clock.addClockBySearch = function addClockBySearch(options) {
    throw new UIAError("Not yet implemented.");
}

/**
 * Adds a world clock.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.viaSearch - If clock creation should use the
 *                  search option instead of scrolling/accessing directly.
 * @param {bool} options.clockName - Name of clock. This is based on its location.
 *
 * @returns none
 */
clock.addWorldClock = function addWorldClock(options) {
    options = UIAUtilities.defaults(options, {
        viaSearch: false,
    });

    if (!options.clockName) {
        throw new UIAError('No clockName was specified for world clock.');
    }

    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);
    this.tap(UIAQuery.Clock.ADD_NAV_BUTTON);

    if (options.viaSearch === true) {
        this.search(options.clockName);
        this.tap(UIAQuery.Clock.MAIN_CONTENT_CONTAINER.andThen(UIAQuery.staticTexts().first()));
    } else {
        UIAUtilities.assert(
            clock.scrollToVisibleIfExists(options.clockName),
            'Could not scroll to element: (%0)'.format(options.clockName)
        );
        this.tap(options.clockName);
    }
}

/**
 * Deletes a world clock by clock name.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} clockName - Name of clock to delete.
 *
 * @returns none
 */
clock.deleteWorldClock = function deleteWorldClock(clockName) {
    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);
    this.tap(UIAQuery.Clock.EDIT_NAV_BUTTON);
    this.tap(UIAQuery.query(clockName).siblings().andThen(UIAQuery.withPredicate('name beginswith "Delete"')));
    this.tap('Delete');
}

/**
 * Edits the options associated with an alarm.
 *
 * Required Starting View: Open alarm editing page.
 *
 * @param {object} options - Options dictionary
 * @param {string} options.time= - A string in format hh:mm:period.
 * @param {string[]} options.repeat - The repeat string as shown in UI
 * @param {string} options.label - Label/nickname for alarm
 * @param {string} options.sound - Name of the sound as shown in UI
 * @param {boolean} options.snooze - Flag for if snooze should be set.
 *
 * @returns none
 */
clock.editAlarmOptions = function editAlarmOptions(options) {
    // this.getToView(UIStateDescription.Clock.ALARM);

    if (options.time) {
        this.setAlarmTime(options.time);
    }

    if (options.repeat && options.repeat.length > 0) {
        this.setAlarmRepeatValues(options.repeat);
    }

    if (options.label) {
        this.setAlarmLabel(options.label);
    }

    if (options.sound) {
        this.setAlarmSound(options.sound);
    }

    //TODO: this is broken!!! Snooze control cannot be set
    if (options.snooze) {
        // this.setControl(Labels.SNOOZE, options.snooze);
    }

    this.tap(UIAQuery.Clock.SAVE_NAV_BUTTON);
}

/**
 * Adds a alarm with passed atrributes.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {object} options - Options dictionary
 * @param {string} options.time= - A string in format hh:mm:period.
 * @param {string[]} options.repeat - The repeat string as shown in UI
 * @param {string} options.label - Label/nickname for alarm
 * @param {string} options.sound - Name of the sound as shown in UI
 * @param {boolean} options.snooze - Flag for if snooze should be set.
 *
 * @returns none
 */
clock.addAlarm = function addAlarm(options) {
    this.getToView(UIStateDescription.Clock.ALARM);
    this.tap(UIAQuery.Clock.ADD_NAV_BUTTON);
    this.editAlarmOptions(options);
}

/**
 * Creates a new alarm to trigger after the given number of minutes
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {number} nMinutes - number minutes after alarm should trigger
 *
 * @returns {object} timeValues - time values object for alarm trigger time
 * @returns {number} timeValues.theDate - the Date object    
 * @returns {number} timeValues.theHour - the hour value    
 * @returns {number} timeValues.theMinute - the minute value    
 * @returns {string} timeValues.thePeriod - 'AM' | 'PM'   
 * @returns {number} timeValues.theMillisecond - milliseconds value     
 */
clock.setAlarm = function setAlarm(nMinutes) {
    this.getToView(UIStateDescription.Clock.ALARM);
    this.tap(UIAQuery.Clock.ADD_NAV_BUTTON);

    timeValues = this.getTimeIn(nMinutes);
    timeString = '%0:%1:%2'.format(
        ((timeValues.theHour < 10 && timeValues.theHour >= 0) ? '0' + timeValues.theHour : timeValues.theHour), 
        ((timeValues.theMinute < 10 && timeValues.theMinute >= 0) ? '0' + timeValues.theMinute : timeValues.theMinute), 
        timeValues.thePeriod
    );

    this.setAlarmTime(timeString);
    this.tap(UIAQuery.Clock.SAVE_NAV_BUTTON);

    return timeValues;
}

/**
 * Waits for alarm to trigger while the system is locked.
 *
 * Required Starting View: Assumes device is locked.
 *
 * @param {object} timeValues - time values object for alarm trigger time
 * @returns {number} timeValues.theDate - the Date object    
 * @returns {number} timeValues.theHour - the hour value    
 * @returns {number} timeValues.theMinute - the minute value    
 * @returns {string} timeValues.thePeriod - 'AM' | 'PM'   
 * @returns {number} timeValues.theMillisecond - milliseconds value    
 *
 * @returns {boolean} args - true if alarm triggers as expected, false otherwise
 */
clock.verifyAlarmTriggers = function verifyAlarmTriggers(timeValues) {
    if (!target.systemApp().isLocked()) {
        throw new UIAError("verifyAlarmTriggers: device is not locked");
    }
    
    var timeNow = new Date(); 
    var timeDiffSet = Math.abs((timeValues.theDate.getTime() - timeNow.getTime()) / 1000);
    UIALogger.logMessage('timeDiffSet: %0'.format(timeDiffSet));
    var waitTime = timeDiffSet * 1.1;   // adds 10% margin

    var alarmTriggered = UIAWaiter.withPredicate('ViewDidAppear',
                            'controllerClass = "SBDashBoardModalPresentationViewController"');
    if (!alarmTriggered.wait(waitTime)) {
        UIALogger.logMessage('alarm never triggered??');
        return false;
    }

    app = target.activeApp();
    app.tap(UIAQuery.buttons().contains('Stop'));

    return true;
}

/**
 * Validates/sets Bedtime after initial setup completed
 * 
 * Required Starting View: UIStateDescription.Clock.BEDTIME.
 * 
 * @param {object} options - Options dictionary
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - Days of week when Bedtime will go off.
 * @param {string} options.sleep - Hours to sleep. 
 * @param {string} options.reminder - Bedtime reminder. 
 * @param {string} options.sound - Wake Up Sound.
 */
clock.validateBedtime = function validateBedtime(options) {
    // Check if we are on the Main Bedtime screen
    UIAUtilities.assert(
        (this.currentUIState() === UIStateDescription.Clock.BEDTIME), 
        'Could not validate Bedtime settings. Clock app is not in a required view state'
    );

    // Switch Bedtime On
    this.setControl(UIAQuery.Clock.BEDTIME_SWITCH, 1);
    this.delay(2);
    this.tap(UIAQuery.Clock.BEDTIME_NAV_BAR_OPTIONS_BUTTON);
    this.setBedtimeRepeatValues(options.repeat);
    this.setBedtimeReminder(options.reminder);
    this.setBedtimeWakeUpSound(options.sound);
    // Switch Bedtime Off
    this.setControl(UIAQuery.Clock.BEDTIME_SWITCH, 0);
};

/**
 * Sets up Bedtime for the first time to specified parameters 
 * 
 * Required Starting View: UIStateDescription.Clock.BEDTIME_WELCOME_PAGE.
 * 
 * @param {object} options - Test arguments
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - Days of week when Bedtime will go off.
 * @param {string} options.sleep - Hours to sleep. 
 * @param {string} options.reminder - Bedtime reminder. 
 * @param {string} options.sound - Wake Up Sound.
 */
clock.setUpBedtime = function setUpBedtime(options) {
    // Check if we are on the Welcome screen
    UIAUtilities.assert(
        (this.currentUIState() === UIStateDescription.Clock.BEDTIME_WELCOME_PAGE), 
        'Could not set up Bedtime. Clock app is not in a required view state'
    );

    // Tap 'Get Started' button to proceed to the next screen.
    this.tap(UIAQuery.Clock.BEDTIME_GET_STARTED_BUTTON);
    this.setAlarmTime(options.time);
    this.tap(UIAQuery.Clock.NEXT_NAV_BUTTON);
    this.setBedtimeRepeatValues(options.repeat);
    this.tap(UIAQuery.Clock.NEXT_NAV_BUTTON);
    this.setControl(UIAQuery.pickerWheels(), options.sleep);
    this.tap(UIAQuery.Clock.NEXT_NAV_BUTTON);
    this.tap(UIAQuery.tableCells().andThen(UIAQuery.staticTexts(options.reminder)));
    this.tap(UIAQuery.Clock.NEXT_NAV_BUTTON);
    this.tap(UIAQuery.tableCells().andThen(UIAQuery.staticTexts(options.sound)));
    this.tap(UIAQuery.Clock.NEXT_NAV_BUTTON);
    this.tap(UIAQuery.Clock.SAVE_NAV_BUTTON);
    // Switch Bedtime Off
    this.setControl(UIAQuery.Clock.BEDTIME_SWITCH, 0);
};

/**
 * Goes through the Bedtime setup and/or validates the existing settings.  
 * 
 * @param {object} options - Test arguments
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - Days of week when Bedtime will go off.
 * @param {string} options.sleep - Hours to sleep. 
 * @param {string} options.reminder - Bedtime reminder. 
 * @param {string} options.sound - Wake Up Sound.
 */
clock.setupAndValidateBedtime = function setupAndValidateBedtime(options) {
    this.getToView(UIStateDescription.Clock.BEDTIME);
    
    var currentUIState = this.currentUIState();
    if (currentUIState === UIStateDescription.Clock.BEDTIME_WELCOME_PAGE) {
        this.setUpBedtime(options);
    } else if (currentUIState === UIStateDescription.Clock.BEDTIME) {
        this.validateBedtime(options);
    } else {
        throw new UIAError('Could not get to a required state. The current state: %0'.format(currentUIState));
    }
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Tap all of the visible cancel or done buttons
 */
clock.tapAllCancelOrDoneButtons = function tapAllCancelOrDoneButtons() {
    var count = 0;// tap a maximum of 10 times
    while (clock.exists(UIAQuery.buttons('Cancel').orElse(UIAQuery.buttons('Done'))) && count < 10) {
        this.tap(UIAQuery.buttons('Cancel').orElse(UIAQuery.buttons('Done')));
        count += 1;
    }
}

/**
 * Navigate back to the top level of app.
 */
clock.returnToTopLevel = function returnToTopLevel() {
    if (this.exists(UIAQuery.VISIBLE_POPOVERS)) {
        this.dismissPopover();
    }

    this.tapIfExists(UIAQuery.buttons('Cancel'));
    this.tapIfExists(UIAQuery.buttons('Done'));
}

/**
 * Determines if specified content exists in Clock's main
 * content container.
 *
 * Required Starting View: TODO:
 *
 * @param {string/Query} content
 *
 * @returns {bool}
 */
clock.doesContentExist = function doesContentExist(content) {
    return this.exists(UIAQuery.Clock.MAIN_CONTENT_CONTAINER.andThen(UIAQuery.query(content)));
}

/**
 * Determines if specified clock exists.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} clockName - Name of clock.
 *
 * @returns {bool}
 */
clock.doesClockExist = function doesClockExist(clockName) {
    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);
    return this.doesContentExist(clockName);
}

/**
 * Determines if specified alarm exists.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {string} alarmName - Name of alarm.
 *
 * @returns {bool}
 */
clock.doesAlarmExist = function doesAlarmExist(alarmName) {
    this.getToView(UIStateDescription.Clock.ALARM);
    return this.doesContentExist(alarmName);
}

/**
 * Creates the full name of a clock based on the location values.
 *
 * Required Starting View: N/A. Does not interact with UI
 *
 * @param {string} city
 * @param {string} country
 *
 * @returns {string} - Expected name of clock
 */
clock.setClockName = function setClockName(city, country) {
    if (city && country) {
        return '%0, %1'.format(city, country);
    } else if (city) {
        return city;
    } else if (country) {
        return country;
    } else {
        throw new UIAError("Location info not defined.");
    }
}

/**
 * Gets the number of elements containing content that exist in Clock's main
 * content container.
 *
 * Required Starting View: TODO:
 *
 * @param {string/Query} content
 *
 * @returns {bool}
 */
clock.getContentCount = function getContentCount(content) {
    return this.count(UIAQuery.Clock.MAIN_CONTENT_CONTAINER.andThen(UIAQuery.query(content)));
}

/**
 * Determines current number of world clocks.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @returns {bool} - Number of clocks in clock list.
 */
clock.getNumClocks = function getNumClocks() {
    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);
    return this.getContentCount(UIAQuery.tableCells());
}

/**
 * Determines current number of alarm.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @returns {bool} - Number of alarms in alarm list.
 */
clock.getNumAlarms = function getNumAlarms() {
    this.getToView(UIStateDescription.Clock.ALARM);
    return this.getContentCount(UIAQuery.tableCells());
}

/**
 * Gets snapshot of specified content from Clock's main
 * content container.
 *
 * Required Starting View: TODO:
 *
 * @param {string/Query} content
 *
 * @returns {bool}
 */
clock.getContent = function getContent(content) {
    return this.inspect(UIAQuery.Clock.MAIN_CONTENT_CONTAINER.andThen(UIAQuery.query(content)));
}

/**
 * Gets a clock snapshot. Retrieves clock based on this critiera:
 *  first checks if a clock name was specified
 *  if no name, then checks if a index was specified
 *  if also no index, grabs first clock in list.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.clockName - Name of clock to retrieve. If null, grab
 *                  first clock.
 *
 * @returns {bool} - Number of alarms in alarm list.
 */
clock.getClock = function getClock(options) {
    options = UIAUtilities.defaults(options, {
        clockName: null,
        index: null
    });

    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);

    if (options.clockName) {
        return this.getContent(UIAQuery.tableCells().above(options.clockName));
    } else if (options.index) {
        return this.getContent(UIAQuery.tableCells().atIndex(options.index));
    } else {
        return this.getContent(UIAQuery.tableCells());
    }
}

/**
 * Gets the name of the clock at the specified index. If no
 * index is given, grab the first clock's name.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {object} options - Options dictionary
 * @param {bool} options.clockName - Name of clock to retrieve. If null, grab
 *                  first clock.
 *
 * @returns {bool} - Number of alarms in alarm list.
 */
clock.getClockName = function getClockName(options) {
    options = UIAUtilities.defaults(options, {
        index: null
    });

    this.getToView(UIStateDescription.Clock.WORLD_CLOCK);
    return (this.getClock(options).label).split(",")[0];
}

/**
 * Sets the time for an alarm
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {string} time - A string in format hh:mm:period. Where period is 'AM' or 'PM'.
 *
 * @returns None
 */
clock.setAlarmTime = function setAlarmTime(time) {
    var [hour, min, period] = time.split(":");
    if ((hour.length == '2') && (hour[0] == '0')) { hour = hour[1]; }

    this.setControl(UIAQuery.pickerWheels().atIndex(0), hour);
    this.setControl(UIAQuery.pickerWheels().atIndex(1), min);
    this.setControl(UIAQuery.pickerWheels().atIndex(2), period);
}

/**
 * Sets the repeat times for an alarm
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {string[]} repeats - The repeat string as shown in UI
 *             (i.e. "Every Monday", "Every Tuesday" ...).
 *              Can specify multiple repeat strings.
 *
 * @returns None
 */
clock.setAlarmRepeatValues = function setAlarmRepeatValues(repeats) {
    this.tap(Labels.REPEAT);

    for (var i = 0; i < repeats.length; i++) {
        // this.tap(UIAQuery.withPredicate('name endsWith "%0"'.format(repeats[i])));
        this.tap(repeats[i]);
    }

    this.tap(UIAQuery.Clock.BACK_NAV_BUTTON);
}

/**
 * Sets the alarm label.
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {string} label - Label descripting/naming alarm
 *
 * @returns None
 */
clock.setAlarmLabel = function setAlarmLabel(label) {
    this.tap(Labels.LABEL);
    this.enterText(UIAQuery.query('UITextField'), label);
    this.tapIfExists(UIAQuery.Clock.BACK_NAV_BUTTON);
}

/**
 * Sets the sound of an alarm.
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {string} sound - Name of the sound as shown in UI
 *             (i.e. "Marimba", "Alarm"....)
 *
 * @returns None
 */
clock.setAlarmSound = function setAlarmSound(sound) {
    this.tap(Labels.SOUND);

    this.scrollToVisible(sound);
    this.tap(sound);

    this.tap(UIAQuery.Clock.BACK_NAV_BUTTON);
}

/**
 * Takes a time string and validates it is correctly formated.
 *
 * Required Starting View: TODO
 *
 * @param {string[]} repeats - The repeat string as shown in UI
 *             (i.e. "Every Monday", "Every Tuesday" ...).
 *              Can specify multiple repeat strings.
 *
 * @returns None
 * @throws on incorrectly formated time strings.
 */
clock.validateTimeString = function validateTimeString(timeStr) {
    var regex = /^\d{1,2}:\d{1,2}:\w{2}$/;
    var [hour, min, period] = timeStr.split(":");

    if (!regex.test(timeStr)) {
        throw new UIAError('Time string incorrectly formated. Expected: HH:MM:Period, Actual: %0'.format(timeStr));
    }

    if ( (hour < 1) || (hour > 12) ) {
        throw new UIAError('Hour incorrectly formated. Must be between 1 and 12. Passed value: %0'.format(hour));
    }

    if ( (min < 0) || (min > 59) ) {
        throw new UIAError('Minute incorrectly formated. Must be between 0 and 59. Passed value: %0'.format(minute));
    }

    if ( (period != 'AM') && (period != 'PM') ) {
        throw new UIAError('Period incorrectly formated. Must be AM or PM. Passed value: %0'.format(period));
    }
}

/**
 * Determines repeat string part of the alarm name
 * based on the repeat array option.
 *
 * Required Starting View: TODO
 *
 * @param {object} options - Options dictionary
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - The repeat string as shown in UI
 * @param {string} options.label - Label/nickname for alarm
 *
 * @returns None
 */
clock.determineRepeatStrLabel = function determineRepeatStrLabel(repeat) {
    var mon='', tue='', wed='', thu='', fri='', sat='', sun='';

    // assuming no dups and all valid because of validation step
    // at beginnig of test
    if (repeat.length === 7) {
        return 'Every Day';
    }

    for (var i = 0; i < repeat.length; ++i) {
        if (repeat[i] == 'Every Sunday') {
            sun = 'Sun';
        } else if (repeat[i] == 'Every Monday') {
            mon = 'Mon';
        } else if (repeat[i] == 'Every Tuesday') {
            tue = 'Tue';
        } else if (repeat[i] == 'Every Wednesday') {
            wed = 'Wed';
        } else if (repeat[i] == 'Every Thursday') {
            thu = 'Thu';
        } else if (repeat[i] == 'Every Friday') {
            fri = 'Fri';
        } else if (repeat[i] == 'Every Saturday') {
            sat = 'Sat';
        }
    }

    var label = '%0 %1 %2 %3 %4 %5 %6'.format(mon, tue, wed, thu, fri, sat, sun);
    return label.replace(/\s+/g,' ').trim();
}

/**
 * Determines alarm name base on passed in options.
 *
 * Required Starting View: N/A. Can start anywhere.
 *
 * @param {object} options - Options dictionary
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - The repeat string as shown in UI
 * @param {string} options.label - Label/nickname for alarm
 *
 * @returns None
 */
clock.determineAlarmName = function determineAlarmName(options) {
    var [hour, min, period] = time.split(":");
    if ((hour.length === '2') && (hour[0] === '0')) { hour = hour[1]; }

    var name = '%0:%1, %2'.format(hour, min, period);

    if (options.label) {
        name = '%0, %1'.format(name, period);
    } else {
        name = '%0, Alarm'.format(name);
    }

    if (options.repeat && options.repeat.length > 0) {
        name = '%0, %1'.format(name, this.determineRepeatStrLabel(options.repeat));
    }

    return name;
}

/**
 * Determines if the alarm sound is set to desired value.
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {string} sound - Disired sound track for alarm
 *
 * @returns true/false
 */
clock.isSoundSetTo = function isSoundSetTo(sound) {
    return this.exists(UIAQuery.query(Labels.SOUND).siblings(sound));
}

/**
 * Determines if the snooze switch is set to desired value.
 *
 * Required Starting View: Open alarm editing/adding page
 *
 * @param {boolean} snooze - Disired value of snooze switch
 *
 * @returns true/false
 */
clock.isSnoozeSetTo = function isSnoozeSetTo(snooze) {
    return (inspect(UIAQuery.switches(Labels.SNOOZE)).value == snooze);
}

/**
 * Validates that a particular alarm exists with the
 * supplied attributes.
 *
 * Required Starting View: TODO
 *
 * @param {object} options - Options dictionary
 * @param {string} options.time - A string in format hh:mm:period.
 * @param {string[]} options.repeat - The repeat string as shown in UI
 * @param {string} options.label - Label/nickname for alarm
 * @param {string} options.sound - Name of the sound as shown in UI
 * @param {boolean} options.snooze - Flag for if snooze should be set.
 *
 * @returns None
 */
clock.validateAlarmExists = function validateAlarmExists(options) {
    var alarmName = this.determineAlarmName(options);
    var count = this.getContentCount(alarmName);

    UIAUtilities.assertNotEqual(count, 0, 'Alarm not created. No alarm with name: %0'.format(alarmName));
    if (!options.sound && !options.snooze) { return; }

    for (var i = 0; i < count; ++i) {
        this.tapIfExists(UIAQuery.Clock.EDIT_NAV_BUTTON);
        this.tap(alarmName);

        if (options.sound
                && options.snooze
                && this.isSoundSetTo(options.sound)
                && thils.isSnoozeSetTo(options.snooze)) {
            return;
        }

        if (options.sound
                && !options.snooze
                && this.isSoundSetTo(options.sound)) {
            return;
        }

        if (!options.sound
                && options.snooze
                && this.isSnoozeSetTo(options.snooze)) {
            return;
        }

        this.tap(UIAQuery.Clock.CANCEL_NAV_BUTTON);
    }

    throw new UIAError('Failed to find an alarm with the supplied values.');
}

/**
 * Returns time values based on current time plus number of minutes in future.
 *
 * @param {number} alarmPeriod - number of minutes
 *
 * @returns {object} - time values describing now + given number of minutes
 */
clock.getTimeIn = function getTimeIn(nMinutes) {
    var d1 = new Date(); 
    var d2 = new Date(d1.getTime() + (nMinutes * 60 * 1000));
    var theHour = d2.getHours();
    var thePeriod = theHour > 12 ? 'PM' : 'AM';
    theHour = theHour > 12 ? theHour - 12 : theHour;
    var theMinute = d2.getMinutes();
    var theMillisecond = d1.getTime() + (nMinutes * 60 * 1000);

    return {
        theDate: d2,
        theHour: theHour,
        theMinute: theMinute,
        thePeriod: thePeriod,
        theMillisecond: theMillisecond
    };
}

/**
 * Sets the repeat times for Bedtime
 *
 * @param {string[]} repeat - The repeat string 
 *             (i.e. "Every Monday", "Every Tuesday" ...).
 *              Can specify multiple repeat strings (e.g. ["Monday", "Wednesday", "Friday"]).
 */
clock.setBedtimeRepeatValues = function setBedtimeRepeatValues(repeat) {
    UIALogger.logMessage('In setBedtimeRepeatValues');

    var repeats = [];
    // If there is only one element in the array, 
    // it is different from button labels we use.
    if (repeat.length === 1) {
        repeats = this.getRepeatValues(repeat[0]);
    } else {
        repeats = repeat;
    }

    // Go through all day buttons and select/deselect as required 
    for (var i = 0; i < 7; i++) {
        var dayOfWeekButtonQuery = '';
        if (this.exists(UIAQuery.Clock.BEDTIME_OPTIONS_NAV_BAR)) {
            UIALogger.logMessage('In Bedtime Options');
            dayOfWeekButtonQuery = UIAQuery.tableViews().andThen(UIAQuery.buttons().atIndex(i));
        } else {
            UIALogger.logMessage('In Bedtime Setup');
            dayOfWeekButtonQuery = UIAQuery.query('MTABedtimeRepeatControl').andThen(UIAQuery.buttons().atIndex(i));
        }
        var dayOfWeekButton = clock.inspect(dayOfWeekButtonQuery).name
        var dayOfWeekButtonState = clock.inspect(dayOfWeekButtonQuery).isSelected
        UIALogger.logMessage('Current state of button "%0": %1'.format(dayOfWeekButton, (dayOfWeekButtonState ? 'Selected' : 'Not Selected')));
        // Tap on a day button only if its current state differs from required state 
        if (repeats.includes(dayOfWeekButton) && !dayOfWeekButtonState) {
            this.tap(dayOfWeekButtonQuery);
        } else if (!repeats.includes(dayOfWeekButton) && dayOfWeekButtonState) {
            this.tap(dayOfWeekButtonQuery);
        }
    }
};

/**
 * Sets Bedtime Wake Up Sound to a specified value
 * 
 * Required Starting View: Bedtime Options
 * 
 * @param {string} sound - String representation of Bedtime sound (e.g. 'Early Riser', 'First Light', etc.)
 */
clock.setBedtimeWakeUpSound = function setBedtimeWakeUpSound(sound) {
    UIALogger.logMessage('In setBedtimeWakeUpSound');
    // Check if we are in the correct view
    UIAUtilities.assert(
        (this.currentUIState() === UIStateDescription.Clock.BEDTIME_OPTIONS), 
        'Could not set Bedtime Wake Up sound. Clock app is not in a required view state'
    );

    this.tap(UIAQuery.Clock.BEDTIME_WAKEUP_SOUND_CELL);

    if (this.waitUntilPresent(UIAQuery.tableViews('TKTonePickerTableView'), 5)) {
        this.tap(UIAQuery.tableCells().andThen(UIAQuery.staticTexts(sound)));
        this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Bedtime Options')));
    } else {
        throw new UIAError('Failed to reach sound selection screen');
    }
    if (this.inspect(UIAQuery.Clock.DONE_NAV_BUTTON).isEnabled) {
        this.tap(UIAQuery.Clock.DONE_NAV_BUTTON);
    } else {
        this.tap(UIAQuery.Clock.CANCEL_NAV_BUTTON);
    }
};

/**
 * Sets Bedtime reminder to a specified value
 * 
 * Required Starting View: Bedtime Options
 * 
 * @param {string} reminder - String representation of Bedtime reminder (e.g. 'At bedtime', '15 minutes before', etc.)
 */
clock.setBedtimeReminder = function setBedtimeReminder(reminder) {
    UIALogger.logMessage('In setBedtimeReminder');
    // Check if we are in the correct view
    UIAUtilities.assert(
        (this.currentUIState() === UIStateDescription.Clock.BEDTIME_OPTIONS), 
        'Could not set Bedtime Reminder. Clock app is not in a required view state'
    );

    this.tap(UIAQuery.Clock.BEDTIME_REMINDER_CELL);

    if (this.waitUntilPresent(UIAQuery.PROMPT_CONTAINER.contains('Bedtime Reminder'), 5)) {
        this.tap(UIAQuery.buttons(reminder));
    } else {
        throw new UIAError('Failed to get Bedtime Reminder action sheet');
    }
};

/**
 * Helper function to translate summary string for Bedtime repeats (e.g. 'Every day')
 * into an array of correspondent button labels
 * 
 * @param {string} - Repeats description used in UI as a summary, e.g. 'Every day' 
 * 
 * @returns {string[]} - an array of strings that represents button labels 
 *                      for each selected day of week
 */
clock.getRepeatValues = function getRepeatValues(repeat) {
    UIALogger.logMessage('In getRepeatValues');
    var repeats = [];
    switch(repeat) {
    case 'Every Monday':
        repeats.push('Monday');
        break;
    case 'Every Tuesday':
        repeats.push('Tuesday');
        break;
    case 'Every Wednesday':
        repeats.push('Wednesday');
        break;
    case 'Every Thursday':
        repeats.push('Thursday');
        break;
    case 'Every Friday':
        repeats.push('Friday');
        break;
    case 'Every Saturday':
        repeats.push('Saturday');
        break;
    case 'Every Sunday':
        repeats.push('Sunday');
        break;
    case 'Weekdays':
        repeats.push('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');
        break;
    case 'Weekends':
        repeats.push('Saturday', 'Sunday');
        break;
    case 'Every day':
        repeats.push('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
        break;
    default:
        repeats.push('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
        break;
    }
    return repeats;
};






