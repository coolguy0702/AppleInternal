load('UIAApp.js');
load('SpringBoard.js');

if (typeof phone === 'undefined') {

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Query Constants                                                     */
    /*                                                                             */
    /*      App specific queries that will be made frequently                      */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for common phone queries */
    UIAQuery.Phone = {
        /** 'Favorites' button within a TabBar */
        FAVORITES_TABBAR:   UIAQuery.tabBars().andThen(UIAQuery.buttons('Favorites')),

        /** 'Add To Favorites' button within a 'Favorites' tab */
        ADD_TO_FAVORITES_BUTTON: UIAQuery.navigationBars('Favorites').andThen(UIAQuery.buttons('Add')),

        /** 'Recents' button within a TabBar */
        RECENTS_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Recents')),

        /** 'All' tab button within a 'Recents' tab */
        ALL_RECENTS_TABBUTTON: UIAQuery.navigationBars('Recents').andThen(UIAQuery.buttons('All')), 

        /** 'Missed' tab button within a 'Recents' tab */
        MISSED_RECENTS_TABBUTTON: UIAQuery.navigationBars('Recents').andThen(UIAQuery.buttons('Missed')), 

        /** 'Contacts' button within a TabBar */
        CONTACTS_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Contacts')), 

        /** 'Add Contact' button within a 'Contacts' tab */
        ADD_CONTACT_BUTTON: UIAQuery.navigationBars('Contacts').andThen(UIAQuery.buttons('Add')), 

        /** 'Keypad' button within a TabBar */
        KEYPAD_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Keypad')),

        /** 'Voicemail' button within a TabBar */
        VOICEMAIL_TABBAR: UIAQuery.tabBars().andThen(UIAQuery.buttons('Voicemail')),

        /** 'Call Voicemail' button on a 'Voicemail' screen */
        CALL_VOICEMAIL_BUTTON: UIAQuery.buttons('Call Voicemail'), 

        /** 'mute' button within the PHAudioCallControlsView element */
        IN_CALL_MUTE_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('mute')),

        /** 'keypad' button within the PHAudioCallControlsView element */
        IN_CALL_KEYPAD_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('keypad')),

        /** 'speaker' button within the PHAudioCallControlsView element */
        IN_CALL_SPEAKER_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('speaker')),

        /** 'hold' button within the PHAudioCallControlsView element */
        IN_CALL_HOLD_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('hold')),

        /** 'add call' button within the PHAudioCallControlsView element */
        IN_CALL_ADD_CALL_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('add call')),

        /** 'FaceTime' button within the PHAudioCallControlsView element */
        IN_CALL_FACETIME_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('FaceTime')),

        /** 'contacts' button within the PHAudioCallControlsView element */
        IN_CALL_CONTACTS_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('contacts')),

        /** 'merge calls' button within the PHAudioCallControlsView element */
        IN_CALL_MERGE_CALLS_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('merge calls')),

        /** 'swap' button within the PHAudioCallControlsView element */
        IN_CALL_SWAP_BUTTON: UIAQuery.contains('PHAudioCallControlsView').andThen(UIAQuery.buttons('swap')),

        /** In conference call */
        CONFERENCE_CALL: UIAQuery.contains("PHSingleCallParticipantLabelView").andThen(UIAQuery.staticTexts('Conference')),

        /** 'Call' button within the PHHandsetDialerView element */
        CALL_BUTTON: UIAQuery.contains('PHHandsetDialerView').andThen(UIAQuery.buttons('Call')),

        /** 'End call' button within the PHBottomBar element */
        END_CALL_BUTTON: UIAQuery.contains('PHBottomBar').andThen(UIAQuery.buttons('End call')).orElse(
                            UIAQuery.contains('TPSuperBottomBar').andThen(UIAQuery.buttons('End call'))).orElse(
                            UIAQuery.buttons('PHBottomBarButton')),
        
        /** 'Search' bar within Contacts view */
        CONTACTS_SEARCHBAR: UIAQuery.searchBars('Search'),

        /** 'Clear text' button within Search Bar in Phone Contacts */
        CONTACTS_SEARCHBAR_CLEARTEXT_BUTTON: UIAQuery.contains('UISearchBar').andThen(UIAQuery.buttons('Clear text')),

        /** No Voicemail view when there is no incoming messages */
        NO_VOICEMAIL_VIEW: UIAQuery.tableViews('No Voicemail'),

        /** Voicemail message cells */
        VOICEMAIL_MESSAGE_CELLS: UIAQuery.tableViews('UITableView').andThen(UIAQuery.tableCells()),

        /** Voicemail Play Button */
        VOICEMAIL_PLAY_BUTTON: UIAQuery.buttons('Play voicemail'),

        /** Voicemail Pause Button */
        VOICEMAIL_PAUSE_BUTTON: UIAQuery.buttons('Pause voicemail'),
    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: UI State Constants                                                  */
    /*                                                                             */
    /*      A dictionary of strings describing the possible UI states of the app   */
    /*                                                                             */
    /*******************************************************************************/

    /** Constants for possible UI state names specific to Phone */
    UIStateDescription.Phone = {
    /** Favorites */
        FAVORITES:              'favorites',

    /** Add Favorite */
        ADD_FAVORITE:           'add favorite',

    /** Recents */
        RECENTS:                'recents',

    /** Contacts */
        CONTACTS:               'contacts',

    /** Contact */
        CONTACT:                'contact',

    /** New Contact */
        NEW_CONTACT:            'new contact',

    /** Edit Contact */
        EDIT_CONTACT:           'edit contact',

    /** Ringtone */
        RINGTONE:               'ringtone',

    /** Add Field */
        ADD_FIELD:              'add field',

    /** Link Contact */
        LINK_CONTACT:           'link contact',

    /** Keypad */
        KEYPAD:                 'keypad',

    /** Keypad (new contact) */
        KEYPAD_NEW_CONTACT:     'keypad (new contact)',

    /** Edit Contact (edit contact) */
        KEYPAD_EDIT_CONTACT:    'keypad (edit contact)',

    /** Incoming Call */
        INCOMING_CALL:          'incoming call',

    /** Calling */
        CALLING:                'calling',

    /** In Call */
        IN_CALL:                'in call',

    /** In Call (keypad) */
        IN_CALL_KEYPAD:         'in call (keypad)',

    /** In Call (contacts) */
        IN_CALL_CONSTACTS:      'in call (contacts)',

    /** In Call (conference) */
        IN_CALL_CONFERENCE:     'in call (conference)',

    /** Add Call */
        ADD_CALL:               'add call',
    };


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Other Constants                                                     */
    /*                                                                             */
    /*      Any other app specific constants                                       */
    /*                                                                             */
    /*******************************************************************************/

    /**
     *  Constants for possible call states
     *
     *  @namespace
     */

    CallStates = {
    /**  idle */
        IDLE: "Idle",

    /**  held */
        HELD: "Held",

    /**  sending */
        SENDING: "Sending",

    /**  ringing */
        RINGING: "Ringing",

    /**  disconnected */
        DISCONNECTED: "Disconnected",

    /**  alerting */
        ALERTING: "Alerting",

    /**  waiting */
        WAITING: "Waiting",

    /**  active */
        ACTIVE: "Active",

    /**  unknown */
        UNKNOWN: "Unknown",
    };


    /**
        @namespace
        @augments UIAApp
    */
    var phone = target.appWithBundleID('com.apple.mobilephone');


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get The Current UI State                                            */
    /*                                                                             */
    /*      A function to determine which UIState the app is currently in          */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Return description of current UI state.  See UIStateDescription constants defined in UIAApp and Phone for possible values.
     *
     * @returns {string} Description of current UI state from a list of possible constants contained in UIStateDescription.
     */
    phone.currentUIState = function currentUIState() {
        throw new UIAError('Not yet implemented.');
    }


    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Get To [page] functions                                             */
    /*                                                                             */
    /*      Helper functions for navigating to different pages within the app      */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Navigate to the call page
     */
    phone.getToCallPage = function getToCallPage() {
        throw new UIAError("Not yet implemented.");
    }

    /**
     * Navigate to the Favorites page
     */
    phone.getToFavoritesView = function getToFavoritesView() {
        this.launch();
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.FAVORITES_TABBAR);
    }

    /**
     * Tap on Add To Favorites button on Favorites screen
     */
    phone.addToFavorites = function addToFavorites() {
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.ADD_TO_FAVORITES_BUTTON);
    }

    /**
     * Navigate to the Recents page
     */
    phone.getToRecentsView = function getToRecentsView() {
        this.launch();
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.RECENTS_TABBAR);
    }

    /**
     * Navigate to 'All' tab on Recents page
     */
    phone.getToAllRecents = function getToAllRecents() {
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.ALL_RECENTS_TABBUTTON);
    }

    /**
     * Navigate to 'Missed' tab on Recents page
     */
    phone.getToMissedRecents = function getToMissedRecents() {
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.MISSED_RECENTS_TABBUTTON);
    }

    /**
     * Navigate to the Contacts page
     */
    phone.getToContactsList = function getToContactsList() {
        this.launch();
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.CONTACTS_TABBAR);
    }

    /**
     * Tap on 'Add' button within Contacts page
     */
    phone.addToContacts = function addToContacts() {
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.ADD_CONTACT_BUTTON);
    }

    /**
     * Navigate to the Keypad page
     */
    phone.getToKeypadView = function getToKeypadView(options) {
        this.launch();
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.KEYPAD_TABBAR);
    }

    /**
     * Navigate to the Voicemail page
     */
    phone.getToVoicemailView = function getToVoicemailView(options) {
        this.launch();
        this.tapAllCancelOrDoneButtons();
        this.tap(UIAQuery.Phone.VOICEMAIL_TABBAR);
    }


    /***********************************************************************************/
    /*                                                                                 */
    /*   Mark: Tasks                                                                   */
    /*                                                                                 */
    /*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
    /*      These will be comprised of multiple Action functions                       */
    /*                                                                                 */
    /***********************************************************************************/

    /**
     * Make call(s)
     *
     * @param {object} options
     * @param {array} options.phoneNumbers - Array of phone numbers (strings) to be dialed
     * @param {boolean} options.shouldReset - A boolean, if true, hang up and return to the keypad view after placing each call
     * @param {boolean} options.shouldMerge - A boolean, if true, the last two calls are merged
     * @param {string} options.desiredCallStatus - The desired call status after tapping the 'Call' button
     * @param {int} options.timeout - The number of seconds to wait for the desiredCallStatus
     */
    phone.makeCall = function makeCall(options) {
        if (!options.timeout) {
            options.timeout = 10;//default to 10 second timeout
        }
        var phoneAlert = UIAQuery.query('PHCallParticipantsView');
        this.handlingAlertsInline(phoneAlert, function() {
            for (var i = 0; i < options.phoneNumbers.length; i++) {

                var numActiveCalls = target.activeCallCount();
                if (numActiveCalls > 1) {
                    phone.mergeCalls();
                }
                if (numActiveCalls > 0) {
                    if (springboard.waitUntilPresent(UIAQuery.Phone.IN_CALL_ADD_CALL_BUTTON.isEnabled(), 30)) {
                        springboard.tap(UIAQuery.Phone.IN_CALL_ADD_CALL_BUTTON);
                        this.waitUntilPresent(UIAQuery.Phone.KEYPAD_TABBAR);
                        this.tap(UIAQuery.Phone.KEYPAD_TABBAR);
                    } else {
                        throw new UIAError("Add Call button did not show up.");
                    }
                } else {
                    this.getToKeypadView();
                }

                this.dialNumber(this.returnCleanedNumber(options.phoneNumbers[i]));

                var callStatusWaiter = UIAWaiter.waiter('CallStatusChanged', {predicate: 'status == "'+options.desiredCallStatus+'"'});
                this.tap(UIAQuery.Phone.CALL_BUTTON);
                var success = callStatusWaiter.wait(options.timeout);

                if (!success) {
                    throw new UIAError("Failed to acheive the desiredCallStatus");
                } else {
                    UIALogger.logMessage("CallStatus: " + options.desiredCallStatus);
                }

                if (options.shouldReset) {
                    springboard.tap(UIAQuery.Phone.END_CALL_BUTTON);
                }
            }

            if (options.shouldMerge) {
                phone.mergeCalls();
            }
        });
    }

    /**
     * Ends all existing calls
     */
    phone.endAllCalls = function endAllCalls() {
        var callCount = target.activeCallCount();
        UIALogger.logMessage("Starting CallCount: " + callCount);
        while (callCount != 0) {
            this.endCall();
            callCount = target.activeCallCount();
            UIALogger.logMessage("Current CallCount: " + callCount);
        }
    }

    /**
     * Search for a specified contact
     *
     * @param {object} options
     * @param {string} options.contactName - Full name of a contact to search 
     */
    phone.searchForContact = function searchForContact(options) {
        UIALogger.logMessage('About to search for contact "%0"'.format(options.contactName));
        phone.getToContactsList();
        this.tap(UIAQuery.Phone.CONTACTS_SEARCHBAR);
        // Clear the Search bar text field if there is anything in it
        var clearButton = UIAQuery.Phone.CONTACTS_SEARCHBAR_CLEARTEXT_BUTTON;
        if (this.exists(clearButton)) {
            UIALogger.logMessage('Tapping "Clear text" button within the Contacts Search bar');
            this.tap(clearButton);
        }
        // Type in the string to search 
        this.typeString(options.contactName); 
        // Tap 'Search' key on a keyboard
        this.tap(UIAQuery.keyboard().andThen('Search'));
        // Validate the result 
        var searchResult = UIAQuery.staticTexts(options.contactName);
        if (!this.exists(searchResult)) {
            throw new UIAError('Failed to find "%0" in Phone Contacts'.format(options.contactName));
        }
        this.tap(searchResult);
    }
    
    /**
     * Make a call to Voicemail
     * @param {object} options
     * @param {boolean} options.shouldReset - A boolean, if true, hang up and return to the keypad view after placing each call
     * @param {string} options.desiredCallStatus - The desired call status after tapping the 'Call' button
     * @param {int} options.timeout - The number of seconds to wait for the desiredCallStatus
     * @param {int} options.callTime - Playback time or time to wait while the call is active, sec
     */
    phone.callVoicemail = function callVoicemail(options) {
        this.getToVoicemailView();
        if (this.exists(UIAQuery.Phone.NO_VOICEMAIL_VIEW)) {
            UIALogger.logMessage('Voicemail with embedded player detected');
            UIALogger.logMessage('No voicemail messages found');
            // Pass the test: if there's no incoming messages, there's nothing more to test here
            return;
        }
        if (this.exists(UIAQuery.Phone.VOICEMAIL_MESSAGE_CELLS)) {
            UIALogger.logMessage('Voicemail with embedded player detected');
            var messageCell = UIAQuery.Phone.VOICEMAIL_MESSAGE_CELLS.first();
            if (messageCell) {
                UIALogger.logMessage('Attempting to open a voicemail message "%0"'.format(this.inspect(messageCell.andThen(UIAQuery.withPredicate('behavior == "Element"').atIndex(0))).label));
                this.tap(messageCell);
                if (this.exists(UIAQuery.Phone.VOICEMAIL_PLAY_BUTTON)) {
                    // Play voicemail message for callTime sec, pause then if it's not finished
                    UIALogger.logMessage('Playing message...');
                    this.tap(UIAQuery.Phone.VOICEMAIL_PLAY_BUTTON);
                    // Verify that the playback has started
                    UIAUtilities.assert(
                        this.waitUntilPresent(UIAQuery.Phone.VOICEMAIL_PAUSE_BUTTON, 5.0),
                        'Voicemail playback not started'
                    );
                    
                    if (!this.waitUntilPresent(UIAQuery.Phone.VOICEMAIL_PLAY_BUTTON, options.callTime)) {
                        this.tap(UIAQuery.Phone.VOICEMAIL_PAUSE_BUTTON);
                    }
                }
            } else {
                throw new UIAError('Failed to get access to Voicemail message');
            }
        } else if (this.exists(UIAQuery.Phone.CALL_VOICEMAIL_BUTTON)) {
            UIALogger.logMessage('Legacy Voicemail detected');
            var callStatusWaiter = UIAWaiter.waiter('CallStatusChanged', {predicate: 'status == "%0"'.format(options.desiredCallStatus)});
            this.tap(UIAQuery.Phone.CALL_VOICEMAIL_BUTTON);
            var success = callStatusWaiter.wait(options.timeout);
            if (!success) {
                throw new UIAError('Failed to acheive the desiredCallStatus');
            } else {
                UIALogger.logMessage('CallStatus: %0'.format(options.desiredCallStatus));
            }

            if (options.shouldReset) {
                springboard.tap(UIAQuery.Phone.END_CALL_BUTTON);
            } else {
                target.delay(options.callTime);
                this.endCall();
            }
        } else {
            throw new UIAError('Undefined version of Voicemail');
        }
    }

    /*******************************************************************************/
    /*                                                                             */
    /*   Mark: Actions                                                             */
    /*                                                                             */
    /*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
    /*      Other helper functions. E.g. - returnCleanedNumber                     */
    /*                                                                             */
    /*******************************************************************************/

    /**
     * Dial the phone number
     *
     * @param {string} phoneNumber - The phone number to dial
     */
    phone.dialNumber = function dialNumber(phoneNumber) {
        if (!phoneNumber) {
            throw new UIAError('Missing required argument: phoneNumber');
        }
        while (this.exists(UIAQuery.buttons("DeleteButton").isVisible())) {
            this.tap(UIAQuery.buttons("DeleteButton"));
        }
        UIALogger.logMessage('Dialing number "' + phoneNumber + '"');
        var numPad = UIAQuery.query("TPDialerNumberPad");
        this.withAnimationTimeout(0.5, (function() {
            for (var i = 0; i < phoneNumber.length; i++) {
                var digit = phoneNumber.charAt(i);
                if (digit == '#') {
                    this.tap(numPad.andThen('Pound'));
                } else if (digit == '*') {
                    this.tap(numPad.andThen('Star'));
                } else if (digit == '+') {
                    this.touchAndHold('0',2);
                } else if (digit == ',') {
                    this.touchAndHold('Star',2);
                } else if (digit == ';') {
                    this.touchAndHold('Pound',2);
                } else {
                    this.tap(numPad.andThen(digit));
                }
            }
        }).bind(this));
    }

    /**
     * Returns a phone number after removing all occurences of (,),-, and " "
     *
     * @param {string} phoneNumber - The phone number to clean
     * @returns {string} the cleaned phone number
     */
    phone.returnCleanedNumber = function returnCleanedNumber(phoneNumber) {
        // return phoneNumber.replace(/\(|\)| |-/g,""); // DONT DO THIS - DOESN'T CATCH ALL DIFFERENT TYPES OF UNICODE SPACES
        if ( phoneNumber === 'undefined' || typeof(phoneNumber) !== "string" ) {
            UIALogger.logMessage('Phone Number:' + typeof(phoneNumber) + ':' + phoneNumber);
            throw new UIAError('Phone number is not valid value');
        }
        return phoneNumber.match(/[\d*#]+/g).join('');
    }

    /**
     * Ends a call
     *
     * @param {string} phoneNumber - The phone number of the call to end
     */
    phone.endCall = function endCall(phoneNumber) {
        // Function to force kill calls if they are still running at the end of the test.
        function forceEndCall(phoneNumber) {
            var currentCallCount = target.activeCallCount();
            var targetCallCount = phoneNumber?target.activeCallCount()-1:0;
            var previousCallCount = 0;
            while (currentCallCount > targetCallCount && currentCallCount != previousCallCount) {
                previousCallCount = currentCallCount;
                UIALogger.logMessage("Attempting to kill call");
                // Get call off hold
                target.activeApp().waitUntilPresent(UIAQuery.Phone.IN_CALL_HOLD_BUTTON);
                target.activeApp().tapIfExists(UIAQuery.Phone.IN_CALL_HOLD_BUTTON.isSelected());
                target.activeApp().waitUntilAbsent(UIAQuery.Phone.IN_CALL_HOLD_BUTTON.isSelected());

                var r = target.performTask('/usr/local/bin/testCT', ['-e'], 10);
                currentCallCount = target.activeCallCount();
            }

            if (target.activeCallCount() != targetCallCount) {
                throw new UIAError("Could not force end all calls");
            }
        }
        // REMOVE ONCE THIS IS FIX:  Work around for default alert handler tapping the first button and getting us into the info page.
        // <rdar://problem/20670759> [UIA2/AX] Permission to remove changes that made Call Failure screen behave more like an Alert
        // <rdar://problem/20575690> 13A224: Not properly ending phone calls
        target.activeApp().tapIfExists(UIAQuery.BACK_NAV_BUTTON);
        // END WORK AROUND

        if (target.activeCallCount() < 1) {
            throw new UIAError("No active calls to end.");
        }
        var callCount = target.activeCallCount();
        var callStatusWaiter = UIAWaiter.withPredicate(
            'CallStatusChanged',
            'status == "Disconnected"'
        );
        var success = true;
        if (phoneNumber) {
            if (!phone.isActiveCall(phoneNumber) && callCount > 1) {
                springboard.tap(UIAQuery.Phone.IN_CALL_SWAP_BUTTON);
            }
            if (phone.isActiveCall(phoneNumber)) {
                springboard.tap(UIAQuery.Phone.END_CALL_BUTTON);
                success = callStatusWaiter.wait(5);
            } else {
                throw new UIAError('Could not get to the desired call.');
            }
        } else {
            springboard.tap(UIAQuery.Phone.END_CALL_BUTTON);
            success = callStatusWaiter.wait(5);
        }

        if (!success) {
            forceEndCall(phoneNumber);
            throw new UIAError('Could not end the call.');
        }
    }

    /**
     * Merge two in progress calls
     */
    phone.mergeCalls = function mergeCalls() {
        UIALogger.logMessage('MERGE THOSE CALLS');
        var callCount = target.activeCallCount();
        if (callCount < 2) {
            throw new UIAError('Not enough calls to merge.');
        }

        if (!springboard.waitUntilPresent(UIAQuery.Phone.IN_CALL_MERGE_CALLS_BUTTON.isEnabled(), 20)) {
            throw new UIAError("Merge Call button never became enabled.");
        }
        springboard.tap(UIAQuery.Phone.IN_CALL_MERGE_CALLS_BUTTON);

        if ( target.systemApp().exists("Multiple Calls") ) {
            if (!target.systemApp().waitUntilPresent(UIAQuery.Phone.IN_CALL_ADD_CALL_BUTTON.withPredicate("isEnabled == 0"), 3)) {
                throw new UIAError('Did not establish merged call (CDMA)');
            }
        }
        else {
            if (!target.systemApp().waitUntilPresent(UIAQuery.Phone.CONFERENCE_CALL, 30)) {
                throw new UIAError('Did not establish merged call (GSM)');
            }
        }
    }

    /**
     * Check if a phone number is the active call.
     *
     * @param {string} phoneNumber - the phone number to check.
     * @returns {boolean} true if the number is the active call.
     */
    phone.isActiveCall = function isActiveCall(phoneNumber) {
        if (!phoneNumber) {
            throw new UIAError('Missing required argument: phoneNumber');
        }
        if (target.activeCallCount() < 1) {
            return false;
        }
        var cleanedNumber = phone.returnCleanedNumber(phoneNumber);
        var activeCall = UIAQuery.contains("PHSingleCallParticipantLabelView").andThen(UIAQuery.staticTexts());
        var activeCalls = UIAQuery.contains("PHMultipleCallParticipantLabelView").withPredicate("ALL children.name != 'hold'").andThen(UIAQuery.staticTexts());
        var phoneNumberMarquee = target.systemApp().inspect(activeCall.orElse(activeCalls)).label;
        if (phoneNumberMarquee === "Conference") {
            UIALogger.logMessage("We are on a conference call.")
            return true;
        }
        else if (phoneNumberMarquee.indexOf('&') == -1) {
            return cleanedNumber == phone.returnCleanedNumber(phoneNumberMarquee);
        } else {
            var phoneNumbers = phoneNumberMarquee.split('&');
            for (var i = 0; i < phoneNumbers.length; i++) {
                if (cleanedNumber == phone.returnCleanedNumber(phoneNumbers[i])) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Tap all of the visible cancel or done buttons
     */
    phone.tapAllCancelOrDoneButtons = function tapAllCancelOrDoneButtons() {
        var count = 0;// tap a maximum of 10 times
        while (phone.exists(UIAQuery.buttons('Cancel').orElse(UIAQuery.buttons('Done'))) && count < 10) {
            this.tap(UIAQuery.buttons('Cancel').orElse(UIAQuery.buttons('Done')));
            count += 1;
        }
    }

    /**
     * Clear Recent Calls tab from Phone history
     */
    phone.clearRecentTab = function clearRecentTab() {
        UIALogger.logMessage('Clearing Recent Call History from iPhone');
        this.getToRecentsView();

        // Clear all the calls from Recents folder if count > 0
        if (this.count(UIAQuery.query('UITableViewCellAccessibilityElement')) > 0) {
            this.tap(UIAQuery.buttons('Edit'));
            this.tap(UIAQuery.buttons('Clear'));

            var clearRecentsButton = UIAQuery.buttons().beginsWith('Clear ');
            if (!this.waitUntilPresent(clearRecentsButton.isEnabled(), 2)) {
                    throw new UIAError("Clear All Recents button did not appear on Phone's Recents tab");
            }

            this.tap(clearRecentsButton);
        }
    }

}
