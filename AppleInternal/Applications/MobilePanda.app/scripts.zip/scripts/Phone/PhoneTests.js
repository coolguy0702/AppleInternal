load('UIATesting.js');
load('Phone.js');

if (typeof PhoneTests === 'undefined') {
    /**
     * @namespace PhoneTests
     */
    var PhoneTests = {

        /**
          * Place a call to a specified phone number then hang up
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          *
          * @param {object} args - Test arguments
          * @param {string} [args.phoneNumber=""] - Required phone number to call
          * @param {boolean} [args.waitForAnswer=true] - Optional if true wait for call to be 'Active' else wait for call to be 'Sending'
          * @param {int} [args.timeout=10] - Optional timeout to wait for the call to exist
          * @param {int} [args.callTime=3] - Optional time to wait while the call is active
          */
         placeCall: function placeCall(args) {
          args = UIAUtilities.defaults(args, {
            phoneNumber: '',
            waitForAnswer: true,
            timeout: 10,
            callTime: 3,
          })

          if (!args.phoneNumber) {
              throw new UIAError('Missing required argument: phoneNumber');
          }

          var desiredCallStatus = 'Active';
          if (!args.waitForAnswer) {
            desiredCallStatus = 'Sending';
          }

          var options = {
            phoneNumbers: [args.phoneNumber],
            shouldReset: false,
            shouldMerge: false,
            desiredCallStatus: desiredCallStatus,
            timeout: args.timeout,
          }
          phone.makeCall(options);
          target.delay(args.callTime);
          PhoneTests.endCall(options);
         },

         /**
          * Make a call to a specified phone number
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          *
          * @param {object} args - Test arguments
          * @param {string} [args.phoneNumber=""] - Required phone number to call
          * @param {boolean} [args.waitForAnswer=true] - Optional if true wait for call to be 'Active' else wait for call to be 'Sending'
          * @param {int} [args.timeout=10] - Optional timeout to wait for the call to exist
          */
         makeCall: function makeCall(args) {
          args = UIAUtilities.defaults(args, {
            phoneNumber: '',
            waitForAnswer: true,
            timeout: 10,
          })

          if (!args.phoneNumber) {
              throw new UIAError('Missing required argument: phoneNumber');
          }

          var desiredCallStatus = 'Active';
          if (!args.waitForAnswer) {
            desiredCallStatus = 'Sending';
          }

          var options = {
            phoneNumbers: [args.phoneNumber],
            shouldReset: false,
            shouldMerge: false,
            desiredCallStatus: desiredCallStatus,
            timeout: args.timeout,
          }
          phone.makeCall(options);
         },
         /**
          * Add a call to the existing call.
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          *
          * @param {object} args - Test arguments
          * @param {string} [args.phoneNumber=""] - Required phone number to add
          * @param {boolean} [args.waitForAnswer=true] - Optional if true wait for call to be 'Active' else wait for call to be 'Sending'
          * @param {int} [args.timeout=10] - Optional timeout to wait for the call to exist
          */
         addCall: function addCall(args) {
          args = UIAUtilities.defaults(args, {
            phoneNumber: '',
            waitForAnswer: true,
            timeout: 10,
          })

          if (!args.phoneNumber) {
              throw new UIAError('Missing required argument: phoneNumber');
          }

          var desiredCallStatus = 'Active';
          if (!args.waitForAnswer) {
            desiredCallStatus = 'Sending';
          }

          var options = {
            phoneNumbers: [args.phoneNumber],
            shouldReset: false,
            shouldMerge: false,
            desiredCallStatus: desiredCallStatus,
            timeout: args.timeout,
          }
          phone.makeCall(options);
         },
         /**
          * Merge two in-progress calls together
          */
         mergeCall: function mergeCalls() {
          phone.mergeCalls();
         },
         /**
          * End an existing call.
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          *
          * @param {object} args - Test arguments
          * @param {string} [args.phoneNumber] - Optional phone number of call to end
          */
         endCall: function endCall(args) {
          phone.endCall(args.phoneNumber);
         },
         /**
          * Clear Recent Calls tab from Phone history
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          */
         clearRecentTab: function clearRecentTab() {
          phone.clearRecentTab();
         },
         /**
          * Search for a contact
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          *
          * @param {object} args - Test arguments
          * @param {string} [args.contactName=""] - Required contact name
          */
         searchForContact: function searchForContact(args) {
          args = UIAUtilities.defaults(args, {
            contactName: '',
          })

          if (!args.contactName) {
              throw new UIAError('Missing required argument: contactName');
          }

          phone.searchForContact(args)
         },
         /**
          * Navigate to each tab of Phone app
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          */
         checkAllTabs: function checkAllTabs() {
          phone.getToFavoritesView();
          phone.addToFavorites();
          phone.getToRecentsView();
          phone.getToAllRecents();
          phone.getToMissedRecents();
          phone.getToAllRecents();
          phone.getToContactsList();
          phone.addToContacts();
          phone.getToKeypadView();
          phone.getToVoicemailView();
         }, 
         /**
          * Make a call to Voicemail
          *
          * @eligibleResource deviceClass == 'iPhone'
          * @targetApps MobilePhone
          * 
          * @param {object} args - Test arguments
          * @param {int} [args.timeout=10] - Optional timeout to wait for the call to exist
          * @param {int} [args.callTime=3] - Optional time to wait while the call is active
          */
         callVoicemail: function callVoicemail(args) {
          args = UIAUtilities.defaults(args, {
            timeout: 10,
            callTime: 3,
          });
          var options = {
            timeout: args.timeout,
            desiredCallStatus: 'Active',
            callTime: args.callTime,
          };
          phone.callVoicemail(options);
         }, 
    }
}
