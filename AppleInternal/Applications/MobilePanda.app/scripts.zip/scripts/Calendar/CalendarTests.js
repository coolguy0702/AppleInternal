load("UIATesting.js");
load("SpringBoard.js");
load("Calendar.js");

if (typeof CalendarTestUtilities !== 'undefined') throw new UIAError("CalendarTestUtilities has already been loaded!", {identifier:"UIA module already loaded"});
if (typeof CalendarTest !== 'undefined') throw new UIAError("CalendarTest has already been loaded!", {identifier:"UIA module already loaded"});

var CalendarTestUtilities = {
    _removeUndefinedFields: function _removeUndefinedFields(obj) {
        var undefinedFields = Object.keys(obj).filter(function (f) { return obj[f] === undefined || obj[f] === null; });
        for (var i in undefinedFields) {
            delete obj[ undefinedFields[i] ];
        }
        return obj;
    },

    _cleanedDate: function _cleanedDate(dateString) {
        dateString = this._cleanedString(dateString);
        // This is for parsing RepeatEndDates; Calendar.js interprets UNDEFINED as "don't change the current value" and NULL as "explicitly set value to null"
        if (dateString === undefined || dateString === null || dateString.match(/^never$/i)) return null;

        var date = new Date(dateString);
        return isNaN(date) ? undefined : date;
    },

    _cleanedBool: function _cleanedBool(boolString) {
        return (typeof boolString == 'string') ? boolString.match(/^true$/i) :
               (typeof boolString == 'number' ) ? (boolString != 0) :
               (typeof boolString == 'boolean' ) ? boolString : undefined;
    },

    _cleanedNumber: function _cleanedNumber(numString) {
        return (!isNaN(numString) && (typeof numString == 'number')) ? numString : undefined;
    },

    _cleanedString: function _cleanedString(string) {
        return string ? String(string) : undefined;
    },

    _cleanedHash: function _cleanedHash(thunk) {
        var hash = new Object();
        if (typeof thunk == 'undefined') return hash;
        else if (thunk === null) return hash;
        else if (thunk instanceof Array) {
            for (var i in thunk) {
                hash[ String(thunk[i]) ] = "";
            }

        } else if (typeof thunk == 'object') {
            for (var property in thunk) {
                if (thunk.hasOwnProperty(property)) {
                    hash[ String(property) ] = this._cleanedString( thunk[property] );
                }
            }

        } else {
            hash[ String(thunk) ] = "";
        }

        return hash;
    },

    _cleanedStringArray: function _cleanedStringArray(thunk) {
        var arr = [];
        if (typeof thunk == 'undefined') return arr;
        else if (thunk === null) return arr;
        else if (thunk instanceof Array) {
            for (var i in thunk) {
                arr.push( this._cleanedString(thunk[i]) );
            }

        } else {
            arr.push( this._cleanedString(thunk) );
        }

        return arr;
    },

    generateUniqueTitle: function generateUniqueTitle() {
        return "Event %0".format(UIAUtilities.randomInt(0, 10000));
    },

    extractEventFieldsOnly: function extractEventFieldsOnly(options) {
        return {
            Title:              options.Title,
            StartDate:          options.StartDate,
            EndDate:            options.EndDate,
            Location:           options.Location,
            CalendarName:       options.CalendarName,
            CalendarGroup:      options.CalendarGroup,
            AllDay:             options.AllDay,
            Repeat:             options.Repeat,
            RepeatEndDate:      options.RepeatEndDate,
            Invitees:           options.Invitees,
            InvitationFrom:     options.InvitationFrom,
            Alert:              options.Alert,
            ShowAs:             options.ShowAs,
            Private:            options.Private,
            Url:                options.Url,
            Notes:              options.Notes,
        };
    },

    defaultTestArgs: function defaultTestArgs(args, customDefaults) {
        // First override with custom defaults if available
        if (typeof customDefaults == 'object') args = UIAUtilities.defaults(args, customDefaults);

        return UIAUtilities.defaults(args, {
            Title:                      "",
            PredicateString:            "",
            NewTitle:                   "",
            Location:                   "",

            StartDate:                  "",
            NewStartDate:               "",
            EndDate:                    "",
            AllDay:                     false,
            Repeat:                     "",
            RepeatEndDate:              "",
            Invitees:                   [],
            InvitationFrom:             "",
            Alert:                      "",
            ShowAs:                     "",
            Private:                    false,
            Url:                        "",
            Notes:                      "",
            TravelTime:                 "",

            ApplyToFutureOccurrences:   false,

            Response:                   "",
            AcceptAll:                  false,
            ReplyComment:               "",

            CalendarGroup:              "",
            CalendarName:               "",
            SharedWith:                 [],
            Color:                      "",
            CalendarIsPublic:           false,
            ShowSharedEventChanges:     true,
            ShareLink:                  "",
            Notifications:              true,
            Visibility:                 true,
            ShowDeclinedEvents:         false,

            WorkflowToEvent:            "",
            InboxList:                  "",
            PredicateString:            "",
            ExpectPredicateToFindMatch: true,

            ViewsToNavigate:            [],
            TargetDate:                 "",
            SkipVerification:           false,
        });
    },

    // Parses args dictionary into calendar test arguments
    parseOptions: function parseOptions(args, customOverrides) {
        // First do type-checking
        var options = {
            Title:                      this._cleanedString(args.Title),
            NewTitle:                   this._cleanedString(args.NewTitle),
            Location:                   this._cleanedString(args.Location),

            StartDate:                  this._cleanedDate(args.StartDate),
            NewStartDate:               this._cleanedDate(args.NewStartDate),
            EndDate:                    this._cleanedDate(args.EndDate),
            AllDay:                     this._cleanedBool(args.AllDay),
            Repeat:                     this._cleanedString(args.Repeat),
            RepeatEndDate:              this._cleanedDate(args.RepeatEndDate),
            Invitees:                   this._cleanedStringArray(args.Invitees),
            InvitationFrom:             this._cleanedString(args.InvitationFrom),
            Alert:                      this._cleanedString(args.Alert),
            ShowAs:                     this._cleanedString(args.ShowAs),
            Private:                    this._cleanedBool(args.Private),
            Url:                        this._cleanedString(args.Url),
            Notes:                      this._cleanedString(args.Notes),
            TravelTime:                 this._cleanedString(args.TravelTime),

            ApplyToFutureOccurrences:   this._cleanedBool(args.ApplyToFutureOccurrences),

            Response:                   this._cleanedString(args.Response),
            AcceptAll:                  this._cleanedBool(args.AcceptAll),
            ReplyComment:               this._cleanedString(args.ReplyComment),

            CalendarGroup:              this._cleanedString(args.CalendarGroup),
            CalendarName:               this._cleanedString(args.CalendarName),
            SharedWith:                 this._cleanedStringArray(args.SharedWith),
            Color:                      this._cleanedString(args.Color),
            CalendarIsPublic:           this._cleanedBool(args.CalendarIsPublic),
            ShowSharedEventChanges:     this._cleanedBool(args.ShowSharedEventChanges),
            ShareLink:                  this._cleanedString(args.ShareLink),
            Notifications:              this._cleanedBool(args.Notifications),
            Visibility:                 this._cleanedBool(args.Visibility),
            ShowDeclinedEvents:         this._cleanedBool(args.ShowDeclinedEvents),

            WorkflowToEvent:            this._cleanedString(args.WorkflowToEvent),
            InboxList:                  this._cleanedString(args.InboxList),
            PredicateString:            this._cleanedString(args.PredicateString),
            ExpectPredicateToFindMatch: this._cleanedBool(args.ExpectPredicateToFindMatch),

            ViewsToNavigate:            this._cleanedStringArray(args.ViewsToNavigate),
            TargetDate:                 this._cleanedDate(args.TargetDate),

            AddEvent:                   this._cleanedBool(args.AddEvent),
            Timeout:                    this._cleanedNumber(args.Timeout),
        };

        // Then do value-checking
        if (! options.Title) {
            UIALogger.logWarning("No title provided; will create a unique event name based on the Unix Epoch!");
            options.Title = this.generateUniqueTitle();
        }

        if (! options.StartDate) {
            UIALogger.logWarning("No valid StartDate provided; will default to 3 days in the future!");
            options.StartDate = new Date();
            options.StartDate.setDate(options.StartDate.getDate() + 3);
            // Make sure that a default event doesn't span over a single day: <rdar://problem/23426950> Two events or more are present on deletion.
            if (options.StartDate.getHours() > 22) {
                options.StartDate.setHours(22);
                options.StartDate.setMinutes(59);
            }
        }

        if (options.InboxList) {
            options.InboxList = calendar._sanitizeInboxList(options.InboxList);
        }

        if (options.Response) {
            options.Response = calendar._sanitizeInviteResponse(options.Response);
        }

        if (options.ShowAs) {
            options.ShowAs = calendar._sanitizeAvailability(options.ShowAs);
        }

        if (options.WorkflowToEvent) {
            options.WorkflowToEvent = calendar._sanitizeWorkflowToEvent(options.WorkflowToEvent);
        }

        if (options.ViewsToNavigate) {
            var navigationMap = {
                'Day':      UIStateDescription.Calendar.DAY_VIEW,
                'Week':     UIStateDescription.Calendar.WEEK_VIEW,
                'Month':    UIStateDescription.Calendar.MONTH_VIEW,
                'Year':     UIStateDescription.Calendar.YEAR_VIEW,
                'List':     UIStateDescription.Calendar.LIST_VIEW,
            };
            options.ViewsToNavigate = options.ViewsToNavigate.map(function (v) { return calendar._sanitizeViewName(v); }).map(function (k) { return navigationMap[k]; });
        }

        if (typeof customOverrides == 'object') options = UIAUtilities.defaults(customOverrides, options);

        UIALogger.logMessage("Calendar options are: %0".format(JSON.stringify(options)));
        return options;
    },
};


/**
 * @namespace CalendarTests
 */
var CalendarTests = {

/*******************************************************************************/
/*                                                                             */
/*   Mark: CalendarTests Public API - Calendar Navigation                      */
/*                                                                             */
/*      This is where test interfaces for handling Calendar navigation         */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Navigates along a list of calendar views.
     * This test is a QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string[]}    [args.ViewsToNavigate=[ "Month", "Day", "List" ]]     - Calendars to navigate
     */
    navigateCalendar: function navigateCalendar(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        for (var i = 0; i < options.ViewsToNavigate.length-1; i++) {
            var startView = options.ViewsToNavigate[i];
            var endView   = options.ViewsToNavigate[i+1];

            // First get to the start view
            calendar.navigation.goTo(startView);
            if (calendar.currentUIState() != startView) {
                UIALogger.logError("Cannot get to starting view %0".format(startView));
            }

            try {
                // DON'T use UIANavigation, we are explicitly stepping through ViewsToNavigate.
                calendar.navigation.transitionTo(endView);
            } catch(e) {
                UIALogger.logError("Cannot get from %0 to %1!".format(startView, endView));
            }
        }
    },

    /**
     * Navigate to the Year view.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {DateString}  [args.TargetDate=""]            - (Optional) Specific year in view, given by the date
     */
    getToYear: function getToYear(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.getToYear(options.TargetDate);
    },

    /**
     * Navigate to the Month view.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {DateString}  [args.TargetDate=""]            - (Optional) Specific month in view, given by the date
     */
    getToMonth: function getToMonth(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.getToMonth(options.TargetDate);
    },

    /**
     * Navigate to the Week view.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {DateString}  [args.TargetDate=""]            - (Optional) Specific week in view, given by the date
     */
    getToWeek: function getToWeek(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.getToWeek(options.TargetDate);
    },

    /**
     * Navigate to the Day view.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {DateString}  [args.TargetDate=""]            - (Optional) Specific day in view, given by the date
     */
    getToDay: function getToDay(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.getToDay(options.TargetDate);
    },



/*******************************************************************************/
/*                                                                             */
/*   Mark: CalendarTests Public API - Events & Invites                         */
/*                                                                             */
/*      This is where test interfaces for handling events                      */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Adds an event to calendar and verifies its existence.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]      - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]              - StartDate of event
     * @param {DateString}  [args.EndDate=""]                - EndDate of event
     * @param {string}      [args.Location=""]               - Location of event
     * @param {string}      [args.CalendarName=""]           - Calendar to save this event under
     * @param {string}      [args.CalendarGroup=""]          - Calendar group to save this event under
     * @param {bool}        [args.AllDay=false]              - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                 - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]          - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]               - List of invitees to add to event (Not available in all calendars)
     * @param {string}      [args.Alert=""]                  - Alert for event
     * @param {enum}        [args.ShowAs=""]                 - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]             - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                    - Event URL
     * @param {string}      [args.Notes=""]                  - Event notes
     * @param {bool}        [args.SkipVerification=false]    - Adds event without verifying
     */
    addEvent: function addEvent(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.addEvent(options.Title, options.StartDate, options.EndDate, options);

        if (args.SkipVerification) return;

        // Because verifyEventExists checks for event properties against ALL fields in a given object, we first create a new object with a subset of the key-value pairs
        var FieldsToTest = CalendarTestUtilities.extractEventFieldsOnly(options);
        FieldsToTest = CalendarTestUtilities._removeUndefinedFields(FieldsToTest);

        // Verify event and attributes after event creation
        calendar.verifyEventExists(options.Title, options.StartDate, FieldsToTest, { WorkflowToEvent: calendar.WORKFLOWS_TO_EVENT.CALENDAR_DAY });
    },


    /**
     * Adds multiples of event to calendar and verifies their existence.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {number}      [args.Count=3]                   - Number of events to create
     * @param {string}      [args.TitlePrefix=""]            - Prefix for event titles
     *     (Complete title: "TitlePrefix_event number_random integer")
     * @param {DateString}  [args.StartDate=""]              - StartDate of event
     * @param {DateString}  [args.EndDate=""]                - EndDate of event
     * @param {string}      [args.Location=""]               - Location of event
     * @param {string}      [args.CalendarName=""]           - Calendar to save this event under
     * @param {string}      [args.CalendarGroup=""]          - Calendar group to save this event under
     * @param {bool}        [args.AllDay=false]              - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                 - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]          - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]               - List of invitees to add to event (Not available in all calendars)
     * @param {string}      [args.Alert=""]                  - Alert for event
     * @param {enum}        [args.ShowAs=""]                 - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]             - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                    - Event URL
     * @param {string}      [args.Notes=""]                  - Event notes
     * @param {bool}        [args.SkipVerification=false]    - Adds event without verifying
     */
     addMultiplesOfEvent: function addMultiplesOfEvent(args) {
        args = UIAUtilities.defaults(args, {
            Count: 3,
            TitlePrefix: '',
        });

        for (i = 0; i < args.Count; i++) {
            randomID = UIAUtilities.randomInt(0, 10000);
            addEventArgs = args;
            addEventArgs.Title = '%0_%1_%2'.format(args.TitlePrefix, i, randomID);
            CalendarTests.addEvent(addEventArgs);
        }
    },


    /**
     * Verifies that an event exists on calendar, and validates the event's attributes, if provided.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     * @param {DateString}  [args.EndDate=""]                           - EndDate of event
     * @param {string}      [args.Location=""]                          - Location of event
     * @param {string}      [args.CalendarName=""]                      - Calendar this event is saved under
     * @param {string}      [args.CalendarGroup=""]                     - Calendar group this event is saved under
     * @param {bool}        [args.AllDay=false]                         - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                            - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]                     - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]                          - List of invitees to add to event (Not available in all calendars)
     * @param {string}      [args.Alert=""]                             - Alert for event
     * @param {enum}        [args.ShowAs=""]                            - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]                        - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                               - Event URL
     * @param {string}      [args.Notes=""]                             - Event notes
     */
    verifyEventExists: function verifyEventExists(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args, { StartDate: CalendarTestUtilities._cleanedDate(args.StartDate) });

        // Because verifyEventExists checks for event properties against ALL fields in a given object, we first create a new object with a subset of the key-value pairs
        var FieldsToTest = CalendarTestUtilities.extractEventFieldsOnly(options);
        FieldsToTest = CalendarTestUtilities._removeUndefinedFields(FieldsToTest);

        calendar.verifyEventExists(options.Title, options.StartDate, FieldsToTest, options);
    },

    /**
     * Verifies that an event exists on invitee's calendar, and validates provided attributes.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="Auto test"]                    - (Required) Title of event
     * @param {string[]}    [args.Invitees=["ios2003_30"]]              - (Required) List of invitees added to event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     * @param {DateString}  [args.EndDate=""]                           - EndDate of event
     * @param {string}      [args.Location=""]                          - Location of event
     * @param {bool}        [args.AllDay=false]                         - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                            - Repeat interval
     * @param {string}      [args.InvitationFrom=""]                    - Username of event originator
     * @param {string}      [args.Alert=""]                             - Alert for event
     * @param {enum}        [args.ShowAs=""]                            - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]                        - Set event to private (Not available in all calendars)
     * @param {string}      [args.Notes=""]                             - Event notes
     */
    verifyEventExistsInviteeView: function verifyEventExistsInviteeView(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args, { StartDate: CalendarTestUtilities._cleanedDate(args.StartDate) });

        // Because verifyEventExists checks for event properties against ALL fields in a given object,
        // we first create a new object with a subset of the key-value pairs
        var fieldsToTest = CalendarTestUtilities.extractEventFieldsOnly(options);
        fieldsToTest = CalendarTestUtilities._removeUndefinedFields(fieldsToTest);

        calendar.verifyEventExistsInviteeView(options.Title, options.StartDate, fieldsToTest, options);
    },

    /**
     * Edits an event on calendar.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     * @param {string}      [args.NewTitle="EDITED SAMPLE TITLE"]       - New Title of event
     * @param {DateString}  [args.NewStartDate=""]                      - New StartDate of event
     * @param {DateString}  [args.EndDate=""]                           - EndDate of event
     * @param {string}      [args.Location=""]                          - Location of event
     * @param {string}      [args.CalendarName=""]                      - Calendar to save this event under
     * @param {string}      [args.CalendarGroup=""]                     - Calendar group to save this event under
     * @param {bool}        [args.AllDay=false]                         - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                            - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]                     - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]                          - List of invitees to add to event (Not available in all calendars)
     * @param {string}      [args.Alert=""]                             - Alert for event
     * @param {enum}        [args.ShowAs=""]                            - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]                        - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                               - Event URL
     * @param {string}      [args.Notes=""]                             - Event notes
     * @param {bool}        [args.ApplyToFutureOccurrences=false]       - Apply changes to all future occurrences of this event
     */
    editEvent: function editEvent(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.editEvent(options.Title, options.StartDate, options, options.ApplyToFutureOccurrences, options);
    },

    /**
     * Searches for a specified event in calendar.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent="SearchList"]         - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     *
     */
    searchForEvent: function searchForEvent(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.searchForEvent(options.Title, options.StartDate, options);
    },

    /**
     * Deletes an event on calendar and verifies that the event doesn't exist anymore.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     * @param {bool}        [args.ApplyToFutureOccurrences=false]       - Delete all future occurrences of this event
     */
    deleteEvent: function deleteEvent(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args, { StartDate: CalendarTestUtilities._cleanedDate(args.StartDate) });

        calendar.deleteEvent(options.Title, options.StartDate, options.ApplyToFutureOccurrences, options);
        calendar.verifyEventDoesNotExist(options.Title, options.StartDate, options);
    },

    /**
     * Verify that an event does not exist on calendar.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     */
    verifyEventDoesNotExist: function verifyEventDoesNotExist(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.verifyEventDoesNotExist(options.Title, options.StartDate, options);
    },

    /**
     * Deletes all events on a specified calendar.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     */
    deleteAllEvents: function deleteAllEvents(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.deleteAllEvents();
    },

    /**
     * Respond to an event invite.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.Title="SAMPLE TITLE"]                 - (Required) Title of event
     * @param {DateString}  [args.StartDate=""]                         - StartDate of event
     * @param {enum}        [args.WorkflowToEvent=""]                   - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
     * @param {string}      [args.PredicateString=""]                   - Predicate string for searching event
     * @param {bool}        [args.ExpectPredicateToFindMatch=true]      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
     * @param {enum}        [args.InboxList=""]                         - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
     * @param {enum}        [args.Response="Accept"]                    - Response to event invite
     * @param {bool}        [args.AcceptAll=false]                      - Apply response to all future occurrences of this event
     * @param {string}      [args.ReplyComment=""]                      - Comment to input when responding to invites
     * @param {bool}        [args.Private=false]                        - Set invited event to private (Not available in all calendars)
     * @param {enum}        [args.ShowAs=""]                            - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     */
    respondToInvite: function respondToInvite(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.respondToInvite(options.Title, options.StartDate, options, options);
    },

    /**
     * Waits for a Calendar event timer notification to appear and handles notification.
     * If flag set, will add an event before waiting. Otherwise, assumes event has already
     * been created. If an event is to be added beforehand, can take same arguments as
     * addEvent if desired.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {number}      [args.Timeout=60]                - (Required) Amount of time (in seconds) to wait for an event notification to appear.
     *                          A cushion will be added to this timeout; therefore this timeout is not exact.
     * @param {bool}        [args.AddEvent=true]             - (Required) Flag. Set if event should be created before wait
     * @param {string}      [args.Alert="5 minutes before"]  - Alert for event
     * @param {string}      [args.Title="SAMPLE TITLE"]      - (Required if not adding new event) Title of event
     * @param {DateString}  [args.StartDate=""]              - (Required if not adding new event) StartDate of event. Only used if not adding a new event.
     * @param {string}      [args.Location=""]               - Location of event
     * @param {DateString}  [args.EndDate=""]                - EndDate of event
     * @param {string}      [args.CalendarName=""]           - Calendar to save this event under
     * @param {string}      [args.CalendarGroup=""]          - Calendar group to save this event under
     * @param {bool}        [args.AllDay=false]              - Specify whether event is an all-day event or not
     * @param {string}      [args.Repeat=""]                 - Repeat interval
     * @param {DateString}  [args.RepeatEndDate=""]          - RepeatEndDate of event, if a repeat interval is set
     * @param {string[]}    [args.Invitees=[]]               - List of invitees to add to event (Not available in all calendars)
     * @param {enum}        [args.ShowAs=""]                 - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
     * @param {bool}        [args.Private=false]             - Set event to private (Not available in all calendars)
     * @param {string}      [args.Url=""]                    - Event URL
     * @param {string}      [args.Notes=""]                  - Event notes
     * @param {bool}        [args.SkipVerification=false]    - Adds event without verifying
     */
    waitForCalendarEventNotification: function waitForCalendarEventNotification(args) {
        // Stating defaults using standard way instead of CalendarTestUtilities.defaultTestArgs(args);
        // as defaultTestArgs outputs incorrect log messages for this workflow
        args = UIAUtilities.defaults(args, {
            Timeout:            60,
            AddEvent:           true,

            // options for event addition
            Title:              CalendarTestUtilities.generateUniqueTitle(),
            Alert:              calendar.EventAlertValues.FIVE_MINUTES,
            StartDate:          '',
            EndDate:            '',
            Location:           '',
            CalendarName:       '',
            CalendarGroup:      '',
            AllDay:             false,
            Repeat:             '',
            RepeatEndDate:      '',
            Invitees:           [],
            ShowAs:             '',
            Private:            false,
            Url:                '',
            Notes:              '',
            SkipVerification:   false,
        });

        var options = CalendarTestUtilities.parseOptions(args);

        UIAUtilities.assert(
            args.Timeout <= 900,
            'Possible incorrect parameter. \
            Timeout for event notification alert is longer then framework alotted runtime for test. \
            Update parameter to shorter Timeout option.'
        );

        calendar.waitForCalendarEventNotification(options);
    },

/*******************************************************************************/
/*                                                                             */
/*   Mark: CalendarTests Public API - Calendars                                */
/*                                                                             */
/*      This is where test interfaces for handling calendars                   */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

    /**
     * Add calendar to device.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     * @param {string[]}    [args.SharedWith=[]]                    - List of contacts to share calendar with (Not available in all calendars)
     * @param {bool}        [args.ShowSharedEventChanges=true]      - Enable notifications when other people add/edit/delete events in shared calendar
     * @param {string}      [args.Color=""]                         - Calendar color
     * @param {bool}        [args.CalendarIsPublic=null]            - Set calendar to be public (Not available in all calendars)
     * @param {string}      [args.ShareLink=null]                   - Share link to public calendar (Not available in all calendars)
     * @param {bool}        [args.Notifications=true]               - Enable event notifications (i.e. Exchange; Not available in all calendars)
     * @param {bool}        [args.Visibility=true]                  - Set visibility of the calendar (true if the calendar is to be hidden, else false)
     */
    addCalendar: function addCalendar(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.addCalendar(options.CalendarGroup, options.CalendarName, options);
        calendar.verifyCalendarExists(options.CalendarGroup, options.CalendarName);
    },

    /**
     * Verifies that a calendar exists.
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     */
    verifyCalendarExists: function verifyCalendarExists(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.verifyCalendarExists(options.CalendarGroup, options.CalendarName);
    },

    /**
     * Edit calendar on device.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                         - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]           - Calendar name
     * @param {string}      [args.NewCalendarName="NEW SAMPLE CALENDAR"]    - New Calendar name
     * @param {string[]}    [args.SharedWith=[]]                            - List of contacts to share calendar with (Not available in all calendars)
     * @param {bool}        [args.ShowSharedEventChanges=null]              - Enable notifications when other people add/edit/delete events in shared calendar
     * @param {string}      [args.Color=""]                                 - Calendar color
     * @param {bool}        [args.CalendarIsPublic=null]                    - Set calendar to be public (Not available in all calendars)
     * @param {string}      [args.ShareLink=null]                           - Share link to public calendar (Not available in all calendars)
     * @param {bool}        [args.Notifications=true]                       - Enable event notifications (i.e. Exchange; Not available in all calendars)
     * @param {bool}        [args.Visibility=true]                          - Set visibility of the calendar (true if the calendar is to be hidden, else false)
     */
    editCalendar: function editCalendar(args) {
        var args = UIAUtilities.defaults(args, {
                CalendarGroup: "",
                CalendarName: 'SAMPLE CALENDAR',
                NewCalendarName:'NEW SAMPLE CALENDAR',
                SharedWith: [],
                ShowSharedEventChanges: null,
                Color: "",
                CalendarIsPublic: null,
                ShareLink: null,
                Notifications: true,
                Visibility: true,
        });
        calendar.editCalendar(args.CalendarGroup, args.CalendarName, args);
    },

    /**
     * Delete calendar from device and verifies that the calendar doesn't exist anymore.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     */
    deleteCalendar: function deleteCalendar(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.deleteCalendar(options.CalendarGroup, options.CalendarName);
        calendar.verifyCalendarDoesNotExist(options.CalendarGroup, options.CalendarName);
    },

    /**
     * Verifies that a calendar does not exist.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     */
    verifyCalendarDoesNotExist: function verifyCalendarDoesNotExist(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.verifyCalendarDoesNotExist(options.CalendarGroup, options.CalendarName);
    },

    /**
     * Set the visibility for calendar(s).
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {string}      [args.CalendarGroup=""]                 - Calendar Group name
     * @param {string}      [args.CalendarName="SAMPLE CALENDAR"]   - Calendar name
     */
    setCalendarVisibility: function setCalendarVisibility(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.setCalendarVisiblilty(options.CalendarGroup, options.CalendarName, options.Visibility);
    },

    /**
     * Set calendar app to show declined events.
     * This test is an interface test to the Calendar library function (single user action), not a specific QL test.
     *
     * @targetApps MobileCal
     *
     * @param {object} args Test arguments
     * @param {bool}        [args.ShowDeclinedEvents=false]         - Show declined events
     */
    setShowDeclinedEvents: function setShowDeclinedEvents(args) {
        args = CalendarTestUtilities.defaultTestArgs(args);
        var options = CalendarTestUtilities.parseOptions(args);

        calendar.setShowDeclinedEvents(options.ShowDeclinedEvents);
    },
};
