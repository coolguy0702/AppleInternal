load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');

if (typeof calendar !== 'undefined') {
    if (!(calendar instanceof UIAApp)) {
        throw new UIAError("calendar has already been defined to something not an instance of UIAApp! Value: %0".format(calendar));
    }
    if (calendar.bundleID() !== 'com.apple.mobilecal') {
        var oldDefinition = calendar.bundleID();
        var calendar = target.appWithBundleID('com.apple.mobilecal');
        UIALogger.logWarning("'calendar' was redefined from '%0' to '%1'".format(oldDefinition, calendar.bundleID()));
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Calendar Query Constants                                            */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIAQuery.Calendar = {
    /** 'List' button */
    LIST_BUTTON: UIAQuery.buttons('List'),

    /** 'Search' button */
    SEARCH_BUTTON: UIAQuery.buttons('Search'),

    /** 'Add' button */
    ADD_BUTTON: UIAQuery.buttons('Add'),

    /** 'Edit' button */
    EDIT_BUTTON: UIAQuery.buttons('Edit'),

    /** Visible 'Back' button */
    VISIBLE_BACK_BUTTON: UIAQuery.BACK_NAV_BUTTON.isVisible(),


    // TOOLBAR BUTTONS
    /** 'Day' button */
    DAY_BUTTON: UIAQuery.buttons().andThen(UIAQuery.beginsWith('Day')),

    /** 'Week' button */
    WEEK_BUTTON: UIAQuery.buttons().andThen(UIAQuery.beginsWith('Week')),

    /** 'Month' button */
    MONTH_BUTTON: UIAQuery.buttons().andThen(UIAQuery.beginsWith('Month')),

    /** 'Year' button */
    YEAR_BUTTON: UIAQuery.buttons().andThen(UIAQuery.beginsWith('Year')),

    /** 'Today' button within a ToolBar */
    TODAY_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Today')),

    /** 'Calendars' button within a ToolBar */
    CALENDARS_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Calendars')),

    /** 'Inbox' button within a ToolBar */
    INBOX_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons()).andThen(UIAQuery.beginsWith('Inbox')),


    // INBOX VIEW BUTTONS
    /** InboxView */
    INBOX_VIEW: UIAQuery.query("InboxView"),

    /** 'New' button within an InboxView */
    NEW_EVENTS_BUTTON: UIAQuery.query("InboxView").andThen(UIAQuery.buttons('New')),

    /** 'Replied' button within an InboxView */
    REPLIED_EVENTS_BUTTON: UIAQuery.query("InboxView").andThen(UIAQuery.buttons('Replied')),


    // POPOVER VIEW BUTTONS
    /** 'Accept' button within a Popover */
    ACCEPT_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Accept')),

    /** 'Maybe' button within a Popover */
    MAYBE_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Maybe')),

    /** 'Decline' button within a Popover */
    DECLINE_BUTTON: UIAQuery.toolbars().andThen(UIAQuery.buttons('Decline')),


    // SPLASH SCREEN BUTTONS
    /** 'Continue' button on the What's New in Calendar Splash Screen. */
    CONTINUE_BUTTON: UIAQuery.buttons('Continue'),


    KEYBOARD_DELETE_BUTTON: UIAQuery.keyboard().andThen(UIAQuery.query('Delete')),

    // EVENT RESPOND/EDIT VIEW BUTTONS
    /** Delete the event (detailed view) */
    // The first query is for the general case
    // The second query is for the Edit Event view on iPads (either in Day-view sheet or inside the bubble in Week/Month views), where the "Delete Event" element is a table cell as opposed to a button
    // The children predicate is used to prevent UIA2 from tapping on staticTexts, which is untappable
    // The workaround will be fixed with <rdar://problem/21106638> Calendar "Delete Event" element is inconsistent depending on view (button vs tablecell)
    DELETE_EVENT_BUTTON: UIAQuery.buttons("Delete Event").isVisible().orElse( UIAQuery.tableCells().withPredicate("ANY children.name == 'Delete Event'") ),

    // Confirm Delete Event - it is a collection view button on iPhones and an alert button on iPads
    CONFIRM_DELETE_BUTTON: UIAQuery.alerts().andThen(UIAQuery.buttons("Delete Event")).isVisible().orElse( UIAQuery.actionSheets().andThen(UIAQuery.buttons("Delete Event")) ).isVisible(),

    BULK_EVENTS_BUTTON: UIAQuery.buttons().withPredicate("name == 'Save for all events' OR name == 'Save for future events' OR name == 'Delete All Future Events'"),
    /** Apply invite response/event change to all events */
    get APPLY_TO_ALL_FUTURE_BUTTON () { return UIAQuery.collectionViews().andThen(this.BULK_EVENTS_BUTTON); },

    SINGLE_EVENT_BUTTON: UIAQuery.buttons().withPredicate("name == 'Save for this event only' OR name == 'Delete This Event Only'"),

    /** Apply invite response/event change to this occurrence only */
    get APPLY_TO_ONE_BUTTON () { return UIAQuery.collectionViews().andThen(this.SINGLE_EVENT_BUTTON); },

    // CALENDAR VIEW DATE QUERIES
    MONTH_YEAR_ELEMENT: UIAQuery.withPredicate("name MATCHES '.*[0-9]{4}'").isVisible(),

    MONTH_DAY_ELEMENT: UIAQuery.withPredicate("name MATCHES '.*[0-9]{1,2}'").isVisible(),


    // SEARCH RESULTS
    SEARCH_RESULTS_CONTAINER: UIAQuery.tableViews("Search results").isVisible(),

    get SEARCH_RESULTS_DATE_SECTION () { return this.SEARCH_RESULTS_CONTAINER.andThen('UITableViewSectionElement'); },


    // EDIT CALENDARS VIEW BUTTONS

    ADD_CALENDAR_BUTTON: UIAQuery.query('Add Calendar').isVisible(),

    DELETE_CALENDAR_BUTTON: UIAQuery.query('Delete Calendar'),

    SHOW_DECLINED_EVENTS: UIAQuery.switches('Show Declined Events'),

    // NON-EDIT EVENT DETAILS VIEW
    EVENT_DETAILS_CONTAINER: UIAQuery.query("EventDetailsContainer").isVisible(),    // UIAQuery.VISIBLE_POPOVERS.orElse(UIAQuery.RIGHT_TABLE).andThen("EKCalendarItemEditorTableView"),

    EVENT_AUTO_COMPLETE_LOCATIONS: UIAQuery.query('UINavigationTransitionView').isVisible().andThen(UIAQuery.tableCells()),

    // This buttons allows traversal from Event Details view to Edit Event view.  The first subquery for iPad Day views, the second is for the general case
    get EVENT_DETAILS_EDIT_BUTTON () { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.buttons('Edit')).orElse(UIAQuery.buttons('Edit')); },

    get EVENT_DETAILS_ALERT () { return this.EVENT_DETAILS_CONTAINER.andThen("Alert"); },

    get EVENT_DETAILS_ALERT_VALUE () { return this.EVENT_DETAILS_ALERT.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EVENT_DETAILS_SHOW_AS () { return this.EVENT_DETAILS_CONTAINER.andThen("Show As"); },

    get EVENT_DETAILS_SHOW_AS_VALUE () { return this.EVENT_DETAILS_SHOW_AS.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EVENT_DETAILS_PRIVATE () { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.switches("Private")); },

    get EVENT_DETAILS_REPLY_COMMENT () { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.query("UITextField")); },

    // Event details view queries on invitee's view
    get EVENT_DETAILS_HEADER_INVITEE_VIEW() { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.tableCells().topmost()); },

    get EVENT_DETAILS_INVITEE_BTN_INVITEE_VIEW() { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.staticTexts('Invitees')); },

    get EVENT_DETAILS_INVITATION_FROM_BTN_INVITEE_VIEW() {return UIAQuery.staticTexts('Invitation from'); },

    get EVENT_DETAILS_INVITEES_SECTION_INVITEE_VIEW() { return UIAQuery.tableViews('EKUIEventInviteesView').andThen(UIAQuery.tableCells()); },

    get EVENT_DETAILS_NOTES_INVITEE_VIEW() { return this.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.textViews('Notes')); },

    get EVENT_DETAILS_INVITATION_FROM_INVITEE_VIEW() { return UIAQuery.query('CNContactHeaderDisplayView').andThen(UIAQuery.staticTexts()); },

    // EDIT EVENT VIEW QUERIES
    // The Edit Event container is NOT the same as the Event Details container (it is reachable by tapping Edit in the Event Details container)
    EDIT_EVENT_CONTAINER: UIAQuery.query("EKCalendarItemEditorTableView"),

    get EDIT_EVENT_CONTAINER_CANCEL () { return this.EDIT_EVENT_CONTAINER.parent().ancestors().andThen("Cancel"); },

    get EDIT_EVENT_TITLE () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.textFields().isVisible().topmost()); },

    get EDIT_EVENT_LOCATION () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.query('Location')).parent(); },

    get EDIT_EVENT_ALLDAY () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.switches("All-day")); },

    get EDIT_EVENT_START () { return this.EDIT_EVENT_CONTAINER.andThen("Starts"); },

    get EDIT_EVENT_START_VALUE () { return this.EDIT_EVENT_START.parent().andThen(UIAQuery.staticTexts().rightmost()) },

    get EDIT_EVENT_END () { return this.EDIT_EVENT_CONTAINER.andThen("Ends"); },

    get EDIT_EVENT_END_VALUE () { return this.EDIT_EVENT_END.parent().andThen(UIAQuery.staticTexts().rightmost()) },

    get EDIT_EVENT_PICKER () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.pickers()); },

    get EDIT_EVENT_REPEAT () { return this.EDIT_EVENT_CONTAINER.andThen("Repeat"); },

    get EDIT_EVENT_REPEAT_VALUE () { return this.EDIT_EVENT_REPEAT.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EDIT_EVENT_REPEAT_END () { return this.EDIT_EVENT_CONTAINER.andThen("End Repeat"); },

    get EDIT_EVENT_REPEAT_END_VALUE () { return this.EDIT_EVENT_REPEAT_END.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EDIT_EVENT_CALENDAR () { return UIAQuery.Calendar.EDIT_EVENT_CONTAINER.andThen("Calendar"); },

    get EDIT_EVENT_ALERT () { return this.EDIT_EVENT_CONTAINER.andThen("Alert"); },

    get EDIT_EVENT_ALERT_VALUE () { return this.EDIT_EVENT_ALERT.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EDIT_EVENT_SHOW_AS () { return this.EDIT_EVENT_CONTAINER.andThen("Show As"); },

    get EDIT_EVENT_SHOW_AS_VALUE () { return this.EDIT_EVENT_SHOW_AS.parent().andThen(UIAQuery.staticTexts().rightmost()); },

    get EDIT_EVENT_PRIVATE () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.switches("Private")); },

    get EDIT_EVENT_URL () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.textFields('URL').bottommost()); },

    get EDIT_EVENT_NOTES () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.textViews().bottommost()); },


    get EDIT_EVENT_INVITEES () { return this.EDIT_EVENT_CONTAINER.andThen(UIAQuery.withPredicate("name BEGINSWITH 'invited.status'").orElse('Invitees')); },

    get EDIT_EVENT_INVITEES_VALUE () { return this.EDIT_EVENT_INVITEES.parent().children().andThen( UIAQuery.withPredicate("TRUEPREDICATE").rightmost() ); },

    EDIT_EVENT_INVITEE_ENTRIES: UIAQuery.query('UINavigationTransitionView').andThen(UIAQuery.query('EKUIInviteesEditView').orElse('EKUIEventInviteesView')).andThen(UIAQuery.staticTexts().withPredicate("name != 'Add invitees' and name != 'No Response'")).parent().withPredicate('behavior == "TableCell"'),

    EDIT_EVENT_INVITEE_EMAIL_ENTRY: UIAQuery.tableViews("CNContactView").andThen(UIAQuery.tableCells().first()).andThen(UIAQuery.staticTexts().last()),

    RECIPIENTS_TEXTFIELD: UIAQuery.query("MFComposeRecipientTextView"),

    EDIT_EVENT_INVITEES_ADD: UIAQuery.query("Add invitees"),

    INVITE_DETAILS_VIEW: UIAQuery.tableViews("UITableView"),


    CALENDARS_CONTAINER: UIAQuery.query("UITransitionView"),

    get CALENDAR_GROUP_SECTION () { return this.CALENDARS_CONTAINER.andThen('UITableViewSectionElement'); },

    get CALENDAR_LIST_ENTRIES () { return this.CALENDARS_CONTAINER.andThen('UITableViewCellAccessibilityElement'); },

    get CALENDAR_SHOW_SHAREDEVENT_CHANGES_SWITCH () { return this.CALENDARS_CONTAINER.andThen(UIAQuery.switches('Show Changes')); },

    get CALENDAR_NOTIFICATIONS_SWITCH () { return this.CALENDARS_CONTAINER.andThen(UIAQuery.switches("Event Alerts")); },

    get EDIT_CALENDAR_PUBLIC_SWITCH () { return this.CALENDARS_CONTAINER.andThen(UIAQuery.switches("Public Calendar")); },

    get EDIT_CALENDAR_SHAREDWITH_ENTRY () { return this.CALENDARS_CONTAINER.andThen("View & Edit"); },

    EDIT_CALENDAR_SHAREDWITH_STOPSHARING: UIAQuery.query('Stop Sharing'),

    REMOVE_BUTTON: UIAQuery.collectionViews().andThen('Remove'),

    COMPACT_MONTH_WEEK_VIEW: UIAQuery.contains("CompactMonthWeekView"),

};



/*******************************************************************************/
/*                                                                             */
/*   Mark: Calendar UI State Constants                                         */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** @namespace */
UIStateDescription.Calendar = {
    /** What's New in Calendar Splash Screen */
    CALENDAR_SPLASH:        'calendar splash',

    /** Calendar in day view */
    DAY_VIEW:               'day view',

    /** Calendar in week view */
    WEEK_VIEW:              'week view',

    /** Calendar in month view */
    MONTH_VIEW:             'month view',

    /** Calendar in year view */
    YEAR_VIEW:              'year view',

    /** List view */
    LIST_VIEW:              'list view',

    /** New events in inbox */
    INBOX_NEW:              'inbox (new)',               // inbox view (new selected)

    /** Replied events in inbox */
    INBOX_REPLIED:          'inbox (replied)',           // inbox view (replied selected)

    /** Calendars view */
    CALENDARS:              'calendars selection',

    /** Edit Calendars view */
    EDIT_CALENDARS:         'edit calendars',            // calendars -> edit button

    /** Edit Calendar view */
    EDIT_CALENDAR:          'edit calendar',             // calendars -> info button

    /** Add Calendar view */
    ADD_CALENDAR:           'add calendar',             // calendars -> edit button -> add calendar button

    /** New Event view */
    NEW_EVENT:              'add new event',

    /** Event details view */
    EVENT_DETAILS:          'event details',             // responding to event invite

    /** Event details - invitee view */
    INVITEE_EVENT_VIEW:     'invitee event view',       // event details on invitee view

    /** Edit event view */
    EDIT_EVENT:             'edit event',

    /** Event Alert view */
    EVENT_ALERT:            'event alert',               // new event -> alert

    /** Location view */
    LOCATION:               'location view',             // new event -> location

    /** Repeat Event view */
    REPEAT:                 'event repeat',              // new event -> repeat

    /** Custom Repeat view */
    CUSTOM_REPEAT:          'custom repeat',             // new event -> repeat -> custom

    /** End Repeat view */
    END_REPEAT:             'end repeat',                // new event -> end repeat (becomes available once event is set to repeating)

    /** Travel Time view */
    TRAVEL_TIME:            'travel time',               // new event -> travel time

    /** Add Person view */
    ADD_PERSON:             'add person',                // new event -> invitees (needs to be signed in)

    /** Add Invitees view */
    ADD_INVITEES:           'add invitees',

    /** Search view */
    SEARCH:                 'search event',

};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var calendar = target.appWithBundleID('com.apple.mobilecal');



/*******************************************************************************/
/*                                                                             */
/*   Mark: Calendar Constants and Enums                                        */
/*                                                                             */
/*      Enums used by the Calendar library, for internal and external API use  */
/*                                                                             */
/*******************************************************************************/

calendar.WORKFLOWS_TO_EVENT = {
    CALENDAR_DAY:           'CalendarDay',
    CALENDAR_WEEK:          'CalendarWeek',
    CALENDAR_MONTH:         'CalendarMonth',
    MONTH_LIST:             'MonthList',
    DAY_LIST:               'DayList',
    SEARCH_LIST:            'SearchList',
    INBOX:                  'Inbox',
    INBOX_EVENT_DETAILS:    'InboxEventDetails',
}

calendar.CALENDAR_VIEWS = {
    DAY:   'Day',
    WEEK:  'Week',
    MONTH: 'Month',
    YEAR:  'Year',
    LIST:  'List',
}

calendar.NAVBAR_VALUES = {
    DayView:      'DayViewContainerView',
    WeekView:     'WeekViewContainerView',
    MonthView:    'MonthViewContainerView',
    YearView:     'YearViewContainerView',
    ListView:     'ListViewContainerView',
    Calendars:    'Calendars',
    Search:       'UISearch',
    NewEvent:     'New Event',
    InboxNew:     'InboxSwitcherView',
    InboxReplied: 'Replied',
    EditCalendar: 'Edit Calendar',
    Repeat:       'Repeat',
    CustomRepeat: 'Custom',
    EndRepeat:    'End Repeat',
    TravelTime:   'Travel Time',
    EventAlert:   'Event Alert',
    EventDetails: 'Event Details',
}

calendar.INVITE_RESPONSE_VALUES = {
    ACCEPT:     'Accept',
    MAYBE:      'Maybe',
    DECLINE:    'Decline',
}

calendar.INBOX_LIST_VALUES = {
    NEW:        'New',
    REPLIED:    'Replied',
}

calendar.AVAILABILITY_VALUES = {
    BUSY:           'Busy',
    FREE:           'Free',
    TENTATIVE:      'Tentative',
    OUT_OF_OFFICE:  'Out of office',
}

calendar.EVENT_REPEAT_VALUES = {
    NEVER:          'Never',
    DAILY:          'Every Day',
    WEEKLY:         'Every Week',
    BIWEEKLY:       'Every 2 Weeks',
    MONTHLY:        'Every Month',
    YEARLY:         'Every Year',
}

calendar.MONTHS      = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ];
calendar.DAY_OF_WEEK = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", ];

/*
 *  Common string names for event notification times.
 *  Comes from the 'Alert' section of the edit menu of an event.
 */
calendar.EventAlertValues = {
    NONE:                    'None',
    AT_TIME_OF_EVENT:        'At time of event',
    FIVE_MINUTES:            '5 minutes before',
    FIFTEEN_MINUTES:         '15 minutes before',
    THIRTY_MINUTES:          '30 minutes before',
    ONE_HOUR:                '1 hour before',
    TWO_HOURS:               '2 hours before',
    ONE_DAY:                 '1 day before',
    TWO_DAYS:                '2 days before',
    ONE_WEEK:                '1 week before',
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Return description of current UI state. See Calendar UIStateDescription constants
* for possible values. Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Calendar UIStateDescription.
*
* @throws If cannot determine state.
*/
calendar.currentUIState = function currentUIState() {
    var navBarName = null;
    if (this.exists(UIAQuery.VISIBLE_NAVBARS)) {
        navBarName = this.nameOf(UIAQuery.VISIBLE_NAVBARS);
    } else if (this.exists(UIAQuery.contains('UISearchBarContainerView'))) {
        // If there wasn't a visible navbar, check to see if we're in a Search view
        return UIStateDescription.Calendar.SEARCH;
    }

    switch (navBarName) {
        case 'SplashScreenView':
            return UIStateDescription.Calendar.CALENDAR_SPLASH;
        case 'DayViewContainerView':
            // iPads don't update navBars in Day view
            return UIStateDescription.Calendar.DAY_VIEW;
        case 'WeekViewContainerView':
            // Only present on iPads
            return UIStateDescription.Calendar.WEEK_VIEW;
        case 'MonthViewContainerView':
            return UIStateDescription.Calendar.MONTH_VIEW;
        case 'YearViewContainerView':
            return UIStateDescription.Calendar.YEAR_VIEW;
        case 'ListViewContainerView':
            return UIStateDescription.Calendar.LIST_VIEW;
        case 'InboxSwitcherView':
            return UIStateDescription.Calendar.INBOX_NEW;
        case 'Replied':
            return UIStateDescription.Calendar.INBOX_REPLIED;
        case 'Show Calendars':
            // iPad version of 'Calendars'
        case 'Calendars':
            return UIStateDescription.Calendar.CALENDARS;
        case 'Edit Calendars':
            // Plural
            return UIStateDescription.Calendar.EDIT_CALENDARS;
        case 'Edit Calendar':
            // Singular
            return UIStateDescription.Calendar.EDIT_CALENDAR;
        case 'Add Calendar':
            return UIStateDescription.Calendar.ADD_CALENDAR;
        case 'New Event':
            return UIStateDescription.Calendar.NEW_EVENT;
        case 'Event Details':
            return UIStateDescription.Calendar.EVENT_DETAILS;
        case 'Edit Event':
            return UIStateDescription.Calendar.EDIT_EVENT;
        case 'Alert':
            return UIStateDescription.Calendar.EVENT_ALERT;
        case 'Second Alert':
            return UIStateDescription.Calendar.EVENT_ALERT;
        case 'Location':
            return UIStateDescription.Calendar.LOCATION;
        case 'Repeat':
            return UIStateDescription.Calendar.REPEAT;
        case 'Custom':
            return UIStateDescription.Calendar.CUSTOM_REPEAT;
        case 'End Repeat':
            return UIStateDescription.Calendar.END_REPEAT;
        case 'Travel Time':
            return UIStateDescription.Calendar.TRAVEL_TIME;
        case 'Add Person':
            return UIStateDescription.Calendar.ADD_PERSON;
        case 'Add Invitees':
            return UIStateDescription.Calendar.ADD_INVITEES;
        default:
            // if we got here, we don't have no clue where we are...

            /* NOTE: Workaround for:
            * <rdar://problem/26663798> Calendar Splash Screen no longer has a visible navigation bar element
            *
            * Will be implemented by:
            * <rdar://problem/26683369>
            *
            * Will be reverted by:
            * <rdar://problem/26683416>
            */
            if (calendar.exists(UIAQuery.query('SplashScreen').andThen(UIAQuery.buttons('Continue')))) {
                return UIStateDescription.Calendar.CALENDAR_SPLASH;
            }
            // Check if current view represents unacknowledged calendar event
            if (calendar.exists(UIAQuery.query('EKUIEventStatusButtonsView'))) {
                return UIStateDescription.Calendar.INVITEE_EVENT_VIEW;
            }
            throw new UIAError('Could not determine state.');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
* Navigation function to get out of auxillary states. Max iterations is 5
* because max number of actions to any top level of a tab is 4 actions.
* Added a cushion of 1 call.
*
* Any criteria for defining a transition from a state to another state
* should be very exact. Navigation function should always get to where
* they are meant to go or throw.
*
* Expected starting states: Works for any UI state.
*
* @param {object} options
* @param {string} options.currentState - Can pass a starting state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state.
*/
calendar.exitAuxillaryUIStates = function exitAuxillaryUIStates(options) {
    options = UIAUtilities.defaults(options, {
        currentState: this.currentUIState(),
    });

    calendar.launch();

    var keepTrying = true;

    // Max depth from within an auxillary state is 4 actions. Adding extra.
    for (var i = 0; i < 5 && keepTrying; i++) {
        options.currentState = this.currentUIState();

        UIALogger.logMessage("Current state: '%0'".format(options.currentState));

        switch (options.currentState) {
            case UIStateDescription.Calendar.CALENDAR_SPLASH:
                this.tap(UIAQuery.Calendar.CONTINUE_BUTTON);
                break;
            case UIStateDescription.Calendar.ADD_CALENDAR:
            case UIStateDescription.Calendar.EDIT_CALENDAR:
            case UIStateDescription.Calendar.NEW_EVENT:
            case UIStateDescription.Calendar.EDIT_EVENT:
            case UIStateDescription.Calendar.LOCATION:
            case UIStateDescription.Calendar.SEARCH:
                this.tap(UIAQuery.CANCEL_BUTTON.isVisible());
                break;
            case UIStateDescription.Calendar.INBOX_NEW:
            case UIStateDescription.Calendar.INBOX_REPLIED:
            case UIStateDescription.Calendar.CALENDARS:
            case UIStateDescription.Calendar.EDIT_CALENDARS:
                this.tap(UIAQuery.DONE_BUTTON);
                break;
            case UIStateDescription.Calendar.LIST_VIEW:
                calendar.tap(UIAQuery.Calendar.LIST_BUTTON);
                break;
            case UIStateDescription.Calendar.EVENT_DETAILS:
            case UIStateDescription.Calendar.EVENT_ALERT:
            case UIStateDescription.Calendar.REPEAT:
            case UIStateDescription.Calendar.CUSTOM_REPEAT:
            case UIStateDescription.Calendar.END_REPEAT:
            case UIStateDescription.Calendar.TRAVEL_TIME:
            case UIStateDescription.Calendar.ADD_PERSON:
            case UIStateDescription.Calendar.ADD_INVITEES:
                this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
                break;
            case UIStateDescription.Calendar.INVITEE_EVENT_VIEW:
                this.dismissPopover();
                break;
            // If we're already out of all auxillary states, we will fall through
            default:
                keepTrying = false;
                break;
        }
    }

    // lets get the new state
    options.currentState = this.currentUIState();

    switch (options.currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
        case UIStateDescription.Calendar.WEEK_VIEW:
        case UIStateDescription.Calendar.MONTH_VIEW:
        case UIStateDescription.Calendar.YEAR_VIEW:
            UIALogger.logMessage('Got out of auxillary states.');
            return options.currentState;
        default:
            throw new UIAError('Could not exit auxillary states after 5 attempts.');
    }
}

/**
* Navigate to the Year View.
*
* @param {Date} [TargetDate=null] - Scroll to the year specified; if no date provided, just get to the view
*
* @throws If we were unable to transition from some starting state to
*           desired state.
*/
calendar.getToYear = function getToYear(TargetDate) {
    TargetDate = (TargetDate === undefined) ? null : this._sanitizeDateTime(TargetDate);

    calendar.launch();

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Year view...');

    this.exitAuxillaryUIStates(currentState);

    currentState = this.currentUIState();

    switch (currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.YEAR_BUTTON);
            } else {
                this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
                this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.WEEK_VIEW:
            this.tap(UIAQuery.Calendar.YEAR_BUTTON);
            break;
        case UIStateDescription.Calendar.MONTH_VIEW:
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.YEAR_BUTTON);
            } else {
                this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.YEAR_VIEW:
            break;
        default:
            throw new UIAError(
                "Did not get to expected state. Current state: '%0', Expected state: '%1'"
                .format(currentState, UIStateDescription.Calendar.YEAR_VIEW)
            );
    }

    if (TargetDate === null) {
        return;
    }

    if ( TargetDate.getFullYear() === (new Date()).getFullYear() && !this.exists(this._targetMonthElement(new Date())) ) {
        /* If the target year is same as current date's year, AND
            if the target month (current date's month) is NOT visible,
            then skip the scrolling and tap Today, which will bring in the year view of the current year
            with the current month in view

            If the current month is already visible in the Year view, then tapping Today for iPhones will transition into the Month view
        */
        this.tap(UIAQuery.Calendar.TODAY_BUTTON);
        return;
    }

    // If the target month's element is already visible, skip
    if (this.exists( this._targetMonthElement(TargetDate) )) return;

    // If we are roughly in the range of the target year (determined by counting the number of month buttons with the marked year), then we can skip
    var visibleMonthsOfTargetYear = UIAQuery.buttons().contains( "%0".format(TargetDate.getFullYear()) ).isVisible();
    var visibleMonth = UIAQuery.buttons().isVisible().andThen(this._targetMonthElement(TargetDate));
    // if (calendar.count(visibleMonthsOfTargetYear) >= 9 ) return;

    // Scrape the Month buttons in the Year view to get a rough estimate of what year it is
    var monthNodes = calendar.inspectAll( UIAQuery.Calendar.MONTH_YEAR_ELEMENT );
    var mostCommonYear = parseInt( this._listmode( monthNodes.map(function (n) { return n.name.match(/\d{4}/); }) ) );

    // If we are mostly past the desired year, we choose to scroll back up; else we scroll down
    var goUp = mostCommonYear > TargetDate.getFullYear();
    var direction = this._calendarSheetUpDownShiftOffset(goUp);
    while (this.count(visibleMonthsOfTargetYear) < 9 || !this.exists(visibleMonth)) {
        this.drag("UIScrollView", direction);
    }
}

/**
 * Navigate to the Month View
 *
 * @param {Date} [TargetDate=null] - Scroll to the month specified; if no date provided, just get to the view
 *
 * @throws If unable to get to month
 */
calendar.getToMonth = function getToMonth(TargetDate) {
    TargetDate = (TargetDate === undefined) ? null : this._sanitizeDateTime(TargetDate);

    calendar.launch();

    if (TargetDate !== null) {
        this.getToYear(TargetDate);
        this.tap( this._targetMonthElement(TargetDate) );
    }

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Month view...');

    this.exitAuxillaryUIStates(currentState);

    currentState = this.currentUIState();

    switch (currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.MONTH_BUTTON);
            } else {
                this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.WEEK_VIEW:
            this.tap(UIAQuery.Calendar.MONTH_BUTTON);
            break;
        case UIStateDescription.Calendar.YEAR_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.MONTH_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.MONTH_VIEW:
            break;
        default:
            throw new UIAError(
                "Did not get to expected state. Current state: '%0', Expected state: '%1'"
                .format(currentState, UIStateDescription.Calendar.MONTH_VIEW)
            );
        }
}

/**
 * Navigate to the Week View
 *
 * @param {Date} [TargetDate=null] - Scroll to the week specified; if no date provided, just get to the view
 *
 * @throws If unable to get to week
 */
calendar.getToWeek = function getToWeek(TargetDate) {
    var _getVisibleDates = (function () {
        // Grabs all elements with a fully-parsable Date, grabs the Date values, and returns them as sorted numbers (UNIX timestamps)
        // This is a slow query, and can be optimized if Calendar AX provides some better labels
        return this._dateSet( this.inspectAll( UIAQuery.query("WeekGroupView").andThen(UIAQuery.withPredicate("TRUEPREDICATE").isVisible()) )
                                  .map(function (n) { return new Date("%0 %1".format(n.name, TargetDate.getFullYear())); })
                                  .filter(function (d) { return !isNaN(d); }) )
                   .map(function (d) { return d.getTime(); })
                   .sort();
    }).bind(this);

    TargetDate = (TargetDate === undefined) ? null : this._sanitizeDateTime(TargetDate);

    calendar.launch();

    if (TargetDate !== null) {
        this.getToMonth(TargetDate);

        // If the device is an iPhone class, where the week-view cannot be accessed by a button, then flip the orientation to week view
        // Call getToMonth first so that the week view will start off close to the target date
        if (! this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
            UIALogger.logWarning("Week view does not exist in current orientation; will first rotate device orientation");
            target.setDeviceOrientation( UIAInterfaceOrientation.LANDSCAPE_RIGHT );
        } else {
            // Going to week view at this stage will land UIA into a week view that starts off close to the target date
            UIALogger.logMessage("Week view exists in current orientation; tapping to week view");
        }

        // For N61s (after screen rotation) and iPads, UIA needs to tap week view. This should be a no-op for all other devices
        this.tap(UIAQuery.Calendar.WEEK_BUTTON);
        var visibleDateSet = _getVisibleDates();

        // If the target date is not on display in the week view, then decide to scroll left or right along the week view until the target date appears
        if (! visibleDateSet.contains(TargetDate.setHours(0,0,0,0))) {
            var goLeft = visibleDateSet[0] > TargetDate.setHours(0,0,0,0);
            var direction = this._calendarSheetLeftRightShiftOffset(goLeft);

            while (! _getVisibleDates().contains(TargetDate.setHours(0,0,0,0)) ) {
                this.drag(UIAQuery.query("UIScrollView").last(), direction);
            }
        }
    }

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Week view...');

    this.exitAuxillaryUIStates(currentState);

    currentState = this.currentUIState();

    switch (currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
        case UIStateDescription.Calendar.MONTH_VIEW:
        case UIStateDescription.Calendar.YEAR_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            this.tap(UIAQuery.Calendar.WEEK_BUTTON);
            break;
        case UIStateDescription.Calendar.WEEK_VIEW:
            break;
        default:
            throw new UIAError(
                "Did not get to expected state. Current state: '%0', Expected state: '%1'"
                .format(currentState, UIStateDescription.Calendar.WEEK_VIEW)
            );
        }
}

/**
 * Navigate to the Day View
 *
 * @param {Date} [TargetDate=null] - Scroll to the day specified, if no date it provide just get to view
 *
 * @throws If unable to get to day
 */
calendar.getToDay = function getToDay(TargetDate) {
    TargetDate = (TargetDate === undefined) ? null : this._sanitizeDateTime(TargetDate);

    calendar.launch();

    if (TargetDate !== null) {
        this.getToMonth(TargetDate);

        var dayQuery = this._targetDateElement(TargetDate).isVisible().isEnabled();
        if (! this.waitUntilPresent(dayQuery, 10)) { throw new UIAError("Could not find a tappable day button for %0".format(TargetDate), {identifier:"Day button not found"}); }
        this.doubleTap(dayQuery);
    }

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Day view...');

    this.exitAuxillaryUIStates(currentState);

    currentState = this.currentUIState();

    switch (currentState) {
        case UIStateDescription.Calendar.WEEK_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            this.tap(UIAQuery.Calendar.DAY_BUTTON);
            break;
        case UIStateDescription.Calendar.MONTH_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.DAY_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.YEAR_VIEW:
            this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            if (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) {
                this.tap(UIAQuery.Calendar.DAY_BUTTON);
            } else {
                this.tap(UIAQuery.Calendar.TODAY_BUTTON);
            }
            break;
        case UIStateDescription.Calendar.DAY_VIEW:
            break;
        default:
            throw new UIAError(
                "Did not get to expected state. Current state: '%0', Expected state: '%1'"
                .format(currentState, UIStateDescription.Calendar.DAY_VIEW)
            );
        }
}

/**
 * Navigate to the Calendar View
 *
 * @throws If unable to get to calendar
 */
calendar.getToCalendarView = function getToCalendarView() {

    calendar.launch();

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Calendars view...');

    switch (currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
        case UIStateDescription.Calendar.WEEK_VIEW:
        case UIStateDescription.Calendar.MONTH_VIEW:
        case UIStateDescription.Calendar.YEAR_VIEW:
            break;
        default:
            this.exitAuxillaryUIStates(currentState);
        }

    this.tap(UIAQuery.Calendar.CALENDARS_BUTTON);
}

/**
 * Navigate to the Search View
 *
 * @throws If unable to get to search
 */
calendar.getToSearch = function getToSearch() {

    calendar.launch();

    var currentState = this.currentUIState();

    UIALogger.logMessage('Attempting to get to Search view...');

    switch (currentState) {
        case UIStateDescription.Calendar.DAY_VIEW:
        case UIStateDescription.Calendar.WEEK_VIEW:
        case UIStateDescription.Calendar.MONTH_VIEW:
        case UIStateDescription.Calendar.YEAR_VIEW:
            break;
        default:
            this.exitAuxillaryUIStates(currentState);
        }

    this.tap(UIAQuery.Calendar.SEARCH_BUTTON);
}

/**
 * Get to the event using the Calendar Week View
 *
 * @param {object} SearchOptions - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 * @throws If unable to get to event
 */
calendar._getToEvent_CalendarWeekView = function _getToEvent_CalendarWeekView(SearchOptions) {
    UIALogger.logMessage("Looking for event with title '%0' through the Calendar Week view...".format(SearchOptions.Title));
    this.getToWeek(SearchOptions.StartDate);

    var eventsOnSpecifiedDay = UIAQuery.query("UIScrollView").andThen(UIAQuery.contains("%0 %1".format(this.MONTHS[SearchOptions.StartDate.getMonth()], SearchOptions.StartDate.getDate()))).andThen(UIAQuery.buttons());
    SearchOptions.EventQuery = eventsOnSpecifiedDay.contains(SearchOptions.Title);
    SearchOptions.ViewString = 'week view';
    return this._cycleThroughPotentialEventMatches(SearchOptions);
}

/**
 * Get to the event using the Calendar Day View
 *
 * @param {object} SearchOptions - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 * @throws If unable to get to event
 */
calendar._getToEvent_CalendarDayView = function _getToEvent_CalendarDayView(SearchOptions) {
    UIALogger.logMessage("Looking for event with title '%0' through the Calendar Day view...".format(SearchOptions.Title));
    this.getToDay(SearchOptions.StartDate);

    // Save the DontThrow flag - this is used in the second events query
    var dontThrow = SearchOptions.DontThrow;

    // check for buttons with NO children, b/c there are duplicate buttons
    var allDayEvents = UIAQuery.query('EKDayAllDayView').andThen(UIAQuery.buttons().leaves().contains(SearchOptions.Title));
    var nonAllDayEvents = UIAQuery.query('EKDayViewContent').andThen(UIAQuery.buttons().leaves().contains(SearchOptions.Title));

    // Attempt to search through qualifying all-day events BUT don't throw
    SearchOptions.EventQuery = allDayEvents;
    SearchOptions.ViewString = 'day view (all-day)';
    SearchOptions.DontThrow  = true;    // Force DontThrow flag to be true, because we need to be able to run a second search later
    var indexOfMatchingEvent = this._cycleThroughPotentialEventMatches(SearchOptions);

    if (indexOfMatchingEvent >= 0) {
        return indexOfMatchingEvent;

    // If not found, attempt to search through qualifying non all-day events, and throw on search failure
    } else {
        SearchOptions.EventQuery = nonAllDayEvents;
        SearchOptions.ViewString = 'day view (non all-day)';
        SearchOptions.DontThrow  = dontThrow;   // Reload DontThrow flag
        return this._cycleThroughPotentialEventMatches(SearchOptions);
    }
}

/**
 * Get to the event using the Month List View (This view is only available for iPhones/compact-view devices)
 *
 * @param {object} SearchOptions - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 */
calendar._getToEvent_MonthListView = function _getToEvent_MonthListView(SearchOptions) {
    UIALogger.logMessage("Searching for event through the month list view...");
    this.getToMonth(SearchOptions.StartDate);

    // Now that we are in day view, tap the list button to get into day list view
    this._setToListView(true);

    // Tap the intended date, since only events from the active date will appear on the list
    this.doubleTap(this._targetDateElement(SearchOptions.StartDate));

    // Replied-to events have a \uFFCC prepended to the title, but \uFFCC doesn't escape well on the terminal
    var cellPredicate = "name == '%0' OR (name.length == %1 AND name ENDSWITH '%0')".format(SearchOptions.Title, SearchOptions.Title.length+1);
    SearchOptions.EventQuery = UIAQuery.tableCells().andThen(UIAQuery.staticTexts().withPredicate(cellPredicate)).parent();
    SearchOptions.ViewString = 'month list view';
    return this._cycleThroughPotentialEventMatches(SearchOptions);
}

/**
 * Get to the event using the Day List View (This view is only available for iPhones/compact-view devices)
 *
 * @param {object} SearchOptions - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 */
calendar._getToEvent_DayListView = function _getToEvent_DayListView(SearchOptions) {
    UIALogger.logMessage("Searching for event through the day list view...");
    this.getToDay(SearchOptions.StartDate);

    // Now that we are in day view, tap the list button to get into day list view
    this._setToListView(true);

    SearchOptions.EventQuery = this._sectionSubElementQuery(UIAQuery.Calendar.SEARCH_RESULTS_DATE_SECTION, this._toDateString(SearchOptions.StartDate), SearchOptions.Title, true);
    SearchOptions.ViewString = 'day list view';
    return this._cycleThroughPotentialEventMatches(SearchOptions);
}

/**
 * Get to the event using the Search List
 *
 * @param {object} SearchOptions - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 * @throws If unable to get to event
 */
calendar._getToEvent_SearchListView = function _getToEvent_SearchListView(SearchOptions) {
    UIALogger.logMessage("Searching for event through the search list view...");
    var goSearchEvent = (function(SearchTerm) {
        // go to the search view. this will also open the app if it is not yet open
        this.getToSearch();

        // Perform the actual search
        this._enterTextAndDismiss(UIAQuery.searchBars(), SearchTerm);

        // Verify after performing text search that the search results container is actually visible
        if (! this.waitUntilPresent(UIAQuery.Calendar.SEARCH_RESULTS_CONTAINER, 3) ) {
            throw new UIAError("Attempted to search for event '%0' but could not find the search results view!".format(SearchTerm), {identifier: "Search results view is not visible"});
        }
    }).bind(this, SearchOptions.Title);
    goSearchEvent();

    // Find cells below the startDateSection but above the next date section (if a next date section exists)
    // Some start date sections are named "Sunday, June 15, 2014" while others are named "Sunday, June 15"
    // If StartDate is not given, then we simply search by title
    // Use contains since events to be accepted starts with 'Event needs reply'.
    var searchEventBelowStartDate = this._sectionSubElementQuery(UIAQuery.Calendar.SEARCH_RESULTS_DATE_SECTION,
        this._toDateString(SearchOptions.StartDate), SearchOptions.Title);
    var searchEventByTitle = UIAQuery.Calendar.SEARCH_RESULTS_CONTAINER
        .andThen(UIAQuery.tableCells().contains("%0, ".format(SearchOptions.Title)));
    SearchOptions.EventQuery                        = SearchOptions.StartDate ? searchEventBelowStartDate : searchEventByTitle;
    SearchOptions.ViewString                        = 'search list view';
    SearchOptions.GetBackToStartingPointFunction    = goSearchEvent;
    return this._cycleThroughPotentialEventMatches(SearchOptions);
}

/**
 * Get to the event using the Calendar Inbox
 *
 * @param {object} SearchOptions                    - A struct containing the same required fields as the SearchOptions argument for calendar._cycleThroughPotentialEventMatches(), but without SearchOptions.EventQuery and SearchOptions.ViewString, + the following extra attributes
 * @param {enum}        [SearchOptions.InboxList=calendar.INBOX_LIST_VALUES.NEW]        - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
 * @param {object} GoBackToInboxViewAfterSearch     - Get back to the inbox view after search and return the query to the inbox item (for responding to invites via inbox instead of inbox detailed view)
 *
 * @returns {UIAQuery|number}    Returns Index of EventQuery that matches event, or throws if none found (returns -1 if SearchOptions.DontThrow is true and none found)
 * @throws If unable to get to event
 */
calendar._getToEvent_InboxView = function _getToEvent_InboxView(SearchOptions, GoBackToInboxViewAfterSearch) {
    SearchOptions.InboxList = this._sanitizeInboxList(SearchOptions.InboxList);

    UIALogger.logMessage("Searching for event through the inbox ('%0')...".format(SearchOptions.InboxList));
    var goToInboxFn = (function() {
        this.getToYear();
        this.tap(UIAQuery.Calendar.INBOX_BUTTON);

        var expectedState = (SearchOptions.InboxList === this.INBOX_LIST_VALUES.REPLIED ? UIStateDescription.Calendar.INBOX_REPLIED : UIStateDescription.Calendar.INBOX_NEW);
        var buttonToState = (SearchOptions.InboxList === this.INBOX_LIST_VALUES.REPLIED ? UIAQuery.Calendar.REPLIED_EVENTS_BUTTON : UIAQuery.Calendar.NEW_EVENTS_BUTTON);

        this.tap(buttonToState);

        var currentState = this.currentUIState();

        if (currentState !== expectedState) {
            throw new UIAError(
                "Did not get to expected state. Current state: '%0', Expected state: '%1'"
                .format(currentState, expectedState)
            );
        }

    }).bind(this);
    goToInboxFn();

    SearchOptions.EventQuery                        = UIAQuery.Calendar.INBOX_VIEW.andThen(UIAQuery.staticTexts(SearchOptions.Title));
    SearchOptions.ViewString                        = 'inbox view';
    SearchOptions.GetBackToStartingPointFunction    = goToInboxFn;
    SearchOptions.GoBackToViewAfterSearch           = GoBackToInboxViewAfterSearch;
    var indexOfMatchingEvent = this._cycleThroughPotentialEventMatches(SearchOptions);

    /*
        At this point of execution, indexOfMatchingEvent is one of two values:
            1) -1       = can ONLY happen when DontThrow is set to true (otherwise, calendar._cycleThroughPotentialEventMatches() would have thrown UIAError when it cannot find event)
            2) >= 0     = can ONLY happen when DontThrow is set to false

        DontThrow is set to true ONLY when calendar._getToEvent() is called by calendar.verifyEventDoesNotExist(), and
        calendar.verifyEventDoesNotExist() expects an integer to be returned, so we return the integer when [ DontThrow == true <---> indexOfMatchingEvent == -1 ]

        Other methods calling calendar._getToEvent() (i.e. calendar.respondToInvite()) expect a query instead, so we return the query when [ DontThrow == false <---> indexOfMatchingEvent >= 0 ]
    */
    if (indexOfMatchingEvent < 0) {
        return indexOfMatchingEvent;

    } else {
        var finalQuery = SearchOptions.EventQuery.atIndex(indexOfMatchingEvent).parent();
        UIALogger.logMessage('Returning the exact query to the found event --> %0'.format(finalQuery.description()));
        return finalQuery;
    }
}

/**
 * Get to the event
 *
 * @param {string}  Title                                               - Title of event
 * @param {Date}    StartDate                                           - Start date of event
 * @param {enum}    WorkflowToEvent                                     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 * @param {object}  SearchOptions                                       - Options struct
 * @param {string}          [SearchOptions.PredicateString=""]                        - Predicate string to match an event property by (i.e. "name CONTAINS 'Repeats Weekly'")
 * @param {bool}            [SearchOptions.ExpectPredicateToFindMatch=true]           - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
 * @param {enum}            [SearchOptions.InboxList=calendar.INBOX_LIST_VALUES.NEW]  - Inbox list to look for event (enum calendar.INBOX_LIST_VALUES)
 * @param {bool}            [SearchOptions.DontThrow=false]                           - Specify whether to throw if event is not found (useful for the calendar.verifyEventDoesNotExist() library call)
 *
 * @throws If event cannot be found or unable to get to event
 */
calendar._getToEvent = function _getToEvent(Title, StartDate, WorkflowToEvent, SearchOptions) {
    SearchOptions.StartDate = (StartDate === undefined || StartDate === null) ? undefined : this._sanitizeDateTime(StartDate);
    WorkflowToEvent = this._sanitizeWorkflowToEvent(WorkflowToEvent);

    if (SearchOptions.StartDate === undefined && ! [this.WORKFLOWS_TO_EVENT.SEARCH_LIST, this.WORKFLOWS_TO_EVENT.INBOX_EVENT_DETAILS, this.WORKFLOWS_TO_EVENT.INBOX].contains(WorkflowToEvent)) {
        throw new UIAError("WorkflowToEvent is %0 which requires a valid StartDate, but none provided!".format(WorkflowToEvent), {identifier:'Invalid StartDate value'});
    }

    SearchOptions.Title = String(Title);
    if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.CALENDAR_WEEK) {
        return this._getToEvent_CalendarWeekView(SearchOptions);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.CALENDAR_DAY) {
        return this._getToEvent_CalendarDayView(SearchOptions);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.MONTH_LIST) {
        return this._getToEvent_MonthListView(SearchOptions);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.DAY_LIST) {
        return this._getToEvent_DayListView(SearchOptions);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.SEARCH_LIST) {
        return this._getToEvent_SearchListView(SearchOptions);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.INBOX_EVENT_DETAILS) {
        return this._getToEvent_InboxView(SearchOptions, false);

    } else if (WorkflowToEvent === this.WORKFLOWS_TO_EVENT.INBOX) {
        return this._getToEvent_InboxView(SearchOptions, true);

    } else {
        throw new UIAError("WorkflowToEvent '%0' has no associated _getToEvent_*() method defined yet!".format(WorkflowToEvent), {identifier:'No method defined for getting to event for the given workflow'});
    }
}

/**
 * Get to the EDIT EVENT view, given we are on an event's EVENT DETAILS view.
 * This is a no-op for event invites, since the event view === event edit view
 */
calendar._getToEditEventView = function _getToEditEventView() {
    this._tapIfExists(UIAQuery.Calendar.EVENT_DETAILS_EDIT_BUTTON, 3);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Private UIAApp Extension Methods                 */
/*                                                                             */
/*      UIAApp extension methods that are specifically useful for Calendar     */
/*                                                                             */
/*******************************************************************************/

calendar._enterTextAndDismiss = function _enterTextAndDismiss(query, text, clearTextFirst) {
    var options = { allowTypeStringToRetry:true };
    if (clearTextFirst) {
        options['clearTextBeforeTyping'] = true;
    }

    this.enterText(query, String(text), options);

    var keyboard = UIAQuery.keyboard();
    if (this.exists(keyboard)) {
        UIALogger.logMessage("Dismissing keyboard");
        this.tap(keyboard.andThen(UIAQuery.buttons('Done').orElse(UIAQuery.buttons('Return')).orElse(UIAQuery.buttons('Search'))));
    }
}

calendar._switchVal = function _switchVal(query) {
    return Boolean(Number(this.inspect(query).value));
}

calendar._tapIfExists = function _tapIfExists(queryToTap, timeToWait) {
    if (Number(timeToWait) > 0) { this.waitUntilPresent(queryToTap, timeToWait); }
    this.tapIfExists(queryToTap);
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Calendar Library Public API - Events & Invites                      */
/*                                                                             */
/*      This is where all public API methods for handling events               */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Add new calendar event
 *
 * @param {string} Title            - Title of the event
 * @param {Date}   StartDate        - Date when the first occurrence of the event starts
 * @param {Date}   EndDate          - Date when the first occurrence of the event ends
 * @param {object} EventOptions     - A struct containing the same fields as the options argument for calendar._setEventOptions()
 *
 * @throws If unable to add event
 */
calendar.addEvent = function addEvent(Title, StartDate, EndDate, EventOptions) {
    UIALogger.logMessage('Attempting to create event with options: %0'.format(JSON.stringify(EventOptions)));

    EventOptions = (EventOptions === undefined) ? {} : EventOptions;

    this.getToYear();
    this.tap(UIAQuery.Calendar.ADD_BUTTON)

    EventOptions.Title = Title;
    EventOptions.StartDate = StartDate;
    EventOptions.EndDate = EndDate;
    this._setEventOptions(EventOptions);
}

/**
 * Verifies event exists on calendar, and validates the event's attributes, if provided.
 *
 * @param {string}  Title                   - Title of the event
 * @param {Date}    StartDate               - Date when the first occurrence of the event starts
 * @param {object}  FieldsToTest            - A struct containing the same fields as the options argument for calendar._setEventOptions()
 * @param {object}  SearchOptions           - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}          [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to find or validate event
 */
calendar.verifyEventExists = function verifyEventExists(Title, StartDate, FieldsToTest, SearchOptions) {
    UIALogger.logMessage('Attempting to verify event with title: %0'.format(Title));

    FieldsToTest = (FieldsToTest === undefined) ? {} : FieldsToTest;
    FieldsToTest.Title = Title;

    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
    this._getToEditEventView();

    this._validateEventFields(FieldsToTest);
}

/**
 * Verifies event exists on invitee's calendar, and validates provided event attributes.
 * The method deals with event details view on invitee's device. This view doesn't have 'Edit' option
 * so verifyEventExists() can not be used.
 *
 * @param {string}  Title                   - Title of the event
 * @param {Date}    StartDate               - Date when the first occurrence of the event starts
 * @param {object}  FieldsToTest            - A struct containing the same fields as the options argument for calendar._setEventOptions()
 * @param {object}  SearchOptions           - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}          [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to find or validate event
 */
calendar.verifyEventExistsInviteeView = function verifyEventExistsInviteeView(Title, StartDate, FieldsToTest, SearchOptions) {
    UIALogger.logMessage('Starting event verification with title: %0'.format(Title));

    FieldsToTest = (FieldsToTest === undefined) ? {} : FieldsToTest;
    FieldsToTest.Title = Title;

    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
    this._validateEventFieldsInviteeView(FieldsToTest);
}

/**
 * Edit an existing calendar event
 *
 * @param {string}  Title                               - Title of the event to edit
 * @param {Date}    StartDate                           - Date when the occurrence of the event to edit
 * @param {object}  EventOptions                        - A struct containing the same fields as the options argument for calendar._setEventOptions()
 * @param {boolean} [ApplyToFutureOccurrences=false]    - Apply changes to future event
 * @param {object}  SearchOptions                       - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}          [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to find or edit the event
 */
calendar.editEvent = function editEvent(Title, StartDate, EventOptions, ApplyToFutureOccurrences, SearchOptions) {
    EventOptions = (EventOptions === undefined) ? {} : EventOptions;

    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
    this._getToEditEventView();

    // If we want to change Title or StartDate of event, we move the values over right here.
    EventOptions.Title = EventOptions.NewTitle;
    EventOptions.StartDate = EventOptions.NewStartDate;
    this._setEventOptions(EventOptions, ApplyToFutureOccurrences);
}

/**
 * Searches for an existing calendar event
 *
 * @param {string}  Title               - Search term or Title of the event to look for
 * @param {Date}    StartDate           - Date when the occurrence of the event to look for
 * @param {object}  SearchOptions       - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}          [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to find event
 */
calendar.searchForEvent = function searchForEvent(Title, StartDate, SearchOptions) {
    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
}

/**
 * Delete an existing calendar event
 *
 * @param {string}  Title                               - Title of the event to edit
 * @param {Date}    StartDate                           - Date when the occurrence of the event to edit
 * @param {boolean} [ApplyToFutureOccurrences=false]    - Apply changes to future event
 * @param {object}  SearchOptions                       - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}        [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to delete event
 */
calendar.deleteEvent = function deleteEvent(Title, StartDate, ApplyToFutureOccurrences, SearchOptions) {
    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);

    // On iPads, an alert will appear when the event details view is in the calendar day view.  The query used in tapIfExists() works for alerts as well
    this.handlingAlertsInline(UIAQuery.alerts(), function () {
        this.waitUntilPresent(UIAQuery.Calendar.DELETE_EVENT_BUTTON, 3);    // Wait for transition to finish and button to be present before tapping
        var applyButton = (ApplyToFutureOccurrences ? UIAQuery.Calendar.BULK_EVENTS_BUTTON : UIAQuery.Calendar.SINGLE_EVENT_BUTTON).isVisible();
        var confirmDeleteButton = UIAQuery.Calendar.CONFIRM_DELETE_BUTTON.orElse(applyButton);
        var viewDidAppear = UIAWaiter.waiter('Alert');

        this.tap(UIAQuery.Calendar.DELETE_EVENT_BUTTON);
        if (! viewDidAppear.wait(5)) { throw new UIAError("The alert to confirm deletion of event '%0' never appeared!".format(Title), {identifier:"Confirm Delete alert never appeared"}); }
        this.waitUntilPresent(confirmDeleteButton, 3);
        this.tap(confirmDeleteButton);
    });
}

/**
 * Verify that an event does not exist on calendar
 *
 * @param {string}  Title                               - Title of the event to edit
 * @param {Date}    StartDate                           - Date when the occurrence of the event to edit
 * @param {object}  SearchOptions                       - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}        [SearchOptions.WorkflowToEvent=<default WorkflowToEvent from calendar._defaultEventSearchOptions()>]     - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to delete event
 */
calendar.verifyEventDoesNotExist = function verifyEventDoesNotExist(Title, StartDate, SearchOptions) {
    SearchOptions = this._defaultEventSearchOptions(SearchOptions);
    SearchOptions.DontThrow = true;     // This is absolutely necessary to ensure that calendar._getToEvent() returns -1 if it cannot find the event, otherwise calendar._getToEvent() will throw

    if (this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions) < 0) {
        UIALogger.logMessage("Could not find the event '%0' (as expected)".format(Title));
    } else {
        throw new UIAError("Event '%0' exists in calendar!".format(Title), {identifier:"Event exists in calendar"});
    }
}

calendar.deleteAllEvents = function deleteAllEvents() {
    throw new UIAError("Not yet implemented", {identifier:"Method not implemented yet"});
}

/**
 * Respond to event invitation (default response is 'Accept')
 *
 * @param {string}  Title                                           - Title of the event to edit
 * @param {Date}    StartDate                                       - Date when the occurrence of the event to edit
 * @param {object}  ResponseOptions                                 - A struct of response options
 * @param {enum}            [ResponseOptions.Response=calendar.INVITE_RESPONSE_VALUES.ACCEPT]       - Invite response (enum calendar.INVITE_RESPONSE_VALUES)
 * @param {bool}            [ResponseOptions.AcceptAll=false]                                       - Accept all occurrences of the event invite
 * @param {enum}            [ResponseOptions.ShowAs=""]                                             - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
 * @param {bool}            [ResponseOptions.Private=false]                                         - Set event to private (Not available in all calendars)
 * @param {string}          [ResponseOptions.ReplyComment=""]                                       - Comment to input when responding to invites as declined
 * @param {object}  SearchOptions                                   - A struct containing the same fields as the options argument for calendar._getToEvent() + the following extra attributes:
 * @param {enum}            [SearchOptions.WorkflowToEvent=calendar.WORKFLOWS_TO_EVENT.INBOX]             - Workflow to event (enum calendar.WORKFLOWS_TO_EVENT)
 *
 * @throws If unable to respond to event invite
 */
calendar.respondToInvite = function respondToInvite(Title, StartDate, ResponseOptions, SearchOptions) {
    Title = String(Title);
    StartDate = this._sanitizeDateTime(StartDate);

    SearchOptions = UIAUtilities.defaults((SearchOptions === undefined) ? {} : SearchOptions, {
        WorkflowToEvent:                this.WORKFLOWS_TO_EVENT.INBOX,
        InboxList:                      this.INBOX_LIST_VALUES.NEW,
        PredicateString:                '',
        ExpectPredicateToFindMatch:     true,

    });
    SearchOptions.Title = Title;
    SearchOptions.StartDate = StartDate;

    ResponseOptions = UIAUtilities.defaults((ResponseOptions === undefined) ? {} : ResponseOptions, {
        Response:                       this.INVITE_RESPONSE_VALUES.ACCEPT,
        ReplyComment:                   '',
        AcceptAll:                      false,
        Private:                        false,
        ShowAs:                         '',
    });
    ResponseOptions.Response = this._sanitizeInviteResponse(ResponseOptions.Response);

    SearchOptions.WorkflowToEvent = this._sanitizeWorkflowToEvent(SearchOptions.WorkflowToEvent);
    if (SearchOptions.WorkflowToEvent === this.WORKFLOWS_TO_EVENT.INBOX) {
        var resultQuery = this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
        this._respondToInvite_InboxView(resultQuery, ResponseOptions.Response, ResponseOptions.AcceptAll, ResponseOptions.ReplyComment);

    } else {
        this._getToEvent(Title, StartDate, SearchOptions.WorkflowToEvent, SearchOptions);
        this._getToEditEventView();
        this._respondToInvite_DetailsView(ResponseOptions.Response, ResponseOptions.AcceptAll, ResponseOptions.ShowAs, ResponseOptions.Private, ResponseOptions.ReplyComment);
    }
}

/**
 * Waits for a calendar event alert notification to appear and handles notification.
 * If 'AddEvent' is set, will add the event beforehand.
 *
 * @param {object} options              - Options dictionary
 * @param {number} options.Timeout      - Amount of time (in seconds) to wait for an event notification to appear.
 *                                      A cushion will be added to this timeout; therefore, this timeout is not exact.
 * @param {boolean} options.AddEvent    - Flag. If set, will add an event to wait for.
 * @param {string} options.Title        - Title of event
 * @param {string} options.Alert        - Alert for event. See calendar.EventAlertValues for possible values.
 * @param {boolean} options.[blank]     - Other options that can be set if an event is to be created.
 *                                      See calendar._setEventOptions().
 *
 * @throws If event notification did not appear.
 */
calendar.waitForCalendarEventNotification = function waitForCalendarEventNotification(options) {
    options = UIAUtilities.defaults(options, {
        Timeout:    60,
        AddEvent:   true,
        Title:      'Event',
        Alert:      this.EventAlertValues.FIVE_MINUTES,
    });

    UIAUtilities.assert(
        options.AddEvent || options.StartDate, // no AddEvent and no StartDate
        'A Start Date of an existing event must be given if no new event is being added.'
    );

    var timeOfAlert;
    var eventNotificationTime = this.calculateEventNotificationTime(options.Alert);
    var cushion = 120;   // cushion for timeout and event creation date

    // waiter for notification to appear
    var notificationAppeared = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass == "NCLegacyNotificationShortLookViewController" OR controllerClass == "NCNotificationShortLookViewController"'
    );

    var eventNotificationAlert = UIAQuery.alerts().withPredicate("name contains '%0' OR label contains '%0' OR ANY descendants.name contains '%0'".format(options.Title));

    if (options.AddEvent) {
        options.StartDate = new Date();
        // StartDate originally used options.StartDate.getSeconds() + eventNotificationTime + cushion
        // for the start time of the event, but if we were close to the end of a minute (30 to 59 seconds)
        // then slower devices would still be setting up while the alert appears.
        // We've instead increased the cushion by a minute if we are near the minute threshold.
        if (options.StartDate.getSeconds() > 30) {
            cushion = cushion + 60;
        }
        options.StartDate.setSeconds(eventNotificationTime + cushion);

        this.addEvent(options.Title, options.StartDate, options.EndDate, options);
    }

    this.verifyEventExists(
        options.Title,
        options.StartDate,
        {}, // we will look for a title only, no event attributes
        { WorkflowToEvent: calendar.WORKFLOWS_TO_EVENT.CALENDAR_DAY }
    );

    this.handlingAlertsInline(eventNotificationAlert, function() {
        // tap the done button
        this.tap(UIAQuery.Calendar.EDIT_EVENT_CONTAINER.ancestors().andThen(UIAQuery.DONE_BUTTON));
        UIALogger.logMessage('Tapped button to finish event creation. Beginning wait for notification ...');

        // wait for notification of event
        if (!notificationAppeared.wait(options.Timeout+cushion)) {
            throw new UIAError('Event notification alert did not appear in the expected time frame.');
        }

        // get time of alert
        timeOfAlert = new Date().getTime();

        // alert owned by springboard
        // NOTE: <rdar://problem/32229339> Banner alerts must now be dismissed by swiping down twice instead of up once
        //  we should remove this workaround when <rdar://problem/32253863> is completed
        springboard.drag(eventNotificationAlert, {fromOffset: {x: 0.5, y: 0.5}, toQuery: UIAQuery.application(), toOffset: {x: 0.5, y: 1.0}, duration: 0.5, flick: 1});
        springboard.dragIfExists(eventNotificationAlert, {fromOffset: {x: 0.5, y: 0.5}, toQuery: UIAQuery.application(), toOffset: {x: 0.5, y: 1.0}, duration: 0.5, flick: 1});
    });

    // lets ensure the alert came up within the expected timeframe with a 1 minute cushion
    var expectedAlertTime = options.StartDate.getTime() - (eventNotificationTime*1000); // switch to epoch and milliseconds
    var oneMinuteInMilliseconds = 60000;
    var lower = expectedAlertTime - oneMinuteInMilliseconds;
    var upper = expectedAlertTime + oneMinuteInMilliseconds;

    if (timeOfAlert < lower || timeOfAlert > upper) {
        UIALogger.logMessage('Expected time of alert: %0, time of alert: %1'.format(new Date(expectedAlertTime), new Date(timeOfAlert)));
        throw new UIAError('Event notification alert appeared but NOT within the expected timeframe.');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Calendar Library Public API - Calendars                             */
/*                                                                             */
/*      This is where all public API methods for handling calendars            */
/*      are defined.                                                           */
/*                                                                             */
/*******************************************************************************/

/**
 * Add new calendar
 *
 * @param {string}   CalendarGroup      - name of the calendar group that the calendar is in
 * @param {string}   CalendarName       - name of the calendar
 * @param {object}   CalendarOptions    - A struct containing the same fields as the options argument for calendar._setCalendarOptions()
 *
 * @throws If unable to edit calendar settings
 */
calendar.addCalendar = function addCalendar(CalendarGroup, CalendarName, CalendarOptions) {
    // Go to Edit Calendars view
    this.getToCalendarView();
    this.tap(UIAQuery.Calendar.EDIT_BUTTON);

    // Add new calendar by name
    // The subelement name is "Add Calendar\u2026" but we would like to avoid localization problems with unicode in the string search, so we query using UIAQuery.contains() instead
    this.tap( this._specificCalendarQuery(CalendarGroup, "Add Calendar", true) );
    this._setCalendarOptions( {CalendarName: CalendarName} );

    // Go back to summary view and add the other event properties
    CalendarOptions.NewCalendarName = undefined;
    this.tap(UIAQuery.DONE_BUTTON);
    this.editCalendar(CalendarGroup, CalendarName, CalendarOptions);
}

/**
 * Verifies that a calendar exists
 *
 * @param {string} CalendarGroup    - Name of the calendar group that the calendar is in
 * @param {string} CalendarName     - Name of the calendar
 *
 * @throws If the calendar is not found
 */
calendar.verifyCalendarExists = function verifyCalendarExists(CalendarGroup, CalendarName) {
    this.getToCalendarView();
    this._verifyCalendarExistence(CalendarGroup, CalendarName);
}

/**
 * Verifies that a calendar does not exist
 *
 * @param {string} CalendarGroup    - Name of the calendar group that the calendar is in
 * @param {string} CalendarName     - Name of the calendar
 *
 * @throws If the calendar is found
 */
calendar.verifyCalendarDoesNotExist = function verifyCalendarDoesNotExist(CalendarGroup, CalendarName) {
    this.getToCalendarView();
    this._verifyCalendarExistence(CalendarGroup, CalendarName, false);
}

/**
 * Edit an existing calendar
 *
 * @param {string}   CalendarGroup      - name of the calendar group that the calendar is in
 * @param {string}   CalendarName       - name of the calendar
 * @param {object}   CalendarOptions    - A struct containing the same fields as the options argument for calendar._setCalendarOptions()
 *
 * @throws If unable edit calendar settings
 */
calendar.editCalendar = function editCalendar(CalendarGroup, CalendarName, CalendarOptions) {
    // First set the calendar's visibility (this property is not in the calendar details view, but in the main Calendar's view)
    if (CalendarOptions.Visibility !== undefined) this.setCalendarVisiblilty(CalendarGroup, CalendarName, CalendarOptions.Visibility);

    // Add CalendarName into options if renaming the calendar
    if (CalendarOptions.NewCalendarName) CalendarOptions.CalendarName = CalendarOptions.NewCalendarName;
    CalendarOptions.CalendarGroup = CalendarGroup;

    // Navigate to event details and make calendar modifications
    this._getToCalendarEdit(CalendarGroup, CalendarName);
    this._setCalendarOptions(CalendarOptions);
}

/**
 * Delete an existing calendar
 *
 * @param {string}   CalendarGroup      - name of the calendar group that the calendar is in
 * @param {string}   CalendarName       - name of the calendar
 *
 * @throws If unable to delete calendar
 */
calendar.deleteCalendar = function deleteCalendar(CalendarGroup, CalendarName) {
    this._getToCalendarEdit(CalendarGroup, CalendarName);
    this.tap(UIAQuery.Calendar.DELETE_CALENDAR_BUTTON);
    this._tapIfExists(UIAQuery.Calendar.DELETE_CALENDAR_BUTTON, 2); // Tap the confirmation to delete calendar
}


/**
 * Sets the visibility of a calendar
 *
 * @param {string} CalendarGroup    - Name of the calendar group that the calendar is in
 * @param {string} CalendarName     - Name of the calendar
 * @param {bool}   Visibility       - Set visibility of the calendar (true if the calendar is to be hidden, else false)
 *
 * @throws If the calendar is not found or if the calendar's visibility could be set
 */
calendar.setCalendarVisiblilty = function setCalendarVisiblilty(CalendarGroup, CalendarName, Visibility) {
    this.verifyCalendarExists(CalendarGroup, CalendarName);
    this._setCalendarToVisible(CalendarGroup, CalendarName, Visibility);
}

/**
 * Shows or hides the declined events
 *
 * @param {bool} ShowDeclinedEvents - true if all calendars are to be hidden, else false
 *
 * @throws If the switch cannot be tapped
 */
calendar.setShowDeclinedEvents = function setShowDeclinedEvents(ShowDeclinedEvents) {
    this.getToCalendarView();
    this.setControl(UIAQuery.Calendar.SHOW_DECLINED_EVENTS, Boolean(ShowDeclinedEvents));
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Variable/Argument Sanitizers                     */
/*                            and Struct Defaults                              */
/*                                                                             */
/*      Sanitizes variables against types and Calendar-specific enums/structs  */
/*                                                                             */
/*******************************************************************************/

/**
 * Asserts that a key is in an enum of { key : value }
 *
 * @param {enum}    enumDict     - Enum to check against (implemented in JS as an object)
 * @param {string}  key          - Key to check
 * @param {string}  description  - Description of the key (for error logging)
 *
 * @throws If the key was not found in the enum
 */
calendar._assertEnumKey = function _assertEnumKey(enumDict, key, description) {
    var enumKeys = Object.keys(enumDict);
    if (! enumKeys.contains(key)) {
        throw new UIAError("Invalid %0 key provided ('%1'); accepted enum keys are %2!".format(description, key, JSON.stringify(enumKeys)), {identifier:'Invalid %0'.format(description)});
    } return key;
}

/**
 * Asserts that a value is in an enum of { key : value }
 *
 * @param {enum}    enumDict     - Enum to check against (implemented in JS as an object)
 * @param {string}  value        - Key to check
 * @param {string}  description  - Description of the key (for error logging)
 *
 * @throws If the value was not found in the enum
 */
calendar._assertEnumValue = function _assertEnumValue(enumDict, value, description) {
    var enumValues = Object.keys(enumDict).map(function (k) { return enumDict[k]; });
    if (! enumValues.contains(value)) {
        throw new UIAError("Invalid %0 value provided ('%1'); accepted enum values are %2!".format(description, value, JSON.stringify(enumValues)), {identifier:'Invalid %0'.format(description)});
    } return value;
}

/**
 * Sanitizes the view name
 *
 * @param {string}  viewName                - Candidate view name to check
 *
 * @throws If the view name is not a value of calendar.CALENDAR_VIEWS
 * @returns {string}    Returns the sanitized view name
 */
calendar._sanitizeViewName = function _sanitizeViewName(viewName) {
    return this._assertEnumValue(this.CALENDAR_VIEWS, String(viewName).capitalize(), 'View Name');
}

/**
 * Sanitizes the inbox list
 *
 * @param {string}  inboxList               - Candidate inbox list to check
 *
 * @throws If the inboxList is not a value of calendar.INBOX_LIST_VALUES
 * @returns {string}    Returns the sanitized inbox list
 */
calendar._sanitizeInboxList = function _sanitizeInboxList(inboxList) {
    return this._assertEnumValue(this.INBOX_LIST_VALUES, String(inboxList).capitalize(), 'Inbox List');
}

/**
 * Sanitizes the invitee response
 *
 * @param {string}  inviteeResponse         - Candidate invitee response to check
 *
 * @throws If the inviteResponse is not a value of calendar.INBOX_LIST_VALUES
 * @returns {string}    Returns the sanitized invitee response
 */
calendar._sanitizeInviteResponse = function _sanitizeInviteResponse(inviteResponse) {
    return this._assertEnumValue(this.INVITE_RESPONSE_VALUES, String(inviteResponse).capitalize(), 'Invitee Response');
}

/**
 * Sanitizes the availability
 *
 * @param {string}  availability            - Candidate availability to check
 *
 * @throws If the availability is not a value of calendar.AVAILABILITY_VALUES
 * @returns {string}    Returns the sanitized availability
 */
calendar._sanitizeAvailability = function _sanitizeAvailability(availability) {
    return this._assertEnumValue(this.AVAILABILITY_VALUES, String(availability).capitalize(), 'Availability');
}

/**
 * Sanitizes the workflow
 *
 * @param {string}  workflow                - Candidate workflow to check
 *
 * @throws If the workflow is not a value of calendar.WORKFLOWS_TO_EVENT
 * @returns {string}    Returns the sanitized workflow
 */
calendar._sanitizeWorkflowToEvent = function _sanitizeWorkflowToEvent(workflow) {
    return this._assertEnumValue(this.WORKFLOWS_TO_EVENT, workflow, 'Workflow to Event');
}

/**
 * Sanitizes the repeat key and returns the associated repeat value
 *
 * @param {string}  repeatKey               - Candidate repeat key to check
 *
 * @throws If the repeat key is not a key of this.EVENT_REPEAT_VALUES
 * @returns {string}    Returns the repeat value associated with repeatKey
 */
calendar._sanitizeEventRepeatValue = function _sanitizeEventRepeatValue(repeatKey) {
    repeatKey = this._assertEnumKey(this.EVENT_REPEAT_VALUES, String(repeatKey).toUpperCase(), 'Event Repeat');
    return this.EVENT_REPEAT_VALUES[ repeatKey ];
}

/**
 * Sanitizes a datetime value
 *
 * @param {Date|string}  dateOrString       - Datetime value or string representation of a datetime value
 *
 * @throws If the input is not parseable into a datetime value
 * @returns {Date}    Returns a sanitized datetime value
 */
calendar._sanitizeDateTime = function _sanitizeDateTime(dateOrString) {
    try {
        /* NOTE: If a datestring is passed without time information, it will be interpreted as a UTC date!
            > new Date("2014-12-23")
            Mon Dec 22 2014 16:00:00 GMT-0800 (PST)
        */
        if (dateOrString instanceof Date) return dateOrString;
        else {
            var fnName = arguments.callee.toString();
            fnName = fnName.substr('function '.length);
            fnName = fnName.substr(0, fnName.indexOf('('));

            UIALogger.logWarning("Remember to specify timezone in the date string when calling %0 to account for system timezone! (i.e. '2015-01-06' parses into '2015-01-05 PST')".format(fnName));
            return new Date(dateOrString);
        }
    } catch (e) {
        var errorMessage = "Could not parse object into DateTime ('%0')!".format(dateOrString);
        UIALogger.logError(errorMessage);
        throw new UIAError(errorMessage, {identifier:"Could not parse object into DateTime"})
    }
}

/**
 * Creates a well-formatted SearchOptions object using user-inputted values merged with default values
 *
 * @param {Object}  SearchOptions       - user-inputted search options
 *
 * @returns {Object}    Returns a well-formatted SearchOptions object
 */
calendar._defaultEventSearchOptions = function _defaultEventSearchOptions(SearchOptions) {
    SearchOptions = UIAUtilities.defaults((SearchOptions === undefined) ? {} : SearchOptions, {
        WorkflowToEvent:                this.WORKFLOWS_TO_EVENT.SEARCH_LIST,
        PredicateString:                '',
        ExpectPredicateToFindMatch:     true,
        InboxList:                      this.INBOX_LIST_VALUES.NEW,
        DontThrow:                      false,
    });
    // Takes care of empty-string cases, since UIAUtilities.defaults() doesn't check for that
    if (! SearchOptions.WorkflowToEvent) SearchOptions.WorkflowToEvent = this.WORKFLOWS_TO_EVENT.SEARCH_LIST;
    return SearchOptions
}

/**
 * Gets a formatted string used for querying Calendar elements
 *
 * @param {Date|string}  date       - Datetime value or string representation of a datetime value
 *
 * @throws If the input is not parseable into a datetime value
 * @returns {Date}    Returns a formatted date string
 */
calendar._toDateString = function _toDateString(date) {
    date = this._sanitizeDateTime(date);
    var baseDateString = "%0, %1 %2".format( this.DAY_OF_WEEK[date.getDay()], this.MONTHS[date.getMonth()], date.getDate() );

    // Append year to string if the date's year is not the current year
    if (date.getFullYear() === (new Date()).getFullYear()) {
        return baseDateString;
    } else {
        return "%0, %1".format(baseDateString, date.getFullYear());
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - General Navigation                               */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for general Calendar navigation                                        */
/*                                                                             */
/*******************************************************************************/

/**
 * Asserts device is in a specified view in Calendar
 *
 * @param {enum} ExpectedView            - The expected view (enum UIStateDescription.Calendar)
 *
 * @throws If current view !== ExpectedView
 */
calendar._ensureCurrentViewIs = function _ensureCurrentViewIs(ExpectedView) {
    var actualView = this.currentUIState();
    if (actualView !== ExpectedView) throw new UIAError("UIA expected to be in the '%0' view but is currently in the '%1' view instead!".format(ExpectedView, actualView), {identifier:"Device in unexpected view"});
    return true;
}

/**
 * Asserts device is NOT in a specified view in Calendar
 *
 * @param {enum} NotExpectedView            - The unexpected view (enum UIStateDescription.Calendar)
 *
 * @throws If current view === NotExpectedView
 */
calendar._ensureCurrentViewIsNot = function _ensureCurrentViewIsNot(NotExpectedView) {
    var actualView = this.currentUIState();
    if (actualView === NotExpectedView) throw new UIAError("UIA expected to not be in the '%0' view but currently is!".format(NotExpectedView), {identifier:"Device in unexpected view"});
    return true;
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Navigation to date                               */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigating to specific dates on the Calendar                       */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets the mode of a list of values
 *
 * @param {any[]} List     - List of values
 *
 * @returns {any}    Returns the mode value
 */
calendar._listmode = function _listmode(List) {
    if(List.length == 0) return null;
    var modeMap = {};
    var maxEl = List[0], maxCount = 1;
    for (var i = 0; i < List.length; i++) {
        var el = List[i];
        if (modeMap[el] == null) modeMap[el] = 1;
        else modeMap[el]++;
        if (modeMap[el] > maxCount) {
            maxEl = el;
            maxCount = modeMap[el];
        }
    } return maxEl;
}

/**
 * Gets a set (i.e. python set()) of unique Dates from a list
 *
 * @param {Date[]} Dates     - List of dates
 *
 * @returns {Date[]}    Returns a set of unique dates
 */
calendar._dateSet = function _dateSet (Dates) {
  return Dates.reduce(function (a, val) {
    var t = val.getTime();
    if (a.indexOf(t) === -1) { a.push(t); }
    return a;
  }, []).map(function (d) { return new Date(d); });
}

/**
 * Calculates the offset to shift by for flipping up or down along the calendar view
 *
 * @param {bool} GoingUpwards     - Specify whether we are going up or down along the calendar view sheet
 *
 * @returns {Object}    Returns an offsets struct to pass into the options parameter in UIAApp.drag()
 */
calendar._calendarSheetUpDownShiftOffset = function _calendarSheetUpDownShiftOffset(GoingUpwards) {
    if (GoingUpwards) {
        return (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) ? {toOffset: {x: 0.50, y: 0.80}, fromOffset: {x: 0.50, y: 0.20}} :
                                             {toOffset: {x: 0.50, y: 0.90}, fromOffset: {x: 0.50, y: 0.20}};
    } else {
        return (this.isHorizontalSizeClassRegular(UIAQuery.VISIBLE_NAVBARS.orElse(UIAQuery.navigationBars("AdaptiveSearch")))) ? {toOffset: {x: 0.50, y: 0.20}, fromOffset: {x: 0.50, y: 0.80}} :
                                             {toOffset: {x: 0.50, y: 0.20}, fromOffset: {x: 0.50, y: 0.90}};
    }
}

/**
 * Calculates the offset to shift by for flipping left or right along the calendar view
 *
 * @param {bool} GoingLeftwards     - Specify whether we are going left or right along the calendar view sheet
 *
 * @returns {Object}    Returns an offsets struct to pass into the options parameter in UIAApp.drag()
 */
calendar._calendarSheetLeftRightShiftOffset = function _calendarSheetLeftRightShiftOffset(GoingLeftwards) {
    if (GoingLeftwards) {
        return {toOffset: {x: 0.90, y: 0.50}, fromOffset: {x: 0.10, y: 0.50}};
    } else {
        return {toOffset: {x: 0.10, y: 0.50}, fromOffset: {x: 0.90, y: 0.50}};
    }
}

/**
 * Builds a query to a month element in the calendar year view
 *
 * @param {Date} TargetDate     - Date containing the target month + year
 *
 * @returns {UIAQuery}    Returns query to the target month element
 */
calendar._targetMonthElement = function _targetMonthElement(TargetDate) {
    TargetDate = this._sanitizeDateTime(TargetDate);
    return UIAQuery.contains( "%0 %1".format(this.MONTHS[TargetDate.getMonth()], TargetDate.getFullYear()) ).isVisible();
}

/**
 * Builds a query to a date element in the calendar month view
 *
 * @param {Date} TargetDate     - Date containing the target date + month
 *
 * @returns {UIAQuery}    Returns query to the target date element
 */
calendar._targetDateElement = function _targetDateElement(TargetDate) {
    TargetDate = this._sanitizeDateTime(TargetDate);

    var dateQuery = UIAQuery.endsWith("%0 %1".format(this.MONTHS[TargetDate.getMonth()], TargetDate.getDate()));
    if (this.inspect( UIAQuery.Calendar.COMPACT_MONTH_WEEK_VIEW )) {
        return UIAQuery.buttons().andThen(dateQuery);
    } else {
        return UIAQuery.scrollViews().andThen(UIAQuery.staticTexts().isVisible().andThen(dateQuery));
    }
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Navigation to event                              */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for navigating to specific events on the calendar                      */
/*                                                                             */
/*******************************************************************************/

/**
 * Change the current Month or Day view to Month-List or Day-List view, respectively.
 * Assumes we are in the Month or Day view
 *
 * @param {bool}    ToListView            - Set to list view or normal view
 *
 * @throws If list view button is not found (i.e. device class does not support list view)
 */
calendar._setToListView = function _setToListView(ToListView) {
    if (this.exists(UIAQuery.Calendar.LIST_BUTTON)) {
        if (Boolean(Number(this.inspect(UIAQuery.Calendar.LIST_BUTTON).isSelected)) === Boolean(ToListView)) {
            UIALogger.logMessage("List view is already set to %0".format(ToListView));
        } else {
            this.tap(UIAQuery.Calendar.LIST_BUTTON);
        }
    } else {
        throw new UIAError("List Button not found; this device may not support it (iPad-class device)!", {identifier:"List button not found"});
    }
}

/**
 * Exit from an event details view to Calendar/Inbox/List.
 * Assumes we are in the event details view
 */
calendar._exitEventDetailsView = function _exitEventDetailsView() {
    currentState = this.currentUIState();

    switch (currentState) {
        case UIStateDescription.Calendar.EVENT_DETAILS:
            this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);  // Need to tap back to get to * view for iPhones
            break;
        // If we're already out of all auxillary states, we will fall through
        default:
            break;
    }

    this.dismissPopover();                                    // Need to dismiss popover on iPads (won't throw exception if there are no popovers, just returns FALSE)
}

/**
 * Verify that either at least one element satisfies the query, or NO element satisfies the given query.
 * Assumes we are in the event details view
 *
 * @param {string}  PredicateString                 - Predicate string to match an event property by (i.e. "name CONTAINS 'Repeats Weekly'")
 * @param {bool}    ExpectPredicateToFindMatch      - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
 * @param {bool}    ReturnBool                      - Have the method return a false if the predicate does not match, else throw a UIAError
 * @param {string}  IdentifierString                - string to add to the UIAError identifier if a UIAError is thrown from the method
 *
 * @throws If match failed and ReturnBool is false
 */
calendar._verifyEventDetailsViewPredicate = function _verifyEventDetailsViewPredicate(PredicateString, ExpectPredicateToFindMatch) {
    if (PredicateString) {
        ExpectPredicateToFindMatch = (ExpectPredicateToFindMatch === undefined) ? true : Boolean(ExpectPredicateToFindMatch);
        // there may be a delay during rendering event details container
        this.waitUntilPresent(UIAQuery.Calendar.EVENT_DETAILS_CONTAINER, 10);
        matchExists = this.exists( UIAQuery.Calendar.EVENT_DETAILS_CONTAINER.andThen(UIAQuery.withPredicate(PredicateString)) );
        if ((ExpectPredicateToFindMatch && !matchExists) || (!ExpectPredicateToFindMatch && matchExists)) {
            UIALogger.logError("Event does not match predicate: '%0' with ExpectPredicateToFindMatch = %1".format(PredicateString, ExpectPredicateToFindMatch));
            return false;
        }
    } return true;
}

/**
 * For each event that satisfied the query, tap into it, and check for predicate match/no-match.  If the event details match what we want, then return the index of the matched event (or -1 if no such event is found).
 * Assumes we are in a view where event elements are accessible (i.e. List view, Search view, Day view, Week view, Month view)
 *
 * @param {string}      EventQuery                          - Query for the potentially-matching events
 * @param {bool}        PredicateString                     - Predicate string to match an event property by (i.e. "name CONTAINS 'Repeats Weekly'")
 * @param {bool}        ExpectPredicateToFindMatch          - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
 * @param {function}    GetBackToStartingPointFunction      - On iPads (Calendar -> Inbox -> Event -> (exit event view) -> Calendar), exiting an event-details view does not land back into the previous view.  Providing this tells method how to get back to the starting point
 *
 * @returns {number}    Index of EventQuery that matches event (or -1 if none found)
 */
calendar._indexOfEventMatchingPredicate = function _indexOfEventMatchingPredicate(EventQuery, PredicateString, ExpectPredicateToFindMatch, GetBackToStartingPointFunction) {
    var matchingCount = this.count(EventQuery);
    for (var i=0; i < matchingCount; i++) {
        this.tap( EventQuery.atIndex(i) );
        if (this._verifyEventDetailsViewPredicate(PredicateString, ExpectPredicateToFindMatch)) {
            UIALogger.logMessage("Event matches predicate '%0' with ExpectPredicateToFindMatch = %1!  Skipping predicate-matching on the rest of the events, if any".format(PredicateString, ExpectPredicateToFindMatch));
            return i; // Returns the index at which the event query matched the predicate
        }

        this._exitEventDetailsView();
        if (GetBackToStartingPointFunction) GetBackToStartingPointFunction();
    }
    return -1;
}

/**
 * Search for event in a given view; cycle through multiple events matching the given query by tapping, then matching upon the given predicate
 *
 * @param {object} SearchOptions - SearchOptions struct
 * @param {string}          SearchOptions.ViewString                                    - Name of view to cycle predicate-matching through candidate events (for logging purposes)
 * @param {string}          SearchOptions.Title                                         - Title of event
 * @param {UIAQuery}        SearchOptions.EventQuery                                    - Query for the potentially-matching events
 * @param {string}          SearchOptions.PredicateString                               - Predicate string to match an event property by (i.e. "name CONTAINS 'Repeats Weekly'")
 * @param {string}          SearchOptions.ExpectPredicateToFindMatch                    - Expect the predicate to return results (set to false to check that NO such UI element matches the predicate query)
 * @param {function}        [SearchOptions.GetBackToStartingPointFunction=undefined]    - On iPads (Calendar -> Inbox -> Event -> (exit event view) -> Calendar), exiting an event-details view does not land back into the previous view.  Providing this tells method how to get back to the starting point
 * @param {bool}            [SearchOptions.GoBackToViewAfterSearch=false]               - Go back to the starting point after search (applicably only to nagivating to inbox for responding to events from inbox view)
 * @param {bool}            [SearchOptions.DontThrow=false]                             - Specify whether to throw if event is not found
 *
 * @returns {number}    Returns Index of EventQuery that matches event when SearchOptions.DontThrow is true (or -1 if none found)
 * @throws If event cannot be found and DontThrow is false
 */
calendar._cycleThroughPotentialEventMatches = function _cycleThroughPotentialEventMatches(SearchOptions) {
    var ViewString                      = SearchOptions.ViewString;
    var Title                           = SearchOptions.Title;
    var EventQuery                      = SearchOptions.EventQuery;
    var PredicateString                 = SearchOptions.PredicateString;
    var ExpectPredicateToFindMatch      = SearchOptions.ExpectPredicateToFindMatch;
    var GetBackToStartingPointFunction  = SearchOptions.GoBackViewFn;
    var GoBackToViewAfterSearch         = SearchOptions.GoBackToViewAfterSearch;
    var DontThrow                       = SearchOptions.DontThrow;

    var indexOfMatchingEvent = undefined;
    var numberOfMatches = this.count(EventQuery);
    var eventFound = this.exists(EventQuery);

    // If there are no event matches, throw (or return -1 if DontThrow flag is set to true)
    if (numberOfMatches < 1 && !eventFound) {
        if (DontThrow) return -1;
        throw new UIAError("Didn't find the target event with title: '%0'".format(Title), {identifier:"Didn't find the target event in %0 matching title".format(ViewString)});

    // If there is exactly one match, tap to event and verify predicate; throw if predicate verification fails (or return -1 if DontThrow flag is set to true)
    } else if (eventFound && numberOfMatches < 2) {
        UIALogger.logMessage("Found one match on title");

        // Tap into the one event, and verify the predicate if exists; else throw (or return -1 if DontThrow flag is set to true)
        if (!this.exists(UIAQuery.Calendar.EVENT_DETAILS_CONTAINER)) {
            // FIXME: <rdar://problem/27163528> Calendar events aren't pulling up detail panel if they are too low when tapped on
            // We grab the bottom edge of the event if we are in the top half of the app, otherwise we grab the top of the
            //   event if it's on the bottom half.
            // Lastly, the drag from the bottom works everytime, but the drag from the top may not pull an event onto the
            //   screen if it is too far from the top and may take multiple drags.
            var appCenterY = this.inspect(UIAQuery.application()).center.y
            var yCoordinate = (this.inspect(EventQuery).center.y < appCenterY / 2) ? 0.99 : 0.01;

            this.drag(EventQuery, {fromOffset: {x: 0.5, y: yCoordinate}, toQuery: UIAQuery.application(), toOffset: {x: 0.5, y: 0.5}, duration: 0.5});
            this.tap(EventQuery);
        }
        if (! this._verifyEventDetailsViewPredicate(PredicateString, ExpectPredicateToFindMatch)) {
            this._exitEventDetailsView();
            if (DontThrow) return -1;
            else throw new UIAError("Only one event with title: '%0' was found, but did not match the predicate: '%1' (with ExpectPredicateToFindMatch = %2)".format(Title, PredicateString, ExpectPredicateToFindMatch), {identifier:"Didn't find the target event in %0 matching predicate".format(ViewString)});
        }

        indexOfMatchingEvent = 0;

    // If there are multiple matches and no predicate was provided, throw, since the search was not specific enough (or return -1 if DontThrow flag is set to true)
    } else if (! PredicateString) {
        if (DontThrow) return -1;
        else throw new UIAError("Search was not specific enough; %0 event(s) found in %1 with title '%2'; please provide a PredicateString to narrow the search!".format(numberOfMatches, ViewString, Title), {identifier:"More than one event found in %0 matching title".format(ViewString)});

    // If a predicate was provided, cycle through tapping each potentially matching event and verifying the predicate - returns the matching event's query index or -1 if no match was found
    } else if ((indexOfMatchingEvent = this._indexOfEventMatchingPredicate(EventQuery, PredicateString, ExpectPredicateToFindMatch, GetBackToStartingPointFunction)) >= 0) {
        // continue to end of method

    // Else, we didn't find a matching event, so throw (or return -1 if DontThrow flag is set to true)
    } else {
        if (DontThrow) return -1;
        else throw new UIAError("Didn't find the target event in %0 with title '%1' and matching predicate: '%2' (with ExpectPredicateToFindMatch = %3)".format(ViewString, Title, PredicateString, ExpectPredicateToFindMatch), {identifier:"Didn't find the target event in %0 matching predicate".format(ViewString)});
    }

    // Get back to starting point if needed
    if (GoBackToViewAfterSearch) {
        UIALogger.logMessage("Going back to %0 from event details view first".format(ViewString));
        GetBackToStartingPointFunction();
    }

    // Index of EventQuery that matches event (or -1 if none found)
    return indexOfMatchingEvent;
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Responding to Invites                            */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for responding to event invites                                        */
/*                                                                             */
/*******************************************************************************/

/**
 * Respond to invite.  This assumes we are on the event's details view
 *
 * @param {enum}    Response                - Invite response (enum calendar.INVITE_RESPONSE_VALUES)
 * @param {bool}    [AcceptAll=false]       - Accept all occurrences of the event invite
 * @param {bool}    [Private=null]          - Set event to private (Not available in all calendars)
 * @param {enum}    [ShowAs=""]             - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
 * @param {string}  [ReplyComment=""]       - Comment to input when responding to invites
 * @param {string}  [Alert=null]            - Alert for event
 *
 * @throws If unable to respond to invite
 */
calendar._respondToInvite_DetailsView = function _respondToInvite_DetailsView(Response, AcceptAll, ShowAs, Private, ReplyComment, Alert) {
    Response = this._sanitizeInviteResponse(Response);
    var responseButton = (Response === this.INVITE_RESPONSE_VALUES.ACCEPT) ? UIAQuery.Calendar.ACCEPT_BUTTON :
                         (Response === this.INVITE_RESPONSE_VALUES.MAYBE)  ? UIAQuery.Calendar.MAYBE_BUTTON  :  UIAQuery.Calendar.DECLINE_BUTTON;

    // Set an alert for the event, if given one
    this._setEventAlert(UIAQuery.Calendar.EVENT_DETAILS_ALERT, UIAQuery.Calendar.EVENT_DETAILS_ALERT_VALUE, Alert);

    // Set the user's availability status at time of event
    if (ShowAs) {
        this.tap( UIAQuery.Calendar.EVENT_DETAILS_SHOW_AS );
        this.tap( ShowAs );
    }

    // Set the event view to private
    if (Private !== undefined) {
        this.setControl(UIAQuery.Calendar.EVENT_DETAILS_PRIVATE, Boolean(Private));
    }

    // Add a reply comment if neccessary
    if (ReplyComment) this._enterTextAndDismiss(UIAQuery.Calendar.EVENT_DETAILS_REPLY_COMMENT, ReplyComment)

    // If the response has already been highlighted, then tapping on it will not exit event details view
    if (this.inspect(responseButton).isSelected) {
        UIALogger.logWarning("Response has already been set to '%0'!".format(Response));
        return;
    }

    this.tap(responseButton);
    var acceptResponse = AcceptAll ? UIAQuery.Calendar.APPLY_TO_ALL_FUTURE_BUTTON : UIAQuery.Calendar.APPLY_TO_ONE_BUTTON;
    this._tapIfExists(acceptResponse, 3);
    this._ensureCurrentViewIsNot( UIStateDescription.Calendar.EVENT_DETAILS );
}

/**
 * Respond to invite.  This assumes we are on the inbox view
 *
 * @param {UIAQuery}    InboxItemQuery              - Query to the element in Inbox to tap
 * @param {enum}        Response                    - Invite response (enum calendar.INVITE_RESPONSE_VALUES)
 * @param {bool}        [AcceptAll=false]           - Accept all occurrences of the event invite
 * @param {string}      [ReplyComment=""]           - Comment to input when responding to invites (as declined)
 *
 * @throws If unable to respond to invite
 */
calendar._respondToInvite_InboxView = function _respondToInvite_InboxView(InboxItemQuery, Response, AcceptAll, ReplyComment) {
    Response = this._sanitizeInviteResponse(Response);
    this.tap(InboxItemQuery.andThen(Response));

    var replyCommentField = InboxItemQuery.andThen(UIAQuery.textFields());
    if (Response === this.INVITE_RESPONSE_VALUES.DECLINE && ReplyComment && this.exists(replyCommentField)) {
        this._enterTextAndDismiss(replyCommentField, ReplyComment);
    }

    this._tapIfExists( AcceptAll ? UIAQuery.Calendar.APPLY_TO_ALL_FUTURE_BUTTON : UIAQuery.Calendar.APPLY_TO_ONE_BUTTON, 2 );
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Managing Calendars                               */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for managing calendars                                                 */
/*                                                                             */
/*******************************************************************************/

/**
 * Builds a query to a table element under a subsection
 *
 * @param {UIAQuery}    SectionHeaderQuery           - Query to the table's section header
 * @param {string}      SectionHeaderName            - Name of the section header
 * @param {string}      TargetElementName            - Name of the table element below the section header
 * @param {bool}        SearchByContainsInstead      - Search for table element by UIAQuery.contains() instead of by exact string matching
 *
 * @returns {UIAQuery}    Returns query to a table element under a subsection
 */
calendar._sectionSubElementQuery = function _sectionSubElementQuery(SectionHeaderQuery, SectionHeaderName, TargetElementName, SearchByContainsInstead) {
    var specificGroupSection = SectionHeaderQuery.andThen(UIAQuery.contains(SectionHeaderName)).parent();
    var lastSectionHeaderName = this.inspectAll( SectionHeaderQuery.andThen(UIAQuery.withPredicate('TRUEPREDICATE')) ).map(function (n) { return n.name; }).pop();

    var baseQuery = SearchByContainsInstead ? UIAQuery.staticTexts().contains(TargetElementName).below(specificGroupSection) :
                                              UIAQuery.staticTexts(TargetElementName).below(specificGroupSection);
    if (lastSectionHeaderName === SectionHeaderName) {
        return baseQuery.parent();  // the q.above(p) fails when there's nothing below q
    } else {
        return baseQuery.above(SectionHeaderQuery).parent();
    }
}

/**
 * Builds a query to get to the calendar with the specified CalendarGroup and CalendarName
 *
 * @param {string}  CalendarGroup                       - Name of the calendar group that the calendar is in
 * @param {string}  CalendarName                        - Name of the calendar
 * @param {bool}    [SearchByContainsInstead=false]     - Search for the calendar name using UIAQuery.contains() instead of by exact string matching
 *
 * @returns {UIAQuery}    Returns query to the calendar with the specified CalendarGroup and CalendarName
 */
calendar._specificCalendarQuery = function _specificCalendarQuery(CalendarGroup, CalendarName, SearchByContainsInstead) {
    if (CalendarGroup) {
        SearchByContainsInstead = (SearchByContainsInstead === undefined || SearchByContainsInstead === null) ? false : Boolean(SearchByContainsInstead);
        return this._sectionSubElementQuery(UIAQuery.Calendar.CALENDAR_GROUP_SECTION, String(CalendarGroup), String(CalendarName), SearchByContainsInstead);
    } else {
        return UIAQuery.Calendar.CALENDAR_LIST_ENTRIES.andThen(UIAQuery.staticTexts(CalendarName)).parent();
    }
}

/**
 * Checks that a calendar with specified CalendarGroup and CalendarName exists.
 * Assumes device is currently in a view that lists calendars (i.e. Add Event->Calendar or Edit Calendars)
 *
 * @param {string}  CalendarGroup                   - Name of the calendar group that the calendar is in
 * @param {string}  CalendarName                    - Name of the calendar
 * @param {bool}    [ExpectCalendarToExist=true]    - If set to true, will throw when calendar is found; else will throw if calendar is NOT found
 *
 * @throws If the calendar does/does not exist, depending on the ExpectCalendarToExist flag
 */
calendar._verifyCalendarExistence = function _verifyCalendarExistence(CalendarGroup, CalendarName, ExpectCalendarToExist) {
    ExpectCalendarToExist = (ExpectCalendarToExist === undefined || ExpectCalendarToExist === null) ? true : Boolean(ExpectCalendarToExist);
    var calendarCell = this._specificCalendarQuery(CalendarGroup, CalendarName);
    var calendarCount = this.count(calendarCell);
    if (ExpectCalendarToExist) {
        if (calendarCount < 1) {
            throw new UIAError("Could not find calendar '%0' under group '%1'!".format(CalendarName, CalendarGroup), {identifier:"Calendar not found"});
        } else if (calendarCount > 1) {
            throw new UIAError("More than one calendar found with name '%0' under greoup '%1'; please narrow search if group not provided!".format(CalendarName, CalendarGroup), {identifier:"More than one calendar found"});
        }
    } else {
        if (calendarCount > 0) {
            throw new UIAError("Calendar '%0' under group '%1' exists!".format(CalendarName, CalendarGroup), {identifier:"Matching calendar exists"});
        }
    }
}

/**
 * Get to the calendar edit view for a specific calendar.
 *
 * @param {string} CalendarGroup    - Name of the calendar group that the calendar is in
 * @param {string} CalendarName     - Name of the calendar
 *
 * @throws If the calendar is not found
 */
calendar._getToCalendarEdit = function _getToCalendarEdit(CalendarGroup, CalendarName) {
    this.verifyCalendarExists(CalendarGroup, CalendarName);
    this.tap( this._specificCalendarQuery(CalendarGroup, CalendarName).andThen(UIAQuery.contains('More Info')) );
}

/**
 * Shows or hides the events of a specific calendar.  Assumes calendar exists
 *
 * @param {string} CalendarGroup    - Name of the calendar group that the calendar is in
 * @param {string} CalendarName     - Name of the calendar
 * @param {bool}   Visibility       - true if the calendar is to be hidden, else false
 *
 * @throws If the calendar is not found or if the calendar's visibility could be set
 */
calendar._setCalendarToVisible = function _setCalendarToVisible(CalendarGroup, CalendarName, Visibility) {
    var calendarCell = this._specificCalendarQuery(CalendarGroup, CalendarName);
    if (Boolean( this.inspect(calendarCell).isSelected ) === Boolean(Visibility)) {   // The isSelected attribute returns a number
        UIALogger.logMessage("The '%0' calendar is already set to visibility '%1'!".format(CalendarName, Visibility));
        return;
    } else {
        this.tap(calendarCell);
    }
}

/**
 * Set the properties of a calendar in Calendar Edit View
 *
 * @param {object} options - Options dictionary
 * @param {string}          [options.CalendarName="SAMPLE NAME"]    - Calendar name
 * @param {string[]}        [options.SharedWith=[]]                 - List of contacts to share calendar with (Not available in all calendars)
 * @param {bool}            [options.ShowSharedEventChanges=null]   - Enable notifications when other people add/edit/delete events in shared calendar
 * @param {string}          [options.Color=null]                    - Calendar color
 * @param {bool}            [options.CalendarIsPublic=null]         - Set calendar to be public (Not available in all calendars)
 * @param {string}          [options.ShareLink=null]                - Share link to public calendar (Not available in all calendars)
 * @param {bool}            [options.Notifications=null]            - Enable event notifications (i.e. Exchange; Not available in all calendars)
 *
 * @throws If unable edit calendar
 */
calendar._setCalendarOptions = function _setCalendarOptions(options) {
    if (options.CalendarName) {
        try {
            UIALogger.logMessage("(Re)naming calendar to '%0'".format(options.CalendarName));
            this._enterTextAndDismiss(UIAQuery.query("UITextField"), options.CalendarName);
        } catch (e) {
            throw new UIAError("Caught an exception while trying to edit calendar name: %0; perhaps the calendar's name is not editable (Exchange calendar)?".format(e.message), {identifier:'Could not edit Calendar Name'});
        }
    }

    if (options.SharedWith && options.SharedWith.length > 0) {
        // Remove all previous SharedWith recipients
        while (this.exists(UIAQuery.Calendar.EDIT_CALENDAR_SHAREDWITH_ENTRY)) {
            this.tap(UIAQuery.Calendar.EDIT_CALENDAR_SHAREDWITH_ENTRY);
            this.tap(UIAQuery.Calendar.EDIT_CALENDAR_SHAREDWITH_STOPSHARING);
            this.tap(UIAQuery.Calendar.REMOVE_BUTTON);
        }

        var addPersonCell = this._specificCalendarQuery("Shared with:", "Add Person\u2026");
        if (! this.exists(addPersonCell)) throw new UIAError('Shared with: field not found; this calendar probably cannot be shared', {identifier:'Cannot share calendar'});
        this.tap(addPersonCell)

        this._enterTextAndDismiss(UIAQuery.Calendar.RECIPIENTS_TEXTFIELD, options.SharedWith.join('\n') + '\n');
        this.tap(UIAQuery.Calendar.ADD_BUTTON);
    }

    if (options.ShowSharedEventChanges !== undefined && options.ShowSharedEventChanges !== null) {
        if (! this.exists(UIAQuery.Calendar.CALENDAR_SHOW_SHAREDEVENT_CHANGES_SWITCH)) {
            throw new UIAError('Show Shared Event Changes switch not found; calendar must be saved with a calendar-sharing recipient first before this field will appear!', {identifier:'Show Shared Event Changes switch not found'});
        } else {
            this.setControl(UIAQuery.Calendar.CALENDAR_SHOW_SHAREDEVENT_CHANGES_SWITCH, Boolean(options.ShowSharedEventChanges));
        }
    }

    if (options.Color) {
        options.Color = options.Color.capitalize();
        UIALogger.logMessage("Setting calendar color to '%0'".format(options.Color));

        var colorSection = UIAQuery.Calendar.CALENDAR_GROUP_SECTION.andThen("Color");
        var colorCell = UIAQuery.query(options.Color).below(colorSection).above(UIAQuery.Calendar.CALENDAR_GROUP_SECTION);
        if (! this.exists(colorCell)) throw new UIAError("Color '%0' does not exist!".format(options.Color), {identifier:'Color does not exist'});

        this.tap(colorCell);
    }

    if (options.CalendarIsPublic !== undefined && options.CalendarIsPublic !== null) {
        if (! this.exists(UIAQuery.Calendar.EDIT_CALENDAR_PUBLIC_SWITCH)) {
            UIALogger.logWarning("The Public switch was not found; skipping!");
        } else {
            this.setControl(UIAQuery.Calendar.EDIT_CALENDAR_PUBLIC_SWITCH, Boolean(options.CalendarIsPublic));
        }
    }

    if (options.ShareLink) {
        // FIX ME: Not yet implemented
    }

    if (options.Notifications !== undefined && options.Notifications !== null) {
        if (! this.exists(UIAQuery.Calendar.CALENDAR_NOTIFICATIONS_SWITCH)) {
            UIALogger.logWarning("The Event Alerts switch was not found; skipping!");
        } else {
            this.setControl(UIAQuery.Calendar.CALENDAR_NOTIFICATIONS_SWITCH, Boolean(options.Notifications));
        }
    }

    this.tap(UIAQuery.DONE_BUTTON);
    this._tapIfExists(UIAQuery.CANCEL_BUTTON, 2);  // If no changes were made, then the Done Button is greyed out, so we need to tap the cancel button
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Internal Methods - Editing and Verifying Events                     */
/*                                                                             */
/*      These methods are used to implement the public API                     */
/*      for editing and verifying event properties                             */
/*                                                                             */
/*******************************************************************************/

/**
 * Validate fields of a calendar event.
 * This method only works for the detail views of events created by the device; a new set of queries and extraction functions are needed for detail views of event invites!
 *
 * @param {object} FieldsToTest      - A struct containing the same fields as the options argument for calendar._setEventOptions()
 *
 * @throws If validation of calendar event fields fails
 */
calendar._validateEventFields = function _validateEventFields(FieldsToTest) {
    /**
    * Omit hostname (if any) and gets username part only to simplify further verification.
    * Some invitee emails may come with @hostname part depending on Exchange server version.
    *
    * @param {string} value - invitee email.
    * @returns {string} - username part of invitee email.
    */
    function omitHostName(value) {
        return value.split('@')[0].trim();
    }

    /**
    * Gets actual number of invitees ignoring optional scheduling conflict elements.
    */
    function getInviteesCount() {
        var entriesNum = calendar.count(UIAQuery.Calendar.EDIT_EVENT_INVITEE_ENTRIES);
        for (var i = 0; i < entriesNum; i++) {
            var currentEntry = UIAQuery.Calendar.EDIT_EVENT_INVITEE_ENTRIES.atIndex(i)
                .andThen(UIAQuery.staticTexts());
            var currentText = calendar.inspectElementKey(currentEntry, 'name');

            if (currentText.toLowerCase() === 'scheduling conflict') {
                // all further elements are alternative schedule options, ignore them.
                return i;
            }
        }
        return entriesNum;
    }

    var compareTwoValues = function(fieldName, expectedValue, actualValue) {
        var header = "Comparing %0...".format(fieldName);

        // Convert Date and Array objects to values comparable using the === operator
        var tmpExpectedValue = (expectedValue instanceof Date) ? expectedValue.getTime() :
                               (expectedValue instanceof Array) ? JSON.stringify(expectedValue.sort()) : expectedValue;
        var tmpActualValue   = (actualValue instanceof Date) ? actualValue.getTime() :
                               (actualValue instanceof Array) ? JSON.stringify(actualValue.sort()) : actualValue;

        if (tmpExpectedValue === tmpActualValue) {
            UIALogger.logMessage("%0 PASSED".format(header));
            return true;
        } else {
            UIALogger.logMessage("%0 FAILED [expected '%1' but got '%2' instead!]".format( header, String(expectedValue), String(actualValue) ));
            return false;
        }
    };

    // This table lists all the functions on grabbing the field values properly from the event details view
    var valueExtractionFunctionsTable = {
        Title:                      function () { return this.inspect( UIAQuery.Calendar.EDIT_EVENT_TITLE ).value },
        Location:                   function () { return this.inspect( UIAQuery.Calendar.EDIT_EVENT_LOCATION ).name; },
        AllDay:                     function () {
            if (!this.exists(UIAQuery.Calendar.EDIT_EVENT_ALLDAY)) {
                return false; // default test args value
            }
            return this._switchVal(UIAQuery.Calendar.EDIT_EVENT_ALLDAY);
        },
        Repeat:                     function () { return this.inspect(UIAQuery.Calendar.EDIT_EVENT_REPEAT_VALUE).name; },
        Alert:                      function () { return this.inspect(UIAQuery.Calendar.EDIT_EVENT_ALERT_VALUE).name; },
        ShowAs:                     function () { return this.inspect(UIAQuery.Calendar.EDIT_EVENT_SHOW_AS_VALUE).name; },
        Url:                        function () { return this.inspect( UIAQuery.Calendar.EDIT_EVENT_URL ).value; },
        Notes:                      function () { return this.inspect( UIAQuery.Calendar.EDIT_EVENT_NOTES ).value; },
        Private:                    function () {
            if (! this.exists(UIAQuery.Calendar.EDIT_EVENT_PRIVATE) ) { return false; }
            return this._switchVal( UIAQuery.Calendar.EDIT_EVENT_PRIVATE );
        },

        StartDate:                  function () { return new Date( this.inspect(UIAQuery.Calendar.EDIT_EVENT_START_VALUE).name ); },
        EndDate:                    function () {
            // For events that last within the range of a single day, the EndDate appears in time format only (i.e. "3:00 PM") in the UI
            // This will check for that formatting, and return the StartDate of the event with the hours and minutes changed into the time of the EndDate
            var timeStr = this.inspect(UIAQuery.Calendar.EDIT_EVENT_END_VALUE).name;
            if ( timeStr.match(/^(\d+)(:(\d\d))?\s*((a|(p))m?)?$/i) ) {
                var startDate = new Date( this.inspect(UIAQuery.Calendar.EDIT_EVENT_START_VALUE).name );
                return Date.parseTime(timeStr, startDate); // Date.parseTime is a Date extention method defined in UIAUtility.js

            } else {
                return new Date(timeStr);
            }
        },
        RepeatEnd:                  function () { return new Date( calendar.inspect(UIAQuery.Calendar.EDIT_EVENT_REPEAT_END_VALUE).name ); },

        /** Not implemented yet */
        Calendar:                   function () { return null; },
        Invitees:                   function () {
            if (! this.exists(UIAQuery.Calendar.EDIT_EVENT_INVITEES)) {
                UIALogger.logMessage("Invitees cell does not exist - this is the case when the event belongs to a local (non-iCloud and non-Exchange) calendar");
                return [];

            } else if ( this.inspect( UIAQuery.Calendar.EDIT_EVENT_INVITEES_VALUE ).name === "None") {
                UIALogger.logMessage("Invitees value cell is 'None'; looks like there are no invitees");
                return [];
            }

            var invitees = [];
            this.tap(UIAQuery.Calendar.EDIT_EVENT_INVITEES);
            var inviteesNum = getInviteesCount();
            UIALogger.logMessage('Total number of invitees: %0\n'.format(inviteesNum));

            for (var i = 0; i < inviteesNum; i++) {
                this.tap(UIAQuery.Calendar.EDIT_EVENT_INVITEE_ENTRIES.atIndex(i));
                this.waitUntilPresent(UIAQuery.Calendar.EDIT_EVENT_INVITEE_EMAIL_ENTRY, 10);
                var email = this.inspect(UIAQuery.Calendar.EDIT_EVENT_INVITEE_EMAIL_ENTRY).name;
                invitees.push(email);

                this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Invitees')));
            }

            this.tap(UIAQuery.CANCEL_BUTTON.isVisible().orElse(UIAQuery.Calendar.VISIBLE_BACK_BUTTON));
            return invitees.map(omitHostName);
        },
    };

    // This table lists all the functions on cleaning up the expected values for minor mismatches against the values parsed from the UI
    var expectedValuesCleanupFunctionsTable = {
        StartDate:      function (FieldsToTest) {
            if (FieldsToTest.StartDate) {
                if (valueExtractionFunctionsTable.AllDay.apply(this)) { FieldsToTest.StartDate.setHours(0,0,0,0); }
                else { FieldsToTest.StartDate.setSeconds(0,0); }
            }
        },
        EndDate:        function (FieldsToTest) {
            if (FieldsToTest.EndDate) {
                if (valueExtractionFunctionsTable.AllDay.apply(this)) { FieldsToTest.EndDate.setHours(0,0,0,0); }
            }
        },
        RepeatEndDate:  function (FieldsToTest) {
            if (FieldsToTest.RepeatEndDate) { FieldsToTest.RepeatEndDate.setSeconds(0, 0); }
        },
        Invitees:       function(FieldsToTest) {
            if (FieldsToTest.Invitees) {
                FieldsToTest.Invitees = FieldsToTest.Invitees.map(omitHostName);
            }
        },
        Repeat:         function(FieldsToTest) {
            // Mapping between possible input values and their actual UI representation.
            var repeatIntervalsMapping = {
                DAILY: 'Daily',
                'Daily': 'Daily',
                WEEKLY: 'Weekly',
                'Weekly': 'Weekly',
                BIWEEKLY: 'Biweekly',
                'Biweekly': 'Biweekly',
                MONTHLY: 'Monthly',
                'Monthly': 'Monthly',
                YEARLY: 'Yearly',
                'Yearly': 'Yearly'
            };
            if (FieldsToTest.Repeat && repeatIntervalsMapping.hasOwnProperty(FieldsToTest.Repeat)) {
                FieldsToTest.Repeat = repeatIntervalsMapping[FieldsToTest.Repeat];
            }
        }
    };

    UIALogger.logMessage("Validating event details against the following expected fields:\n\n%0\n".format(JSON.stringify(FieldsToTest)));

    var mismatchingFields = [];
    for (var field in FieldsToTest) {
        // if (["CalendarName",].contains(field) && FieldsToTest[field] === null) { continue; }
        UIALogger.logMessage('Processing %0 field...'.format(field));
        if (! FieldsToTest.hasOwnProperty(field)) { continue; }
        if (! valueExtractionFunctionsTable.hasOwnProperty(field) ) {
            throw new UIAError("No extraction function defined yet for %0".format(field), {identifier:"No value extraction method defined"});
        }

        // First, look up the function for extracting the field value from the UI view, and attempt to run it
        try {
            var testValue = valueExtractionFunctionsTable[field].apply(this);
        } catch(e) {
            UIALogger.logWarning("Failed to extract the %0 field! --> %1".format(field, e.message));
            mismatchingFields.push(field);
            continue;
        }

        // Then, look up the function for cleaning the expected field for minor data mismatches against the actual value parsed from the UI, and run it
        if (expectedValuesCleanupFunctionsTable.hasOwnProperty(field)) {
            expectedValuesCleanupFunctionsTable[field].apply(this, [FieldsToTest]);
        }

        // Run the actual comparison
        if (!compareTwoValues(field, FieldsToTest[field], testValue)) {
            mismatchingFields.push(field);
        }
    }

    if (mismatchingFields.length > 0) {
        throw new UIAError("Calendar event values mismatch in the following fields: %0".format(JSON.stringify(mismatchingFields)), {identifier:"Calendar event verification failed"});
    } else {
        UIALogger.logMessage("Calendar event verification passed!");
    }
}

/**
 * Validate calendar event fields on an invitee's device.
 * This method should be used for verification on event detail view of invitee,
 * and not on edit view of originator.
 *
 * @param {object} FieldsToTest - A structure containing the same fields as the options argument for calendar._setEventOptions().
 *
 * @throws - If validation of calendar event fields fails.
 */
calendar._validateEventFieldsInviteeView = function _validateEventFieldsInviteeView(FieldsToTest) {
    /**
    * Parse event header and extract field values encapsulated in it.
    * Event header contains title, optionally location, start and end date and time (or All Day flag),
    * and optionally repeat interval.
    *
    * There are 3 properties defining structure of possible event header:
    * 1) single or multi day event;
    * 2) timed or all day event;
    * 3) recurring or non-recurring event.
    *
    * So there are 8 possible combinations for calendar event header and each of them has its own template.
    * There are 8 regex defined to match each of possible combinations.
    *
    * Header samples:
    * 'Auto test, Saturday, Jan 21, 2017, All day',
    * 'Auto test, Hollywood, Friday, Jan 20, 2017, 3:30 PM to 4 PM',
    * 'Auto test, Friday, Jan 20, 2017, All day, repeats every 2 weeks',
    * 'Auto test, Shoreline, All day from Sun, Aug 21, 2016, to Wed, Aug 24, 2016',
    * 'Auto test, from 4 PM Sun, Aug 28, 2016, to 5 PM Wed, Aug 31, 2016, repeats weekly'.
    *
    * @param {string} header - Event header.
    *
    * @returns {Object} - object with event fields mapped to extracted values.
    */
    function parse(header) {
        var year = '(\\d{4})';
        var date = '(\\d{1,2})';
        var month = '(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)';
        var shortDay = '(Mon|Tue|Wed|Thu|Fri|Sat|Sun)';
        var longDay = '(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)';
        var time = '(\\d{1,2}(?:\\:\\d{2})? (?:AM|PM))';
        var titleAndLocation = '(.*)';
        var repeatInterval = '(repeats .*)';

        var fromOrToDateAndTime = `${time} ${shortDay}, ${month} ${date}, ${year}`;
        var fromOrToDate = `${shortDay}, ${month} ${date}, ${year}`;

        // Even though using format() is a preferred concatenation mechanism,
        // using back quotes in regex below makes the definition more readable.

        // Some event, Saturday, Jan 21, 2017, All day
        var singleAllDay = `^${titleAndLocation}, ${longDay}, ${month} ${date}, ${year}, All day$`;

        // Auto test, Friday, Jan 20, 2017, 3 PM to 4 PM
        var singleDayTimed = `^${titleAndLocation}, ${longDay}, ${month} ${date}, ${year},(?: from)? ${time} to ${time}$`;

        // Test, Sunday, Aug 28, 2016, All day, repeats weekly
        var singleAllDayRecurring = `^${titleAndLocation}, ${longDay}, ${month} ${date}, ${year}, All day, ${repeatInterval}$`;

        // Test, Sunday, Aug 28, 2016, 4 PM to 5 PM, repeats weekly !
        var singleDayTimedRecurring = `^${titleAndLocation}, ${longDay}, ${month} ${date}, ${year},(?: from)? ${time} to ${time}, ${repeatInterval}$`;

        // Multi all day, Shoreline, All day from Sun, Aug 21, 2016, to Wed, Aug 24, 2016
        var multiAllDay = `^${titleAndLocation}, All day(?: from)? ${fromOrToDate}, to ${fromOrToDate}$`;

        // Auto Title, Shoreline, from 10:15 AM Thu, Mar 2, 2017, to 11:15 AM Sun, Mar 5, 2017
        var multiDayTimed = `^${titleAndLocation},(?: from)? ${fromOrToDateAndTime}, to ${fromOrToDateAndTime}$`;

        // Multi all day, Shoreline, All day from Sun, Aug 21, 2016, to Wed, Aug 24, 2016, repeats weekly
        var multiAllDayRecurring = `^${titleAndLocation}, All day(?: from)? ${fromOrToDate}, to ${fromOrToDate}, ${repeatInterval}$`;

        // Multi all day, from 4 PM Sun, Aug 28, 2016, to 5 PM Wed, Aug 31, 2016, repeats weekly
        var multiDayTimedRecurring = `^${titleAndLocation},(?: from)? ${fromOrToDateAndTime}, to ${fromOrToDateAndTime}, ${repeatInterval}$`;

        /**
        * Returns Date object from string representation of year, date and time.
        *
        * @param {string} year - year in 4-digit format, e.g. 2016,
        * @param {string} month - full or abbreviated name of month, e.g. Jan,
        * @param {string} day - numeric date representation, e.g. 20,
        * @param {string} time - 12-hour clock time representation, e.g. 3:30 PM.
        *
        * @returns {Date} - Date instance.
        */
        function toDate(year, month, day, time) {
            // Time is optionally appended with :00 if tailing minutes are missing,
            // e.g. 4 PM becomes 4:00 PM.
            time = time.replace(/^(\d\d?) (am|pm)/i, '$1:00 $2');
            return new Date('%0 %1, %2 %3'.format(month, day, year, time));
        }

        /**
        * Extracts title and optionally location from respective regex group.
        */
        function getTitleAndLocation(group) {
            var titleAndLocation = group.split(', ');
            event.Title = titleAndLocation[0];
            event.Location = titleAndLocation[1];
        }

        var event = {};

        // check if any of defined regex matches header
        if (new RegExp(multiDayTimed).test(header)) {
            var groups = new RegExp(multiDayTimed).exec(header);
            event.AllDay = false;

            /*
            group 0, 'Auto Title, Shoreline Amphitheater, from 10:15 AM Thu, Mar 2, 2017, to 11:15 AM Sun, Mar 5, 2017'
            group 1, 'Auto Title, Shoreline Amphitheater'
            group 2, '10:15 AM'
            group 3, 'Thu'
            group 4, 'Mar'
            group 5, '2'
            group 6, '2017'
            group 7, '11:15 AM'
            group 8, 'Sun'
            group 9, 'Mar'
            group 10, '5'
            group 11, '2017'
            */

            var fromTime = groups[2];
            var fromMonth = groups[4];
            var fromDay = groups[5];
            var fromYear = groups[6];

            var toTime = groups[7];
            var toMonth = groups[9];
            var toDay = groups[10];
            var toYear = groups[11];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);

            return event;
        }

        if (new RegExp(multiAllDay).test(header)) {
            var groups = new RegExp(multiAllDay).exec(header);
            event.AllDay = true;

            /*
            group 0, 'Multi all day, Shoreline, All day from Sun, Aug 21, 2016, to Wed, Aug 24, 2016'
            group 1, 'Multi all day, Shoreline'
            group 2, 'Sun'
            group 3, 'Aug'
            group 4, '21'
            group 5, '2016'
            group 6, 'Wed'
            group 7, 'Aug'
            group 8, '24'
            group 9, '2016'
            */

            var fromTime = '0 AM';
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = '11:59 PM';
            var toMonth = groups[7];
            var toDay = groups[8];
            var toYear = groups[9];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);

            return event;
        }

        if (new RegExp(multiAllDayRecurring).test(header)) {
            var groups = new RegExp(multiAllDayRecurring).exec(header);
            event.AllDay = true;

            /*
            group 0, 'Multi all day, Shoreline, All day from Sun, Aug 21, 2016, to Wed, Aug 24, 2016, repeats weekly'
            group 1, 'Multi all day, Shoreline'
            group 2, 'Sun'
            group 3, 'Aug'
            group 4, '21'
            group 5, '2016'
            group 6, 'Wed'
            group 7, 'Aug'
            group 8, '24'
            group 9, '2016'
            group 10, 'weekly'
            */

            var fromTime = '0 AM';
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = '11:59 PM';
            var toMonth = groups[7];
            var toDay = groups[8];
            var toYear = groups[9];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);
            event.Repeat = groups[10];

            return event;
        }

        if (new RegExp(multiDayTimedRecurring).test(header)) {
            var groups = new RegExp(multiDayTimedRecurring).exec(header);
            event.AllDay = false;

            /*
            group 0, 'Multi timed repeated, My Location, from 4 PM Sun, Aug 28, 2016, to 5 PM Wed, Aug 31, 2016, repeats weekly'
            group 1, 'Multi timed repeated, My Location'
            group 2, '4 PM'
            group 3, 'Sun'
            group 4, 'Aug'
            group 5, '28'
            group 6, '2016'
            group 7, '5 PM'
            group 8, 'Wed'
            group 9, 'Aug'
            group 10, '31'
            group 11, '2016'
            group 12, 'weekly'
            */

            var fromTime =  groups[2];
            var fromMonth = groups[4];
            var fromDay = groups[5];
            var fromYear = groups[6];

            var toTime = groups[7];
            var toMonth = groups[9];
            var toDay = groups[10];
            var toYear = groups[11];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);
            event.Repeat = groups[12];

            return event;
        }

        if (new RegExp(singleAllDay).test(header)) {
            var groups = new RegExp(singleAllDay).exec(header);
            event.AllDay = true;

            /*
            group 0, 'All day trololo, Kharkiv, Saturday, Jan 23, 2017, All day'
            group 1, 'All day trololo, Kharkiv'
            group 2, 'Saturday'
            group 3, 'Jan'
            group 4, '23'
            group 5, '2017'
            */

            var fromTime = '0 AM';
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = '11:59 PM';
            var toMonth = groups[3];
            var toDay = groups[4];
            var toYear = groups[5];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);

            return event;
        }

        if (new RegExp(singleAllDayRecurring).test(header)) {
            var groups = new RegExp(singleAllDayRecurring).exec(header);
            event.AllDay = true;

            /*
            group 0, 'Auto test, Friday, Jan 25, 2017, All day, repeats every 2 weeks'
            group 1, 'Auto test'
            group 2, 'Friday'
            group 3, 'Jan'
            group 4, '25'
            group 5, '2017'
            group 6, 'every 2 weeks'
            */

            var fromTime = '0 AM';
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = '11:59 PM';
            var toMonth = groups[3];
            var toDay = groups[4];
            var toYear = groups[5];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);
            event.Repeat = groups[6];

            return event;
        }

        if (new RegExp(singleDayTimed).test(header)) {
            var groups = new RegExp(singleDayTimed).exec(header);
            event.AllDay = false;

            /*
            group 0, 'Auto test, Hollywood , Friday, Jan 20, 2017, 3:30 PM to 4 PM'
            group 1, 'Auto test, Hollywood '
            group 2, 'Friday'
            group 3, 'Jan'
            group 4, '20'
            group 5, '2017'
            group 6, '3:30 PM'
            group 7, '4 PM'
            */

            var fromTime =  groups[6];
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = groups[7];
            var toMonth = groups[3];
            var toDay = groups[4];
            var toYear = groups[5];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);

            return event;
        }

        if (new RegExp(singleDayTimedRecurring).test(header)) {
            var groups = new RegExp(singleDayTimedRecurring).exec(header);
            event.AllDay = false;

            /*
            group 0, 'Ololo, Thursday, Mar 2, 2017, 2 PM to 3 PM, repeats weekly'
            group 1, 'Ololo'
            group 2, 'Thursday'
            group 3, 'Mar'
            group 4, '2'
            group 5, '2017'
            group 6, '2 PM'
            group 7, '3 PM'
            group 8, 'repeats weekly'
            */

            var fromTime =  groups[6];
            var fromMonth = groups[3];
            var fromDay = groups[4];
            var fromYear = groups[5];

            var toTime = groups[7];
            var toMonth = groups[3];
            var toDay = groups[4];
            var toYear = groups[5];

            event.StartDate = toDate(fromYear, fromMonth, fromDay, fromTime);
            event.EndDate = toDate(toYear, toMonth, toDay, toTime);

            getTitleAndLocation(groups[1]);
            event.Repeat = groups[8];

            return event;
        }

        throw new UIAError('No regex matches header %0'.format(header));
    }

    // Define a mapping between the rest of event fields and their respective functions to extract actual values.
    var nonHeaderValuesFunctionsTable = {
        Invitees: function() {
            this.tap(UIAQuery.Calendar.EVENT_DETAILS_INVITEE_BTN_INVITEE_VIEW);
            var inviteesCount = this.count(UIAQuery.Calendar.EVENT_DETAILS_INVITEES_SECTION_INVITEE_VIEW);
            var invitees = [];

            for (var i = 0; i < inviteesCount; i++) {
                var thisInvitee = this.inspectElementKey(
                    UIAQuery.Calendar.EVENT_DETAILS_INVITEES_SECTION_INVITEE_VIEW.atIndex(i)
                    .andThen(UIAQuery.staticTexts()),
                    'name');

                // Depending on Exchange server version, invitee layout may have additional 'Add invitees' option.
                if (thisInvitee.toLowerCase() === 'add invitees') {
                    continue;
                }
                invitees.push(thisInvitee);
            }

            this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
            return invitees;
        },

        InvitationFrom: function() {
            this.waitUntilPresent(UIAQuery.Calendar.EVENT_DETAILS_INVITATION_FROM_BTN_INVITEE_VIEW, 5);
            this.tap(UIAQuery.Calendar.EVENT_DETAILS_INVITATION_FROM_BTN_INVITEE_VIEW);
            // Allow invitee element to render
            this.waitUntilPresent(UIAQuery.Calendar.EVENT_DETAILS_INVITATION_FROM_INVITEE_VIEW, 10);
            var invitationFromValue = this.inspectElementKey(
                UIAQuery.Calendar.EVENT_DETAILS_INVITATION_FROM_INVITEE_VIEW,
                'name');
            this.tap(UIAQuery.Calendar.VISIBLE_BACK_BUTTON);
            return invitationFromValue;
        },

        Notes: function() {
            return this.inspectElementKey(UIAQuery.Calendar.EVENT_DETAILS_NOTES_INVITEE_VIEW, 'value');
        },

        Private: function() {
            if (!this.exists(UIAQuery.Calendar.EVENT_DETAILS_PRIVATE)) {
                return false;
            } else {
                return this._switchVal(UIAQuery.Calendar.EVENT_DETAILS_PRIVATE);
            }
        },

        ShowAs: function() {
            return this.inspectElementKey(UIAQuery.Calendar.EVENT_DETAILS_SHOW_AS_VALUE, 'name');
        },

        Alert: function() {
            return this.inspectElementKey(UIAQuery.Calendar.EVENT_DETAILS_ALERT_VALUE, 'name');
        },
    };

    // Mapping between enums used for event creating and their representation
    // in invitee's header.
    var repeatIntervalsMapping = {
        DAILY: 'daily',
        WEEKLY: 'weekly',
        BIWEEKLY: 'every 2 weeks',
        MONTHLY: 'monthly',
        YEARLY: 'yearly',
    }

    /**
    * Normalize and compare two values.
    *
    * @param {string} fieldName - field name to compare,
    * @param {*} expectedValue - expected value of a field,
    * @param {*} actualValue - actual value of a field.
    *
    * @returns {boolean} - true if values are equal, false otherwise.
    */
    function compare(fieldName, expectedValue, actualValue) {
        if (fieldName === 'Repeat' && repeatIntervalsMapping.hasOwnProperty(expectedValue)) {
            expectedValue = 'repeats ' + repeatIntervalsMapping[expectedValue];
        }

        function omitHostName(value) {
            // Depending on Exchange server version some emails come with @hostname in their names,
            // while others only contain username part. Omit hostnames (if any) to simplify further verification.
            return value.split('@')[0].trim();
        }

        function normalizeValue(value) {
            if (typeof value === 'string') {
                return omitHostName(value);
            }

            if ((value instanceof Array)) {
                var values = value.map(omitHostName);
                return JSON.stringify(values.sort());
            }

            if (value instanceof Date) {
                return value.getTime();
            }

            return value;
        }

        if (normalizeValue(expectedValue) === normalizeValue(actualValue)) {
            UIALogger.logMessage('... Comparing <%0> field, <%1> value -> PASSED'.format(fieldName, expectedValue));
            return true;
        } else {
            UIALogger.logMessage('... Comparing <%0> field -> FAILED: expected <%1>, but got <%2> instead!'
                .format(fieldName, String(expectedValue), String(actualValue)));
            return false;
        }
    }

    UIALogger.logMessage('Options to verify: %0'.format(JSON.stringify(FieldsToTest)));
    if (!FieldsToTest.Invitees) {
        throw new UIAError('Provide invitee email to start verification.');
    }

    if (!this.waitUntilPresent(UIAQuery.Calendar.EVENT_DETAILS_CONTAINER, 5) ) {
        throw new UIAError('Event details view did not appear.');
    }

    var headerValues = this.inspectElementKey(UIAQuery.Calendar.EVENT_DETAILS_HEADER_INVITEE_VIEW, 'name');
    headerValues = parse(headerValues);

    var mismatchingFields = [];
    for (var field in FieldsToTest) {
        if (!FieldsToTest.hasOwnProperty(field)) {
            continue;
        }

        var expectedValue = FieldsToTest[field];
        var actualValue = undefined;

        if (headerValues.hasOwnProperty(field)) {
            actualValue = headerValues[field];
        } else if (nonHeaderValuesFunctionsTable.hasOwnProperty(field)) {
            try {
                actualValue = nonHeaderValuesFunctionsTable[field].apply(this);
            } catch(e) {
                UIALogger.logWarning('Failed to extract value for <%0> field:\n%1'.format(field, e.message));
            }
        } else {
            UIALogger.logWarning('No actual value found for <%0> field'.format(field));
        }

        if (actualValue === undefined || !compare(field, expectedValue, actualValue)) {
            mismatchingFields.push(field);
        }
    }

    if (mismatchingFields.length > 0) {
        throw new UIAError('Calendar event values mismatch in the following fields: %0'
            .format(JSON.stringify(mismatchingFields)), {identifier: 'Calendar event verification failed'});
    } else {
        UIALogger.logMessage('Calendar event verification passed!');
    }
}

/**
 * Set the values of an event from the "New Event" or "Edit Event" view
 *
 * @param {object} options - Options struct
 * @param {string}          [options.Title="SAMPLE TITLE"]       - Title of event
 * @param {Date}            [options.StartDate=null]             - StartDate of event
 * @param {Date}            [options.EndDate=null]               - EndDate of event
 * @param {string}          [options.Location=null]              - Location of event
 * @param {string}          [options.AutoCompleteLocationString=null] - The location string to search in auto-complete location
 * @param {string}          [options.CalendarName=null]          - Calendar to save this event under
 * @param {string}          [options.CalendarGroup=""]           - Calendar group to save this event under
 * @param {bool}            [options.AllDay=false]               - Specify whether event is an all-day event or not
 * @param {string}          [options.Repeat=null]                - Repeat interval
 * @param {Date}            [options.RepeatEndDate=null]         - RepeatEndDate of event, if a repeat interval is set - set to NULL to get Never-ending Repeat, or UNDEFINED to keep the same state
 * @param {string}          [options.Alert=null]                 - Alert for event
 * @param {string}          [options.Notes=null]                 - Event notes
 * @param {string[]}        [options.Invitees=[]]                - List of invitees to add to event (Not available in all calendars)
 * @param {bool}            [options.TravelTimeEnabled=null]     - Displaying travel time for event
 * @param {string}          [options.TravelTimeAmount=null]      - Set travel time amount
 * @param {enum}            [options.ShowAs=null]                - Status at time of event (Busy, Free, Tentative, Out of office -> enum calendar.AVAILABILITY_VALUES)
 * @param {bool}            [options.Private=null]               - Event is private (Not available in all calendars)
 * @param {string}          [options.Url=null]                   - URL string
 * @param {bool}    ApplyToFutureOccurrences                     - Apply changes to all future occurrences of this event
 *
 * @throws If unable set an event property
 */
calendar._setEventOptions = function _setEventOptions(options, ApplyToFutureOccurrences) {
    options = UIAUtilities.defaults(options, {
        Title:                      'SAMPLE TITLE',
        StartDate:                  null,
        EndDate:                    null,
        Location:                   null,
        AutoCompleteLocationString: null,
        CalendarName:               null,
        CalendarGroup:              '',
        AllDay:                     false,
        Repeat:                     null,
        RepeatEndDate:              null,
        Alert:                      null,
        Notes:                      null,
        Invitees:                   [],
        TravelTimeEnabled:          null,
        TravelTimeAmount:           null,
        ShowAs:                     null,
        Private:                    null,
        Url:                        null,
     });

    var eventTableCellCount = this.count(UIAQuery.Calendar.EDIT_EVENT_CONTAINER.andThen(UIAQuery.tableCells()));

    // Set Title
    if (options.Title) {
        this.enterText(UIAQuery.Calendar.EDIT_EVENT_TITLE , options.Title);
    }

    // Set Location
    if (options.Location) {
        this.tap(UIAQuery.Calendar.EDIT_EVENT_LOCATION);
        if (!options.AutoCompleteLocationString) {
            this._enterTextAndDismiss(UIAQuery.searchBars(), options.Location);
        } else {
            // Enter location in search bar
            var typeOptions = {
                allowTypeStringToRetry: true,
                clearTextBeforeTyping: true
            };
            this.enterText(UIAQuery.searchBars(), options.Location, typeOptions);
            // The AC list dynamically updates. Waits until it's completely loaded.
            previousTotalSuggestions = -1;
            while ((totalSuggestions = this.count(UIAQuery.Calendar.EVENT_AUTO_COMPLETE_LOCATIONS)) > previousTotalSuggestions) {
                previousTotalSuggestions = totalSuggestions;
                target.delay(1);
            }
            // Look for the location which contains both Location and AutoCompleteLocationString
            var targetLocationQuery = UIAQuery.Calendar.EVENT_AUTO_COMPLETE_LOCATIONS.withPredicate(
                'ANY descendants.name contains "%0" AND ANY descendants.name contains "%1"'.format(
                    options.Location, options.AutoCompleteLocationString
                )
            );
            UIAUtilities.assert(
                // it takes some time to search and get results
                this.waitUntilPresent(targetLocationQuery, 30),
                'Did not find an auto-complete location containing "%0" and "%1"'.format(
                    options.Location, options.AutoCompleteLocationString)
            );
            this.tap(targetLocationQuery);
        }
    }

    // Set AllDay
    if (options.AllDay !== undefined && options.AllDay !== null && this.exists(UIAQuery.Calendar.EDIT_EVENT_ALLDAY)) {
        this.waitUntilPresent(UIAQuery.Calendar.EDIT_EVENT_ALLDAY.isVisible(), 5);
        this.setControl(UIAQuery.Calendar.EDIT_EVENT_ALLDAY, Boolean(options.AllDay));
    }

    // Set start time
    if (options.StartDate) {
        this.tap(UIAQuery.Calendar.EDIT_EVENT_START);
        // Workaround for <rdar://28343030>. Removal tracked in <rdar://problem/29115035>
        var wheelsQuery = UIAQuery.Calendar.EDIT_EVENT_PICKER.andThen(UIAQuery.pickerWheels());

        var wheelCount = this.count(wheelsQuery);
        if (wheelCount == 0) {
            UIALogger.logMessage("There were 0 wheels for this picker; will try to spawn the pickerWheels again.");
            this.tap(UIAQuery.Calendar.EDIT_EVENT_START);
            var timeout = 1;
            if (!this.waitUntilPresent(wheelsQuery, timeout)) {
                throw new UIAError("We waited %0 second(s) after tapping %1 to spawn a pickerWheel and it still didn't appear!".format(timeout, UIAQuery.Calendar.EDIT_EVENT_START.description()));
            }
        }
        this._setDateTimePicker(UIAQuery.Calendar.EDIT_EVENT_PICKER, UIAQuery.Calendar.EDIT_EVENT_ALLDAY, options.StartDate);
        this.tap(UIAQuery.Calendar.EDIT_EVENT_START);
    }

    // Set end time
    if (options.EndDate) {
        this.tap(UIAQuery.Calendar.EDIT_EVENT_END);
        this._setDateTimePicker(UIAQuery.Calendar.EDIT_EVENT_PICKER, UIAQuery.Calendar.EDIT_EVENT_ALLDAY, options.EndDate);
        this.tap(UIAQuery.Calendar.EDIT_EVENT_END);
    }

    // Set Repeat
    if (options.Repeat && (this.inspect(UIAQuery.Calendar.EDIT_EVENT_REPEAT_VALUE).name != options.Repeat)) {
        var longRepeatName = this._sanitizeEventRepeatValue(options.Repeat);

        this.tap(UIAQuery.Calendar.EDIT_EVENT_REPEAT);
        var repeatView = UIAQuery.navigationBars("Repeat").parent();
        if (! this.exists(repeatView.andThen(longRepeatName))) {
            throw new UIAError("Repeat value not found in view: %0".format(longRepeatName), {identifier:'Repeat value not found'});
        }
        this.tap( repeatView.andThen(longRepeatName) );
    }

    // Set Repeat End
    if (options.RepeatEndDate !== undefined && this.exists(UIAQuery.Calendar.EDIT_EVENT_REPEAT_END)) {
        this.tap(UIAQuery.Calendar.EDIT_EVENT_REPEAT_END);

        var endRepeatView = UIAQuery.navigationBars("End Repeat").parent();
        if (options.RepeatEndDate instanceof Date) {
            this.tap(endRepeatView.andThen("On Date"));
            this._setDayPicker(endRepeatView, options.RepeatEndDate);
        } else {
            this.tap(endRepeatView.andThen("Never"));
        }
        this.tap(endRepeatView.andThen(UIAQuery.Calendar.VISIBLE_BACK_BUTTON));
    }

    // Set Calendar
    if (options.CalendarName) {
        this.tap(UIAQuery.Calendar.EDIT_EVENT_CALENDAR);

        this._verifyCalendarExistence(options.CalendarGroup, options.CalendarName);
        var cell_q = UIAQuery.tableCells().withPredicate("ANY children.name == '" + options.CalendarName + "'");
        if (this.inspect(cell_q).isSelected) {
            // If calendar is already selected, back out manually
            this.tap( UIAQuery.Calendar.VISIBLE_BACK_BUTTON );
        }
        this.tap( this._specificCalendarQuery(options.CalendarGroup, options.CalendarName) );
    }

    // Set Invitees
    if (options.Invitees && options.Invitees.length > 0) {
        if (! this.exists(UIAQuery.Calendar.EDIT_EVENT_INVITEES)) throw new UIAError('No Invitees field found; this calendar is probably local', {identifier:'Cannot add invitees to event'});

        // Get to the List-Invitee view
        this.tap(UIAQuery.Calendar.EDIT_EVENT_INVITEES);

        // If in List-Invitee view, tap into Add-Invitee view
        this._tapIfExists(UIAQuery.Calendar.EDIT_EVENT_INVITEES_ADD, 2);

        // Delete existing emails first (There will be N+1 buttons in this subtree, N for the N invitees and 1 for the '+' button)
        while (this.inspectAll(UIAQuery.Calendar.RECIPIENTS_TEXTFIELD.andThen(UIAQuery.buttons())).length > 1) {
            // Two taps on the Delete button are required to delete an email entry
            this.doubleTap(UIAQuery.Calendar.KEYBOARD_DELETE_BUTTON);
        }

        // Enter the new emails
        this._enterTextAndDismiss(UIAQuery.Calendar.RECIPIENTS_TEXTFIELD, options.Invitees.join('\n') + '\n');

        // Exit Add-Invitee view and List-Invitee view
        this.tap( UIAQuery.DONE_BUTTON );
        this.tap( UIAQuery.Calendar.VISIBLE_BACK_BUTTON );
    }

    // Set Alert
    this._setEventAlert(UIAQuery.Calendar.EDIT_EVENT_ALERT, UIAQuery.Calendar.EDIT_EVENT_ALERT_VALUE, options.Alert);

    // Set Show As
    if (options.ShowAs) {
        if (this.exists(UIAQuery.Calendar.EDIT_EVENT_SHOW_AS) && (options.ShowAs !== this.inspect(UIAQuery.Calendar.EDIT_EVENT_SHOW_AS.parent()).value)) {
            this.tap(UIAQuery.Calendar.EDIT_EVENT_SHOW_AS);
            var showAsToSelect = UIAQuery.beginsWith(options.ShowAs);
            if ( !this.exists(showAsToSelect) ) {
                throw new UIAError(options.ShowAs, {identifier:'Invalid ShowAs value'});
            }
            this.tap(showAsToSelect);
        }
    }

    // Private
    if (options.Private !== undefined) {
        this.setControlIfExists(UIAQuery.Calendar.EDIT_EVENT_PRIVATE, Boolean(options.Private));
    }

    // URL
    if (options.Url) {
        this.enterText(UIAQuery.Calendar.EDIT_EVENT_URL, options.Url);
    }

    // Notes
    if (options.Notes) {
        this.enterText(UIAQuery.Calendar.EDIT_EVENT_NOTES, options.Notes);
    }

    // Save - by default it will apply event edits to only the current occurrence
    this.tap(UIAQuery.Calendar.EDIT_EVENT_CONTAINER.ancestors().andThen(UIAQuery.Calendar.ADD_BUTTON).orElse(UIAQuery.DONE_BUTTON));
    this._tapIfExists( ApplyToFutureOccurrences ? UIAQuery.Calendar.BULK_EVENTS_BUTTON : UIAQuery.Calendar.SINGLE_EVENT_BUTTON, 2 );
}

/**
 * Sets an alert for the event
 * Assumes device is currently in the event details view (for event invites) or on the edit event view.
 *
 * @param {UIAQuery}    AlertQuery              - Query for the alert field
 * @param {UIAQuery}    AlertValueQuery         - Query for the alert value field
 * @param {string}      AlertSelection          - The alert type (i.e. "At time of event", "5 minutes before", etc)
 *
 * @throws If unable set the date and time values of a picker
 */
calendar._setEventAlert = function _setEventAlert(AlertQuery, AlertValueQuery, AlertSelection) {
    if (AlertSelection && this.exists(AlertQuery)) {
        if (AlertSelection != this.inspect(AlertValueQuery).name) {
            this.tap(AlertQuery);
            var alertToSelect = UIAQuery.withPredicate("name BEGINSWITH[c] '%0'".format(AlertSelection));
            if ( !this.exists(alertToSelect) ) {
                throw new UIAError("Invalid Alert value '%0'".format(AlertSelection), {identifier:"Invalid Alert value"});
            }
            this.tap(alertToSelect);
        }
    }
}

/**
 * Set the date and time of a picker with both date and time attributes.
 * Flips the All-Day switch to navigate to the target date first, before navigating to the target time.
 * Assumes device is currently in edit event view.
 *
 * @param {UIAQuery}    PickerQuery             - Query for the picker where the picker wheels are nested in
 * @param {UIAQuery}    AllDaySwitchQuery       - Query for the all-day switch
 * @param {Date}        TargetDate              - date to set the picker wheels' values
 *
 * @throws If unable set the date and time values of a picker
 */
calendar._setDateTimePicker = function _setDateTimePicker(PickerQuery, AllDaySwitchQuery, TargetDate) {
    // Set All-Day to true to allow for faster scrolling to the desired date
    var isAllDayEvent = false;
    if (this.exists(AllDaySwitchQuery)) {
        isAllDayEvent = this._switchVal(AllDaySwitchQuery);
        this.setControl(AllDaySwitchQuery, true);
        // Set the correct day
        this._setDayPicker(PickerQuery, TargetDate);
        // Set All-Day to false to allow setting the specific time
        this.setControl(AllDaySwitchQuery, false);
    }

    // Set the exact time
    this._setTimePicker(PickerQuery, TargetDate);

    if (this.exists(AllDaySwitchQuery)) {
        // Set the value back to what it was
        this.setControl(AllDaySwitchQuery, isAllDayEvent);
    }
}

/**
 * Set the date and time of a picker with date-only attributes.
 * Assumes device is currently in edit event view.
 *
 * @param {UIAQuery}    PickerQuery     - Query for the picker where the picker wheels are nested in
 * @param {Date}        TargetDate      - date to set the picker wheels' values
 *
 * @throws If unable set the date values of a picker
 */
calendar._setDayPicker = function _setDayPicker(PickerQuery, TargetDate) {
    var year = String( TargetDate.getFullYear() );
    var month = this.MONTHS[TargetDate.getMonth()];
    var dayOfMonth = String( TargetDate.getDate() );
    // NOTE: This is a workaround for <rdar://30265841>. The workaround radar is <rdar://30274789>. The radar to remove the workaround is <rdar://30277787>.
    this.setControl(PickerQuery.andThen(UIAQuery.pickerWheels()).atIndex(0), month);
    if (! this.waitUntilPresent(PickerQuery.andThen(UIAQuery.pickerWheels()).atIndex(1).withPredicate('values.@count > 0'), 2))
    {
        throw new UIAError('Could not get values for the dayOfMonth pickerWheel after setting the month pickerWheel.');
    }
    this.setPickerValues(PickerQuery, [month, dayOfMonth, year]);
}

/**
 * Set the date and time of a picker with DateTime attributes
 *
 * @param {UIAQuery}    PickerQuery     - Query for the picker where the picker wheels are nested in
 * @param {Date}        TargetDate      - date and time to set the picker wheels' values
 *
 * @throws If unable set the date and time values of a picker
 */
calendar._setTimePicker = function _setTimePicker(PickerQuery, TargetDate) {
    // Validate picker wheel count
    var wheelsQuery = PickerQuery.andThen(UIAQuery.pickerWheels());
    var wheelCount = this.count(wheelsQuery);
    if (wheelCount !== 3 && wheelCount !== 4) {
        throw new UIAError('Expect 3 or 4 picker wheels but got %0'.format(wheelCount));
    }

    // Get the minute value
    var minutes = TargetDate.getMinutes();
    var minutesValue = (minutes < 10) ? '0' + minutes.toString() : minutes.toString();
    // Get date in format 'Oct 5'
    var dateValue = TargetDate.toDateString().split(' ').slice(1,3).map(function(value){ return value.replace(/^0+/, ''); }).join(' ');

    // Set the hour and meridiem values
    var hours = TargetDate.getHours();
    var hoursValue;
    var meridiemValue;
    if (wheelCount === 3) {
        // 24-hour format
        hoursValue = (hours < 10) ? '0' + hours.toString() : hours.toString();
        this.setPickerValues(PickerQuery, [dateValue, hoursValue, minutesValue]);
    } else {
        // 12-hour format
        if (hours == 0) {
            hoursValue = '12';
            meridiemValue = 'AM';
        } else if(hours < 12) {
            hoursValue = hours.toString();
            meridiemValue = 'AM';
        } else if(hours == 12) {
            hoursValue = '12';
            meridiemValue = 'PM';
        } else {
            hoursValue = (hours - 12).toString();
            meridiemValue = 'PM';
        }
        this.setPickerValues(PickerQuery, [dateValue, hoursValue, minutesValue, meridiemValue]);
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Non-UI helper functions. E.g. convertHourToMinutes                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Convert common string names for event notification times to time in seconds
 *
 * @param {string} eventAlertStr - String for event alert notifications. Comes from the 'Alert
 *                          section of the edit menu of an event.
 *
 * @returns {number} - Time in seconds deduced from eventAlertStr
 * @throws If eventAlertStr is not a recognized string.
 */
calendar.calculateEventNotificationTime = function calculateEventNotificationTime(eventAlertStr) {
    UIALogger.logMessage('Event notification time set to: %0'.format(eventAlertStr));

    switch (eventAlertStr) {
        case calendar.EventAlertValues.AT_TIME_OF_EVENT:
            return 0;
        case calendar.EventAlertValues.FIVE_MINUTES:
            return 5 * 60;
        case calendar.EventAlertValues.FIFTEEN_MINUTES:
            return 15 * 60;
        case calendar.EventAlertValues.THIRTY_MINUTES:
            return 30 * 60;
        case calendar.EventAlertValues.ONE_HOUR:
            return 1 * 60 * 60;
        case calendar.EventAlertValues.TWO_HOURS:
            return 2 * 60 * 60;
        case calendar.EventAlertValues.ONE_DAY:
            return 1 * 24 * 60 * 60;
        case calendar.EventAlertValues.TWO_DAYS:
            return 2 * 24 * 60 * 60;
        case calendar.EventAlertValues.ONE_WEEK:
            return 7 * 24 * 60 * 60;
        default:
            throw new UIAError(
                "Alert notification string is incorrectly defined/unsupported. \
                Likely incorrect test parameter for 'Alert' or notification strings have changed."
            );
    }
}
