load('UIATesting.js');
load('iTunes.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof iTunesTests === 'undefined',
    'iTunesTests has already been defined.'
);

/** @namespace */
var iTunesTests = {

    /**
      * Sign into the iTunes store with a given username and password
      *
      * @targetApps iTunes
      *
      * @param {object} args - Test arguments
      * @param {string}         [args.username="PERSISTEDAPPLEID"] - If set,
      * @param {string}         [args.password="PERSISTEDAPPLEIDPASSWORD"] - If set, will confirm
      */
    signIn: function signIn(args) {
        args = UIAUtilities.defaults(args, {
            // iTunes login credentials:
            username:               null,
            password:               null,
        });

        if (args.username === 'PERSISTEDAPPLEID') {
            UIALogger.logMessage('Using the persisted AppleID to sign into iTunes');
            args.username = springboard.appleID;
        }

        if (args.password === 'PERSISTEDAPPLEIDPASSWORD') {
            UIALogger.logMessage('Using the persisted AppleID password to sign into iTunes');
            args.password = springboard.appleIDPassword;
        }

        itunes.signIn(args);
    },

    /**
      * Sign out of the iTunes store
      *
      * @targetApps iTunes
      *
      * @param {object} args - Test arguments
      */
    signOut: function signOut(args) {
        args = UIAUtilities.defaults(args, {

        });

        itunes.signOut();
    },

    /**
      * Starts playing a sample media from either Music, Movies, or TV Shows
      *
      * @targetApps iTunes
      *
      * @param {object} args - Test arguments
      * @param {enum}           [args.mediaType="Music"] - Type of the sample media to play -> enum itunes.MediaType
      *
      */
    playSampleMedia: function playSampleMedia(args) {
        args = UIAUtilities.defaults(args, {
            // Media type selection
            mediaType:               itunes.MediaType.MUSIC,
        });

        if (args.mediaType === itunes.MediaType.MUSIC) {
            itunes.playSampleMusic(args);

        } else if (args.mediaType === itunes.MediaType.MOVIES) {
            itunes.playSampleMovie(args);

        } else if (args.mediaType === itunes.MediaType.TV_SHOWS) {
            itunes.playSampleTVShow(args);

        } else {
            throw new UIAError("Unrecognized media type: '%0'".format(args.mediaType), {identifier: "Unrecognized media type"});
        }
    },
}
