load('UIAUtility.js');
load('UIAApp.js');
load('UIANavigation.js');
load('SpringBoard.js');

if (typeof itunes !== 'undefined') {
    if (!(itunes instanceof UIAApp)) {
        throw new UIAError("itunes has already been defined to something not an instance of UIAApp! Value: %0".format(itunes));
    }
    if (itunes.bundleID() !== 'com.apple.MobileStore') {
        var oldDefinition = itunes.bundleID();
        var itunes = target.appWithBundleID('com.apple.MobileStore');
        UIALogger.logWarning("'itunes' was redefined from '%0' to '%1'".format(oldDefinition, itunes.bundleID()));
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common iTunes queries */
UIAQuery.iTunes = {
    GENRES:         UIAQuery.navigationBars('Genres'),

    Segments : {
        FEATURED:   UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Featured')),
        CHARTS:     UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Charts')),

        DETAILS:    UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Details')),
        REVIEWS:    UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Reviews')),
        RELATED:    UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Related')),

        WISH_LIST:  UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Wish List')),
        SIRI:       UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Siri')),
        RADIO:      UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Radio')),
        PREVIEWS:   UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Previews')),

        ALL:        UIAQuery.segmentedControls().andThen(UIAQuery.buttons('All')),
        MUSIC:      UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Music')),
        SONGS:      UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Songs')),
        ALBUMS:     UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Albums')),
        TV_SHOWS:   UIAQuery.segmentedControls().andThen(UIAQuery.buttons('TV Shows')),
        TV_SEASONS: UIAQuery.segmentedControls().andThen(UIAQuery.buttons('TV Seasons')),
        TV_EPISODES:UIAQuery.segmentedControls().andThen(UIAQuery.buttons('TV Episodes')),
        MOVIES:     UIAQuery.segmentedControls().andThen(UIAQuery.buttons('Movies')),
        MORE:       UIAQuery.segmentedControls().andThen(UIAQuery.buttons('More')),
    },

    /** Tabs/Views Within iTunes App */
    Tabs : {
        MUSIC:       UIAQuery.tabBars().andThen(UIAQuery.buttons('Music')),
        MOVIES:      UIAQuery.tabBars().andThen(UIAQuery.buttons('Movies')),
        TV_SHOWS:    UIAQuery.tabBars().andThen(UIAQuery.buttons('TV Shows')),
        TONES:       UIAQuery.tabBars().andThen(UIAQuery.buttons('Tones')),
        SEARCH:      UIAQuery.tabBars().andThen(UIAQuery.buttons('Search')),
        MORE:        UIAQuery.tabBars().andThen(UIAQuery.buttons('More')),

        TOP_CHARTS:     UIAQuery.tabBars().andThen(UIAQuery.buttons('Top Charts')),
        GENIUS:         UIAQuery.tabBars().andThen(UIAQuery.buttons('Genius')),
        PURCHASED:      UIAQuery.tabBars().andThen(UIAQuery.buttons('Purchased')),
    },

    BackTo : {
        MUSIC:      UIAQuery.navigationBars().andThen(UIAQuery.buttons('Music')),
        MOVIES:     UIAQuery.navigationBars().andThen(UIAQuery.buttons('Movies')),
        TV_SHOWS:   UIAQuery.navigationBars().andThen(UIAQuery.buttons('TV Shows')),
        TONES:      UIAQuery.navigationBars().andThen(UIAQuery.buttons('Tones')),
        PURCHASED:  UIAQuery.navigationBars().andThen(UIAQuery.buttons('Purchased')),
    },

    SEARCH_BAR:         UIAQuery.query('SKUISearchBar'),
    SEARCH_CONTAINER:   UIAQuery.query('SKUIDocumentContainerView'),
    OVERLAY:            UIAQuery.query('OverlayCaptureView'),
    SIGN_IN_BUTTON:     UIAQuery.query('Sign In'),
    SIGN_OUT_BUTTON:    UIAQuery.beginsWith('Apple ID: '),

    Alerts: {
        ACCOUNT_NOT_YET_BEEN_USED:   UIAQuery.alerts('This Apple ID has not yet been used in the iTunes Store.'),
        FIRST_SIGN_IN:  UIAQuery.alerts('Sign In'),
        SIGN_IN:        UIAQuery.alerts('Sign In to iTunes Store'),
        SIGN_OUT:       UIAQuery.alerts('Apple ID'),
    },
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to iTunes */
UIStateDescription.iTunes = {
    Detail : {
        /* Tone Detail view - accessed by tapping a music/album entry in Music tab  */
        MUSIC:          'music detail',

        /* Movies Detail view - accessed by tapping a movie entry in Movies tab  */
        MOVIES:         'movies detail',

        /* TV Shows Detail view - accessed by tapping a TV show entry in TV Shows tab  */
        TV_SHOWS:       'TV shows detail',

        /* Tone Detail view - accessed by tapping a tone entry in Tones tab  */
        TONES:          'tones detail',
    },

    /* Genres view - this is accessed by tapping the top left button in the navigation bar in Music/Movies/TVShows tab */
    GENRES:             'genres',

    /* Main/empty Search Tab (iPhones only; iPads have the Search bar in the Navigation bar) */
    SEARCH:             'search',

    /* Search results view */
    SEARCH_RESULTS:     'search results',

    /* The Item list is accessed by tapping the top right button of the navigation bar in Music/Movies/TVShows tab.  There are 4 segmented views available */
    ItemList : {
        WISH_LIST:      'items - wish list',
        SIRI:           'items - siri',
        RADIO:          'items - radio',
        PREVIEWS:       'items - previews',
    },

    /* Main Music Tab */
    MUSIC:              'music',

    /* Main Movies Tab */
    MOVIES:             'movies',

    /* Main TV Shows Tab */
    TV_SHOWS:           'TV shows',

    /* Main Tones Tab (iPhones only) */
    TONES:              'tones',

    /* "More" Tab (iPhones only) */
    MORE:               'more',

    /* Top Charts Tab (iPads only; iPhones have the top charts of each media category as a segmnt view) */
    TOP_CHARTS:         'top charts',

    /* Genius Tab */
    GENIUS:             'genius',

    /* Purchased Tab */
    PURCHASED:          'purchased',

    /* Downloads Tab (iPhones only) */
    DOWNLOADS:          'downloads',
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: iTunes Constants and Enums                                          */
/*                                                                             */
/*      Enums used by the iTunes library, for internal and external API use    */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var itunes = target.appWithBundleID('com.apple.MobileStore');

/** Constants for iTunes WaiterType */
itunes.WaiterType = {
    /** Category change alert/action sheet in 'My iTunes'  */
    UI_LOAD:                            'UI Load',
    ACCOUNT_NOT_YET_BEEN_USED_ALERT:    'Account not yet been used',
    FIRST_SIGN_IN_ALERT:                'First Sign In Alert',
    SIGN_IN_ALERT:                      'Sign In Alert',
    SIGN_OUT_ALERT:                     'Sign Out',
}

itunes.MediaType = {
    MUSIC:              'Music',
    MOVIES:             'Movies',
    TV_SHOWS:           'TV Shows',
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Navigation Utilities                                                */
/*                                                                             */
/*      A set of functions to help determine current state and                 */
/*      navigation between states                                              */
/*                                                                             */
/*******************************************************************************/

/**
 * Return true/false as to whether the device is an iPad
 *
 * Required Starting State: None
 *
 * @returns true if the device is an iPad class; else false
 *
 */
function isPadClass()   { return UIATarget.localTarget().model() === 'iPad'; }

/**
 * Exits an overlay on iPads
 *
 * It is necessary to hardcode the coordinates since all other queries
 * outside the overlay are not tappable - <rdar://problem/23923506> [UIA2] Cannot dismiss overlays on iPads
 *
 * Required Starting State: In an Overlay view (Music/Movies/TVShows detail view, iPads only)
 *
 * @returns None
 */
itunes._exitOverlay = function _exitOverlay() {
    if (this.exists(UIAQuery.query('OverlayCaptureView'))) {
        this.tap(UIAQuery.application(), {offset: {x: 0.1, y: 0.1}});
    }
}


/**
 * Exits the Item List view first before going to another state
 *
 * Required Starting State: In an Item List view
 *
 * @param {string} destinationUIState - a UIStateDescription
 *
 * @returns None
 *
 * @throws if unable to tap the navigation bar Done button or
 *          nagivate to the destination UIStateDescription
 *
 */
itunes._exitItemListAndNavigate = function _exitItemListAndNavigate(destinationUIState) {
    this.tap(UIAQuery.NAV_BAR_DONE_BUTTON);
    this.navigation.goTo(destinationUIState);
}

/**
 * Returns true if ALL queries in a list of queries returns false
 *
 * Required Starting State: None
 *
 * @param {Array<UIAQuery>} arrayOfQueries - an array of UIAQueries
 *
 * @returns true if all the queries returns EXISTS; else false
 */
itunes._multiExists = function _multiExists(arrayOfQueries) {
    var appInfo = this.inspect(UIAQuery.application());
    for(var i=0; i < arrayOfQueries.length; i++) {
        if (! appInfo.exists(arrayOfQueries[i])) return false;
    } return true;
}

/**
 * Returns true if ALL queries in a list of queries returns false
 *
 * Required Starting State: None
 *
 * @param {Array<UIAQuery>} arrayOfQueries - an array of UIAQueries
 *
 * @returns true if all the queries returns NOT-EXISTS; else false
 */
itunes._multiNotExists = function _multiNotExists(arrayOfQueries) {
    var appInfo = this.inspect(UIAQuery.application());
    for(var i=0; i < arrayOfQueries.length; i++) {
        if (appInfo.exists(arrayOfQueries[i])) return false;
    } return true;
}

/**
 * Returns true if the first query returns EXISTS and the second query
 * returns NOT-EXISTS
 *
 * Required Starting State: None
 *
 * @param {UIAQuery} query1 - a UIAQuery
 * @param {UIAQuery} query2 - a UIAQuery
 *
 * @returns None
 *
 */
itunes._existsAndNotExists = function _existsAndNotExists(query1, query2) {
    var appInfo = this.inspect(UIAQuery.application());
    if (appInfo.exists(query1) && ! appInfo.exists(query2)) {
        return true;
    } return false;
}

/**
 * Navigate to Top Charts tab (iPads only)
 *
 * Required Starting State: None
 *
 * @param {UIAQuery} query1 - a UIAQuery
 * @param {UIAQuery} query2 - a UIAQuery
 *
 * @returns None
 *
 * @throws if device is not iPad class, or unable to navigate to Top Charts
 *
 */
itunes._goToTopCharts = function _goToTopCharts() {
    if (UIATarget.localTarget().model() === 'iPad') {
        itunes.tap(UIAQuery.iTunes.Tabs.TOP_CHARTS);
    } else {
        throw new UIAError('Top Charts tab is only available on iPads!');
    }
}

itunes.NAVIGATION_VIEW_TRANSITIONS = [
    // From MUSIC to other tabs
    { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.MOVIES,      transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MOVIES } },
    { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.TV_SHOWS,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.TV_SHOWS } },
    { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.SEARCH,      transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.SEARCH } },
    { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.MORE,        transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MORE } },
    { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.TOP_CHARTS,  transition: { action:itunes._goToTopCharts, options:null } },

    // From other tabs to MUSIC
    { from: UIStateDescription.iTunes.MOVIES,   to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.TV_SHOWS, to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.SEARCH,   to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.MORE,     to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.TONES,    to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.GENUS,    to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.PURCHASED,    to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.DOWNLOADS,    to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },
    { from: UIStateDescription.iTunes.TOP_CHARTS,   to: UIStateDescription.iTunes.MUSIC,    transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.MUSIC } },

    // from detail view  to the main view
    { from: UIStateDescription.iTunes.Detail.MUSIC,      to: UIStateDescription.iTunes.MUSIC,    transition: { action:function() { itunes._exitOverlay(); itunes.tap(UIAQuery.iTunes.Tabs.MUSIC); } }},
    { from: UIStateDescription.iTunes.Detail.MOVIES,     to: UIStateDescription.iTunes.MOVIES,   transition: { action:function() { itunes._exitOverlay(); itunes.tap(UIAQuery.iTunes.Tabs.MOVIES); } }},
    { from: UIStateDescription.iTunes.Detail.TV_SHOWS,   to: UIStateDescription.iTunes.TV_SHOWS, transition: { action:function() { itunes._exitOverlay(); itunes.tap(UIAQuery.iTunes.Tabs.TV_SHOWS); } }},

    // iPhones only
    { from: UIStateDescription.iTunes.Detail.TONES,      to: UIStateDescription.iTunes.TONES,    transition: { action:itunes.tap, options:UIAQuery.iTunes.BackTo.TONES } },

    // Navigate between each list in the Items List view
    { from: UIStateDescription.iTunes.ItemList.WISH_LIST, to: UIStateDescription.iTunes.ItemList.SIRI,      transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.SIRI } },
    { from: UIStateDescription.iTunes.ItemList.WISH_LIST, to: UIStateDescription.iTunes.ItemList.RADIO,     transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.RADIO } },
    { from: UIStateDescription.iTunes.ItemList.WISH_LIST, to: UIStateDescription.iTunes.ItemList.PREVIEWS,  transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.PREVIEWS } },
    { from: UIStateDescription.iTunes.ItemList.SIRI,        to: UIStateDescription.iTunes.ItemList.WISH_LIST,  transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.WISH_LIST } },
    { from: UIStateDescription.iTunes.ItemList.RADIO,       to: UIStateDescription.iTunes.ItemList.WISH_LIST,  transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.WISH_LIST } },
    { from: UIStateDescription.iTunes.ItemList.PREVIEWS,    to: UIStateDescription.iTunes.ItemList.WISH_LIST,  transition: { action:itunes.tap, options:UIAQuery.iTunes.Segments.WISH_LIST } },
];

if (isPadClass()) {
    itunes.NAVIGATION_VIEW_TRANSITIONS.concat([
        { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.TOP_CHARTS,  transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.TOP_CHARTS } },
        { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.GENIUS,      transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.GENIUS } },
        { from: UIStateDescription.iTunes.MUSIC, to: UIStateDescription.iTunes.PURCHASED,   transition: { action:itunes.tap, options:UIAQuery.iTunes.Tabs.PURCHASED } },
    ]);
} else {
    itunes.NAVIGATION_VIEW_TRANSITIONS.concat([
        { from: UIStateDescription.iTunes.MORE, to: UIStateDescription.iTunes.TONES,        transition: { action:itunes.tap, options:UIAQuery.staticTexts('Tones') }, },
        { from: UIStateDescription.iTunes.MORE, to: UIStateDescription.iTunes.GENIUS,       transition: { action:itunes.tap, options:UIAQuery.staticTexts('Genius') }, },
        { from: UIStateDescription.iTunes.MORE, to: UIStateDescription.iTunes.PURCHASED,    transition: { action:itunes.tap, options:UIAQuery.staticTexts('Purchased') }, },
        { from: UIStateDescription.iTunes.MORE, to: UIStateDescription.iTunes.DOWNLOADS,    transition: { action:itunes.tap, options:UIAQuery.staticTexts('Downloads') }, },
    ]);
}

// This is for navigating between each of the segmented views in the History/Lists view (i.e. WishList, Siri, Radio, Previews) to the main tab views (Music/Movies/etc)
for (var i=0, toState; toState = [
        UIStateDescription.iTunes.MUSIC, UIStateDescription.iTunes.MOVIES, UIStateDescription.iTunes.TV_SHOWS,
        UIStateDescription.iTunes.TONES, UIStateDescription.iTunes.SEARCH_RESULTS, UIStateDescription.iTunes.SEARCH,
        UIStateDescription.iTunes.MORE
    ][i]; i++) {
        for (var j=0, fromState; fromState = [
            UIStateDescription.iTunes.ItemList.WISH_LIST,
            UIStateDescription.iTunes.ItemList.SIRI,
            UIStateDescription.iTunes.ItemList.RADIO,
            UIStateDescription.iTunes.ItemList.PREVIEWS,
        ][j]; j++)
            itunes.NAVIGATION_VIEW_TRANSITIONS.push( { from: fromState, to: toState, transition: { action:itunes._exitItemListAndNavigate, options:toState }} );
}

// The following states are same-queryable for both iPads and iPhones
itunes.NAVIGATION_VIEWS = {};
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.GENRES]               = { action:itunes.exists, options:UIAQuery.iTunes.GENRES };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.ItemList.WISH_LIST]   = { action:itunes.exists, options:UIAQuery.iTunes.Segments.WISH_LIST.isSelected() };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.ItemList.SIRI]        = { action:itunes.exists, options:UIAQuery.iTunes.Segments.SIRI.isSelected() };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.ItemList.RADIO]       = { action:itunes.exists, options:UIAQuery.iTunes.Segments.RADIO.isSelected() };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.ItemList.PREVIEWS]    = { action:itunes.exists, options:UIAQuery.iTunes.Segments.PREVIEWS.isSelected() };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.DOWNLOADS]            = { action:itunes.exists, options:UIAQuery.navigationBars('Downloads') };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.GENIUS]               = { action:itunes._multiExists, options:[UIAQuery.iTunes.Segments.MUSIC, UIAQuery.iTunes.Segments.MOVIES, UIAQuery.iTunes.Segments.TV_SHOWS] };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.PURCHASED]            = { action:itunes._multiExists, options:[UIAQuery.navigationBars('Purchased'), UIAQuery.iTunes.Tabs.PURCHASED.isSelected()] };

// The Top Charts view is only valid for iPads
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.TOP_CHARTS]           = { action:itunes.exists, options:UIAQuery.iTunes.Tabs.TOP_CHARTS.isSelected() };

// The Tones and Tones Detail views are only valid for iPhones
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.SEARCH]               = { action:function(){ itunes._existsAndNotExists(UIAQuery.iTunes.SEARCH_CONTAINER.andThen('Search'), UIAQuery.iTunes.Segments.ALL); }};
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.MORE]                 = { action:function(){ return itunes.exists(UIAQuery.navigationBars('More')) && itunes._multiNotExists([UIAQuery.iTunes.BackTo.TONES, UIAQuery.iTunes.Segments.MUSIC]); }};
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.TONES]                = { action:itunes.exists, options:UIAQuery.navigationBars('Tones') };
itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.TONES]         = { action:itunes.exists, options:UIAQuery.iTunes.BackTo.TONES };


if (isPadClass()) {
    /*
        For iPads, the Music/Movies/TV Shows detail window may either be a full view or a large popover, so we need different rules to determine the states
        !itunes.exists(UIAQuery.navigationBars('Top Charts'))) is needed because it appears incorrectly (?) in the UI tree for these views for some reason
    */
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.MUSIC]     = { action:function(){ return itunes._multiExists([ UIAQuery.iTunes.OVERLAY, UIAQuery.iTunes.Tabs.MUSIC.isSelected() ])   || itunes._existsAndNotExists(UIAQuery.iTunes.BackTo.MUSIC, UIAQuery.navigationBars('Top Charts'));  } };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.MOVIES]    = { action:function(){ return itunes._multiExists([ UIAQuery.iTunes.OVERLAY, UIAQuery.iTunes.Tabs.MOVIES.isSelected() ])  || itunes._existsAndNotExists(UIAQuery.iTunes.BackTo.MOVIES, UIAQuery.navigationBars('Top Charts'));  } };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.TV_SHOWS]  = { action:function(){ return itunes._multiExists([ UIAQuery.iTunes.OVERLAY, UIAQuery.iTunes.Tabs.TV_SHOWS.isSelected() ])|| itunes._existsAndNotExists(UIAQuery.iTunes.BackTo.TV_SHOWS, UIAQuery.navigationBars('Top Charts'));  } };

    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.MUSIC]            = { action:function(){ return itunes._existsAndNotExists(UIAQuery.navigationBars('Music'), UIAQuery.iTunes.OVERLAY); } };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.MOVIES]           = { action:function(){ return itunes._existsAndNotExists(UIAQuery.navigationBars('Movies'), UIAQuery.iTunes.OVERLAY); } };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.TV_SHOWS]         = { action:function(){ return itunes._existsAndNotExists(UIAQuery.navigationBars('TV Shows'), UIAQuery.iTunes.OVERLAY); } };

    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.SEARCH_RESULTS]   = { action:function(){ return itunes.exists(UIAQuery.navigationBars('Search')); } };

} else {
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.MUSIC]     = { action:itunes.exists, options:UIAQuery.iTunes.BackTo.MUSIC };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.MOVIES]    = { action:itunes.exists, options:UIAQuery.iTunes.BackTo.MOVIES };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.Detail.TV_SHOWS]  = { action:itunes.exists, options:UIAQuery.iTunes.BackTo.TV_SHOWS };

    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.MUSIC]            = { action:itunes.exists, options:UIAQuery.navigationBars('Music') };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.MOVIES]           = { action:itunes.exists, options:UIAQuery.navigationBars('Movies') };
    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.TV_SHOWS]         = { action:itunes.exists, options:UIAQuery.navigationBars('TV Shows') };

    itunes.NAVIGATION_VIEWS[UIStateDescription.iTunes.SEARCH_RESULTS]   = { action:function(){ return itunes._multiExists([ UIAQuery.iTunes.SEARCH_CONTAINER.andThen('Search'), UIAQuery.iTunes.Segments.ALL ]); } };
}

// Defines iTunes Navigation
itunes.navigation = new UIANavigation(itunes, itunes.NAVIGATION_VIEW_TRANSITIONS, itunes.NAVIGATION_VIEWS);

/**
* Return description of current UI state. See iTunes UIStateDescription constants
* for possible values. Any critia for defining a state should be very exact so
* there is no confusion on state. We should always throw if we cannot determine state.
*
* Expected starting states: Works for any UI state.
*
* @returns {string} Description of current UI state from a list
* of possible constants contained in Safari UIStateDescription.
*
* @throws If cannot determine state.
*/
itunes.currentUIState = function currentUIState() {
    var currentUIState = this.navigation.getCurrentState() || 'UNKNOWN STATE';
    if (currentUIState === 'UNKNOWN STATE') {
        throw new UIAError('Could not determine iTunes state');
    }
    return currentUIState;
}

/**
 * Gets desired waiter
 *
 * Required Starting State: N/A. Not UI dependent.
 *
 * @param {string} waiterID - ID of waiter to return. Comes from a list
 * of possible constants contained in iTunes WaiterType.
 *
 * @returns waiter object
 *
 * @throws if passed waiterId does not match a predefined
 *          waiter
 */
itunes.createWaiterForID = function createWaiterForID(waiterId) {
    switch (waiterId) {
        case itunes.WaiterType.UI_LOAD:
            return UIAWaiter.withPredicate(
                'ViewDidDisappear',
                'controllerClass == "SKUILoadingDocumentViewController"'
            );
        case itunes.WaiterType.ACCOUNT_NOT_YET_BEEN_USED_ALERT:
            return UIAWaiter.withPredicate(
                'ViewDidAppear',
                'controllerTitle = "This Apple ID has not yet been used in the iTunes Store."'
            );
        case itunes.WaiterType.FIRST_SIGN_IN_ALERT:
            return UIAWaiter.withPredicate(
                'ViewDidAppear',
                'controllerTitle = "Sign In"'
            );
        case itunes.WaiterType.SIGN_IN_ALERT:
            return UIAWaiter.withPredicate(
                'ViewDidAppear',
                'controllerTitle = "Sign In to iTunes Store"'
            );

        case itunes.WaiterType.SIGN_OUT_ALERT:
            return UIAWaiter.withPredicate(
                'ViewDidAppear',
                'controllerTitle = "Apple ID"'
            );
        default:
            throw new UIAError('No waiter exists for waiterID: %0'.format(waiterID));
    }
}

/**
* Navigation function to get to the top level of any tab.
*
* Expected starting states: Works for any UI state.
*
* @param {object} (Optional) tabName - the top level tab to be in
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state.
*/
itunes.getToTopLevelTab = function getToTopLevelTab(tabName) {
    this.launch();

    this._exitOverlay(); // applicable only to iPads
    this.tapIfExists(UIAQuery.DONE_BUTTON);
    this.tapIfExists(UIAQuery.CANCEL_BUTTON);
    this.tapIfExists(UIAQuery.CONTINUE_BUTTON);
    this.dismissPopovers();

    // Default to MUSIC if no tabName is provided
    if (!tabName || tabName == UIStateDescription.iTunes.MUSIC) {
        this.tap(UIAQuery.iTunes.Tabs.MUSIC);
        this.tapIfExists(UIAQuery.iTunes.Segments.FEATURED);
        this.waitUntilPresent(UIAQuery.iTunes.SIGN_IN_BUTTON.orElse(UIAQuery.iTunes.SIGN_OUT_BUTTON), 5);

    } else if (tabName == UIStateDescription.iTunes.MOVIES) {
        this.tap(UIAQuery.iTunes.Tabs.MOVIES);
        this.taptapIfExists(UIAQuery.iTunes.Segments.FEATURED);
        this.waitUntilPresent(UIAQuery.iTunes.SIGN_IN_BUTTON.orElse(UIAQuery.iTunes.SIGN_OUT_BUTTON), 5);

    } else if (tabName == UIStateDescription.iTunes.TV_SHOWS) {
        this.tap(UIAQuery.iTunes.Tabs.TV_SHOWS);
        this.taptapIfExists(UIAQuery.iTunes.Segments.FEATURED);
        this.waitUntilPresent(UIAQuery.iTunes.SIGN_IN_BUTTON.orElse(UIAQuery.iTunes.SIGN_OUT_BUTTON), 5);

    // iPhone-Only Tabs

    } else if (tabName == UIStateDescription.iTunes.SEARCH) {
        this.tap(UIAQuery.iTunes.Tabs.SEARCH);

    } else if (tabName == UIStateDescription.iTunes.MORE) {
        for (var i=0; i < 2; i++) {
            this.tap(UIAQuery.iTunes.Tabs.MORE);
        }

    // iPad-Only Tabs

    } else if (tabName == UIStateDescription.iTunes.TOP_CHARTS) {
        this.tap(UIAQuery.iTunes.Tabs.SEARCH);

    } else if (tabName == UIStateDescription.iTunes.GENIUS) {
        this.tap(UIAQuery.iTunes.Tabs.SEARCH);

    } else if (tabName == UIStateDescription.iTunes.PURCHASED) {
        this.tap(UIAQuery.iTunes.Tabs.SEARCH);


    } else {
        throw new UIAError("Not a valid top level tab that is found in either iPhones and iPads: '%0'".format(tabName));
    }
}



/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
* Navigate to Music, select the first entry in New Music, and play a sample clip
*
* Expected starting states: Works for any UI state.
*
* @param {object} options
* @param {array} options.actions - Array of actions. i.e. buttons to press on
*              the view.
* @param {string[]} options.validateSongs - If set, contains an
*              identifying song substring to match against after a control
*              button has been pressed. This match is a 'contains' match.
*              e.g. ['Bob'] would match on 'Bob Marley's greatest hits'.
*              Array size must be same as 'actions' array. Array can contain
*              null elements if no validation is desired on an action.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state, or failed to open the song sample.
*/
itunes.playSampleMusic = function playSampleMusic(options) {
    options = UIAUtilities.defaults(options, {
        actions:            [],
        validateSongs:      null,
    });

    this.getToTopLevelTab(UIStateDescription.iTunes.MUSIC);
    this.tap('See All');
    this.tap(UIAQuery.query('SKUICollectionView').andThen(UIAQuery.buttons()));

    var musicCell = UIAQuery.tableCells().beginsWith('1, ');
    this.scrollToVisible(musicCell.andThen(UIAQuery.buttons()))
    this.tap(musicCell);
}

/**
* Navigate to Movies, select the first entry in New Movies, and play a trailer clip
*
* Expected starting states: Works for any UI state.
*
* @param {object} options
* @param {array} options.actions - Array of actions. i.e. buttons to press on
*              the view.
* @param {string[]} options.validateMovies - If set, contains an
*              identifying song substring to match against after a control
*              button has been pressed. This match is a 'contains' match.
*              e.g. ['Bob'] would match on 'Bob Marley's greatest hits'.
*              Array size must be same as 'actions' array. Array can contain
*              null elements if no validation is desired on an action.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state, or failed to open the song sample.
*/
itunes.playSampleMovie = function playSampleMovie(options) {
    options = UIAUtilities.defaults(options, {
        actions:            [],
        validateMovies:     null,
    });

    this.getToTopLevelTab(UIStateDescription.iTunes.MOVIES);
    this.tap('See All');
    this.tap(UIAQuery.query('SKUICollectionView').andThen(UIAQuery.buttons()));
    this.tap(UIAQuery.tableCells().beginsWith('Trailer, '));
}

/**
* Navigate to TV Shows, select the first entry in Latest TV Episodes, and play a sample clip
*
* Expected starting states: Works for any UI state.
*
* @param {object} options
* @param {array} options.actions - Array of actions. i.e. buttons to press on
*              the view.
* @param {string[]} options.validateTVShows - If set, contains an
*              identifying TV show substring to match against after a control
*              button has been pressed. This match is a 'contains' match.
*              e.g. ['Bob'] would match on 'Bob Marley's greatest hits'.
*              Array size must be same as 'actions' array. Array can contain
*              null elements if no validation is desired on an action.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state, or failed to open the song sample.
*/
itunes.playSampleTVShow = function playSampleTVShow(options) {
    options = UIAUtilities.defaults(options, {
        actions:            [],
        validateTVShows:    null,
    });

    this.getToTopLevelTab(UIStateDescription.iTunes.TV_SHOWS);
    this.tap('See All');
    this.tap(UIAQuery.query('SKUICollectionView').andThen(UIAQuery.buttons()));
    this.tap(UIAQuery.buttons().beginsWith('Play video'));
}



/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
* Navigate to Music, scroll down to bottom of view and sign in to an iTunes account
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state, or failed to sign into an iTunes account
*/
itunes.signIn = function signIn(options) {
    if (! options.username) {
        throw new UIAError("Username for signing into iTunes cannot be blank");
    } else if (! options.password) {
        throw new UIAError("Password for signing into iTunes cannot be blank");
    }

    this.getToTopLevelTab();

    if ((! this.exists(UIAQuery.iTunes.SIGN_IN_BUTTON)) && this.exists(UIAQuery.iTunes.SIGN_OUT_BUTTON)) {
        var buttonName = this.inspectElementKey(UIAQuery.iTunes.SIGN_IN_BUTTON, 'name')
        throw new UIAError("Device is already signed into iTunes, button is labeled '%0'".format(buttonName), {identifier:"Device is already signed into iTunes"});
    }

    // UIA2 is currently unable to scroll to the Sign In button so this is the workaround - see <rdar://problem/23993222> [UIA2][iTunes] Unable to scroll to Sign In/Out button in iTunes
    for (var i=0; i<6; i++) {
        if (!this.exists(UIAQuery.iTunes.SIGN_IN_BUTTON.isVisible())) {
            this.drag(UIAQuery.query("SKUICollectionView").last(), {toOffset: {x: 0.50, y: 0.20}, fromOffset: {x: 0.50, y: 0.80}});
        }
    }

    this.handlingAlertsInline(UIAQuery.iTunes.Alerts.ACCOUNT_NOT_YET_BEEN_USED.orElse(UIAQuery.iTunes.Alerts.FIRST_SIGN_IN).orElse(UIAQuery.iTunes.Alerts.SIGN_IN), function() {
        // Tap the Sign In button
        var firstSignInAlertWaiter = this.createWaiterForID( this.WaiterType.FIRST_SIGN_IN_ALERT );
        this.tap(UIAQuery.iTunes.SIGN_IN_BUTTON);

        // Tap the first Sign In alert
        if (! firstSignInAlertWaiter.wait(15)) {
            throw new UIAError('Did not encounter prompt for selecting how to log in');
        }
        var signInAlertWaiter = this.createWaiterForID( this.WaiterType.SIGN_IN_ALERT );
        var app = target.activeApp();
        app.tap('Use Existing Apple ID');

        // Enter the credentials in the second alert
        if (! signInAlertWaiter.wait(15)) {
            throw new UIAError('Did not encounter prompt for iTunes credentials');
        }
        var usernameField = UIAQuery.iTunes.Alerts.SIGN_IN.andThen(UIAQuery.textFields().topmost());
        var passwordField = UIAQuery.iTunes.Alerts.SIGN_IN.andThen(UIAQuery.secureTextFields().bottommost());
        app.enterText(usernameField, options.username);
        app.enterText(passwordField, options.password);

        // Tap OK and wait to see if an "Account not yet been used" alert appears
        var accountNotYetBeenUsedAlertWaiter = this.createWaiterForID( this.WaiterType.ACCOUNT_NOT_YET_BEEN_USED_ALERT );
        app.tap(UIAQuery.iTunes.Alerts.SIGN_IN.andThen('OK'));

        if (accountNotYetBeenUsedAlertWaiter.wait(10)) {
            UIALogger.logMessage("Encountered the 'Account not yet been used' alert; proceeding to walk through iTunes account setup");
            this._handleFirstTimeSignIn();
        }

        if (! this.waitUntilPresent(UIAQuery.iTunes.SIGN_OUT_BUTTON, 10)) {
            throw new UIAError("The Sign-Out button is not visible; failed to sign into iTunes", {identifier:"Failed to sign into iTunes"});
        }
    });
}

/**
* Walk through the EULA and Payment Information views after the first sign-in to iTunes
*
* Expected starting states: UIAQuery.iTunes.Alerts.ACCOUNT_NOT_YET_BEEN_USED is true (the alert is showing)
*
* @returns None.
*
* @throws If we failed to walk through the EULA and Payment Information views
*/
itunes._handleFirstTimeSignIn = function _handleFirstTimeSignIn() {
    this.handlingAlertsInline(UIAQuery.iTunes.Alerts.ACCOUNT_NOT_YET_BEEN_USED, function() {
        // Tap the Review button in the alert
        target.activeApp().tap("Review");

        // Tap through the EULA and agree
        this.tap("Next");
        this.tap("Agree");

        // Fill out the Title for the user (Mr, Ms, Dr)
        this.tap("Title");
        this.setPickerValues(UIAQuery.pickerWheels(), ['Dr.']);
        this.tap("Done");
        this.tap("Next");

        // Tap done to get back to Music view
        this.tap(UIAQuery.NAV_BAR_DONE_BUTTON);
    });
}

/**
* Navigate to Music, scroll down to bottom of view and sign out of an iTunes account
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If we were unable to transition from some starting state to
*           desired tab state, or failed to sign out of an iTunes account
*/
itunes.signOut = function signOut(options) {
    this.getToTopLevelTab();

    if ((! this.exists(UIAQuery.iTunes.SIGN_OUT_BUTTON)) && this.exists(UIAQuery.iTunes.SIGN_IN_BUTTON)) {
        throw new UIAError("Device is not signed into iTunes yet", {identifier:"Device is not signed into iTunes yet"});
    }

    // UIA2 is currently unable to scroll to the Sign Out button so this is the workaround - see <rdar://problem/23993222> [UIA2][iTunes] Unable to scroll to Sign In/Out button in iTunes
    if (! this.exists(UIAQuery.iTunes.SIGN_OUT_BUTTON.isVisible())) {
        for (var i=0; i<4; i++) {
            this.drag(UIAQuery.query("SKUICollectionView").last(), {toOffset: {x: 0.50, y: 0.20}, fromOffset: {x: 0.50, y: 0.80}});
        }
    }

    this.scrollToVisible(UIAQuery.iTunes.SIGN_OUT_BUTTON);
    this.handlingAlertsInline(UIAQuery.iTunes.Alerts.SIGN_OUT, function() {
        // Tap Sign Out button
        var signOutAlertWaiter = this.createWaiterForID( this.WaiterType.SIGN_OUT_ALERT );
        this.tap(UIAQuery.iTunes.SIGN_OUT_BUTTON);

        // Tap to confirm signout
        if (! signOutAlertWaiter.wait(15)) {
            throw new UIAError('Did not encounter prompt for confirming sign out');
        }
        target.activeApp().tap(UIAQuery.iTunes.Alerts.SIGN_OUT.andThen('Sign Out'));
    });

    if (! this.waitUntilPresent(UIAQuery.iTunes.SIGN_IN_BUTTON, 10)) {
        throw new UIAError("The Sign-In button is not visible; failed to sign out of iTunes", {identifier:"Failed to sign out of iTunes"});
    }
}
