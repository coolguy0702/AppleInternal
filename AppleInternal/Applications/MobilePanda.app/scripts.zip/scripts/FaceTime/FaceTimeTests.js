load('UIATesting.js');
load('UIASemaphore.js');
load('FaceTime.js');
load('Settings+FaceTime.js');
load('UIAUtility.js');

UIAUtilities.assert(
    typeof FaceTimeTests === 'undefined',
    'FaceTimeTests has already been defined.'
);

var THUMPER_PAIR_WITH_SEMAPHORE = false; 

/** @namespace **/
var FaceTimeTests = {
    /**
    * Test part of thumper suite sets up the settings for a primary device
    *
    * @targetApps Preferences, FaceTime   
    *     
    * @param {object} args - Test arguments
    *
    */
    enableThumperSettingsPrimary: function enableThumperSettingsPrimary(args) {
        args = UIAUtilities.defaults(args, {
        });
        settings.launch();
        settings.enableThumperSettingsPrimary(); 
        //validation of settings
    },

    /**
    * Test part of thumper suite pairs a primary device with the passcode provided from,
    * a secondary thumper device.
    *
    * @targetApps Preferences, SpringBoard, FaceTime
    *
    * @param {object} args                                 - Test arguments
    * @param {string} [args.semaphoreUUID=null]            - UUID to handle semaphore passcode send and receive
    * @param {string} [args.phoneNumber="0000000000"]      - Phone number to be stored with semaphore
    * @param {timeout}[args.timeout = 300]                 - Timeout duration for setting semaphore (for passcode and number)
    * @param {string} [args.passcode ="123456"]            - Passcode to be used to pair thumper devices
    */
    pairThumperPrimaryWithPasscode: function pairThumperPrimaryWithPasscode(args) {
        args = UIAUtilities.defaults(args, {
            semaphoreUUID: null,
            phoneNumber: '0000000000',
        });

        UIALogger.logMessage(
            'Passcode Pair Args Semaphore UUID: %0; \
             number: %1;'.format(args.semaphoreUUID,args.phoneNumber)
        );

        if (THUMPER_PAIR_WITH_SEMAPHORE) {
            //get the semaphore data
            try {
                settings.pairThumperPrimaryWithPasscode(args.semaphoreUUID,args.phoneNumber);
            } finally {
                //lock semaphore data in the case of future passcode use on same sending device
                UIASemaphore.lock(args.semaphoreUUID);
            }
        } else {
            var ENTER_PASSCODE_QUERY = UIAQuery.staticTexts("Wi-Fi Calling");
            springboard.handlingAlertsInline(ENTER_PASSCODE_QUERY, function() {
                settings.pairThumperPrimaryWithPasscode(null,args.phoneNumber,args.passcode);
            });
        }
    },

    /**
    * Test part of thumper suite sets up the settings for a primary device
    *
    * @targetApps Preferences, FaceTime
    *
    * @param {object} args                                 - Test arguments
    * @param {string} [args.semaphoreUUID=null]            - UUID to handle semaphore passcode send and receive
    * @param {string} [args.phoneNumber="0000000000"]      - Phone number to be stored with semaphore 
    * @param {timeout}[args.timeout=300]                  - Timeout duration for setting semaphore (for passcode and number)
    */
    requestThumperPasscodeFromSecondary: function requestThumperPasscodeFromSecondary(args) {
        args = UIAUtilities.defaults(args, {
            semaphoreUUID: null,
            phoneNumber: '0000000000',
            timeout: 300,
        });

        settings.launch();
        if (THUMPER_PAIR_WITH_SEMAPHORE) {
            settings.requestPairFromSecondayDevice(args.semaphoreUUID,args.timeout);
        }
        else {
            settings.requestPairFromSecondayDevice(null,args.timeout);
        }
    },


    /**
    * Have a Secondary Device verify the thumper pair to a primary device (wait until inactive)
    *
    * @targetApps Preferences, FaceTime
    *
    * @throws If Validation activated prompt is not apparent. "Use your ** account to make and receive calls..."
    * @throws If Timed out waiting for activation of wifi calling
    */
    validateThumperPairSecondary: function validateThumperPairSecondary(args) {
        args = UIAUtilities.defaults(args, {
        });

        settings.launch();
        settings.validateThumperPairSecondary();
    },

    /**
    * Test make a Wi-Fi based secondary device hand off call to a particular number in arguments
    *
    * @targetApps Preferences, FaceTime        
    * @param {object} args                         - Test arguments
    * @param {string} [args.phoneNumber = "411"]   - Phone number to be dialed as part of the hand off call
    *
    */
    makeThumperCall: function makeThumperCall(args) {
        args = UIAUtilities.defaults(args, {
            phoneNumber: '411',
        });

        facetime.launch();
        facetime.makeThumperCallToNumber(args.phoneNumber);

        //verify that call is incoming
    },


    /**
     * Wait for a call from a specific contact.
     *
     * @targetApps FaceTime, SpringBoard
     * @param {object} args                       - Test Arguments
     * @param {object} [args.contact="{phoneNumber: 411}"] - Dictionary containing acceptable contact information to validate the call
     * @param {string} [args.contact.phoneNumber="411"] - Phone number (e.g. "408-867-5309")
     * @param {string} [args.contact.email = ""]  - Email address, i.e. Apple ID (e.g. "johnnyappleseed@icloud.com")
     * @param {string} [args.contact.name = ""]   - Name, usually resolved by AddressBook Framework (e.g. "Johnny Appleseed")
     * @param {int}      [args.timeout=200]       - Duration to wait for incoming call
     * @param {boolean}  [args.answer=true]       - Should answer the incoming call
     * @param {string}   [args.callState="FaceTime Audio"] - State that the incoming call should be throws error if not matching
     */
    waitToReceiveCall: function waitToReceiveCall(args) {
        args = UIAUtilities.defaults(args, {
            contact: {
                        phoneNumber: '411',
                        email: '',
                        name: '',
                     },
            timeout: 200,
            answer: true,
            callState: 'FaceTime Audio',
        });

        if (!springboard.waitForCallFromContact(args.contact, args.answer, args.callState, args.timeout)) {
            throw new UIAError('Waited to receive call from call and timed out');
        }
    },

    /**
    * Perform a hand off of a Thumper Call.
    *
    * @targetApps FaceTime, Springboard
    * @param {object}  args                              - Test arguments 
    * @param {string}  [args.contact="411"]              - Contact of call to handoff (Phone Number {'411'}, AppleID {'appleid@icloud.com'}, or Contact Name {'Johnny Appleseed'} 
    * @param {boolean} [args.beginLocked=true]           - If we start the test off in a locked ('Slide to Unlock') state
    */
    handOffThumperCall: function handOffThumperCall(args) {
        args = UIAUtilities.defaults(args, {
            contact: '411',
            beginLocked: true,
        });

        //lock device if we are expecting it to start out locked
        if (args.beginLocked) {
            target.systemApp().lock();
        }
        
        //TODO: Validate Arguments (if necessary)
        facetime.handOffThumperCall({phoneNumber: args.contact});
    },

    /**
    * Wait for a hand off of a Thumper Call.
    *
    * @targetApps FaceTime, Springboard
    * @param {object}  args                              - Test arguments 
    * @param {string}  [args.contact="411"]              - Contact of call to handoff (Phone Number {'411'}, AppleID {'appleid@icloud.com'}, or Contact Name {'Johnny Appleseed'} 
    * @param {int}     [args.timeout=200]                - Seconds to wait for incoming call
    */
    waitForThumperHandoff: function waitForThumperHandoff(args) {
        args = UIAUtilities.defaults(args, {
            contact: '411',
            timeout: 200,
        });

        if (!facetime.waitForThumperHandoff(args.timeout)) {
            throw new UIAError('Waited to hand-off call and timed out, No hand-off Occurred');
        }
    },

    /**
    * Places a FaceTime call to another device and verifies the connection stays active.
    *
    * @targetApps FaceTime
    *
    * @param {object} args Test arguments
    * @param {string} [args.contactName="newFTContact"]     - The contact to search for
    * @param {null|string} [args.email=""]                  - Email address to use if the contact needs to be created. Required if phone is not set
    * @param {null|string} [args.phone=""]                  - Phone number to use if the contact needs to be created. Required if email is not set
    * @param {int} [args.callLength=45]                     - Number of seconds the call should stay active
    * @param {bool} [args.shouldEndCall=true]               - Whether we should end the call ourselves
    * @param {bool} [args.dumpLogs=false]                   - Dump logs on failure [Not implemented yet]
    * @param {bool} [args.audioCall=false]                  - Make an audio call instead of a video one
    */
    placeCall: function placeCall(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            contactName:            'newFTContact',

            // Optional parameters
            email:                  null,
            phone:                  null,
            callLength:             '45',
            shouldEndCall:          true,
            dumpLogs:               false,
            audioCall:              false,
        }, true);

        // TODO Verify parameters
        // TODO e.g. reject contactName === ''?

        contactName = args.contactName;
        facetime.launch();
        facetime.call(contactName, args);
    },

    /**
    * Places FaceTime call to FaceTimeBot and receives a call back.
    *
    * @targetApps FaceTime
    *
    * @param {object} args Test arguments
    * @param {string} [args.contactName="FaceTimeBot"]      - The contact to search for - for compatibility
    * @param {null|string} [args.email=""]                  - Email address to use if FaceTimeBot email is not provided
    * @param {null|string} [args.phone=""]                  - Phone number to use if FaceTimeBot email is not provided
    * @param {integer} [args.callLength=30]                 - Number of seconds the call should stay active
    * @param {bool} [args.shouldEndCall=true]               - Whether we should end the call ourselves
    * @param {bool} [args.dumpLogs=false]                   - Dump logs on failure [Not implemented yet]
    * @param {bool} [args.audioCall=false]                  - Make an audio call instead of a video one
    * @param {integer} [args.callbackTimeout=120]           - Timeout for getting a callback from FaceTimeBot
    */
    callAndReceive: function callAndReceive(args) {
        args = UIAUtilities.defaults(args, {
            // Required parameters:
            contactName:            'FaceTimeBot',

            email:                  null,
            phone:                  null,
            callLength:             30,
            shouldEndCall:          true,
            dumpLogs:               false,
            audioCall:              false,
            callbackTimeout:        120,
        }, true);
        contactName = args.contactName;
        // Get email address of recipient
        var address = facetime.getEmailFromFile();
        // Fill in email address that we get from AA 
        args.email = address;
        UIALogger.logMessage('An email to call: %0'.format(args.email));
        facetime.launch();
        facetime.call(contactName, args);
        facetime.receiveIncomingCall(args);
    },
}   
