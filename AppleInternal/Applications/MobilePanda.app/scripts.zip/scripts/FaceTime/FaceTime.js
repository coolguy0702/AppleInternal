load('UIAApp.js');
load('UIAUtility.js')
load('Settings.js');

load('SpringBoard.js');
load('SpringBoard+InCallServices.js');

load('Contacts.js');

UIAUtilities.assert(
    typeof facetime === 'undefined',
    'facetime has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common FaceTime queries */
/** @namespace */
UIAQuery.FaceTime = {

    /** Visible navigation bars. */
    NAVIGATION_BARS: UIAQuery.navigationBars(),

    /** Visible search bars. */
    SEARCH_BAR: UIAQuery.searchBars().isVisible(),

    /** Segmented Control between Audio and Video */
    SEGMENTED_CONTROL: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.segmentedControls()),

    /** Edit Button for table lists. */
    EDIT_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Edit')),

    /** Cancel button on Navigation bar */
    CANCEL_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Cancel')),

    /** Done button visible during EDIT state. */
    EDIT_DONE_BUTTON: UIAQuery.navigationBars('FaceTime').isVisible().andThen(UIAQuery.buttons('Done')),

    /** Delete button visible during EDIT state */
    DELETE_BUTTON: UIAQuery.buttons('Delete').isVisible(),

    /** Video call button visible in contact search results */
    VIDEO_CALL_BUTTON: UIAQuery.query('_UIVisualEffectContentView').andThen(UIAQuery.buttons('Video').isEnabled()),

    /** Audio call button visible in contact search results */
    AUDIO_CALL_BUTTON: UIAQuery.query('_UIVisualEffectContentView').andThen(UIAQuery.buttons('Audio').isEnabled()),

    /** Add Call Button used to look through contacts. */
    ADD_CALL_BUTTON: UIAQuery.navigationBars().isVisible().andThen(UIAQuery.buttons('Add')),

    /** Add Contact button */
    ADD_CONTACT_BUTTON: UIAQuery.query('PHFaceTimePeoplePickerViewController_RecipientTextView').andThen(UIAQuery.buttons('Add Contact')),

    /** During ADD_CALL state the all contacts list presents itself. */
    ALL_CONTACTS_NAVIGATION_BAR: UIAQuery.navigationBars('Contacts').isVisible(),

    /** Recipient Test Field */
    RECIPIENT_TEXT_FIELD: UIAQuery.query('PHFaceTimePeoplePickerViewController_RecipientTextView').andThen(UIAQuery.textFields()),

    /** Info Navigation Bar appears when clicking call history or Contact info/edit */
    INFO_NAVIGATION_BAR: UIAQuery.navigationBars('FaceTime').isVisible().andThen(UIAQuery.buttons('FaceTime')),

    /** Cancel/Done Add Contact button */
    CANCEL_DONE_ADD_CONTACT_BUTTON: UIAQuery.navigationBars('Contacts').andThen(UIAQuery.buttons('Cancel').orElse(UIAQuery.buttons('Done'))),

    /** Cancel Search for a contact button */
    CANCEL_CONTACT_SEARCH_BUTTON: UIAQuery.query('UISearchBar').andThen(UIAQuery.buttons('Cancel')),

    /** Disable Video button */
    DISABLE_VIDEO_BUTTON: UIAQuery.buttons('DisableVideoButton'),

    /** Mute Audio button */
    MUTE_AUDIO_BUTTON: UIAQuery.buttons('MuteAudioButton'),

    /** Contacts Search view */
    CONTACT_SEARCH_DONE_BUTTON: UIAQuery.navigationBars('Contacts').andThen(UIAQuery.buttons('Done')),

    /** Cancel Edit Contact button */
    CANCEL_EDIT_CONTACT_BUTTON: UIAQuery.query('PhoneContentView').andThen(UIAQuery.buttons('Cancel')),

    /** Done Edit Contact button */
    DONE_EDIT_CONTACT_BUTTON: UIAQuery.query('PhoneContentView').andThen(UIAQuery.buttons('Done')),

    /** More Options button */
    MORE_OPTIONS_BUTTON: UIAQuery.buttons('ExpandButton'),

    /** Video Calling View */
    CALLING_VIDEO_VIEW: UIAQuery.query('PHCallParticipantsView').andThen(UIAQuery.staticTexts('PHSingleCallParticipantLabelView_StatusLabel')).isVisible(),

    /** End Call Button for Video and Audio */
    JOIN_LEAVE_BUTTON: UIAQuery.buttons('JoinLeaveButton').orElse(UIAQuery.buttons('End call')),
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other App specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the App   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to FaceTime */
/** @namespace */
UIStateDescription.FaceTime = {
    /** Calling Video */
    CALLING_VIDEO:          'Calling Video',

    /** Video State */
    VIDEO_CALL:             'Video',

    /** Audio State */
    AUDIO_CALL:             'Audio',

    /** Add Call State */
    ADD_CALL:               'Add Call',

    /** Search State */
    SEARCH_CONTACT:         'Search Contact',

    /** Contact Info State */
    CONTACT_INFO:           'Contact Info',

    /** Add Contact state */
    ADD_CONTACT:            'Add Contact',

    /** Edit Recents List State */
    EDIT_RECENTS:           'Edit Recents',

    /** More Call Options State */
    MORE_CALL_OPTIONS:      'More Call Options',

    /** Select Contact State */
    SELECT_CONTACT:         'Select Contact',

    /** Edit Contact State */
    EDIT_CONTACT:           'Edit Contact',

    /** Ready To Call State */
    READY_TO_CALL:          'Ready To Call',

    /** Initial State */
    INITIAL:                'Initial',
};

/**
 * @namespace {UIAApp} facetime
 */
var facetime = target.appWithBundleID('com.apple.facetime');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the App is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
* Get Current UI state of FaceTime App.
* States can be : INITIAL, ADD_CALL, EDIT_CONTACT, MORE_CALL_OPTIONS, 
* AUDIO_CALL, CONTACT_INFO, SEARCH_CONTACT, CONTACTS, EDIT_RECENTS, SELECT_CONTACT,
* VIDEO_CALL, READY_TO_CALL
*
* @overrideID Current UI State
* @returns {string} - The current state of the UI in the FaceTime App
*/
facetime.currentUIState = function currentUIState() {
    if (this.exists(UIAQuery.FaceTime.ADD_CALL_BUTTON)) {
        return UIStateDescription.FaceTime.INITIAL;
    } else if (this.exists(UIAQuery.FaceTime.ADD_CONTACT_BUTTON)) {
        return UIStateDescription.FaceTime.ADD_CALL;
    } else if (this.exists(UIAQuery.FaceTime.DISABLE_VIDEO_BUTTON)) {
        return UIStateDescription.FaceTime.MORE_CALL_OPTIONS;
    } else if (this.exists(UIAQuery.FaceTime.MORE_OPTIONS_BUTTON)) {
        return UIStateDescription.FaceTime.VIDEO_CALL;
    } else if (this.exists(UIAQuery.query('PHAudioCallControlsView'))) {
        return UIStateDescription.FaceTime.AUDIO_CALL;
    } else if (this.exists(UIAQuery.FaceTime.AUDIO_CALL_BUTTON) || 
                this.exists(UIAQuery.FaceTime.VIDEO_CALL_BUTTON)) {
        return UIStateDescription.FaceTime.READY_TO_CALL;
    } else if (this.exists(UIAQuery.query('CNContactHeaderDisplayView'))) {
        return UIStateDescription.FaceTime.CONTACT_INFO;
    } else if (this.exists(UIAQuery.FaceTime.CANCEL_CONTACT_SEARCH_BUTTON)) {
        return UIStateDescription.FaceTime.SEARCH_CONTACT;
    } else if (this.exists(UIAQuery.FaceTime.CANCEL_EDIT_CONTACT_BUTTON)) {
        return UIStateDescription.FaceTime.EDIT_CONTACT;
    } else if (this.exists(UIAQuery.FaceTime.EDIT_DONE_BUTTON)) {
        return UIStateDescription.FaceTime.EDIT_RECENTS;
    } else if (this.exists(UIAQuery.FaceTime.ALL_CONTACTS_NAVIGATION_BAR)) {
        return UIStateDescription.FaceTime.SELECT_CONTACT;
    } else if (this.exists(UIAQuery.FaceTime.CALLING_VIDEO_VIEW)) {
        return UIStateDescription.CALLING_VIDEO;
    } else {
        throw new UIAError('Unrecognized UI State of Application');
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the App      */
/*                                                                             */
/*******************************************************************************/

/**
* Get Current UI state of FaceTime App.
* States can be : INITIAL, ADD_CALL, EDIT_CONTACT, MORE_CALL_OPTIONS, 
* AUDIO_CALL, CONTACT_INFO, SEARCH_CONTACT, CONTACTS, EDIT_RECENTS, SELECT_CONTACT,
* VIDEO_CALL, READY_TO_CALL
*
* Expected starting states: Works for any UI state.
*
* @overrideID Current UI State
* @returns None.
*/
facetime.getToInitialUIState = function getToInitialUIState() {
    var currentState = this.currentUIState();
    UIALogger.logMessage('Restoring UI State: Currently in ' + currentState + '.');
    if (currentState === UIStateDescription.FaceTime.INITIAL) {
        return;
    }
    if (currentState === UIStateDescription.FaceTime.CONTACT_INFO) {
        this.tap('back-nav-button');
        this.getToInitialUIState();
    } else if (currentState === UIStateDescription.FaceTime.EDIT_RECENTS) {
        this.tap(UIAQuery.FaceTime.DONE_BUTTON);
        this.getToInitialUIState();
    } else if (currentState === UIStateDescription.FaceTime.ADD_CALL) {
        this.tap(UIAQuery.FaceTime.CANCEL_BUTTON);
        this.getToInitialUIState();
    } else if (currentState === UIStateDescription.FaceTime.SELECT_CONTACT) {
        this.tap(UIAQuery.FaceTime.CANCEL_DONE_ADD_CONTACT_BUTTON);
        this.getToInitialUIState();
    } else if (currentState === UIStateDescription.FaceTime.SEARCH_CONTACT) {
        this.tap(UIAQuery.FaceTime.CANCEL_CONTACT_SEARCH_BUTTON);
        this.getToInitialUIState();
    } else if (currentState === UIStateDescription.FaceTime.EDIT_CONTACT) {
        this.tap(UIAQuery.FaceTime.CANCEL_EDIT_CONTACT_BUTTON);
        this.getToInitialUIState();
    } else {
        throw new UIAError('Could not get to the initial state. Current state: %0'.format(currentState));
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
* Attempt a Wi-Fi call from a secondary device to a device with a particular
* number
*
* Expected starting states: Works for any UI state. Auto goes back initial state.
* @overrideID Make Thumper Phone Call
*
* @param {string} phoneNumber - Phone Number to dial to initiate Thumper call
*
* @returns None.
*
* @throws  If FaceTime Audio Button doesn't exist to make a thumper.
*          If the action sheet to select to make a call from iPhone doesn't appear.
*          If we get sent into a FaceTime Audio call as apposed to a Thumper call.
*          If we were unable to make the Thumper call.
*          If the InCall Services springboard App never becomes active.
*/
facetime.makeThumperCallToNumber = function makeThumperCallToNumber(phoneNumber) {
    this.getToInitialUIState();

    //number validation (ensure that the number is only digits)
    //potentially something more in the future
    this.tap('Audio');
    this.search(phoneNumber);

    if (!this.exists('FaceTime Audio')) {
        throw new UIAError(
            'Unable to access FaceTime Audio Button \
            (Ensure that "Calls From iPhone" are enable in settings)'
        );
    }

    //tap FaceTime audio button
    this.tap('FaceTime Audio');

    //if tapping the FaceTime audio button leads you to FaceTime audio call screen then
    //something went wrong and then need to ensure that FaceTime audio is not the method of call

    var CALL_PROMPT_BUTTON = UIAQuery.actionSheets().andThen(UIAQuery.buttons().first());
    if (!this.exists(CALL_PROMPT_BUTTON)) {
        UIALogger.logError('Action sheet for prompt view did not appear. Error in attempting phone call');
    }

    if (springboard.currentInCallState() === UIStateDescription.InCall.FACETIME_AUDIO) {
        throw new UIAError('Action sheet for prompt view did not appear. Error in attempting phone call');
    }

    var callLabel = this.inspect(CALL_PROMPT_BUTTON).label
    if (callLabel === 'FaceTime Audio') {
        throw new UIAError(
            'Number not found in prompt view, would be attempting a FaceTime call.\
             (Ensure that "Calls from iPhone" are enable and paired'
        );
    }

    var CALLS_NOT_AVAILABLE = UIAQuery.alerts('iPhone Calls Not Available');

    springboard.handlingAlertsInline(CALLS_NOT_AVAILABLE, function() {
        facetime.tap(CALL_PROMPT_BUTTON);
        UIALogger.logMessage("Handling Error Alerts in Line");
        if (this.exists(CALLS_NOT_AVAILABLE)) {
            throw new UIAError(
                'Unable to make thumper call, iPhone-Secondary devices were not configured \
                to allow phone calls using this Secondary device'
            );
        }

        //inCall services verify
        var contactToVerify = {phoneNumber: phoneNumber};
        if (!springboard.waitForCallActive(contactToVerify,20)) {
            throw new UIAError('Unable verify call for caller label %0'.format(phoneNumber));
        }
    });
}

/**
* Primary Device transfer/hand-off an active thumper call from a secondary device
*
* Expected starting states: In Background Call, Or In SpringBoard InCallServices App
*
* @param {object} contact - Expected current call of the hand off refer to isActiveCall in SpringBoard+InCallServices.js
*
* @returns None.
*
* @throws If Background Thumper call was not found.
*/
facetime.handOffThumperCall = function handOffThumperCall(contact) {
    //if device is locked then check for handoff button from lock screen
    if (target.isLocked()) {

        if (target.isMainScreenOff()) {
            target.clickLock();
        }

        var CONTINUITY_BUTTON = UIAQuery.buttons('Phone').isVisible();
        var STATUS_BAR = UIAQuery.statusBars();
        var CONTINUITY_WAIT = 30;

        var sysApp = target.systemApp();
        //wait for the continuity button exists
        if (!sysApp.waitUntilPresent(CONTINUITY_BUTTON, CONTINUITY_WAIT)) {
            throw new UIAError('The Phone continuity button was not present');
        } else {
            var continuityHitPoint = sysApp.inspect(CONTINUITY_BUTTON).hitpoint
            UIALogger.logMessage("Attempting to flick hand off button.");
            sysApp.flick(CONTINUITY_BUTTON, {toQuery: STATUS_BAR, duration: 0.05});
        }
    } else {

        //check if there is an active background call to transfer over
        if (!springboard.isInBackgroundCall()) {
                //if not throw an error
            throw new UIAError('Background Call was not found, unable to transfer call over');
        }

        //hit top status bar to return
        springboard.tap(UIAQuery.InCall.STATUS_BAR)
    }

    //check the contact information of caller id to verify the correct number is listed
    if (!springboard.isActiveCall(contact)) {
        throw new UIAError('Could not verify correct contact: %0 for hand off'.format(contact.phoneNumber));
    }

    //Wait for calling hand off text
    if (!springboard.waitUntilAbsent(UIAQuery.staticTexts().contains("call handing off"), 20)) {
        throw new UIAError('Timed out waiting for handoff to complete');
    }

    if (!springboard.exists(UIAQuery.InCall.PHONE_AUDIO_CONTROL_VIEW)) {
        throw new UIAError('User Busy occurred and was unable to hand off call');
    }
}

/**
* Have a Secondary Device wait for the hand-off/transfer to a primary device (wait until inactive)
*
* Expected starting states: Works for any In Call UI state.
* @overrideID Wait for Thumper Hand-off
*
* @param {int} timeout - Seconds to wait for hand-off to occur.
*
* @returns {boolean} If wait for hand-off was successful and In Call State Disappeared.
*
* @throws  If Not In a Call.
*          If the call control sheet from InCall doesn't appear, then disappear.
*/
facetime.waitForThumperHandoff = function waitForThumperHandoff(timeout) {
    //check if there is a current call to be handed off
    //now wait for call to go into an inactive state
    if (springboard.isInBackgroundCall()) {
        //if in background call tap the status bar to return to call
        springboard.tap(UIAQuery.InCall.STATUS_BAR);
    } else if (!springboard.isInCall()) {
        throw new UIAError('Could not find call in background or foreground state.')
    }

    if (springboard.exists(UIAQuery.InCall.PHONE_AUDIO_CONTROL_VIEW)) {
        return (springboard.waitUntilAbsent(UIAQuery.InCall.PHONE_AUDIO_CONTROL_VIEW, timeout));
    } else {
        throw new UIAError('Could not find phone control view of to establish in call mode')
    }

}

/**
* Calls another device and verifies the connection stays active.
*
* @param {string} contactName - Whom to call
*
* @param {object} options - Options dictionary
* @param {null|string}      options.email      - email address used if the contact needs to be created
* @param {null|string}      options.phone      - Phone number used if the contact needs to be created and no email address is specified
* @param {int}              options.callLength - Number of seconds the call should stay active
* @param {bool}             options.shouldEndCall - Whether we should end the call ourselves
* @param {bool}             options.dumpLogs - Dump logs on failure [Not implemented yet]
* @param {bool}             options.audioCall - Make an audio call instead of a video one
*/
facetime.call = function call(contactName, options) {
    UIALogger.logMessage('FTCaller: Placing a FaceTime Call to %0'.format(contactName));

    this.getToInitialUIState();

    var callButton = options.audioCall ? UIAQuery.FaceTime.AUDIO_CALL_BUTTON : UIAQuery.FaceTime.VIDEO_CALL_BUTTON;
    var sendingCallControllerClass = options.audioCall ? 'PHAudioCallControlsViewController' : 'CNKFaceTimeInCallControlsViewController';
    var sendingCallViewWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass == "%0"'.format(sendingCallControllerClass)
    );
    UIALogger.logMessage('Adding a new call');
    this.addCall(options);

    // Initiate call
    UIAUtilities.assert(
        this.waitUntilPresent(callButton, 10.0),
        'Button for %0 call did not appear or become active'.format(options.audioCall ? 'Audio' : 'Video')
    );
    UIALogger.logMessage('Initiating %0 call'.format(options.audioCall ? 'Audio' : 'Video'));
    this.tap(callButton);
    UIAUtilities.assert(
        (sendingCallViewWaiter.wait(10.0)),
        'Failed to get to Calling state'
    );

    // Verify that the connection is established 
    if (options.audioCall) {
        UIAUtilities.assert(
            (springboard.waitUntilPresent(UIAQuery.InCall.ADD_CALL_BUTTON.isEnabled(), 20.0)),
            'Failed to establish FaceTime Audio connection'
        );
    } else {
        UIAUtilities.assert(
            (springboard.waitUntilAbsent(UIAQuery.FaceTime.CALLING_VIDEO_VIEW, 20.0)),
            'Failed to establish FaceTime Video connection'
        );
    }
    UIALogger.logMessage('FaceTime %0 connection established'.format(options.audioCall ? 'Audio' : 'Video'));

    UIALogger.logMessage('Waiting for %0 sec before ending the call'.format(options.callLength));
    UIAUtilities.assert(
        (springboard.waitUntilAbsent(UIAQuery.FaceTime.JOIN_LEAVE_BUTTON, options.callLength) == false),
        'The call has dropped unexpectedly'
    );

    if (options.shouldEndCall) {
        UIALogger.logMessage('Will try to end call now');
        // Make control panel appear on screen in Video mode
        if (!options.audioCall) {
            springboard.tap(UIAQuery.query('AXRemoteElement').andThen(UIAQuery.query('PHInCallRootView')));
        }
        springboard.tapIfExists(UIAQuery.FaceTime.JOIN_LEAVE_BUTTON);
    }
}

/**
* Receive and accept incoming FaceTime Video/Audio call 
* 
* @param {object} options - Test arguments
* @param {int}              options.callLength - Number of seconds the call should stay active
* @param {bool}             options.shouldEndCall - Whether we should end the call ourselves
* @param {bool}             options.dumpLogs - Dump logs on failure [Not implemented yet]
* @param {bool}             options.audioCall - Make an audio call instead of a video one
* @param {integer}          options.callbackTimeout - wait time for incoming call 
*/
facetime.receiveIncomingCall = function receiveIncomingCall(options) {
    var callType = options.audioCall ? 'Audio' : 'Video';
    UIALogger.logMessage('Waiting for incoming FaceTime %0 call for %1 sec'.format(callType, options.callbackTimeout));
    var incomeCallViewWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass == "%0"'.format(options.audioCall ? 'PHAudioCallViewController' : 'CNKFaceTimeInCallControlsViewController')
    );

    // Waiting for an incoming call
    if (!incomeCallViewWaiter.wait(options.callbackTimeout)) {
        // Do not fail the test as this might be caused by FaceTime bot
        UIALogger.logMessage('Failed to get a callback from FaceTime bot');
        return;
    }

    // Accept call
    UIAUtilities.assert(
        springboard.waitUntilPresent(UIAQuery.InCall.ACCEPT_BUTTON, 10.0),
        'Accept button did not appear'
    );
    UIALogger.logMessage('Accepting call...');
    springboard.tapIfExists(UIAQuery.InCall.ACCEPT_BUTTON);

    // Verify that the connection is established 
    if (options.audioCall) {
        UIAUtilities.assert(
            (springboard.waitUntilPresent(UIAQuery.InCall.ADD_CALL_BUTTON.isEnabled(), 20.0)),
            'Failed to establish FaceTime Audio connection'
        );
    } else {
        UIAUtilities.assert(
            (springboard.waitUntilAbsent(UIAQuery.FaceTime.CALLING_VIDEO_VIEW, 20.0)),
            'Failed to establish FaceTime Video connection'
        );
    }
    UIALogger.logMessage('FaceTime %0 connection established'.format(callType));

    // FaceTimeBot is supposed to end call in 20 sec
    if (!springboard.waitUntilAbsent(UIAQuery.FaceTime.JOIN_LEAVE_BUTTON, 30.0)) {
        UIALogger.logMessage('Will try to end call now');
        // Make control panel appear on screen in Video mode
        if (!options.audioCall) {
            springboard.tap(UIAQuery.query('AXRemoteElement').andThen(UIAQuery.query('PHInCallRootView')));
        }
        springboard.tapIfExists(UIAQuery.FaceTime.JOIN_LEAVE_BUTTON);
    } else {
        UIALogger.logMessage('FaceTime %0 call back dropped by FaceTimeBot'.format(callType));
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/
/**
 * Add a new call in FaceTime 
 * 
 * @param {object} options - Test arguments
 * @param {string} options.email - email address of a recipient
 */
facetime.addCall = function addCall(options) {
    var contactPickerViewWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'controllerClass == "PHFaceTimePeoplePickerViewController"'
    );
    this.tap(UIAQuery.FaceTime.ADD_CALL_BUTTON);
    UIAUtilities.assert(
        (contactPickerViewWaiter.wait(10.0)),
        'Failed to get to Contact Picker view'
    );
    this.enterText(UIAQuery.FaceTime.RECIPIENT_TEXT_FIELD, (options.email.length === 0 ? options.phone : options.email) + '\n');
}

/**
 * Read FaceTimeBot email address from file located in /tmp/Semaphore
 * 
 * @returns {string} - email address of recipient
 * @throws if failed to read from file or if it does not exist
 */
facetime.getEmailFromFile = function getEmailFromFile() {
    // Read file stored by host machine
    var facetimeBotFileName = '/tmp/Semaphore/%0.txt'.format(target.uniqueIdentifier());
    UIAUtilities.assert(
        (UIAFile.fileExists(facetimeBotFileName)),
        'File <%0> does not exist'.format(facetimeBotFileName)
    );
    var facetimeBotFile = new UIAFile(facetimeBotFileName);
    facetimeBotFile.open('r', 'unicode');
    content = facetimeBotFile.read();
    UIALogger.logMessage('File contents: %0'.format(content));
    facetimeBotFile.close();
    UIAUtilities.assert(
        (content.length > 0),
        'File <%0> is empty'.format(facetimeBotFileName)
    );
    return content;
}