load('UIAApp.js');
load('SpringBoard.js');
load('Settings.js');
load('SettingsTests.js');
load('UIASemaphore.js');

if (typeof findMy !== 'undefined') {
    if (!(findMy instanceof UIAApp)) {
        throw new UIAError("findmy has already been defined to something not an instance of UIAApp! Value: %0".format(findMy));
    }
    if (findMy.bundleID() !== 'com.apple.mobileme.fmip1') {
        var oldDefinition = findMy.bundleID();
        var findMy = target.appWithBundleID('com.apple.mobileme.fmip1');
        UIALogger.logWarning("'findMy' was redefined from '%0' to '%1'".format(oldDefinition, findMy.bundleID()));
    }
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

/** Constants for common findMy queries */
UIAQuery.FindMy = {
    /** 'Help' navigation button */
    HELP_NAV_BUTTON:        UIAQuery.navigationBars().andThen(UIAQuery.buttons('Help').isVisible()),

    /** 'Sign Out' navigation button */
    SIGN_OUT_NAV_BUTTON:    UIAQuery.navigationBars().andThen(UIAQuery.buttons('Sign Out').isVisible()),

    /** 'Sign Out' navigation button */
    ALL_NAV_BUTTON:         UIAQuery.navigationBars().andThen(UIAQuery.buttons('All')),

    /** 'Refreash' navigation button */
    REFRESH_NAV_BUTTON:     UIAQuery.navigationBars().andThen(UIAQuery.buttons('Refresh')),

    /** 'Remove' navigation button. Used for removing device from tracking. */
    REMOVE_NAV_BUTTON:      UIAQuery.navigationBars().andThen(UIAQuery.buttons('Remove')).isVisible(),

    /** 'Back' navigation button. Care should be taken as there is an invisble on iPhones.
        It is likely this will be replaced with 'All' on iPads later. */
    BACK_NAV_BUTTON:        UIAQuery.buttons("back-nav-button"),

    /** 'Tracking' action button */
    TRACKING_BUTTON:        UIAQuery.buttons('Tracking'),

    /** 'Actions' action button */
    ACTIONS_BUTTON:         UIAQuery.buttons('Actions'),

    /** 'Tracking' action button */
    MAP_OPTIONS_BUTTON:     UIAQuery.buttons('Toolbar MapOptions'),

    /** Get Directions Button */
    DIRECTIONS_BUTTON:      UIAQuery.buttons('Directions'),

    /** Play Sound Button */
    PLAY_SOUND_BUTTON:      UIAQuery.buttons('Play Sound').isVisible(),

    /** Lost Mode Button */
    LOST_MODE_BUTTON:       UIAQuery.buttons().contains('Lost Mode'),

    /** Erase Device Button */
    ERASE_DEVICE_BUTTON:    UIAQuery.buttons().andThen(UIAQuery.beginsWith('Erase i')),

    /** Notify when device found button. */
    NOTIFY_BUTTON:          UIAQuery.buttons('Notify When Found'),

    /** Grabs the devices linked with the current account.
        Use .atIndex(n) after the below to get specific device. */
    // DEVICES:                UIAQuery.tableCells().below(UIAQuery.staticTexts('All Devices')),
    DEVICES:                UIAQuery.tableCells(),

    /** No devices registered static text on no device screen. */
    NO_DEVICES_REGISTERED:  UIAQuery.staticTexts('No Devices Registered'),

    /** This devices */
    THIS_DEVICE:            UIAQuery.tableViews().andThen(UIAQuery.tableCells().contains('This i')),

    /** Button to display iPad left hand side device list */
    DEVICE_LIST_BUTTON:     UIAQuery.navigationBars('All Devices').andThen(UIAQuery.buttons('back-nav-button')),
};


/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of strings describing the possible UI states of the app   */
/*                                                                             */
/*******************************************************************************/

/** Constants for possible UI state names specific to FindMy */
UIStateDescription.FindMy = {
    /**  Login Page for App */
    LOGIN:                     'login',

    /**  Cached login Page for App */
    LOGIN_CACHED:              'login (cached)',

    /**  Page that appears after login. Locates devices attached to account. */
    COMPASS:                    'compass',

    /**  Page that appears after login and calibration completes. May or may not
            have devices listed. Depends if any are attacted to the account. */
    DEVICE_LIST:                'account device list',

    /** Device page. Lists info/attributes about device. */
    DEVICE:                     'device page',

    /** When no devices are registered in the same iCloud account. */
    NO_DEVICES:                 'no devices page',

    /** Device page. Lists actions associated with the device. */
    DEVICE_ACTIONS:             'device page (actions selected)',

    /** After we tap the lost mode action, we get a prompt page. */
    LOST_MODE_PROMPT:           'lost mode page',

    /** After we tap the erase device action, we get a prompt page. */
    ERASE_DEVICE_PROMPT:        'erase device page',

    /** When location services are turned off and location information isn't available. */
    NO_LOCATION:                'No Locations Available',

    // we need to turn off the alert handler for this... otherwise we cannot detect this
    /** Alert that comes up once a play sound request has been transmitted. */
    PLAY_SOUND_ALERT:           'play sound',

    /** Gives us map display options */
    DEVICE_MAP_OPTIONS:         'device page (map options selected)',

    /**  Page that appears after login. States that device is offline. */
    NO_LOCATION:                    'no location available',

    // TODO: Add state for the help menu once the UI has been added to build.
    // TODO: Consider state for when no devices present and on a device page.
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
 * @namespace {UIAApp} findMy
 */
var findMy = target.appWithBundleID('com.apple.mobileme.fmip1');

/**
 *  Constants for FindMy
 */
findMy.Constants = {
    SEMAPHORE_UUID_PREFIX:          'FIND_MY_TESTS',
};

/**
 * Connection states for receiver devices. Devices attached to an account
 * will have a offline/online connection state. This represents whether
 * is connected to iCloud.
 */
findMy.ConnectionState = {
    OFFLINE:                        'offline',

    ONLINE:                         'online',
};

findMy.Waiters = {
    LOGIN_WAITER:                   'login complete',

    COMPASS_WAITER:                 'compass spin complete',

    PASSWORD_WAITER:                'password entry',

    INITIAL_DUMMY_SCREEN:           'initial dummy screen', 
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state.  See UIStateDescription
 * constants defined in UIAApp and FindMy for possible values.
 *
 * The states are listed according to likelihood of use. This way
 * we reduce the number of queries executed.
 *
 * @returns {string} Description of current UI state from a list of
 *           possible constants contained in UIStateDescription.
 */
findMy.getCurrentUIState = function getCurrentUIState() {
    // device list MUST come before lost mode propmt and erase device prompt
    // or we could end up grabbing the wrong state (these buttons exist
    // on device list page as well)
    if ( this.exists(UIAQuery.FindMy.HELP_NAV_BUTTON)
            && this.exists(UIAQuery.FindMy.SIGN_OUT_NAV_BUTTON) ) {
        return UIStateDescription.FindMy.DEVICE_LIST;
    }

    if ( this.exists(UIAQuery.FindMy.TRACKING_BUTTON) ) {
        return UIStateDescription.FindMy.DEVICE;
    } else if ( target.model() === 'iPad'
            && this.exists(UIAQuery.FindMy.REFRESH_NAV_BUTTON)
            && this.exists(UIAQuery.FindMy.NO_DEVICES_REGISTERED) ) {
        return UIStateDescription.FindMy.NO_DEVICES;
    }

    if ( this.exists(UIAQuery.FindMy.PLAY_SOUND_BUTTON)) {
        return UIStateDescription.FindMy.DEVICE_ACTIONS;
    }

    if ( this.exists(UIAQuery.FindMy.LOST_MODE_BUTTON) ) {
        return UIStateDescription.FindMy.LOST_MODE_PROMPT;
    }

    if ( this.exists(UIAQuery.FindMy.ERASE_DEVICE_BUTTON) ) {
        return UIStateDescription.FindMy.ERASE_DEVICE_PROMPT;
    }

    if ( this.exists(UIAQuery.alerts().andThen(UIAQuery.contains('Find My'))) ) {
        return UIStateDescription.FindMy.PLAY_SOUND_ALERT;
    }

    if ( this.exists(UIAQuery.contains('Satellite')) ) {
        return UIStateDescription.FindMy.DEVICE_MAP_OPTIONS;
    }

    if ( this.exists(UIAQuery.contains('Use a different Apple ID')) ) {
        return UIStateDescription.FindMy.LOGIN_CACHED;
    }

    if ( this.exists(UIAQuery.staticTexts('Password').orElse
                    (UIAQuery.contains('Find My iPhone').andThen(UIAQuery.contains('Apple ID')))) ) {
        return UIStateDescription.FindMy.LOGIN;
    }

    if ( findMy.exists(UIAQuery.staticTexts('No Locations Available')) ) {
        return UIStateDescription.FindMy.NO_LOCATION;
    }

    if ( this.exists(UIAQuery.contains('Compass')) ) {
        return UIStateDescription.FindMy.COMPASS;
    }

    if ( this.exists(UIAQuery.contains('No location')) ) {
        return UIStateDescription.FindMy.NO_LOCATION;
    }

    // if we get to here, we have no idea where we are...
    throw new UIAError('Cannot determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/


/**
* Navigation function to get to the device list UI from some starting state.
* Any critia for defining a transition from a state to the web page state
* should be very exact so we always end up in the device list state or else
* throw.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If transition from starting state to device list UI has not been
*           defined in this function yet. This means we need to update the
*           this function to detect this new state.
*         If we were unable to transition from starting state to
*           DEVICE_LIST state.
*/
findMy.getToDeviceListUI = function getToDeviceListUI() {
    findMy.launch();

    var currentState = this.getCurrentUIState();
    if (currentState === UIStateDescription.FindMy.DEVICE_LIST || currentState === UIStateDescription.FindMy.NO_LOCATION){
        return;
    }

    UIALogger.logMessage('Navigating to %0 UI'.format(UIStateDescription.FindMy.DEVICE_LIST));
    var compassWaiter = this.getWaiter(findMy.Waiters.COMPASS_WAITER);

    switch (currentState) {
        case UIStateDescription.FindMy.DEVICE:
        case UIStateDescription.FindMy.DEVICE_ACTIONS:
            this.tap(UIAQuery.FindMy.BACK_NAV_BUTTON);
            break;

        case UIStateDescription.FindMy.LOST_MODE_PROMPT:
        case UIStateDescription.FindMy.ERASE_DEVICE_PROMPT:
            this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back').isVisible()));
            break;

        case UIStateDescription.FindMy.DEVICE_MAP_OPTIONS:
            this.tap('Done');
            this.tap(UIAQuery.navigationBars().andThen(UIAQuery.buttons('Back').isVisible()));
            break;
        case UIStateDescription.FindMy.NO_DEVICES:
        case UIStateDescription.FindMy.NO_LOCATION:
            //We should remove tapping on a space (UIAQuery.buttons(" ")) once AX adds the label to the back button. <rdar://problem/39735281>
            findMy.tap(UIAQuery.buttons(" ").orElse(UIAQuery.FindMy.BACK_NAV_BUTTON));
            break;

        case UIStateDescription.FindMy.COMPASS:
            UIALogger.logMessage('We are in the compass state. Lets wait to get to DeviceListUI.');

            if (!compassWaiter.wait(60)) {
                throw new UIAError('Compass spin time exceeded!');
            }
            findMy.getToDeviceListUI();
            break;

        case UIStateDescription.FindMy.LOGIN:
        case UIStateDescription.FindMy.LOGIN_CACHED:
            throw new UIAError(
                'Account not logged in. Cannot get to state: \'%0\''
                .format(UIStateDescription.FindMy.DEVICE_LIST)
            );

        default:
            // we found and new state and need to update
            throw new UIAError('Current UI State unexpected. Update getToDeviceListUI with new state: %0'.format(currentState));
    }

    var previousState = currentState;
    currentState = this.getCurrentUIState();

    if (currentState !== UIStateDescription.FindMy.DEVICE_LIST) {
        throw new UIAError('Could not get to \'%0\' UI from \'%1\' UI'.format(UIStateDescription.FindMy.DEVICE_LIST, currentState));
    }
}

/**
* Navigation function to get to the login UI from some starting state.
* If an account is already logged in, we log out.
*
* Expected starting states: Works for any UI state.
*
* @returns None.
*
* @throws If transition from starting state to login UI has not been
*           defined in this function yet. This means we need to update the
*           this function to detect this new state.
*         If we were unable to transition from starting state to
*           LOGIN state.
*/
findMy.getToLoginUI = function getToLoginUI() {
    this.launch();

    var currentState = this.getCurrentUIState();
    if (currentState === UIStateDescription.FindMy.LOGIN) {
        return;
    }

    if (currentState !== UIStateDescription.FindMy.LOGIN
            && currentState !== UIStateDescription.FindMy.LOGIN_CACHED) {
        UIALogger.logWarning('Account already login. Attempting to log out.');
        this.signOutOfAccount();
    }

    // need to get the state again incase we logged out
    currentState = this.getCurrentUIState();
    if (currentState === UIStateDescription.FindMy.LOGIN_CACHED) {
        this.tap(UIAQuery.buttons('Use a different Apple ID'));
    }

    var previousState = currentState;
    currentState = this.getCurrentUIState();

    if (currentState !== UIStateDescription.FindMy.LOGIN) {
        throw new UIAError('Could not get to \'%0\' UI from \'%1\' UI'.format(UIStateDescription.FindMy.LOGIN, currentState));
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks - FOR SENDERS ONLY                                                */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - logIntoAccount       */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Attempts to log into findMy on a device. If an account is already logged in,
 * we attempt to log out of the active account and log in with the supplied
 * account.
 *
 * TODO: should allow for a option to not log out if we accounts are the same
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {object} options
 * @param {string} [options.user="something@icloud.com"] - (Required) Apple ID
 * @param {string} [options.password="password"] - (Required) Apple ID password
 *
 * @returns none
 */
findMy.logIntoAccount = function logIntoAccount(options) {
    var dummyScreenGoneWaiter = this.getWaiter(findMy.Waiters.INITIAL_DUMMY_SCREEN);
    dummyScreenGoneWaiter.wait(10);

    this.getToLoginUI();

    var passwordEntryWaiter = this.getWaiter(findMy.Waiters.PASSWORD_WAITER);
    this.enterText(UIAQuery.query('UIAccessibilityTextFieldElement').contains('Apple ID'), options.user);
    this.typeString("\n");
    if (!passwordEntryWaiter.wait(options.passwordTimeLimit)) {
        throw new UIAError('Password entry field never appeared!');
    }
    this.enterText(UIAQuery.query('UIAccessibilityTextFieldElement').contains('Password'), options.password);

    var loginWaiter = this.getWaiter(findMy.Waiters.LOGIN_WAITER);
    var compassWaiter = this.getWaiter(findMy.Waiters.COMPASS_WAITER);

    this.typeString("\n");

    if (options.loginTimeLimit && !loginWaiter.wait(options.loginTimeLimit)) {
        throw new UIAError('Login time exceeded!');
    }

    if (options.compassTimeLimit && !compassWaiter.wait(options.compassTimeLimit)) {
        throw new UIAError('Compass spin time exceeded!');
    }

    UIAUtilities.assertNotEqual(
        this.getCurrentUIState(),
        UIStateDescription.FindMy.LOGIN,
        'Login failed.'
    );
}

// function still under construction. Works for most cases.
findMy.signOutOfAccount = function signOutOfAccount(options) {
    options = UIAUtilities.defaults(options, {
        failNotLoggedIn: true,
        user: null,
    });

    this.getToDeviceListUI();

    // this is for if we want to keep a certain user logined in.
    if (options.user) { //need check if signed in account is one specified
        throw new UIAError("Not yet implemented.");
    }

    if (options.failNotLoggedIn) {
        UIAUtilities.assert(
            this.isLoggedIn(),
            'No user account is already signed in.'
        );
    }

    // title of alert has a non-breaking space
    this.handlingAlertsInline(UIAQuery.contains('Sign Out of Find\xA0My\xA0i'), function() {
        if (target.model() == 'iPad') {
            this.tapIfExists(UIAQuery.FindMy.DEVICE_LIST_BUTTON);
        }
        this.tap(UIAQuery.FindMy.SIGN_OUT_NAV_BUTTON);
        this.tap(UIAQuery.alerts().andThen(UIAQuery.buttons("Sign Out")));
    });

    UIAUtilities.assert(
        !this.isLoggedIn(),
        'Could not sign out of account.'
    );

}



/**
 * Checks each device currently attached to the account. If values are given for
 * one or more of 'totalDevices', 'onlineDevices', and 'offlineDevices' and we find the
 * the value given differs from the actual, we will throw.
 *
 * @param {object} options - Test arguments
 * @param {null|int} [options.totalDevices=null] - (Optional) Expected number
 *              total devices attached to the logged in account.
 * @param {null|int} [options.onlineDevices=null] - (Optional) Expected number
 *              total online devices attached to the logged in account.
 * @param {null|int} [options.offlineDevices=null] - (Optional) Expected number
 *              total offline devices attached to the logged in account.
 *
 * @return none
 *
 * @throws if supplied count values differ from actual
 */
findMy.checkDevicesConnectionState = function checkDevicesConnectionState(options) {
    options = UIAUtilities.defaults(options, {
        totalDevices: null,
        onlineDevices: null,
        offlineDevices: null,
    });

    this.getToDeviceListUI();

    var numDevices = this.count(UIAQuery.FindMy.DEVICES);
    UIALogger.logMessage('Found \'%0\' devices present.'.format(numDevices));

    var onlineCount = 0;
    var offlineCount = 0;

    for (var i = 0; i < numDevices; ++i) {
        var deviceInfo = findMy.inspect(UIAQuery.FindMy.DEVICES.atIndex(i)).name;
        UIALogger.logMessage('Found device: %0'.format(deviceInfo));

        if (deviceInfo.toLowerCase().indexOf(findMy.ConnectionState.OFFLINE) > -1) {
            UIALogger.logMessage('Device is offline.');
            offlineCount++;
        } else if (deviceInfo.toLowerCase().indexOf(findMy.ConnectionState.ONLINE) > -1) {
            UIALogger.logMessage('Device is online.');
            onlineCount++;
        } else {
            UIALogger.logError('Cannot determine device connection state.');
        }
    }

    var truthVal = this.isCountCorrect(numDevices, options.totalDevices)
                    && this.isCountCorrect(onlineCount, options.onlineDevices)
                    && this.isCountCorrect(offlineCount, options.offlineDevices);

    if ( !truthVal ) {
        throw new UIAError('Expected vs. actual device infomation is incorrect.');
    }
}

/**
 * Inspects each device for the current logged in account. Checks
 * map loads and is valid, checks valid battery info, and checks valid lost mode,
 * erase device, and play sound buttons.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {object} options - Test arguments
 * @param {bool} options.failOnNoDevices - If true and no devices attached
 *                  to account, we throw.
 *
 * @return none
 *
 * @throws If finds an invalid element.
 *         If failOnNoDevices set and no devices attached.
 */
findMy.inspectAttachedDevices = function inspectAttachedDevices(options) {
    options = UIAUtilities.defaults(options, {
        failOnNoDevices: true,
    });

    var actions = [
        this.checkMapExists,
        this.checkValidBatteryInfo,
        this.checkValidLostButton,
        this.checkValidEraseButton,
        this.checkValidPlaySoundButton,
    ];

    this.applyActionsOnDevices(actions, options);
}

/**
 * Enables the play sound option on all devices attached to the
 * logged on account. If the receiver devices are online, we
 * must first go into a waiting state and wait for the signal
 * they are ready to receive the alert.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {object} options - Test arguments
 * @param {bool} options.failOnNoDevices - If true and no devices attached
 * @param {array} options.receiverSemaphoreUuidEndings - array of receiver devices udids. If
 *                  populated, we will wait for the receiver devices to get
 *                  into a ready state. The semaphore's
 *                  uuid will be based on SEMAPHORE_UUID_PREFIX + _ + device_udid
 *                  e.g. FIND_MY_TESTS_84480c578waec97d928cc7fe4e0947d8be20b776
 *
 * @return none
 *
 * @throws If unable to tap play sound.
 *         If failOnNoDevices set and no devices attached.
 */
findMy.playSound = function playSound(options) {
    options = UIAUtilities.defaults(options, {
        failOnNoDevices: true,
        receiverSemaphoreUuidEndings: [],
    });

    if (options.receiverSemaphoreUuidEndings.length > 0 ) {
        this.awaitReceiversReady(options.receiverSemaphoreUuidEndings, UIASemaphore.States.UNLOCKED);
    }

    var actions = [
        this.activatePlaySoundAction,
    ];

    this.applyActionsOnDevices(actions, options);
}

/**
 * Takes a list of function references and runs them on each attached
 * device.
 *
 * @param {object} options - Test arguments
 * @param {bool} options.failOnNoDevices - If true and no devices attached
 *                  to account, we throw.
 *
 * @return none
 *
 * @throws If failOnNoDevices set and no devices attached.
 */
findMy.applyActionsOnDevices = function applyActionsOnDevices(actions, options) {
    options = UIAUtilities.defaults(options, {
        failOnNoDevices: true,
    });

    this.getToDeviceListUI();

    if (options.failOnNoDevices && !this.isDevicesOnAccount()) {
        throw new UIAError('No devices are present on logged in account.');
    }

    return this.iterateDevices(actions, options.failOnNoDevices);
}


/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks - FOR RECEIVERS ONLY                                              */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - logIntoAccount       */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * For a receiver device, logs into the supplied iCloud account. If an
 * account is already logged in, we log out of that one first.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {string} accountName - Apple ID
 *
 * @returns none
 */
findMy.receiverCloudLogin = function receiverCloudLogin(accountName, password) {
    // delete iCloud if one already exists on device
    SettingsTests.deleteiCloudAccount();

    options = {
            type:                'iCloud',
            name:                'FindMy Automation',
            address:             accountName,
            password:            password,
            syncOptions: {
                syncFindMyDevice:    true,
            },
        };

    SettingsTests.createEmailAccount(options);
}

/**
 * This is a receiver function. The receiver waits for a play sound
 * notice from the caller and deals with the alert.
 * connectionState determines how the play sound alert will appear. If we
 * are offline, we need to get back online. While we are offline, the
 * caller should have send the play sound notice. If we are already online,
 * we need to unlock the semaphore. This is to notify the caller we are in
 * waiting state for the play sound notice.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @return none
 *
 * @throws If play sound alert does not appear after waiting period.
 */
findMy.receiverRepondToPlaySound = function receiverRepondToPlaySound(connectionState, options) {
    options = UIAUtilities.defaults(options, {
        soundWaitTimeout: 30,
    });

    this.handlingAlertsInline('Find My i', function() {
        var waiter = UIAWaiter.waiter('Alert');

        if (connectionState === findMy.ConnectionState.OFFLINE) {
            this.setConnectionState(findMy.ConnectionState.ONLINE);
        } else {
            this.receiverUnlockSemaphore();
        }

        // the alert may appear immediately
        if (target.systemApp().exists(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')))) {
            target.systemApp().tap(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')));
            waiter.discard();
            return;
        }

        // otherwise, lets go into a waiting state for it
        if ( waiter.wait(options.soundWaitTimeout) ) {
            target.systemApp().tap(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')));
            return;
        } else {
            throw new UIAError('Play sound alert was never raised.');
        }
    });
}


findMy.receiverLockSemaphore = function receiverLockSemaphore() {
    //these semaphores should be active for a test suite and no longer
    //therefore, we should be able to just set the lock
    UIASemaphore.lock(this.getSemaphoreUuid());
}

findMy.receiverUnlockSemaphore = function receiverUnlockSemaphore() {
    //these semaphores should be active for a test suite and no longer
    //therefore, we should be able to just unock the semaphore
    UIASemaphore.unlock(this.getSemaphoreUuid());
}


/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Gets a waiter.
 *
 * Required Starting State: N/A. Not UI dependent.
 *
 * @param {string} waiterID - ID of waiter to return.
 *
 * @returns waiter object
 *
 * @throws if passed waiterId does not match a predefined
 *          waiter
 */
findMy.getWaiter = function getWaiter(waiterId) {

    switch (waiterId) {
        case findMy.Waiters.LOGIN_WAITER:
            return UIAWaiter.withPredicate(
                'ViewDidDisappear',
                'controllerClass == "LoginViewController"'
            );
        case findMy.Waiters.COMPASS_WAITER:
            if (target.model() === 'iPad') {
                return UIAWaiter.withPredicate(
                    'ViewDidAppear',
                    'controllerClass == "MainViewController"'
                );
            } else {
                return UIAWaiter.withPredicate(
                    'ViewDidAppear',
                    'controllerClass == "DeviceListViewController"'
                );
            }
        case findMy.Waiters.PASSWORD_WAITER:
            return UIAWaiter.withPredicate(
                'ViewDidAppear',
                'controllerClass == "UICompatibilityInputViewController"'
            );
        case findMy.Waiters.INITIAL_DUMMY_SCREEN:
            return UIAWaiter.withPredicate(
                'ViewDidDisappear',
                'controllerClass == "DummyInitialViewController"'
            );        
        default:
            throw new UIAError('No waiter exists for waiterID: %0'.format(waiterID));
    }
}

/**
 * Takes an array of function references and calls the functions
 * as we iterate throught the devices in device list. Setting flag 'accessDevice'
 * enters the device page of the device before we call the functions.
 *
 * Required starting state: UIStateDescription.FindMy.DEVICE_LIST
 *
 * @param {object} options - Options dictionary
 * @param {boolean} options.useGestures - If true, use swipe from left/right gestures
 *
 * @returns {array} A array of return values from called functions.
 */
findMy.iterateDevices = function iterateDevices(funcs, options) {
    options = UIAUtilities.defaults(options, {
        accessDevice: true,
    });

    this.getToDeviceListUI();

    var retValues = [];
    var numDevices = this.count(UIAQuery.FindMy.DEVICES);
    UIALogger.logMessage('Found \'%0\' devices present.'.format(numDevices));

    for (var i = 0; i < numDevices; i++) {
        UIALogger.logMessage('On device \'%0\' of \'%1\''.format(i+1, numDevices));
        UIALogger.logMessage(
            'Device name: \'%0\''
            .format(this.inspect(UIAQuery.FindMy.DEVICES.atIndex(i)).name)
        );

        if (options.accessDevice) {
            this.tap(UIAQuery.FindMy.DEVICES.atIndex(i));
        }

        for (var j = 0; j < funcs.length; j++) {
            try {
                retValues.push( funcs[j].call(this) );
            } catch (e) {
                throw new UIAError(e);
            }
        }

        if (options.accessDevice) {
            this.tap(UIAQuery.FindMy.BACK_NAV_BUTTON);
        }
    }

    return retValues;
}


/**
 * Turn Find My iPhone/iPad on for the current iCloud account and
 * turn on 'Send Last Location'.
 * Assumes account already logged in.
 *
 * @param none
 * @returns none
 *
 */
findMy.enableFindMy = function enableFindMy() {
    settings.launch();
    settings.returnToTopLevel();
    var findMyString = 'Find My ' + target.model();
    settings.tap(UIAQuery.staticTexts().contains('Apple ID'));
    settings.tap(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells('iCloud')));
    settings.tap(UIAQuery.tableViews().rightmost().andThen(UIAQuery.tableCells(findMyString)));
    settings.setSwitchSetting(findMyString, true, true);  
    settings.setSwitchSetting('Send Last Location', true, true);
}

/**
 * Play sound on this iPhone/iPad for the current iCloud account. 
 * Assumes account already logged in.
 *
 * @param none
 * @returns none
 *
 */
findMy.playSoundOnThis = function playSoundOnThis() {
    this.launch();
    if (target.model() == 'iPad') {
        this.tap(UIAQuery.FindMy.DEVICE_LIST_BUTTON);
    }

    this.tap(UIAQuery.FindMy.THIS_DEVICE);
    this.tapIfExists(UIAQuery.FindMy.ACTIONS_BUTTON);

    this.handlingAlertsInline('Find My i', function() {
        this.tap(UIAQuery.FindMy.PLAY_SOUND_BUTTON);
        target.systemApp().tap(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')));
    });
}


/**
 * Turns findMy on/off for the current iCloud account based
 * on specified options.
 *
 * TODO: should check to see if account is already logged in.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {object} options
 * @param {string} [options.password="password"] -  Password for iCloud account
 * @param {boolean} [options.keepAlreadSynced=true] -  Flag, if enabled, keeps
 *              current data sync on device.
 * @param {boolean} [options.syncFindMyDevice=true/false] - Sets findMy to on/off
 *              depending on flag
 *
 * @returns none
 */
findMy.switchFindMyOnOff = function switchFindMyOnOff(options) {
    options = UIAUtilities.defaults(options, {
        password: null,
        keepAlreadSynced: true,
    });

    settings.launch();
    settings.navigateNavigationViews(['iCloud']);
    settings.setSyncOptions(options);

    this.launch();
}

/**
 * Turns findMy off for the current iCloud account
 *
 * TODO: should check to see if account is already logged in.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {string} password - (Required) Password for iCloud account.
 *
 * @returns none
 */
findMy.turnOffFindMy = function turnOffFindMy(password) {
    this.switchFindMyOnOff({syncFindMyDevice:false, password:password});
}

/**
 * Turns findMy on for the current iCloud account
 *
 * TODO: should check to see if account is already logged in.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @returns none
 */
findMy.turnOnFindMy = function turnOnFindMy() {
    this.switchFindMyOnOff({syncFindMyDevice:true});
}

/**
 * Checks the count values between actual and expected. If expectedNum
 * is null we do not do the check.
 *
 * Required Starting State: N/A. Not UI dependent.
 *
 * @returns (boolean) False, if values differ. True if values same.
 */
findMy.isCountCorrect = function isCountCorrect(actualNum, expectedNum) {
    if ( (expectedNum !== null) && (actualNum != expectedNum) ) {
        UIALogger.logError(
            'Number of devices differs from expected. Actual: \'%0\'. Expected: \'%1\'.'.format(actualNum, expectedNum)
        );
        return false;
    }

    return true;
}

/**
 * Determines if there is an account logged into FindMy. This function
 * should NOT be used if we care about LOGIN vx. LOGIN_CACHED state
 * difference.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {string} state - (optional) State to check against.
 *
 * @returns bool. If true, an account is logged in.
 */
findMy.isLoggedIn = function isLoggedIn() {
    if (arguments.length == 1) {
        var state = arguments[0];
    } else {
        var state = this.getCurrentUIState();
    }

    if (state === UIStateDescription.FindMy.LOGIN
            || state === UIStateDescription.FindMy.LOGIN_CACHED) {
        return 0;
    }

    return 1;
}

/**
 * Determines if logged in account has devices attached to the account.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @returns bool. If true account has devices registered. If false,
 *                  no devices attacted to account.
 */
findMy.isDevicesOnAccount = function isDevicesOnAccount() {
    this.getToDeviceListUI();

    if (this.exists(UIAQuery.FindMy.NO_DEVICES_REGISTERED)) {
        return 0;
    }

    return 1;
}

/**
 * Checks to see if map was loaded and exists in view.
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *                          UIStateDescription.FindMy.DEVICE_MAP_OPTIONS
 *
 * @returns None.
 */
findMy.checkMapExists = function checkMapExists() {
    // NOTE: THIS FUNCTION DOESN'T ACTUALLY CONFIRM IF THE
    // MAP IS LOADED OR NOT. WE NEED A EVENT FOR THAT. WAITING ON:
    //<rdar://problem/19786001> [UIA2] Need Event Notification for Map Loaded
    this.assertExists(UIAQuery.mapViews(), 'Map did not load.');
    UIALogger.logMessage('Map appears to have loaded.');
}

/**
 * Checks to see if there is valid battery infomation.
 *
 * TODO: this function needs to do, ask Ruhal about what he needs.
 *
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *                          UIStateDescription.FindMy.DEVICE_MAP_OPTIONS
 *
 * @returns None.
 */
findMy.checkValidBatteryInfo = function checkValidBatteryInfo() {
    this.assertExists(UIAQuery.contains('battery power'));

    UIALogger.logMessage(
        'Found valid battery infomation: \'%0\''
        .format(this.inspect(UIAQuery.contains('battery power')).name)
    );
}

/**
 * Checks to see if the lost mode button is valid.
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *
 * @returns None.
 */
findMy.checkValidLostButton = function checkValidLostButton() {
    this.tapIfExists(UIAQuery.FindMy.ACTIONS_BUTTON);
    this.tap(UIAQuery.FindMy.LOST_MODE_BUTTON);
    UIALogger.logMessage('Found valid \'Lost\' button.');
    this.tap('Cancel');
}

/**
 * Checks to see if the erase device button is valid.
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *
 * @returns None.
 */
findMy.checkValidEraseButton = function checkValidEraseButton() {
    this.tapIfExists(UIAQuery.FindMy.ACTIONS_BUTTON);
    this.tap(UIAQuery.FindMy.ERASE_DEVICE_BUTTON);
    UIALogger.logMessage('Found valid \'Erase\' button.');
    this.tap('Cancel');
}

/**
 * Checks to see if the play sound button is valid. Note: we do
 * do not tap this button as it could send alerts off to attached
 * devices.
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *
 * @returns None.
 */
findMy.checkValidPlaySoundButton = function checkValidPlaySoundButton() {
    this.tapIfExists(UIAQuery.FindMy.ACTIONS_BUTTON);
    this.assertExists(UIAQuery.FindMy.PLAY_SOUND_BUTTON, 'No \'Play Sound\' button.');
    UIALogger.logMessage('Found valid \'Play Sound\' button.');
}

/**
 * Taps the play sound button on a device page.
 *
 * Required Starting State: UIStateDescription.FindMy.DEVICE
 *                          UIStateDescription.FindMy.DEVICE_ACTIONS
 *
 * @returns None.
 */
findMy.activatePlaySoundAction = function activatePlaySoundAction() {
    this.tapIfExists(UIAQuery.FindMy.ACTIONS_BUTTON);

    if (this.exists('This device')) {
        this.handlingAlertsInline('Find My i', function() {
            this.tap(UIAQuery.FindMy.PLAY_SOUND_BUTTON);
            UIALogger.logMessage('Activated play sound action on sender device. Pressing \'OK\'');
            target.systemApp().tap(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')));
        });
    } else {
        this.tap(UIAQuery.FindMy.PLAY_SOUND_BUTTON);
    }
}

/**
 * Turns a deivce online/offline to FindMy detection.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @return none
 *
 * @throws If incorrect is sent.
 */
findMy.setConnectionState = function setConnectionState(state) {
    if (state === findMy.ConnectionState.ONLINE) {
        settings.changeSingleSwitch([], 'Airplane Mode', false);
    } else if (state === findMy.ConnectionState.OFFLINE) {
        settings.changeSingleSwitch([], 'Airplane Mode', true);
    } else {
        throw new UIAError('Incorrect online/offline state request.')
    }
}

/**
 * Waits for the devices with the passed udids to get into the correct state.
 *
 * Required Starting State: N/A. Can start anywhere.
 *
 * @param {array} receiverSemaphoreUuidEndings - array of receiver devices udids.
 *                  The semaphore's uuid will be based on
 *                  SEMAPHORE_UUID_PREFIX + _ + device_udid
 *                  e.g. FIND_MY_TESTS_84480c578waec97d928cc7fe4e0947d8be20b776
 * @param {string} readyState - Semaphore state to wait for
 *
 * @return none
 *
 * @throws If invalid readyState
 */
findMy.awaitReceiversReady = function awaitReceiversReady(receiverSemaphoreUuidEndings, readyState) {
    var uuid;

    for (var i = 0; i < receiverSemaphoreUuidEndings.length; i++) {
        uuid = '%0_%1'.format(findMy.Constants.SEMAPHORE_UUID_PREFIX, receiverSemaphoreUuidEndings[i]);

        if (readyState === 'locked') {
            UIASemaphore.pollForLocked(uuid);
        } else if (readyState === 'unlocked') {
            UIASemaphore.pollForUnlocked(uudi);
        } else {
            throw new UIAError('readyState \'%0\' unsupported.'.format(readyState));
        }
    }
}


findMy.getSemaphoreUuid = function getSemaphoreUuid() {
    return '%0_%1'.format(findMy.Constants.SEMAPHORE_UUID_PREFIX, target.uniqueIdentifier());
}


findMy.validateNoDeviceState = function validateNoDeviceState() {
    UIAUtilities.assertEqual(
        this.getCurrentUIState(),
        UIStateDescription.FindMy.LOGGED_IN_NO_DEVICES,
        'Could not sign into account.'
    );

    UIAUtilities.assert(
        this.exists(UIAQuery.buttons('Setup Instructions')),
        "'Setup Instructions' button missing from page."
    );
}






