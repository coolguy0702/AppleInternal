load('UIATesting.js');
load('FindMy.js'); 

UIAUtilities.assert(
    typeof FindMyTests === 'undefined', 
    'FindMyTests has already been defined.'
);


/**
 * @namespace FindMyTests
 */
var FindMyTests = {

    /**
     * Logs into findMy with supplied Apple ID and password.
     * If an account is already logged on we log out and log
     * in with the supplied account.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.user="p15_cookie11@icloud.com"] - (Required) Apple ID
     * @param {string} [args.password="iCloud1234"] - (Required) Password
     * @param {null|int} [args.loginTimeLimit=5] - (Optional) If int value set, throws
     *                      if login time (seconds) exceededs loginTimeLimit
     * @param {null|int} [args.compassTimeLimit=5] - (Optional) If int value set, throws
     *                      if compass time (seconds) exceededs compassTimeLimit         
     */
    logIntoAccount: function logIntoAccount(args) {
        args = UIAUtilities.defaults(args, {
            user: 'p15_cookie11@icloud.com',
            password: 'iCloud1234',
            loginTimeLimit: 5,
            compassTimeLimit: 5,
            // failIfAlreadyLoggedIn: null,
        });

        findMy.logIntoAccount(args);
    },     

    // *
    //  * Logs into findMy with supplied Apple ID and password.
    //  * The account is expected to have no devices associated with it.
    //  * If an account is already logged on we log out and log
    //  * in with the supplied account.
    //  *
    //  * @param {object} args - Test arguments
    //  * @param {string} [args.user="p15_cookie11@icloud.com"] - (Required) Apple ID
    //  * @param {string} [args.password="iCloud1234"] - (Required) Password
    //  * @param {null|boolean} [args.loginTimeLimit=null] - (Optional) If true, issues warnging if
    //  *              logging on and getting pass compass screen takes more than 5 secondes.
    //  *              Throws if takes more than 10 seconds.
     
    // loginAccountNoDevices: function loginAccountNoDevices(args) {
    //     args = UIAUtilities.defaults(args, {
    //         user: 'p15_cookie11@icloud.com',
    //         password: 'iCloud1234',
    //         loginTimeLimit: true, 
    //         // failIfAlreadyLoggedIn: null,
    //     });

    //     findMy.logIntoAccount(args);
    //     findMy.validateNoDeviceState();
    // }, 


    /**
     * Will attempt to log out of the active account.
     *
     * @param {object} args - Test arguments
     * @param {boolean} [args.failNotLoggedIn=false] - (Optional) Flag determines if
     *              test passes if no account is currently logged. If true: test will 
     *              fail if no account logged in. If false, test will pass if no 
     *              account logged in.
     */
    signOutOfAccount: function signOutOfAccount(args) {
        args = UIAUtilities.defaults(args, {
            failNotLoggedIn: true,  //default to always failing test if no account logged in
        });

        findMy.signOutOfAccount(args);
    },

    // *
    //  * Will attempt to log out of the active account if the current
    //  * logged in account is not the specified one. 
    //  *
    //  * @param {object} args - Test arguments
    //  * @param {null|string} [args.user="p15_cookie11@icloud.com"] - (Required) Apple ID for account
    //  * @param {boolean} [args.failNotLoggedIn=false] - (Optional) Flag determines if
    //  *              test passes if no account is currently logged. If true: test will 
    //  *              fail if no account logged in. If false, test will pass if no 
    //  *              account logged in.
     
    // signOutIfNotSpecifiedAccount: function signOutIfNotSpecifiedAccount(args) {
    //     args = UIAUtilities.defaults(args, {
    //         user: 'p15_cookie11@icloud.com',
    //         failNotLoggedIn: true,  //default to always failing test if no account logged in
    //     });

    //     throw new UIAError("Not yet implemented.");
    // },

    /**
     * Checks each device currently attached to the account. If values are given for
     * one or more of 'totalDevices', 'onlineDevices', and 'offlineDevices' and we find the
     * the value given differs from the actual, we will throw.
     *
     * @param {object} args - Test arguments
     * @param {null|int} [args.totalDevices=null] - (Optional) Expected number
     *              total devices attached to the logged in account.
     * @param {null|int} [args.onlineDevices=null] - (Optional) Expected number
     *              total online devices attached to the logged in account.
     * @param {null|int} [args.offlineDevices=null] - (Optional) Expected number
     *              total offline devices attached to the logged in account.                  
     */
    checkDevicesConnectionState: function checkDevicesConnectionState(args) {
        args = UIAUtilities.defaults(args, {
            totalDevices: null,
            onlineDevices: null,
            offlineDevices: null,
        });            

        findMy.checkDevicesConnectionState(args);
    },

    /**
     * Inspects each device for the current logged in account. Checks 
     * map loads and is valid. Checks there is valid battery infomation.
     * Checks valid lost mode, erase device, and play sound buttons.  
     *
     * @param {object} args - Test arguments
     * @param {bool} [args.failOnNoDevices=true] - If true and no devices attached
     *                  to account, we throw.               
     */
    checkDevicesAttributes: function checkDevicesAttributes(args) {
        args = UIAUtilities.defaults(args, {
            failOnNoDevices: true,
        });

        findMy.inspectAttachedDevices(args);
    },

    /**
     * Play's sound on each device for the current logged in account. 
     *
     * @param {object} args - Test arguments
     * @param {bool} [args.failOnNoDevices=true] - If true and no devices attached
     *                  to account, we throw.
     * @param {array} [args.receiverUdids=[]] - Array of devices udids. If populated,
     *                  we will wait for receiver online devices to get into a ready state 
     *                  before we play sound.
     */
    playSound: function playSound(args) {
        args = UIAUtilities.defaults(args, {
            failOnNoDevices: true,
            receiverUdids: [],
        });

        findMy.playSound(args);
    },

    /**
     * Logs into findMy with supplied Apple ID/password and enable Find My iPhone.
     *
     * @param {object} args - Test arguments
     * @param {string} [args.user="p15_cookie11@icloud.com"] - (Required) Apple ID
     * @param {string} [args.password="iCloud1234"] - (Required) Password
     * @param {null|int} [args.loginTimeLimit=5] - (Optional) If int value set, throws
     *                      if login time (seconds) exceededs loginTimeLimit
     * @param {null|int} [args.compassTimeLimit=60] - (Optional) If int value set, throws
     *                      if compass time (seconds) exceededs compassTimeLimit   
     * @param {int} [args.passwordTimeLimit=15] - Throws if password entry field appearance exceededs passwordTimeLimit seconds       
     */
    enableFindMyIPhone: function enableFindMyIPhone(args) {
        args = UIAUtilities.defaults(args, {
            user: 'p15_cookie11@icloud.com',
            password: 'iCloud1234',
            loginTimeLimit: 5,
            compassTimeLimit: 60,
            passwordTimeLimit: 15,
        });

        findMy.logIntoAccount(args);
        findMy.enableFindMy();
    },

    /**
     * Logs into findMy with supplied Apple ID/password and play sound on this device. 
     *
     * @param {object} args - Test arguments
     * @param {string} [args.user="p15_cookie11@icloud.com"] - (Required) Apple ID
     * @param {string} [args.password="iCloud1234"] - (Required) Password
     * @param {null|int} [args.loginTimeLimit=5] - (Optional) If int value set, throws
     *                      if login time (seconds) exceededs loginTimeLimit
     * @param {null|int} [args.compassTimeLimit=60] - (Optional) If int value set, throws
     *                      if compass time (seconds) exceededs compassTimeLimit   
     * @param {int} [args.passwordTimeLimit=15] - Throws if password entry field appearance exceededs passwordTimeLimit seconds       
     */
    playSoundOnThisDevice: function playSoundOnThisDevice(args) {  
        args = UIAUtilities.defaults(args, {
            user: 'p15_cookie11@icloud.com',
            password: 'iCloud1234',
            loginTimeLimit: 5,
            compassTimeLimit: 60,
            passwordTimeLimit: 15,
        });

        findMy.logIntoAccount(args);
        findMy.playSoundOnThis();
    },

    /*************************************************************************/
    /*                                                                       */
    /*                      Receiver Only Tests:                             */
    /*                                                                       */
    /*************************************************************************/    
    
    /**
     * Log into the supplied iCloud account on the current receiver device.
     *
     * @param {object} args - Test arguments
     * @param {null|string} [args.accountName="p15_cookie11@icloud.com"] - (Required) Apple ID for account
     */
    receiverCloudLogin: function receiverCloudLogin(args) {
        args = UIAUtilities.defaults(args, {
            accountName: 'p15_cookie11@icloud.com',  // SHOULD THIS BE NULL?
            password: 'iCloud1234',
        });

        findMy.receiverCloudLogin(args.accountName, args.password);
    }, 

    /**
     * Lock semaphore on the current receiver device. The semaphore's
     * uuid will be based on SEMAPHORE_UUID_PREFIX + _ + device_udid
     * e.g. FIND_MY_TESTS_84480c578waec97d928cc7fe4e0947d8be20b776
     *
     * @param {object} args - Test arguments
     *                 
     */
    receiverLockSemaphore: function receiverLockSemaphore(args) {
        args = UIAUtilities.defaults(args, {
        });

        findMy.receiverLockSemaphore();
    },

    /**
     * Response to the play sound alert on the current receiver device.
     *
     * @param {object} args - Test arguments
     * @param {null|string} [args.soundWaitTimeout=13] - Max time to wait for alert
     */
    receiverRepondToPlaySound: function receiverRepondToPlaySound(args) {
        args = UIAUtilities.defaults(args, {
            receiverConnectionState: findMy.ConnectionState.ONLINE,
            soundWaitTimeout: 300, 
        });

        findMy.receiverRepondToPlaySound(args.receiverConnectionState, args);
    },     
}


















