load('UIAUtility.js');
load('UIAApp.js');
load('Settings.js');
load('UIAApp+International.js');

UIAUtilities.assert(
    typeof International === 'undefined',
    'International has already been defined.'
);

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/
UIAQuery.International = {
}

/**
    @namespace
    @augments International
*/
International = {
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

International.withFunctionBoundaryLogging = function withFunctionBoundaryLogging(object, body) {
    UIAUtilities.assert(
        typeof body === 'function',
        'Second argument must be a function.'
    );

    var result = null;

    var callerName = arguments.callee.caller.name;
    UIALogger.logDebug('-----> %0'.format(callerName));

    result = body.call(object);

    UIALogger.logDebug('<----- %0'.format(callerName));

    return result;
}

//This is internal used function, to convert unicode to UTF-16 encoding
International._utf16EncodeAsString = function _utf16EncodeAsString(input) {
	var output = [];
	var i = 0;
	
	//The passed parameter should be leading with "0x", like "0x0001f44d"
	input = parseInt(input);
	if ( (input & 0xF800) === 0xD800 ) {
		throw new RangeError("UTF-16(encode): Illegal UTF-16 value");
	}
	if (input > 0xFFFF) {
		input -= 0x10000;
		output.push(String.fromCharCode(((input >>>10) & 0x3FF) | 0xD800));
		input = 0xDC00 | (input & 0x3FF);
	}
	output.push(String.fromCharCode(input));

	return output.join("");
}

//This is internal used function, to query candidate bar.
International.queryForKeyboardCandidateCellWithText = function queryForKeyboardCandidateCellWithText(text) {
    return UIAQuery.KEYBOARD_CANDIDATE_VIEW.andThen(UIAQuery.tableCells(text)).orElse(UIAQuery.collectionCells(text));
}

/**
 * Verify typed text on current view is exact same as expected text.
 *
 * @param   {string}    expectedText - expected typed text to be tested.
 * @param   {string}    testCaseID - will show TSTT test case ID if presented.
 * @returns {boolean} - if verification is failed.
 * @throws              if verification is passed.
 *
 * NOTE: assumes that there is only one active app.
 */
International.verifyTypedText = function verifyTypedText(expectedText, testCaseID) {
    International.withFunctionBoundaryLogging(this, function () {
        UIAUtilities.assert(expectedText, 'Mandatory parameter, expectedText, not specified');

        var typedText = target.activeApp().getTextFromElementForInternationalTyping();
        var result = !expectedText.localeCompare(typedText);

        if (testCaseID) {
            UIALogger.logMessage('testCaseID: %0'.format(testCaseID));
        }

        UIALogger.logMessage('Verification: %0'.format(result ? 'Passed' : 'FAILED'));
        UIALogger.logMessage('    typedText    = [%0]'.format(typedText));
        UIALogger.logMessage('    expectedText = [%0]'.format(expectedText));

        UIAUtilities.assert(result, 'Detected unexpected typed text!!  TypedText=[%0], Expected=[%1]'.format(typedText, expectedText));
    });
} // End verifyTypedText


/**
 * Verify if all specified candidate words are available in the current showing candiate bar.
 *
 * @param   {string}    candidates - string consist of one or more words separated by space character (0x20).
 * @param   {boolean}   nonexist - opposite check if true.
 * @param   {string}    testCaseID - will show TSTT test case ID if presented.
 * @returns {boolean} - if verification is failed.
 * @throws              if verification is passed.
 *
 * NOTE: assumes that there is only one active app.
 */
International.verifyCandidates = function verifyCandidates(candidates, nonexist, testCaseID) {
    International.withFunctionBoundaryLogging(this, function () {
        UIAUtilities.assert(candidates, 'Mandatory parameter, candidates, not specified');

        var candidateArray = candidates.split(/ +/);
        var typedText = target.activeApp().getTextFromElementForInternationalTyping();

        var failedItems = [];   // Missing, or available but unexpected
        var passedItems = [];

        // Replace _SPACE_ in candidate with a space character, so we can verify the case which has space character in the candidate
        for (var i = 0; i < candidateArray.length; i++) {
            candidateArray[i] = candidateArray[i].replace(/_SPACE_/g, ' ');
        }

        for (var i = 0; i < candidateArray.length; i++) {
            var exist;
            target.activeApp().withMaximumSnapshotBreadth(400, function() {
                exist = target.activeApp().exists(International.queryForKeyboardCandidateCellWithText(candidateArray[i]));
            });
            UIALogger.logDebug('nonexist:%0,  exist:%1    [%2]'.format(nonexist, exist, candidateArray[i]));
            if ((nonexist && exist) || (!nonexist && !exist)) {
                UIALogger.logDebug('Item failed');
                failedItems.push(candidateArray[i]);
            } else {
                UIALogger.logDebug('Item passed');
                passedItems.push(candidateArray[i]);
            }
        }

        if (testCaseID) {
            UIALogger.logMessage('testCaseID: %0'.format(testCaseID));
        }
        var result = (failedItems.length < 1);

        var passedString = passedItems.join(', ');
        var failedString = failedItems.join(', ');

        UIALogger.logMessage('Verification: %0'.format(result ? 'Passed' : 'FAILED'));
        UIALogger.logMessage('    typedText         = [%0]'.format(typedText));
        UIALogger.logMessage('    candidates Passed = [%0]'.format(passedString));
        UIALogger.logMessage('    candidates Failed = [%0]'.format(failedString));

        UIAUtilities.assert(result, 'Detected %0 candidates!  TypedText=[%1], Passed=[%2], Failed=[%3]'.format(
            (nonexist ? 'unexpected' : 'missing'),
            typedText,
            passedString,
            failedString
        ));
    });
} // End verifyCandidates

/**
 * Verify command controled candidate words are expected in the current showing candiate bar.
 *
 * @param   {string}    candidates - string consist of one or more words separated by space character (0x20).
 * @param   {string}    testCaseID - will show TSTT test case ID if presented.
 * @returns {boolean} - if verification is failed.
 * @throws              if verification is passed.
 *
 * NOTE: assumes that there is only one active app.
 */
International.verifyCandidatesWithCommands = function verifyCandidatesWithCommands(candidates, testCaseID) {
    International.withFunctionBoundaryLogging(this, function () {
        UIAUtilities.assert(candidates, 'Mandatory parameter, candidates, not specified');

		//split candidates and added to an array
		var candidatesArray = candidates.split(/ +/);
		var typedText = target.activeApp().getTextFromElementForInternationalTyping();
		var failedItems = []; // Missing, or available but unexpected
		var passedItems = []; // Passed candidates			        
		
		//Traverse the array to verify each candidate.
		for (var j = 0; j < candidatesArray.length; j++) {

			if (candidatesArray[j].match(/^-/)) { //check if there is not expected candidates.
				var exist = target.activeApp().exists(International.queryForKeyboardCandidateCellWithText(candidatesArray[j].substring(1)));
				if (!exist) {
					passedItems.push(candidatesArray[j].substring(1));
				} else {
					target.activeApp().tap(International.queryForKeyboardCandidateCellWithText(candidatesArray[j].substring(1)));
					target.activeApp().waitUntilReady();
					failedItems.push(candidatesArray[j].substring(1));
				}
			} else {
			    //Add logic to process multiple candidates verification.
			    //Like when user add expected candidates, morning/evening/afternoon, it means that we need to verify all these 3 candidates are existing.
			    //And all will be verified, but only first one is tapped.
			    if (candidatesArray[j].match(/\//g) != null) {
			        var multiCandi = candidatesArray[j].split("\/");
			        for (var n = 0; n < multiCandi.length; n++) {			        
						//Verifying the english candidates on Chinese keyboards, then there is a leading space.
						if (j > 0 && multiCandi[n].match(/[a-zA-Z]+/g) != null) {
							multiCandi[n] = " " + multiCandi[n];
						}

						var exist = target.activeApp().exists(International.queryForKeyboardCandidateCellWithText(multiCandi[n]));
						if (exist) {
							passedItems.push(multiCandi[n]);
						} else {
							failedItems.push(multiCandi[n]);
						}
			        }
			        UIALogger.logDebug('========================Item in multi candidates: %0'.format(multiCandi[0]));
			        target.activeApp().tap(International.queryForKeyboardCandidateCellWithText(multiCandi[0]));
					target.activeApp().waitUntilReady();
			    } else {
					//Verifying the english candidates on Chinese keyboards, then there is a leading space.
					if (j > 0 && candidatesArray[j].match(/[a-zA-Z]+/g) != null) {
					    candidatesArray[j] = " " + candidatesArray[j];
					}
					
					var exist = target.activeApp().exists(International.queryForKeyboardCandidateCellWithText(candidatesArray[j]));
					if (exist) {
						target.activeApp().tap(International.queryForKeyboardCandidateCellWithText(candidatesArray[j]));
						target.activeApp().waitUntilReady();
						passedItems.push(candidatesArray[j]);
					} else {
						failedItems.push(candidatesArray[j]);
					}
			    }
			}
		}
		
		if (testCaseID) {
			UIALogger.logMessage('testCaseID: %0'.format(testCaseID));
		}
		var result = (failedItems.length < 1);

		var passedString = passedItems.join(', ');
		var failedString = failedItems.join(', ');

		UIALogger.logMessage('Verification: %0'.format(result ? 'Passed' : 'Failed'));
		UIALogger.logMessage('    typedText         = [%0]'.format(typedText));
		UIALogger.logMessage('    candidates Passed = [%0]'.format(passedString));
		UIALogger.logMessage('    candidates Failed = [%0]'.format(failedString));

		UIAUtilities.assert(result, 'Detected unexpected typed text!!  TypedText=[%0], Expected=[%1]'.format(typedText, failedString));

    });
} // End verifyCandidatesWithCommands

/**
 * A group strokes typing and candidates verification with commands.
 *
 * @param   {string}    keyStrokeTokens         - string consist of one or more keystrokes separated by ";"
 * @param   {string}    expectedCandidateTokens - string consist of one or more candidates separated by ";"
 * @param   {string}    flick                   - enable flick typing if "1"
 * @param   {string}    testCaseID              - will show TSTT test case ID if presented
 * @param   {string}    bundleID                - Application bundleID
 * @param   {string}    keyboardID              - keyboard identifier 
 * @returns {boolean} - if verification is failed.
 * @throws              if verification is passed.
 *
 * NOTE: assumes that there is only one active app.
 */
International.verifyGroupedStrokesAndCandidatesWithCommands = function verifyGroupedStrokesAndCandidatesWithCommands(keyStrokeTokens, 
                                                                                                                     expectedCandidateTokens, 
                                                                                                                     flick, 
                                                                                                                     testCaseID, 
                                                                                                                     bundleID, 
                                                                                                                     keyboardID) {
    International.withFunctionBoundaryLogging(this, function () {
        UIAUtilities.assert(keyStrokeTokens, 'Mandatory parameter, keyStrokeTokens, not specified');
        UIAUtilities.assert(expectedCandidateTokens, 'Mandatory parameter, expectedCandidateTokens, not specified');
        
        /** Delete button */
        UIAQuery.KEYBOARD_DELETE_BUTTON = UIAQuery.query('delete');
        
        /** Return button */
        UIAQuery.KEYBOARD_RETURN_BUTTON = UIAQuery.query('Return');        

		for (var i = 0; i < keyStrokeTokens.length; i++) {
			var kToken = keyStrokeTokens[i];
			var eToken = expectedCandidateTokens[i];            
			if (kToken == "") 
				continue;
			else if (kToken == "\\n")
				target.activeApp().tap(UIAQuery.KEYBOARD_RETURN_BUTTON);
			else if (kToken == "\\b")
				target.activeApp().tap(UIAQuery.KEYBOARD_DELETE_BUTTON);
			else if (kToken == "\\r") {
				var options = new Object();
				options.autoCorrection = "1";
				options.resetLearningDict = "1";
			
				//reset dictionary and check the keyboard is same keyboard.
				InternationalKeyboardTests._setupKeyboard(keyboardID, options);
			
				//re-lunch apps to type
				var app = target.appWithBundleID(bundleID);
				app.setupForInternationalTyping();
			} else if (kToken == "\\p") {
				//Kill SpringBoard to test the data saving.
				settings.navigateNavigationViews(["Internal Settings",]);
				var stateChangedEvent = UIAWaiter.waiter('PidStatusChanged');
				settings.tapIfExists("Kill SpringBoard");
				if (!stateChangedEvent.wait(10)) {
					UIALogger.logWarning("Never got the Lock Screen view.");
				}
			
				//re-launch apps to type
				var app = target.appWithBundleID(bundleID);
				app.setupForInternationalTyping();
			} else {
				//Type keystrokes and verify related candidates
				UIALogger.logDebug('Typing keystrokes %0 for expecteText %1'.format(kToken, eToken));
			
				var position = "0";
				if (eToken.match(/^[1-9]/)) {
					position = (eToken.match(/^[1-9]/))[0];
					target.activeApp().typeKeystrokes(kToken, "", flick == '1');
					target.activeApp().waitUntilReady();
					International.verifyCandidatesWithPosition(eToken.substring(1), position, testCaseID);
					target.activeApp().tap(International.queryForKeyboardCandidateCellWithText(eToken.substring(1)));
				} else if (eToken.match(/^-/)) {
					target.activeApp().typeKeystrokes(kToken, "", flick == '1');
					target.activeApp().waitUntilReady();
					International.verifyCandidates(eToken.substring(1), true, testCaseID);
				} else {
					//Find all unicode encoding bytes and convert to normal chars
					var matched = eToken.match(/0x[0-9a-fA-F]+/g);
					if (matched != null && matched.length>0) {
						for(var k=0; k < matched.length; k++) {
							var toReplaceChar = International._utf16EncodeAsString(matched[k]);
							eToken = eToken.replace(matched[k], toReplaceChar);
						}
					}
					//type key strokes
					target.activeApp().typeKeystrokes(kToken, "", flick == '1');
					target.activeApp().waitUntilReady();
					International.verifyCandidatesWithCommands(eToken, testCaseID);
				}
			}
		}
    });
} // End verifyGroupedStrokesAndCandidatesWithCommands

/**
 * Verify if all specified candidate words are available in the current showing candiate bar.
 *
 * @param   {string}    candidates - string consist of one or more words separated by space character (0x20).
 * @param   {string}    position - position or range candidate expected to appear.
 *                          (e.g,  "1": 1st position, "2-": as 2nd or later position {opposite of "1"},
 *                                "4-6": range in 4th to 6th positions, "-5": range in last 5 positions.)
 * @param   {string}    testCaseID - will show TSTT test case ID if presented.
 * @returns {boolean} - if wrong pisition is specified, or verification is failed.
 * @throws              if verification is passed.
 */
International.verifyCandidatesWithPosition = function verifyCandidatesWithPosition(candidates, position, testCaseID) {
    International.withFunctionBoundaryLogging(this, function () {
        UIAUtilities.assert(candidates, 'Mandatory parameter, candidates, not specified');

        var posTop = 0;
        var posEnd = 9999;
        if (position.match(/^(\d+)$/)) {
            posTop = RegExp.$1;
            posEnd = RegExp.$1;
        } else if (position.match(/^(\d+)-$/)) {
            posTop = RegExp.$1;
        } else if (position.match(/^-(\d+)$/)) {
            posEnd = RegExp.$1;
        } else if (position.match(/^(\d+)-(\d+)$/)) {
            posTop = RegExp.$1;
            posEnd = RegExp.$2;
        } else {
            throw new UIAError('Unexpected position specifiers: %0'.format(position));
        }

        var candidateArray = candidates.split(/ +/);
        var typedText = target.activeApp().getTextFromElementForInternationalTyping();
        var candidateCells = target.activeApp().tap(UIAQuery.KEYBOARD_CANDIDATE_VIEW.andThen(UIAQuery.tableCells()).orElse(UIAQuery.collectionCells()));

        var candidateItems = [];
        for (var i = 0; i < candidateCells.length; i++) {
            candidateItems.push(candidateCells[i].name);
        }

        var failedItems = [];   // Available but out of position/range
        var missedItems = [];  // Missing
        var passedItems = [];
        for (var i = 0; i < candidateArray.length; i++) {
            var posCandidate = candidateItems.indexOf(candidateArray[i]) + 1;
            if (posCandidate < 1) {
                // Not in the candidates --> FAILED
                missedItems.push(candidateArray[i]);
            } else if (posTop <= posCandidate &&  posCandidate <= posEnd) {
                // Between posTop and posEnd --> PASSED
                passedItems.push(candidateArray[i]+'('+posCandidate+')');
            } else {
                // Not in position, or our of range --> FAILED
                failedItems.push(candidateArray[i]+'('+posCandidate+')');
            }
        }

        if (testCaseID) {
            UIALogger.logMessage('testCaseID: %0'.format(testCaseID));
        }
        var result = (failedItems.length < 1 && missedItems.length < 1);

        var passedString = passedItems.join(', ');
        var missedString = missedItems.join(', ');
        var failedString = failedItems.join(', ');

        UIALogger.logMessage('Verification: %0'.format(result ? 'Passed' : 'FAILED'));
        UIALogger.logMessage('    typedText         = [%0]'.format(typedText));
        UIALogger.logMessage('    range             = [%0 - %1]'.format(posTop, posEnd));
        UIALogger.logMessage('    candidates Passed = [%0]'.format(passedString));
        UIALogger.logMessage('    candidates Missed = [%0]'.format(missedString));
        UIALogger.logMessage('    candidates Failed = [%0]'.format(failedString));

        UIAUtilities.assert(result, 'Detected missing or out of range items in candidates!  TypedText=[%0], Passed=[%1], Missed=[%2], Failed=[%3]'.format(
            typedText,
            passedString,
            missedString,
            failedString
        ));
    });
} // End verifyCandidatesWithPosition

/**
 * Helper function to get UI text of keyboard type from keyboard ID,
 *
 * @param   {string}    keyboardID - iOS specific keyboard ID.
 *                          (e.g, "zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US", "ja_JP-Kana@sw=Kana-Flick;hw=US")
 * @returns {object}    UIString -  UI string object
 *          {string}    [UIString.type] - UI string of the Keyboard type
 *          {array}     [UIString.opts] - UI string of pair array of [switch-name, value], or null if no option switch required
 */
International.keyboardTypeFromKeyboardID = function keyboardTypeFromKeyboardID(keyboardID) {
    return International.withFunctionBoundaryLogging(this, function () {
        var languageID = keyboardID.match(/^[^-@]*/g)[0];
        keyboardID.match(/sw=([^;]*)/g);
        var keyboardType = RegExp.$1;

         function getTypeLocString(title, layout) {
            var titleUIString = target.localizedString(title, {
                    tableName:'KeyboardTitles',
                    bundlePath:'/System/Library/PreferenceBundles/KeyboardSettings.bundle'});
            if (!layout) return titleUIString;
            var layoutUIString = target.localizedString(layout, {
                    tableName:'KeyboardLayouts',
                    bundlePath:'/System/Library/PreferenceBundles/KeyboardSettings.bundle'});
            return '%0 – %1'.format(titleUIString, layoutUIString);
        };

        if (languageID == 'zh_Hans') {
            if (keyboardType == 'Pinyin-Simplified') {
                return {type:'Pinyin – QWERTY', opts:''};
                // TODO: Need to be internationalized for UI sting lookup
                // TODO: Will change like following for interntionalization effort
                // return {type:getTypeLocString('Pinyin', 'Pinyin-Simplified', opts:''};
            } else if (keyboardType == 'Pinyin10-Simplified') {
                return {type:'Pinyin – 10 Key', opts:''};
            } else if (keyboardType == 'AZERTY-Pinyin-Simplified') {
                return {type:'Pinyin – AZERTY', opts:''};
            } else if (keyboardType == 'HWR-Simplified') {
                return {type:'Handwriting', opts:''};
            } else if (keyboardType == 'Wubihua-Simplified') {
                return {type:'Stroke', opts:''};
            }
        } else if (languageID == 'zh_Hant') {
        
        	if( target.model() == 'iPad' ) {
				if (keyboardType == 'Zhuyin') {
					return {type:'Zhuyin', opts:''};
				} else if (keyboardType == 'HWR-Traditional') {
					return {type:'Handwriting', opts:''};
				} else if (keyboardType == 'Pinyin-Traditional') {
					return {type:'Pinyin – QWERTY', opts:''};
				} else if (keyboardType == 'Pinyin10-Traditional') {
					return {type:'Pinyin – 10 Key', opts:''};
				} else if (keyboardType == 'AZERTY-Pinyin-Traditional') {
					return {type:'Pinyin – AZERTY', opts:''};
				} else if (keyboardType == 'Wubihua-Traditional') {
					return {type:'Stroke', opts:''};
				} else if (keyboardType == 'Sucheng') {
					return {type:'Sucheng – Standard', opts:''};
				} else if (keyboardType == 'Sucheng-QWERTY') {
					return {type:'Sucheng – QWERTY', opts:''};
				} else if (keyboardType == 'Cangjie') {
					return {type:'Cangjie – Standard', opts:''};
				} else if (keyboardType == 'Cangjie-QWERTY') {
					return {type:'Cangjie – QWERTY', opts:''};
				}
        	} else {
				if (keyboardType == 'Zhuyin') {
					return {type:'Zhuyin – Standard', opts:''};
				} else if (keyboardType == 'ZhuyinDynamic') {
					return {type:'Zhuyin – Dynamic', opts:''};
				} else if (keyboardType == 'HWR-Traditional') {
					return {type:'Handwriting', opts:''};
				} else if (keyboardType == 'Pinyin-Traditional') {
					return {type:'Pinyin – QWERTY', opts:''};
				} else if (keyboardType == 'Pinyin10-Traditional') {
					return {type:'Pinyin – 10 Key', opts:''};
				} else if (keyboardType == 'AZERTY-Pinyin-Traditional') {
					return {type:'Pinyin – AZERTY', opts:''};
				} else if (keyboardType == 'Wubihua-Traditional') {
					return {type:'Stroke', opts:''};
				} else if (keyboardType == 'Sucheng') {
					return {type:'Sucheng – Standard', opts:''};
				} else if (keyboardType == 'Sucheng-QWERTY') {
					return {type:'Sucheng – QWERTY', opts:''};
				} else if (keyboardType == 'Cangjie') {
					return {type:'Cangjie – Standard', opts:''};
				} else if (keyboardType == 'Cangjie-QWERTY') {
					return {type:'Cangjie – QWERTY', opts:''};
				}
			}
        } else if (languageID == 'ja_JP') {
            if (keyboardType == 'Kana') {
                return {type:'Kana', opts:''};
            } else if (keyboardType == 'Kana-Flick') {
                return {type:'Kana', opts:['Flick Only', 1]};
            } else if (keyboardType == 'QWERTY-Japanese') {
                return {type:'Romaji', opts:''};
            }
        } else if (languageID == 'ko_KR') {
            if (keyboardType == 'Korean') {
                return {type:'Standard', opts:''};
            } else if (keyboardType == 'Korean10Key') {
                return {type:'10 Key', opts:''};
            }

        }
        return keyboardType;
    });
}
