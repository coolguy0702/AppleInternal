load('KeystrokesGenerator.js');

//----------------------------------------------------------------------------------------------------------------
//	Function: typeKeystrokes_LatinGeneric
//		type keystrokes on Latin keyboard except French
//
//	Parameters:
//      keystrokesText - keystroke text (e.g. hola)
//      expectedText - text to be displayed in text view or field on app
//      mode - Not used at this time, but for future
//
//	Returns:
//		true if key type is done successfully
//		Throws an error for any error cases.
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.typeKeystrokes_LatinGeneric = function typeKeystrokes_LatinGeneric(keystrokesText, expectedText, mode) {
    return International.withFunctionBoundaryLogging(this, function () {
        var currentKeyboardID  = this.app.getKeyboardID();
        UIALogger.logDebug("current keyboard ID: " + currentKeyboardID);

        //  Convert to array to accomodate basekey and index info for diacritics
        var originalChars = keystrokesText.split('');

        // Pre Processing
        var regularTypes = "";
        var typingStream = [];
        var indexOfStream = 0;
        
        for (var i = 0; i < originalChars.length; i++) {
            // type as is if the character found on keyboard
            if (this.baseKeyList.indexOf(originalChars[i]) >= 0) {
                regularTypes += originalChars[i];
            } else {
                var conversion = this.getPopupkeyInfo(originalChars[i]);
                if (conversion != false) {
                    // type character using tapCharPopup() if it's avalable in popup key menu
                    if (regularTypes !== "") {
                        typingStream[indexOfStream++] = {action:'typeString', data:regularTypes};
                        regularTypes = "";
                    }
                    typingStream[indexOfStream++] = {action:'tapPopup', data:conversion};
                } else {
                    regularTypes += originalChars[i];
                }
            }
        }
        if (regularTypes !== "") {
            typingStream[indexOfStream++] = {action:'typeString', data:regularTypes};
        }

        // Actual Typing
        for (var i = 0; i < indexOfStream; i++) {
            if (typingStream[i].action === 'tapPopup') {
                this.tapCharPopup(typingStream[i].data[0], typingStream[i].data[1], typingStream[i].data[2])
            } else {
                this.app.typeString(typingStream[i].data);
            }
        }

        return true;
    });
}

