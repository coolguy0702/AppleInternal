load('Mail.js');

load('International.js');

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Launch specified app for keyboard testing, and focus on text view or field to be typed.
 *
 * @returns {boolean} - always true if completed successfully.
 */
mail.setupForInternationalTyping = function setupForInternationalTyping(options) {
    International.withFunctionBoundaryLogging(this, function () {
		UIALogger.logMessage("Launching Mail");
        this.getToEmailFolder();
        // Get rid of Popover on iPad
        if (target.model() === 'iPad' && this.waitUntilPresent('PopoverDismissRegion', 0.5)) {
            this.tap('PopoverDismissRegion');
        }
        // Tap compose button
        UIALogger.logMessage('Tapping Compose');
        var composeButton = UIAQuery.buttons(LocStrings.COMPOSE).isVisible();
        if (!this.waitUntilPresent(composeButton)) {
            throw new UIAError('Compose button is not tappable');
        }
        this.tap(composeButton);
        this.tap(LocStrings.MESSAGE_BODY);
        // Erase all body text including signature
        this.cleanupForInternationalTyping();
    });
}

/*****************************************************************************/
/*                                                                           */
/*   Mark: Actions                                                           */
/*                                                                           */
/*      Atomic units of UI automation and helper functions                   */
/*      These will assume the devices is already in the required state       */
/*                                                                           */
/*****************************************************************************/

/**
 * Clear all text at focused text view or field on current app, for the next typing.
 *
 * @returns {boolean} - always true if completed successfully.
 * @throws              if callout menu cannot be shown.
 */
mail.cleanupForInternationalTyping = function cleanupForInternationalTyping() {
    International.withFunctionBoundaryLogging(this, function () {
        this.withMaximumSnapshotBreadth(400, function() {
            UIALogger.logMessage("Clearing the content for mail");
            this.tap("Return");
            this.tap("Return");  // Fix conversion forcedly if available
            this.tap(LocStrings.MESSAGE_BODY);
            if (!this.waitUntilPresent(UIAQuery.menuItems().isVisible(), 1)) {
                UIALogger.logMessage("Tap again to call callout menu.");
                this.tap(LocStrings.MESSAGE_BODY);
                if (!this.waitUntilPresent(UIAQuery.menuItems().isVisible(), 1)) {
                    throw new UIAError("Menu bar never appeared");
                }
            }
            this.tap(LocStrings.SELECT_ALL);
            this.typeString("\b");
        }.bind(this));
    });
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Get text in text view or field on current active app.
 *
 * @returns {string} -  typed text on text view or field. NULL if unsupported app is active.
 */
mail.getTextFromElementForInternationalTyping = function getTextFromElementForInternationalTyping() {
    return International.withFunctionBoundaryLogging(this, function () {
        var typedText = "";

        this.withMaximumSnapshotBreadth(400, function() {
            typedText = this.valueOf(UIAQuery.MAIL_MESSAGE_BODY);
        }.bind(this));

        return typedText;
    });
}
