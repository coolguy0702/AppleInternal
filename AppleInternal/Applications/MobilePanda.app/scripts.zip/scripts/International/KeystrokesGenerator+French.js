load('KeystrokesGenerator.js');

//----------------------------------------------------------------------------------------------------------------
//	Function: typeKeystrokes_French
//		type keystrokes on French keyboard
//
//	Parameters:
//      keystrokesText - keystroke text (e.g. hola)
//      expectedText - text to be displayed in text view or field on app
//      mode - type using diacritical key if true or "1"
//
//	Returns:
//		true if key type is done successfully
//		Throws an error for any error cases.
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.typeKeystrokes_French = function typeKeystrokes_French(keystrokesText, expectedText, mode) {
    return International.withFunctionBoundaryLogging(this, function () {
        var currentKeyboardID  = this.app.getKeyboardID();
        UIALogger.logDebug("current keyboard ID: " + currentKeyboardID);

        //  Convert to array to accomodate basekey and index info for diacritics
        var tempChars = keystrokesText.split('');

        // Exam character in tempChars, and convert or modify typing sequences to originalChars
        var originalChars = [];
        UIALogger.logDebug(mode ? "French keyboard typing: Use diacritical key if possible." : "French: Use popup key.");
        for (var i = 0; i < tempChars.length; i++) {
            if (mode) {
                Array.prototype.push.apply(originalChars, tempChars[i] == "'" ? ["’"] : this.decomposeFrenchCharacter(tempChars[i]));
            } else {
                Array.prototype.push.apply(originalChars, tempChars[i] == "'" ? ["’"] : [tempChars[i]]);
            }
        }
                                              
        // Pre Processing
        var regularTypes = "";
        var typingStream = [];
        var indexOfStream = 0;
        
        for (var i = 0; i < originalChars.length; i++) {
            // type as is if the character found on keyboard
            if (this.baseKeyList.indexOf(originalChars[i]) >= 0) {
                regularTypes += originalChars[i];
            }else {
                var conversion = this.getPopupkeyInfo(originalChars[i]);
                if (conversion != false) {
                    // type character using tapCharPopup() if it's avalable in popup key menu
                    if (regularTypes !== "") {
                        typingStream[indexOfStream++] = {action:'typeString', data:regularTypes};
                        regularTypes = "";
                    }
                    typingStream[indexOfStream++] = {action:'tapPopup', data:conversion};
                } else {
                    regularTypes += originalChars[i];
                }
            }
        }

        // Actual Typing
        for (var i = 0; i < indexOfStream; i++) {
            if (typingStream[i].action === 'tapPopup') {
                this.tapCharPopup(typingStream[i].data[0], typingStream[i].data[1], typingStream[i].data[2])
            } else {
                this.app.typeString(typingStream[i].data);
            }
        }
        
        return true;
    });
}


//----------------------------------------------------------------------------------------------------------------
//	Function: decomposeFrenchCharacter
//		decompose French character if it can be.
//
//	Parameters:
//      character - a French character
//
//	Returns:
//		key type sequence array: character as it is, or baseKey + "’" if it can be decomposed.
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.decomposeFrenchCharacter = function decomposeFrenchCharacter(character) {
    const decomposedCharacterTable = {
        'à': 'a', 'é': 'e', 'û': 'u', 'î': 'i', 'ô': 'o',
    };
    var baseKey = decomposedCharacterTable[character];
    return baseKey ? [baseKey, "’"] : [character];
}
