load('KeystrokesGenerator.js');
load('International.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

/**
 * @namespace
 */
UIAQuery.International.Chinese = {
    /** pinyin keyplane key */
    PINYIN_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('Pinyin-Plane')),

    /** alpha keyplane key */
    ABC_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('字母鍵盤')),

    /** number keyplane key */
    NUM_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('Number-Plane')),

    /** symbol keyplane key */
    SYM_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('更多')),
}

/**
 * type keystrokes on Simplified Chinese keyboard
 *
 * @param   {string}   keystrokesText - keystroke text (e.g. toukyou).
 * @param   {string}   expectedText - text to be displayed in text view or field on app (e.g. 北京).
 * @param   {string}   [flick="0"] - Optional enable flick typing if "1", keystrokes will be entered by flick gesture on 10-key keyboards
 **/
KeystrokesGenerator.prototype.typeKeystrokes_SimpChinese = function typeKeystrokes_SimpChinese(keystrokesText, expectedText, flick) {
    International.withFunctionBoundaryLogging(this, function () {
        var keyboardLayoutType = this.getKeyboardLayoutType();
        var keystrokesArray = [];

        if (keyboardLayoutType.match(/sw=Pinyin10-/i)) {
            // Convert keystrokesText to keystrokesArray for Chinese 10 key
            keystrokesArray = this.convertSimpChineseKeystrokesFor10key(keystrokesText, flick);
            UIALogger.logDebug("Convert Chinese Pinyin text to keystorkes for 10 key keyboard: " + JSON.stringify(keystrokesArray));
            //
            // For SimpChinese 10 key
            //
            UIALogger.logMessage("Handling Pinyin 10-Key keyboard typing");
            this.typeKeystrokesFor10key(keystrokesArray);
        } else if (keyboardLayoutType.match(/sw=Wubihua-Simplified/i)) {
            // Convert keystrokesText to keystrokesArray for Simplified Stroke Key
            keystrokesArray = this.convertSimpChineseKeystrokesForStroke(keystrokesText);
            UIALogger.logDebug("Convert Chinese Pinyin text to simplified stroke keyboard: " + JSON.stringify(keystrokesArray));
            UIALogger.logMessage("Handling Simplified Stroke 10-Key keyboard typing");
            this.typeKeystrokesFor10key(keystrokesArray);        	
        } else {
            //
            // For Other SimpChinese keyboards
            //
            UIALogger.logMessage("Handling other keyboard (e.g. Pinyin-Qwerty) typing");
            this.app.typeString(keystrokesText);
        }

        if (expectedText) {
            this.fixChineseConversionForTypedText(expectedText);
        }
    });
}

/**
 * Universal function to type keystrokes on zhuyin keyboards
 *
 * @param   {string}   keystrokesText - keystroke text (e.g. ㄨㄢˋㄨˊㄧㄕ)
 **/
KeystrokesGenerator.prototype.typeKeystrokes_TradChinese_Zhuyin = function typeKeystrokes_TradChinese_Zhuyin(keystrokesText) {
    International.withFunctionBoundaryLogging(this, function () {
        var characters = keystrokesText.split("");

        for (var i = 0; i < keystrokesText.length; i++) {
            var key;

            if (characters[i] == "ˉ") {
                this.app.tap(UIAQuery.keyboard().andThen(UIAQuery.keys('一聲')));
            } else if (characters[i] == "ˇ") {
                this.app.tap(UIAQuery.keyboard().andThen(UIAQuery.keys('三聲、')));
            } else {
                this.app.typeString(characters[i]);
            }
        }
    });
}

/**
 * type keystrokes on Cangjie keyboards, now support cangjie Standard and Qwerty layout
 *
 * @param   {string}    keystrokesText - Key storkes (e.g, Cangjie-Standard: "日月")
 **/
KeystrokesGenerator.prototype.typeKeystrokes_TradChinese_CangjieStandard = function typeKeystrokes_TradChinese_CangjieStandard(keystrokesText) {
    International.withFunctionBoundaryLogging(this, function () {
        var characters = keystrokesText.split("");

        for (var i = 0; i < keystrokesText.length; i++) {
            var key;

            if (characters[i] == "重") {
                this.app.tap(UIAQuery.keyboard().andThen(UIAQuery.keys('蟲')));
            } else {
                this.app.typeString(characters[i]);
            }
        }
    });
}

/**
 * type keystrokes on Traditional Chinese keyboard
 *
 * @param   {string}   keystrokesText - keystroke text (e.g. toukyou).
 * @param   {string}   expectedText - text to be displayed in text view or field on app (e.g. 東京).
 * @param   {string}   [flick="0"] - Optional enable flick typing if "1", keystrokes will be entered by flick gesture on 10-key keyboards
 **/
KeystrokesGenerator.prototype.typeKeystrokes_TradChinese = function typeKeystrokes_TradChinese(keystrokesText, expectedText, flick) {
    International.withFunctionBoundaryLogging(this, function () {
        var currentKeyboardID  = this.app.getKeyboardID();
        var keyboardLayoutType = currentKeyboardID.match(/(sw=[^;]*)/)[1];
        var keystrokesArray = [];

        if (keyboardLayoutType.match(/sw=Pinyin10-/i)) {
            // Convert keystrokesText to keystrokesArray for Chinese 10 key
            keystrokesArray = this.convertSimpChineseKeystrokesFor10key(keystrokesText, flick);
            UIALogger.logDebug("Convert Chinese Pinyin text to keystorkes for 10 key keyboard: " + JSON.stringify(keystrokesArray));
            //
            // For TradChinese 10 key
            //
            UIALogger.logMessage("Handling Pinyin 10-Key keyboard typing");
            this.typeKeystrokesFor10key(keystrokesArray);
        } else if (keyboardLayoutType.match(/sw=Wubihua-Traditional/i)) {
            // Convert keystrokesText to keystrokesArray for Simplified Stroke Key
            keystrokesArray = this.convertTradChineseKeystrokesForStroke(keystrokesText);
            UIALogger.logDebug("Convert Chinese strokes text to traditional stroke keyboard: " + JSON.stringify(keystrokesArray));
            UIALogger.logMessage("Handling Traditional Stroke 10-Key keyboard typing");
            this.typeKeystrokesFor10key(keystrokesArray);
        } else if ((keyboardLayoutType.match(/sw=Zhuyin/i))) {
            //
            // For TradChinese Zhuyin
            //
            //process some special keys.
            UIALogger.logMessage("Handling Zhuyin keyboard typing");
            this.typeKeystrokes_TradChinese_Zhuyin(keystrokesText);
        } else if ((keyboardLayoutType.match(/sw=Cangjie/i))) {
            //
            // For TradChinese Cangjie
            //
            //process some special keys.
            UIALogger.logMessage("Handling Cangjie keyboard typing");
            this.typeKeystrokes_TradChinese_CangjieStandard(keystrokesText);
        } else {
            //
            // For Other TradChinese keyboards
            //
            UIALogger.logMessage("Handling other keyboard (e.g. Pinyin-Qwerty) typing");
            this.app.typeString(keystrokesText);
        }

        if (expectedText) {
            // Need to be separated for SC and TC?
            this.fixChineseConversionForTypedText(expectedText);
        }
    });
}

/**
 * Set keyboard plain for Chinese 10 key keyboard
 *
 * @param   {string}    keyplane - type of planes (pinyin, abc, num, shift, sym)
 **/
KeystrokesGenerator.prototype.switchKeyplane_Chinese = function switchKeyplane_Chinese(keyplane) {
    International.withFunctionBoundaryLogging(this, function () {
        var keyplaneSwitchKey = {
            'pinyin':UIAQuery.International.Chinese.PINYIN_KEY,
            'abc':UIAQuery.International.Chinese.ABC_KEY,
            'sym':UIAQuery.International.Chinese.SYM_KEY,
            'shift':UIAQuery.KEYBOARD_SHIFT_BUTTON,
            'num':UIAQuery.KEYBOARD_SHIFT_BUTTON,
        }[keyplane];

        UIAUtilities.assert(typeof keyplaneSwitchKey !== 'undefined', 'Unrecognized keyplane identifier "%0"'.format(keyplane));

        this.app.tap(keyplaneSwitchKey);
    });
}

/**
 * Convert pinyin text to tap keystrokes for 10 key keyboard
 *
 * @param   {string}   strokesText - Simplified Chinese Pinyin text and some controls keys to be entered
 * @param   {boolean}  flick - generate keystroke steam for flick typing if true
 **/
KeystrokesGenerator.prototype.convertSimpChineseKeystrokesFor10key = function convertSimpChineseKeystrokesFor10key(strokesText, flick) {
    return International.withFunctionBoundaryLogging(this, function () {

        var STR_COMPLETE = target.localizedString('keyboard.complete.key', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });

        const conversionTable_Pinyin_Tap = {
            "a":[['a b c ', 1]], "b":[['a b c ', 1]], "c":[['a b c ', 1]], "d":[['d e f ', 1]], "e":[['d e f ', 1]], "f":[['d e f ', 1]],
            "g":[['g h i ', 1]], "h":[['g h i ', 1]], "i":[['g h i ', 1]], "j":[['j k l ', 1]], "k":[['j k l ', 1]], "l":[['j k l ', 1]],
            "m":[['m n o ', 1]], "n":[['m n o ', 1]], "o":[['m n o ', 1]], "t":[['t u v ', 1]], "u":[['t u v ', 1]], "v":[['t u v ', 1]],
            "p":[['p q r s ', 1]], "q":[['p q r s ', 1]], "r":[['p q r s ', 1]], "s":[['p q r s ', 1]],
            "w":[['w x y z ', 1]], "x":[['w x y z ', 1]], "y":[['w x y z ', 1]], "z":[['w x y z ', 1]],
            "'":[['Face marks', 1]], "，":[['，', 'L']], "。":[['，', 'U']], "？":[['，', 'R']], "！":[['，', 'D']]
            // Need flick input until <rdar://problem/25026132> is implemented in Chinese Pinyin10Key keyboard
            // "'":[['Face marks', 1]], "，":[['，', 1]], "。":[['，', 2]], "？":[['，', 3]], "！":[['，', 4]]
            };
        const conversionTable_Pinyin_Flick = {
            "a":[['a b c ', 'L']], "b":[['a b c ', 'U']], "c":[['a b c ', 'R']], "d":[['d e f ', 'L']], "e":[['d e f ', 'U']], "f":[['d e f ', 'R']],
            "g":[['g h i ', 'L']], "h":[['g h i ', 'U']], "i":[['g h i ', 'R']], "j":[['j k l ', 'L']], "k":[['j k l ', 'U']], "l":[['j k l ', 'R']],
            "m":[['m n o ', 'L']], "n":[['m n o ', 'U']], "o":[['m n o ', 'R']], "t":[['t u v ', 'L']], "u":[['t u v ', 'U']], "v":[['t u v ', 'R']],
            "p":[['p q r s ', 'L']], "q":[['p q r s ', 'U']], "r":[['p q r s ', 'R']], "s":[['p q r s ', 'D']],
            "w":[['w x y z ', 'L']], "x":[['w x y z ', 'U']], "y":[['w x y z ', 'R']], "z":[['w x y z ', 'D']],
            "'":[['Face marks', 1]], "，":[['，', 'L']], "。":[['，', 'U']], "？":[['，', 'R']], "！":[['，', 'D']]
            };
        const conversionTable_ABC_Tap = {
            ".":[['.', 1]], "_":[['.', 2]], "@":[['.', 3]], "/":[['.', 4]], "#":[['.', 5]],
            "a":[['a b c ', 1]], "b":[['a b c ', 2]], "c":[['a b c ', 3]], "d":[['d e f ', 1]], "e":[['d e f ', 2]], "f":[['d e f ', 3]],
            "g":[['g h i ', 1]], "h":[['g h i ', 2]], "i":[['g h i ', 3]], "j":[['j k l ', 1]], "k":[['j k l ', 2]], "l":[['j k l ', 3]],
            "m":[['m n o ', 1]], "n":[['m n o ', 2]], "o":[['m n o ', 3]], "t":[['t u v ', 1]], "u":[['t u v ', 2]], "v":[['t u v ', 3]],
            "p":[['p q r s ', 1]], "q":[['p q r s ', 2]], "r":[['p q r s ', 3]], "s":[['p q r s ', 4]],
            "w":[['w x y z ', 1]], "x":[['w x y z ', 2]], "y":[['w x y z ', 3]], "z":[['w x y z ', 4]],
            "A":[['==>shift', 1],['A B C ', 1]], "B":[['==>shift', 1],['A B C ', 2]], "C":[['==>shift', 1],['A B C ', 3]], "D":[['==>shift', 1],['D E F ', 1]], "E":[['==>shift', 1],['D E F ', 2]], "F":[['==>shift', 1],['D E F ', 3]],
            "G":[['==>shift', 1],['G H I ', 1]], "H":[['==>shift', 1],['G H I ', 2]], "I":[['==>shift', 1],['G H I ', 3]], "J":[['==>shift', 1],['J K L ', 1]], "K":[['==>shift', 1],['J K L ', 2]], "L":[['==>shift', 1],['J K L ', 3]],
            "M":[['==>shift', 1],['M N O ', 1]], "N":[['==>shift', 1],['M N O ', 2]], "O":[['==>shift', 1],['M N O ', 3]], "T":[['==>shift', 1],['T U V ', 1]], "U":[['==>shift', 1],['T U V ', 2]], "V":[['==>shift', 1],['T U V ', 3]],
            "P":[['==>shift', 1],['P Q R S ', 1]], "Q":[['==>shift', 1],['P Q R S ', 2]], "R":[['==>shift', 1],['P Q R S ', 3]], "S":[['==>shift', 1],['P Q R S ', 4]],
            "W":[['==>shift', 1],['W X Y Z ', 1]], "X":[['==>shift', 1],['W X Y Z ', 2]], "Y":[['==>shift', 1],['W X Y Z ', 3]], "Z":[['==>shift', 1],['W X Y Z ', 4]]
            };
        const conversionTable_ABC_Flick = {
            ".":[['.', 1]], "_":[['.', 2]], "@":[['.', 3]], "/":[['.', 4]], "#":[['.', 5]],
            "a":[['a b c ', 1]], "b":[['a b c ', 2]], "c":[['a b c ', 3]], "d":[['d e f ', 1]], "e":[['d e f ', 2]], "f":[['d e f ', 3]],
            "g":[['g h i ', 1]], "h":[['g h i ', 2]], "i":[['g h i ', 3]], "j":[['j k l ', 1]], "k":[['j k l ', 2]], "l":[['j k l ', 3]],
            "m":[['m n o ', 1]], "n":[['m n o ', 2]], "o":[['m n o ', 3]], "t":[['t u v ', 1]], "u":[['t u v ', 2]], "v":[['t u v ', 3]],
            "p":[['p q r s ', 1]], "q":[['p q r s ', 2]], "r":[['p q r s ', 3]], "s":[['p q r s ', 4]],
            "w":[['w x y z ', 1]], "x":[['w x y z ', 2]], "y":[['w x y z ', 3]], "z":[['w x y z ', 4]]
            };
        const conversionTable_NUM = {
            "1":[['1', 1]], "2":[['2', 1]], "3":[['3', 1]], "4":[['4', 1]], "5":[['5', 1]], "6":[['6', 1]], "7":[['7', 1]], "8":[['8', 1]], "9":[['9', 1]], "0":[['0', 1]]
            };
        const conversionTable_SYM_Tap = {
            "$":[['$', 1]], "¥":[['¥', 1]], "℃":[['2', 1]], "%":[['%', 1]], ",":[[',', 1]], "+":[['+', 1]], "-":[['-', 1]], ":":[[':', 1]], "/":[['/', 1]], "=":[['=', 1]], ".":[['.', 1]], "_":[['_', 1]]
        };


        var conversionTable_Pinyin = conversionTable_Pinyin_Tap;
        var conversionTable_ABC  = conversionTable_ABC_Tap;
        var conversionTable_SYM  = conversionTable_SYM_Tap;

        if (flick) {
            conversionTable_Pinyin = conversionTable_Pinyin_Flick;
            conversionTable_ABC  = conversionTable_ABC_Flick;
            conversionTable_SYM  = conversionTable_SYM_Tap;
        }

        var strokes = strokesText.split("");
        var strokesArray = [];
        var prevStrokeSet = [];
        var currentPlane = 'pinyin';

        for (i = 0; i < strokesText.length; i++) {
            var strokeSet = [];
            var planeSwitch = [];

            if (strokes[i] == '拼') {    // To switch to Pinyin plane
                strokeSet = [['==>pinyin',1]];
                currentPlane = 'pinyin';
            } else if (strokes[i] == '英') {    // To switch to Alphabet plane
                strokeSet = [['==>abc',1]];
                currentPlane = 'abc';
            } else if (strokes[i] == ' ') {    // space key
                strokeSet = [['空格',1]];
            } else if (currentPlane == 'pinyin' && conversionTable_Pinyin[strokes[i]]) {
                strokeSet = conversionTable_Pinyin[strokes[i]];
                if (currentPlane != 'pinyin') {
                    planeSwitch = [['==>pinyin',1]];
                    currentPlane = 'pinyin';
                }
            } else if (currentPlane != 'pinyin' && conversionTable_ABC[strokes[i]]) {
                strokeSet = conversionTable_ABC[strokes[i]];
                if (currentPlane != 'abc') {
                    planeSwitch = [['==>abc',1]];
                    currentPlane = 'abc';
                }
            } else if (conversionTable_NUM[strokes[i]]) {
                strokeSet = conversionTable_NUM[strokes[i]];
                if (currentPlane != 'num') {
                    planeSwitch = [['==>num',1]];
                    currentPlane = 'num';
                }
            } else if (conversionTable_SYM[strokes[i]]) {
                strokeSet = conversionTable_SYM[strokes[i]];
                if (currentPlane != 'sym') {
                    planeSwitch = [['==>num',1],['==>sym',1]];
                    currentPlane = 'sym';
                }
            } else {  // For other, assuming as Pinyin key
                strokeSet = [[strokes[i], 1]];
               if (currentPlane != 'pinyin') {
                    planeSwitch = [['==>pinyin',1]];
                    currentPlane = 'pinyin';
                }
            }
     
            // Add Complete button for tap case, if the first strokeSet is the same as prevous strokeSet, so we can avoid continual taps.
            // e.g. abc 1 tap + abc 2 taps should not be abc 3 taps, but abc 1tap + complete + abc 2 taps.
            // Commented out: <rdar://problem/21852368> No Complete key on Chinese 10 key needed
             if (currentPlane == 'abc' && typeof strokeSet[0][1] == 'number' && typeof prevStrokeSet[1] == 'number' && strokeSet[0][0] == prevStrokeSet[0]) {
                strokesArray = strokesArray.concat([[STR_COMPLETE, 1]]);
             }

            prevStrokeSet = strokeSet[strokeSet.length-1];  // Save the last strokeSet

            if (planeSwitch.length != 0) {
                strokeSet = planeSwitch.concat(strokeSet);
            }
            strokesArray = strokesArray.concat(strokeSet);
        }

        var result = [];
        for (var i = 0; i < strokesArray.length; i++) {
                result.push({key:strokesArray[i][0], act:strokesArray[i][1]});
        }

        return result;
    });
}

/**
 * Convert stroke text to tap keystrokes for stroke keyboard
 *
 * @param   {string}   strokesText - Traditional Chinese Stroke text and some controls keys to be entered (e.g. 丨乛一丨)
 **/
KeystrokesGenerator.prototype.convertTradChineseKeystrokesForStroke = function convertTradChineseKeystrokesForStroke(strokesText) {
    return International.withFunctionBoundaryLogging(this, function () {

		var STR_COMPLETE = target.localizedString('keyboard.complete.key', {
								bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
								tableName:'Accessibility'
							});

		const conversionTableTradStroke = {
			一:[['橫', 1]], 丨:[['豎', 1]], 丿:[['撇', 1]],
			丶:[['點', 1]], 乛:[['折', 1]], "＊":[['Any stroke…', 1]],
			"，":[['，', 1]], "。":[['。', 1]],
            "？":[['？', 'L']], "！":[['？', 'U']], "、":[['？', 'R']]
			};

		var conversionTable_TradStroke = conversionTableTradStroke;

		var strokes = strokesText.split("");
		var strokesArray = [];
		var prevStrokeSet = [];
		var currentPlane = 'stroke';
        
		for (i = 0; i < strokesText.length; i++) {
			var strokeSet = [];
			var planeSwitch = [];

			if (strokes[i] == '筆') {    // To switch to Pinyin plane
				strokeSet = [['==>stroke',1]];
				currentPlane = 'stroke';
			} else if (strokes[i] == '英' || strokes[i] == '字') {    // To switch to Alphabet plane
				strokeSet = [['==>abc',1]];
				currentPlane = 'abc';
			} else if (strokes[i] == ' ') {    // space key
				strokeSet = [['空格',1]];
			} else if (currentPlane == 'stroke' ) {
				strokeSet = conversionTable_TradStroke[strokes[i]];
				if (currentPlane != 'stroke') {
					planeSwitch = [['==>stroke',1]];
					currentPlane = 'stroke';
				}
			} else {  // For other, assuming as stroke key
				strokeSet = [[strokes[i], 1]];
			   if (currentPlane != 'stroke') {
					planeSwitch = [['==>stroke',1]];
					currentPlane = 'stroke';
				}
			}
			
			// Add Complete button for tap case, if the first strokeSet is the same as prevous strokeSet, so we can avoid continual taps.
			// e.g. abc 1 tap + abc 2 taps should not be abc 3 taps, but abc 1tap + complete + abc 2 taps.
			// Commented out: <rdar://problem/21852368> No Complete key on Chinese 10 key needed
			 if (currentPlane == 'abc' && typeof strokeSet[0][1] == 'number' && typeof prevStrokeSet[1] == 'number' && strokeSet[0][0] == prevStrokeSet[0]) {
				strokesArray = strokesArray.concat([[STR_COMPLETE, 1]]);
			 }

			prevStrokeSet = strokeSet[strokeSet.length-1];  // Save the last strokeSet

			if (planeSwitch.length != 0) {
				strokeSet = planeSwitch.concat(strokeSet);
			}
			strokesArray = strokesArray.concat(strokeSet);
		}

		var result = [];
		for (var i = 0; i < strokesArray.length; i++) {
				result.push({key:strokesArray[i][0], act:strokesArray[i][1]});
		}

		return result;
	});
} // End convertTradChineseKeystrokesForStroke

/**
 * Convert stroke text to tap keystrokes for stroke keyboard
 *
 * @param   {string}   strokesText - Simplified Chinese Stroke text and some controls keys to be entered (e.g. 丨乛一丨)
 **/
KeystrokesGenerator.prototype.convertSimpChineseKeystrokesForStroke = function convertSimpChineseKeystrokesForStroke(strokesText) {
    return International.withFunctionBoundaryLogging(this, function () {

		var STR_COMPLETE = target.localizedString('keyboard.complete.key', {
								bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
								tableName:'Accessibility'
							});

		const conversionTableSimpStroke = {
			一:[['横', 1]], 丨:[['竖', 1]], 丿:[['撇', 1]],
			丶:[['点', 1]], 乛:[['折', 1]], "＊":[['Any stroke…', 1]],
			"，":[['，', 1]], "。":[['。', 1]],
            "？":[['？', 'L']], "！":[['？', 'U']], "、":[['？', 'R']]
			};

		var conversionTable_SimpStroke = conversionTableSimpStroke;

		var strokes = strokesText.split("");
		var strokesArray = [];
		var prevStrokeSet = [];
		var currentPlane = 'stroke';

		for (i = 0; i < strokesText.length; i++) {
			var strokeSet = [];
			var planeSwitch = [];

			if (strokes[i] == '笔') {    // To switch to Stroke plane
				strokeSet = [['==>stroke',1]];
				currentPlane = 'stroke';
			} else if (strokes[i] == '英' || strokes[i] == '字') {    // To switch to Alphabet plane
				strokeSet = [['==>abc',1]];
				currentPlane = 'abc';
			} else if (strokes[i] == ' ') {    // space key
				strokeSet = [['空格',1]];
			} else if (currentPlane == 'stroke' ) {
				strokeSet = conversionTable_SimpStroke[strokes[i]];
				if (currentPlane != 'stroke') {
					planeSwitch = [['==>stroke',1]];
					currentPlane = 'stroke';
				}
			} else {  // For other, assuming as stroke key
				strokeSet = [[strokes[i], 1]];
			   if (currentPlane != 'stroke') {
					planeSwitch = [['==>stroke',1]];
					currentPlane = 'stroke';
				}
			}

			// Add Complete button for tap case, if the first strokeSet is the same as prevous strokeSet, so we can avoid continual taps.
			// e.g. abc 1 tap + abc 2 taps should not be abc 3 taps, but abc 1tap + complete + abc 2 taps.
			// Commented out: <rdar://problem/21852368> No Complete key on Chinese 10 key needed
			 if (currentPlane == 'abc' && typeof strokeSet[0][1] == 'number' && typeof prevStrokeSet[1] == 'number' && strokeSet[0][0] == prevStrokeSet[0]) {
				strokesArray = strokesArray.concat([[STR_COMPLETE, 1]]);
			 }

			prevStrokeSet = strokeSet[strokeSet.length-1];  // Save the last strokeSet

			if (planeSwitch.length != 0) {
				strokeSet = planeSwitch.concat(strokeSet);
			}
			strokesArray = strokesArray.concat(strokeSet);
		}

		var result = [];
		for (var i = 0; i < strokesArray.length; i++) {
				result.push({key:strokesArray[i][0], act:strokesArray[i][1]});
		}

		return result;
	});
} // End convertSimpChineseKeystrokesForStroke

/**
 * Cadidate selection from candidates bar for Chinese keybords
 *
 * @param   {string}   expectedText - A candidate to select
 **/
KeystrokesGenerator.prototype.fixChineseConversionForTypedText = function fixChineseConversionForTypedText(expectedText) {
    return International.withFunctionBoundaryLogging(this, function () {
        // FIXME: we should try to avoid this hardcoded wait
        this.app.delay(0.5);

        if (expectedText) {
            // Select expected conversion candidate after typing
            this.app.tap(International.queryForKeyboardCandidateCellWithText(expectedText));
        }
    });
}

