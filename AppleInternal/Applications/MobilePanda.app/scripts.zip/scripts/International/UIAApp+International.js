load('UIAApp.js');
load('UIAApp+Keyboard.js');

load('KeystrokesGenerator.js');

/******************************************************************************/
/*                                                                            */
/*   Mark: Query Constants                                                    */
/*                                                                            */
/*      App specific queries that will be used frequently                     */
/*                                                                            */
/******************************************************************************/
/** @namespace */
UIAQuery.International = {
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Maps Localized String Constants                                     */
/*                                                                             */
/*      A dictionary of localization look up strings                           */
/*      To abstract the localized string constants for Maps                    */
/*                                                                             */
/*******************************************************************************/

LocStrings.International = {
};

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Launch specified app for keyboard testing, and focus on text view or field to be typed.
 *
 * @returns {boolean} - always true if completed successfully.
 */
UIAApp.prototype.setupForInternationalTyping = function setupForInternationalTyping(options) {
    throw new UIAError("Application '%0' does not support international typing.", this.name());
}

/*****************************************************************************/
/*                                                                           */
/*   Mark: Actions                                                           */
/*                                                                           */
/*      Atomic units of UI automation and helper functions                   */
/*      These will assume the devices is already in the required state       */
/*                                                                           */
/*****************************************************************************/

/**
 * Clear all text at focused text view or field on current app, for the next typing.
 *
 * @returns {boolean} - always true if completed successfully.
 * @throws              if callout menu cannot be shown.
 */
UIAApp.prototype.cleanupForInternationalTyping = function cleanupForInternationalTyping() {
    throw new UIAError("Application '%0' does not support international typing.", this.name());
}

UIAApp.prototype.keystrokesGeneratorForActiveKeyboard = function keystrokesGeneratorForActiveKeyboard() {
    var keyboardID = this.getKeyboardID();
    var languageID = keyboardID.match(/^[^-@]*/g)[0];

    if (typeof this._keystrokesGenerator === 'undefined' || this._keystrokesGenerator.languageID != languageID) {
        this._keystrokesGenerator = new KeystrokesGenerator(this, languageID);
    }

    return this._keystrokesGenerator;
}

/**
 *  This function types storokes on current loaded Asian international keyboards such as Chinese, Japanese, Korean into current focused view; text field, text view, search field, etc.
 *
 * @param   {string}  keystrokesText - text for keystroles on current keyboard.
 * @param   {string}  expectedText - expected text to be displayed on the view for conversion. If empty no conversion happens.
 * @param   {boolean} flick - if this is true, keystrokes will be entered by flick gesture on appropriate 10-key keyboard
 *
 *  @returns None
 */
UIAApp.prototype.typeKeystrokes = function typeKeystrokes(keystrokesText, expectedText, flick) {
    this.keystrokesGeneratorForActiveKeyboard().typeKeystrokes(keystrokesText, expectedText, flick);
}

/**
 * Get keyboardIDs for all available keyboards on currently activated text view or field.
 *
 * @returns {array} -   array of keyboard IDs.
 */
UIAApp.prototype.getAvailableKeyboardIDs = function getAvailableKeyboardIDs() {

    var currentKeyboardID = this.getKeyboardID();
    var keyboardIDs = [currentKeyboardID];

    this.tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
    var keyboardID = this.getKeyboardID();

    while (currentKeyboardID != keyboardID && limit-- > 0) {
        keyboardIDs.push(keyboardID);
        this.tap(UIAQuery.KEYBOARD_SWITCHER_BUTTON);
        keyboardID = this.getKeyboardID()
     }

    return keyboardIDs;
}

/**
 * Get text in text view or field on current active app.
 *
 * @returns {string} -  typed text on text view or field. NULL if unsupported app is active.
 */
UIAApp.prototype.getTextFromElementForInternationalTyping = function getTextFromElementForInternationalTyping() {
    return International.withFunctionBoundaryLogging(this, function () {
        var typedText = "";

        this.withMaximumSnapshotBreadth(400, function() {
            typedText = this.valueOf(UIAQuery.textViews().orElse(UIAQuery.textFields()).isVisible());
        }.bind(this));

        return typedText;
    });
}

/**
 * Get date and time word candidates on current active keyboard/app.
 *
 * @returns {string} -  typed text on text view or field. NULL if unsupported app is active.
 */
UIAApp.prototype.getExpectedDateWordCandidates = function getExpectedDateWordCandidates(dateTimeID) {
    return International.withFunctionBoundaryLogging(this, function () {
        var candidates = "";

        this.withMaximumSnapshotBreadth(400, function() {
            candidates = this.keystrokesGeneratorForActiveKeyboard().getExpectedDateWordCandidates(dateTimeID);
        }.bind(this));

        return candidates;
    });
}

