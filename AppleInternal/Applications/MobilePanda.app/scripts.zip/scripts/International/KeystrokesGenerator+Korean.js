load('KeystrokesGenerator.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAQuery.International.Korean = {
    /* hangul keyplane key */
    HANGUL_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('한글')),

    /* alpha keyplane key */
    ABC_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('기타, 숫자')),

    /* number keyplane key */
    NUM_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('기타, 문자')),

    /* symbol keyplane key */
    SYM_KEY: UIAQuery.keyboard().andThen(UIAQuery.keys('기타, 문자')),
}

//----------------------------------------------------------------------------------------------------------------
//	Function: typeKeystrokes_Korean
//		type keystrokes on Korean keyboard
//
//	Parameters:
//      keystrokesText - keystroke text (e.g. toukyou).
//      expectedText - text to be displayed in text view or field on app (e.g. 東京).  Kanji conversion won't happen if empty on Japanese keyboards
//      flick - if this is true, keystrokes will be entered by flick gesture on appropriate 10-key keyboards
//
//	Returns:
//		true if selection succeeded
//		Throws an error if expectedText is not in the candidate list
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.typeKeystrokes_Korean = function typeKeystrokes_Korean(keystrokesText, expectedText, flick) {
    International.withFunctionBoundaryLogging(this, function () {
        var keyboardLayoutType = this.getKeyboardLayoutType();
        var keystrokesArray = [];

                                              
        if (keyboardLayoutType.match(/sw=Korean10key$/i)) {
            // Convert keystrokesText to keystrokesArray for Korean 10 key
            keystrokesArray = this.convertKoreanKeystrokesFor10key(this.breakKoreanTextIntoParts(keystrokesText), flick);
            UIALogger.logDebug("Breaking Korean text to keystorkes for 10 key keyboard tap or flick: " + JSON.stringify(keystrokesArray));
        } else if (keyboardLayoutType.match(/sw=Korean$/i)) {
            // Convert keystrokesText to keystrokesArray for Korean qwerty key
            keystrokesText = this.convertKoreanKeystrokesForQwerty(
                                    this.breakKoreanTextIntoParts(keystrokesText));
            UIALogger.logMessage("Breaking Korean text to keystorkes for qwerty keyboard: " + keystrokesText);
        }

        if (keyboardLayoutType.match(/sw=Korean10Key$/)) {
            //
            // For Korean 10 key
            //
            UIALogger.logMessage("Handling Korean 10 key keyboard typing");
            this.switchKeyplane('hangul');    // Reset keyboard plane to Hangle
            this.typeKeystrokesFor10key(keystrokesArray);
        } else {
            //
            // For Korean QWERTY
            //
            UIALogger.logMessage("Handling Korean QWERTY keyboard typing");
            this.app.typeString(keystrokesText);
        }
    });
}

//----------------------------------------------------------------------------------------------------------------
//	Function: switchKeyplane_Korean
//		Set keyboard plain for Korean 10 key keyboard
//
//	Parameters:
//		plane		type of planes (hangul, alphabet, number, or symbol)
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.switchKeyplane_Korean = function switchKeyplane_Korean(keyplane) {
    International.withFunctionBoundaryLogging(this, function () {
        var keyplaneSwitchKey = {
            'hangul':UIAQuery.International.Korean.HANGUL_KEY,
            'abc':UIAQuery.International.Korean.ABC_KEY,
            'sym':UIAQuery.International.Korean.SYM_KEY,
            'num':UIAQuery.International.Korean.NUM_KEY,
            'shift':UIAQuery.KEYBOARD_SHIFT_BUTTON,
        }[keyplane];

        UIAUtilities.assert(typeof keyplaneSwitchKey !== 'undefined', 'Unrecognized keyplane identifier "%0"'.format(keyplane));

        this.app.tap(plainSwitchKey);
    });
}

//---------------------------------------------------------------------------------------------
// Function: convertKoreanKeystrokesForQwerty
//      Some Korean double-Jamo is re-decomposed in key strokes level for qwerty keyboard
//          after being decomposed by koreanBreaker
// Parameters:
//      strokeParts : brokenText from koreanBreaker
//---------------------------------------------------------------------------------------------  
KeystrokesGenerator.prototype.convertKoreanKeystrokesForQwerty = function convertKoreanKeystrokesForQwerty(strokeParts) {
    return International.withFunctionBoundaryLogging(this, function () {
        var decomposedStrokes = new Array();
     
        for (var i = 0; i < strokeParts.length; i++) {
             //Handling a space and a complete key symbol
             if (strokeParts[i] == " ")
                 decomposedStrokes.push(" ");
             else if (strokeParts[i] == String.fromCharCode(0xF7F1))
                 decomposedStrokes.push("");
             //when it's a single-Jamo, no processing is required
             else
                 decomposedStrokes.push(strokeParts[i]);
        }
        return decomposedStrokes.join("");
    });
} // End convertKoreanKeystrokesForQwerty


//---------------------------------------------------------------------------------------------
// Function: convertKoreanKeystrokesFor10keyTap
//      Korean Jamos that were decomposed from koreanBreaker are now converted for 10 Key strokes
// Parameters:
//      strokeParts : brokenText from koreanBreaker
//--------------------------------------------------------------------------------------------- 
KeystrokesGenerator.prototype.convertKoreanKeystrokesFor10key = function convertKoreanKeystrokesFor10key(strokeParts, flick) {
    return International.withFunctionBoundaryLogging(this, function () {
         var STR_COMPLETE = target.localizedString('keyboard.complete.key', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });
         var STR_UPPERLOWER = target.localizedString('shift.key', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });
         var STR_PUNCTUATION = target.localizedString('Punctuation', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });
         
         const conversionTable_10key_Tap = {
             ㄱ:[['ㄱ', 1]], ㅋ:[['ㄱ', 2]], ㄲ:[['ㄱ', 3]],
             ㄴ:[['ㄴ', 1]], ㄹ:[['ㄴ', 2]],
             ㄷ:[['ㄷ', 1]], ㅌ:[['ㄷ', 2]], ㄸ:[['ㄷ', 3]],
             ㅂ:[['ㅂ', 1]], ㅍ:[['ㅂ', 2]], ㅃ:[['ㅂ', 3]],
             ㅅ:[['ㅅ', 1]], ㅎ:[['ㅅ', 2]], ㅆ:[['ㅅ', 3]],
             ㅈ:[['ㅈ', 1]], ㅊ:[['ㅈ', 2]], ㅉ:[['ㅈ', 3]],
             ㅇ:[['ㅇ', 1]], ㅁ:[['ㅇ', 2]],
             ㅣ:[['ㅣ', 1]], ㅓ:[['ㆍ', 1], ['ㅣ', 1]], ㅏ:[['ㅣ', 1], ['ㆍ', 1]], ㅕ:[['ㆍ', 2], ['ㅣ', 1]], ㅑ:[['ㅣ', 1], ['ㆍ', 2]],
             ㅡ:[['ㅡ', 1]], ㅠ:[['ㅡ', 1], ['ㆍ', 2]], ㅛ:[['ㆍ', 2], ['ㅡ', 1]], ㅗ:[['ㆍ', 1], ['ㅡ', 1]], ㅜ:[['ㅡ', 1], ['ㆍ', 1]],
             ㅐ:[['ㅣ', 1], ['ㆍ', 1], ['ㅣ', 1]], ㅒ:[['ㅣ', 1], ['ㆍ', 2], ['ㅣ', 1]], ㅔ:[['ㆍ', 1], ['ㅣ', 2]], ㅖ:[['ㆍ', 2], ['ㅣ', 2]],
             ㆍ:[['ㆍ', 1]],
             " ":[['간격', 1]], "":[['', 1]]
         };
         
         const conversionTable_10key_Flick = {
             ㄱ:[['ㄱ', 'L']], ㅋ:[['ㄱ', 'R']], ㄲ:[['ㄱ', 'D']],
             ㄴ:[['ㄴ', 'L']], ㄹ:[['ㄴ', 'R']],
             ㄷ:[['ㄷ', 'L']], ㅌ:[['ㄷ', 'R']], ㄸ:[['ㄷ', 'D']],
             ㅂ:[['ㅂ', 'L']], ㅍ:[['ㅂ', 'R']], ㅃ:[['ㅂ', 'D']],
             ㅅ:[['ㅅ', 'L']], ㅎ:[['ㅅ', 'R']], ㅆ:[['ㅅ', 'D']],
             ㅈ:[['ㅈ', 'L']], ㅊ:[['ㅈ', 'R']], ㅉ:[['ㅈ', 'D']],
             ㅇ:[['ㅇ', 'L']], ㅁ:[['ㅇ', 'R']],
             ㅣ:[['ㅣ', 1]], ㅓ:[['ㅣ', 'L']], ㅏ:[['ㅣ', 'R']], ㅕ:[['ㅣ', 'U']], ㅑ:[['ㅣ', 'D']],
             ㅡ:[['ㅡ', 1]], ㅠ:[['ㅡ', 'L']], ㅛ:[['ㅡ', 'R']], ㅗ:[['ㅡ', 'U']], ㅜ:[['ㅡ', 'D']],
             ㅐ:[['ㅣ', 'R'], ['ㅣ', 1]], ㅒ:[['ㅣ', 'R'], ['ㆍ', 1], ['ㅣ', 1]], ㅔ:[['ㅣ', 'L'], ['ㅣ', 1]], ㅖ:[['ㅣ', 'L'], ['ㆍ', 1], ['ㅣ', 1]],
             ㆍ:[['ㆍ', 1]],
             " ":[['간격', 1]], "":[['', 1]]
         };
         
         const conversionTable_ABC_Tap = {
             "@":[['@ # / & _ ', 1]], "#":[['@ # / & _ ', 2]], "/":[['@ # / & _ ', 3]], "&":[['@ # / & _ ', 4]], "_":[['@ # / & _ ', 5]],
             "a":[['a b c ', 1]], "b":[['a b c ', 2]], "c":[['a b c ', 3]], "d":[['d e f ', 1]], "e":[['d e f ', 2]], "f":[['d e f ', 3]],
             "g":[['g h i ', 1]], "h":[['g h i ', 2]], "i":[['g h i ', 3]], "j":[['j k l ', 1]], "k":[['j k l ', 2]], "l":[['j k l ', 3]],
             "m":[['m n o ', 1]], "n":[['m n o ', 2]], "o":[['m n o ', 3]], "t":[['t u v ', 1]], "u":[['t u v ', 2]], "v":[['t u v ', 3]],
             "p":[['p q r s ', 1]], "q":[['p q r s ', 2]], "r":[['p q r s ', 3]], "s":[['p q r s ', 4]],
             "w":[['w x y z ', 1]], "x":[['w x y z ', 2]], "y":[['w x y z ', 3]], "z":[['w x y z ', 4]],
             "A":[['A B C ', 1]], "B":[['A B C ', 2]], "C":[['A B C ', 3]], "D":[['D E F ', 1]], "E":[['D E F ', 2]], "F":[['D E F ', 3]],
             "G":[['G H I ', 1]], "H":[['G H I ', 2]], "I":[['G H I ', 3]], "J":[['J K L ', 1]], "K":[['J K L ', 2]], "L":[['J K L ', 3]],
             "M":[['M N O ', 1]], "N":[['M N O ', 2]], "O":[['M N O ', 3]], "T":[['T U V ', 1]], "U":[['T U V ', 2]], "V":[['T U V ', 3]],
             "P":[['P Q R S ', 1]], "Q":[['P Q R S ', 2]], "R":[['P Q R S ', 3]], "S":[['P Q R S ', 4]],
             "W":[['W X Y Z ', 1]], "X":[['W X Y Z ', 2]], "Y":[['W X Y Z ', 3]], "Z":[['W X Y Z ', 4]],
             ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 2]], "?":[[STR_PUNCTUATION, 3]],"!":[[STR_PUNCTUATION, 4]]
         };
         
         const conversionTable_ABC_Flick = {
             "@":[['@ # / & _ ', 1]], "#":[['@ # / & _ ', 'L']], "/":[['@ # / & _ ', 'U']], "&":[['@ # / & _ ', 'R']], "_":[['@ # / & _ ', 'D']],
             "a":[['a b c ', 1]], "b":[['a b c ', 'L']], "c":[['a b c ', 'U']], "d":[['d e f ', 1]], "e":[['d e f ', 'L']], "f":[['d e f ', 'U']],
             "g":[['g h i ', 1]], "h":[['g h i ', 'L']], "i":[['g h i ', 'U']], "j":[['j k l ', 1]], "k":[['j k l ', 'L']], "l":[['j k l ', 'U']],
             "m":[['m n o ', 1]], "n":[['m n o ', 'L']], "o":[['m n o ', 'U']], "t":[['t u v ', 1]], "u":[['t u v ', 'L']], "v":[['t u v ', 'U']],
             "p":[['p q r s ', 1]], "q":[['p q r s ', 'L']], "r":[['p q r s ', 'U']], "s":[['p q r s ', 'R']],
             "w":[['w x y z ', 1]], "x":[['w x y z ', 'L']], "y":[['w x y z ', 'U']], "z":[['w x y z ', 'R']],
             "A":[['A B C ', 1]], "B":[['A B C ', 'L']], "C":[['A B C ', 'U']], "D":[['D E F ', 1]], "E":[['D E F ', 'L']], "F":[['D E F ', 'U']],
             "G":[['G H I ', 1]], "H":[['G H I ', 'L']], "I":[['G H I ', 'U']], "J":[['J K L ', 1]], "K":[['J K L ', 'L']], "L":[['J K L ', 'U']],
             "M":[['M N O ', 1]], "N":[['M N O ', 'L']], "O":[['M N O ', 'U']], "T":[['T U V ', 1]], "U":[['T U V ', 'L']], "V":[['T U V ', 'U']],
             "P":[['P Q R S ', 1]], "Q":[['P Q R S ', 'L']], "R":[['P Q R S ', 'U']], "S":[['P Q R S ', 'R']],
             "W":[['W X Y Z ', 1]], "X":[['W X Y Z ', 'L']], "Y":[['W X Y Z ', 'U']], "Z":[['W X Y Z ', 'R']],
             ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 'L']], "?":[[STR_PUNCTUATION, 'U']],"!":[[STR_PUNCTUATION, 'R']]
         };
         
         const conversionTable_NUM_Tap = {
             "1":[['1', 1]], "2":[['2', 1]], "3":[['3', 1]], "4":[['4', 1]], "5":[['5', 1]], "6":[['6', 1]], "7":[['7', 1]], "8":[['8', 1]], "9":[['9', 1]], "0":[['0', 1]],
             "(":[['1', 2]], "-":[['1', 3]], ")":[['1', 4]], "₩":[['2', 2]], "$":[['2', 3]], "¥":[['2', 4]], "^":[['3', 2]], "%":[['3', 3]], "#":[['3', 4]],
             "{":[['4', 2]], "*":[['4', 3]], "}":[['4', 4]], "+":[['5', 2]], "×":[['5', 3]], "÷":[['5', 4]], "<":[['6', 2]], "=":[['6', 3]], ">":[['6', 4]],
             "[":[['7', 2]], ":":[['7', 3]], "]":[['7', 4]], "\"":[['8', 2]], "\'":[['8', 3]], ";":[['8', 4]], "\/":[['9', 2]], "\\":[['9', 3]], "\|":[['9', 4]],
             "〜":[['0', 2]], "…":[['0', 3]], "•":[['0', 4]], ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 2]], "?":[[STR_PUNCTUATION, 3]], "!":[[STR_PUNCTUATION, 4]]
         };
         
         const conversionTable_NUM_Flick = {
             "1":[['1', 1]], "2":[['2', 1]], "3":[['3', 1]], "4":[['4', 1]], "5":[['5', 1]], "6":[['6', 1]], "7":[['7', 1]], "8":[['8', 1]], "9":[['9', 1]], "0":[['0', 1]],
             "(":[['1', 'L']], "-":[['1', 'U']], ")":[['1', 'R']], "₩":[['2', 'L']], "$":[['2', 'U']], "¥":[['2', 'R']], "^":[['3', 'L']], "%":[['3', 'U']], "#":[['3', 'R']],
             "{":[['4', 'L']], "*":[['4', 'U']], "}":[['4', 'R']], "+":[['5', 'L']], "×":[['5', 'U']], "÷":[['5', 'R']], "<":[['6', 'L']], "=":[['6', 'U']], ">":[['6', 'R']],
             "[":[['7', 'L']], ":":[['7', 'U']], "]":[['7', 'R']], "\"":[['8', 'L']], "\'":[['8', 'U']], ";":[['8', 'R']], "\/":[['9', 'L']], "\\":[['9', 'U']], "\|":[['9', 'R']],
             "〜":[['0', 'L']], "…":[['0', 'U']], "•":[['0', 'R']], ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 'L']], "?":[[STR_PUNCTUATION, 'U']], "!":[[STR_PUNCTUATION, 'R']]
         };
         
         var conversionTable_10key = conversionTable_10key_Tap;
         var conversionTable_ABC  = conversionTable_ABC_Tap;
         var conversionTable_NUM  = conversionTable_NUM_Tap;
         
         if (flick) {
            conversionTable_10key = conversionTable_10key_Flick;
            conversionTable_ABC  = conversionTable_ABC_Flick;
            conversionTable_NUM  = conversionTable_NUM_Flick;
         }
         
         var strokes = strokeParts.split("");
         var strokesArray = [];
         var prevStrokeSet = [];
         var currentPlane = 'hangul';
         
         for (var i = 0; i < strokes.length; i++) {
            var strokeSet = [];
            var planeSwitch = [];

            if (conversionTable_10key[strokes[i]]) {
                strokeSet = conversionTable_10key[strokes[i]];
 
                if (currentPlane != 'hangul') {
                    planeSwitch = [['==>hangul', 1]];
                    currentPlane = 'hangul';
                }
            } else if (conversionTable_ABC[strokes[i]]) {
                if (strokes[i] == strokes[i].toLowerCase()) {
                    strokeSet = conversionTable_ABC[strokes[i]];
                } else {
                    strokeSet = [['==>shift', 1]];
                    strokeSet = strokeSet.concat(conversionTable_ABC[strokes[i]]);
                }
                strokeSet = strokeSet.concat([[STR_COMPLETE, 1]]);
                if (currentPlane != 'abc') {
                    planeSwitch = [['==>abc', 1]];
                    currentPlane = 'abc';
                }
            } else if (conversionTable_NUM[strokes[i]]) {
                strokeSet = conversionTable_NUM[strokes[i]];
                //strokeSet = strokeSet.concat([[STR_COMPLETE, 1]]);
                if (currentPlane != 'num') {
                    planeSwitch = [['==>num', 1]];
                currentPlane = 'num';
                }
            } else {  // For other, assuming as hangul key
                strokeSet = [[strokes[i], 1]];
                if (currentPlane != 'hangul') {
                    planeSwitch = [['==>hangul', 1]];
                    currentPlane = 'hangul';
                }
            }
         
             if (!conversionTable_10key[strokes[i]] && typeof strokeSet[0][1] == 'number' && typeof prevStrokeSet[1] == 'number' && strokeSet[0][0] == prevStrokeSet[0]) {
                 strokesArray = strokesArray.concat([[STR_COMPLETE, 1]]);
             }
         
             prevStrokeSet = strokeSet[strokeSet.length-1];  // Save the last strokeSet
         
             if (planeSwitch.length != 0) {
                 strokeSet = planeSwitch.concat(strokeSet);
             }
         
             strokesArray = strokesArray.concat(strokeSet);
         }
         
         var result = [];
         for (var i = 0; i < strokesArray.length; i++) {
             result.push({key:strokesArray[i][0], act:strokesArray[i][1]});
         }
         
         return result;
    });
} // End convertKoreanKeystrokesFor10key



//---------------------------------------------------------------------------------------------
// Function: breakKoreanTextIntoParts
//      This function breaks a complete Korean syllable into 3 different parts 
//          - ChoSeong, JungSeong and JongSeong
//      Unicode is calculated according to some consistent listing rules for Korean unicodes
// Parameters:
//      koreanText : Korean string (complete syllables)
//--------------------------------------------------------------------------------------------- 
KeystrokesGenerator.prototype.breakKoreanTextIntoParts = function breakKoreanTextIntoParts(koreanText) {
    return International.withFunctionBoundaryLogging(this, function () {
        //Define Korean ChoSeong, JungSeong and JongSeong unicodes
        var ChoSeong = new Array (0x3131, 0x3132, 0x3134, 0x3137, 0x3138, 0x3139, 0x3141, 0x3142, 0x3143, 0x3145, 0x3146, 0x3147, 0x3148, 0x3149, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e);  
        var JungSeong = new Array (0x314f, 0x3150, 0x3151, 0x3152, 0x3153, 0x3154, 0x3155, 0x3156, 0x3157, 0x3158, 0x3159, 0x315a, 0x315b,0x315c, 0x315d, 0x315e, 0x315f, 0x3160, 0x3161, 0x3162, 0x3163); 
        var JongSeong = new Array (0x0000, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136, 0x3137, 0x3139, 0x313a, 0x313b, 0x313c, 0x313d, 0x313e, 0x313f, 0x3140, 0x3141, 0x3142, 0x3144, 0x3145, 0x3146, 0x3147, 0x3148, 0x314a, 0x314b, 0x314c, 0x314d, 0x314e);  

        var chars = new Array();
        var brokenText = new Array();  

        //Calculate the Cho/Jung and Jong(if applicable) ranges, and finally extract each jamo's unicode from one syllable   
        for (var i = 0; i < koreanText.length; i++) {  
            chars[i] = koreanText.charCodeAt(i);  
            if (chars[i] >= 0xAC00 && chars[i] <= 0xD7A3) {
                var cho, jung, jong;  
                jong = chars[i] - 0xAC00;  
                cho = jong / (21 * 28);  
                jong = jong % (21 * 28);  
                jung = jong / 28;  
                jong = jong % 28;  
                brokenText.push(String.fromCharCode(ChoSeong[parseInt(cho)]));  
                brokenText.push(this.decomposeDoubleJamo(String.fromCharCode(JungSeong[parseInt(jung)])));
                //Inserting a finalize symbol for 10 Key
                if (jong == 0x0000) {
                    brokenText.push(String.fromCharCode(0xF7F1));
                }
                if (jong != 0x0000) {
                    brokenText.push(this.decomposeDoubleJamo(String.fromCharCode(JongSeong[parseInt(jong)])));
                    brokenText.push(String.fromCharCode(0xF7F1));
                }
            } else {
                brokenText.push(String.fromCharCode(chars[i]));
            }  
        }

        return brokenText.join("");
    });
} // End breakKoreanTextIntoParts


//---------------------------------------------------------------------------------------------
// Function decomposeDoubleJamo:
//      Decompose double-consonant or double-vowel jamo
// Parameters:
//      doubleJamo : A single double jamo char
//---------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.decomposeDoubleJamo = function decomposeDoubleJamo(doubleJamo) {
    return International.withFunctionBoundaryLogging(this, function () {
                                                     
        var doubleConsonant = new Array(0x3133, 0x3135, 0x3136, 0x313A, 0x313B, 0x313C, 0x313D, 0x313E, 0x313F, 0x3140, 0x3144);
        var doubleVowel = new Array(0x3158, 0x3159, 0x315A, 0x315D, 0x315E, 0x315F, 0x3162);
        var decomposedDoubleJamo = new Array();

        var doubleConsonantIndex = doubleConsonant.indexOf(doubleJamo.charCodeAt());
        var doubleVowelIndex = doubleVowel.indexOf(doubleJamo.charCodeAt());

        //when it's a single-Jamo, no processing is required
        if ((doubleConsonantIndex == -1) && (doubleVowelIndex == -1))
            decomposedDoubleJamo.push(doubleJamo);
        //converting double-consonants
        else if ((doubleConsonantIndex > -1) && (doubleVowelIndex == -1)) {
            if (doubleConsonantIndex == 0)
                decomposedDoubleJamo.push(String.fromCharCode(0x3131) + String.fromCharCode(0x3145));
            else if (doubleConsonantIndex < 3)  {
                decomposedDoubleJamo.push(String.fromCharCode(0x3134));
                if (doubleConsonantIndex == 1)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3148));    }
                if (doubleConsonantIndex == 2)  {   decomposedDoubleJamo.push(String.fromCharCode(0x314E));    }
            } else if (doubleConsonantIndex < 10)  {
                decomposedDoubleJamo.push(String.fromCharCode(0x3139));
                if (doubleConsonantIndex == 3)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3131));    }
                if (doubleConsonantIndex == 4)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3141));    }
                if (doubleConsonantIndex == 5)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3142));    }
                if (doubleConsonantIndex == 6)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3145));    }
                if (doubleConsonantIndex == 7)  {   decomposedDoubleJamo.push(String.fromCharCode(0x314C));    }
                if (doubleConsonantIndex == 8)  {   decomposedDoubleJamo.push(String.fromCharCode(0x314D));    }
                if (doubleConsonantIndex == 9)  {   decomposedDoubleJamo.push(String.fromCharCode(0x314E));    }
            } else if (doubleConsonantIndex == 10)
                decomposedDoubleJamo.push(String.fromCharCode(0x3142) + String.fromCharCode(0x3145));
        } else if ((doubleConsonantIndex == -1) && (doubleVowelIndex > -1)) {
            //converting double-vowels
            if (doubleVowelIndex < 3)  {
                decomposedDoubleJamo.push(String.fromCharCode(0x3157));
                if (doubleVowelIndex == 0)  {   decomposedDoubleJamo.push(String.fromCharCode(0x314F));    }
                if (doubleVowelIndex == 1)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3150));    }
                if (doubleVowelIndex == 2)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3163));    }
            } else if (doubleVowelIndex < 6)  {
                decomposedDoubleJamo.push(String.fromCharCode(0x315C));
                if (doubleVowelIndex == 3)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3153));    }
                if (doubleVowelIndex == 4)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3154));    }
                if (doubleVowelIndex == 5)  {   decomposedDoubleJamo.push(String.fromCharCode(0x3163));    }
            } else if (doubleVowelIndex == 6)
                decomposedDoubleJamo.push(String.fromCharCode(0x3161) + String.fromCharCode(0x3163));
        } else {
            //if anything not fall into any category, mark it as @ for debugging
            decomposedDoubleJamo.push("@");
        }
                                                     
        return decomposedDoubleJamo.join("");
    });
} // End decomposeDoubleJamo
