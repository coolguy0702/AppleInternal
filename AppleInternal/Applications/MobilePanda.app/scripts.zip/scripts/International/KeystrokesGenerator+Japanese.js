load('KeystrokesGenerator.js');

//----------------------------------------------------------------------------------------------------------------
//	Function: typeKeystrokes_Japanese
//		type keystrokes on Japanese keyboard
//
//	Parameters:
//      keystrokesText - keystroke text (e.g. toukyou).
//      expectedText - text to be displayed in text view or field on app (e.g. 東京).  Kanji conversion won't happen if empty on Japanese keyboards
//      flick - if this is true, keystrokes will be entered by flick gesture on appropriate 10-key keyboards
//
//	Returns:
//		true if key type is done successfully
//		Throws an error for any error cases.
//----------------------------------------------------------------------------------------------------------------
KeystrokesGenerator.prototype.typeKeystrokes_Japanese = function typeKeystrokes_Japanese(keystrokesText, expectedText, flick) {
    International.withFunctionBoundaryLogging(this, function () {
        var currentKeyboardID  = this.app.getKeyboardID();
        var keyboardLayoutType = currentKeyboardID.match(/(sw=[^;]*)/)[1];
        var keystrokesArray    = [];

        UIALogger.logDebug("current keyboard ID: " + currentKeyboardID);

        if (keyboardLayoutType.match(/sw=Kana/i)) {
            // Convert keystrokesText to keystrokesArray for Japanese 10 key
            keystrokesArray = this.convertJapaneseKeystrokesFor10key(keystrokesText, flick);
            UIALogger.logDebug("Convert Japanese hiragana text to keystorkes for 10 key keyboard (flick = " + flick + "): " + JSON.stringify(keystrokesArray));
        }

        if (keyboardLayoutType.match(/sw=Kana$/)) {
            //
            // For Japanese 10 key
            //
            UIALogger.logMessage("Handling Kana keyboard typing");
            this.switchKeyplane('kana');     // Reset keyboard plane to Kana
            this.typeKeystrokesFor10key(keystrokesArray);
        } else {
            //
            // For Japanese QWERTY
            //
            UIALogger.logMessage("Handling Romaji keyboard typing");
            this.app.typeString(keystrokesText);
        }

        this.fixJapaneseConversionForTypedText(expectedText);
    });
}



KeystrokesGenerator.prototype.fixJapaneseConversionForTypedText = function fixJapaneseConversionForTypedText(expectedText) {
    International.withFunctionBoundaryLogging(this, function () {
        this.app.delay(0.5);

        if (expectedText) {
            // Select expected conversion candidate after typing
            try {
                this.app.tap(UIAQuery.KEYBOARD_CANDIDATE_VIEW.andThen(
                        UIAQuery.tableCells(expectedText)));
            }
            catch (e) {
                throw new UIAError("expected Text is not available in the candidates list:" + expectedText);
            }
        }
    });
} // End fixConversionForTypedText


KeystrokesGenerator.prototype.switchKeyplane_Japanese = function switchKeyplane_Japanese(keyplane) {
    International.withFunctionBoundaryLogging(this, function () {
        var expected = {
            'kana':'あ',
            'abc':'a b c',
            'num':'1',
            'sym':'1',
        }[keyplane];

        UIAUtilities.assert(typeof expected !== 'undefined', 'Unrecognized keyplane identifier "%0"'.format(keyplane));

        // Cyclic tapping until expected plane appears
        while (!this.app.exists(UIAQuery.keyboard().andThen(UIAQuery.keys(expected)))) {
            this.app.tap(UIAQuery.keyboard().andThen(UIAQuery.keys().atIndex(10)));  // tap cyclic plane change key
        }
    });
}


KeystrokesGenerator.prototype.getExpectedDateWordCandidates_Japanese = function getExpectedDateWordCandidates_Japanese(expectedText) {
    return International.withFunctionBoundaryLogging(this, function () {
        function getDateCandidates(date) {
            const dayNames = ['日', '月', '火', '水', '木', '金', '土'];
            var candidates = [];
            candidates.push("$MO$/$DT$".replace("$MO$", date.getMonth() + 1).replace("$DT$", date.getDate()));
            candidates.push("$YR$/$MO$/$DT$".replace("$YR$", date.getFullYear()).replace("$MO$",("0"+(date.getMonth()+1)).substr(-2)).replace("$DT$",("0"+date.getDate()).substr(-2)));
            candidates.push("$MO$月$DT$日($DY$)".replace("$MO$", date.getMonth() + 1).replace("$DT$", date.getDate()).replace("$DY$", dayNames[date.getDay()]));
            candidates.push("$YR$年$MO$月$DT$日".replace("$YR$", date.getFullYear()).replace("$MO$", date.getMonth() + 1).replace("$DT$", date.getDate()));
            candidates.push("平成$YR$年$MO$月$DT$日".replace("$YR$", date.getFullYear() - 1988).replace("$MO$", date.getMonth() + 1).replace("$DT$", date.getDate()));
            candidates.push("$DY$曜日".replace("$DY$", dayNames[date.getDay()]));
            return candidates.join(' ');
        };

        function getMonthCandidates(date) {
            const monthNames = ['睦月', '如月', '弥生', '卯月', '皐月', '水無月', '文月', '葉月', '長月', '神無月', '霜月', '師走'];
            var candidates = [];
            candidates.push("$MO$月".replace("$MO$", date.getMonth() + 1));
            candidates.push(monthNames[date.getMonth()]);
            return candidates.join(' ');
        };

        function getYearCandidates(date) {
            var candidates = [];
            candidates.push("$YR$年".replace("$YR$", date.getFullYear()));
            candidates.push("平成$YR$年".replace("$YR$", date.getFullYear() - 1988));
            return candidates.join(' ');
        };

        var candidates = [];
        var curDate = new Date();
        var expectedDateWord = "";

        switch (expectedText) {

            // ========== Date
            case 'TODAY':
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY-4':
                curDate.setDate(curDate.getDate() - 4);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY-3':
                curDate.setDate(curDate.getDate() - 3);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY-2':
                curDate.setDate(curDate.getDate() - 2);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY-1':
                curDate.setDate(curDate.getDate() - 1);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY+1':
                curDate.setDate(curDate.getDate() + 1);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY+2':
                curDate.setDate(curDate.getDate() + 2);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY+3':
                curDate.setDate(curDate.getDate() + 3);
                expectedDateWord = getDateCandidates(curDate);
                break;
            case 'TODAY+4':
                curDate.setDate(curDate.getDate() + 4);
                expectedDateWord = getDateCandidates(curDate);
                break;
            // ========== Month
            case 'THISMONTH':
                expectedDateWord = getMonthCandidates(curDate);
                break;
            case 'THISMONTH-2':
                curDate.setMonth(curDate.getMonth() - 2);
                expectedDateWord = getMonthCandidates(curDate);
                break;
            case 'THISMONTH-1':
                curDate.setMonth(curDate.getMonth() - 1);
                expectedDateWord = getMonthCandidates(curDate);
                break;
            case 'THISMONTH+1':
                curDate.setMonth(curDate.getMonth() + 1);
                expectedDateWord = getMonthCandidates(curDate);
                break;
            case 'THISMONTH+2':
                curDate.setMonth(curDate.getMonth() + 2);
                expectedDateWord = getMonthCandidates(curDate);
                break;
            // ========== Year
            case 'THISYEAR':
                expectedDateWord = getYearCandidates(curDate);
                break;
            case 'THISYEAR-2':
                curDate.setFullYear(curDate.getFullYear() - 2);
                expectedDateWord = getYearCandidates(curDate);
                break;
            case 'THISYEAR-1':
                curDate.setFullYear(curDate.getFullYear() - 1);
                expectedDateWord = getYearCandidates(curDate);
                break;
            case 'THISYEAR+1':
                curDate.setFullYear(curDate.getFullYear() + 1);
                expectedDateWord = getYearCandidates(curDate);
                break;
            case 'THISYEAR+2':
                curDate.setFullYear(curDate.getFullYear() + 2);
                expectedDateWord = getYearCandidates(curDate);
                break;
            // ========== ERROR
            default:
                throw new UIAError("Invalid date keyword to be verified, or not supported keyword:" + expectedText);
                break;
        }

        return expectedDateWord;
    });
} // End getExpectedDateWordCandidates_Japanese



KeystrokesGenerator.prototype.convertJapaneseKeystrokesFor10key = function convertJapaneseKeystrokesFor10key(strokesText, flick) {
    return International.withFunctionBoundaryLogging(this, function () {
        var STR_COMPLETE = target.localizedString('keyboard.complete.key', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });
        var STR_UPPERLOWER = target.localizedString('keyboard.case.swap.key', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });

        var STR_PUNCTUATION = target.localizedString('keyboard.key.chinese.stroke.punctuation', {
                                bundlePath:'/System/Library/AccessibilityBundles/UIKit.axbundle',
                                tableName:'Accessibility'
                            });

        const conversionTable_Kana_Tap = {
            い:[['あ', 2]], う:[['あ', 3]], え:[['あ', 4]], お:[['あ', 5]], き:[['か', 2]], く:[['か', 3]], け:[['か', 4]], こ:[['か', 5]],
            し:[['さ', 2]], す:[['さ', 3]], せ:[['さ', 4]], そ:[['さ', 5]], ち:[['た', 2]], つ:[['た', 3]], て:[['た', 4]], と:[['た', 5]],
            に:[['な', 2]], ぬ:[['な', 3]], ね:[['な', 4]], の:[['な', 5]], ひ:[['は', 2]], ふ:[['は', 3]], へ:[['は', 4]], ほ:[['は', 5]],
            み:[['ま', 2]], む:[['ま', 3]], め:[['ま', 4]], も:[['ま', 5]], り:[['ら', 2]], る:[['ら', 3]], れ:[['ら', 4]], ろ:[['ら', 5]],
            ゆ:[['や', 2]], よ:[['や', 3]], を:[['わ', 2]], ん:[['わ', 3]], ー:[['わ', 4]], "。":[['、', 2]], "？":[['、', 3]], "！":[['、', 4]],
            ぁ:[['あ', 1],['゛', 1]], ぃ:[['あ', 2],['゛', 1]], ぅ:[['あ', 3],['゛', 1]], ぇ:[['あ', 4],['゛', 1]], ぉ:[['あ', 5],['゛', 1]],
            っ:[['た', 3],['゛', 1]], ゃ:[['や', 1],['゛', 1]], ゅ:[['や', 2],['゛', 1]], ょ:[['や', 3],['゛', 1]], ゎ:[['わ', 1],['゛', 1]],
            が:[['か', 1],['゛', 1]], ぎ:[['か', 2],['゛', 1]], ぐ:[['か', 3],['゛', 1]], げ:[['か', 4],['゛', 1]], ご:[['か', 5],['゛', 1]],
            ざ:[['さ', 1],['゛', 1]], じ:[['さ', 2],['゛', 1]], ず:[['さ', 3],['゛', 1]], ぜ:[['さ', 4],['゛', 1]], ぞ:[['さ', 5],['゛', 1]],
            だ:[['た', 1],['゛', 1]], ぢ:[['た', 2],['゛', 1]], づ:[['た', 3],['゛', 1]], で:[['た', 4],['゛', 1]], ど:[['た', 5],['゛', 1]],
            ば:[['は', 1],['゛', 1]], び:[['は', 2],['゛', 1]], ぶ:[['は', 3],['゛', 1]], べ:[['は', 4],['゛', 1]], ぼ:[['は', 5],['゛', 1]],
            ぱ:[['は', 1],['゛', 2]], ぴ:[['は', 2],['゛', 2]], ぷ:[['は', 3],['゛', 2]], ぺ:[['は', 4],['゛', 2]], ぽ:[['は', 5],['゛', 2]],
            "『":[['や', 'L']], "』":[['や', 'R']]
            };
        const conversionTable_Kana_Flick = {
            い:[['あ', 'L']], う:[['あ', 'U']], え:[['あ', 'R']], お:[['あ', 'D']], き:[['か', 'L']], く:[['か', 'U']], け:[['か', 'R']], こ:[['か', 'D']],
            し:[['さ', 'L']], す:[['さ', 'U']], せ:[['さ', 'R']], そ:[['さ', 'D']], ち:[['た', 'L']], つ:[['た', 'U']], て:[['た', 'R']], と:[['た', 'D']],
            に:[['な', 'L']], ぬ:[['な', 'U']], ね:[['な', 'R']], の:[['な', 'D']], ひ:[['は', 'L']], ふ:[['は', 'U']], へ:[['は', 'R']], ほ:[['は', 'D']],
            み:[['ま', 'L']], む:[['ま', 'U']], め:[['ま', 'R']], も:[['ま', 'D']], り:[['ら', 'L']], る:[['ら', 'U']], れ:[['ら', 'R']], ろ:[['ら', 'D']],
            ゆ:[['や', 'U']], よ:[['や', 'D']], を:[['わ', 'L']], ん:[['わ', 'U']], ー:[['わ', 'R']], "。":[['、', 'L']], "？":[['、', 'U']], "！":[['、', 'R']],
            ぁ:[['あ', 1],['゛', 1]], ぃ:[['あ', 'L'],['゛', 1]], ぅ:[['あ', 'U'],['゛', 1]], ぇ:[['あ', 'R'],['゛', 1]], ぉ:[['あ', 'D'],['゛', 1]],
            っ:[['た', 'U'],['゛', 1]], ゃ:[['や', 1],['゛', 1]], ゅ:[['や', 'U'],['゛', 1]], ょ:[['や', 'D'],['゛', 1]], ゎ:[['わ', 1],['゛', 1]],
            が:[['か', 1],['゛', 1]], ぎ:[['か', 'L'],['゛', 1]], ぐ:[['か', 'U'],['゛', 1]], げ:[['か', 'R'],['゛', 1]], ご:[['か', 'D'],['゛', 1]],
            ざ:[['さ', 1],['゛', 1]], じ:[['さ', 'L'],['゛', 1]], ず:[['さ', 'U'],['゛', 1]], ぜ:[['さ', 'R'],['゛', 1]], ぞ:[['さ', 'D'],['゛', 1]],
            だ:[['た', 1],['゛', 1]], ぢ:[['た', 'L'],['゛', 1]], づ:[['た', 'U'],['゛', 1]], で:[['た', 'R'],['゛', 1]], ど:[['た', 'D'],['゛', 1]],
            ば:[['は', 1],['゛', 1]], び:[['は', 'L'],['゛', 1]], ぶ:[['は', 'U'],['゛', 1]], べ:[['は', 'R'],['゛', 1]], ぼ:[['は', 'D'],['゛', 1]],
            ぱ:[['は', 1],['゛', 2]], ぴ:[['は', 'L'],['゛', 2]], ぷ:[['は', 'U'],['゛', 2]], ぺ:[['は', 'R'],['゛', 2]], ぽ:[['は', 'D'],['゛', 2]],
            "『":[['や', 'L']], "』":[['や', 'R']]
            };
        const conversionTable_ABC_Tap = {
            "@":[['@ # / & _ ', 1]], "#":[['@ # / & _ ', 2]], "/":[['@ # / & _ ', 3]], "&":[['@ # / & _ ', 4]], "_":[['@ # / & _ ', 5]],
            "a":[['a b c ', 1]], "b":[['a b c ', 2]], "c":[['a b c ', 3]], "d":[['d e f ', 1]], "e":[['d e f ', 2]], "f":[['d e f ', 3]],
            "g":[['g h i ', 1]], "h":[['g h i ', 2]], "i":[['g h i ', 3]], "j":[['j k l ', 1]], "k":[['j k l ', 2]], "l":[['j k l ', 3]],
            "m":[['m n o ', 1]], "n":[['m n o ', 2]], "o":[['m n o ', 3]], "t":[['t u v ', 1]], "u":[['t u v ', 2]], "v":[['t u v ', 3]],
            "p":[['p q r s ', 1]], "q":[['p q r s ', 2]], "r":[['p q r s ', 3]], "s":[['p q r s ', 4]],
            "w":[['w x y z ', 1]], "x":[['w x y z ', 2]], "y":[['w x y z ', 3]], "z":[['w x y z ', 4]],
            "'":[['\'', 1]], "\"":[['"', 2]], "(":[['\'', 3]],")":[['\'', 4]],
            ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 2]], "?":[[STR_PUNCTUATION, 3]],"!":[[STR_PUNCTUATION, 4]]
            };
        const conversionTable_ABC_Flick = {
            "@":[['@ # / & _ ', 1]], "#":[['@ # / & _ ', 'L']], "/":[['@ # / & _ ', 'U']], "&":[['@ # / & _ ', 'R']], "_":[['@ # / & _ ', 'D']],
            "a":[['a b c ', 1]], "b":[['a b c ', 'L']], "c":[['a b c ', 'U']], "d":[['d e f ', 1]], "e":[['d e f ', 'L']], "f":[['d e f ', 'U']],
            "g":[['g h i ', 1]], "h":[['g h i ', 'L']], "i":[['g h i ', 'U']], "j":[['j k l ', 1]], "k":[['j k l ', 'L']], "l":[['j k l ', 'U']],
            "m":[['m n o ', 1]], "n":[['m n o ', 'L']], "o":[['m n o ', 'U']], "t":[['t u v ', 1]], "u":[['t u v ', 'L']], "v":[['t u v ', 'U']],
            "p":[['p q r s ', 1]], "q":[['p q r s ', 'L']], "r":[['p q r s ', 'U']], "s":[['p q r s ', 'R']],
            "w":[['w x y z ', 1]], "x":[['w x y z ', 'L']], "y":[['w x y z ', 'U']], "z":[['w x y z ', 'R']],
            "'":[['\'', 1]], "\"":[['"', 'L']], "(":[['\'', 3]],")":[['\'', 'R']],
            ".":[[STR_PUNCTUATION, 1]], ",":[[STR_PUNCTUATION, 'L']], "?":[[STR_PUNCTUATION, 3]],"!":[[STR_PUNCTUATION, 'R']]
            };
        const conversionTable_NUM_Tap = {
            "1":[['1', 1]], "2":[['2', 1]], "3":[['3', 1]], "4":[['4', 1]], "5":[['5', 1]], "6":[['6', 1]], "7":[['7', 1]], "8":[['8', 1]], "9":[['9', 1]], "0":[['0', 1]],
            "☆":[['1', 2]], "♪":[['1', 3]], "→":[['1', 4]], "¥":[['2', 2]], "$":[['2', 3]], "€":[['2', 4]], "%":[['3', 2]], "°":[['3', 3]], "#":[['3', 4]],
            "○":[['4', 2]], "＊":[['4', 3]], "・":[['4', 4]], "+":[['5', 2]], "×":[['5', 3]], "÷":[['5', 4]], "<":[['6', 2]], "=":[['6', 3]], ">":[['6', 4]],
            "「":[['7', 2]], "」":[['7', 3]], ":":[['7', 4]], "〒":[['8', 2]], "々":[['8', 3]], "〆":[['8', 4]], "^":[['9', 2]], "|":[['9', 3]], "\\":[['9', 4]],
            "〜":[['0', 2]], "…":[['0', 3]], ")":[['(', 2]], "[":[['(', 3]], "]":[['(', 4]], ",":[['.', 2]], "-":[['.', 3]], "/":[['.', 4]]
            };
        const conversionTable_NUM_Flick = {
            "1":[['1', 1]], "2":[['2', 1]], "3":[['3', 1]], "4":[['4', 1]], "5":[['5', 1]], "6":[['6', 1]], "7":[['7', 1]], "8":[['8', 1]], "9":[['9', 1]], "0":[['0', 1]],
            "☆":[['1', 'L']], "♪":[['1', 'U']], "→":[['1', 'R']], "¥":[['2', 'L']], "$":[['2', 'U']], "€":[['2', 'R']], "%":[['3', 'L']], "°":[['3', 'U']], "#":[['3', 'R']],
            "○":[['4', 'L']], "＊":[['4', 'U']], "・":[['4', 'R']], "+":[['5', 'L']], "×":[['5', 'U']], "÷":[['5', 'R']], "<":[['6', 'L']], "=":[['6', 'U']], ">":[['6', 'R']],
            "「":[['7', 'L']], "」":[['7', 'U']], ":":[['7', 'R']], "〒":[['8', 'L']], "々":[['8', 'U']], "〆":[['8', 'R']], "^":[['9', 'L']], "|":[['9', 'U']], "\\":[['9', 'R']],
            "〜":[['0', 'L']], "…":[['0', 'U']], ")":[['(', 'L']], "[":[['(', 'U']], "]":[['(', 'R']], ",":[['.', 'L']], "-":[['.', 'U']], "/":[['.', 'R']]
            };

        var conversionTable_Kana = conversionTable_Kana_Tap;
        var conversionTable_ABC  = conversionTable_ABC_Tap;
        var conversionTable_NUM  = conversionTable_NUM_Tap;

        if (flick) {
            conversionTable_Kana = conversionTable_Kana_Flick;
            conversionTable_ABC  = conversionTable_ABC_Flick;
            conversionTable_NUM  = conversionTable_NUM_Flick;
        }

        var strokes = strokesText.split("");
        var strokesArray = [];
        var prevStrokeSet = [];
        var currentPlane = 'kana';

        for (var i = 0; i < strokes.length; i++) {
            var strokeSet = [];
            var planeSwitch = [];

            if (strokes[i] == ' ') {    // space key
                strokeSet = [['空白',1]];
            } else if (conversionTable_Kana[strokes[i]]) {
                strokeSet = conversionTable_Kana[strokes[i]];
               if (currentPlane != 'kana') {
                    planeSwitch = [['==>kana',1]];
                    currentPlane = 'kana';
                }
            } else if (conversionTable_ABC[strokes[i]]) {
                strokeSet = conversionTable_ABC[strokes[i]];
                if (currentPlane != 'abc') {
                    planeSwitch = [['==>abc',1]];
                    currentPlane = 'abc';
                }
            } else if (conversionTable_ABC[strokes[i].toLowerCase()]) {
                strokeSet = conversionTable_ABC[strokes[i].toLowerCase()];
                strokeSet = strokeSet.concat([[STR_UPPERLOWER, 1]]); // add an action to tap "a/A" key to make it upper case
                if (currentPlane != 'abc') {
                    planeSwitch = [['==>abc',1]];
                    currentPlane = 'abc';
                }
            } else if (conversionTable_NUM[strokes[i]]) {
                strokeSet = conversionTable_NUM[strokes[i]];
                if (currentPlane != 'num') {
                    planeSwitch = [['==>num',1]];
                    currentPlane = 'num';
                }
            } else {  // For other, assuming as Kana key
                strokeSet = [[strokes[i], 1]];
               if (currentPlane != 'kana') {
                    planeSwitch = [['==>kana',1]];
                    currentPlane = 'kana';
                }
            }

            // Add Complete button for tap case, if the first strokeSet is the same as prevous strokeSet, so we can avoid continual taps.
            // e.g. abc 1 tap + abc 2 taps should not be abc 3 taps, but abc 1tap + complete + abc 2 taps.
            if (typeof strokeSet[0][1] == 'number' && typeof prevStrokeSet[1] == 'number' && strokeSet[0][0] == prevStrokeSet[0]) {
                strokesArray = strokesArray.concat([[STR_COMPLETE, 1]]);
            }

            prevStrokeSet = strokeSet[strokeSet.length-1];  // Save the last strokeSet

            if (planeSwitch.length != 0) {
                strokeSet = planeSwitch.concat(strokeSet);
            }
            strokesArray = strokesArray.concat(strokeSet);
        }

        var result = [];
        for (var i = 0; i < strokesArray.length; i++) {
            result.push({key:strokesArray[i][0], act:strokesArray[i][1]});
        }

        return result;
    });
} // End international.convertJapaneseKeystrokesFor10key


