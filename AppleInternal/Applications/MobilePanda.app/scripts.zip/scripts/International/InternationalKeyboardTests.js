load('UIATesting.js');
load('Settings.js');

load('International.js');

UIAUtilities.assert(
    typeof InternationalKeyboardTests === 'undefined',
    'InternationalKeyboardTests has already been defined.'
);

/**
 * @namespace
 */
var InternationalKeyboardTests = {

    _supportedBundleIDs: [
        'com.apple.mobilenotes',
        'com.apple.MobileSMS',
        'com.apple.addressbook',
        'com.apple.mobilemail',
    ],

    _assertRequiredArgument: function _assertRequiredArguments(value, name) {
        UIAUtilities.assert(
            typeof value != 'undefined' && value != null,
            'Argument %0 is not specified'.format(name)
        );
    },

    _assertRequiredArguments: function _assertRequiredArguments(args, names) {
        for (var index = 0; index < names.count; names++) {
            var key = names[index];
            this._assertRequiredArgument(args[key], key)
        }
    },

    
    /**
     * Setup keyboard by adding on Settings if not available. Also enabe/disable switches for specificed keyboard settings.
     *
     * @param   {string}    keyboardID - iOS specific keyboard ID.
     *                          (e.g, "zh_Hant-Pinyin@sw=Pinyin-Traditional;hw=US", "ja_JP-Kana@sw=Kana-Flick;hw=US")
     * @param   {object}    options - a dictionary object of optional arguments
     * @param   {string}    [options.autoCorrection="0"] - if true the auto-Correction switch will be turned on.
     * @param   {string}    [options.resetLearningDict="0"] - if true Keyboard Learning Dictionary will be resetted at the end.
     * @returns {boolean} - true if the setup is completed successfully.
     * @throws              if keyboardID is not specified, or others from settings.addKeyboard()
     */
    _setupKeyboard: function _setupKeyboard(keyboardID, options) {
        International.withFunctionBoundaryLogging(this, function () {
            InternationalKeyboardTests._assertRequiredArgument(keyboardID, 'keyboardID');

            var languageID = keyboardID.match(/^[^-@]*/g)[0];
            var keyboardUIstrings = International.keyboardTypeFromKeyboardID(keyboardID);
            var keyboardType = keyboardUIstrings.type;
            var keyboardOpts = keyboardUIstrings.opts;
            // settings.addKeyboard(languageID, {type:[keyboardID]});
            UIALogger.logMessage('Adding keyboard: settings.addKeyboard("%0", "%1", "%2", "%3", true)'.format(languageID, keyboardType, keyboardID, keyboardOpts));
            // Set true for passOnAlreadyAdded - true if the test should pass if the keyboard already exists.

            settings.addKeyboard(languageID, keyboardType, keyboardID, keyboardOpts, true);

            if (typeof options == 'undefined') options = {};
            UIALogger.logDebug('Settings for keyboard options : %0'.format(JSON.stringify(options)));
            // Set Auto-Correction switch
            if (typeof options.autoCorrection != 'undefined' && options.autoCorrection != null) {
                UIALogger.logMessage('Set Auto-Correction to turn %0'.format(options.autoCorrection == '1' ? 'ON' : 'OFF'));
                settings.navigateNavigationViews([LocStrings.Settings.GENERAL, {query:LocStrings.Settings.KEYBOARD, title:LocStrings.Settings.KEYBOARDS_SETTINGS_TITLE}]);
                settings.setSwitchSetting(LocStrings.Settings.AUTOCORRECTION, options.autoCorrection);
            }

            // Reset Keyboard Learning Dictionary
            if (typeof options.resetLearningDict != 'undefined' && options.resetLearningDict == '1') {
                InternationalKeyboardTests.resetKeyboardDictionary();
            }    // options.resetLearningDict would be NULL if the option is not specified, and ignore it, nothing to do.
        });
    },

    /**
     *  Reset keyboard learning dictionary - Just go to General > Reset, then tap "Reset Dictionary".
     *
     **/
    resetKeyboardDictionary: function resetKeyboardDictionary() {
        // Reset Keyboard Learning Dictionary
        UIALogger.logMessage('Navigating to Reset section in General Settings, and run Reset Dictionary');
        settings.navigateNavigationViews([LocStrings.Settings.GENERAL, LocStrings.Settings.RESET]);
        settings.tapIfExists(LocStrings.Settings.RESET_KEYBOARD_DICTIONARY_LABEL);
        target.delay(0.5);
        settings.tapIfExists(LocStrings.Settings.RESET_KEYBOARD_DICTIONARY_TITLE);
        target.delay(1);  // wait for animation to finish
    },

    /**
     *  Setup test environment - Adding desired keyboard, set keyboard settings, lauch test app, and switch to desired keyboard.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.keyboardID] - desired Keyboard ID (e.g. 'zh_Hant-Pinyin@sw=Pinyin10-Traditional;hw=US')
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.autoCorrection="0"] - if true the auto-Correction switch will be turned on.
     * @param {string}  [args.resetLearningDict="0"] - if true Keyboard Learning Dictionary will be resetted at the end.
     **/
    setup: function setup(args) {
        args = UIAUtilities.defaults(args, {
            keyboardID: null,
            bundleID: null,
            autoCorrection: '0',
            resetLearningDict: '0',
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keyboardID', 'bundleID', 'keyboardID']);

        UIAUtilities.assert(
            InternationalKeyboardTests._supportedBundleIDs.contains(args.bundleID),
            'Application with bundleID %0 is not supported by this test.'.format(args.bundleID)
        );

        var options = new Object();
        options.autoCorrection = args.autoCorrection;
        options.resetLearningDict = args.resetLearningDict;

        InternationalKeyboardTests._setupKeyboard(args.keyboardID, options);

        var app = target.appWithBundleID(args.bundleID);
        app.setupForInternationalTyping();
        app.withMaximumSnapshotBreadth(400, function() {
        	try {
        		app.setupForInternationalTyping();
				if (app.getKeyboardID() != args.keyboardID) {
					app.switchKeyboard(args.keyboardID);
				}
			} catch(e) {
				UIALogger.logWarning("Hit Workaround for radar 33487697");
        		app.setupForInternationalTyping();
				if (app.getKeyboardID() != args.keyboardID) {
					app.switchKeyboard(args.keyboardID);
				}
			}
        });
    },

    /**
     *  Setup test environment - Lauch test app, and switch to desired keyboard if necessary.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keyboardID] - Optional desired Keyboard ID (e.g. 'zh_Hant-Pinyin@sw=Pinyin10-Traditional;hw=US')
     **/
    launchApp: function launchApp(args) {
        args = UIAUtilities.defaults(args, {
            keyboardID: null,
            bundleID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['bundleID']);

        UIAUtilities.assert(
            InternationalKeyboardTests._supportedBundleIDs.contains(args.bundleID),
            'Application with bundleID %0 is not supported by this test.'.format(args.bundleID)
        );

        var app = target.appWithBundleID(args.bundleID);
        app.setupForInternationalTyping();
        if (args.keyboardID !== null) {
            app.withMaximumSnapshotBreadth(400, function() {
                if (app.getKeyboardID() !== args.keyboardID) {
                    app.switchKeyboard(args.keyboardID);
                }
            });
        }
        
        target.delay(5);
        app.tap(UIAQuery.buttons("Cancel"));
    },

    /**
     *  Setup test environment - Switch to desired keyboard.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keyboardID] - desired Keyboard ID (e.g. 'zh_Hant-Pinyin@sw=Pinyin10-Traditional;hw=US')
     **/
    switchToDesiredKeyboard: function switchToDesiredKeyboard(args) {
        args = UIAUtilities.defaults(args, {
            keyboardID: null,
            bundleID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keyboardID', 'bundleID']);

        UIAUtilities.assert(
            InternationalKeyboardTests._supportedBundleIDs.contains(args.bundleID),
            'Application with bundleID %0 is not supported by this test.'.format(args.bundleID)
        );

        var app = target.appWithBundleID(args.bundleID);
        app.withMaximumSnapshotBreadth(400, function() {
            if (app.getKeyboardID() != args.keyboardID) {
                app.switchKeyboard(args.keyboardID);
            }
        });
    },

    /**
     *  Type keystorkes on standard/10-key keyboard, and verify the text on view.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, J-Romaji: "roppongi")
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, "六本木") - No conversion if this is not presented (For C/J).
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyText: function typeAndVerifyText(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'bundleID']);

        var app = target.appWithBundleID(args.bundleID);
        app.cleanupForInternationalTyping();
        var expectedText = args.expectedText;
        app.typeKeystrokes(args.keystrokesText, expectedText, args.flick == '1');
        if (!expectedText)
            expectedText = args.keystrokesText;
        International.verifyTypedText(expectedText, args.testCaseID);
    },

    /**
     *  Type keystorkes on standard/10-key keyboard, and verify the candidate list on keyboard.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *      If expectedText is not specified:
     *          Verify if specified words exist in candidate list for a keystroke, or opposite.
     *      If expectedText is specified:
     *          Verify if specified predictive candidates are available in candidate list, after the first conversion is fixed, or opposite.
     *
     *  This is for Chinese and Japanese only.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, J-Romaji: "roppongi")
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, "六本木") - No conversion if this is not presented (For C/J).
     * @param {string}  [args.candidates] - string consist of one or more words separated by space character (0x20).
     * @param {string}  [args.nonexist="0"] - Optional enable negative check, pass if all words in expectedCandidates doesn't exist in candidate list
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.position] - Optional position or range candidate expected to appear
     *                                     (e.g,  "1": 1st position, "2-": as 2nd or later position {opposite of "1"},
     *                                            "4-6": range in 4th to 6th positions, "-5": range in last 5 positions.)
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyCandidates: function typeAndVerifyCandidates(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            candidates: null,
            nonexist: '0',
            flick: '0',
            position: null,
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'candidates', 'bundleID']);

        var keyboardID;
        var app = target.appWithBundleID(args.bundleID);
        app.withMaximumSnapshotBreadth(400, function() {
            keyboardID = app.getKeyboardID();
        });
        UIALogger.logDebug('keyboardID: %0'.format(keyboardID));
        var languageID = keyboardID.match(/^[^-@]*/g)[0];  // [0] is necessary to get the value in string type <rdar://problem/17049829>
        UIALogger.logDebug('languageID: %0'.format(languageID));

        switch (languageID) {
            case 'zh_Hans':
            case 'zh_Hant':
            case 'ja_JP':
                // Simplified Chinese, Traditional Chinese, and Japanese
                break;
            default:
                // Other languages
                throw new UIAError('The language "%0" is not supported for this conversion test so far.'.format(languageID));
                break;
        }

        app.cleanupForInternationalTyping();
        app.typeKeystrokes(args.keystrokesText, args.expectedText, args.flick == '1');
        target.delay(0.5);
        // WORKAROUND: Retry to type on 10key, because sometime flick gesture is ignored. <rdar://problem/24763652>
        var typedText = target.activeApp().getTextFromElementForInternationalTyping();
        if (args.flick == '1' && typedText != args.keystrokesText) {
            UIALogger.logDebug("Retry on 10key flick because of unexpected flick gesture happend.  keystrokesText: %0, typedText: %1".format(args.keystrokesText, typedText));
            app.cleanupForInternationalTyping();
            app.typeKeystrokes(args.keystrokesText, args.expectedText, args.flick == '1');
            target.delay(0.5);
        }

        if (args.position) {
            International.verifyCandidatesWithPosition(args.candidates, args.position, args.testCaseID);
        } else {
            International.verifyCandidates(args.candidates, args.nonexist == '1', args.testCaseID);
        }
    },

    /**
     *  According specified keystrokes/candidates sequence, type keystorkes and verify the candidate list on keyboard.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *      There are several actions are supported:
     *          ; is used to seperate keystrokes/actions 
     *          number the digits before candidates are used to specify the expected position
     *          \b is backspace to delete 
     *          - before candidate is to use for verifying the candidates is not existing
     *          0x20/Space between candidates is use to tap/choose multi candidates, this one is also used for predication verification
     *          \U before candidates is used to specify candidates related unicode.
     *          \n return and newline for keystrokes, and related candidates can leave as empty
     *          \r reset dictionary, this is used to reset the dictionary and then launch the testing again.
     *          \p reboot device, reboot device and launch the testing again.
     *          
     *  This is for Chinese only.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, J-Romaji: "roppongi")
     * @param {string}  [args.candidates] - string consist of one or more words separated by space character (0x20).
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyAdaptationLearning: function typeAndVerifyAdaptationLearning(args) {        
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            candidates: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'candidates', 'bundleID']);

        var keyboardID;
        var app = target.appWithBundleID(args.bundleID);
        app.withMaximumSnapshotBreadth(400, function() {
            keyboardID = app.getKeyboardID();
        });
        UIALogger.logDebug('keyboardID: %0'.format(keyboardID));
        var languageID = keyboardID.match(/^[^-@]*/g)[0];  // [0] is necessary to get the value in string type <rdar://problem/17049829>
        UIALogger.logDebug('languageID: %0'.format(languageID));

        switch (languageID) {
            case 'zh_Hans':
            case 'zh_Hant':
                // Simplified Chinese, Traditional Chinese, and Japanese
                break;
            default:
                // Other languages
                throw new UIAError('The language "%0" is not supported for this conversion test so far.'.format(languageID));
                break;
        }
        //clear up edit field for testing
        app.cleanupForInternationalTyping();

        //Check if the key strokes and candidates amount are equal.
        var keyStrokeTokens = args.keystrokesText.split(";");
        var expectedCandidateTokens = args.candidates.split(";");
        UIALogger.logDebug('Number of keystroke tokens %0 - Number of expected text tokens %1'.format(keyStrokeTokens.length, expectedCandidateTokens.length));
        if (keyStrokeTokens.length != expectedCandidateTokens.length) {
            throw new UIAError("Invalid input. The size of the keystroke tokens %0 is different from the size of expected text tokens %1".format(keyStrokeTokens.length, expectedCandidateTokens.length));
        }
        
        //Verify keystrokes and candidates
        International.verifyGroupedStrokesAndCandidatesWithCommands(keyStrokeTokens, expectedCandidateTokens, args.flick, args.testCaseID, args.bundleID, keyboardID);
    },

    /**
     *  Type keystorkes on Chinese standard/10-key keyboard, and verify the candidate list on keyboard with prediction conversion.
     *  This is for Chinese only.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text
     * @param {string}  [args.expectedText] - expected text to be typed
     * @param {string}  [args.nonexist="0"] - Optional enable negative check, pass if all words in expectedCandidates doesn't exist in candidate list
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndPredictionAndVerifyText: function typeAndPredictionAndVerifyText(args) {
         args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            nonexist: '0',
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'candidates', 'bundleID']);

        var app = target.appWithBundleID(args.bundleID);
        app.cleanupForInternationalTyping();
        for (var i = 0; i < args.keystrokesText.length; i++) {
            if (!args.keystrokesText[i].localeCompare("联想") || !args.keystrokesText[i].localeCompare("=PREDICTION=")) {
                target.delay(0.5);
                International.verifyCandidates(args.expectedText[i], args.nonexist == '1', args.testCaseID);
                International.fixChineseConversionForTypedText(args.expectedText[i]);
            } else {
                app.typeKeystrokes(args.keystrokesText[i], args.expectedText[i], args.flick == '1');
            }
        }
    },

	/**
     *  Type keystorkes on Chinese keyboard, and verify the ProactiveQuickType candidates.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, John's phone number)
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, John's phone number) 
    * @param {string}  [args.candidates] - Expected ProactiveQuickType candidates (e.g, (408) 252-5928) 
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyChinesePQTText: function typeAndVerifyChinesePQTText(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            candidates: null,
            nonexist: '0',
            flick: '0',
            position: null,
            testCaseID: null,
            pqtCandidate: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'candidates', 'bundleID']);

        var keyboardID;
        var result;
        var finalResult = 0;
        var app = target.appWithBundleID(args.bundleID);
        app.withMaximumSnapshotBreadth(400, function() {
            keyboardID = app.getKeyboardID();
        });
        UIALogger.logDebug('keyboardID: %0'.format(keyboardID));
        var languageID = keyboardID.match(/^[^-@]*/g)[0];  // [0] is necessary to get the value in string type <rdar://problem/17049829>
        UIALogger.logDebug('languageID: %0'.format(languageID));

        switch (languageID) {
            case 'zh_Hans':
            case 'zh_Hant':
            case 'ja_JP':
                // Simplified Chinese, Traditional Chinese, and Japanese
                break;
            default:
                // Other languages
                throw new UIAError('The language "%0" is not supported for this conversion test so far.'.format(languageID));
                break;
        }
        
		app.cleanupForInternationalTyping();
       	app.typeKeystrokes(args.keystrokesText, args.expectedText, args.flick == '1');
        target.delay(2);
        
        var proactiveCandidates = app.inspectAll(UIAQuery.keyboard().isVisible().andThen(UIAQuery.query("TableCell")));
        //If candidates are more than 2, it means normal QuickType candidates are shown instead of Proactive QuickType candidates
        if (proactiveCandidates.length > 2) {
        	var result = false;
        	UIALogger.logMessage('		Verification: %0'.format(result ? 'Passed' : 'Failed'));
			UIALogger.logMessage('		Proactive candidates not triggered, Normal Chinese candidates show instead');
			UIALogger.logMessage('		QuickType Candidates = [%0] [%1] [%2]'.format(proactiveCandidates[0].name, proactiveCandidates[1].name, proactiveCandidates[2].name));
        } else {
            for (var i = 0, j = 0; i < proactiveCandidates.length; i++) {
                UIALogger.logMessage('#################Start checking proactiveCandidate[%0]'.format(i));
                UIALogger.logMessage('proactiveCandidate[%0] = [%1]'.format(i, proactiveCandidates[i].name));
                //Chinese Proactive QuickType candidate contains a ff0c which is full width comma
                var splitPtestCandidate = args.candidates.split("|");
                var resultFirstCompare = proactiveCandidates[i].name.contains(splitPtestCandidate[j]);
                if (splitPtestCandidate.length == 2) {
                	var resultSecondCompare = proactiveCandidates[i].name.contains(splitPtestCandidate[j+1]);
                }
                UIALogger.logMessage('Value of resultFirstCompare is [%0], value for resultSecondCompare is [%1]'.format(resultFirstCompare, resultSecondCompare));
                if (resultFirstCompare || resultSecondCompare) {
                	finalResult++;
                }
                UIALogger.logMessage('Value of finalResult: [%0]'.format(finalResult));
                UIALogger.logMessage('#################End Checking proactiveCandidate[%0]'.format(i));
            }
            UIALogger.logMessage('		finalResult: %0'.format(finalResult));
            UIALogger.logMessage('		proactiveCandidates.length: %0'.format(proactiveCandidates.length));
            UIALogger.logMessage('		Verification: %0'.format(finalResult == proactiveCandidates.length ? 'Passed' : 'Failed'));
            UIALogger.logMessage('		typedText = [%0]'.format(proactiveCandidates[0].name));
            UIALogger.logMessage('		expectedText = [%0]'.format(args.candidates));
        }
    },
    
    
    /**
     *  Type keystorkes on English keyboard, and verify the ProactiveQuickType candidates.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, John's phone number)
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, John's phone number) 
    * @param {string}  [args.candidates] - Expected ProactiveQuickType candidates (e.g, (408) 252-5928) 
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyPQTText: function typeAndVerifyPQTText(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            candidates: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'bundleID']);
    	var app = target.appWithBundleID(args.bundleID);
        var expectedText = args.expectedText;
        var finalResult = 0;
        app.cleanupForInternationalTyping();
        app.typeString(args.keystrokesText, expectedText, args.flick == '1');

        // NEED SOME DELAY AFTER TYPING IS COMPLETED
        target.delay(2);
        
        var proactiveCandidates = app.inspectAll(UIAQuery.keyboard().isVisible().andThen(UIAQuery.query("UIKeyboardPredictionCell")));
        //If candidates are more than 2, it means normal QuickType candidates are shown instead of Proactive QuickType candidates
        if (proactiveCandidates.length > 2) {
        	var result = false;
        	UIALogger.logMessage('		Verification: %0'.format(result ? 'Passed' : 'Failed'));
			UIALogger.logMessage('		Proactive candidates not triggered, Quick Type candidates show instead');
			UIALogger.logMessage('		QuickType Candidates = [%0] [%1] [%2]'.format(proactiveCandidates[0].name, proactiveCandidates[1].name, proactiveCandidates[2].name));
        } else {
            for (var i = 0, j = 0; i < proactiveCandidates.length; i++) {
                UIALogger.logMessage('#################Start checking proactiveCandidate[%0]'.format(i));
                UIALogger.logMessage('proactiveCandidate[%0] = [%1]'.format(i, proactiveCandidates[i].name));
                //English Proactive QuickType candidate contains a 0xa0 but shows as a Space (0x20)
                var splitPtestCandidate = args.candidates.split("|");
                var resultFirstCompare = proactiveCandidates[i].name.contains(splitPtestCandidate[j]);
                if (splitPtestCandidate.length == 2) {
                	var resultSecondCompare = proactiveCandidates[i].name.contains(splitPtestCandidate[j+1]);
                }
                UIALogger.logMessage('Value of resultFirstCompare is [%0], value for resultSecondCompare is [%1]'.format(resultFirstCompare, resultSecondCompare));
                if (resultFirstCompare || resultSecondCompare) {
                	finalResult++;
                }
                UIALogger.logMessage('Value of finalResult: [%0]'.format(finalResult));
                UIALogger.logMessage('#################End Checking proactiveCandidate[%0]'.format(i));
            }
            UIALogger.logMessage('		finalResult: %0'.format(finalResult));
            UIALogger.logMessage('		proactiveCandidates.length: %0'.format(proactiveCandidates.length));
            UIALogger.logMessage('		Verification: %0'.format(finalResult == proactiveCandidates.length ? 'Passed' : 'Failed'));
            UIALogger.logMessage('		typedText = [%0]'.format(proactiveCandidates[0].name));
            UIALogger.logMessage('		expectedText = [%0]'.format(args.candidates));
        }
    },
    
    /**
     *  Type new user words using English keyboard for three times, so dictionary can save it to Cache.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, subali)
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, subali) 
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeUserWords: function typeUserWords(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'bundleID']);
    	var app = target.appWithBundleID(args.bundleID);
        // NEED SOME DELAY TO LOAD DICTIONARY
        target.delay(5);
        app.cleanupForInternationalTyping();
        
        for (i=0; i<3; i++) {
            app.typeString(args.keystrokesText, args.expectedText, args.flick == '1');
        }  
        // NEED SOME DELAY AFTER TYPING NEW WORDS
        target.delay(5);
        //DISMISS KEYBOARD AFTER TYPING NEW WORDS
        app.tap(UIAQuery.buttons("Cancel"));       
    },

    /**
     *  Type partial user words using English keyboard, and verify the user words are shown as top candidates in Keyboard
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, subali)
     * @param {string}  [args.expectedText] - Optional expected text to be typed (e.g, subali) 
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyUserWords: function typeAndVerifyUserWords(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'bundleID']);
        var app = target.appWithBundleID(args.bundleID);
        var resultCounter = 0;
        // NEED SOME DELAY TO LOAD DICTIONARY
        target.delay(10);
        app.cleanupForInternationalTyping();    
        app.typeString(args.keystrokesText, args.expectedText, args.flick == '1');

        var allCandidates = app.inspectAll(UIAQuery.keyboard().isVisible().andThen(UIAQuery.query("UIKeyboardPredictionCell")));
        for (i=0; i<allCandidates.length; i++){
            var result = allCandidates[i].name.localeCompare(args.expectedText);
            UIALogger.logMessage('      Comparing with candidate [%0]: [%1]'.format(i, allCandidates[i].name));
            if (result != 0){
                resultCounter ++;
            } else {
                UIALogger.logMessage('      Verification: Passed');
                UIALogger.logMessage('      InPredictionBar = candidate [%0] [%1]'.format(i, allCandidates[i].name));
                UIALogger.logMessage('      expectedUserWords = [%0]'.format(args.expectedText));
                break;
            }
        }

        if (resultCounter == 3){
            UIALogger.logMessage('      Verification: Failed');
            UIALogger.logMessage('      Expected User Words Not Shown In Prediction Bar');
        }
        
        UIAUtilities.assert(!(resultCounter == 3), 'Expected User Words Not Shown In Prediction Bar');
    },
    
    /**
     *  Type keystorkes on standard/10-key keyboard, and verify if expected datetime candidates are available.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *      If expectedText is not specified:
     *          Verify if specified words exist in candidate list for a keystroke, or opposite.
     *      If expectedText is specified:
     *          Verify if specified predictive candidates are available in candidate list, after the first conversion is fixed, or opposite.
     *
     *  This is for Japanese only so far.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected text (e.g, J-Kana: "あした")
     * @param {string}  [args.expectedText] - special string for datetime word. which showns in candate as expected
     *                                        (One of "TODAY-4".."TODAY".."TODAY+4", "THISMONTH-2".."THISMONTH".."THISMONTH+2", "THISYEAR-1".."THISYEAR".."THISYEAR+2")
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyDateWordCandidates: function typeAndVerifyDateWordCandidates(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedText: null,
            flick: '0',
            testCaseID: null,
        }, true);

        InternationalKeyboardTests._assertRequiredArguments(args, ['keystrokesText', 'bundleID']);

        var keyboardID;
        var app = target.appWithBundleID(args.bundleID);
        app.withMaximumSnapshotBreadth(400, function() {
            keyboardID = app.getKeyboardID();
        });
        UIALogger.logDebug('keyboardID: %0'.format(keyboardID));
        var languageID = keyboardID.match(/^[^-@]*/g)[0];  // [0] is necessary to get the value in string type <rdar://problem/17049829>
        UIALogger.logDebug('languageID: %0'.format(languageID));
        var candidates = app.getExpectedDateWordCandidates(args.expectedText);
        UIALogger.logDebug('Candidates for "%0": %1=[%2]'.format(args.keystrokesText, args.expectedText, candidates));

        app.cleanupForInternationalTyping();
        app.typeKeystrokes(args.keystrokesText, null, args.flick == '1');
        target.delay(0.5);
        International.verifyCandidates(candidates, null, args.testCaseID);
    },
    
    /**
     *  Type keystorkes on standard/10-key keyboard, and verify the emoji on candidate view.
     *  Assuming expected keyboard is already loaded. Clean the view/field before typing.
     *
     * @param {object}  args - Test arguments
     * @param {string}  [args.bundleID] - Application bundleID
     * @param {string}  [args.keystrokesText] - Keystorkes for the expected emoji (e.g, C-Pinyin: "kaixin" to get 😄)
     * @param {string}  [args.expectedEmoji] - Expected Emoji.
     * @param {string}  [args.flick="0"] - Optional enable flick typing if "1"
     * @param {string}  [args.testCaseID] - Optional show TSTT test case ID in log if presented
     **/
    typeAndVerifyEmojiMapping: function typeAndVerifyEmojiMapping(args) {
        args = UIAUtilities.defaults(args, {
            keystrokesText: null,
            expectedEmoji: null,
            flick: '0',
            testCaseID: null,
        }, true);
        InternationalKeyboardTests._assertRequiredArguments(args, ['bundleID', 'keystrokesText', 'expectedEmoji']);

        var app = target.appWithBundleID(args.bundleID);
        app.cleanupForInternationalTyping();
        
		//Find all unicode encoding emojis bytes and convert to normal chars.
		var expectedEmoji = args.expectedEmoji;
		var matched = expectedEmoji.match(/0x[0-9a-fA-F]+/g);
		if (matched != null && matched.length>0) {
			for(var k=0; k < matched.length; k++) {
				var toReplaceChar = International._utf16EncodeAsString(matched[k]);
				expectedEmoji = expectedEmoji.replace(matched[k], toReplaceChar);
			}
			expectedEmoji = expectedEmoji.replace(/ /g, "");
		}
		
		//type key strokes and verify the candidates is expected emoji.
        app.typeKeystrokes(args.keystrokesText, "", args.flick == '1');
		app.waitUntilReady();
		International.verifyCandidates(expectedEmoji, null, args.testCaseID);
    },
}
