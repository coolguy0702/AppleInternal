load('Calendar.js');

load('UIAApp+International.js');

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/

/**
 * Launch specified app for keyboard testing, and focus on text view or field to be typed.
 *
 * @returns {boolean} - always true if completed successfully.
 */
calendar.setupForInternationalTyping = function setupForInternationalTyping(options) {
    International.withFunctionBoundaryLogging(this, function () {
		UIALogger.logMessage("Launching Calendar");
        this.navigation.goTo(UIStateDescription.Calendar.NEW_EVENT);
        this.tapIfExists(UIAQuery.buttons().andThen(UIAQuery.buttons(LocStrings.CLEAR_TEXT)));
		UIALogger.logMessage("Open a new calendar event view.");
    });
}

/*****************************************************************************/
/*                                                                           */
/*   Mark: Actions                                                           */
/*                                                                           */
/*      Atomic units of UI automation and helper functions                   */
/*      These will assume the devices is already in the required state       */
/*                                                                           */
/*****************************************************************************/

/**
 * Clear all text at focused text view or field on current app, for the next typing.
 *
 * @returns {boolean} - always true if completed successfully.
 * @throws              if callout menu cannot be shown.
 */
calendar.cleanupForInternationalTyping = function cleanupForInternationalTyping() {
    International.withFunctionBoundaryLogging(this, function () {
        this.withMaximumSnapshotBreadth(400, function() {
            UIALogger.logMessage("Clearing the content for calendar");
            this.scrollUpIfExists(UIAQuery.Calendar.EDIT_EVENT_CONTAINER)
            this.tapIfExists(UIAQuery.buttons().andThen(UIAQuery.buttons(LocStrings.CLEAR_TEXT)));
        }.bind(this));
    });
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Helpers                                                             */
/*                                                                             */
/*      Functions that perform basic actions checks in the app                 */
/*      These are App specific helpers only                                    */
/*                                                                             */
/*******************************************************************************/

/**
 * Get text in text view or field on current active app.
 *
 * @returns {string} -  typed text on text view or field. NULL if unsupported app is active.
 */
calendar.getTextFromElementForInternationalTyping = function getTextFromElementForInternationalTyping() {
    return International.withFunctionBoundaryLogging(this, function () {
        var typedText = "";

        this.withMaximumSnapshotBreadth(400, function() {
            typedText = this.valueOf(UIAQuery.Calendar.EDIT_EVENT_TITLE);
        }.bind(this));

        return typedText;
    });
}
