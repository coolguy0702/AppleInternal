load('UIAApp.js');

load('International.js');

/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be used frequently                      */
/*                                                                             */
/*******************************************************************************/

UIAUtilities.assert(
    typeof KeystrokesGenerator === 'undefined',
    'KeystrokesGenerator has already been defined.'
);

/**
    @namespace
    @augments KeystrokesGenerator
*/
KeystrokesGenerator = function(app, languageID) {
    UIAUtilities.assert(app && app instanceof UIAApp, 'No app provided for KeystrokesGenerator');
    UIAUtilities.assert(languageID, 'No language ID provided for KeystrokesGenerator');

    this.app = app;
    this.languageID   = languageID;
    this.languageCode = languageID.match(/^([^@_]*)_([^@_]*)$/)[1];
    this.regionCode   = languageID.match(/^([^@_]*)_([^@_]*)$/)[2];

    var usesPopupChars = false;
    
    switch (this.languageCode) {
        case 'zh':
            // Chinese
            load('KeystrokesGenerator+Chinese.js');
            break;
        case 'ja':
            // Japanese
            load('KeystrokesGenerator+Japanese.js');
            break;
        case 'ko':
            // Korean
            load('KeystrokesGenerator+Korean.js');
            break;
        case 'fr':
            // French
            load('KeystrokesGenerator+French.js');
            usesPopupChars = true;
            break;
        default:
            // Guess as Latin Generic 
            load('KeystrokesGenerator+LatinGeneric.js');
            usesPopupChars = true;
            break;
    }

    if (usesPopupChars) {
        this.popupKeyList = this.getPopupkeyList(this.languageCode, this.regionCode);
        this.baseKeyList = this.getbasekeyListForActiveKeyboard();
    }

    // Enable faux collection view to obtain candidate cells properly <rdar://problem/24478187>
    target.performTask('/usr/bin/defaults', ["write", "/private/var/mobile/Library/Preferences/com.apple.scripter.plist", "FauxCollectionViewCellsDisabled", "-bool", "NO"]);
}

KeystrokesGenerator.prototype = {

    /**
     * Get the keyboard ID for the active keyboard
     *
     * @returns {string} - keyboard ID
     */
    getKeyboardID: function getKeyboardID() {
            var keyboardID  = this.app.getKeyboardID();
            UIALogger.logDebug('Current keyboard ID is ' + keyboardID);
            return keyboardID;
    },

    /**
     * Get the keyboard layout type for the active keyboard
     *
     * @returns {string} - keyboard layout type
     */
    getKeyboardLayoutType: function getKeyboardLayoutType() {
            var keyboardLayoutType = this.getKeyboardID().match(/(sw=[^;]*)/)[1];
            UIALogger.logDebug('Current keyboard layout type is ' + keyboardLayoutType);
            return keyboardLayoutType;
    },

    /**
     * This function types keystrokes on CJK keyboard
     *
     * @param    {string} keystrokesText - keystroke text (e.g. toukyou).
     * @param    {string} expectedText - text to be displayed in text view or field on app (e.g. 東京).  Kanji conversion won't happen if empty on Japanese keyboards
     * @param   {boolean} [options.flick=true] - if true, keystrokes will be entered by flick gesture on appropriate CJK 10-key keyboards, or use diacritical key on French AZERTY keyboard
     *
     */
    typeKeystrokes: function typeKeystrokes(keystrokesText, expectedText, flick) {
        UIALogger.logDebug('Language code for current keyboard is ' + this.languageCode);
        switch (this.languageCode) {
            case 'zh':
                if (this.regionCode == 'Hans') {
                    // Simplified Chinese
                    this.typeKeystrokes_SimpChinese(keystrokesText, expectedText, flick);
                } else if (this.regionCode == 'Hant') {
                    // Traditional Chinese
                    this.typeKeystrokes_TradChinese(keystrokesText, expectedText, flick);
                }
                break;
            case 'ja':
                // Japanese
                this.typeKeystrokes_Japanese(keystrokesText, expectedText, flick);
                break;
            case 'ko':
                // Korean
                this.typeKeystrokes_Korean(keystrokesText, expectedText, flick);
                break;
            case 'fr':
                // French
                this.typeKeystrokes_French(keystrokesText, expectedText, flick);
                break;
            default:
                // Guess as Latin Generic 
                this.typeKeystrokes_LatinGeneric(keystrokesText, expectedText, flick);
                break;
        }
    },

    /**
     * This function switch keyplane for current active keyboard
     *
     * @param    {string} keyplane - keyplane for each language specific.
     * @returns {boolean} - always true if completed successfully.
     * @throws              if wrong keyplane is specified.
     *
     */
    switchKeyplane: function switchKeyplane(keyplane) {
        switch (this.languageCode) {
            case 'zh':
                // Simplified & Traditional Chinese
                this.switchKeyplane_Chinese(keyplane);
                break;
            case 'ja':
                // Japanese
                this.switchKeyplane_Japanese(keyplane);
                break;
            case 'ko':
                // Korean
                this.switchKeyplane_Korean(keyplane);
                break;
            default:
                // Other language keyboards
                break;
        }
    },

    /**
     * Tap or flick on current loaded 10-key keyboard.
     *
     * @param   {array}     keystrokesArray - array of key stroke stream by specify key and action.
     *                          (e.g, [['あ', 'R'], ['か', 'L']] for "えき" on flick mode, [['あ', 4], ['か', 2]] on tap mode)
     * @returns {boolean} - always true if completed successfully.
     * @throws              if wrong key is specified.
     */
    typeKeystrokesFor10key: function typeKeystrokesFor10key(keystrokesArray) {
        International.withFunctionBoundaryLogging(this, function () {
            for (var i = 0; i < keystrokesArray.length; i++) {
                var key = keystrokesArray[i].key;
                var act = keystrokesArray[i].act;

                // a string which begins with '==>' indicates a keyplane switch
                var matches;
                if (matches = key.match(/^==>(.*)/)) {
                    // the string following '==>' identifies the keyplane
                    var keyplane = matches[1];
                    this.switchKeyplane(keyplane);
                    continue;
                }

                var targetKey = UIAQuery.keyboard().andThen(UIAQuery.keys(key)).orElse(UIAQuery.keys(key.toUpperCase()));;

                this.app.withMaximumSnapshotBreadth(400, function() {
                    // Inside this block, we’ll retrieve up to 400 children at each node
                    // <rdar://problem/22390922> UIA2: Unexpected Warning - Incomplete snapshot for node 2346 - 200/336 children retrieved
                    
                    if (act >= 1 && act <= 5) {
                        this.tap(targetKey, {tapCount:act});
                    } else if (act == 'L') {
                        this.drag(targetKey, {flick:true, fromOffset:{x:0.5,y:0.5}, toOffset:{x:-0.5,y:0.5}, duration:0.05});
                    } else if (act == 'U') {
                        this.drag(targetKey, {flick:true, fromOffset:{x:0.5,y:0.5}, toOffset:{x:0.5,y:-0.5}, duration:0.05});
                    } else if (act == 'R') {
                        this.drag(targetKey, {flick:true, fromOffset:{x:0.5,y:0.5}, toOffset:{x:1.5,y:0.5}, duration:0.05});
                    } else if (act == 'D') {
                        this.drag(targetKey, {flick:true, fromOffset:{x:0.5,y:0.5}, toOffset:{x:0.5,y:1.5}, duration:0.05});
                    } else {
                        this.tap(targetKey);
                    }
                }.bind(this.app));
                // Back to previous limit (200 by default)
            }
        });
    },

    /**
     * This function generates candidates for date or time word
     *
     * @param    {string} dateTimeID - ID to specify date or time (e.g. TODAY, TODAY+1, TODAY-1, THISMONTH[+num|-num], THISYEAR[+num|-num]).
     * @returns {boolean} - conversion candidate list for dateTime ID if it's acceptable.
     * @throws              if wrong ID or unsupported language is specified.
     *
     */
    getExpectedDateWordCandidates: function getExpectedDateWordCandidates(dateTimeID) {
        switch (this.languageID) {
            case 'ja_JP':
                // Japanese
                return this.getExpectedDateWordCandidates_Japanese(dateTimeID);
                break;
            default:
                // Other language keyboards
                throw new UIAError('The language "%0" is not supported to generate date & time word conversion candidates.'.format(this.languageID));
                break;
        }
    },

    /**
     * This function obtain list of base keys (only alphabet plane)
     *
     * @returns {array} - List of base keys on alphabet plane on current active keyboard
     * @throws              if wrong keyboardID is specified.
     *
     */
    getbasekeyListForActiveKeyboard: function getbasekeyListForActiveKeyboard() {
        return International.withFunctionBoundaryLogging(this, function () {
            var keys = this.app.inspectAll(UIAQuery.keyboard().andThen(UIAQuery.keys()));
            var results = [' '];
                        
            for (i = 0; i < keys.length; i++) {
                if (keys[i].name.length == 1) {
                    results.push(keys[i].name.toUpperCase());
                    results.push(keys[i].name.toLowerCase());
                }
            }
            UIALogger.logDebug('Obtained baseKeyList for current active keyboard : %0'.format(results));
            return results;
        });
    },

    /**
     * This function obtain list of popup key keyplane for current active keyboard
     *
     * @param    {string} languageCode - language code  e.g, "es", "de", "fr"
     * @param    {string} regionCode - region code  e.g, "ES" or "MX" for "es", "DE" or "AT" or "CH" for "de"
     * @returns {object} - popup key menu list; paired base key and arry of the popup keys  e.g, {'a':['à','á','â',...], 'u':['ū','ù','ú',...]}
     * @throws              if wrong keyboardID is specified.
     *
     */
    getPopupkeyList: function getPopupkeyList(languageCode, regionCode) {
        return International.withFunctionBoundaryLogging(this, function () {
            var results = new Object();
            var kbdPlist    = '/System/Library/TextInput/TextInput_%0.bundle/Keyboard-%0.plist'.format(languageCode);
            var kbdExtPlist = '/System/Library/TextInput/TextInput_%0.bundle/Keyboard-%0_%1.plist'.format(languageCode, regionCode);
            var kbdPlistObj;
            
            // Read /System/Library/TextInput/TextInput_*.bundle/Keyboard-*.plist file, and make it JS Objects
            if (UIAFile.fileExists(kbdPlist)) {
                UIALogger.logDebug('Reading TextInput plist file: %0'.format(kbdPlist));
                var kbdPlistResult = target.performTask('/usr/bin/plutil', ['-convert', 'json', '-o', '-', kbdPlist], 5);
                UIAUtilities.assert(kbdPlistResult['exitCode'] == 0, 'Cannot get JSON formatted string via plutil command for file: %0'.format(kbdPlist));
                kbdPlistObj = JSON.parse(kbdPlistResult['stdout']);
            }

            // Read /System/Library/TextInput/TextInput_*.bundle/Keyboard-*_*.plist file, and make it JS Objects, if available
            if (UIAFile.fileExists(kbdExtPlist)) {
                UIALogger.logDebug('Reading TextInput plist file: %0'.format(kbdExtPlist));
                var kbdPlistResult = target.performTask('/usr/bin/plutil', ['-convert', 'json', '-o', '-', kbdExtPlist], 5);
                if (kbdPlistResult['exitCode'] == 0) {
                    var kbdExtPlistObj = JSON.parse(kbdPlistResult['stdout']);
                    // merge the two objects
                    for (var attr in kbdExtPlistObj) {
                        kbdPlistObj[attr] = kbdExtPlistObj[attr];
                    }
                }
            }

            // Make a new popupkeyList Object 
            var keyList = Object.keys(kbdPlistObj);
            for (var i = 0; i < keyList.length; ++i) {
                if (keyList[i].match(/^Roman-Accent-(.*)$/)) {
                    var keytop = RegExp.$1;
                    var keysString = kbdPlistObj[keyList[i]]['Strings'];
                    var direction = kbdPlistObj[keyList[i]]['Direction'];
                    var keysList = keysString.split(/\s+/);
                    // Remove base key from the list
                    keysList.splice(keysList.indexOf(keytop), 1);
                    
                    // EXCEPTION: "ª" and "º" : Move to the most far postion.
                    if (keytop.match(/[ao]/i)) {
                        var idx;
                        if ((idx = keysList.indexOf('ª')) >= 0 || (idx = keysList.indexOf('º')) >= 0) {
                            var char = keysList.splice(idx, 1);
                            keysList = keysList.concat(char);
                        }
                    }

                    if (direction.match(/left/i)) {
                        keysList.reverse();
                        // EXCEPTION: "o", "O" : Insert base key into the second position from the most right if keys are available 10 or more.
                        if (keytop.match(/o/i) && keysList.length == 9) {
                            var lastKey = keysList.pop();
                            keysList = keysList.concat(keytop, lastKey);
                        } else {
                            keysList.push(keytop);
                        }
                    } else {
                        // EXCEPTION: "e", "E" : Insert base key into the second position from the most left if keys are available 9 or more.
                        if (keytop.match(/e/i) && keysList.length == 8) {
                            var firstKey = keysList.shift();
                            keysList.unshift(firstKey, keytop);
                        } else {
                            keysList.unshift(keytop);
                        }
                    }
                    results[keytop] = keysList;
                }
            }
            UIALogger.logDebug('Generated popupKeyList for languageID "%0_%1" : %2'.format(languageCode, regionCode, JSON.stringify(results)));

            return results;
        });
    },
    
    /**
     * This function tap a key in popup key menu
     *
     * @param    {string} basekey - Keytop appears on keyboard.
     * @param    {string} basekeyIndex - xxxxx.
     * @param    {string} charIndex - xxxxx.
     * @returns {boolean} - always true if completed successfully.
     * @throws              if wrong value for arguments is specified.
     *
     */
    tapCharPopup: function tapCharPopup(basekey, basekeyIndex, charIndex) {
        International.withFunctionBoundaryLogging(this, function () {
            // calculate toOffset which is x distance from a basekey
            var offset = charIndex - basekeyIndex;

            // hold the basekey and drag to a desired diacritics
            if (this.app.dragIfExists(UIAQuery.keys(basekey), {holdDuration:1, toOffset:{x:0.5 + offset, y:-1.0}})) {
                UIALogger.logMessage('successfully entered the character');
            } else {
            // in case of the current pane is not the right case
                UIALogger.logMessage('the character does not exist on current case keyboard. see if it exists in the other case keyboard');
                this.app.tapIfExists(UIAQuery.keyboard().andThen(UIAQuery.buttons('shift')));
                this.app.dragIfExists(UIAQuery.keys(basekey), {holdDuration:1, toOffset:{x:0.5 + offset, y:-1.0}});
                UIALogger.logMessage('successfully entered the character');        
            }
        });
    },

    /**
     * This function obtain info for popup key
     *
     * @param    {string} character - Latin character to be typed.
     * @returns {array} - Array of baseKey, baseKeyIndex, and characterIndex if the key won't be available on keyboard (expecting in poup key menu).  Otherwise false.
     *
     */
    getPopupkeyInfo: function getPopupkeyInfo(character) {
        var charIndex;
        var basekeyIndex;
        var result;
        
        // check if the character exists in the mapping table. also ignore a base character.
        if ((character in this.popupKeyList) == false) {
            UIALogger.logDebug('Character "%0" is not avaiable in the mapping table as base character.'.format(character));
            for (basekey in this.popupKeyList) {
                charIndex = this.popupKeyList[basekey].indexOf(character);
                if (charIndex > -1) { 
                    basekeyIndex = this.popupKeyList[basekey].indexOf(basekey);
                    result = [basekey, basekeyIndex, charIndex];
                    UIALogger.logDebug('Character "%0" was found in basekey table for "%1" at index %2.'.format(character, basekey, basekeyIndex));
                    break;
                } else {
                    result = false;
                }
            }
        } else {
            result = false;
        }
        
        return result;
    },

}
