load('UIATesting.js');
load('Music.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof MusicTests === 'undefined',
    'MusicTests has already been defined.'
);

/** @namespace */
var MusicTests = {

    /**
      * Plays a song from 'Library' tab and category 'Songs'. Song choice is
      * determined via:
      *   - If an array of keywords is passed, we will attempt to find a music
      * element that matches. If more than one element matches all the keywords,
      * we will use the first.
      *   - If the keywords array is empty and the random flag is enabled, we
      * will select a random element from the elementsQuery list.
      *   - If the keywords array is empty and the random flag is not enabled,
      * we will select the first element from elementsQuery list.
      *
      * @targetApps Music
      *
      * @param {object} args - Test arguments
      * @param {null|array}     [args.keywords=null] -
      *                             Search terms for selecting a song element.
      * @param {boolean}        [args.random=false] - If set and args.keywords is not
      *                             set, we will choose a random song to play.
      * @param {boolean}        [args.stopCurrentPlayback=true] - If set, will
      *                             attempt to stop any current playback.
      * @param {null|number}    [args.duration=10] - If set, will play song for
      *                             passed number of seconds before test ends.
      * @param {boolean}        [args.stopAfterDuration=true] - Applicable only if
      *                             duration is set. If set, stops playback after
      *                             the duration time has elapsed.
      * @param {boolean}        [args.confirmDesiredElementPlaying=true] - If set,
      *                             will confirm the choosen song is playing.
      *                             Check is based off name that was determine
      *                             via keywords or random flag.
      * @param {boolean}        [args.confirmPlaying=true] - If set, will confirm
      *                             something is playing. Does not check playing
      *                             song's name. If confirmDesiredElementPlaying
      *                             is set, it will take precedent.
      * @param {boolean}        [args.nonSubscriberMode=true] - If set, will not
      *                             login but use the non subscriber mode.
      */
    playSongFromLibrary: function playSongFromLibrary(args) {
        args = UIAUtilities.defaults(args, {
            // selection options:
            keywords:               null,
            random:                 false,

            // playback options:
            stopCurrentPlayback:    true,
            duration:               10, // seconds
            stopAfterDuration:      true,

            // validation options:
            confirmDesiredElementPlaying: true,
            confirmPlaying:         true,

            // login options:
            nonSubscriberMode:      true,
        });

        music.startSongFromSongList(args);
    },

    /**
      * Stops playback.
      *
      * @targetApps Music
      *
      * @param {object} args - Test arguments
      * @param {boolean}     [args.failOnNoPlay=true] - If set, test fails if
      *                             nothing is playing.
      */
    stopPlayback: function stopPlayback(args) {
        args = UIAUtilities.defaults(args, {
            failOnNoPlay:           true,
        });

        music.stopPlayback(args);
    },

    /**
      * Plays a song from 'Library' tab and category 'Playlist'. Playlist choice is
      * determined via:
      *   - If an array of keywords is passed, we will attempt to find a playlist
      * element that matches. If more than one element matches all the keywords,
      * we will use the first.
      *   - If the keywords array is empty and the random flag is enabled, we
      * will select a random element from the elementsQuery list.
      *   - If the keywords array is empty and the random flag is not enabled,
      * we will select the first element from elementsQuery list.
      *
      * @overrideID Start Specific Playlist
      * @targetApps Music
      *
      * @param {object} args - Test arguments
      * @param {null|array}     [args.keywords=["90"]] -
      *                             Search terms for selecting a playlist element.
      * @param {boolean}        [args.random=false] - If set and args.keywords is not
      *                             set, we will choose a random playlist to play.
      * @param {boolean}        [args.stopCurrentPlayback=true] - If set, will
      *                             attempt to stop any current playback.
      * @param {null|number}    [args.duration=10] - If set, will play playlist for
      *                             passed number of seconds before test ends.
      * @param {boolean}        [args.stopAfterDuration=true] - Applicable only if
      *                             duration is set. If set, stops playback after
      *                             the duration time has elapsed.
      * @param {boolean}        [args.confirmDesiredElementPlaying=true] - If set,
      *                             will confirm the choosen playlist is playing.
      *                             Check is based off name that was determine
      *                             via keywords or random flag.
      * @param {boolean}        [args.confirmPlaying=true] - If set, will confirm
      *                             something is playing. Does not check playing
      *                             playlist's name. If confirmDesiredElementPlaying
      *                             is set, it will take precedent.
      * @param {boolean}        [args.nonSubscriberMode=true] - If set, will not
      *                             login but use the non subscriber mode.
      */
    startPlaylist: function startPlaylist(args) {
        args = UIAUtilities.defaults(args, {
            // selection options:
            keywords:               ['90'],
            random:                 false,

            // playback options:
            stopCurrentPlayback:    true,
            duration:               10, // seconds
            stopAfterDuration:      true,

            // validation options:
            confirmDesiredElementPlaying: true,
            confirmPlaying:         true,

            // login options:
            nonSubscriberMode:      true,
        });

        music.startPlaylist(args);
    },

    /**
      * Starts playing a radio station from the 'Radio' tab. Choosen station is
      * determined via:
      *   - If an array of keywords is passed, we will attempt to find a radio
      * element that matches. If more than one element matches all the keywords,
      * we will use the first.
      *   - If the keywords array is empty and the random flag is enabled, we
      * will select a random element from the elementsQuery list.
      *   - If the keywords array is empty and the random flag is not enabled,
      * we will select the first element from elementsQuery list.
      *
      * @targetApps Music
      *
      * @param {object} args - Test arguments
      * @param {null|array}     [args.keywords=["NPR"]] -
      *                             Search terms for selecting a radio element.
      * @param {boolean}        [args.random=false] - If set and args.keywords is not
      *                             set, we will choose a random song to play.
      * @param {boolean}        [args.stopCurrentPlayback=true] - If set, will
      *                             attempt to stop any current playback.
      * @param {null|number}    [args.duration=10] - If set, will play song for
      *                             passed number of seconds before test ends.
      * @param {boolean}        [args.stopAfterDuration=true] - Applicable only if
      *                             duration is set. If set, stops playback after
      *                             the duration time has elapsed.
      * @param {boolean}        [args.confirmPlaying=true] - If set, will confirm
      *                             something is playing. Does not check playing
      *                             radio's name. If confirmDesiredElementPlaying
      *                             is set, it will take precedent.
      * @param {string}         [args.AppleID="PERSISTEDAPPLEID"] - Apple ID. Use
      *                             "PERSISTEDAPPLEID" to retrieve persisted password
      *                             from Springboard
      * @param {string}         [args.AppleIDPassword="PERSISTEDAPPLEIDPASSWORD"] -
      *                             AppleID password. Use 'PERSISTEDAPPLEIDPASSWORD' to
      *                             retrieve persisted password from SpringBoard
      */
    playRadioStation: function playRadioStation(args) {
        args = UIAUtilities.defaults(args, {
            // selection options:
            keywords:               ['NPR',],
            random:                 false,

            // playback options:
            stopCurrentPlayback:    true,
            duration:               10, // seconds
            stopAfterDuration:      true,

            // validation options:
            confirmPlaying:         true,

            // we need to sign in to access any radio station
            appleID :               springboard.appleID,
            appleIDPassword :       springboard.appleIDPassword,
        });

        music.startRadioStation(args);
    },

    /**
     * Queues up a song and then runs one or more actions on the player controls.
     * Actions are listed in array 'actions' and may be comprised of'Play', 'Pause',
     * 'Next', 'Previous'.
     *
     * Can take optional arrays 'validateSongs' and 'actionsTimeouts'. These arrays
     * must be same size as 'actions' in order to be used. 'validateSongs' checks
     * the current song listed in the player after an action has been taken.
     * 'actionsTimeouts' sets a delay till the next action is taken.
     *
     * @targetApps Music
     *
     * @param {object} args - Test arguments
     * @param {array}          [args.keywords=["Airplane"]] - an array of search strings
     *                             Search terms for selecting a song element.
     * @param {boolean}        [args.random=false] - If set and args.keywords is not
     *                             set, we will choose a random song to play.
     * @param {array}          [args.actions=["Pause"]] -
     *                             Array of actions. i.e. buttons to press on
     *                             the control menu.
     * @param {boolean}        [args.fullScreenMode=true] - If set, we interact with the
     *                              control buttons on the full screen player instead of the mini.
     * @param {array}          [args.actionsTimeouts=[5]] - If set, contains
     *                             an array of timeouts to be taken after a corresponding
     *                             action. Array size must be same as 'actions' array.
     *                             Array can contain null elements if no timeout
     *                             is desired on an action.
     * @param {array}          [args.validateSongs=["Airplane"]] -
     *                             If set, contains an identifying song substring
     *                             to match against after a control button has been
     *                             pressed. This match is a 'contains' match.
     *                             e.g. ['Bob'] would match on 'Bob Marley's greatest hits'.
     *                             Array size must be same as 'actions' array. Array can contain
     *                             null elements if no validation is desired on an action.
     * @param {boolean}        [args.nonSubscriberMode=true] - If set, will not
     *                             login but use the non subscriber mode.
     */
    operatePlayerControls: function operatePlayerControls(args) {
        args = UIAUtilities.defaults(args, {
            // selection options:
            keywords:               ['Airplane'],
            random:                 false,

            // actions:
            actions:                [Controls.PAUSE],
            actionsTimeouts:        [5],

            // validation options:
            validateSongs:          ['Airplane'],

            // mode:
            fullScreenMode:         true,

            // login options:
            nonSubscriberMode:      true,
        });

        UIALogger.logMessage('Queuing up song...');
        music.startSongFromSongList(args);

        UIALogger.logMessage('Song should be playing. Attempting to operate player controls.');
        music.navigatePlayerControls(args);
    }
}
