load('UIAApp.js');
load('SpringBoard.js');

UIAUtilities.assert(
    typeof Music === 'undefined',
    'Music has already been defined.'
);


/*******************************************************************************/
/*                                                                             */
/*   Mark: Query Constants                                                     */
/*                                                                             */
/*      App specific queries that will be made frequently                      */
/*                                                                             */
/*******************************************************************************/

var tabBar = UIAQuery.tabBars('UITabBar').orElse('Music.TabItemsStack');

/** Constants for common Music queries */
UIAQuery.Music = {

    /** Queries for the tabs at the bottom of the app */
    Tabs:   {
        LIBRARY:    tabBar.andThen(UIAQuery.query('Library').isVisible()), // workaround for rdar://problem/28662020

        FOR_YOU:    tabBar.andThen(UIAQuery.query('For You')),

        BROWSE:     tabBar.andThen(UIAQuery.query('Browse')),

        RADIO:      tabBar.andThen(UIAQuery.query('Radio')).isVisible(),

        SEARCH:     tabBar.andThen(UIAQuery.query('Search')),
    },

    /** Evaluation queries are used to determine whether we're in a certain state or not */
    Evaluation: {
        Tabs:   {
            /** Present when we're in the Library Tab */
            LIBRARY:    tabBar.andThen(UIAQuery.query('Library').isSelected()),

            /** Present when we're in the For You Tab */
            FOR_YOU:    tabBar.andThen(UIAQuery.query('For You').isSelected()),

            /** Present when we're in the Radio Tab */
            BROWSE:     tabBar.andThen(UIAQuery.query('Browse').isSelected()),

            /** Present when we're in the Radio Tab */
            RADIO:      tabBar.andThen(UIAQuery.query('Radio').isSelected()),

            /** Present when we're in the Search Tab */
            SEARCH:     tabBar.andThen(UIAQuery.query('Search').isSelected()),
        },

        Library:    {
            /** Navbar for Playlists list view in Library Tab */
            PLAYLISTS_NAVBAR:   UIAQuery.navigationBars('Playlists'),

            /** Navbar for Songs list view in Library Tab */
            SONGS_NAVBAR:       UIAQuery.navigationBars('Songs'),

            /** Collection view present with library categories popover on iPad */
            POPOVER_COLLECTION: UIAQuery.collectionViews('Music.CompositeComponentCollectionView'),
        },

        Players:    {
            /** Mini Player */
            MINI_PLAYER: UIAQuery.query('MiniPlayer').isVisible(),

            /** Full Screen Player */
            FULL_SCREEN_PLAYER: UIAQuery.query('NowPlayingScreen'),
        },

        MusicCollections:  {
            /** Specific Playlist */
            PLAYLIST:   UIAQuery.navigationBars('Library').andThen(UIAQuery.buttons('Playlists')),
        },

        /** Present when we're typing a Search */
        SEARCH_BAR:   UIAQuery.query('Music.SearchSourceBar'),

        SPLASH_SCREEN:  UIAQuery.staticTexts('Welcome to Apple Music'),

        JOIN_APPLE_MUSIC:  UIAQuery.contains('Join Apple Music'),

        JOIN_APPLE_MUSIC_SCREEN: UIAQuery.endsWith('download all the music you want.'),

        APPLE_MUSIC_TRY_IT_NOW: UIAQuery.buttons().contains('Try'),

        APPLE_MUSIC_SPLASH_SCREEN: UIAQuery.staticTexts('The best way to enjoy all the songs you already have and all the ones you want.'),

        /** Help dialog on Now Playing screen: "You can now swipe up to access Repeat, Shuffle, and Up Next." */
        NOW_PLAYING_HELP_DIALOG: UIAQuery.query('Music.NowPlayingScrollingTipView'),
    },

    Library:    {
        /** Library categories */

        PLAYLISTS:  UIAQuery.collectionViews().andThen(UIAQuery.collectionCells('Playlists')),

        SONGS:  UIAQuery.collectionViews().andThen(UIAQuery.collectionCells('Songs')),

        IPAD_LIBRARY_BUTTON:    UIAQuery.navigationBars().andThen(UIAQuery.buttons('Library')),
    },

    Player:     {
        /** Player buttons */
        PLAY_PAUSE_BUTTON:  UIAQuery.query('Music.NowPlayingTransportControlStackView').andThen(UIAQuery.buttons('Play').orElse('Pause').orElse('Stop')).isVisible(),

        NEXT_BUTTON:        UIAQuery.query('Music.NowPlayingTransportControlStackView').andThen(UIAQuery.buttons('Skip').orElse('Next track')),

        PREVIOUS_BUTTON:    UIAQuery.query('Music.NowPlayingTransportControlStackView').andThen(UIAQuery.buttons('Previous track')),

        SHUFFLE_BUTTON:     UIAQuery.buttons('Shuffle'),

        REPEAT_BUTTON:      UIAQuery.buttons('Repeat'),
    },

    /** List of music elements (songs, albums, artists, etc.) */
    GENERAL_MUSIC_ELEMENTS: UIAQuery.query('UINavigationTransitionView').andThen(UIAQuery.collectionViews().andThen(UIAQuery.collectionCells().withPredicate('name != "Shuffle All"'))),

    /** Position of current track */
    TRACK_POSITION: UIAQuery.query('NowPlayingScreen').andThen('Track position'),

    /** Button to dismiss Full Screen Player */
    DISMISS_FULL_SCREEN_PLAYER: UIAQuery.buttons('Dismiss Now Playing Screen'),

    /** Button to dismiss Now Playing help screen */
    DISMISS_NOW_PLAYING_HELP_DIALOG: UIAQuery.query('Music.NowPlayingScrollingTipView').andThen(UIAQuery.buttons('Got It')),

    PLAYLIST_HEADER:    UIAQuery.query('Music.PlaylistDetailHeaderLockupView').andThen(UIAQuery.textViews().topmost()),

    RADIO_STATIONS:  UIAQuery.tableCells('Radio Stations'),

    RADIO_SCROLL_VIEW:  UIAQuery.scrollViews("Music.VerticalScrollStackScrollView"),

    FULL_SCREEN_PLAYER_SONG_NAME:   UIAQuery.query('Music.NowPlayingControlsHeader'),

    MINI_PLAYER_SONG_NAME:  UIAQuery.query('NowPlayingSongTitleBar'),
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: UI State Constants                                                  */
/*                                                                             */
/*      A dictionary of string, function mappings describing the possible      */
/*      UI states of the app. The Description is a human readable identifier   */
/*      for the state and the isCurrentState is a function that returns true   */
/*      when the snapshot argument is in that state and false otherwise.       */
/*                                                                             */
/*******************************************************************************/

/** Right now this is a local variable, but if (when) this becomes the standard we'll want to move it */
var UIStates = {

    /** Splash Screen */
    SPLASH_SCREEN: {
        Description: 'Splash Screen',
        isCurrentState: function(snapshot) {
            return snapshot.exists(
                UIAQuery.Music.Evaluation.SPLASH_SCREEN
                .orElse(UIAQuery.Music.Evaluation.APPLE_MUSIC_SPLASH_SCREEN));
        },
    },

    /** Join Apple Music */
    JOIN_APPLE_MUSIC: {
        Description: 'Join Apple Music Screen',
        isCurrentState: function(snapshot) {
            return snapshot.exists(
                UIAQuery.Music.Evaluation.JOIN_APPLE_MUSIC
                .orElse(UIAQuery.Music.Evaluation.JOIN_APPLE_MUSIC_SCREEN
                .orElse(UIAQuery.Music.Evaluation.APPLE_MUSIC_TRY_IT_NOW)));
        },
    },

    /** States for the various tabs
    /** Library Tab */
    LIBRARY: {
        Description: 'Library',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Tabs.LIBRARY.isVisible())
            && !snapshot.exists(UIAQuery.Music.Evaluation.Library.PLAYLISTS_NAVBAR)
            && !snapshot.exists(UIAQuery.Music.Evaluation.Library.SONGS_NAVBAR);
        },
    },

    /** For You Tab */
    FOR_YOU: {
        Description: 'For You',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Tabs.FOR_YOU.isVisible());
        },
    },

    /** Browse Tab */
    BROWSE: {
        Description: 'Browse',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Tabs.BROWSE.isVisible());
        },
    },

    /** Radio Tab */
    RADIO: {
        Description: 'Radio',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Tabs.RADIO.isVisible());
        },
    },

    /** Search Tab */
    SEARCH: {
        Description: 'Search',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Tabs.SEARCH.isVisible());
        },
    },

    /** States for categories in Library tab */
    /** Playlists list inside Library tab */
    PLAYLISTS:  {
        Description: 'Playlists',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Library.PLAYLISTS_NAVBAR.isVisible());
        },
    },

    /** Songs list inside Library tab */
    SONGS:  {
        Description: 'Songs',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.Library.SONGS_NAVBAR.isVisible());
        },
    },

    /** Any particular playlist ex: My Top Rated */
    PLAYLIST:   {
        Description:    'Playlist',
        isCurrentState: function(snapshot)  {
            return snapshot.exists(UIAQuery.Music.Evaluation.MusicCollections.PLAYLIST.isVisible());
        },
    },

    /** Full Screen Player view */
    FULL_SCREEN_PLAYER: {
        Description: 'Full Screen Player',
        isCurrentState: function(snapshot)  {
            return snapshot.exists(UIAQuery.Music.Evaluation.Players.FULL_SCREEN_PLAYER)
            && !snapshot.exists(UIAQuery.Music.Evaluation.NOW_PLAYING_HELP_DIALOG);
        },
    },

    /** iPad Library Popover categories list view */
    LIBRARY_POPOVER:   {
        Description:    'Library Popover',
        isCurrentState: function(snapshot)  {
            return snapshot.exists(UIAQuery.Music.Evaluation.Library.POPOVER_COLLECTION);
        },
    },

    /** Now Playing help screen popover */
    NOW_PLAYING_HELP_DIALOG: {
        Description: 'Now Playing Help Screen',
        isCurrentState: function(snapshot) {
            return snapshot.exists(UIAQuery.Music.Evaluation.NOW_PLAYING_HELP_DIALOG);
        },
    },
};

/*******************************************************************************/
/*                                                                             */
/*   Mark: Other Constants                                                     */
/*                                                                             */
/*      Any other app specific constants                                       */
/*                                                                             */
/*******************************************************************************/

/**
    @namespace
    @augments UIAApp
*/
var music = target.appWithBundleID('com.apple.Music');

/** Actions possible on the controls of the mini/full player */
Controls = {
    /** Next */
    NEXT:                       'Next',

    /** Previous */
    PREVIOUS:                   'Previous',

    /** Play */
    PLAY:                       'Play',

    /** Pause */
    PAUSE:                      'Pause',
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get The Current UI State                                            */
/*                                                                             */
/*      A function to determine which UIState the app is currently in          */
/*                                                                             */
/*******************************************************************************/

/**
 * Return description of current UI state. See Music UIState constants
 * for possible values. Any critia for defining a state should be very exact so
 * there is no confusion on state. We should always throw if we cannot determine state.
 *
 * Expected starting states: Works for any UI state.
 *
 * @returns {string} Description of current UI state from a list
 * of possible constants contained in Music UIStates.
 *
 * @throws If cannot determine state.
 */
music.currentUIState = function currentUIState() {

    // Grab a snapshot to feed to the isCurrentState functions of the State objects
    var snapshot = this.inspect(UIAQuery.application());

    // List of all the state objects
    var states = Object.keys(UIStates).map(function (key) {
        return UIStates[key];
    });

    /*
     * For each state, check if we're in that state
     * using the isCurrentState function and the snapshot
     * If we are then log and return the State's description
     */
    for (i = 0; i < states.length; i++) {
        var state = states[i];
        if (state.isCurrentState(snapshot)) {
            var stateName = state.Description;
            UIALogger.logMessage('Currently in state %0'.format(stateName));
            return stateName;
        }
    }

    // if we got here, we don't have any idea where we are...
    throw new UIAError('Could not determine state.');
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Get To [page] functions                                             */
/*                                                                             */
/*      Helper functions for navigating to different pages within the app      */
/*                                                                             */
/*******************************************************************************/

/**
 * Navigation function to get to some Music tab from some starting state.
 * Any critia for defining a transition from a state to another state
 * should be very exact. Navigation function should always get to where
 * they are meant to go or throw.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {string} tab - Tab name. Comes from the descriptions for the states listed in UIStates.
 * @param {object} options
 * @param {string} options.nonSubscriberMode - If true and we will not log in
 *                       and instead use the non-subscripter mode of Music.
 *
 * @returns None.
 *
 * @throws If we were unable to transition from some starting state to
 *           desired tab state.
 */
music.getToTab = function getToTab(tab, options) {
    options = UIAUtilities.defaults(options, {
        nonSubscriberMode: true,
        user: null,
        password: null,
    });

    music.launch();
    // workaround for rdar://problem/28311543
    // the splash screen may take several seconds to appear, so we should try to anticipate it
    var splashScreenTimeout = 5;
    UIALogger.logMessage('Waiting %0 seconds to see if the splash screen appears'.format(splashScreenTimeout));
    this.waitUntilPresent(UIAQuery.Music.Evaluation.APPLE_MUSIC_SPLASH_SCREEN, splashScreenTimeout);
    var currentState = this.currentUIState();

    // States where the tabs aren't present
    switch (currentState) {
        case UIStates.FULL_SCREEN_PLAYER.Description:
        case UIStates.LIBRARY_POPOVER.Description:
        case UIStates.SPLASH_SCREEN.Description:
        case UIStates.NOW_PLAYING_HELP_DIALOG.Description:
            this.getToTabTopLevel({currentState: currentState});
            break;
        default:
            break;
    }

    // Can now tap a tab button
    switch (tab) {
        case UIStates.LIBRARY.Description:
            this.tap(UIAQuery.Music.Tabs.LIBRARY);
            break;
        case UIStates.FOR_YOU.Description:
            this.tap(UIAQuery.Music.Tabs.FOR_YOU);
            break;
        case UIStates.BROWSE.Description:
            this.tap(UIAQuery.Music.Tabs.BROWSE);
            break;
        case UIStates.RADIO.Description:
            this.tap(UIAQuery.Music.Tabs.RADIO);
            break;
        case UIStates.SEARCH.Description:
            this.tap(UIAQuery.Music.Tabs.SEARCH);
            break;
        default:
            // should never get here
            throw new UIAError('Could not get to unknown tab: [%0].'.format(tab));
    }
}

/**
 * Navigation function to get to the top level of the current tab. This is
 * a recursive function. Max depth is 3 because max number of actions to any
 * top level of a tab is 2 actions. Added a cushion of 1 call.
 *
 * Any critia for defining a transition from a state to another state
 * should be very exact. Navigation function should always get to where
 * they are meant to go or throw.
 *
 * Expected starting states: Works for any UI state.
 *
 * @param {object} options
 * @param {string} options.currentState - Can pass a starting state. If
 *               not set, we will immediately launch and call currentUIState().
 * @param {string} options.nonSubscriberMode - If true and we
 *               encounter the Welcome screen. We will not login
 *               but use the non-subscripter mode of Music.
 *
 * @returns None.
 *
 * @throws If we were unable to transition from some starting state to
 *           desired tab state.
 */
music.getToTabTopLevel = function getToTabTopLevel(options) {
    options = UIAUtilities.defaults(options, {
        currentState: null,
        nonSubscriberMode: true,
        user: null,
        password: null,
    });

    // Max depth from a tab top level is only 2 actions. Adding extra.
    var maxDepth = 3

    if (!options.currentState) {
        music.launch();
        options.currentState = this.currentUIState();
    }

    for (var i = 0; i < maxDepth; i++) {
        // States where you can't see the tabs
        switch (options.currentState) {
            case UIStates.NOW_PLAYING_HELP_DIALOG.Description:
                this.tap(UIAQuery.Music.DISMISS_NOW_PLAYING_HELP_DIALOG);
            case UIStates.FULL_SCREEN_PLAYER.Description:
                this.closeFullScreenPlayer();
                break;
            case UIStates.LIBRARY_POPOVER.Description:
                this.dismissPopover();
                break;
            case UIStates.SPLASH_SCREEN.Description:
                this.tap(UIAQuery.buttons('Continue'));
            case UIStates.JOIN_APPLE_MUSIC.Description:
                this.tap(UIAQuery.links('NOT NOW').orElse(UIAQuery.buttons('Not Now')));
            default:
                break;
        }

        // lets get the new state
        options.currentState = this.currentUIState();

        // List of all the state objects
        var tabNames = Object.keys(UIAQuery.Music.Evaluation.Tabs);

        // Check evaluation queries of all tabs to see if we're at the top level
        for (var i = 0; i < tabNames.length; i++) {
            var tabName = tabNames[i];
            if (this.exists(UIAQuery.Music.Evaluation.Tabs[tabName])) {
                this.tap(UIAQuery.Music.Tabs[tabName]);
                UIALogger.logMessage('Got to top level of tab %0'.format(tabName));
                return;
            }
        }
    }
}

/**
 * Navigation function to get to some category in Library tab.
 * The possible categories are listed in UIStates.
 *
 * Expected starting states: Works for any UI state.
 *
 * @returns None.
 *
 * @throws If we were unable to transition from some starting state to
 *           desired tab state.
 */
music.getToLibraryCategory = function getToLibraryCategory(category) {
    this.getToTab(UIStates.LIBRARY.Description);
    this.getToTabTopLevel();
    this.tapIfExists(UIAQuery.Music.Library.IPAD_LIBRARY_BUTTON);
    switch (category) {
        case UIStates.PLAYLISTS.Description:
            this.tap(UIAQuery.Music.Library.PLAYLISTS);
            break;
        case UIStates.SONGS.Description:
            this.tap(UIAQuery.Music.Library.SONGS);
            break;
        default:
            throw new UIAError('[%0] is not a valid Library category description'.format(category))
    }
}

/***********************************************************************************/
/*                                                                                 */
/*   Mark: Tasks                                                                   */
/*                                                                                 */
/*      A high-level goal we are trying to accomplish. E.g. - composeAndSendEmail  */
/*      These will be comprised of multiple Action functions                       */
/*                                                                                 */
/***********************************************************************************/


/**
 * Plays a song from the 'Song' category on the 'Library' tab. Choosen song
 * played is determined via an array of keywords. If keywords array is empty
 * and the random flag is not enabled the first song in the list will be played.
 *
 * Expected starting states:
 *                      Any view where the bottom tabs are visible
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for selecting
 *              a song element.
 * @param {boolean} options.random - If set and options.keywords is not set,
 *              will choose a random song to play.
 * @param {UIAQuery} options.elementsQuery - Query to song elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 * @param {boolean} options.stopCurrentPlayback - If set, will attempt to stop
 *              any current playback.
 * @param {boolean} options.confirmDesiredElementPlaying - If set, will
 *              confirm the choosen song is playing. Check is based off
 *              name that was determine via keywords or random flag.
 * @param {boolean} options.confirmPlaying - If set, will confirm something
 *              is playing. Does not check playing song's name.
 * @param {null|int} options.duration - If set, will wait passed number of
 *              seconds before test ends.
 * @param {boolean} options.stopAfterDuration - Applicable only if duration
 *              is set. If set, stops playback after the duration time has elapsed.
 *
 * @throws If selected song does not start playing.
 */
music.startSongFromSongList = function startSongFromSongList(options) {
    options = UIAUtilities.defaults(options, {
        keywords: null,
        random: false,
        elementsQuery: UIAQuery.Music.GENERAL_MUSIC_ELEMENTS,
        stopCurrentPlayback: true,
        confirmDesiredElementPlaying: true,
        confirmPlaying: true,
        duration: null,
        stopAfterDuration: true,
    });

    this.getToLibraryCategory(UIStates.SONGS.Description);
    this.startPlaybackWith(options);
}

/**
 * Starts playing a playlist from the 'Playlist' tab. Choosen playlist is
 * determined via an array of keywords. If keywords array is empty and the
 * random flag is not enabled the first playlist in the list will be played.
 * Function defaults to playing first song in playlist.
 *
 * Expected starting states:
 *                      Any view where desired playlist is listed
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for selecting
 *              a song element.
 * @param {boolean} options.random - If set and options.keywords is not set,
 *              will choose a random song to play.
 * @param {UIAQuery} options.elementsQuery - Query to playlist elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 * @param {boolean} options.stopCurrentPlayback - If set, will attempt
 *              to stop any current playback.
 * @param {boolean} options.confirmPlaying - If set, will confirm something
 *              is playing. Does not check playing song's name.
 * @param {null|int} options.duration - If set, will wait passed number of
 *              seconds before test ends.
 * @param {boolean} options.stopAfterDuration - Applicable only if duration
 *              is set. If set, stops playback after the duration time has elapsed.
 *
 * @throws If selected playlist does not start playing.
 */
music.startPlaylist = function startPlaylist(options) {
    options = UIAUtilities.defaults(options, {
        keywords: null,
        random: false,
        elementsQuery: UIAQuery.Music.GENERAL_MUSIC_ELEMENTS,
        stopCurrentPlayback: true,
        confirmPlaying: true,
        duration: null,
        stopAfterDuration: true,
    });

    this.getToLibraryCategory(UIStates.PLAYLISTS.Description);

    var [query, name] = this.selectElementToPlay(options);
    this.confirmOnDesiredPlaylist(name);

    if (this.isPlaylistEmpty()) {
        throw new UIAError('No songs in selected playlist.');
    }

    // need to update some options for song selection in playlist
    options.elementsQuery = UIAQuery.Music.GENERAL_MUSIC_ELEMENTS;
    // this will ensure we select first song of playlist
    options.keywords = null;
    options.random = false;

    this.startPlaybackWith(options);
}

/**
 * Starts playing a radio station from the 'Radio' tab. Choosen station is
 * determined via an array of keywords. If keywords array is empty and the
 * random flag is not enabled the first station in the list will be played.
 *
 * Expected starting states:
 *                      Any view where desired station is listed
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for selecting
 *              a song element.
 * @param {boolean} options.random - If set and options.keywords is not set,
 *              will choose a random song to play.
 * @param {UIAQuery} options.elementsQuery - Query to station elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 * @param {boolean} options.stopCurrentPlayback - If set, will attempt
 *              to stop any current playback.
 * @param {boolean} options.confirmPlaying - If set, will confirm something
 *              is playing. Does not check playing song's name.
 * @param {null|int} options.duration - If set, will wait passed number of
 *              seconds before test ends.
 * @param {boolean} options.stopAfterDuration - Applicable only if duration
 *              is set. If set, stops playback after the duration time has elapsed.
 *
 * @throws If selected radio station does not start playing.
 */
music.startRadioStation = function startRadioStation(options) {
    options = UIAUtilities.defaults(options, {
        keywords: ['NPR',],
        random: false,
        elementsQuery: UIAQuery.Music.GENERAL_MUSIC_ELEMENTS,
        stopCurrentPlayback: true,
        confirmPlaying: true,
        duration: null,
        stopAfterDuration: true,
    });

    if (!options.appleID) {
        UIALogger.logWarning('No Apple ID specified. Defaulting to persisted Apple ID.');
        options.appleID = springboard.appleID;
    }

    if (!options.appleIDPassword) {
        UIALogger.logWarning('No Apple ID password specified. Defaulting to persisted Apple ID password.');
        options.appleIDPassword = springboard.appleIDPassword;
    }

    var signInWaiter = UIAWaiter.withPredicate(
        'ViewDidAppear',
        'navigationItemTitle = "Sign In"'
    );

    this.handlingAlertsInline(UIAQuery.alerts().andThen('Sign In'), function() {
        // trigger alert
        this.getToTab(UIStates.RADIO.Description);

        if (signInWaiter.wait(5)) {
            if (springboard.exists(UIAQuery.alerts().andThen('Sign In'))) {
                // handle alert
                springboard.handlingAlertsInline(UIAQuery.alerts().andThen('Sign In to iTunes Store'), function() {
                    // trigger alert
                    springboard.tap(UIAQuery.alerts().andThen(UIAQuery.buttons('Use Existing Apple ID')));

                    // handle alert
                    springboard.tap(UIAQuery.alerts().andThen(UIAQuery.textFields('example@icloud.com')));
                    springboard.typeString(options.appleID);

                    springboard.tap(UIAQuery.alerts().andThen(UIAQuery.secureTextFields('Password')));
                    springboard.typeString(options.appleIDPassword);

                    springboard.tap(UIAQuery.alerts().andThen(UIAQuery.buttons('OK')));
                });
            }
        }
    });

    // This allows us to listen to the station for the duration even though there is no tracking bar
    options.validate = false;
    this.startPlaybackWith(options);
}

/**
 * Standard way to start a song. Function expects to start in view where song
 * exists; any naviagtion should be done before calling this function. Song
 * selection is based on passed values.
 *
 * Expected starting states:
 *                      Any view where desired song is listed
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for selecting
 *              a song element.
 * @param {boolean} options.random - If set and options.keywords is not set,
 *              will choose a random song to play.
 * @param {UIAQuery} options.elementsQuery - Query to music elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 * @param {boolean} options.stopCurrentPlayback - If set, will attempt
 *              to stop any current playback.
 * @param {boolean} options.confirmDesiredElementPlaying - If set, will
 *              confirm the choosen song is playing. Check is based off
 *              name that was determine via keywords or random flag.
 * @param {boolean} options.confirmPlaying - If set, will confirm something
 *              is playing. Does not check playing song's name.
 * @param {null|int} options.duration - If set, will wait passed number of
 *              seconds before test ends.
 * @param {boolean} options.stopAfterDuration - Applicable only if duration
 *              is set. If set, stops playback after the duration time has elapsed.
 * @param {boolean} options.validate - If true, it checks that the track position
 *              has changed an amount equal to the duration
 *
 * @throws If selected song does not start playing.
 */
music.startPlaybackWith = function startPlaybackWith(options) {
    options = UIAUtilities.defaults(options, {
        keywords: null,
        random: false,
        stopCurrentPlayback: true,
        confirmDesiredElementPlaying: false,
        confirmPlaying: true,
        elementsQuery: UIAQuery.Music.GENERAL_MUSIC_ELEMENTS,
        duration: null,
        stopAfterDuration: true,
        validate: true,
    });

    if (options.stopCurrentPlayback) {
        UIALogger.logMessage('Stopping any current playback.');
        // TODO: should we get to start of song?
        this.stopPlayback();
    }

    var [query, name] = this.selectElementToPlay(options);

    if (options.confirmDesiredElementPlaying) {
        this.confirmSongIsPlaying(name);
    } else if (options.isPlaying) {
        this.confirmPlaying();
    }

    if (options.duration) {
        this.playForDuration(options);
    }
}

/**
 * Allows playback to run from some duration. Track progression is validated.
 * Function expects either the song to already be playing or for some function
 * reference (func) to be passed to navigate and start playing the song.
 *
 * Expected starting states:
 *                      Any view where desired song is listed
 *
 * @param {object} options
 * @param {null|int} options.duration - If set, will wait passed number of
 *              seconds before test ends.
 * @param {boolean} options.stopAfterDuration - If set, stops playback
 *              after the duration time has elapsed.
 * @param {function} options.func - Some function to be called before
 *              duration wait.
 * @param {boolean} options.validate - If true, it checks that the track position
 *              has changed an amount equal to the duration
 *
 * @throws If track position does not change after duration wait.
 */
music.playForDuration = function playForDuration(options) {
    options = UIAUtilities.defaults(options, {
        duration: 10,   //seconds
        stopAfterDuration: true,
        func: null,
        validate: true,
    });

    if (options.func) {
        func.call(this);
    }
    var startingPosition = 0
    var endingPosition = 0

    if (options.validate) {
        UIALogger.logMessage('Playing song for %0 seconds'.format(options.duration));
        startingPosition = this.getTrackPosition();
    }

    this.delay(options.duration);

    if (options.validate) {
        // waiting on radar 21645567
        endingPosition = this.getTrackPosition();
        if (startingPosition === endingPosition) {
            throw new UIAError('Track position has not progressed.');
        }
    }

    if (options.stopAfterDuration) {
        this.stopPlayback();
    }
}

/**
 * Uses the mini/full player to navigate throught a series of actions to be
 * preformed on the control menu. i.e. 'Play', 'Pause', 'Next', ect. Any
 * navigation and playing state should be determined before this function
 * is called.
 *
 * Expected starting states:
 *                      Any view where a music player is visible
 *
 * @param {object} options
 * @param {array} options.actions - Array of actions. i.e. buttons to press on
 *              the control menu. Comes from a list of possible constants
 *              contained in Music 'Controls'.
 * @param {array} options.actionsTimeouts - If set, contains an array of timeouts
 *              for actions. i.e. after an action is taken, some delay/timeout before
 *              we do anything else. Array size must be same as 'actions' array.
 *              Array can contain null elements if no timeout is desired on an action.
 * @param {string[]} options.validateSongs - If set, contains an
 *              identifying song substring to match against after a control
 *              button has been pressed. This match is a 'contains' match.
 *              e.g. ['Bob'] would match on 'Bob Marley's greatest hits'.
 *              Array size must be same as 'actions' array. Array can contain
 *              null elements if no validation is desired on an action.
 * @param {boolean} options.fullScreenMode - If set, will open player to full screen.
 *
 * @throws If validateSongs/actionsTimeouts are set and lengths are different
 *          then actions.
 */
music.navigatePlayerControls = function navigatePlayerControls(options) {
    options = UIAUtilities.defaults(options, {
        actions: [Controls.NEXT, Controls.PREVIOUS],
        validateSongs: null,
        actionsTimeouts: null,
        fullScreenMode: true,
    });

    if (options.validateSongs && options.actions.length !== options.validateSongs.length) {
        throw new UIAError('The songs validation array length is different then the actions array length.');
    }

    if (options.actionsTimeouts && options.actions.length !== options.actionsTimeouts.length) {
        throw new UIAError('The actions timeouts array length is different then the actions array length.');
    }

    if (options.fullScreenMode) {
        this.openFullScreenPlayer();
    } else {
        // no-op if not in full screen
        this.closeFullScreenPlayer();
    }

    for (var i = 0; i < options.actions.length; i++) {
        this.tapControl(options.actions[i]);

        if (options.validateSongs && options.validateSongs[i]) {
            this.confirmSongLoaded(options.validateSongs[i]);
            UIALogger.logMessage('Correct song appears to be loaded.');
        }

        if (options.actionsTimeouts && options.actionsTimeouts[i]) {
            UIALogger.logMessage(
                'Action timeout of %0 seconds for action %1.'
                .format(options.actionsTimeouts[i], options.actions[i])
            );
            this.delay(options.actionsTimeouts[i]);
        }
    }
}

/*******************************************************************************/
/*                                                                             */
/*   Mark: Actions                                                             */
/*                                                                             */
/*      Atomic units of UI automation. E.g. - dialPhoneNumber                  */
/*      Other helper functions. E.g. - returnCleanedNumber                     */
/*                                                                             */
/*******************************************************************************/

/**
 * Selects an element to play and taps to begin playback.
 * Selection is based on passed values.
 * i.e.:
 *   - If an array of keywords is passed, we will attempt to find
 * a music element that meets the match from the elementsQuery list.
 * If more then one elements matches all the keywords, we will use the first.
 *   - If the keywords array is empty and the random flag enabled,
 * we select a random element from the elementsQuery list.
 *   - If the keywords array is empty and the random flag is not
 * enabled, we will select the first element from elementsQuery list.
 *
 * Expected starting states:
 *                      Any view where desired song is listed
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for
 *              selecting a music element.
 * @param {boolean} options.random - If set and options.keywords
 *              is not set, will choose a random music element to play.
 * @param {UIAQuery} options.elementsQuery - Query to song elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 *
 * @returns [UIAQuery, string] Array. First element is UIAQuery to
 *              element. Second element is name of element.
 */
music.selectElementToPlay = function selectElementToPlay(options) {
    var element = this.chooseElementToSelect(options);
    var name = this.inspectElementKey(element, 'name');

    UIALogger.logMessage(
        'Attempting to select element with name [%0]'.format(name)
    );
    this.tap(element);

    // some junk can be added to the name (song position, if its available off/online)
    name = name.replace('Paused, ', '').replace('Now playing, ', '').split(',');
    name = name[0];
    UIALogger.logMessage('Shortening name to: [%0]'.format(name));

    return [element, name];
}

/**
 * Creates a query for selecting a song/playlist/radio station/etc
 * to play from the current view. Selection is based on passed values.
 * i.e.:
 *   - If an array of keywords is passed, we will attempt to find
 * a music element that meets the match from the elementsQuery list.
 * If more then one elements matches all the keywords, we will use the first.
 *   - If the keywords array is emtpy and the random flag enabled,
 * we select a random element from the elementsQuery list.
 *   - If the keywords array is emtpy and the random flag is not
 * enabled, we will select the first element from elementsQuery list.
 *
 * Expected starting states:
 *                      Any view where desired song is listed
 *
 * @param {object} options
 * @param {null|string[]} options.keywords - Search terms for
 *              selecting a music element.
 * @param {boolean} options.random - If set and options.keywords
 *              is not set, will choose a random music element to play.
 * @param {UIAQuery} options.elementsQuery - Query to song elements on tab.
 *              i.e. some list of music elements
 *              e.g.: UIAQuery.tableViews('MusicTableView').andThen(
 *                         UIAQuery.tableCells()
 *                    )
 *
 * @returns {UIAQuery} Query for song to play.
 */
music.chooseElementToSelect = function chooseElementToSelect(options) {
    options = UIAUtilities.defaults(options, {
        keywords: null,
        random: false,
        elementsQuery: UIAQuery.Music.GENERAL_MUSIC_ELEMENTS,
    });

    // choose first element if no keywords and random not enabled
    if (!options.keywords && !options.random) {
        UIALogger.logMessage('Choosing first element to select.');
        return options.elementsQuery.first();
    }

    // choose random if no keywords and random enabled
    if (!options.keywords && options.random) {
        UIALogger.logMessage('Choosing random element to select.');
        var upperBound = this.count(options.elementsQuery);
        var randomInt = UIAUtilities.randomInt(0, upperBound > 0 ? upperBound - 1 : 0);
        return options.elementsQuery.atIndex(randomInt);
    }

    // If we get here, will need to create query with keywords
    UIALogger.logMessage('Using following keywords to choose element to select: %0'.format(
        JSON.stringify(options.keywords)
    ));

    return this.createKeywordsQuery(
        options.keywords,
        {'startingQuery':options.elementsQuery}
    );
}

/**
 * Taps a button on the control panel of the mini/full screen music player.
 *
 * Expected starting states:
 *                       Any view where a music player is visible
 *                          (mini or full screen)
 *
 * @param {string} controlButton - Control button to tap on music player
 *
 * @returns None
 */
music.tapControl = function tapControl(controlButton) {
    if (!controlButton) {
        throw new UIAError('No control button was passed.');
    }

    UIALogger.logMessage(
        'Attempting to tap button [%0] on music player\'s controls.'
        .format(controlButton)
    );

    switch (controlButton) {
        case Controls.PAUSE:
            this.tap(UIAQuery.Music.Player.PLAY_PAUSE_BUTTON);
            return;
        case Controls.PLAY:
            this.tap(UIAQuery.Music.Player.PLAY_PAUSE_BUTTON);
            return;
        case Controls.NEXT:
            this.tap(UIAQuery.Music.Player.NEXT_BUTTON);
            return;
        case Controls.PREVIOUS:
            this.tap(UIAQuery.Music.Player.PREVIOUS_BUTTON);
            return;
        default:
            throw new UIAError(
                'Action [%0] is not supported.'
                .format(options.actions[i])
            );
    }
}

/**
 * Creates a withPredicate query anding the contents of 'keywords'.
 *
 * Expected starting states:
 *                      Helper function. Not UI dependent.
 *
 * @param {object} options
 * @param {UIAQuery} options.startingQuery - Query to append withPredicate
 *              query to.
 *
 * @returns {UIAQuery} Query for song to play.
 */
music.createKeywordsQuery = function createKeywordsQuery(keywords, options) {
    options = UIAUtilities.defaults(options, {
        startingQuery: null,
    });

    // array check
    if (keywords.length === 0) {
        throw new UIAError('No keywords were passed to create search/query with.');
    }

    var predicate = 'name contains[c] "%0"'.format(keywords[0]);

    for (var i = 1; i < keywords.length; i++) {
        predicate = '%0 && name contains[c] "%1"'.format(predicate, keywords[i]);
    }

    var query = UIAQuery.withPredicate('%0'.format(predicate));

    if (!options.startingQuery) {
        return query
    }

    return options.startingQuery.andThen(query);
}

/**
 * Determines if mini player is displayed on screen.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns {boolean} - True if mini player on screen. False otherwise.
 */
music.isMiniPlayerVisible = function isMiniPlayerVisible() {
    return this.exists(UIAQuery.Music.Evaluation.Players.MINI_PLAYER.isVisible());
}

/**
 * Determines if full player is displayed on screen.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns {boolean} - True if full player on screen. False otherwise.
 */
music.isFullScreenPlayerVisible = function isFullScreenPlayerVisible() {
    return this.exists(UIAQuery.Music.Evaluation.Players.FULL_SCREEN_PLAYER);
}

/**
 * Opens the player in full screen mode. No-opt if full screen
 * player already open.
 *
 * Expected starting states:
 *              Any top level Music view with a mini-player visible
 *
 * @returns None
 */
music.openFullScreenPlayer = function openFullScreenPlayer() {
    if (this.exists(UIAQuery.Music.Evaluation.Players.FULL_SCREEN_PLAYER)) {
        return;
    }

    UIALogger.logMessage('Opening player to full screen.');
    this.tap(UIAQuery.Music.Evaluation.Players.MINI_PLAYER);
}

/**
 * Reduces the full screen player to mini-player. No-opt if
 * full screen player already closed.
 *
 * Expected starting states:
 *              UIStates.FULL_SCREEN_PLAYER
 *              UIStates.NOW_PLAYING_HELP_DIALOG
 *
 * @returns None
 */
music.closeFullScreenPlayer = function closeFullScreenPlayer() {
    this.dismissNowPlayingHelpDialog();

    if (this.exists(UIAQuery.Music.Evaluation.Players.MINI_PLAYER)) {
        UIALogger.logMessage('Mini player is present. Will not attempt to dismiss full screen player');
    } else {
        UIALogger.logMessage('Closing full screen player.');
        this.tap(UIAQuery.Music.DISMISS_FULL_SCREEN_PLAYER);
    }

    if (this.currentUIState() == UIStates.FULL_SCREEN_PLAYER.Description) {
        throw new UIAError('Could not dismiss full screen player');
    }
}

/**
 * Determines if music is currently playing.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns {boolean} - True if music is playing. False otherwise.
 */
music.isPlaying = function isPlaying() {
    var inspectPlayPauseButton = this.inspect(UIAQuery.Music.Player.PLAY_PAUSE_BUTTON)
    return (inspectPlayPauseButton && inspectPlayPauseButton.label != 'Play');
}

/**
 * Determines if the Now Playing help dialog is open.
 *
 * Expected starting states:
 *              Any Music view
 *
 * @returns {boolean} - True if the Now Playing dialog is absent at the end, otherwise False
 */
music.dismissNowPlayingHelpDialog = function dismissNowPlayingHelpDialog() {
    if (UIStates.NOW_PLAYING_HELP_DIALOG.isCurrentState(this.inspect(UIAQuery.application()))) {
        UIALogger.logMessage('Currently in state "Now Playing help dialog"');
        this.tap(UIAQuery.Music.DISMISS_NOW_PLAYING_HELP_DIALOG);
    }
    return !UIStates.NOW_PLAYING_HELP_DIALOG.isCurrentState(this.inspect(UIAQuery.application()));
}

/**
 * Stops/pauses any playback that is currently playing. No-opt
 * if nothing is playing.
 *
 * Expected starting states:
 *              Any top level Music view with a mini-player visible
 *              UIStates.FULL_SCREEN_PLAYER
 *              UIStates.NOW_PLAYING_HELP_DIALOG
 *
 * @param {object} options
 * @param {UIAQuery} options.failOnNoPlay - Flag to throw if nothing is playing
 *              before stopping music.
 *
 * @returns If failOnNoPlay is set and nothing is playing.
 */
music.stopPlayback = function stopPlayback(options) {
    options = UIAUtilities.defaults(options, {
        failOnNoPlay: false,
    });

    this.dismissNowPlayingHelpDialog();

    if (!this.isPlaying()) {
        if (options.failOnNoPlay) {
            throw new UIAError('Cannot stop playback as nothing was playing.')
        }

        return;
    }

    UIALogger.logMessage('Stopping playback.');
    this.tap(UIAQuery.Music.Player.PLAY_PAUSE_BUTTON);

    if (this.isPlaying()) {
        throw new UIAError('Could not stop/pause playback.');
    }
}

/**
 * Confirms something is currently playing.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns none
 */
music.confirmIsPlaying = function confirmIsPlaying() {
    if (!this.isPlaying()) {
        throw new UIAError('No song is playing.');
    }
    UIALogger.logMessage('Music is playing.');
}

/**
 * Confirms song with name/identifier is currently loaded. i.e.
 * displayed in player.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns none
 */
music.confirmSongLoaded = function confirmSongLoaded(expectedName) {
    var actualName = '';

    if (this.isFullScreenPlayerVisible()) {
        actualName = this.inspectElementKey(UIAQuery.Music.FULL_SCREEN_PLAYER_SONG_NAME.andThen(UIAQuery.query('MPUMarqueeView')), 'label');
    } else {
        actualName = this.inspectElementKey(UIAQuery.Music.MINI_PLAYER_SONG_NAME, 'label');
    }
    if (!actualName.contains(expectedName)) {
        UIALogger.logError('A song is loaded but it is not the one expected. We expected [%0] but the song that is loaded is [%1]'.format(expectedName, actualName));
        throw new UIAError('A song is loaded but it is not the one expected.');
    }
}

/**
 * Confirms song with name/identifier is currently playing.
 *
 * Expected starting states:
 *              Any top level Music view
 *
 * @returns none
 */
music.confirmSongIsPlaying = function confirmSongIsPlaying(name) {
    // confirm something is playing
    this.confirmIsPlaying();

    // ensure corrected song
    this.confirmSongLoaded(name);
    UIALogger.logMessage('Song with string [%0] appears to be playing.'.format(name))
}

/**
 * Confirms something is currently playing.
 *
 * Expected starting states:
 *              UIStates.PLAYLIST
 *
 * @returns none
 */
music.confirmOnDesiredPlaylist = function confirmOnDesiredPlaylist(name) {
    if (this.valueOf(UIAQuery.Music.PLAYLIST_HEADER) !== name) {
        throw new UIAError('Not in desired playlist.');
    }
}

/**
 * Determines if playlist has music in it or if empty.
 *
 * Expected starting states:
 *              UIStates.PLAYLIST
 *
 * @returns {boolean} - True if playlist has music. False otherwise.
 */
music.isPlaylistEmpty = function isPlaylistEmpty() {
    if (this.count(UIAQuery.Music.GENERAL_MUSIC_ELEMENTS) === 0) {
        return true;
    }

    return false;
}

/**
 * Gets the track position of the currently playing song.
 *
 * Expected starting states:
 *              Any top level Music view with a mini-player visible
 *              UIStates.FULL_SCREEN_PLAYER
 *              UIStates.NOW_PLAYING_HELP_DIALOG
 *
 * @returns string of current track position
 */
music.getTrackPosition = function getTrackPosition() {
    this.openFullScreenPlayer();
    this.dismissNowPlayingHelpDialog();
    var trackPosition = this.inspect(UIAQuery.Music.TRACK_POSITION);
    if (!trackPosition) {
        throw new UIAError('Cannot get track position. Is the player on screen?');
    }

    // waiting on radar 21645567
    trackPosition = trackPosition.value;
    UIALogger.logMessage('Track position is %0'.format(trackPosition));
    return trackPosition;
}

/**
 * Gets the shuffle or repeat state of the currently song
 *
 * Expected starting states:
 *              UIStateDescription.Music.FULL_SCREEN_PLAYER
 *
 * @param {UIAQuery} - UIAQuery.Music.Player.SHUFFLE_BUTTON
 *                     UIAQuery.Music.Player.REPEAT_BUTTON
 *
 * @returns string of current shuffle or repeat state
 */
music.getRepeatShuffleState = function getRepeatShuffleState(button) {
    if (!this.exists(button)) {
        this.dragUpInside(UIAQuery.Music.Evaluation.Players.FULL_SCREEN_PLAYER);
    }
    UIAUtilities.assert(this.exists(button),'Cannot find "Shuffle" or "Repeat" button');
    var buttonState = this.inspect(button);
    buttonState = buttonState.isSelected;
    UIALogger.logMessage('Shuffle/Repeat state currently set to:' + buttonState);
    return buttonState;
}
