#!/bin/bash

if [ -z "${LIB_DIR}" ]; then
  LIB_DIR=/var/mobile/Library
fi

ditto content ${LIB_DIR}

exit $?
