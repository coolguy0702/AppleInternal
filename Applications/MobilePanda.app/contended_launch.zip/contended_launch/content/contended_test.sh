#!/bin/bash
#contended_test -l <AppName> -f <FilePath> -c <PPT Command>

RED='\033[0;31m'
NC='\033[0m'

usage() {
    echo "This script allows you to run a PPT test with CPU contention replayed from workload seen in artraces"
    echo "It takes a PPT command to run or the name of an App to launch"
    echo "Usage:"
    echo "      contended_test -l <AppName> -f <FilePath> -c <PPT Command>"
    echo "          -l     Name of the App to launch as expected by PPT"
    echo "          -f     Path to the CSV file that encodes the scheduler states <optional>"
    echo "          -c     PPT command to run"
}

contended_test() {
    command=$1
    if [[ ! -z $command ]]; then
        #Recap adds delay to when PPT starts and when launch actually starts in Peace. Delay the start of schedtool so that it overlaps with the launch

        #*********** Figure out if we are running on iOS running Peace or newer *************
        product=`sw_vers | grep ProductName| awk '{print $2}'`
        isPeaceOrNewer=0
        if [[ $product == "iPhone" ]]; then
            train=`sw_vers | grep BuildVersion| awk '{print $2}'| sed -e s/[A-Z]/\ /g| awk '{print $1}'`
            isPeaceOrNewer=$(( $train >= 16 ))
        fi
        #*************************************************************************************

        # workaround to run ppt command with double quoted "launch suspended"
        command=$(echo "$command" | sed -e "s/launch suspended/\"launch suspended\"/g")
        echo -e "Running command ${RED}$command${NC} with contention from ${RED}$CPU_CONTENTION_FILE_PATH${NC}"
        $command&

        #Deal with recap latency
        if [[ $isPeaceOrNewer != 0 ]]; then
            sleep 3
        fi

        schedtool --fg-sleep=0 --file $CPU_CONTENTION_FILE_PATH > /dev/null&

        #************** Checks to make sure that schedtool ran during the test ***************
        startCPUUtilization=0
        #If schedtool is not running fail the test
        if [[ -z `pidof schedtool` ]]; then
            echo -e "${RED}TEST FAILED!! Schedtool not running${NC}"
            killall ppt
            exit 1
        else
            startCPUUtilization=`easyperf -p schedtool 2>&1| grep cpu_time| awk '{print $1}'`
            echo "Start Utilization $startCPUUtilization ms"
        fi
        #*************************************************************************************

        #Wait for PPT to exit before killing schedtool
        while [[ ! -z `pidof ppt` ]]
        do
            sleep 1
        done
        killall schedtool
    fi
}

APP_NAME=""
CPU_CONTENTION_FILE_PATH="contended_launch_default_load.csv"
PPT_COMMAND=""

if [[ $# == 0 ]]; then
    usage
    exit 0
fi

#Iterate the arguments provided to the shell script
while [[ $# != 0 ]]
do
    input_arg=$1
    if [[ $input_arg == "-l" ]]; then
        shift
        APP_NAME=$1
    fi

    if [[ $input_arg == "-f" ]]; then
        shift
        CPU_CONTENTION_FILE_PATH=$1
    fi

    if [[ $input_arg == "-c" ]]; then
        shift
        PPT_COMMAND="$@"
    fi
    shift
done

#If we have a PPT command then we run it else we look at other arguments
if [[ ! -z $PPT_COMMAND ]]; then
    contended_test "$PPT_COMMAND"
elif [[ ! -z $APP_NAME ]]; then
    command="ppt -e $APP_NAME -t launch"
    contended_test "$command"
else
    usage
    exit 0
fi

