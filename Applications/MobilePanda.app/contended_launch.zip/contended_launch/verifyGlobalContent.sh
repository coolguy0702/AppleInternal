#!/bin/bash

if [ -z "${LIB_DIR}" ]; then
  LIB_DIR=/var/mobile/Library
fi

CSV_PATH="${LIB_DIR}/contended_launch_default_load.csv"
if [ ! -e "$CSV_PATH" ]
then
    echo "CSV file for contended test not found."
    exit 1
fi

SHELL_SCRIPT_PATH="${LIB_DIR}/contended_test.sh"
if [ ! -e "$SHELL_SCRIPT_PATH" ]
then
    echo "Shell script file for contended test not found."
    exit 1
fi

echo "Global content installed successfully"

exit 0
